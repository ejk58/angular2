pipelineTest_v2_openshift {
    deploymentId = "iva-spring-batch"
    robotTestPath = "ProjectSpringBatch"
    robotArguments = "--include FINAL --exclude NIGHTLY"
    robotNonCriticals = "--noncritical NONCRITICAL"
    environmentChoices = "ont\ntst\nacc"
    streetChoices = "1\n2\n3\n4\n5\n6"
}