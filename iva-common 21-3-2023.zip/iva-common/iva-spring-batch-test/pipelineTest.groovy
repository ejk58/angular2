pipelineTest_v5_Smoke {
	deploymentId = "iva-spring-batch"
	robotTestPath = "ProjectSpringBatch"
	robotArguments = "-v BROWSER:headlesschrome -v GRID_URL:selenium-hub-wd-selenium-grid-4.apps.cn01.chp.belastingdienst.nl --include FINAL"
	robotNonCriticals = "--noncritical NONCRITICAL"
	environmentChoices = "ont\ntst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6"
	robotDir = "/srv/jenkins/home/robotframework_413/bin/"
    }
	
