@Library("GENERIC") _
    pipelineRelease {
    baseDirectory = ""
	deploymentId = "iva-common"
	deployPipeline = ""
	integrationPipeline = ""
	environmentChoices = "tst\nacc"
	streetChoices = "str11"
}
