package nl.belastingdienst.iva.common.springboot.domain;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class NaamNummerDTO {
	private String naam;
	private Integer nummer;
}
