package nl.belastingdienst.iva.common.springboot.exceptions;

public class NotChangedException extends RuntimeException {
	private static final long serialVersionUID = -7938968847856662248L;

	public NotChangedException(String message) {
		super(message);
	}
}
