package nl.belastingdienst.iva.common.springboot.exceptions;

public interface ErrorTypeInterface {
    String getType();
    String getTitle();
}
