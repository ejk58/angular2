package nl.belastingdienst.iva.common.springboot.security2.jwt;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JwtRequest {
	private String username;
	private String password;
}
