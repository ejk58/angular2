package nl.belastingdienst.iva.common.springboot.security2.jwt;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.BASIC_PREFIX;
import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.TOKEN_PREFIX;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.LdapUserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import nl.belastingdienst.iva.common.springboot.security2.BdGroup2RoleMapper;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class JwtRequestFilter extends OncePerRequestFilter {
	private final JwtTokenUtil jwtTokenUtil;
	private final LdapUserDetailsService ldapUserDetailsService;
	private final BdGroup2RoleMapper bdGroup2RoleMapper;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {
		final String requestTokenHeader = request.getHeader(HEADER_STRING);
		String username = null;
		String jwtToken;

		if (requestTokenHeader != null) {
			if (requestTokenHeader.startsWith(TOKEN_PREFIX)) {
				jwtToken = requestTokenHeader.substring(7);
				username = jwtTokenUtil.getUsernameFromToken(jwtToken);
			} else if (!requestTokenHeader.startsWith(BASIC_PREFIX)) {
				logger.error("JWT Token does not begin with Bearer String");
			}
		}
		if (username != null && SecurityContextHolder.getContext()
													 .getAuthentication() == null) {
			UserDetails userDetails = this.ldapUserDetailsService.loadUserByUsername(username);
			Collection<? extends GrantedAuthority> roles = bdGroup2RoleMapper.mapAuthorities(userDetails.getAuthorities());
			UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
					userDetails, null, roles);
			usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
			SecurityContextHolder.getContext()
								 .setAuthentication(usernamePasswordAuthenticationToken);
		}
		chain.doFilter(request, response);
	}
}
