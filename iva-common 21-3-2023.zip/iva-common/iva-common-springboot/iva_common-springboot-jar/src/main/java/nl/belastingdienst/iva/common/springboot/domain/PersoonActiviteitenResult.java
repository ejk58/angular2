package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

import java.util.List;

@Data
public class PersoonActiviteitenResult {
    private Persoon persoon;
    private List<FiscaleActiviteit> fiscaleActiviteiten;
}
