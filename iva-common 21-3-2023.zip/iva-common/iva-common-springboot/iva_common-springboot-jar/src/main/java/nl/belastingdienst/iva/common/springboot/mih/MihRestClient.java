package nl.belastingdienst.iva.common.springboot.mih;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

import nl.belastingdienst.iva.common.springboot.domain.EntiteitPersonenResult;
import nl.belastingdienst.iva.common.springboot.domain.EntiteitResult;
import nl.belastingdienst.iva.common.springboot.domain.PersoonActiviteitenResult;
import nl.belastingdienst.iva.common.springboot.domain.PersoonEntiteitenResult;
import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.common.springboot.exceptions.UpstreamException;
import nl.belastingdienst.iva.common.springboot.mih.domain.*;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class MihRestClient {
    private static final String BEARER = "Bearer ";
    private static final String MIH_BASE = "mih.base";
    private static final String PASSWORD_ENCRYPTION_FAILED = "Password encryption failed";
    private static String userToken;
    private final Environment env;
    private final RestTemplate restTemplate;

    public PersoonActiviteitenResult getPersoonActiviteiten(Integer finr) {
        String resource = env.getRequiredProperty(MIH_BASE) +
                "/economische_activiteiten/personen/v1/finr/" +
                String.format("%09d", finr);

        return getMihResult(resource, PersoonActiviteitenResult.class, "getPersoonActiviteiten", finr.toString());
    }

    public PersoonEntiteitenResult getPersoonEntiteiten(Integer finr) {
        String resource = env.getRequiredProperty(MIH_BASE) +
                "/entiteiten/personen/v1/finr/" +
                String.format("%09d", finr);
        return getMihResult(resource, PersoonEntiteitenResult.class, "getPersoonEntiteiten", finr.toString());
    }

    public EntiteitResult getEntiteit(Integer entiteitNummer) {
        String resource = env.getRequiredProperty(MIH_BASE) +
                "/entiteiten/v1/dosnr/" +
                entiteitNummer.toString();
        return getMihResult(resource, EntiteitResult.class, "getEntiteit", entiteitNummer.toString());
    }

    public EntiteitPersonenResult getEntiteitPersonen(Integer entiteitNummer) {
        String resource = env.getRequiredProperty(MIH_BASE) +
                "/entiteiten/deelnemers/v1/dosnr/" +
                entiteitNummer.toString();
        return getMihResult(resource, EntiteitPersonenResult.class, "getEntiteitPersonen", entiteitNummer.toString());
    }

    private <T> T getMihResult(String resource, Class returnClass, String what, String key) {
        HttpEntity<?> request = new HttpEntity<>(getHttpHeaders(true));
        ResponseEntity<T> responseEntity = null;
        try {
            responseEntity = restTemplate.exchange(resource, HttpMethod.GET, request, returnClass);
        } catch (HttpStatusCodeException e) {
            handleMihErrorStatus(e, false, what, key);
        } catch (RestClientException e) {
            handleGenericMihError(e, false, what, key);
        }
        return (responseEntity.getBody() == null) ? null : responseEntity.getBody();
    }

    private void handleMihErrorStatus(HttpStatusCodeException e, boolean login, String what, String key) {
        log.error("MIH {} geeft returncode = {} bij {}. Body = {}", login ? "login" : "", e.getRawStatusCode(), what, e.getResponseBodyAsString());
        if (e.getResponseBodyAsString().contains("not found") ||
                e.getResponseBodyAsString().contains("FinrValidation"))
            throw new NotFoundException("", what, key, "Not found");
        else
            throw new UpstreamException("Fout bij de benadering van MIH");
    }

    private void handleGenericMihError(RestClientException e, boolean login, String what, String key) {
        log.error("MIH {} geeft message = {} bij {}. ", login ? "login" : "", e.getMessage(), what);
        throw new UpstreamException("Fout bij de benadering van MIH");
    }

    private String getToken() {
        if (userToken != null) {
            DecodedJWT token = JWT.decode(userToken);
            Date expire = token.getExpiresAt();
            Date minDate = new Date();
            minDate.setTime(minDate.getTime() + 5000);
            if (expire.after(minDate)) return userToken;
        }
        final HttpHeaders headers = getHttpHeaders(false);

        String wachtwoordSleutel = getWachtwoordsleutel(headers);

        userToken = getUserToken(headers, wachtwoordSleutel);
        return userToken;
    }

    private String getUserToken(HttpHeaders headers, String wachtwoordSleutel) {
        MihLogin login = null;
        try {
            login = new MihLogin(env.getProperty("mih.username"), encrypt(env.getRequiredProperty("mih.password"), wachtwoordSleutel));
        } catch (BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException | NoSuchAlgorithmException | InvalidKeyException | UnsupportedEncodingException e) {
            log.error(PASSWORD_ENCRYPTION_FAILED, e);
            throw new RuntimeException(PASSWORD_ENCRYPTION_FAILED);
        }
        String resource = env.getRequiredProperty(MIH_BASE) +
                "/platform/gebruikers/v1/login";
        HttpEntity<Object> request = new HttpEntity<>(login, headers);

        ResponseEntity<MihLoginResult> responseEntity = null;
        try {
            responseEntity = restTemplate.postForEntity(resource, request, MihLoginResult.class);
        } catch (HttpStatusCodeException e) {
            handleMihErrorStatus(e, true, "Login", "");
        } catch (RestClientException e) {
            handleGenericMihError(e, true, "Login", "");
        }
        return (responseEntity.getBody() == null) ? null : responseEntity.getBody().getJsonWebToken();
    }

    private String getWachtwoordsleutel(HttpHeaders headers) {
        String resource = env.getRequiredProperty(MIH_BASE) +
                "/platform/gebruikers/v1/wachtwoordsleutel";
        HttpEntity<?> request1 = new HttpEntity<>(headers);
        ResponseEntity<MihWachtwoordsleutelResult> responseEntity1 = null;
        try {
            responseEntity1 = restTemplate.exchange(resource, HttpMethod.GET, request1, MihWachtwoordsleutelResult.class);
        } catch (HttpStatusCodeException e) {
            handleMihErrorStatus(e, true, "Wachtwoordsleutel", "");
        } catch (RestClientException e) {
            handleGenericMihError(e, true, "Wachtwoordsleutel", "");
        }
        String wachtwoordSleutel = (responseEntity1.getBody() == null) ? null : responseEntity1.getBody().getValue();
        if (wachtwoordSleutel == null) {
            log.error(PASSWORD_ENCRYPTION_FAILED + " empty passwordkey");
            throw new RuntimeException(PASSWORD_ENCRYPTION_FAILED);
        }
        return wachtwoordSleutel;
    }

    private HttpHeaders getHttpHeaders(boolean withToken) {
        String token = withToken ? getToken() : env.getProperty("mih.apikey");
        final HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.set("UserToken", BEARER + token);
        headers.set(HttpHeaders.AUTHORIZATION, BEARER + env.getProperty("mih.apikey"));
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        return headers;
    }

    private String encrypt(String toEncrypt, String passwordKey) throws BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        MessageDigest sha = MessageDigest.getInstance("SHA-1");
        byte[] key = sha.digest(passwordKey.getBytes(StandardCharsets.UTF_8));
        key = Arrays.copyOf(key, 16);
        SecretKeySpec aesKey = new SecretKeySpec(key, "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, aesKey);
        byte[] value = cipher.doFinal(toEncrypt.getBytes());
        return new String(Base64.getEncoder().encode(value));
    }
}
