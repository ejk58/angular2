package nl.belastingdienst.iva.common.springboot.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class NotFoundException extends RuntimeException {
	private static final long serialVersionUID = -1L;
	private Object object;
	private String what;
	private String key;
	private String why;
}
