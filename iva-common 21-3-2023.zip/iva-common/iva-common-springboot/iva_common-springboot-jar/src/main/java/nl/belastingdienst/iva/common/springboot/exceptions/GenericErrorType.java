package nl.belastingdienst.iva.common.springboot.exceptions;

public enum GenericErrorType implements ErrorTypeInterface {
	JSON_FORMAT("/errors/json_format", "The provided json has a wrong format"),
	ARGUMENT_FORMAT("/errors/argument_format", "A parameter has the wrong format"),
	SYSTEM_CONFIG("/errors/system_config", "The system has a wrong configuration"),
	FORBIDDEN("/errors/forbidden", "This operation is not allowed"),
	UPSTREAM_UNAVAILABLE("/errors/upstream_unavailable", "No connection possible to another system"),
	NOT_FOUND("/errors/not_found", "The requested resource is not found"),
	ALREADY_EXISTS("/errors/already_exists", "The entity to be inserted already exists"),
	NOT_POSSIBLE("/errors/not_possible", "The requested action is not possible"),
	VALIDATION("/errors/validation", "The validation for this request failed"),
	UNAUTHORIZED("/errors/unauthorized", "You are not authorized for this operation"),
	BAD_TOKEN("/errors/bad_token", "The provided token is not valid"),
	UNCLASSIFIED("/errors/unclassified", "Unclassified error"),
	NOT_ANTICIPATED("/errors/not_anticipated", "Unexpected error"),
	CONFLICT("/errors/conflict", "Conflicting changes, not changed");

	private final String type;
	private final String title;

	GenericErrorType(String type, String title) {
		this.title = title;
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public String getTitle() {
		return title;
	}
}
