package nl.belastingdienst.iva.common.springboot.security2;

import java.time.LocalDateTime;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LocalTimeZone {
	public LocalTimeZone() {
		java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("Europe/Amsterdam"));
		log.info("LocalDateTime in {}: {}", java.util.TimeZone.getDefault()
															  .getDisplayName(), LocalDateTime.now());
	}
}
