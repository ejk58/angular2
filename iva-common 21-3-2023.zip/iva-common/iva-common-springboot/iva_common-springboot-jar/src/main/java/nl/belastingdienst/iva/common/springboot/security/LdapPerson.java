package nl.belastingdienst.iva.common.springboot.security;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class LdapPerson {
    private String userId;
    private String name;
    private String email;
    private List<String> adGroepen;

    public LdapPerson() {
        this.adGroepen = new ArrayList<>();
    }
}
