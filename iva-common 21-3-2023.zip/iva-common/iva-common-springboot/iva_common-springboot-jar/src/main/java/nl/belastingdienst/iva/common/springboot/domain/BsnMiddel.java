package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

@Data
public class BsnMiddel {
    private Long bsn;
    private String belastingmiddel;
}
