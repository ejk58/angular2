package nl.belastingdienst.iva.common.springboot.security;

import com.auth0.jwt.JWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.exceptions.ApiError;
import nl.belastingdienst.iva.common.springboot.exceptions.GenericErrorType;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static com.auth0.jwt.algorithms.Algorithm.HMAC512;
import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.*;
import static java.util.stream.Collectors.*;

@Log4j2
public class JWTLoginFilter extends AbstractAuthenticationProcessingFilter {
    private final LdapTemplate ldapTemplate;
    private final Environment env;
    private final List<RoleMapping> roleMappings;

    public JWTLoginFilter(Environment env,
                          LdapTemplate ldapTemplate,
                          List<RoleMapping> roleMappings) {
        super(env.getRequiredProperty("jwt.login.url"));
        this.env = env;
        this.ldapTemplate = ldapTemplate;
        this.roleMappings = roleMappings;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest req, HttpServletResponse res) {
        try {
            LoginCredentials user = new ObjectMapper()
                    .readValue(req.getInputStream(), LoginCredentials.class);

            if (user.getPassword().isEmpty()) {
                user.setPassword(null);
            }
            if (!ldapTemplate.authenticate(env.getRequiredProperty("ldap.partitionSuffix"), "(cn=" + user.getUsername() + ")", user.getPassword())) {
                throw new BadCredentialsException(user.getUsername() + ": Verkeerd userid of password");
            }
            List<GrantedAuthority> rollen = getGrantedAuthorities(user);
            if (rollen.isEmpty())
                throw new InsufficientAuthenticationException(user.getUsername() + ": Niet de juiste rol");
            return new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword(), rollen);
        } catch (IOException e) {
            throw new UsernameNotFoundException("Credentials not found in the input");
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest req,
                                            HttpServletResponse res,
                                            FilterChain chain,
                                            Authentication auth) throws IOException, ServletException {
        String[] authority = auth.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toArray(String[]::new);
        long geldigheid = Long.parseLong(Objects.requireNonNull(env.getProperty("jwt.max.days"))) * 24 * 60 * 60 * 1000;
        String token = JWT.create()
                .withSubject(auth.getPrincipal().toString())
                .withArrayClaim(AUTHORITIES_STRING, authority)
                .withExpiresAt(new Date(System.currentTimeMillis() + geldigheid))
                .sign(HMAC512(env.getRequiredProperty("jwt.secret").getBytes()));
        res.addHeader(HEADER_STRING, TOKEN_PREFIX + token);

        String rollen = auth.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .distinct()
                .collect(joining(","));
        res.addHeader(HEADER_ROLES, rollen);
    }

    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException ex) throws IOException {
        ApiError apiError;
        if (ex instanceof InsufficientAuthenticationException) {
            apiError = new ApiError(GenericErrorType.FORBIDDEN,ex.getMessage());
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        } else {
            apiError = new ApiError(GenericErrorType.UNAUTHORIZED,ex.getMessage());
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        }

        log.info("Login van {} ({})", apiError.getDetail(), response.getStatus());
        ObjectMapper mapper = new ObjectMapper();
        response.getWriter().write(mapper.writeValueAsString(apiError));
    }

    private List<GrantedAuthority> getGrantedAuthorities(LoginCredentials user) {
        LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
                .base(env.getRequiredProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
                .is(user.getUsername());
        List<LdapPerson> users = ldapTemplate.search(query, new LdapPersonAttributesMapper(env.getProperty("ldap.emailKey")));
        assert !users.isEmpty();
        List<String> groepen = users.get(0).getAdGroepen();
        return this.roleMappings.stream()
                .filter(mapping -> groepen.contains(mapping.getLdapGroup()))
                .map(roleMapping -> new SimpleGrantedAuthority(roleMapping.getRole()))
                .collect(toList());
    }
}
