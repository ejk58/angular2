package nl.belastingdienst.iva.common.springboot.security2.jwt;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public class JwtResponse {
	private final String token;
}
