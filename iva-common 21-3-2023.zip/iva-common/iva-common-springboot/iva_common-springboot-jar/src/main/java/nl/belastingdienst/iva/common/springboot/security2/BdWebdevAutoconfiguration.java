package nl.belastingdienst.iva.common.springboot.security2;

import java.time.Duration;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLException;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.ldap.search.FilterBasedLdapUserSearch;
import org.springframework.security.ldap.userdetails.LdapUserDetailsService;
import org.springframework.web.reactive.function.client.WebClient;

import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtProperties;
import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtRequestFilter;
import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtTokenUtil;

import nl.altindag.ssl.SSLFactory;
import nl.altindag.ssl.util.NettySslUtils;

import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import lombok.RequiredArgsConstructor;
import reactor.netty.http.client.HttpClient;

@Configuration
@AutoConfigureOrder(Ordered.LOWEST_PRECEDENCE)
@RequiredArgsConstructor
public class BdWebdevAutoconfiguration {
	private final BeanFactory beanFactory;

	@Bean
	@ConditionalOnMissingBean
	@ConditionalOnProperty({ "ssl.trust-store", "ssl.password" })
	public WebClient webClient() throws SSLException {
		SslProperties sslProperties = beanFactory.getBean(SslProperties.class);
		SSLFactory sslFactory = SSLFactory.builder()
										  .withTrustMaterial(sslProperties.getTrustStore(), sslProperties.getPassword()
																										 .toCharArray())
										  .build();

		SslContext sslContext = NettySslUtils.forClient(sslFactory)
											 .build();
		HttpClient httpClient = HttpClient.create()
										  .secure(sslSpec -> sslSpec.sslContext(sslContext))
										  .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
										  .responseTimeout(Duration.ofMillis(5000))
										  .doOnConnected(
												  conn -> conn.addHandlerLast(new ReadTimeoutHandler(5000, TimeUnit.MILLISECONDS))
															  .addHandlerLast(
																	  new WriteTimeoutHandler(5000, TimeUnit.MILLISECONDS)));
		return WebClient.builder()
						.clientConnector(new ReactorClientHttpConnector(httpClient))
						.build();
	}

	@Bean
	@ConditionalOnMissingBean
	@ConditionalOnProperty({ "jwt.max-days", "jwt.secret" })
	public JwtTokenUtil jwtTokenUtil() {
		JwtProperties jwtProperties = beanFactory.getBean(JwtProperties.class);
		return new JwtTokenUtil(jwtProperties);
	}

	@Bean
	@ConditionalOnMissingBean
	@ConditionalOnProperty({ "auth.ldap.search-base", "auth.ldap.search-filter" })
	public BdGroup2RoleMapper bdGroup2RoleMapper() {
		AuthProperties authProperties = beanFactory.getBean(AuthProperties.class);
		return new BdGroup2RoleMapper(authProperties);
	}

	@Bean
	@ConditionalOnMissingBean
	public BdGroupPopulator bdGroupPopulator() {
		return new BdGroupPopulator();
	}

	@Bean
	@ConditionalOnMissingBean
	public LocalTimeZone localTimeZone() {
		return new LocalTimeZone();
	}

	/**
	 * In deze UserdetailsService wordt geconfigureerd hoe een gebruiker gevonden kan worden in de ldap, en hoe de aug groepen
	 * gevuld moeten worden. Wordt gebruikt in het {@link JwtRequestFilter}
	 */
	@Bean
	@ConditionalOnMissingBean
	@ConditionalOnProperty({ "spring.ldap.urls", "spring.ldap.username", "spring.ldap.password", "auth.ldap.search-base",
			"auth.ldap.search-filter" })
	public LdapUserDetailsService ldapUserDetailsService() {
		AuthProperties authProperties = beanFactory.getBean(AuthProperties.class);
		LdapContextSource ldapContextSource = beanFactory.getBean(LdapContextSource.class);
		FilterBasedLdapUserSearch userSearch = new FilterBasedLdapUserSearch(authProperties.getLdap()
																						   .getSearchBase(),
				authProperties.getLdap()
							  .getSearchFilter(), ldapContextSource);
		return new LdapUserDetailsService(userSearch, bdGroupPopulator());
	}
}
