package nl.belastingdienst.iva.common.springboot.exceptions;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidationResult {
    boolean validationOk;
    String message;

    public ValidationResult() {
        this.validationOk = true;
    }

    public ValidationResult(String message, boolean result) {
        this.validationOk = result;
        this.message = message;
    }
}