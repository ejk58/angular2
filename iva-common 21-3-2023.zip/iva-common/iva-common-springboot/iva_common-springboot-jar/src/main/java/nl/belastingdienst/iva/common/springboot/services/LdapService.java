package nl.belastingdienst.iva.common.springboot.services;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

import java.util.*;

import javax.naming.directory.SearchControls;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.ldap.control.PagedResultsDirContextProcessor;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapOperationsCallback;
import org.springframework.ldap.core.support.SingleContextSource;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.security.LdapGroup;
import nl.belastingdienst.iva.common.springboot.security.LdapGroupAttributesMapper;
import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.security.LdapPersonAttributesMapper;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class LdapService {
	private static final int BLOCK_SIZE = 1450; //Intentionally 50 less than current max
	private static final String CACHE_NAME = "ldap";
	private static final String CONTROLEURS = "controleurs";

	private final Environment environment;
	private final LdapTemplate ldapTemplate;
	private final CacheManager cacheManager;

	@Scheduled(cron = "0 0 0 * * *") // Clear at midnight
	public void killLdapCache() {
		log.info("Ldap cache clear");
		cacheManager.getCache(CACHE_NAME).clear();
		cacheManager.getCache(CONTROLEURS).clear();
	}

	public List<LdapPerson> getPersons(String userid) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
				.like(userid.trim() + "*");
		return ldapTemplate.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));
	}

	public List<LdapPerson> getPersonByLastNameOrUserId(String searchString) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and(
						LdapQueryBuilder.query().where("sn").like("*" + searchString + "*").or("cn").like( searchString + "*"));
		return ldapTemplate.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));
	}

	@Cacheable(value = CACHE_NAME)
	public List<LdapPerson> getPersonsInBothGroups(String smallGroup, List<String> largeGroup) {
		final Set<LdapPerson> personsInSmallgroup = getUnionOfPersonsThatAreMemberOfAllGroups(Arrays.asList(smallGroup));
		final Set<LdapPerson> personsInlargeGroup = getUnionOfPersonsThatAreMemberOfAllGroups(largeGroup);
		return personsInSmallgroup.stream().parallel()
				.filter(ldapPersonInSmall -> personsInlargeGroup.stream()
						.anyMatch(ldapPersonInLarge -> ldapPersonInLarge.getUserId().equals(ldapPersonInSmall.getUserId())))
				.collect(toList());
	}

	private List<LdapPerson> getPersonList(LdapGroup smallLdapGroup, LdapGroup largeLdapGroup) {
		return largeLdapGroup.getMembers().stream().filter(m -> smallLdapGroup.getMembers().contains(m)).map(this::getPerson)
				.filter(Objects::nonNull).sorted(Comparator.comparing(LdapPerson::getUserId)).collect(toList());
	}

	private LdapGroup getGroups(List<String> augGroepen) {
		LdapGroup result = new LdapGroup();
		result.setMembers(new ArrayList<>());
		augGroepen.forEach(groep -> {
			LdapGroup ldapGroup = this.getGroup(groep);
			if (ldapGroup != null) {
				ldapGroup.getMembers().stream().forEach(member -> {
					if (!result.getMembers().contains(member)) {
						result.getMembers().add(member);
					}
				});
			}
		});
		return result;
	}

	public LdapGroup getGroup(String augGroup) {
		final SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		searchControls.setCountLimit(BLOCK_SIZE);
		final PagedResultsDirContextProcessor processor =
				new PagedResultsDirContextProcessor(BLOCK_SIZE);
		LdapOperationsCallback<List<LdapGroup>> ldapOperationsCallback = operations -> {
			List<LdapGroup> operationsResult = new LinkedList<>();
			do {
				List<LdapGroup> oneResult = operations.search(
						environment.getProperty("ldap.partitionSuffix"),
						"(&(objectclass=group)&(cn=" + augGroup + "))",
						searchControls,
						new LdapGroupAttributesMapper(),
						processor);
				operationsResult.addAll(oneResult);
			} while (processor.hasMore());
			return operationsResult;
		};
		List<LdapGroup> result = SingleContextSource.doWithSingleContext(ldapTemplate.getContextSource(), ldapOperationsCallback);
		if(result.size() == 1) {
			return result.get(0);
		}
		return null;
	}

	/**
	 * @param userid
	 * 		A partial userid (A * will be added)
	 * @return A list of persons matching this string
	 */
	public List<LdapPerson> findPersons(String userid) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
				.like(userid.trim() + "*");
		return ldapTemplate.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));

	}

	public LdapPerson getPerson(String userid) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
				.is(userid.trim());
		List<LdapPerson> ldapPersonList = ldapTemplate
				.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));
		return ldapPersonList == null || ldapPersonList.isEmpty() ? null : ldapPersonList.get(0);
	}

	public boolean isAdGroep(String werkgroep) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("group").and("cn").is(werkgroep);
		List<LdapGroup> adGroepen = ldapTemplate.search(query, new LdapGroupAttributesMapper());
		return adGroepen.size() == 1;
	}

	public List<LdapPerson> getPersonsFromAugGroup(String augGroup) {
		List<LdapPerson> result = new ArrayList<>();
		getGroup(augGroup).getMembers().forEach(userId -> result.add(getPerson(userId)));
		return result;
	}

	private Set<LdapPerson> getUnionOfPersonsThatAreMemberOfAllGroups(List<String> workGroups) {
		return workGroups.stream()
				.map(this::getDistinguishedNameOfGroup)
				.filter(Optional::isPresent)
				.map(Optional::get)
				.map(this::getDistinctPersonsThatAreMemberOfGroup)
				.flatMap(Set::stream)
				.collect(toSet());
	}


	private Set<LdapPerson> getDistinctPersonsThatAreMemberOfGroup(String distinguisedGroupName) {
		final SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		searchControls.setCountLimit(0);
		final PagedResultsDirContextProcessor processor =
				new PagedResultsDirContextProcessor(BLOCK_SIZE);
		LdapOperationsCallback<Set<LdapPerson>> ldapOperationsCallback = operations -> {
			Set<LdapPerson> operationsResult = new HashSet<>();
			do {
				List<LdapPerson> oneResult = operations.search(
						environment.getProperty("ldap.partitionSuffix"),
						"(&(objectclass=person)&(memberOf=" + distinguisedGroupName + "))",
						searchControls,
						new LdapPersonAttributesMapper(),
						processor);
				operationsResult.addAll(oneResult);
			} while (processor.hasMore());
			return operationsResult;
		};
		return SingleContextSource.doWithSingleContext(ldapTemplate.getContextSource(), ldapOperationsCallback);
	}

	public Optional<String> getDistinguishedNameOfGroup(String werkgroep) {
		try {
			LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE)
					.base(Objects.requireNonNull(environment.getProperty("ldap.partitionSuffix"))).where("objectclass").is("group").and("cn").is(werkgroep);
			List<String> search = ldapTemplate.search(query, (AttributesMapper<String>) attributes -> (String) attributes.get("distinguishedname").get());
			if (search.size() != 1) {
				return Optional.empty();
			}
			return Optional.of(search.get(0));
		} catch (RuntimeException e) {
			log.error("Exception when getting distinguished name for workgroup: {}. Exception message: {}", werkgroep, e.getMessage());
			return Optional.empty();
		}
	}
}
