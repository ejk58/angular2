package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

import java.time.LocalDate;

@Data
public class Aangifte {
    private Long bsn;
    private Integer belastingjaar;
    private String belastingmiddel;
    private LocalDate klantreactieDt;
    private Boolean aangifteOntvangen;
}
