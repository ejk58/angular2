package nl.belastingdienst.iva.common.springboot.security2;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.common.springboot.exceptions.NotAllowedException;
import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtRequest;
import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtResponse;
import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtTokenUtil;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/authenticate")
@RequiredArgsConstructor
public class AuthenticationRestController {
	private final AuthenticationManager authenticationManager;
	private final JwtTokenUtil jwtTokenUtil;

	@PostMapping()
	public JwtResponse createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {
		UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword()));
		if (auth.getAuthorities()
				.stream()
				.noneMatch(r -> r.getAuthority()
								 .equalsIgnoreCase("ROLE_USER")))
			throw new NotAllowedException("U heeft geen toegang tot deze applicatie");

		final String token = jwtTokenUtil.generateToken(auth);
		return (new JwtResponse(token));
	}
}
