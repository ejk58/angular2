/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: SplunkData.java
 *             Auteur: denee00
 *    Creatietijdstip: 23-4-2020 08:45
 *          Copyright: (c) 2020 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.common.springboot.logging;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import nl.belastingdienst.iva.common.springboot.exceptions.ApiError;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SplunkEvent {

	private long time = System.currentTimeMillis();

	private String source;

	private String host;

	private String sourcetype;

	private String index;

	private Event event;

	private Map<String, String> fields = new HashMap<>();

}

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
class Event {

	private String message;
	private String logLevel;
	private String stackTrace;
	private ApiError apiError;

	public Event(String message, String logLevel) {
		this.message = message;
		this.logLevel = logLevel;
	}
}
