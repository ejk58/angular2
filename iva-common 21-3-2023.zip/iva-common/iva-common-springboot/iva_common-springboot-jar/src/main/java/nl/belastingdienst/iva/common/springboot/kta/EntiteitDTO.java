package nl.belastingdienst.iva.common.springboot.kta;

import lombok.Data;

@Data
public class EntiteitDTO {
	private String naam;
	private Integer dosNr;
	private Integer kantoorId;
	private String kantoorNaam;
	private String teamCode;
	private String teamOmschrijving;
}
