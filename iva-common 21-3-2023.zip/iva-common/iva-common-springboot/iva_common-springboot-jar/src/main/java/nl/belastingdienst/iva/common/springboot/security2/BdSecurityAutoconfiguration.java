package nl.belastingdienst.iva.common.springboot.security2;

import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.ldap.search.FilterBasedLdapUserSearch;
import org.springframework.security.ldap.userdetails.LdapUserDetailsService;

import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtProperties;
import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtRequestFilter;
import nl.belastingdienst.iva.common.springboot.security2.jwt.JwtTokenUtil;

import lombok.RequiredArgsConstructor;

@Configuration
@AutoConfigureOrder(Ordered.LOWEST_PRECEDENCE)
@RequiredArgsConstructor
@ConditionalOnBean({ AuthProperties.class, JwtProperties.class, LdapContextSource.class })
public class BdSecurityAutoconfiguration {
    private final AuthProperties authProperties;
    private final JwtProperties jwtProperties;
    private final LdapContextSource ldapContextSource;

    @Bean
    @ConditionalOnMissingBean
    public JwtTokenUtil jwtTokenUtil() {
        return new JwtTokenUtil(jwtProperties);
    }

    @Bean
    @ConditionalOnMissingBean
    public BdGroup2RoleMapper bdGroup2RoleMapper() {
        return new BdGroup2RoleMapper(authProperties);
    }

    @Bean
    @ConditionalOnMissingBean
    public BdGroupPopulator bdGroupPopulator() {
        return new BdGroupPopulator();
    }

    @Bean
    @ConditionalOnMissingBean
    public LocalTimeZone localTimeZone() {
        return new LocalTimeZone();
    }
    /**
     * In deze UserdetailsService wordt geconfigureerd hoe een gebruiker gevonden kan worden in de ldap, en hoe de aug groepen
     * gevuld moeten worden.
     * Wordt gebruikt in het {@link JwtRequestFilter}
     *
     */
    @Bean
    @ConditionalOnMissingBean
    public LdapUserDetailsService ldapUserDetailsService() {
        FilterBasedLdapUserSearch userSearch = new FilterBasedLdapUserSearch(authProperties.getLdap()
                .getSearchBase(),
                authProperties.getLdap()
                        .getSearchFilter(), ldapContextSource);
        return new LdapUserDetailsService(userSearch, bdGroupPopulator());
    }
}