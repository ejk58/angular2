package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

@Data
public class FiscaleActiviteit {
    private String type;
    private String volgNummer;
    private String actueleOndernemerscode;
    private String doelGroep;
    private String teNaamStelling;
}
