package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

@Data
public class CompetentKantoor {
    private Integer kantoorId;
    private String dosteam;
}
