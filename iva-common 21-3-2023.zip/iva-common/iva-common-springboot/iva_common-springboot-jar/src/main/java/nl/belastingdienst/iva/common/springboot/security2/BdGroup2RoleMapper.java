package nl.belastingdienst.iva.common.springboot.security2;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Component
public class BdGroup2RoleMapper implements GrantedAuthoritiesMapper {

	private final AuthProperties authProperties;

	@Override
	public Collection<? extends GrantedAuthority> mapAuthorities(Collection<? extends GrantedAuthority> collection) {
		return authProperties.getRoles()
																   .getMapping()
																   .entrySet()
																   .stream()
																   .map((Map.Entry<String, String> entry) -> {
																	   String[] adgroepen = entry.getValue()
																								 .split(",");
																	   for (String adgroep : adgroepen) {
																		   if (collection.stream()
																						 .anyMatch(ga -> ga.getAuthority()
																										   .equalsIgnoreCase(
																												   adgroep.trim()))) {
																			   return new SimpleGrantedAuthority(entry.getKey());
																		   }
																	   }
																	   return null;
																   })
																   .filter(Objects::nonNull)
																   .collect(Collectors.toList());
	}
}
