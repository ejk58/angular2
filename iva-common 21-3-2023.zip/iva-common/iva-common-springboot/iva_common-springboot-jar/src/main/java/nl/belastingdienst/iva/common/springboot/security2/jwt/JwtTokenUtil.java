package nl.belastingdienst.iva.common.springboot.security2.jwt;

import static com.auth0.jwt.algorithms.Algorithm.HMAC512;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;

import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class JwtTokenUtil implements Serializable {
	private final JwtProperties jwtProperties;

	public String getUsernameFromToken(String token) {
		return getClaimFromToken(token, "sub").asString();
	}

	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, "exp").asDate();
	}

	public Claim getClaimFromToken(String token, String claim) {
		return getAllClaimsFromToken(token).entrySet()
										   .stream()
										   .filter(entry -> entry.getKey()
																 .equalsIgnoreCase(claim))
										   .findAny()
										   .orElseThrow(() -> new NotFoundException("", "Claim", claim, "Niet aanwezig in token"))
										   .getValue();
	}

	private Map<String, Claim> getAllClaimsFromToken(String token) {
		return JWT.require(Algorithm.HMAC512(jwtProperties.getSecret()
														  .getBytes()))
				  .build()
				  .verify(token)
				  .getClaims();
	}

	public Boolean isTokenExpired(String token) {
		final Date expiration = getExpirationDateFromToken(token);
		return expiration.before(new Date());
	}

	public String generateToken(UsernamePasswordAuthenticationToken authentication) {
		//TODO: Een mogelijkheid inbouwen om extra claims in het token te zetten
		Map<String, Object> claims = new HashMap<>();
		claims.put("ROLES", authentication.getAuthorities()
										  .stream()
										  .map(GrantedAuthority::getAuthority)
										  .collect(Collectors.joining(",")));
		return generateToken(claims, authentication.getName());
	}

	private String generateToken(Map<String, Object> claims, String subject) {
		long curMillis = System.currentTimeMillis();
		long expMillis = curMillis + jwtProperties.getMaxDays() * 1000 * 60 * 60 * 24;
		return JWT.create()
				  .withSubject(subject)
				  .withIssuedAt(new Date(curMillis))
				  .withPayload(claims)
				  .withExpiresAt(new Date(expMillis))
				  .sign(HMAC512(jwtProperties.getSecret()
											 .getBytes()));
	}
}
