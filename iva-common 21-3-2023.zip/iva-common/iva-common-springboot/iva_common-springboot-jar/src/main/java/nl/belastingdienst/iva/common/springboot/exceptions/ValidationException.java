package nl.belastingdienst.iva.common.springboot.exceptions;

import java.util.List;

import lombok.Getter;

@Getter
public class ValidationException extends RuntimeException {
    private ValidationResult result;
    private List<ValidationResult> validationResultList;

    public ValidationException(ValidationResult result) {
        super(result.message);
        this.result = result;
    }

    public ValidationException(List<ValidationResult> validationResultList) {
        super("multiple validations");
        this.validationResultList = validationResultList;
    }
}