package nl.belastingdienst.iva.common.springboot.domain;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.Type;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;

import lombok.Data;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Data
@Entity
public class RetryAction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Enumerated(EnumType.STRING)
	private HttpMethod method;
	@Column(length = 4096)
	private String url;
	private Integer numberOfRetries = Integer.valueOf(0);
	private Integer maxRetries;
	private Long timeToSendMessage;
	@Type(type = "yes_no")
	private Boolean inError = Boolean.FALSE;

	@Lob
	@Column(columnDefinition = "BLOB")
	private byte[] body;

	@Lob
	@Column(columnDefinition = "BLOB")
	private byte[] httpHeaders;

	private LocalDateTime entryTime = LocalDateTime.now();

	public static enum Action {
		RETRY, NO_RETRY_MAX_RETRIES_REACHED, NO_RETRY_MAX_TIME_EXCEEDED;
	}

	public RetryAction() {
		// EMPTY
	}

	public Action getAction() {
		if (numberOfRetries != null && maxRetries != null) {
			if (numberOfRetries >= maxRetries) {
				return Action.NO_RETRY_MAX_RETRIES_REACHED;
			}
		}
		if (this.timeToSendMessage != null) {
			if (ChronoUnit.MILLIS.between(this.entryTime, LocalDateTime.now()) >= this.timeToSendMessage.longValue()) {
				return Action.NO_RETRY_MAX_TIME_EXCEEDED;
			}
		}
		return Action.RETRY;
	}

	public void setMinutesToSend(int minutes) {
		this.setTimeToSendMessage(Long.valueOf(minutes * 60 * 1000));
	}

	public <T> RetryAction(HttpMethod method, HttpHeaders headers, String url, T body) {
		this.method = method;
		this.url = url;

		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeObject(headers);
			oos.flush();
			oos.close();
			baos.close();
			this.setHttpHeaders(baos.toByteArray());
		} catch (IOException e) {
			throw new CommonException("Error serializing", e); //
		}

		ObjectMapper mapper = new ObjectMapper();
		try {
			this.body = mapper.writeValueAsString(body).getBytes();
		} catch (JsonProcessingException e) {
			log.error("body retry not serialized", e);
		}
	}

	public HttpHeaders getHttpHeaders() {
		HttpHeaders httpHeaders = null;
		ByteArrayInputStream bais;
		ObjectInputStream ins;
		try {
			bais = new ByteArrayInputStream(this.httpHeaders);
			ins = new ObjectInputStream(bais);
			httpHeaders = (HttpHeaders) ins.readObject();
			ins.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return httpHeaders;
	}

	public <T> T getBody() {
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<T> typeRef = new TypeReference<T>() {
		};
		try {
			return mapper.readValue(this.body, typeRef);
		} catch (IOException e) {
			log.error("retry not deserialized", e);
		}
		return null;
	}
}
