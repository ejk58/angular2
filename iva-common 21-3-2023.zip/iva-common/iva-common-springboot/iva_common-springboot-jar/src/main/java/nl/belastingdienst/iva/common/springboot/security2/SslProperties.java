package nl.belastingdienst.iva.common.springboot.security2;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
@ConfigurationProperties(prefix = "ssl")
public class SslProperties {
	private String trustStore;
	private String password;
}
