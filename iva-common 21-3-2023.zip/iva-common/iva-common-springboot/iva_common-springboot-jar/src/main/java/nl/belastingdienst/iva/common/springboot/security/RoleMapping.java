package nl.belastingdienst.iva.common.springboot.security;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class RoleMapping {
    String ldapGroup;
    String role;

    public RoleMapping(String ldapGroup, String role) {
        this.ldapGroup = ldapGroup.toUpperCase();
        this.role = role.toUpperCase();
    }
}
