package nl.belastingdienst.iva.common.springboot.security;

import java.util.List;

import lombok.Data;

@Data
public class LdapGroup {
    private String name;
    private List<String> members;
}
