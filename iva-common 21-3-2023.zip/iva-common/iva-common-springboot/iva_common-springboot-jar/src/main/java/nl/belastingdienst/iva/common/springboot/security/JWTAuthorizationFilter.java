package nl.belastingdienst.iva.common.springboot.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.*;

public class JWTAuthorizationFilter extends OncePerRequestFilter {
    private final Environment env;

    public JWTAuthorizationFilter(Environment env) {
        this.env = env;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain) throws IOException, ServletException {
        String header = req.getHeader(HEADER_STRING);

        if (header == null || !header.startsWith(TOKEN_PREFIX)) {
            chain.doFilter(req, res);
            return;
        }
        String token = req.getHeader(HEADER_STRING).replace(TOKEN_PREFIX, "");
        UsernamePasswordAuthenticationToken authentication = getAuthentication(token);

        SecurityContextHolder.getContext().setAuthentication(authentication);
        chain.doFilter(req, res);
    }

    private UsernamePasswordAuthenticationToken getAuthentication(String token) {
        UsernamePasswordAuthenticationToken ret = null;
        DecodedJWT decodedJWT = null;
        try {
            decodedJWT = JWT.require(Algorithm.HMAC512(env.getRequiredProperty("jwt.secret").getBytes()))
                    .build()
                    .verify(token);
            String user = decodedJWT.getSubject();
            List<GrantedAuthority> authorities = null;
            Claim authoritiesClaim = decodedJWT.getClaim(AUTHORITIES_STRING);
            if (!authoritiesClaim.isNull()) {
                authorities = authoritiesClaim.asList(String.class).stream()
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());
            }
            if (user != null) {
                ret = new UsernamePasswordAuthenticationToken(user, null, authorities);
            }
        } catch (Exception e) {
            logger.error("Invalid Token");
        }
        return ret;
    }
}
