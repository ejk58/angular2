package nl.belastingdienst.iva.common.springboot.security;

import java.util.ArrayList;
import java.util.Arrays;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import org.springframework.ldap.core.AttributesMapper;

public class LdapGroupAttributesMapper implements AttributesMapper<LdapGroup> {

	public LdapGroup mapFromAttributes(Attributes attributes) throws NamingException {
		LdapGroup group = new LdapGroup();
		group.setMembers(new ArrayList<>());
		for (NamingEnumeration<?> ae = attributes.getAll(); ae.hasMore(); ) {
			Attribute attr = (Attribute) ae.next();
			if (attr.getID().equalsIgnoreCase("cn")) {
				group.setName(attr.getID());
			}
			if (attr.getID().toLowerCase().startsWith("member")) {
				for (int i = 0; i < attr.size(); i++) {
					group.getMembers()
							.add(Arrays.asList(Arrays.asList(((String) attr.get(i)).split(",")).get(0).split("=")).get(1));
				}
			}
		}
		return group;
	}
}
