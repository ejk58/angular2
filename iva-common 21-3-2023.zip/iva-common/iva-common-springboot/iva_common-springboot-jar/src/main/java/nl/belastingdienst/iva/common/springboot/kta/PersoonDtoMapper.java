package nl.belastingdienst.iva.common.springboot.kta;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import nl.belastingdienst.iva.common.springboot.domain.FiscaleActiviteitDTO;
import nl.belastingdienst.iva.common.springboot.domain.Persoon;
import nl.belastingdienst.iva.common.springboot.domain.PersoonDTO;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class PersoonDtoMapper {

	private PersoonDtoMapper() {
		// empty
	}

	public static List<PersoonDTO> mapEntiteit(List<ViewRecord> records) {
		if (records == null || records.isEmpty()) {
			return new ArrayList<>();
		}
		List<PersoonDTO> result = new LinkedList<>();
		Long bsn = null;
		PersoonDTO p = null;
		for (ViewRecord vr : records) {
			if (bsn == null || !vr.getBsn().equals(bsn)) {
				bsn = vr.getBsn();
				p = mapPersoon(vr);
				result.add(p);
			}
			p.getActiviteiten().add(mapActiviteit(vr));
		}
		return result;
	}

	private static FiscaleActiviteitDTO mapActiviteit(ViewRecord vr) {
		FiscaleActiviteitDTO fa = new FiscaleActiviteitDTO();
		fa.setActiviteit(vr.getActiviteitMiddel());
		fa.setNaam(vr.getActiviteitTeNmStel());
		fa.setSubnummer(vr.getActiviteitVolgnr());
		fa.setOndernemerscode(vr.getActivieitOndernCd());
		fa.setIngangsdatum(toLocalDate(vr.getActiviteitIngDat()));
		fa.setEinddatum(toLocalDate(vr.getActiviteitEindDat()));
		fa.setAangifteplicht(null);
		fa.setDoelgroepcode(String.valueOf(vr.getActiviteitDoelgroep()));
		// Unavailable in vr: fa.setAangifteplicht(null)
		return fa;
	}

	private static PersoonDTO mapPersoon(ViewRecord vr) {
		PersoonDTO p = new PersoonDTO();
		p.setNaam(getRightName(vr));
		p.setSoort(vr.getNpInd());
		p.setSubject(vr.getBsn());
		p.setStart(toLocalDate(vr.getBegindatum()));
		p.setEinde(toLocalDate(vr.getEinddatum()));
		p.setActiviteiten(new ArrayList<>());
		p.setVervalDatumRelatie(toLocalDate(vr.getVervDatRel()));
		// Unused from vr: vr.getVoorletters() and vr.getVoorvoegsel()
		return p;
	}

	private static LocalDate toLocalDate(Date datum) {
		if (datum == null)
			return null;
		if (datum instanceof java.sql.Date)
			return ((java.sql.Date) datum).toLocalDate();
		return datum.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

	private static String getRightName(ViewRecord viewRecord) {
		StringBuilder ret = new StringBuilder();
		if (viewRecord.getVoorletters() != null) ret.append(viewRecord.getVoorletters().trim()).append(" ");
		ret.append(viewRecord.getNaam());
		return ret.toString();
	}
}
