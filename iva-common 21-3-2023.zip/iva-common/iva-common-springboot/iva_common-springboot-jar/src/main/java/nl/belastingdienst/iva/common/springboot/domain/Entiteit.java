package nl.belastingdienst.iva.common.springboot.domain;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Entiteit {
    private String dossierNummer;
    private String dossierBeschrijving;
    private String beginDatum;
    private String id;

    public void setId(String id) {
        this.id = id;
    }

    @Id
    public String getId() {
        return id;
    }
}
