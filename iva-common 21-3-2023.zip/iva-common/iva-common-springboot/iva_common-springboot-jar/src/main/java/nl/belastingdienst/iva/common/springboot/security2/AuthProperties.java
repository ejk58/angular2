package nl.belastingdienst.iva.common.springboot.security2;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
@ConfigurationProperties(prefix = "auth")
public class AuthProperties {
	private Ldap ldap;
	private Roles roles;

	@Getter
	@Setter
	public static class Ldap {
		private String searchBase;
		private String searchFilter;
	}

	@Getter
	@Setter
	public static class Roles {
		private Map<String, String> mapping = new HashMap<>();
	}
}
