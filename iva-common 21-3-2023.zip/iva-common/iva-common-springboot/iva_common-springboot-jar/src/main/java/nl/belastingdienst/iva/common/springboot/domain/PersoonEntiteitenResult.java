package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

import java.util.List;

@Data
public class PersoonEntiteitenResult {
    private Persoon persoon;
    private List<String> dossierNummers;
}
