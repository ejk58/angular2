package nl.belastingdienst.iva.common.springboot.security2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;

import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BdGroupPopulator implements LdapAuthoritiesPopulator {

	@Override
	public List<SimpleGrantedAuthority> getGrantedAuthorities(DirContextOperations userData, String username) {
		List<SimpleGrantedAuthority> authorities = new ArrayList<>();
		Attribute memberAttribute = userData.getAttributes()
											.get("memberof");
		try {
			NamingEnumeration<?> groups = memberAttribute.getAll();

			while (groups.hasMore()) {
				String cn = (String) groups.next();
				Arrays.stream(cn.split(","))
					  .filter(e -> e.startsWith("CN="))
					  .forEach(e -> authorities.add(new SimpleGrantedAuthority(e.substring(3)
																				.toUpperCase())));
			}
		} catch (NamingException ne) {
			log.error("NamingException bij het vullen van groepen van een user. Uitleg is {}", ne.getExplanation());
		}
		return authorities;
	}
}
