@Library("GENERIC") _
    pipelineDeployArtifactFromNexus_v1 {
	baseDirectory = "iva_common-springboot-jar"
	deploymentId = "iva_common-springboot"
	integrationPipeline = ""
	packageChoices = "iva_common-springboot\n"
	applicationVersionChoices = "3.1.0\n3.0.0\n2.69.0\n2.68.0\n2.67.0"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
}
