pipelineRelease_common_openshift {
    baseDirectory = "iva_common-microprofile-jar"
	deploymentId = "iva_common-microprofile-jar"
	deployPipeline = ""
	integrationPipeline = ""
	environmentChoices = "tst\nacc"
	streetChoices = "str11"
	mvnVersion = "maven36-openjdk11"
}