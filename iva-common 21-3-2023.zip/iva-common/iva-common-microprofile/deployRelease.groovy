pipelineDeployArtifactFromHarbor {
	baseDirectory = "iva_common-microprofile-jar"
	deploymentId = "iva_common-microprofile-jar"
	packageChoices = "iva_common-microprofile-jar"
                applicationVersionChoices = "0.5.0\n0.4.0\n0.3.0\n0.2.0\n0.1.1"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "1\n2\n3\n4\n5\n6"
}
