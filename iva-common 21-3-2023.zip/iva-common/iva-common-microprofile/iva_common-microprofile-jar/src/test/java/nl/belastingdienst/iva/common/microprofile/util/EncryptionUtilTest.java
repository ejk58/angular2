package nl.belastingdienst.iva.common.microprofile.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class EncryptionUtilTest {

	@Test
	void testGenerateEncryptedPassword() {
		String pass = "i-V-a-Werkgroep";
		String encryptedPassword = EncryptionUtil.getInstance().encrypt(pass);
		System.out.println(encryptedPassword);
		String decryptedPassword = EncryptionUtil.getInstance().decrypt(encryptedPassword);
		assertEquals(pass, decryptedPassword);

	}
}
