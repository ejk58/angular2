package nl.belastingdienst.iva.common.microprofile.validator;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class DateTimeValidatorIsoOffsetDateTimeTest {

	@Test
	void testDate() {
		DateTimeValidator validator = new DateTimeValidatorIsoOffsetDateTime();
		assertFalse(validator.isValid("01-01-2020T10:00:00"));
		assertFalse(validator.isValid("2020-01-01T00:00:00"));
		assertFalse(validator.isValid("2020-01-01T00:00:00+01"));
		assertFalse(validator.isValid("2020-01-01T00:00:00+01:0"));
		assertTrue(validator.isValid("2020-01-01T10:00:00+01:00"));
		assertTrue(validator.isValid("2020-07-01T10:00:00+02:00"));
		assertTrue(validator.isValid("2020-07-01T10:00:00+05:00"));
		assertTrue(validator.isValid("2020-07-01T10:00:00-05:00"));
		assertFalse(validator.isValid("2020-07-01T10:00:00+02:000"));
		assertFalse(validator.isValid("2020-01-01T10:00:00.0"));
		assertFalse(validator.isValid("2020-01-32T10:00:00"));
		assertFalse(validator.isValid("2020-01-01"));
		assertFalse(validator.isValid("A"));
		assertFalse(validator.isValid(null));
	}

}
