package nl.belastingdienst.iva.common.microprofile.splunk;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class ApiValidationError {
    private String field;
    private String rejectedValue;
    private String message;
}
