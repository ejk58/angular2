package nl.belastingdienst.iva.common.microprofile.validator;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

public class DateTimeValidatorIsoLocalDateTime implements DateTimeValidator {

	@Override
	public boolean isValid(String dateTimeStr) {
		try {
			// Geen ISO_LOCAL_DATE_TIME als formatter omdat milliseconden n.v.t zijn
			LocalDateTime.parse(dateTimeStr, FormatterConstants.FORMATTER_DATETIME_WITHOUT_OFFSET);
		} catch (DateTimeParseException e) {
			return false;
		}
		return true;
	}
}