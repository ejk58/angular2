package nl.belastingdienst.iva.common.microprofile.splunk;

public interface ErrorTypeInterface {
    String getType();
    String getTitle();
}
