package nl.belastingdienst.iva.common.microprofile.exception;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserError implements Serializable {
	private static final long serialVersionUID = -2306305628151664929L;
	static Map<Integer, String> allErrors = new HashMap<>();

	static {
		allErrors.put(400, "Call to remote resource resulted in error");
		allErrors.put(401, "Not authorized");
		allErrors.put(403, "Not authenticated");
		allErrors.put(404, "Item not found");
		allErrors.put(1000, "MediaType not supported");
		allErrors.put(2000, "Message structure violations found");
		allErrors.put(3000, "Configuration is not valid");
		allErrors.put(4000, "Status is not valid");
		allErrors.put(5000, "Dataprovider problem found");
	}

	@Schema(description = "Error code")
	private Integer code;

	@Schema(description = "The message for the user")
	private String userMessage;

	@Schema(description = "Dev oriented message")
	private String internalMessage;

	@Schema(description = "Parameters for the error")
	private Map<String, String> parameters = new HashMap<>();

	public UserError(Integer code) {
		super();
		this.code = code;
		this.userMessage = "";
		this.internalMessage = allErrors.get(code);
	}

	public void addParameter(String key, String value) {
		this.parameters.put(key, value);
	}

	public void addViolations(List<MyConstraintViolation> violations) {
		Integer keyNum = 0;
		for (MyConstraintViolation violation : violations) {
			String key = violation.getProperty();
			if (key == null) {
				key = "Key" + keyNum++;
			}
			this.addParameter(key,
					String.format("Problem with value: %s; violation message: %s", violation.getValue(), violation.getMessage()));
		}
	}

	public void addViolations(Map<Integer, List<MyConstraintViolation>> violationsMap) {
		for (Map.Entry<Integer, List<MyConstraintViolation>> entry : violationsMap.entrySet()) {
			String key = "Signaal_" + entry.getKey();
			Integer keyNum = 0;
			for (MyConstraintViolation violation : entry.getValue()) {
				String prop = violation.getProperty();
				if (prop == null) {
					prop = "Prop" + keyNum++;
				}
				this.addParameter(key + "_" + prop,
						String.format("Problem with value: %s; violation message: %s", violation.getValue(),
								violation.getMessage()));
			}
		}
	}

	public void addContext(UserContext ctx) {
		Integer keyNum = 0;
		addParameter("Functie", ctx.getFunction());
		addParameter("Identificatie", ctx.getIdentification());
		for (Map.Entry<String, String> entry : ctx.getParameters().entrySet()) {
			String key = entry.getKey();
			if (key == null) {
				key = "Key" + keyNum;
			}
			Object value = entry.getValue();
			if (value instanceof String || value instanceof Integer) {
				addParameter(key, value.toString());
			}
			keyNum++;
		}
	}
}
