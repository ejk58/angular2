package nl.belastingdienst.iva.common.microprofile.splunk;

import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.json.bind.JsonbConfig;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.Property;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginElement;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.PatternLayout;
import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.config.ConfigProvider;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

@Plugin(name = "Splunk", category = "Core", elementType = "appender", printObject = true)
public class SplunkAppender extends AbstractAppender {

	private String url;
	private String token;
	private String service;
	private String serverName;

	private Jsonb jsonb = JsonbBuilder.create(new JsonbConfig().withNullValues(false));

	public static final Marker marker = MarkerFactory.getMarker("Splunk");

	private SplunkAppender(String name,
			Filter filter,
			Layout<? extends Serializable> layout,
			String url, String token, String service) {
		super(name, filter, layout, true, Property.EMPTY_ARRAY);
		this.url = url;
		this.token = token;
		this.service = service;

		try {
			this.serverName = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			this.serverName = "Onbekend";
		}
	}

	@PluginFactory
	public static SplunkAppender createAppender(
			@PluginAttribute("name") String name,
			@PluginElement("Layout") Layout<? extends Serializable> layout,
			@PluginElement("Filter") final Filter filter,
			@PluginAttribute("url") String url,
			@PluginAttribute("token") String token,
			@PluginAttribute("service") String service) {
		if (name == null) {
			LOGGER.error("No name provided for SplunkAppender");
			return null;
		}

		if (layout == null) {
			layout = PatternLayout.createDefaultLayout();
		}

		Config config = ConfigProvider.getConfig();
		url = config.getValue("splunk.url", String.class);
		token = config.getValue("splunk.token", String.class);
		service = config.getValue("splunk.service", String.class);

		return new SplunkAppender(name, null, layout, url, token, service);
	}

	@Override
	public void append(LogEvent logEvent) {
		SplunkEvent splunkEvent = new SplunkEvent();
		splunkEvent.setEvent(new Event(logEvent.getMessage().getFormattedMessage(), logEvent.getLevel().name()));
		if (logEvent.getThrown() != null) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			logEvent.getThrown().printStackTrace(pw);
			splunkEvent.getEvent().setStackTrace(sw.toString());
		}

		if (logEvent.getMessage().getThrowable() != null) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			logEvent.getMessage().getThrowable().printStackTrace(pw);
			splunkEvent.getEvent().setStackTrace(sw.toString());
		}

		splunkEvent.setHost(this.serverName);
		splunkEvent.setTime(System.currentTimeMillis());
		splunkEvent.getFields().put("service", this.service);
		String json = jsonb.toJson(splunkEvent);
		send(json);
	}

	void send(String json) {
		Client client = null;
		Response response = null;
		try {
			client = createSSLAgnosticClient();
			WebTarget webTarget = client.target(url).path("services").path("collector").path("event");
			MultivaluedMap<String, Object> headers = new MultivaluedHashMap<>();
			headers.add("Authorization", token);
			headers.add("Accept", "application/json");
			headers.add("Content-Type", "application/json");
			response = webTarget.request().headers(headers).post(Entity.entity(json, MediaType.APPLICATION_JSON), Response.class);
			if (response.getStatus() != 200) {
				LOGGER.error(response);
				LOGGER.log(Level.ERROR, "Failed to send a logging to splunk with statuscode {}", response.getStatus());
			}

		} catch (Exception e) {
			handleExeption(e);
		} finally {
			if (response != null) {
				response.close();
			}
			if (client != null) {
				client.close();
			}
		}
	}

	private void handleExeption(Exception e) {
		LOGGER.log(Level.ERROR, "Failed to send a logging to splunk with an Exception (uri: {}, Message {}})", this.url,
				e.getLocalizedMessage());
	}

	private Client createSSLAgnosticClient() throws NoSuchAlgorithmException, KeyManagementException {
		SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
		KeyManager[] keyManagers = null;
		TrustManager[] trustManagers = null;
		SecureRandom secureRandom = new SecureRandom();
		sslContext.init(keyManagers, trustManagers, secureRandom);
		HostnameVerifier allHostsValid = new NoOpHostnameVerifier();
		return ClientBuilder.newBuilder().sslContext(sslContext).hostnameVerifier(allHostsValid).build();
	}
}
