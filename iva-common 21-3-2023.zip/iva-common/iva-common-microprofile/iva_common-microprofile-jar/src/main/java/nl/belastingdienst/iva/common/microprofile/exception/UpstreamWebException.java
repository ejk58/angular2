package nl.belastingdienst.iva.common.microprofile.exception;

import javax.ejb.ApplicationException;
import javax.xml.ws.WebServiceException;

import lombok.Getter;

@Getter
@ApplicationException
public class UpstreamWebException extends WebServiceException {

	private static final long serialVersionUID = 140279259840901665L;

	private final UserContext context;

	public UpstreamWebException(UserContext context) {
		super();
		this.context = context;
	}
}
