package nl.belastingdienst.iva.common.microprofile.exception;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.ApplicationException;

@ApplicationException
public class ValidationException extends CommonException {
	private static final long serialVersionUID = -9184411547039297608L;
	private final List<MyConstraintViolation> violations = new ArrayList<>();
	private final transient Map<Integer, List<MyConstraintViolation>> violationPerSignal = new HashMap<>();

	public enum Type {
		MESSAGE, VIOLATIONS, PERTYPE
	}

	private final Type type;

	public ValidationException(String property, String value, String message) {
		super(message);
		type = Type.MESSAGE;
		this.violations.add(new MyConstraintViolation(property, value, message));
	}

	public ValidationException(List<MyConstraintViolation> violations) {
		super("request contains violations (" + violations.size() + ")");
		type = Type.VIOLATIONS;
		this.violations.addAll(violations);
	}

	public ValidationException(Map<Integer, List<MyConstraintViolation>> violationPerSignal) {
		super("Multiple violations found.");
		type = Type.PERTYPE;
		this.violationPerSignal.putAll(violationPerSignal);
	}

	public List<MyConstraintViolation> getViolations() {
		return Collections.unmodifiableList(violations);
	}

	public Map<Integer, List<MyConstraintViolation>> getViolationMap() {
		return Collections.unmodifiableMap(violationPerSignal);
	}

	public Type getType() {
		return type;
	}
}
