package nl.belastingdienst.iva.common.microprofile.validator;

import java.time.chrono.IsoChronology;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.ResolverStyle;

public abstract class FormatterConstants {

	private FormatterConstants() {
		// private constructor
	}

	public static final DateTimeFormatter FORMATTER_DATE = DateTimeFormatter.ISO_LOCAL_DATE;

	public static final DateTimeFormatter FORMATTER_DATETIME;

	public static final DateTimeFormatter FORMATTER_DATETIME_WITHOUT_OFFSET;

	static {
		FORMATTER_DATETIME = new DateTimeFormatterBuilder()
				.parseCaseInsensitive()
				.append(DateTimeFormatter.ISO_LOCAL_DATE)
				.appendLiteral('T')
				// Geen ISO_LOCAL_TIME als formatter omdat milliseconden n.v.t zijn
				.append(DateTimeFormatter.ofPattern("HH:mm:ss"))
				.appendOffset("+HH:MM", "+00:00")
				.toFormatter().withResolverStyle(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);

		FORMATTER_DATETIME_WITHOUT_OFFSET = new DateTimeFormatterBuilder()
				.parseCaseInsensitive()
				.append(DateTimeFormatter.ISO_LOCAL_DATE)
				.appendLiteral('T')
				// Geen ISO_LOCAL_TIME als formatter omdat milliseconden n.v.t zijn
				.append(DateTimeFormatter.ofPattern("HH:mm:ss"))
				.toFormatter().withResolverStyle(ResolverStyle.STRICT).withChronology(IsoChronology.INSTANCE);
	}
}
