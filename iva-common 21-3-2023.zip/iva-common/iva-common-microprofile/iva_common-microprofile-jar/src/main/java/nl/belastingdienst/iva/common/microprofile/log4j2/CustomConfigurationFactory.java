package nl.belastingdienst.iva.common.microprofile.log4j2;

import java.net.URI;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.ConfigurationFactory;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.builder.api.AppenderComponentBuilder;
import org.apache.logging.log4j.core.config.builder.api.ConfigurationBuilder;
import org.apache.logging.log4j.core.config.builder.impl.BuiltConfiguration;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.config.ConfigProvider;

@Plugin(name = "CustomConfigurationFactory", category = ConfigurationFactory.CATEGORY)
public class CustomConfigurationFactory extends ConfigurationFactory {

	static Configuration createConfiguration(final String name, ConfigurationBuilder<BuiltConfiguration> builder) {
		Config config = ConfigProvider.getConfig();
		Level levelRoot = config.getValue("logging.level.root", Level.class);
		Level levelNl = config.getValue("logging.level.nl", Level.class);

		builder.setConfigurationName(name);
		builder.setStatusLevel(Level.DEBUG); // LogLevel for initializing configuration

		AppenderComponentBuilder consoleAppenderBuilder = builder.newAppender("Console", "CONSOLE");
		consoleAppenderBuilder.add(
				builder.newLayout("PatternLayout").addAttribute("pattern", "%d{yyyy-MM-dd HH:mm:ss.SSS} %-5p [%C{-2}.%M()] %m%n"));
		builder.add(consoleAppenderBuilder);

		AppenderComponentBuilder splunkAppenderBuilder = builder.newAppender("SplunkAppender", "Splunk");
		splunkAppenderBuilder.add(builder.newLayout("PatternLayout").addAttribute("pattern", "MM %-5p %m%n"));
		builder.add(splunkAppenderBuilder);

		builder.add(builder.newLogger("nl", levelNl).
				add(builder.newAppenderRef("Console")).
				add(builder.newAppenderRef("SplunkAppender")).addAttribute("additivity", false));
		builder.add(builder.newRootLogger(levelRoot).
				add(builder.newAppenderRef("Console")).
				add(builder.newAppenderRef("SplunkAppender")));
		return builder.build();
	}

	@Override
	protected String[] getSupportedTypes() {
		return new String[]{ "*" };
	}

	@Override
	public Configuration getConfiguration(LoggerContext loggerContext, ConfigurationSource source) {
		return getConfiguration(loggerContext, source.toString(), null);
	}

	@Override
	public Configuration getConfiguration(final LoggerContext loggerContext, final String name, final URI configLocation) {
		ConfigurationBuilder<BuiltConfiguration> builder = newConfigurationBuilder();
		return createConfiguration(name, builder);
	}
}
