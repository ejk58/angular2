package nl.belastingdienst.iva.common.microprofile.splunk;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

import nl.belastingdienst.iva.common.microprofile.validator.FormatterConstants;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApiError {
	private String type;
	private String title;
	private String detail = "";
	private String instance = "";
	private String timestamp;
	private List<ApiValidationError> validationErrors;

	public ApiError(ErrorTypeInterface type, String detail) {
		timestamp = LocalDateTime.now().atZone(ZoneId.systemDefault()).format(FormatterConstants.FORMATTER_DATETIME);
		this.type = type.getType();
		this.title = type.getTitle();
		this.detail = detail;
	}

	public ApiError(ErrorTypeInterface type, String detail, String instance) {
		this(type, detail);
		this.instance = instance;
	}
}

