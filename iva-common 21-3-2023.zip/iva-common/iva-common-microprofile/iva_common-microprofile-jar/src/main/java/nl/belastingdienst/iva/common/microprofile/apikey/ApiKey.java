package nl.belastingdienst.iva.common.microprofile.apikey;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "API_KEY")
@NamedQuery(name = "ApiKey.findAll", query = "SELECT a FROM ApiKey a")
public class ApiKey {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "API_KEY")
    private String key;

    @Column(name = "CUSTOMER")
    private String customer;

    @Column(name = "AUTHORIZED_METHODS")
    private String authorizedMethods;

}
