package nl.belastingdienst.iva.common.microprofile.validator;

public interface DateTimeValidator {
	boolean isValid(String dateTimeStr);
}