package nl.belastingdienst.iva.common.microprofile.teradata;

import java.util.concurrent.TimeUnit;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.codec.binary.Base64;

import nl.belastingdienst.iva.common.microprofile.exception.DataproviderClientException;
import nl.belastingdienst.iva.common.microprofile.util.EncryptionUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractTeraDataClient {
	public abstract String getTeradataUserId();

	public abstract String getTeradataEncryptedPassword();

	public abstract String getTeradataRestUrl();

	public String getContent(String query) {
		log.debug("URL: " + getTeradataRestUrl());
		log.debug("Query: " + query);

		int timeOut = 5000; // Timeout in millis.
		ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		clientBuilder.connectTimeout(timeOut, TimeUnit.MILLISECONDS);
		clientBuilder.readTimeout(timeOut, TimeUnit.MILLISECONDS);
		Client client = clientBuilder.build();
		WebTarget webTarget = client.target(getTeradataRestUrl());
		long before = System.currentTimeMillis();
		try (Response response = webTarget.request(MediaType.APPLICATION_JSON)
				.header("Authorization", createCredentials())
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.json(query))) {
			checkTeradataProcessingTime(query, before);
			if (response.getStatus() != 200) {
				String message = "Failed to run a query on Teradata with error " + response.readEntity(String.class);
				throw new DataproviderClientException(message);
			}
			return response.readEntity(String.class);
		} catch (Exception e) {
			throw new DataproviderClientException(e);
		}
	}

	private void checkTeradataProcessingTime(String query, long before) {
		long after = System.currentTimeMillis();
		long duration = after - before;

		if (duration > 2000L) {
			log.warn("Slow query ({} ms) on Teradata: {}", duration, query);
		}
	}

	private String createCredentials() {
		String credential = getTeradataUserId() + ":" + EncryptionUtil.getInstance().decrypt(getTeradataEncryptedPassword());
		byte[] credBytes = credential.getBytes();
		byte[] encodedCredBytes = Base64.encodeBase64(credBytes, false);
		return "Basic " + new String(encodedCredBytes); //$NON-NLS-1$
	}

}
