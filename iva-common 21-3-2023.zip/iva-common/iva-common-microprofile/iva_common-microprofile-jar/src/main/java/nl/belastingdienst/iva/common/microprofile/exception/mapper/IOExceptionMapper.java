package nl.belastingdienst.iva.common.microprofile.exception.mapper;

import java.io.IOException;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import lombok.extern.slf4j.Slf4j;

@Provider
@Slf4j
public class IOExceptionMapper implements ExceptionMapper<IOException> {

	@Override
	public Response toResponse(IOException e) {
		log.error("{}: {}", e.getClass().getName(), e.getMessage(), e);
		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
	}

}
