package nl.belastingdienst.iva.common.microprofile.logging;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

public class Markers {
    public static final Marker TRACK_AND_TRACE = MarkerFactory.getMarker("TrackTrace");
    public static final Marker INFORM = MarkerFactory.getMarker("Inform");
    public static final Marker MATTERMOST = MarkerFactory.getMarker("MatterMost");

    private Markers() {
        // Only use this class accessing the static methods.
    }
}
