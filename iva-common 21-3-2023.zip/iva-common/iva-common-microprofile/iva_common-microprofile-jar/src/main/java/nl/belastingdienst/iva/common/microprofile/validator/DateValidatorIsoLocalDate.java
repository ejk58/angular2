package nl.belastingdienst.iva.common.microprofile.validator;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class DateValidatorIsoLocalDate implements DateTimeValidator {

	@Override
	public boolean isValid(String dateStr) {
		try {
			LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE);
		} catch (DateTimeParseException e) {
			return false;
		}
		return true;
	}
}
