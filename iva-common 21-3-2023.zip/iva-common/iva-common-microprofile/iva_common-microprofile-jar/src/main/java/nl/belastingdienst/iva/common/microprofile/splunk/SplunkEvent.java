package nl.belastingdienst.iva.common.microprofile.splunk;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SplunkEvent {

	private long time = System.currentTimeMillis();

	private String source;

	private String host;

	private String sourcetype;

	private String index;

	private Event event;

	private Map<String, String> fields = new HashMap<>();

}

