package nl.belastingdienst.iva.common.microprofile.exception;

import java.io.Serializable;

import javax.validation.ConstraintViolation;

import lombok.Getter;

@Getter
public class MyConstraintViolation implements Serializable {

	private static final long serialVersionUID = 1L;
	private String message;
	private String property;
	private String value;

	public MyConstraintViolation(ConstraintViolation<? extends Object> violation) {
		this.message = violation.getMessage();
		this.property = violation.getPropertyPath().toString();
		this.value = violation.getInvalidValue() == null ? null : violation.getInvalidValue().toString();
	}

	public MyConstraintViolation(String property, String value, String message) {
		this.property = property;
		this.message = message;
		this.value = value;
	}

}
