pipelineCode_openshift_v4b {
	deploymentId = "iva-spring-batch"
	integrationPipeline = "iva-spring-batch-test"
	environmentChoices = "ont\ntst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6\n"
	nodeVersion = "nodejs16"
	mvnVersion = "maven36-openjdk11"
	vervangenOpenjdk11Image = true
	gitopsRepo = "ivacommon/iva-spring-batch-deploy.git"
	skipSonar = true
	environmentType = "springboot"
}
