package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration.TeradataPhysicalNamingStrategy;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Getter
@Setter
@RequiredArgsConstructor
@IdClass(HallmarkRisicoId.class)
@Table(name = "MDR_out_hallmarkRisico", schema = TeradataPhysicalNamingStrategy.TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER)
public class HallmarkRisico {
    @Id
    @Column(name = "disclosureid", updatable = false, insertable = false)
    private String disclosureId;
    @Id
    @Column(name = "draaidatum", updatable = false, insertable = false)
    private LocalDateTime draaiDatum;
    @Id
    @Column(name = "hallmark", updatable = false, insertable = false)
    private String hallmark;

    @Column(name = "rang")
    private Integer rang;
    @Column(name = "score")
    private Integer score;
    @Column(name = "hm_selectie_ind")
    private Boolean hmSelectieInd;
    @Column(name = "hm_selectie_reden")
    private String hmSelectieReden;
    @Column(name = "subhallmarks")
    private String subHallmarks;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "disclosureid", referencedColumnName = "disclosureid")
    @JoinColumn(name = "draaidatum", referencedColumnName = "draaidatum")
    @JoinColumn(name = "hallmark", referencedColumnName = "hallmark")
    private Set<Beslisregel> beslisregels;

}
