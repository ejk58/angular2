package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto;

import lombok.Data;

import java.util.List;

@Data
public class PrioriteitDAC6NewUpdateDTO {

	private String hallmark;

	private Integer rang;

	private Integer score;

	private Boolean hmSelectieInd;

	private String hmSelectieReden;

	private List<String> subhallmarks;

	private List<BeslisregelDAC6DTO> beslisregels;
}
