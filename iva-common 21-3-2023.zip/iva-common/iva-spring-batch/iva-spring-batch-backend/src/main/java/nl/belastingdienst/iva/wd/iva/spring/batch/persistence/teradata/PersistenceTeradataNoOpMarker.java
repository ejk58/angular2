package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata;

public interface PersistenceTeradataNoOpMarker {
}
