package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration.TeradataPhysicalNamingStrategy;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@RequiredArgsConstructor
@Table(name = "MDR_out_model", schema = TeradataPhysicalNamingStrategy.TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER)
public class Model {

    @Id
    @Column(name = "draaidatum", updatable = false)
    private LocalDateTime draaiDatum;
    @Column(name = "modelversie")
    private String modelVersie;
}
