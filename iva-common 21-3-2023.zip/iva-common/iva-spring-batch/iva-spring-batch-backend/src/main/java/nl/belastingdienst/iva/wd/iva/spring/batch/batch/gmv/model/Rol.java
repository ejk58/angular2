package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model;

public enum Rol {

	DISCLOSER("DisclosingPerson"),
	TAXPAYER("RelevantTaxpayer"),
	PERSON("AffectedPerson"),
	ENTERPRISE("AssociatedEnterprise"),
	INTERMEDIARY("Intermediary"),
	ARRANGEMENT_CHART("ArrangementChart"),
	UNKNOWN("Unknown");

	private final String description;

	Rol(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

}
