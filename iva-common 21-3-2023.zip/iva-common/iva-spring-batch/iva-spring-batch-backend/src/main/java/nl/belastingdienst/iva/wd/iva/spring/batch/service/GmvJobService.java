package nl.belastingdienst.iva.wd.iva.spring.batch.service;

import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.UNSPECIFIED;
import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.IVA_SPRING_BATCH_GMV_CHECK;

import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.common.logging.MattermostAppender;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.JobResultStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.JobResultStatus.JobResultStatusBuilder;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class GmvJobService {

    private final JobLauncher jobLauncher;

    private final Job loadGmvJob;

    private final MeldingStatusRepository meldingStatusRepository;

    private final HandshakeService handshakeService;

    public GmvJobService(JobLauncher jobLauncher,
                               @Qualifier("loadGmv") Job loadGmvJob,
                               MeldingStatusRepository meldingStatusRepository,
                                HandshakeService handshakeService) {
        this.jobLauncher = jobLauncher;
        this.loadGmvJob = loadGmvJob;
        this.meldingStatusRepository = meldingStatusRepository;
        this.handshakeService = handshakeService;
    }

    public JobResultStatus loadGMV() throws JobInstanceAlreadyCompleteException,
            JobExecutionAlreadyRunningException, JobParametersInvalidException,
            JobRestartException {
        handshakeService.checkIfGmvIsAllowedToProcess();
        return doJob(loadGmvJob);
    }

    private JobResultStatus doJob(Job job) throws JobParametersInvalidException,
            JobExecutionAlreadyRunningException, JobRestartException,
            JobInstanceAlreadyCompleteException {
        Map<String, JobParameter> jobParameterMap = new HashMap<>();
        return runJob(job, jobParameterMap);
    }

    public String getAllFailuresEver() {
        return getFailureMessages(this.meldingStatusRepository.findMeldingStatusByInErrorIsTrueOrderByDraaidatum());
    }

    public String getFailuresForJobId(Long jobId) {
        return getFailureMessages(this.meldingStatusRepository.findMeldingStatusByInErrorIsTrueAndJobId(jobId));
    }

    public String getMostRecentFailures() {
        Optional<MeldingStatus> lastJobMeldingStatus = this.meldingStatusRepository.findFirstByOrderByJobIdDesc();
        if(lastJobMeldingStatus.isEmpty()) {
            return null;
        }
        Long lastJobId = lastJobMeldingStatus.get().getJobId();
        return getFailuresForJobId(lastJobId);
    }

    private JobResultStatus runJob(Job job, Map<String, JobParameter> jobParameterMap)
            throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException,
            JobParametersInvalidException {
        jobParameterMap.put("started", new JobParameter(System.currentTimeMillis()));
        jobParameterMap.put("stopOnError", new JobParameter("N"));
        JobParameters parameters = new JobParameters(jobParameterMap);
        JobExecution jobExecution = jobLauncher.run(job, parameters);
        long jobId = jobExecution.getId();
        List<MeldingStatus> failures = this.meldingStatusRepository.findMeldingStatusByInErrorIsTrueAndJobId(jobId);
        List<MeldingStatus> skipped = this.meldingStatusRepository.findMeldingStatusBySkippedIsTrueAndJobId(jobId);
        JobResultStatusBuilder jobResultStatusBuilder = JobResultStatus.builder()
                .job(job).jobExecution(jobExecution).failures(failures).skipped(skipped);
        JobResultStatus jobResultStatus = jobResultStatusBuilder.build();
        logToMatterMost(jobResultStatus.toString(), BatchStatus.COMPLETED.equals(jobExecution.getStatus()) && failures.isEmpty());
        log.info(jobResultStatus.toStringExtendend());
        return jobResultStatus;
    }

    private void logToMatterMost(String logregel, boolean completedAndNoFailures) {
        if (completedAndNoFailures) {
            log.info(MattermostAppender.marker, logregel);
        } else {
            log.error(MattermostAppender.marker, logregel);
        }
    }

    private String getFailureMessages(List<MeldingStatus> failures) {
        if (!failures.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            sb.append("\nFouten tijdens verwerken meldingen:\n");
            sb.append("-------\n");
            failures.forEach(meldingStatus -> {
                sb.append(String.format("%nFouten in melding disclosureID: %s, draaidatum: %s en jobId: %d%n",
                        meldingStatus.getDisclosureId(), meldingStatus.getDraaidatum(), meldingStatus.getJobId()));
                if (meldingStatus.getExecutionMessage() != null) {
                    sb.append("error message : ").append(meldingStatus.getExecutionMessage()).append("\n");
                }
                if (meldingStatus.getValidationErrors() != null) {
                    sb.append("validatiefout(en) : ").append(meldingStatus.getValidationErrors()).append("\n");
                }
            });
            return sb.toString();
        }
        return "No Failures";

    }
}
