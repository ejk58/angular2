package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration.TeradataPhysicalNamingStrategy;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "MDR_out_verantwoordingsinfo", schema = TeradataPhysicalNamingStrategy.TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER)
@IdClass(VerantwoordingsinfoId.class)
public class Verantwoordingsinfo {
    @Id
    @Column(name = "disclosureid", updatable = false, insertable = false)
    private String disclosureId;
    @Id
    @Column(name = "draaidatum", updatable = false, insertable = false)
    private LocalDateTime draaiDatum;
    @Id
    @Column(name = "br_referentie", updatable = false, insertable = false)
    private String brReferentie;
    @Id
    @Column(name = "risico_info_naam")
    private String risicoInfoNaam;
    @Id
    @Column(name = "risico_info_waarde")
    private String risicoInfoWaarde;

}
