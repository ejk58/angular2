package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration.TeradataPhysicalNamingStrategy;

import javax.persistence.*;
import java.sql.Timestamp;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = TeradataPhysicalNamingStrategy.TERADATA_DFA_TABLE_NAME_PLACEHOLDER, schema = TeradataPhysicalNamingStrategy.TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER)
@IdClass(HandshakeId.class)
@ToString
public class HandshakeMDR {

    @Id
    @Column(name = "created")
    Timestamp created;
    @Column(name = "user_id")
    String userId;
    @Id
    @Column(name = "product")
    String product;
    @Id
    @Column(name = "event_name")
    String eventName;
    @Column(name = "event_value")
    String eventValue;
}
