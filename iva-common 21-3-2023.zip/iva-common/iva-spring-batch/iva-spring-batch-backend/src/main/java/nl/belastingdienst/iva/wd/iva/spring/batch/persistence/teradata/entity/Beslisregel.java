package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration.TeradataPhysicalNamingStrategy;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@IdClass(BeslisregelId.class)
@Table(name = "MDR_out_beslisregel", schema = TeradataPhysicalNamingStrategy.TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER)
public class Beslisregel {

    @Id
    @Column(name = "disclosureid", updatable = false, insertable = false)
    private String disclosureId;
    @Id
    @Column(name = "draaidatum", updatable = false, insertable = false)
    private LocalDateTime draaiDatum;
    @Id
    @Column(name = "hallmark", updatable = false, insertable = false)
    private String hallmark;
    @Id
    @Column(name = "br_referentie", updatable = false, insertable = false)
    private String brReferentie;

    @Column(name = "br_score")
    private Integer score;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "disclosureid", referencedColumnName = "disclosureid")
    @JoinColumn(name = "draaidatum", referencedColumnName = "draaidatum")
    @JoinColumn(name = "br_referentie", referencedColumnName = "br_referentie")
    @JoinColumn(name = "hallmark", referencedColumnName = "hallmark")
    private Set<Verantwoordingsinfo> verantwoordingsinfos;
}
