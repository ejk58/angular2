package nl.belastingdienst.iva.wd.iva.spring.batch.exceptions;

public class SkippedInProcessorException extends SkippableException {

    private static final long serialVersionUID = 3742484916272018407L;
    private static final String DEFAULT_MESSAGE = "An exception occurred during the write phase of a batch job";

    public SkippedInProcessorException() {
        super(DEFAULT_MESSAGE);
    }

    public SkippedInProcessorException(String message) {
        super(message);
    }

    public SkippedInProcessorException(Throwable cause) {
        super(DEFAULT_MESSAGE, cause);
    }

    public SkippedInProcessorException(String message, Throwable cause) {
        super(message, cause);
    }
}

