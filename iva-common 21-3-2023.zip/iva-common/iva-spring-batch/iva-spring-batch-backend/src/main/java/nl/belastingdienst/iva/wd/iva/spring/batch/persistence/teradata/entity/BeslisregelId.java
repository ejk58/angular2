package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@RequiredArgsConstructor
@EqualsAndHashCode
public class BeslisregelId implements Serializable {

    private static final long serialVersionUID = 4878553781423660070L;

    private String disclosureId;
    private LocalDateTime draaiDatum;
    private String hallmark;
    private String brReferentie;
}
