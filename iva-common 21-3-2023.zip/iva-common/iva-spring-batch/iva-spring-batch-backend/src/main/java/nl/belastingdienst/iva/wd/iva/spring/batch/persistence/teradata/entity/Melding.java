package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.*;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration.TeradataPhysicalNamingStrategy;

import javax.persistence.*;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "MDR_out_melding", schema = TeradataPhysicalNamingStrategy.TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER)
@IdClass(MeldingId.class)
public class Melding {

    @Id
    @Column(name = "disclosureid")
    private String disclosureId;
    @Id
    @Column(name = "draaidatum", insertable = false, updatable = false)
    private LocalDateTime draaiDatum;

    @Column(name = "arrangementid")
    String arrangementId;
    @Column(name = "disclosure_timestamp")
    private LocalDateTime disclosureTimestamp;
    @Column(name = "disclosure_volgnr")
    private Integer disclosureVolgnr;
    @Column(name = "meldingselectie_ind")
    private Boolean meldingSelectieInd;
    @Column(name = "meldingselectie_reden")
    private String meldingSelectieReden;
    @Column(name = "amount_eur")
    private Long amountEur;
    @Column(name = "implementatiedatum")
    private Date implementatieDatum;
    @Column(name = "belastingmiddelen")
    private String belastingmiddelen;
    @Column(name = "samenvatting")
    private String samenvatting;
    @Column(name = "overcap_rang")
    private Integer overcapRang;
    @Column(name = "overcap_score")
    private Integer overcapScore;
    @Column(name = "overcap_aantal_hm")
    private Integer overcapAantalHm;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "disclosureid", referencedColumnName = "disclosureid")
    @JoinColumn(name = "draaidatum", referencedColumnName = "draaidatum")
    private Set<Subject> subjecten;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "draaidatum", referencedColumnName = "draaidatum")
    @JoinColumn(name = "disclosureid", referencedColumnName = "disclosureid")
    private Set<HallmarkRisico> hallmarkRisicos;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "draaidatum", referencedColumnName = "draaidatum")
    Model model;

    @Override
    public String toString() {
        return "Melding{" +
                "disclosureId='" + disclosureId + '\'' +
                ", draaiDatum=" + draaiDatum +
                '}';
    }

}
