package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration.TeradataPhysicalNamingStrategy;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "MDR_out_melding", schema = TeradataPhysicalNamingStrategy.TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER)
@IdClass(MeldingId.class)
public class MeldingKey {
    @Id
    @Column(name = "disclosureid")
    private String disclosureId;
    @Id
    @Column(name = "draaidatum", insertable = false, updatable = false)
    private LocalDateTime draaiDatum;
}
