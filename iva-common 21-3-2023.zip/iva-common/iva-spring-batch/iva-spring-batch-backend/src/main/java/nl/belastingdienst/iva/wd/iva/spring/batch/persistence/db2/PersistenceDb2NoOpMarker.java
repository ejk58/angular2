package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2;

public interface PersistenceDb2NoOpMarker {
}
