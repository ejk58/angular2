package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto;

import lombok.Data;

import java.util.List;
@Data
public class BeslisregelDAC6DTO {
    private String brReferentie;

    private Integer score;

    private List<VerantwoordingsinfoDAC6DTO> verantwoordingsinfos;
}
