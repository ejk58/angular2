package nl.belastingdienst.iva.wd.iva.spring.batch.security;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_APIKEY;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.ApiKey;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.ApiKeyRepository;

import lombok.extern.log4j.Log4j2;
@Component
@Order(1)
@Log4j2
public class ApiKeyRequestFilter extends GenericFilterBean {

	@Autowired
	private ApiKeyRepository apiKeyRepository;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		String path = req.getRequestURI();

		if(!path.startsWith("/api")){
			chain.doFilter(request, response);
			return;
		}

		String key = req.getHeader(HEADER_APIKEY) == null ? "" : req.getHeader(HEADER_APIKEY);
		log.debug("Trying key: " + key);

		Optional<ApiKey> apiKeyOptional = this.apiKeyRepository.findApiKeyByKey(key);
		if(apiKeyOptional.isPresent()){
			chain.doFilter(request, response);
		}else{
			HttpServletResponse resp = (HttpServletResponse) response;
			String error = "Invalid API KEY";

			resp.reset();
			resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			response.setContentLength(error .length());
			response.getWriter().write(error);
		}
	}
}
