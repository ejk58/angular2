package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model;

import lombok.Data;
import lombok.ToString;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;

@Data
@ToString
public class WriteObject {
	private MeldingStatus meldingStatus;
	private MeldingDAC6NewUpdateDTO melding;

    public WriteObject(MeldingStatus meldingStatus, MeldingDAC6NewUpdateDTO melding) {
        this.meldingStatus = meldingStatus;
        this.melding = melding;
    }
}
