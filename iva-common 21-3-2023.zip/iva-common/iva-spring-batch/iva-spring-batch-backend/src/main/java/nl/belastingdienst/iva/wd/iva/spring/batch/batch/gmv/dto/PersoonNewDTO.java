package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto;

import lombok.Data;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.Rol;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Data
public class PersoonNewDTO {
	private Integer bsnRsin;
	private String naam; // Naam van BSN/RSIN
	@Enumerated(EnumType.STRING)
	private Rol rol;
}
