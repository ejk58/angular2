package nl.belastingdienst.iva.wd.iva.spring.batch.exceptions;

public class MeldingNotNewOrSelectedException extends Exception {

    private static final long serialVersionUID = 107415979877411109L;
    private static final String DEFAULT_MESSAGE = "Melding heeft staus NEW of SELECTED";

    public MeldingNotNewOrSelectedException() {
        super();
    }

    public MeldingNotNewOrSelectedException(String message) {
        super(message);
    }
}
