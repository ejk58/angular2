package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mapper;


import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.*;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.Rol;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.*;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

@Mapper(componentModel = "spring")
public interface MeldingDAC6Mapper {
	@Mapping(target = "meldingselectieInd", source = "meldingSelectieInd")
	@Mapping(target = "meldingselectieReden", source = "meldingSelectieReden")
	@Mapping(target = "modelDAC6", source = "model")
	@Mapping(target = "personen", source = "subjecten")
	@Mapping(target = "belastingMiddelen", source = "belastingmiddelen")
	@Mapping(target = "prioriteiten", source = "hallmarkRisicos")
	MeldingDAC6NewUpdateDTO map(Melding src);

	@Mapping(target = "bsnRsin", source = "finr")
	@Mapping(target = "rol", ignore = true)
	PersoonNewDTO map(Subject src);

	@Mapping(target = "modelversie", source = "modelVersie")
	@Mapping(target = "draaidatum", source = "draaiDatum")
	ModelDAC6DTO map(Model src);

	@Mapping(target = "subhallmarks", expression = "java(getListFromSeperatedString(src.getSubHallmarks()))")
	PrioriteitDAC6NewUpdateDTO map(HallmarkRisico src);

	BeslisregelDAC6DTO map(Beslisregel src);

	VerantwoordingsinfoDAC6DTO map(Verantwoordingsinfo src);

	default List<String> getListFromSeperatedString(String seperatedString) {
		List<String> noSpacesList = new ArrayList<>();
		if (seperatedString != null) {
			Arrays.stream(seperatedString.split(",")).forEach(s -> noSpacesList.add(s.trim()));
		}
		return noSpacesList;
	}

	@AfterMapping
	default void mapFrontendHallmarksToPrioriteitenDAC6(Subject subject, @MappingTarget PersoonNewDTO persoonNewDTO) {
		String rol = subject.getRol();
		if (rol != null) {
			Rol matchingRolEnum = Stream.of(Rol.values())
					.filter(rolEnum -> rolEnum.getDescription().equalsIgnoreCase(rol.replaceAll("\\s+","")))
					.findAny()
					.orElseThrow(() -> new CommonException("Onbekende rol " + rol));
			persoonNewDTO.setRol(matchingRolEnum);
		}
	}

}
