package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Transactional
public interface MeldingStatusRepository extends JpaRepository<MeldingStatus, Integer> {
     Optional<MeldingStatus> findMeldingStatusByDisclosureIdAndDraaidatum(String disclosureId, LocalDateTime draaiDatum);

     List<MeldingStatus> findMeldingStatusByInErrorIsTrueAndJobId(Long jobid);
     List<MeldingStatus> findMeldingStatusBySkippedIsTrueAndJobId(Long jobid);
     List<MeldingStatus> findMeldingStatusByInErrorIsTrueOrderByDraaidatum();
     Optional<MeldingStatus> findFirstByOrderByJobIdDesc();
}
