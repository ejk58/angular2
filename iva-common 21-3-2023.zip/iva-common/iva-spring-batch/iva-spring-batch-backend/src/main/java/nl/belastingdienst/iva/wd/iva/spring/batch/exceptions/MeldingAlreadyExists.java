package nl.belastingdienst.iva.wd.iva.spring.batch.exceptions;

public class MeldingAlreadyExists extends Exception {


    private static final long serialVersionUID = 8432962956417443264L;
    private static final String DEFAULT_MESSAGE = "Melding bestaat al of heeft verkeerde status. Niet geüpdate.";

    public MeldingAlreadyExists() {
        super(DEFAULT_MESSAGE);
    }

    public MeldingAlreadyExists(String message) {
        super(message);
    }

}
