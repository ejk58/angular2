package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeMDR;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface HandshakeMdrRepository extends JpaRepository<HandshakeMDR, HandshakeId> {
}
