package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Id;

@Getter
@Setter
public class HallmarkDAC6 {

    @Id
    private String code;

    private String description;

    private String hoofdhallmark;

    private boolean showInGmv;
}
