package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv;

import lombok.NonNull;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component("dummy")
@Log4j2
public class DummmyMeldingWriter implements ItemWriter<WriteObject> {

    @Autowired
    MeldingStatusRepository meldingStatusRepository;

    @Override
    public void write(@NonNull List<? extends WriteObject> writeObjects) {
        writeObjects.forEach(writeObject -> {
            writeObject.getMeldingStatus().setModified(LocalDateTime.now());
            meldingStatusRepository.save(writeObject.getMeldingStatus());
        });
     }
}
