package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration.TeradataPhysicalNamingStrategy;

import javax.persistence.*;
import java.time.LocalDateTime;

@Table(name = "MDR_out_subject", schema = TeradataPhysicalNamingStrategy.TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER)
@Entity
@Getter
@Setter
@RequiredArgsConstructor
@IdClass(SubjectId.class)
public class Subject {
    @Id
    @Column(name = "disclosureid", insertable = false, updatable = false)
    private String disclosureId;
    @Id
    @Column(name = "draaidatum", insertable = false, updatable = false)
    private LocalDateTime draaiDatum;
    @Id
    @Column(name = "subjectstelsel_cd", insertable = false, updatable = false)
    private String subjectstelselCd;
    @Id
    @Column(name = "subjectstelsel_wrd", insertable = false, updatable = false)
    private String subjectstelselWrd;

    @Column(name = "finr")
    private Integer finr;
    @Column(name = "rol")
    private String rol;
    @Column(name = "naam")
    private String naam;

}
