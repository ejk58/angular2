package nl.belastingdienst.iva.wd.iva.spring.batch;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.models.ExternalDocumentation;
import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.wd.iva.spring.batch.interceptor.RestTemplateInterceptor;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@EnableConfigurationProperties
@EnableRetry
@OpenAPIDefinition(
        info = @Info(
                title = "${iva.spring.batch.name}",
                description = "${iva.spring.batch.description}",
                version = "${iva.spring.batch.version}-${git.commit.id.abbrev}",
                contact = @Contact(
                        name = "${iva.spring.batch.contact.name}",
                        url = "${iva.spring.batch.contact.url}",
                        email = "${iva.spring.batch.contact.email}"
                )
        )
)
@RequiredArgsConstructor
public class Application {

    private final ClientHttpRequestFactory clientHttpRequestFactory;


    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);

        List<ClientHttpRequestInterceptor> interceptors = restTemplate.getInterceptors();
        if (CollectionUtils.isEmpty(interceptors)) {
            interceptors = new ArrayList<>();
        }
        interceptors.add(new RestTemplateInterceptor());
        restTemplate.setInterceptors(interceptors);
        return restTemplate;
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
        PropertySourcesPlaceholderConfigurer propsConfig
                = new PropertySourcesPlaceholderConfigurer();
        propsConfig.setLocation(new ClassPathResource("git.properties"));
        propsConfig.setIgnoreResourceNotFound(true);
        propsConfig.setIgnoreUnresolvablePlaceholders(true);
        return propsConfig;
    }

    //For some reason the ExternalDocumentation in the OpenAPIDefinition annotation doesn't work with property injection
    @Bean
    public OpenApiCustomiser openApiCustomiser(@Value("${iva.spring.batch.documentation.description}") String description,
                                               @Value("${iva.spring.batch.documentation.url}") String url) {
        return openApi -> {
            ExternalDocumentation externalDocumentation = new ExternalDocumentation();
            externalDocumentation.setDescription(description);
            externalDocumentation.setUrl(url);
            openApi.setExternalDocs(externalDocumentation);
        };
    }
}
