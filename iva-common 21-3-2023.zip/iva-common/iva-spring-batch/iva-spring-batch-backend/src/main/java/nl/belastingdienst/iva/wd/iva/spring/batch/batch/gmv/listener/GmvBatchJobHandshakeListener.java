package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.listener;

import java.util.List;
import java.util.Optional;

import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.HandshakeService;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class GmvBatchJobHandshakeListener implements JobExecutionListener {

    private final HandshakeService handshakeService;
    private final String defaultUserId;
    private final String defaultEventValueStart;
    private final MeldingStatusRepository meldingStatusRepository;

    public GmvBatchJobHandshakeListener(HandshakeService handshakeService,
            MeldingStatusRepository meldingStatusRepository,
            @Value("${iva.spring.batch.datasource.teradata.username}") String defaultUserId,
            @Value("${iva.spring.batch.name}") String applicationName,
            @Value("${iva.spring.batch.version}") String applicationVersion) {
        this.handshakeService = handshakeService;
        this.meldingStatusRepository = meldingStatusRepository;
        this.defaultUserId = defaultUserId;
        this.defaultEventValueStart = applicationName + " " + applicationVersion;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        handshakeService.setIVToRunStart(defaultUserId, defaultEventValueStart);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        if(jobExecution.getAllFailureExceptions().isEmpty() && !hasFailures()) {
            handshakeService.setIVToRunEnd(defaultUserId);
        }
    }

    private boolean hasFailures() {
        Optional<MeldingStatus> meldingStatus = meldingStatusRepository.findFirstByOrderByJobIdDesc();
        if (meldingStatus.isPresent()) {
            long jobId = meldingStatus.get().getJobId();
            List<MeldingStatus> failures = meldingStatusRepository.findMeldingStatusByInErrorIsTrueAndJobId(jobId);
            return !failures.isEmpty();
        }

        return false;
    }
}
