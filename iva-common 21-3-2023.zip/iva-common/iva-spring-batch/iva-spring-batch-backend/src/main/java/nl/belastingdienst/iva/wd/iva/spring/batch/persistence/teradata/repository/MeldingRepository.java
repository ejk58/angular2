package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Melding;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingId;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.transaction.annotation.Transactional;

@Transactional(value = "teradataTransactionManager", readOnly = true)
public interface MeldingRepository extends PagingAndSortingRepository<Melding, MeldingId> {
}
