package nl.belastingdienst.iva.wd.iva.spring.batch.service;

import static java.util.Comparator.comparing;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.OppositeSideIsProcessingException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeGMV;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeMDR;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.HandshakeGmvRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.HandshakeMdrRepository;

@Service
public class HandshakeService {

    public static final String RUN_START = "RUN_START";
    public static final String RUN_END = "RUN_END";
    public static final String MDR = "MDR";

    private final boolean useHandshake;
    private final HandshakeGmvRepository handshakeGmvRepository;
    private final HandshakeMdrRepository handshakeMdrRepository;

    public HandshakeService(HandshakeGmvRepository handshakeGmvRepository,
                HandshakeMdrRepository handshakeMdrRepository,
                @Value("${iva.spring.batch.handshake.use-handshake}") boolean useHandshake) {
        this.useHandshake = useHandshake;
        this.handshakeGmvRepository = handshakeGmvRepository;
        this.handshakeMdrRepository = handshakeMdrRepository;
    }

    private void setIVWritingStatus(String userId, String version, String status) {
        HandshakeGMV handshakeGMV = new HandshakeGMV();
        handshakeGMV.setProduct(MDR);
        handshakeGMV.setCreated(Timestamp.from(Instant.now()));
        handshakeGMV.setEventValue(version);
        handshakeGMV.setUserId(userId);
        handshakeGMV.setEventName(status);
        handshakeGmvRepository.save(handshakeGMV);
    }

    public void setIVToRunEnd(String userId) {
        setIVWritingStatus(userId, null, RUN_END);
    }

    public void setIVToRunStart(String userId, String version) {
        setIVWritingStatus(userId, version, RUN_START);
    }

    public void checkIfGmvIsAllowedToProcess() {
        if (!useHandshake) {
            return;
        }
        final Optional<HandshakeMDR> lastMdrEvent = getLastMdrEvent();
        final Optional<HandshakeGMV> lastGmvEvent = getLastGmvEvent();
        throwExceptionIfNotAllowedToProcess(lastMdrEvent, lastGmvEvent);
    }

    private Optional<HandshakeGMV> getLastGmvEvent() {
        return handshakeGmvRepository.findAll().stream().filter(handshakeGMV -> handshakeGMV.getProduct().equals(MDR))
                .filter(handshakeGMV -> handshakeGMV.getEventName().equals(RUN_END) || handshakeGMV.getEventName()
                        .equals(RUN_START)).max(comparing(HandshakeGMV::getCreated));
    }

    private Optional<HandshakeMDR> getLastMdrEvent() {
        return handshakeMdrRepository.findAll().stream().filter(handshakeMDR -> handshakeMDR.getProduct().equals(MDR))
                .filter(handshakeMDR -> handshakeMDR.getEventName().equals(RUN_END) || handshakeMDR.getEventName()
                        .equals(RUN_START)).max(comparing(HandshakeMDR::getCreated));
    }

    private void throwExceptionIfNotAllowedToProcess(
            Optional<HandshakeMDR> lastMdrEventOptional, Optional<HandshakeGMV> lastGmvEventOptional) {
        if(lastMdrEventOptional.isEmpty()) {
            throw new OppositeSideIsProcessingException("MDR has never written to the handshake table before. Cannot start job.",
                    lastMdrEventOptional, lastGmvEventOptional);
        }
        HandshakeMDR lastMdrEvent = lastMdrEventOptional.get();
        if(lastMdrEvent.getEventName().equals(RUN_START)) {
            throw new OppositeSideIsProcessingException("MDR is still processing. Cannot start job.",
                    lastMdrEventOptional, lastGmvEventOptional);
        }
        if(lastGmvEventOptional.isPresent() && lastGmvEventOptional.get().getEventName().equals(RUN_START)) return;
        Timestamp lastGmvCreated = lastGmvEventOptional.map(HandshakeGMV::getCreated).orElse(Timestamp.from(Instant.EPOCH));
        if(lastGmvCreated.compareTo(lastMdrEvent.getCreated()) >= 0) {
            throw new OppositeSideIsProcessingException("MDR has not provided new batch data since last run. Cannot start job.",
                    lastMdrEventOptional, lastGmvEventOptional);
        }
    }
}
