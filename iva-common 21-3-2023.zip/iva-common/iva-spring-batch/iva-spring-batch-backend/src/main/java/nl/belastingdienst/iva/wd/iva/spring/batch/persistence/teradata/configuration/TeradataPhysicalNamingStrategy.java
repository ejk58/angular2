package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration;

import lombok.RequiredArgsConstructor;
import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class TeradataPhysicalNamingStrategy implements PhysicalNamingStrategy {

    public static final String TERADATA_IV_SCHEMA_NAME_PLACEHOLDER = "teradataModelSchemaNamePlaceholder";
    public static final String TERADATA_IV_TABLE_NAME_PLACEHOLDER = "teradataModelTableNamePlaceholder";
    public static final String TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER = "teradataHandshakeSchemaNamePlaceholder";
    public static final String TERADATA_DFA_TABLE_NAME_PLACEHOLDER = "teradataHandshakeTableNamePlaceholder";

    @Value("${iva.spring.batch.datasource.teradata.handshake.iva-schema-name}")
    private String ivaSchemaName;
    @Value("${iva.spring.batch.datasource.teradata.handshake.iva-table-name}")
    private String ivaTableName;
    @Value("${iva.spring.batch.datasource.teradata.handshake.dfa-schema-name}")
    private String dfaSchemaName;
    @Value("${iva.spring.batch.datasource.teradata.handshake.dfa-table-name}")
    private String dfaTableName;

    @Override
    public Identifier toPhysicalCatalogName(Identifier identifier, JdbcEnvironment jdbcEnvironment) {
        return identifier;
    }

    @Override
    public Identifier toPhysicalSchemaName(Identifier identifier, JdbcEnvironment jdbcEnvironment) {
        if(identifier == null) return null;
        String newSchemaName;
        switch (identifier.getText()) {
            case TERADATA_DFA_SCHEMA_NAME_PLACEHOLDER:
                newSchemaName = dfaSchemaName;
                break;
            case TERADATA_IV_SCHEMA_NAME_PLACEHOLDER:
                newSchemaName = ivaSchemaName;
                break;
            default:
                return identifier;
        }
        return Identifier.toIdentifier(newSchemaName,true);
    }

    @Override
    public Identifier toPhysicalTableName(Identifier identifier, JdbcEnvironment jdbcEnvironment) {
        if(identifier == null) return null;
        String newTableName;
        switch (identifier.getText()) {
            case TERADATA_DFA_TABLE_NAME_PLACEHOLDER:
                newTableName = dfaTableName;
                break;
            case TERADATA_IV_TABLE_NAME_PLACEHOLDER:
                newTableName = ivaTableName;
                break;
            default:
                return identifier;
        }
        return Identifier.toIdentifier(newTableName,true);
    }

    @Override
    public Identifier toPhysicalSequenceName(Identifier identifier, JdbcEnvironment jdbcEnvironment) {
        return identifier;
    }

    @Override
    public Identifier toPhysicalColumnName(Identifier identifier, JdbcEnvironment jdbcEnvironment) {
        return identifier;
    }
}
