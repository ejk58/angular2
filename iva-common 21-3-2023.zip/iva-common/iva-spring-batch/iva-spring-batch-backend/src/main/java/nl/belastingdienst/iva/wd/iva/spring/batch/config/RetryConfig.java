/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: RetryConfig.java
 *             Auteur: veldb13
 *    Creatietijdstip: 9-2-2023 09:14
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.support.RetryTemplate;

@Configuration
public class RetryConfig {
	public static int RETRY_3_TIMES_WITH_1_SECOND_BACKOFF = 3;

	@Bean
	public RetryTemplate retry3TimesWith1SecondBackoff() {
		return RetryTemplate.builder()
				.maxAttempts(RETRY_3_TIMES_WITH_1_SECOND_BACKOFF)
				.fixedBackoff(1000)
				.build();
	}
}
