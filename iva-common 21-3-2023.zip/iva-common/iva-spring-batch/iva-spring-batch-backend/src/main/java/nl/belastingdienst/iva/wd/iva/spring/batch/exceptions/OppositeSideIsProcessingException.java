package nl.belastingdienst.iva.wd.iva.spring.batch.exceptions;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeMDR;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeGMV;

import java.util.Optional;

public class OppositeSideIsProcessingException extends RuntimeException {

    private static final long serialVersionUID = -5598680121069642307L;
    private static final String DEFAULT_MESSAGE = "DF&A last written handshake record is a run start event. Preventing you from running this batch process.";

    public OppositeSideIsProcessingException(String message) {
        super(message);
    }

    public OppositeSideIsProcessingException(String message, Optional<HandshakeMDR> handshakeMdr, Optional<HandshakeGMV> handshakeGmv) {
        this(String.format("%s Last MDR record: %s. Last GMV record: %s.",
                message,
                handshakeMdr.map(HandshakeMDR::toString).orElse("null"),
                handshakeGmv.map(HandshakeGMV::toString).orElse("null")
        ));
    }

    public OppositeSideIsProcessingException(Optional<HandshakeMDR> handshakeMdr, Optional<HandshakeGMV> handshakeGmv) {
        this(DEFAULT_MESSAGE, handshakeMdr, handshakeGmv);
    }

    public OppositeSideIsProcessingException() {
        this(DEFAULT_MESSAGE);
    }
}
