package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippableException;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippedInWriterException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
@Log4j2
@RequiredArgsConstructor
@Primary
public class MeldingWriter implements ItemWriter<WriteObject> {

    private final GmvService gmvService;

    private final MeldingStatusRepository meldingStatusRepository;

    @Override
    public void write(List<? extends WriteObject> writeObjects) {
        writeObjects.forEach(this::writeObject);
    }

    private void writeObject(WriteObject writeObject) {
        MeldingStatus meldingStatus = writeObject.getMeldingStatus();
        try {
            String s = gmvService.sendToGmv(writeObject.getMelding());
            meldingStatus.setGmvId(s);
            meldingStatus.setModified(LocalDateTime.now());
            meldingStatusRepository.save(meldingStatus);
        } catch (Exception exception) {
            handleException(exception, meldingStatus);
        }
    }

    private void handleException(Exception exception, MeldingStatus meldingStatus) {
        StringBuilder logMessageBuilder = buildLogMessage(exception, meldingStatus);
        if(exception instanceof SkippedInWriterException) {
            SkippedInWriterException skippableException = (SkippedInWriterException) exception;
            log.info(logMessageBuilder.toString());
            boolean inError = HttpStatus.BAD_REQUEST.equals(skippableException.getHttpStatus());
            prepAndSaveMeldingStatus(meldingStatus, exception, inError);
            throw (SkippableException) exception;
        }
        if(exception instanceof CommonException) {
            log.error(logMessageBuilder.toString());
            prepAndSaveMeldingStatus(meldingStatus, exception, true);
            throw (CommonException) exception;
        }
        prepAndSaveMeldingStatus(meldingStatus, exception, true);
        logMessageBuilder.insert(0, "An unexpected exception was caught. ");
        log.error(logMessageBuilder.toString(), exception);
        throw new CommonException("An unexpected exception was caught.", exception);
    }

    private void prepAndSaveMeldingStatus(MeldingStatus meldingStatus, Exception exception, boolean inError) {
        meldingStatus.setInError(inError);
        meldingStatus.setSkipped(!inError);
        String message = exception.getMessage();
        if (message == null) {
            meldingStatus.setExecutionMessage(exception.toString());
        } else {
            StringBuilder excecutionMessageBuilder = new StringBuilder(message);
            if (exception.getMessage().length() > 255) {
                String messageTelomere = "...[MessageTooLongCheckLogs]";
                excecutionMessageBuilder.delete(255 - messageTelomere.length(), excecutionMessageBuilder.length())
                        .append(messageTelomere);
            }
            meldingStatus.setExecutionMessage(excecutionMessageBuilder.toString());
        }

        meldingStatus.setModified(LocalDateTime.now());
        meldingStatusRepository.save(meldingStatus);
    }

    private StringBuilder buildLogMessage(Exception exception, MeldingStatus meldingStatus) {
        StringBuilder stringBuilder = new StringBuilder();
        return stringBuilder.append("Exception message: ").append(exception.getMessage())
                .append(" Meldingstatus disclosureId: ").append(meldingStatus.getDisclosureId())
                .append(", draaidatum: ").append(meldingStatus.getDraaidatum());
    }
}
