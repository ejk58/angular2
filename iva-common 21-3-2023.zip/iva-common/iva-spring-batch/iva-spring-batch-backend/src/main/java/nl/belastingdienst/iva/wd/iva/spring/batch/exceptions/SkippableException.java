package nl.belastingdienst.iva.wd.iva.spring.batch.exceptions;

public class SkippableException extends RuntimeException {
    private static final long serialVersionUID = -7766374526048635293L;

    public SkippableException() {
        super();
    }

    public SkippableException(String message) {
        super(message);
    }

    public SkippableException(Throwable cause) {
        super(cause);
    }

    public SkippableException(String message, Throwable cause) {
        super(message, cause);
    }
}
