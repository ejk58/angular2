package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Data
public class ModelDAC6DTO {
    @JsonProperty(required = true)
    private LocalDateTime draaidatum;
    @Size(max = 8)
    private String modelversie;
}
