package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv;

import lombok.RequiredArgsConstructor;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingKey;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.MeldingKeyRepository;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.data.builder.RepositoryItemReaderBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.data.domain.Sort.Direction.ASC;

@Configuration
@RequiredArgsConstructor
public class GmvItemReaderCreator {

    @Bean("meldingKeyReader")
    public ItemReader<MeldingKey> createMeldingKeyReader(MeldingKeyRepository meldingRepository) {
        Map<String, Sort.Direction> sortMapping = new HashMap<>();
        sortMapping.put("disclosureId", ASC);
        sortMapping.put("draaiDatum", ASC);
        RepositoryItemReaderBuilder<MeldingKey> builder = new RepositoryItemReaderBuilder<>();
        return builder.name("MeldingKeyRepositoryReader").repository(meldingRepository).methodName("findAll")
                .pageSize(1000).sorts(sortMapping).build();
    }

    @Bean("meldingStatusReader")
    public ItemReader<MeldingStatus> createMeldingStatusReader(MeldingStatusRepository meldingStatusRepository) {
        Map<String, Sort.Direction> sortMapping = new HashMap<>();
        sortMapping.put("disclosureId", ASC);
        sortMapping.put("draaidatum", ASC);
        RepositoryItemReaderBuilder<MeldingStatus> builder = new RepositoryItemReaderBuilder<>();
        return builder.name("MeldingStatusRepositoryReader").repository(meldingStatusRepository).methodName("findAll")
                .pageSize(1000).sorts(sortMapping).build();
    }
}
