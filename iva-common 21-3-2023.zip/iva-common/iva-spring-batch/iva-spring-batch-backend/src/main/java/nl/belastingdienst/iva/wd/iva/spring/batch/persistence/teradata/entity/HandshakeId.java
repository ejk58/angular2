package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.sql.Timestamp;

@Getter
@Setter
@RequiredArgsConstructor
@EqualsAndHashCode
public class HandshakeId implements Serializable {
    private static final long serialVersionUID = -3738393544811610184L;

    Timestamp created;
    String product;
    String eventName;
}
