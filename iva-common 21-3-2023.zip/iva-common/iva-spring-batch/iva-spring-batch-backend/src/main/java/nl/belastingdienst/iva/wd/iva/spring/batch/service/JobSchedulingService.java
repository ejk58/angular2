package nl.belastingdienst.iva.wd.iva.spring.batch.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.JobResultStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.OppositeSideIsProcessingException;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.UNSPECIFIED;

@Configuration
@EnableScheduling
@RequiredArgsConstructor
@Log4j2
@ConditionalOnProperty("iva.spring.batch.scheduling.gmv.enabled")
public class JobSchedulingService {

    private final GmvJobService gmvJobService;

    @Scheduled(cron = "${iva.spring.batch.scheduling.gmv.gmvload}")
    public void gmvLoadScheduledJob() {
        JobResultStatus jobResultStatus;
        try {
            jobResultStatus = gmvJobService.loadGMV();

        } catch (OppositeSideIsProcessingException ex) {
            log.info(ex.getMessage());
            return;
        } catch (JobExecutionException ex) {
            log.error("Scheduled job failed exceptionally. Exception message: {}", ex::getMessage);
            return;
        }
        if (jobResultStatus.getNumberOfFailures() == 0) {
            log.info("Scheduled job ran successfully.");
        } else {
            log.error("Scheduled job did not pass dry run");
        }
    }

}
