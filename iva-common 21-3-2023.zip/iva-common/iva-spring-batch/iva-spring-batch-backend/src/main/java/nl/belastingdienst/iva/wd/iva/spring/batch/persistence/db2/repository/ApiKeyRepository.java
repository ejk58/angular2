package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.ApiKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Transactional
public interface ApiKeyRepository extends JpaRepository<ApiKey, Integer> {

    Optional<ApiKey> findApiKeyByKey(String key);

}
