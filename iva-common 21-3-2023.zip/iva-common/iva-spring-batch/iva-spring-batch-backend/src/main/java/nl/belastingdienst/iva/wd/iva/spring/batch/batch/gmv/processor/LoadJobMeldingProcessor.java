/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: LoadJobMeldingProcessor.java
 *             Auteur: veldb13
 *    Creatietijdstip: 16-2-2023 14:30
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.processor;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mapper.MeldingDAC6Mapper;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingId;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingKey;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.MeldingRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import nl.belastingdienst.iva.wd.iva.spring.batch.validator.MeldingValidator;

import lombok.NonNull;
import lombok.extern.log4j.Log4j2;

@Component("loadJobMeldingProcessor")
@Log4j2
public class LoadJobMeldingProcessor extends AbstractMeldingProcessor<MeldingStatus> {
	public LoadJobMeldingProcessor(MeldingStatusRepository meldingStatusRepository, MeldingDAC6Mapper meldingDAC6Mapper,
			MeldingValidator meldingValidator, GmvService gmvService, MeldingRepository meldingRepository) {
		super(meldingStatusRepository, meldingDAC6Mapper, meldingValidator, gmvService, meldingRepository);
	}

	@Override
	public WriteObject process(@NonNull MeldingStatus meldingStatus) {
		MeldingId meldingId = new MeldingId();
		meldingId.setDisclosureId(meldingStatus.getDisclosureId());
		meldingId.setDraaiDatum(meldingStatus.getDraaidatum());

		if (meldingStatus.getGmvId() != null) {
			logSaveMessageAndSkip(meldingStatus, "Overgeslagen. Deze melding is al verwerkt in GMV", null);
		}
		skipIfAlreadyInGMV(meldingId, meldingStatus);

		String json = meldingStatus.getMessage();
		MeldingDAC6NewUpdateDTO meldingDAC6NewUpdateDTO = convertJsonToMeldingDAC6NewUpdateDTO(json);

		return getWriteObject(meldingStatus, meldingDAC6NewUpdateDTO);
	}

	private MeldingDAC6NewUpdateDTO convertJsonToMeldingDAC6NewUpdateDTO(String json) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		try {
			return mapper.readValue(json, MeldingDAC6NewUpdateDTO.class);
		} catch (IllegalArgumentException | JsonProcessingException e) {
			logAndSkip("Melding heeft geen json");
		}
		return null;
	}

	protected WriteObject getWriteObject(MeldingStatus meldingStatus, MeldingDAC6NewUpdateDTO meldingDAC6NewUpdateDTO) {
		meldingStatus.setInError(Boolean.FALSE);
		meldingStatus.setValidationErrors(null);
		meldingStatus.setExecutionMessage(null);
		return new WriteObject(meldingStatus, meldingDAC6NewUpdateDTO);
	}
}
