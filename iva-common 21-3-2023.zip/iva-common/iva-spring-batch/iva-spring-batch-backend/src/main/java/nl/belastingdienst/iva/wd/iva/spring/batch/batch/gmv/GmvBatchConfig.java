package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv;

import java.util.HashMap;
import java.util.Map;

import lombok.RequiredArgsConstructor;

import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.listener.GmvBatchJobCacheListener;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.listener.GmvBatchJobHandshakeListener;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.listener.GmvLoadStepExecutionListener;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippableException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingKey;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.skip.AlwaysSkipItemSkipPolicy;
import org.springframework.batch.core.step.skip.ExceptionClassifierSkipPolicy;
import org.springframework.batch.core.step.skip.LimitCheckingItemSkipPolicy;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class GmvBatchConfig {

    public static final String IVA_SPRING_BATCH_GMV = "LOAD-MDR-GMV";
    public static final String IVA_SPRING_BATCH_GMV_CHECK = "CHECK-MDR-GMV-INPUT";
    public static final String USER_ID = "userId";
    public static final String EVENT_VALUE = "eventValue";
    public static final String UNSPECIFIED = "UNSPECIFIED";

    private final GmvBatchJobHandshakeListener gmvBatchJobHandshakeListener;
    private final GmvBatchJobCacheListener gmvBatchJobCacheListener;
    private final GmvLoadStepExecutionListener gmvLoadStepExecutionListener;

    @Bean
    PlatformTransactionManager chainTxManager(
            @Qualifier("teradataTransactionManager") PlatformTransactionManager teradataTransactionManager,
            @Qualifier("db2TransactionManager") PlatformTransactionManager db2TransactionManager) {
        return new ChainedTransactionManager(teradataTransactionManager,db2TransactionManager);
    }

    @Bean("loadGmv")
    @Primary
    public Job loadGmv(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory,
                       @Qualifier("meldingKeyReader") ItemReader<MeldingKey> meldingKeyReader,
                       @Qualifier("meldingStatusReader") ItemReader<MeldingStatus> meldingStatusReader,
                       @Qualifier("checkJobMeldingProcessor") ItemProcessor<MeldingKey, WriteObject> checkJobItemProcessor,
                       @Qualifier("loadJobMeldingProcessor") ItemProcessor<MeldingStatus, WriteObject> loadJobItemProcessor,
                       @Qualifier("dummy") ItemWriter<WriteObject> checkJobItemWriter,
                       ItemWriter<WriteObject> itemWriter,
                       @Qualifier("chainTxManager") PlatformTransactionManager chainTxManager,
                       SkipPolicy skipPolicy) {
        Step checkJobStep = stepBuilderFactory.get(IVA_SPRING_BATCH_GMV_CHECK).<MeldingKey, WriteObject>chunk(1).reader(meldingKeyReader)
                .processor(checkJobItemProcessor).writer(checkJobItemWriter).faultTolerant().skipPolicy(skipPolicy)
                .noRollback(SkippableException.class).noRollback(CommonException.class)
                .transactionManager(chainTxManager).build();
        Step loadJobStep = stepBuilderFactory.get(IVA_SPRING_BATCH_GMV).<MeldingStatus, WriteObject>chunk(1).reader(meldingStatusReader)
                .processor(loadJobItemProcessor).writer(itemWriter).faultTolerant().skipPolicy(skipPolicy)
                .noRollback(SkippableException.class).noRollback(CommonException.class)
                .transactionManager(chainTxManager).listener(gmvLoadStepExecutionListener).build();
        return jobBuilderFactory.get(IVA_SPRING_BATCH_GMV).incrementer(new RunIdIncrementer())
                .listener(gmvBatchJobHandshakeListener).listener(gmvBatchJobCacheListener)
                .start(checkJobStep).next(loadJobStep).build();
    }

    @Bean
    public SkipPolicy getSkipPolicy(@Value("${iva.spring.batch.jobconfiguration.max-skip-commonexception}") int maxSkipCount) {
        SkipPolicy commonExceptionSkipPolicy = new LimitCheckingItemSkipPolicy(maxSkipCount, Map.of(CommonException.class, true));
        Map<Class<? extends Throwable>, SkipPolicy> policyMap = new HashMap<>();
        policyMap.put(CommonException.class, commonExceptionSkipPolicy);
        policyMap.put(SkippableException.class, new AlwaysSkipItemSkipPolicy());
        ExceptionClassifierSkipPolicy skipPolicy = new ExceptionClassifierSkipPolicy();
        skipPolicy.setPolicyMap(policyMap);
        return skipPolicy;
    }
}
