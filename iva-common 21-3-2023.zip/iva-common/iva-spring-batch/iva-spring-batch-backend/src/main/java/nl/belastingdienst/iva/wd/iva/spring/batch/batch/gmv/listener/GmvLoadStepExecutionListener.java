/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GmvStepExecutionListener.java
 *             Auteur: veldb13
 *    Creatietijdstip: 8-3-2023 09:22
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.listener;

import java.util.List;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class GmvLoadStepExecutionListener implements StepExecutionListener {
	private final MeldingStatusRepository meldingStatusRepository;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		List<MeldingStatus> failures = this.meldingStatusRepository.findMeldingStatusByInErrorIsTrueAndJobId(
				stepExecution.getJobExecutionId());
		if (failures.isEmpty()) {
			return;
		}
		stepExecution.setTerminateOnly();
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}
}
