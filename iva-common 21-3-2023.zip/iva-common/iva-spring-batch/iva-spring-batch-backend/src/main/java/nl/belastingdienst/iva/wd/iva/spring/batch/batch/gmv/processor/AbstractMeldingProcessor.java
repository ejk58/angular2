/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: Processor.java
 *             Auteur: denee00
 *    Creatietijdstip: 21-12-2020 09:14
 *          Copyright: (c) 2020 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.processor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;

import nl.belastingdienst.iva.common.springboot.exceptions.ApiValidationError;
import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mapper.MeldingDAC6Mapper;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippedInProcessorException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Melding;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingId;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingKey;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.MeldingRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import nl.belastingdienst.iva.wd.iva.spring.batch.validator.MeldingValidator;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
public abstract class AbstractMeldingProcessor<T> implements ItemProcessor<T, WriteObject> {

    protected final MeldingStatusRepository meldingStatusRepository;

    protected final MeldingDAC6Mapper meldingDAC6Mapper;

    protected final MeldingValidator meldingValidator;

    protected final GmvService gmvService;

    protected final MeldingRepository meldingRepository;

    protected long jobId;

    protected String jobName;

    @BeforeStep
    public void beforeStep(final StepExecution stepExecution) {
        jobId = stepExecution.getJobExecutionId();
        jobName = stepExecution.getJobExecution().getJobInstance().getJobName();
    }

    @Override
    public abstract WriteObject process(@NonNull T item);

    protected static MeldingId getMeldingId(MeldingKey meldingKey) {
        MeldingId meldingId = new MeldingId();
        meldingId.setDisclosureId(meldingKey.getDisclosureId());
        meldingId.setDraaiDatum(meldingKey.getDraaiDatum());
        log.info("process :" + meldingId);
        return meldingId;
    }

    protected WriteObject getWriteObject(MeldingStatus meldingStatus, Melding melding) {
        meldingStatus.setInError(Boolean.FALSE);
        meldingStatus.setValidationErrors(null);
        meldingStatus.setExecutionMessage(null);
        return new WriteObject(meldingStatus, meldingDAC6Mapper.map(melding));
    }

    protected void handleValidationResult(MeldingStatus meldingStatus, Melding melding, List<ApiValidationError> apiValidationErrors) {
        if (!apiValidationErrors.isEmpty()) {
            handleValidationErrors(apiValidationErrors, meldingStatus);
            meldingStatus.setModified(LocalDateTime.now());
            meldingStatusRepository.save(meldingStatus);
            logAndSkipWithCommonException(String.format("Melding disclosureId %s draaidatum %s niet versturen vanwege validatiefouten %s",
                    melding.getDisclosureId(), melding.getDraaiDatum(), meldingStatus.getValidationErrors()));
        }
    }

    protected Melding getMeldingOrSkipIfAlreadyInGMV(MeldingId meldingId, MeldingStatus meldingStatus) {
        skipIfAlreadyInGMV(meldingId, meldingStatus);
        Melding melding = getMelding(meldingId);
        return melding;
    }

    protected void skipIfAlreadyInGMV(MeldingId meldingId, MeldingStatus meldingStatus) {
        //check of al voorkomt in GMV (status in batch mogelijk niet juist bijgewerkt)
        String gmvId = gmvService.getGmvId(meldingId.getDisclosureId(), meldingId.getDraaiDatum());
        if (gmvId != null) {
            logSaveMessageAndSkip(meldingStatus, "Overgeslagen. Deze melding is al verwerkt in GMV (JobId was onbekend in laadapplicatie)", gmvId);
        }
    }

    protected Melding getMelding(MeldingId meldingId) {
        Optional<Melding> optionalMelding = meldingRepository.findById(meldingId);
        if (optionalMelding.isPresent()) {
            return optionalMelding.get();
        } else {
            log.error("Melding niet gevonden :" + meldingId);
            throw new CommonException("Melding niet gevonden :" + meldingId);
        }
    }

    protected void logSaveMessageAndSkip(MeldingStatus meldingStatus, String skipMessage, String gmvId) {
        meldingStatus.setModified(LocalDateTime.now());
        meldingStatus.setInError(Boolean.FALSE);
        meldingStatus.setValidationErrors(null);
        meldingStatus.setExecutionMessage(skipMessage);
        meldingStatus.setJobId(this.jobId);
        if (gmvId != null) {
            meldingStatus.setGmvId(gmvId);
        }
        this.meldingStatusRepository.save(meldingStatus);
        logAndSkip(skipMessage);
    }

    protected MeldingStatus getMeldingStatus(MeldingId meldingId) {
        final String disclosureId = meldingId.getDisclosureId();
        final LocalDateTime draaidatum = meldingId.getDraaiDatum();
        MeldingStatus meldingStatus = meldingStatusRepository
                .findMeldingStatusByDisclosureIdAndDraaidatum(disclosureId, draaidatum)
                .map(this::handleExistingMeldingStatus)
                .orElseGet(() -> this.handleNewMeldingStatus(disclosureId, draaidatum));
        meldingStatus.setJobId(this.jobId);
        return meldingStatus;
    }

    protected MeldingStatus handleExistingMeldingStatus(MeldingStatus meldingStatus) {
        return meldingStatus;
    }

    protected MeldingStatus handleNewMeldingStatus(String disclosureId, LocalDateTime draaidatum) {
        MeldingStatus meldingStatus = new MeldingStatus();
        meldingStatus.setDisclosureId(disclosureId);
        meldingStatus.setDraaidatum(draaidatum);
        meldingStatus.setJobId(this.jobId);
        return meldingStatus;
    }

    protected void handleValidationErrors(List<ApiValidationError> validationErrors, MeldingStatus meldingStatus) {
        List<String> errors = new ArrayList<>();
        validationErrors.forEach(apiValidationError -> errors.add(String
                .format("field %s, value %s, %s", apiValidationError.getField(), apiValidationError.getRejectedValue(),
                        apiValidationError.getMessage())));
        meldingStatus.setValidationErrors(String.join(";", errors));
        log.info("Validation failed for melding, disclosureId: {}, draaidatum: {}, validationErrrors {}",
                meldingStatus.getDisclosureId(), meldingStatus.getDraaidatum(), meldingStatus.getValidationErrors());
        meldingStatus.setInError(true);
    }

    protected void logAndSkipWithCommonException(String logMessage) {
        log.error(logMessage);
        throw new CommonException(logMessage);
    }

    protected void logAndSkip(String logMessage) {
        log.info(logMessage);
        throw new SkippedInProcessorException(logMessage);
    }
}
