package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto;

import lombok.Data;

@Data
public class VerantwoordingsinfoDAC6DTO {

    private String risicoInfoNaam;

    private String risicoInfoWaarde;
}
