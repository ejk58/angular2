package nl.belastingdienst.iva.wd.iva.spring.batch.exceptions;

import lombok.Data;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestClientResponseException;

@Data
public class SkippedInWriterException extends SkippableException {

    private static final long SERIAL_VERSION_UID = 328064987148210885L;
    private static final String DEFAULT_MESSAGE = "An exception occurred during the write phase of a batch job";
    private HttpStatus httpStatus;

    public SkippedInWriterException(String message) {
        super(message);
    }

    public SkippedInWriterException(String message, Throwable cause) {
        super(message, cause);
    }

    public SkippedInWriterException(String message, Throwable cause, HttpStatus status) {
        super(message, cause);
        this.httpStatus = status;
    }
}
