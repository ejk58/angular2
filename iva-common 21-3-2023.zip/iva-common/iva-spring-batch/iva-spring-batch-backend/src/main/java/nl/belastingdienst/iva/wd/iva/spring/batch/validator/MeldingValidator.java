/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: BehandelVoornemenValidator.java
 *             Auteur: denee00
 *    Creatietijdstip: 15-2-2021 09:24
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch.validator;

import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.common.springboot.exceptions.ApiValidationError;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.HallmarkDAC6;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.Rol;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Melding;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Stream;

@Component
@RequiredArgsConstructor
public class MeldingValidator {

	private final GmvService gmvService;

	public static final String EMPTY_VALUE_NOT_ALLOWED = "empty value not allowed";


	public List<ApiValidationError> validate(Melding melding) {
		//valideer op id gegevens
		List<ApiValidationError> result = new ArrayList<>();
		if (melding.getDisclosureId() == null)
			result.add(new ApiValidationError("disclosureId", null, EMPTY_VALUE_NOT_ALLOWED));
		if (melding.getDraaiDatum() == null)
			result.add(new ApiValidationError("draaidatum", null, EMPTY_VALUE_NOT_ALLOWED));

		//valideer hallmark
		List<HallmarkDAC6> hallmarkDAC6List = this.gmvService.getHallmarks();

		melding.getHallmarkRisicos().forEach(hallmarkRisico -> {

			//HALLMARK
			Optional<HallmarkDAC6> optionalHallmarkDAC6 =  hallmarkDAC6List.stream()
					.filter(hallmarkDAC6 -> hallmarkDAC6.getCode().equals(hallmarkRisico.getHallmark())).findAny();
			if (!optionalHallmarkDAC6.isPresent()) {
				result.add(new ApiValidationError("hallmark", hallmarkRisico.getHallmark(), "onbekende hallmark"));
			} else if (optionalHallmarkDAC6.get().getHoofdhallmark() != null) {
				result.add(new ApiValidationError("hallmark", hallmarkRisico.getHallmark(), "is geen hallmark, maar een subhallmark"));
			}

			//SUBHALLMARKS
			List<String> subHallmarks = hallmarkRisico.getSubHallmarks() == null ?
					Collections.emptyList() : Arrays.asList(hallmarkRisico.getSubHallmarks().split(","));
			subHallmarks.forEach(subHallmark -> {
				Optional<HallmarkDAC6> optionalSubHallmark =  hallmarkDAC6List.stream().filter(hallmarkDAC6 -> hallmarkDAC6.getCode().equals(subHallmark.trim())).findFirst();
				if (!optionalSubHallmark.isPresent()) {
					result.add(new ApiValidationError("subhallmark", subHallmark, "onbekende subhallmark"));
				}
			});
		});

		//valideer rol
		melding.getSubjecten().forEach(subject -> {
			if (Stream.of(Rol.values())
					.noneMatch(rolEnum -> rolEnum.getDescription().equalsIgnoreCase(subject.getRol().replaceAll("\\s", "")))) {
				result.add(new ApiValidationError("rol", subject.getRol(), "onbekende rol"));
			}
		});
		return  result;
	}
}
