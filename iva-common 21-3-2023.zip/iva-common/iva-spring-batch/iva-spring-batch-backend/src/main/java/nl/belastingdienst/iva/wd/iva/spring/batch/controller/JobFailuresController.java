package nl.belastingdienst.iva.wd.iva.spring.batch.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvJobService;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_APIKEY;

@RestController
@RequestMapping("/api/external")
@Slf4j
@Configuration
@RequiredArgsConstructor
public class JobFailuresController {

    public static final String GMV = "GMV";
    private final GmvJobService gmvJobService;

    @Operation(
            description = "Opvragen fouten alle jobs",
            responses = {
                    @ApiResponse(
                            description = "BatchStatus", responseCode = "200",
                            content = @Content(
                                    mediaType = MediaType.TEXT_PLAIN_VALUE,
                                    schema = @Schema(
                                            implementation = String.class)))
            },
            parameters = {
                    @Parameter(name = HEADER_APIKEY,
                            description = "Api Key",
                            required = true,
                            in = ParameterIn.HEADER,
                            schema = @Schema(
                                    type = "string",
                                    example = "AAA"))
            },
            tags = GMV
    )
    @GetMapping("/getAllFailures")
    public String getFailures() {
        return this.gmvJobService.getAllFailuresEver();
    }

    @Operation(
            description = "Opvragen fouten van één job",
            responses = {
                    @ApiResponse(
                            description = "BatchStatus", responseCode = "200",
                            content = @Content(
                                    mediaType = MediaType.TEXT_PLAIN_VALUE,
                                    schema = @Schema(
                                            implementation = String.class)))
            },
            parameters = {
                    @Parameter(name = HEADER_APIKEY,
                            description = "Api Key",
                            required = true,
                            in = ParameterIn.HEADER,
                            schema = @Schema(
                                    type = "string",
                                    example = "AAA")),
                    @Parameter(name = "jobId",
                            description = "JobId",
                            required = true,
                            in = ParameterIn.PATH,
                            schema = @Schema(
                                    type = "integer",
                                    example = "123"))
            },
            tags = GMV
    )
    @GetMapping("/getFailures/{jobId}")
    public String getFailures(@PathVariable Long jobId) {
        if(jobId == null) return this.gmvJobService.getAllFailuresEver();
        return this.gmvJobService.getFailuresForJobId(jobId);
    }

    @Operation(
            description = "Opvragen fouten van meest recente job",
            responses = {
                    @ApiResponse(
                            description = "BatchStatus", responseCode = "200",
                            content = @Content(
                                    mediaType = MediaType.TEXT_PLAIN_VALUE,
                                    schema = @Schema(
                                            implementation = String.class)))
            },
            parameters = {
                    @Parameter(name = HEADER_APIKEY,
                            description = "Api Key",
                            required = true,
                            in = ParameterIn.HEADER,
                            schema = @Schema(
                                    type = "string",
                                    example = "AAA"))
            },
            tags = GMV
    )
    @GetMapping("/getFailuresMostRecentJob")
    public String getFailuresOfMostRecentJob() {
        return this.gmvJobService.getMostRecentFailures();
    }
}
