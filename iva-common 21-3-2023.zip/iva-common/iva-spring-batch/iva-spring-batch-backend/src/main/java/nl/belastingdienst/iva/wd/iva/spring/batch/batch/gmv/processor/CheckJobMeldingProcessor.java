/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: CheckJobMeldingProcessor.java
 *             Auteur: veldb13
 *    Creatietijdstip: 16-2-2023 14:03
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.processor;

import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import nl.belastingdienst.iva.common.springboot.exceptions.ApiValidationError;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mapper.MeldingDAC6Mapper;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Melding;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingId;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingKey;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.MeldingRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import nl.belastingdienst.iva.wd.iva.spring.batch.validator.MeldingValidator;

import lombok.NonNull;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Primary
@Component("checkJobMeldingProcessor")
public class CheckJobMeldingProcessor extends AbstractMeldingProcessor<MeldingKey> {

	public CheckJobMeldingProcessor(MeldingStatusRepository meldingStatusRepository,
			MeldingDAC6Mapper meldingDAC6Mapper, MeldingValidator meldingValidator, GmvService gmvService,
			MeldingRepository meldingRepository) {
		super(meldingStatusRepository, meldingDAC6Mapper, meldingValidator, gmvService, meldingRepository);
	}

	@Override
	public WriteObject process(@NonNull MeldingKey meldingKey) {
		MeldingId meldingId = getMeldingId(meldingKey);
		MeldingStatus meldingStatus = getMeldingStatus(meldingId);

		if (meldingStatus.getGmvId() != null) {
			logSaveMessageAndSkip(meldingStatus, "Overgeslagen. Deze melding is al verwerkt in GMV", null);
		} else if (meldingStatus.getId() != null && Boolean.FALSE.equals(meldingStatus.getInError())) {
				//is al eerder gecheckt meldingStatus heeft id en is niet in fout, dus skip
				logAndSkip("Overgeslagen vanwege eerdere succesvolle check");
		}

		Melding melding = getMeldingOrSkipIfAlreadyInGMV(meldingId, meldingStatus);

		List<ApiValidationError> apiValidationErrors = meldingValidator.validate(melding);
		handleValidationResult(meldingStatus, melding, apiValidationErrors);

		attachMeldingAsJsonToMeldingStatus(melding, meldingStatus);

		return getWriteObject(meldingStatus, melding);
	}

	private void attachMeldingAsJsonToMeldingStatus(Melding melding, MeldingStatus meldingStatus) {
		MeldingDAC6NewUpdateDTO newUpdateDTO = meldingDAC6Mapper.map(melding);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		String message;
		try {
			message = objectMapper.writeValueAsString(newUpdateDTO);
		} catch (JsonProcessingException e) {
			message = String.format("Mapping melding object with disclosureId %s and draaidatum %s has failed. Exception message: %s",
					melding.getDisclosureId(), melding.getDraaiDatum().toString(), e.getMessage());
			log.error(message);
		}
		meldingStatus.setMessage(message);
		meldingStatusRepository.save(meldingStatus);
	}
}
