package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@RequiredArgsConstructor
@EqualsAndHashCode
public class VerantwoordingsinfoId implements Serializable {
    private static final long serialVersionUID = 5775169801495154007L;

    private String disclosureId;
    private LocalDateTime draaiDatum;
    private String brReferentie;
    private String risicoInfoNaam;
    private String risicoInfoWaarde;
}
