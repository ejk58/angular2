package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@ToString
public class MeldingDAC6NewUpdateDTO {
	@JsonProperty(required = true)
	private String arrangementId;

	@JsonProperty(required = true)
	private String disclosureId;

	@JsonProperty(required = true)
	private Integer disclosureVolgnr;

	@JsonProperty(required = true)
	private Boolean meldingselectieInd;
	private String meldingselectieReden;
	private Long amountEur;
	private Integer overcapRang;
	private Integer overcapScore;
	private Integer overcapAantalHm;
	@JsonProperty(required = true)
	private String belastingMiddelen;

	private ModelDAC6DTO modelDAC6;

	@JsonProperty(required = true)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	private LocalDateTime disclosureTimestamp;

	@JsonProperty(required = true)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private LocalDate implementatieDatum;

	@JsonProperty(required = true)
	private String samenvatting;

	@JsonProperty(required = true)
	private List<PersoonNewDTO> personen;

	@JsonProperty(required = true)
	private List<PrioriteitDAC6NewUpdateDTO> prioriteiten;
}
