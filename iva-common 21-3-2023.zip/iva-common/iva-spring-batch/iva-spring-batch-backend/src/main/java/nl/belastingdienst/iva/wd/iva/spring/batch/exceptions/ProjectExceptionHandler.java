package nl.belastingdienst.iva.wd.iva.spring.batch.exceptions;

import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.exceptions.GenericExceptionHandler;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Log4j2
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class ProjectExceptionHandler extends GenericExceptionHandler {

    @ExceptionHandler(OppositeSideIsProcessingException.class)
    protected ResponseEntity<String> handleConflict(
            OppositeSideIsProcessingException ex) {
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(ex.getMessage());
    }
}
