package nl.belastingdienst.iva.wd.iva.spring.batch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.common.springboot.exceptions.GenericErrorType;
import nl.belastingdienst.iva.common.springboot.security.SecurityConstants;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.HallmarkDAC6;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippedInWriterException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

import static nl.belastingdienst.iva.wd.iva.spring.batch.config.RetryConfig.RETRY_3_TIMES_WITH_1_SECOND_BACKOFF;
import static org.springframework.http.HttpStatus.OK;

@Service
@Log4j2
public class GmvService {

	public final String gmvBaseurl;
	private final String gmvApikey;
	private final RestTemplate restTemplate;
	private final RetryTemplate retryTemplate;

	public GmvService(@Value("${iva.spring.batch.gmv.rest.baseurl}") String gmvBaseurl,
					  @Value("${iva.spring.batch.gmv.rest.apikey}") String gmvApikey, RestTemplate restTemplate,
			          @Qualifier("retry3TimesWith1SecondBackoff") RetryTemplate retryTemplate) {
		this.gmvBaseurl = gmvBaseurl;
		this.gmvApikey = gmvApikey;
		this.restTemplate = restTemplate;
		this.retryTemplate = retryTemplate;
	}

	@Cacheable(value = "getHallmarks")
	public List<HallmarkDAC6> getHallmarks() {
		try {
			return retry3Times(this::getHallmarkDAC6s, "Retried getHallmarks");
		} catch (RestClientResponseException e) {
			log.error("GMV geeft {} bij get hallmarks, {}", e.getRawStatusCode() , e.getMessage());
			throw new CommonException("Fout tijdens ophalen hallmarks :" + e.getMessage());
		}
	}

	private <T> T retry3Times(Supplier<T> supplier, String logMessage) {
		return retryTemplate.execute(context -> {
			if (context.getRetryCount() < RETRY_3_TIMES_WITH_1_SECOND_BACKOFF && context.getRetryCount() > 0)
				log.warn(logMessage);
			return supplier.get();
		});
	}

	private List<HallmarkDAC6> getHallmarkDAC6s() {
		ParameterizedTypeReference<List<HallmarkDAC6>> typeRef = new ParameterizedTypeReference<>() {
		};
		ResponseEntity<List<HallmarkDAC6>> responseEntity = restTemplate.exchange(
				gmvBaseurl + "/external/meldingDAC6/hallmarks", HttpMethod.GET,
				new HttpEntity<>(getStandardHttpHeaders()), typeRef);
		return responseEntity.getBody();
	}

	public String sendToGmv(final MeldingDAC6NewUpdateDTO melding) {
		try {
			return retry3Times(() -> postMeldingDAC6(melding), "Retried postMeldingDAC6");
		} catch (RestClientResponseException e) {
			String detailMessage = getDetailMessage(e);
			if((e.getRawStatusCode() == HttpStatus.CONFLICT.value()) && isNotPossibleGenericErrorType(e)) {
				throw new SkippedInWriterException(detailMessage, e);
			}
			if(e.getRawStatusCode() == HttpStatus.BAD_REQUEST.value()) {
				throw new SkippedInWriterException(detailMessage, e, HttpStatus.BAD_REQUEST);
			}
			throw new CommonException(String.format(
					"Fout opgetreden tijdens opvoeren melding met disclosureId %s, kreeg een onverwachte response van GMV met http statuscode: %d",
					melding.getDisclosureId(), e.getRawStatusCode()), e);
		}
	}

	private String postMeldingDAC6(MeldingDAC6NewUpdateDTO melding) {
		ResponseEntity<String> responseEntity = restTemplate.exchange(
				gmvBaseurl + "/external/meldingDAC6", HttpMethod.POST,
				new HttpEntity<>(melding, getStandardHttpHeaders()), String.class);
		String body = responseEntity.getBody();
		checkForNull(body);
		return body;
	}

	private boolean isNotPossibleGenericErrorType(RestClientResponseException e) {
		return isGenericErrorType(GenericErrorType.NOT_POSSIBLE, e);
	}

	private boolean isGenericErrorType(GenericErrorType genericErrorType, RestClientResponseException e) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(e.getResponseBodyAsString());
			String apiErrorType = getTextValueNullSafe(jsonNode, "type");
			String apiErrorTitle = getTextValueNullSafe(jsonNode, "title");
			return apiErrorType.equals(genericErrorType.getType())
					&& apiErrorTitle.equals(genericErrorType.getTitle());
		} catch (JsonProcessingException jsonProcessingException) {
			log.error("Er was een fout tijdens het deserializen van de response van GMV", jsonProcessingException);
			return false;
		}
	}

	private String getDetailMessage(RestClientResponseException e) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(e.getResponseBodyAsString());
			String result = jsonNode.get("detail") == null ? null : jsonNode.get("detail").textValue();
			if (result == null) {
				return jsonNode.asText();
			}
			return result;
		} catch (JsonProcessingException jsonProcessingException) {
			log.error("Er was een fout tijdens het deserializen van het veld 'detail' van de response van GMV", jsonProcessingException);
			return "Er was een fout tijdens het deserializen van het veld 'detail' van de response van GMV";
		}
	}

	private void checkForNull(String body) {
		if(body == null)
			throw new CommonException("Fout opgetreden tijdens opvoeren melding, geen id teruggekregen");
	}

	public String getGmvId(String disclosureId, LocalDateTime draaidatum) {
		try {
			return retry3Times(() -> getDisclosureId(disclosureId, draaidatum), "Retried getDisclosureId");
		} catch (RestClientResponseException e) {
			log.error("GMV geeft {} bij opvragen gmvId, {}", e.getRawStatusCode() , e.getMessage());
			throw new CommonException("Fout tijdens opvragen gmvId: " + e.getMessage());
		}
	}

	private String getDisclosureId(String disclosureId, LocalDateTime draaidatum) {
		String url = gmvBaseurl + "/external/meldingDAC6/disclosureId/" + disclosureId + "/draaidatum/" + draaidatum + "/id";
		ResponseEntity<String> responseEntity = restTemplate.exchange(
				url, HttpMethod.GET,
				new HttpEntity<>(getStandardHttpHeaders()), String.class);

		if (responseEntity.getStatusCode() != OK) {
			log.error("Fout opgetreden tijdens opvragen gmvId, statusCode {}",  responseEntity.getStatusCode());
			throw new CommonException("Fout opgetreden tijdens opvragen gmvId, statusCode {}" + responseEntity.getStatusCode());

		}
		return responseEntity.getBody();
	}

	protected HttpHeaders getStandardHttpHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);

		if (gmvApikey == null) {
			throw new CommonException("Geen apikey in de configuratie. Waarde is: " + gmvApikey);
		}
		headers.set(SecurityConstants.HEADER_APIKEY, gmvApikey);
		return headers;
	}

	private String getTextValueNullSafe(JsonNode jsonNode, String fieldName) {
		return jsonNode.get(fieldName) == null ? "null" : jsonNode.get(fieldName).textValue();
	}
}
