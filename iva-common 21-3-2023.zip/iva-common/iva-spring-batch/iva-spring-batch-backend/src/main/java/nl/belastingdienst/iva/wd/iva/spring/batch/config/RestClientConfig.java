package nl.belastingdienst.iva.wd.iva.spring.batch.config;

import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

import javax.net.ssl.SSLContext;

@Configuration
@Slf4j
public class RestClientConfig {

	private final char[] trustStorePassword;
	private final Resource trustStore;

	public RestClientConfig(@Value("${http.client.ssl.trust-store-password}") char[] trustStorePassword,
			@Value("${http.client.ssl.trust-store}") Resource trustStore) {
		this.trustStorePassword = trustStorePassword;
		this.trustStore = trustStore;
	}


	@Bean
	public ClientHttpRequestFactory httpRequestFactory() {
		return new HttpComponentsClientHttpRequestFactory(httpClient());
	}

	@Bean
	public CloseableHttpClient httpClient() {
		// Trust own CA and all child certs
		Registry<ConnectionSocketFactory> socketFactoryRegistry = null;
		try {
			SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(trustStore.getURL(), trustStorePassword).build();

			// Since only our own certs are trusted, hostname verification is probably safe to bypass
			SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, (hostname, session) -> true);

			socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory> create()
					.register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", sslSocketFactory).build();

		} catch (Exception e) {
			throw new CommonException("error creating bean httpClient ", e);
		}

		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
		return HttpClientBuilder.create().setConnectionManager(connectionManager).disableCookieManagement().disableAuthCaching()
				.build();
	}
}
