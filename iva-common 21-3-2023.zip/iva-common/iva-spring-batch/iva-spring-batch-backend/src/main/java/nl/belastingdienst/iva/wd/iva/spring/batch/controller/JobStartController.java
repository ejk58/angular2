package nl.belastingdienst.iva.wd.iva.spring.batch.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.JobResultStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvJobService;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_APIKEY;
import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.UNSPECIFIED;

@RestController
@RequestMapping("/api/external")
@Slf4j
@Configuration
@RequiredArgsConstructor
@ConditionalOnProperty("iva.spring.batch.controller.jobstart.enabled")
public class JobStartController {

    public static final String GMV = "GMV";
    private final GmvJobService gmvJobService;

    @Operation(
            description = "Laden GMV vanuit teradata",
            responses = {
                    @ApiResponse(
                            description = "BatchStatus", responseCode = "200",
                            content = @Content(
                                    mediaType = MediaType.TEXT_PLAIN_VALUE,
                                    schema = @Schema(
                                            implementation = String.class)))
            },
            parameters = {
                    @Parameter(name = HEADER_APIKEY,
                            description = "Api Key",
                            required = true,
                            in = ParameterIn.HEADER,
                            schema = @Schema(
                                    type = "string",
                                    example = "AAA"))
            },
            tags = GMV
    )
    @GetMapping("/loadGmv")
    public String loadGMV()
            throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException,
            JobInstanceAlreadyCompleteException {
        return this.gmvJobService.loadGMV().toString();
    }
}
