package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Table(name = "MELDING_STATUS")
public class MeldingStatus {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer id;
	@Column(name = "DISCLOSURE_ID")
	private String disclosureId;
	@Column(name = "DRAAIDATUM")
	private LocalDateTime draaidatum;
	@Column(name = "GMV_ID")
	private String gmvId;
	@Column(name = "IN_ERROR")
	private Boolean inError = false;
	@Column(name = "SKIPPED")
	private Boolean skipped = false;
	@Column(name = "VALIDATION_ERRORS")
	private String validationErrors;
	@Column(name = "EXECUTION_MESSAGE")
	private String executionMessage;
	@Column(name = "MODIFIED")
	private LocalDateTime modified;
	@Column(name = "CREATED")
	private LocalDateTime created;
	@Column(name = "JOB_ID")
	private Long jobId;
	@Column(name= "MESSAGE")
	private String message;

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
		MeldingStatus that = (MeldingStatus) o;
		return id != null && Objects.equals(id, that.id);
	}

	@Override
	public int hashCode() {
		return getClass().hashCode();
	}
}
