package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model;

import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.IVA_SPRING_BATCH_GMV;
import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.IVA_SPRING_BATCH_GMV_CHECK;

import lombok.*;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippableException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;

import java.util.List;
import java.util.Objects;

@Getter
@Setter
public class JobResultStatus {

    private long jobId;
    private String jobName;
    private String jobStatus;
    private long duration;
    private int readCount;
    private int skipped;
    private int written;
    private int numberOfFailures;
    private List<MeldingStatus> failures;

    @Builder
    private JobResultStatus(Job job, JobExecution jobExecution, List<MeldingStatus> failures, List<MeldingStatus> skipped, boolean isDryRun) {
        this.failures = failures;
        this.duration = (Objects.requireNonNull(jobExecution.getEndTime()).getTime() - Objects.requireNonNull(jobExecution.getStartTime()).getTime()) / 1000;
        this.jobId = jobExecution.getId();
        this.jobName = job.getName();
        this.jobStatus = jobExecution.getStatus().toString();
        this.numberOfFailures = failures.size();
        this.readCount = jobExecution.getStepExecutions().stream()
                .filter(stepExecution -> stepExecution.getStepName().equals(IVA_SPRING_BATCH_GMV_CHECK))
                .mapToInt(StepExecution::getReadCount).sum();
        this.skipped  = jobExecution.getStepExecutions().stream()
                .filter(stepExecution -> stepExecution.getStepName().equals(IVA_SPRING_BATCH_GMV_CHECK))
                .mapToInt(stepexecution -> stepexecution.getFilterCount() + stepexecution.getSkipCount()).sum()
                - this.numberOfFailures;
        this.written = jobExecution.getStepExecutions().stream()
                .filter(stepExecution -> stepExecution.getStepName().equals(IVA_SPRING_BATCH_GMV))
                .mapToInt(StepExecution::getWriteCount).sum();
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("IVA-SPRING-BATCH, Job: ").append(jobName).append(" finished in ").append(duration)
                .append(" seconds, jobId: ").append(jobId).append(", status ").append(jobStatus)
                .append(", read: ").append(readCount).append(", skipped: ").append(skipped)
                .append(", written: ").append(written).append(", failures: ").append(numberOfFailures);
        return stringBuilder.toString();
    }

    public String toStringExtendend() {
        StringBuilder stringBuilder = new StringBuilder(this.toString());
            if (!failures.isEmpty()) {
                stringBuilder.append("\nFouten tijdens verwerken meldingen:\n");
                stringBuilder.append("-------\n");
                failures.forEach(meldingStatus -> {
                    stringBuilder.append(String.format("%nFouten in melding disclosureID: %s, draaidatum: %s en jobId: %d%n",
                            meldingStatus.getDisclosureId(), meldingStatus.getDraaidatum(), meldingStatus.getJobId()));
                    if (meldingStatus.getExecutionMessage() != null) {
                        stringBuilder.append("error message : ").append(meldingStatus.getExecutionMessage()).append("\n");
                    }
                    if (meldingStatus.getValidationErrors() != null) {
                        stringBuilder.append("validatiefout(en) : ").append(meldingStatus.getValidationErrors()).append("\n");
                    }
                });
            }
            return stringBuilder.toString();
        }
}
