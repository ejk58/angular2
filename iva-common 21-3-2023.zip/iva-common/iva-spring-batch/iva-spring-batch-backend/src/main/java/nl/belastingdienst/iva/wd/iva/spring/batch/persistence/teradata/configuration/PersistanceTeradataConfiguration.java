package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.configuration;

import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.PersistenceTeradataNoOpMarker;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration(proxyBeanMethods = false)
@EnableJpaRepositories(
        basePackageClasses = PersistenceTeradataNoOpMarker.class,
        entityManagerFactoryRef = "teradataEntityManager",
        transactionManagerRef = "teradataTransactionManager"
)
@RequiredArgsConstructor
public class PersistanceTeradataConfiguration {

    private final TeradataPhysicalNamingStrategy teradataPhysicalNamingStrategy;

    @Bean("teradataDataSourceProperties")
    @ConfigurationProperties(prefix = "iva.spring.batch.datasource.teradata")
    public DataSourceProperties teradataDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean("teradataHikariDataSource")
    public HikariDataSource teradataHikariDataSource(@Qualifier("teradataDataSourceProperties") DataSourceProperties teradataDataSourceProperties) {
        teradataDataSourceProperties.setType(HikariDataSource.class);
        return ((HikariDataSource) teradataDataSourceProperties.initializeDataSourceBuilder().build());
    }

    @Bean("teradataEntityManager")
    @ConfigurationProperties("iva.spring.batch.datasource.teradata.entity-manager")
    public LocalContainerEntityManagerFactoryBean teradataEntityManager(@Qualifier("teradataHikariDataSource") HikariDataSource teradataHikariDataSource, Environment environment) {
        LocalContainerEntityManagerFactoryBean em
                = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(teradataHikariDataSource);
        em.setPackagesToScan(PersistenceTeradataNoOpMarker.class.getPackage().getName());
        HibernateJpaVendorAdapter vendorAdapter
                = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        em.getJpaPropertyMap().put("hibernate.physical_naming_strategy", teradataPhysicalNamingStrategy);
        em.getJpaPropertyMap().put("hibernate.show_sql", environment.getProperty("spring.jpa.properties.hibernate.show_sql"));
        return em;
    }

    @Bean("teradataTransactionManager")
    public PlatformTransactionManager teradataTransactionManager(@Qualifier("teradataEntityManager") LocalContainerEntityManagerFactoryBean entityManagerFactoryBean) {
        JpaTransactionManager transactionManager
                = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(
                entityManagerFactoryBean.getObject());
        return transactionManager;
    }
}
