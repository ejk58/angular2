package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@RequiredArgsConstructor
@EqualsAndHashCode
public class MeldingId implements Serializable {

    private static final long serialVersionUID = 4521812020053428595L;

    private String disclosureId;
    private LocalDateTime draaiDatum;

    @Override
    public String toString() {
        return "MeldingId{" +
                "disclosureId='" + disclosureId + '\'' +
                ", draaiDatum=" + draaiDatum +
                '}';
    }
}
