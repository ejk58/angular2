ALTER TABLE IVA_SPRING_BATCH_TEST.MELDING_STATUS ALTER COLUMN message TYPE VARCHAR(64000);

DELETE FROM IVA_SPRING_BATCH_TEST.MDR_handshake;
DELETE FROM IVA_SPRING_BATCH_TEST.handshake;
DELETE FROM IVA_SPRING_BATCH_TEST.MDR_out_verantwoordingsinfo;
DELETE FROM IVA_SPRING_BATCH_TEST.MDR_out_beslisregel;
DELETE FROM IVA_SPRING_BATCH_TEST.MDR_out_hallmarkRisico;
DELETE FROM IVA_SPRING_BATCH_TEST.MDR_out_subject;
DELETE FROM IVA_SPRING_BATCH_TEST.MDR_out_melding;
DELETE FROM IVA_SPRING_BATCH_TEST.MDR_out_model;

INSERT INTO IVA_SPRING_BATCH_TEST.MDR_out_model (modelversie, draaidatum) VALUES ('1.0.0', '2022-11-08 10:55:00.070000');
INSERT INTO IVA_SPRING_BATCH_TEST.MDR_out_melding (disclosureid, draaidatum, arrangementid, disclosure_timestamp, disclosure_volgnr, meldingselectie_ind, meldingselectie_reden, amount_eur, implementatiedatum, belastingmiddelen, samenvatting, overcap_rang, overcap_score, overcap_aantal_hm) VALUES ('NLD00000000000001', '2022-11-08 10:55:00.070000', 'NLA00000000000001', '2021-01-27 00:00:00.000000', 1, 1, 'model', 192897, '2015-12-28', 'VpB', 'testwaarde', 4, 4, 1);
INSERT INTO IVA_SPRING_BATCH_TEST.MDR_out_subject (disclosureid, draaidatum, subjectstelsel_cd, subjectstelsel_wrd, finr, rol, naam) VALUES ('NLD00000000000001', '2022-11-08 10:55:00.070000', '2', '100001', 1, 'RelevantTaxPayer', 'testwaarde');
INSERT INTO IVA_SPRING_BATCH_TEST.MDR_out_hallmarkRisico (disclosureid, draaidatum, hallmark, rang, score, hm_selectie_ind, hm_selectie_reden, subhallmarks) VALUES ('NLD00000000000001', '2022-11-08 10:55:00.070000', 'E1', 1, 3, 1, 'model', null);
INSERT INTO IVA_SPRING_BATCH_TEST.MDR_out_beslisregel (disclosureid, draaidatum, hallmark, br_referentie, br_score) VALUES ('NLD00000000000001', '2022-11-08 10:55:00.070000', 'E1', 'all.1', 0);
INSERT INTO IVA_SPRING_BATCH_TEST.MDR_out_verantwoordingsinfo (disclosureid, draaidatum, hallmark, br_referentie, risico_info_naam, risico_info_waarde) VALUES ('NLD00000000000001', '2022-11-08 10:55:00.070000', 'E1', 'all.1', 'klantsegment | (sub)hallmark | amount_eur | percent_rank', 'Onbekend | E1 | €192.897 | 100%');
INSERT INTO IVA_SPRING_BATCH_TEST.MDR_handshake (created, product, event_name, event_value) VALUES (TIMESTAMP '2022-10-07 07:00:00', 'MDR','RUN_START','Vx.xx.xx');
INSERT INTO IVA_SPRING_BATCH_TEST.MDR_handshake (created, product, event_name, event_value) VALUES (TIMESTAMP '2022-10-07 07:30:00', 'MDR','RUN_END',NULL);
