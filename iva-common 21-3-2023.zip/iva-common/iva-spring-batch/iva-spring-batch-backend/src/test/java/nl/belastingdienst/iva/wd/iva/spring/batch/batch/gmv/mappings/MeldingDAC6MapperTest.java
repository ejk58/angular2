package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mappings;

import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.*;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mapper.MeldingDAC6Mapper;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mapper.MeldingDAC6MapperImpl;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.Rol;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDateTime;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class) // JUnit 5
@ContextConfiguration(classes = {
        MeldingDAC6MapperImpl.class
})
class MeldingDAC6MapperTest {


    @Autowired
    private MeldingDAC6Mapper meldingDAC6Mapper;

    @Test
    void mapToMeldingDAC6NewUpdateDTOFromMeldingSubHallmarksNull() {
        LocalDateTime disclosureTimestamp = LocalDateTime.now();
        LocalDateTime draaidatum = LocalDateTime.of(2022, 1, 1, 10, 20);

        String disclosureId = "discId";

        Melding melding = createMelding(disclosureTimestamp, draaidatum, disclosureId, null);
        MeldingDAC6NewUpdateDTO meldingDAC6NewUpdateDTO = this.meldingDAC6Mapper.map(melding);
        PrioriteitDAC6NewUpdateDTO prioDTO = meldingDAC6NewUpdateDTO.getPrioriteiten().get(0);
        assertEquals(0, prioDTO.getSubhallmarks().size());
    }


        @Test
    void mapToMeldingDAC6NewUpdateDTOFromMelding() {
        LocalDateTime disclosureTimestamp = LocalDateTime.now();
        LocalDateTime draaidatum = LocalDateTime.of(2022, 1, 1, 10, 20);

        String disclosureId = "discId";

        Melding melding = createMelding(disclosureTimestamp, draaidatum, disclosureId, "S1, S2");

        //melding
        MeldingDAC6NewUpdateDTO meldingDAC6NewUpdateDTO = this.meldingDAC6Mapper.map(melding);
        assertEquals("discId", meldingDAC6NewUpdateDTO.getDisclosureId());
        assertEquals(disclosureTimestamp, meldingDAC6NewUpdateDTO.getDisclosureTimestamp());

        //model
        ModelDAC6DTO modelDAC6DTO = meldingDAC6NewUpdateDTO.getModelDAC6();
        assertEquals(draaidatum, modelDAC6DTO.getDraaidatum());
        assertEquals("versie", modelDAC6DTO.getModelversie());

        //persoon
        PersoonNewDTO persoonNewDTO = meldingDAC6NewUpdateDTO.getPersonen().get(0);
        assertEquals("naam", persoonNewDTO.getNaam());
        assertEquals(Rol.TAXPAYER, persoonNewDTO.getRol());
        assertEquals(11, persoonNewDTO.getBsnRsin());

        //prioriteiten
        PrioriteitDAC6NewUpdateDTO prioDTO = meldingDAC6NewUpdateDTO.getPrioriteiten().get(0);
        assertEquals("H1", prioDTO.getHallmark());
        assertEquals(10, prioDTO.getRang());
        assertEquals("hmSelectieReden", prioDTO.getHmSelectieReden());
        assertEquals(100, prioDTO.getScore());
        assertEquals(2, prioDTO.getSubhallmarks().size());
        assertEquals("S1", prioDTO.getSubhallmarks().get(0));
        assertEquals("S2", prioDTO.getSubhallmarks().get(1));

        //beslisregels
        BeslisregelDAC6DTO beslisregelDAC6DTO = prioDTO.getBeslisregels().get(0);
        assertEquals("brReferentie", beslisregelDAC6DTO.getBrReferentie());
        assertEquals(1000, beslisregelDAC6DTO.getScore());

        //verantwoordinginfo
        VerantwoordingsinfoDAC6DTO verantwoordingsinfoDAC6DTO = beslisregelDAC6DTO.getVerantwoordingsinfos().get(0);
        assertEquals("risicoInfoNaam", verantwoordingsinfoDAC6DTO.getRisicoInfoNaam());
        assertEquals("risicoInfoWaarde", verantwoordingsinfoDAC6DTO.getRisicoInfoWaarde());
    }

    private Melding createMelding(LocalDateTime disclosureTimestamp, LocalDateTime draaidatum, String disclosureId, String subHallmarks) {
        Melding melding = new Melding();
        //melding
        melding.setDisclosureId(disclosureId);
        melding.setDraaiDatum(draaidatum);
        melding.setArrangementId("arrId");
        melding.setDisclosureTimestamp(disclosureTimestamp);


        //subject
        Subject s1 = new Subject();
        s1.setDisclosureId(disclosureId);
        s1.setDraaiDatum(draaidatum);
        s1.setSubjectstelselCd("subjStelselCd");
        s1.setSubjectstelselWrd("subjStelselWrd");
        s1.setNaam("naam");
        s1.setRol("Relevant Taxpayer");
        s1.setFinr(11);
        melding.setSubjecten(new HashSet<>());
        melding.getSubjecten().add(s1);

        //model
        Model model = new Model();
        model.setDraaiDatum(draaidatum);
        model.setModelVersie("versie");
        melding.setModel(model);

        //hallmarkrisico
        HallmarkRisico hallmarkRisico = new HallmarkRisico();
        hallmarkRisico.setHallmark("H1");
        //hallmarkRisico.setHmSelectieInd();
        hallmarkRisico.setRang(10);
        hallmarkRisico.setHmSelectieReden("hmSelectieReden");
        hallmarkRisico.setScore(100);
        hallmarkRisico.setSubHallmarks(subHallmarks);
        melding.setHallmarkRisicos(new HashSet<>());
        melding.getHallmarkRisicos().add(hallmarkRisico);

        //beslisregels
        Beslisregel beslisregel = new Beslisregel();
        beslisregel.setScore(1000);
        beslisregel.setBrReferentie("brReferentie");
        hallmarkRisico.setBeslisregels(new HashSet<>());
        hallmarkRisico.getBeslisregels().add(beslisregel);

        //verantwoordinginfo
        Verantwoordingsinfo verantwoordingsinfo = new Verantwoordingsinfo();
        verantwoordingsinfo.setRisicoInfoNaam("risicoInfoNaam");
        verantwoordingsinfo.setRisicoInfoWaarde("risicoInfoWaarde");

        beslisregel.setVerantwoordingsinfos(new HashSet<>());
        beslisregel.getVerantwoordingsinfos().add(verantwoordingsinfo);

        return melding;
    }
}
