/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: DemoIntegrationTest.java
 *             Auteur: veldb13
 *    Creatietijdstip: 8-2-2023 11:34
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch;

import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.UNSPECIFIED;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.jdbc.SqlGroup;

import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.HallmarkDAC6;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.controller.JobStartController;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;

import lombok.extern.log4j.Log4j2;

@SqlGroup({
		@Sql(scripts = {"/mdr-testdata.sql"},
			config = @SqlConfig(dataSource = "teradataHikariDataSource", transactionManager = "teradataTransactionManager")),
		@Sql(scripts = {"/apikey-testdata.sql"},
			config = @SqlConfig(dataSource = "db2HikariDataSource", transactionManager = "db2TransactionManager"))
})
@Log4j2
@SpringBootTest
@ActiveProfiles({"ont", "unittest"})
class DemoIntegrationTest {
	@Autowired
	private JobStartController jobStartController;

	@MockBean
	private GmvService gmvService;

	@Test
	void test() throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException,
			JobRestartException {
		//Given
		HallmarkDAC6 hallmarkDAC6 = new HallmarkDAC6();
		hallmarkDAC6.setCode("E1");
		Mockito.when(gmvService.getHallmarks()).thenReturn(List.of(hallmarkDAC6));
		Mockito.when(gmvService.sendToGmv(any(MeldingDAC6NewUpdateDTO.class))).thenReturn("id");
		Mockito.when(gmvService.getGmvId(anyString(), any(LocalDateTime.class))).thenReturn(null);

		//When
		String response = jobStartController.loadGMV();

		assertThat(response, containsString("status COMPLETED, read: 1, skipped: 0, written: 1, failures: 0"));
	}
}
