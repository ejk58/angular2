/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GmvBatchJobHandshakeListenerTest.java
 *             Auteur: veldb13
 *    Creatietijdstip: 13-2-2023 15:39
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv;

import static java.util.Comparator.comparing;
import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.UNSPECIFIED;
import static nl.belastingdienst.iva.wd.iva.spring.batch.service.HandshakeService.MDR;
import static nl.belastingdienst.iva.wd.iva.spring.batch.service.HandshakeService.RUN_END;
import static nl.belastingdienst.iva.wd.iva.spring.batch.service.HandshakeService.RUN_START;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeGMV;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.HandshakeGmvRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvJobService;

import lombok.extern.log4j.Log4j2;

@SqlGroup({
		@Sql(scripts = {"/mdr-testdata.sql"},
				config = @SqlConfig(dataSource = "teradataHikariDataSource", transactionManager = "teradataTransactionManager")),
		@Sql(scripts = {"/apikey-testdata.sql"},
				config = @SqlConfig(dataSource = "db2HikariDataSource", transactionManager = "db2TransactionManager"))
})
@Log4j2
@SpringBootTest
@ActiveProfiles({"ont", "unittest"})
class GmvBatchJobHandshakeListenerTest {
	@Autowired
	private GmvJobService gmvJobService;

	@Autowired
	private HandshakeGmvRepository handshakeGmvRepository;

	@MockBean
	private RestTemplate restTemplate;

	@Test
	void afterJobTest()
			throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException,
			JobRestartException {
		//Given
		Mockito.when(restTemplate.exchange(anyString(), any(HttpMethod.class),
						any(HttpEntity.class), any(ParameterizedTypeReference.class)))
				.thenThrow(RestClientResponseException.class)
				.thenThrow(RestClientResponseException.class)
				.thenThrow(RestClientResponseException.class);

		//When
		gmvJobService.loadGMV();

		//Then
		Optional<HandshakeGMV> lastHandshakeGMV = handshakeGmvRepository.findAll().stream().filter(handshakeGMV -> handshakeGMV.getProduct().equals(MDR))
				.filter(handshakeGMV -> handshakeGMV.getEventName().equals(RUN_END) || handshakeGMV.getEventName()
						.equals(RUN_START)).max(comparing(HandshakeGMV::getCreated));
		assertThat(lastHandshakeGMV, is(notNullValue()));
		assertThat(lastHandshakeGMV.get().getEventName(), is(RUN_START));
	}
}
