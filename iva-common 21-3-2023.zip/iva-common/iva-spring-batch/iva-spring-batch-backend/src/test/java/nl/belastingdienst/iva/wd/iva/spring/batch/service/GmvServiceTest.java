package nl.belastingdienst.iva.wd.iva.spring.batch.service;

import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.HallmarkDAC6;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.config.RetryConfig;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.MeldingAlreadyExists;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.MeldingNotNewOrSelectedException;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippableException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class GmvServiceTest {

    private GmvService gmvService;
    private RetryTemplate retryTemplate;

    @Mock
    RestTemplate restTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        String gmvBaseurl = "url";
        String gmvApikey = "apikey";
        retryTemplate = new RetryConfig().retry3TimesWith1SecondBackoff();
        gmvService = new GmvService(gmvBaseurl, gmvApikey, restTemplate, retryTemplate);
    }

    @Test
    void whenSendToGmvReturnsOk() throws MeldingAlreadyExists, MeldingNotNewOrSelectedException {
        //GIVEN
        String uuid = "uuid";

        MeldingDAC6NewUpdateDTO melding = new MeldingDAC6NewUpdateDTO();

        when(restTemplate.exchange(anyString(),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(Class.class))).thenReturn(new ResponseEntity<>(uuid, HttpStatus.OK));

        //WHEN, THEN
        assertEquals(uuid, this.gmvService.sendToGmv(melding));
    }

    @Test
    @Disabled
    void whenSendToGmvReturnsConflict() throws MeldingAlreadyExists, MeldingNotNewOrSelectedException {
        //GIVEN
        String mockDisclosureId = "mockDisclosureId";
        MeldingDAC6NewUpdateDTO melding = new MeldingDAC6NewUpdateDTO();
        melding.setDisclosureId(mockDisclosureId);
        //TODO fix me
        //This message and status should reflect a real ApiError with proper properties. Will not work as is. Remove
        // disabled when fixed
        RestClientResponseException responseException =
                new RestClientResponseException("message", HttpStatus.CONFLICT.value(), "status", null, null, null);

        when(restTemplate.exchange(anyString(),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(Class.class))).thenThrow(responseException);

        //WHEN, THEN
        Exception caughtException = null;
        try {
            this.gmvService.sendToGmv(melding);
        } catch (Exception exception) {
            caughtException = exception;
        }
        assertTrue(caughtException instanceof SkippableException);
        assertTrue(caughtException.getMessage().contains(mockDisclosureId));
    }

    @Test
    @Disabled
    void whenSendToGmvReturnsOtherThanConflict() throws MeldingAlreadyExists, MeldingNotNewOrSelectedException {
        //GIVEN
        String mockDisclosureId = "mockDisclosureId";
        MeldingDAC6NewUpdateDTO melding = new MeldingDAC6NewUpdateDTO();
        melding.setDisclosureId(mockDisclosureId);
        //TODO fix me
        //This message and status should reflect a real ApiError with proper properties. Will not work as is. Remove
        // disabled when fixed
        RestClientResponseException responseException =
                new RestClientResponseException("message", HttpStatus.BAD_REQUEST.value(), "status", null, null, null);

        when(restTemplate.exchange(anyString(),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(Class.class))).thenThrow(responseException);

        //WHEN, THEN
        Exception caughtException = null;
        try {
            this.gmvService.sendToGmv(melding);
        } catch (Exception exception) {
            caughtException = exception;
        }
        assertTrue(caughtException instanceof CommonException);
        assertTrue(caughtException.getMessage().contains(String.valueOf(HttpStatus.BAD_REQUEST.value())));
        assertTrue(caughtException.getMessage().contains(mockDisclosureId));
    }

    @Test
    void getHallmarks() {
        //GIVEN
        List<HallmarkDAC6> hallmarkDAC6List = new ArrayList<>();
        HallmarkDAC6 hallmarkDAC6 = new HallmarkDAC6();
        hallmarkDAC6.setCode("H1");
        hallmarkDAC6List.add(hallmarkDAC6);


        when(restTemplate.exchange(anyString(),
                any(HttpMethod.class),
                (HttpEntity<?>) any(HttpEntity.class),
                (ParameterizedTypeReference<Object>) any())).thenReturn(new ResponseEntity<>(hallmarkDAC6List, HttpStatus.OK));

        //WHEN, THEN
        assertEquals("H1", this.gmvService.getHallmarks().get(0).getCode());
    }


}
