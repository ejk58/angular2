package nl.belastingdienst.iva.wd.iva.spring.batch.validator;

import nl.belastingdienst.iva.common.springboot.exceptions.ApiValidationError;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.HallmarkDAC6;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HallmarkRisico;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Melding;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Subject;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class MeldingValidatorTest {

    public static final String ONBEKEND = "ONBEKEND";
    @Mock
    GmvService gmvService;

    @InjectMocks
    MeldingValidator meldingValidator;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        List<HallmarkDAC6> hallmarkDAC6List = new ArrayList<>();

        HallmarkDAC6 hm1 = new HallmarkDAC6();
        hm1.setCode("A1");

        HallmarkDAC6 hm1Sub = new HallmarkDAC6();
        hm1Sub.setCode("A1sub");
        hm1Sub.setHoofdhallmark("A1");

        HallmarkDAC6 hm2 = new HallmarkDAC6();
        hm2.setCode("A2");

        HallmarkDAC6 hm2Sub = new HallmarkDAC6();
        hm2Sub.setCode("A2sub");
        hm2Sub.setHoofdhallmark("A2");

        hallmarkDAC6List.add(hm1);
        hallmarkDAC6List.add(hm2);
        hallmarkDAC6List.add(hm1Sub);
        hallmarkDAC6List.add(hm2Sub);
        Mockito.when(gmvService.getHallmarks()).thenReturn(hallmarkDAC6List);
    }

    @Test
    void validateOk() {
        Melding melding = new Melding();

        //Id
        melding.setDisclosureId("di");
        melding.setDraaiDatum(LocalDateTime.now());

        //hallmarks
        HallmarkRisico hallmarkRisico = new HallmarkRisico();
        hallmarkRisico.setHallmark("A1");
        hallmarkRisico.setSubHallmarks("A1sub,A2sub");
        melding.setHallmarkRisicos(new HashSet<>());
        melding.getHallmarkRisicos().add(hallmarkRisico);

        //rol
        Subject s = new Subject();
        s.setRol("relevant taxpayer");//kleine letters en met spaties moet die accepteren
        melding.setSubjecten(new HashSet<>());
        melding.getSubjecten().add(s);
        assertTrue(meldingValidator.validate(melding).isEmpty());
    }

    @Test
    void validateNotOk() {
        Melding melding = new Melding();

        //hallmarks
        HallmarkRisico hallmarkRisico = new HallmarkRisico();
        hallmarkRisico.setHallmark(ONBEKEND);
        hallmarkRisico.setSubHallmarks("ONBEKEND,ONBEKEND");

        HallmarkRisico hallmarkRisico2 = new HallmarkRisico();
        hallmarkRisico2.setHallmark("A1sub");
        hallmarkRisico2.setSubHallmarks("A1");

        melding.setHallmarkRisicos(new HashSet<>());
        melding.getHallmarkRisicos().add(hallmarkRisico);
        melding.getHallmarkRisicos().add(hallmarkRisico2);

        //rol
        Subject s = new Subject();
        s.setRol(ONBEKEND);
        melding.setSubjecten(new HashSet<>());
        melding.getSubjecten().add(s);
        List<ApiValidationError> errors = meldingValidator.validate(melding);
        assertEquals(7, errors.size());
        checkError(errors, "empty value not allowed", "disclosureId", null, 1);
        checkError(errors,"empty value not allowed", "draaidatum", null, 1);
        checkError(errors, "onbekende hallmark", "hallmark", ONBEKEND, 1);
        checkError(errors, "onbekende subhallmark", "subhallmark", ONBEKEND, 2);
        checkError(errors, "is geen hallmark, maar een subhallmark", "hallmark", "A1sub", 1);
        checkError(errors, "onbekende rol", "rol", ONBEKEND, 1);
    }

    private void checkError(List<ApiValidationError> errors, String expectedMessage, String field, Object value, long times) {
        assertEquals(errors.stream().filter(error -> Objects.equals(error.getRejectedValue(), value)
                && Objects.equals(error.getField(), field)
                && Objects.equals(error.getMessage(), expectedMessage)
        ).count(), times);
    }

}
