package nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository;

import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("test")
class MeldingStatusRepositoryTest {

    @Autowired
    MeldingStatusRepository meldingStatusRepository;

    @MockBean
    ClientHttpRequestFactory clientHttpRequestFactory;

    @MockBean
    CacheManager cacheManager;

    private static  final String DISCLOSUERE_ID1 = "id1";
    private static  final String DISCLOSUERE_ID2 = "id2";

    private static final LocalDateTime DRAAIDATUM1 = LocalDateTime.of(2022, 1, 1, 1, 1);
    private static final LocalDateTime DRAAIDATUM2 = LocalDateTime.of(2022, 1, 2, 1, 1);


    @BeforeEach
    void setup() {
        this.meldingStatusRepository.deleteAll();

        MeldingStatus meldingStatus1 = new MeldingStatus();
        meldingStatus1.setDraaidatum(DRAAIDATUM1);
        meldingStatus1.setDisclosureId(DISCLOSUERE_ID1);
        meldingStatus1.setJobId(1L);
        meldingStatus1.setInError(Boolean.FALSE);
        this.meldingStatusRepository.save(meldingStatus1);

        MeldingStatus meldingStatus2 = new MeldingStatus();
        meldingStatus2.setDraaidatum(DRAAIDATUM2);
        meldingStatus2.setDisclosureId(DISCLOSUERE_ID2);
        meldingStatus2.setJobId(1L);
        meldingStatus2.setInError(Boolean.TRUE);

        this.meldingStatusRepository.save(meldingStatus2);
    }

    @Test
    void findMeldingStatusByDisclosureIdAndDraaidatum() {
        Optional<MeldingStatus>  optionalMeldingStatus = this.meldingStatusRepository.findMeldingStatusByDisclosureIdAndDraaidatum(DISCLOSUERE_ID1, DRAAIDATUM1);
        assertTrue(optionalMeldingStatus.isPresent());
        assertEquals(DISCLOSUERE_ID1, optionalMeldingStatus.get().getDisclosureId());
        assertEquals(DRAAIDATUM1, optionalMeldingStatus.get().getDraaidatum());
    }

    @Test
    void findMeldingStatusByInErrorIsTrueAndJobId() {
        List<MeldingStatus> meldingStatusList = this.meldingStatusRepository.findMeldingStatusByInErrorIsTrueAndJobId(1L);
        assertEquals(1, meldingStatusList.size());
        assertEquals(DISCLOSUERE_ID2, meldingStatusList.get(0).getDisclosureId());

        meldingStatusList = this.meldingStatusRepository.findMeldingStatusByInErrorIsTrueAndJobId(2L);
        assertEquals(0, meldingStatusList.size());
     }

    @Test
    void findMeldingStatusByInErrorIsTrueOrderByDraaidatum() {
        List<MeldingStatus> meldingStatusList = this.meldingStatusRepository.findMeldingStatusByInErrorIsTrueOrderByDraaidatum();
        assertEquals(1, meldingStatusList.size());
        assertEquals(DISCLOSUERE_ID2, meldingStatusList.get(0).getDisclosureId());
    }
}
