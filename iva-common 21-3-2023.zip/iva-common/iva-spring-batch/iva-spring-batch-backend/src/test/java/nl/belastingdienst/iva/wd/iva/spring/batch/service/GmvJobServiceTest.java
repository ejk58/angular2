package nl.belastingdienst.iva.wd.iva.spring.batch.service;

import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippedInWriterException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;

import java.time.LocalDateTime;
import java.util.*;

import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.IVA_SPRING_BATCH_GMV;
import static nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.GmvBatchConfig.IVA_SPRING_BATCH_GMV_CHECK;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@Log4j2
class GmvJobServiceTest {

    @Mock
    JobLauncher jobLauncher;

    @Mock
    Job loadGmvJob;

    @Mock
    Job testGmvJob;


    @Mock
    JobExecution jobExecution;

    @Mock
    MeldingStatusRepository meldingStatusRepository;

    @Mock
    HandshakeService handshakeService;

    @InjectMocks
    GmvJobService gmvJobService;

    @BeforeEach
    public void setup() throws Exception {
        MockitoAnnotations.openMocks(this);
        when(this.loadGmvJob.getName()).thenReturn("jobName");
        when(this.testGmvJob.getName()).thenReturn("jobName");
        when(this.jobLauncher.run(Mockito.any(), Mockito.any())).thenReturn(jobExecution);
        when(this.jobExecution.getStatus()).thenReturn(BatchStatus.COMPLETED);
        when((this.jobExecution.getStartTime())).thenReturn(new Date(0));
        when((this.jobExecution.getEndTime())).thenReturn(new Date(1000));
        when((this.jobExecution.getJobId())).thenReturn(5L);
        when(this.jobExecution.getId()).thenReturn(1001L);
        when(this.jobExecution.getAllFailureExceptions())
                .thenReturn(List.of(new CommonException("mockCommonException")));

        StepExecution stepExecution = new StepExecution(IVA_SPRING_BATCH_GMV_CHECK, jobExecution);
        stepExecution.setReadCount(100);
        stepExecution.setFilterCount(19);
        // Failure zorgt voor 1 skipped
        stepExecution.setProcessSkipCount(1);
        stepExecution.setWriteCount(0);
        when(this.jobExecution.getStepExecutions()).thenReturn(Collections.singletonList(stepExecution));
        when(this.testGmvJob.getName()).thenReturn("jobName");
        when(this.meldingStatusRepository.findMeldingStatusByInErrorIsTrueAndJobId(Mockito.any())).thenReturn(createFailures());
    }

    @Test
    void loadGMV() throws Exception {
        checkResponse(this.gmvJobService.loadGMV().toStringExtendend());
    }

    private void checkResponse(String result) {
        List<String> responseLines = Arrays.asList(result.split("\\r?\\n"));

        assertEquals("IVA-SPRING-BATCH, Job: jobName finished in 1 seconds, " +
                "jobId: 1001, status COMPLETED, read: 100, skipped: 19, written: 0, failures: 1", responseLines.get(0));
        assertEquals("Fouten tijdens verwerken meldingen:", responseLines.get(1));
        assertEquals("-------", responseLines.get(2));
        assertEquals("", responseLines.get(3));
        assertEquals("Fouten in melding disclosureID: discId, draaidatum: 2022-01-02T03:04 en jobId: 15", responseLines.get(4));
        assertEquals("error message : errorMessage", responseLines.get(5));
        assertEquals("validatiefout(en) : validationErrors", responseLines.get(6));
    }

    private List<MeldingStatus> createFailures() {
        MeldingStatus meldingStatus = new MeldingStatus();
        meldingStatus.setExecutionMessage("errorMessage");
        meldingStatus.setValidationErrors("validationErrors");
        meldingStatus.setDraaidatum(LocalDateTime.of(2022, 1, 2, 3, 4));
        meldingStatus.setDisclosureId("discId");
        meldingStatus.setJobId(15L);
        return Collections.singletonList(meldingStatus);
    }
}
