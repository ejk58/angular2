package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv;

import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.MeldingAlreadyExists;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.MeldingNotNewOrSelectedException;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippedInWriterException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;

class MeldingWriterTest {

    @Mock
    private GmvService gmvService;

    @Mock
    private MeldingStatusRepository meldingStatusRepository;

    @InjectMocks
    private MeldingWriter meldingWriter;// = new MeldingWriter();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void writeOk() throws MeldingAlreadyExists, MeldingNotNewOrSelectedException {
        //GIVEN
        WriteObject writeObject = new WriteObject(new MeldingStatus(), new MeldingDAC6NewUpdateDTO());
        List<WriteObject> writeObjectList = Collections.singletonList(writeObject);

        Mockito.when(gmvService.sendToGmv(writeObject.getMelding())).thenReturn("gmvId");

        //WHEN
        meldingWriter.write(writeObjectList);
        ArgumentCaptor<MeldingStatus> argumentCaptor =
                ArgumentCaptor.forClass(MeldingStatus.class);

        Mockito.verify(meldingStatusRepository, Mockito.times(1)).save(argumentCaptor.capture());
        MeldingStatus meldingStatus = argumentCaptor.getValue();
        assertEquals("gmvId", meldingStatus.getGmvId());
        assertNotNull(meldingStatus.getModified());
    }

    @Test
    void writeUnexpectedFail() throws MeldingAlreadyExists, MeldingNotNewOrSelectedException {
        //GIVEN
        WriteObject writeObject = new WriteObject(new MeldingStatus(), new MeldingDAC6NewUpdateDTO());
        writeObject.getMeldingStatus().setDisclosureId("discId");
        writeObject.getMeldingStatus().setDraaidatum(LocalDateTime.now());
        List<WriteObject> writeObjectList = Collections.singletonList(writeObject);

        given(gmvService.sendToGmv(writeObject.getMelding())).willAnswer( invocation -> { throw new Exception("msg"); });
        //WHEN
        Exception caughtException = null;
        try {
            meldingWriter.write(writeObjectList);
        } catch (Exception exception) {
            caughtException = exception;
        }
        assertTrue(caughtException instanceof CommonException);
        assertTrue(caughtException.getMessage().contains("An unexpected exception was caught."));
        ArgumentCaptor<MeldingStatus> argumentCaptor =
                ArgumentCaptor.forClass(MeldingStatus.class);

        Mockito.verify(meldingStatusRepository, Mockito.times(1)).save(argumentCaptor.capture());
        MeldingStatus meldingStatus = argumentCaptor.getValue();
        assertEquals("msg", meldingStatus.getExecutionMessage());
        assertNotNull(meldingStatus.getModified());

    }

    @Test
    void writeCommonExceptionFail() throws MeldingAlreadyExists, MeldingNotNewOrSelectedException {
        //GIVEN
        WriteObject writeObject = new WriteObject(new MeldingStatus(), new MeldingDAC6NewUpdateDTO());
        writeObject.getMeldingStatus().setDisclosureId("discId");
        writeObject.getMeldingStatus().setDraaidatum(LocalDateTime.now());
        List<WriteObject> writeObjectList = Collections.singletonList(writeObject);

        given(gmvService.sendToGmv(writeObject.getMelding())).willAnswer( invocation -> { throw new CommonException("message"); });

        //WHEN
        Exception caughtException = null;
        try {
            meldingWriter.write(writeObjectList);
        } catch (Exception exception) {
            caughtException = exception;
        }

        //THEN
        assertTrue(caughtException instanceof CommonException);
        ArgumentCaptor<MeldingStatus> argumentCaptor =
                ArgumentCaptor.forClass(MeldingStatus.class);

        Mockito.verify(meldingStatusRepository, Mockito.times(1)).save(argumentCaptor.capture());
        MeldingStatus meldingStatus = argumentCaptor.getValue();
        assertNotNull(meldingStatus.getModified());


    }

    @Test
    void writeSkippableException() throws MeldingAlreadyExists, MeldingNotNewOrSelectedException {
        //GIVEN
        WriteObject writeObject = new WriteObject(new MeldingStatus(), new MeldingDAC6NewUpdateDTO());
        writeObject.getMeldingStatus().setDisclosureId("discId");
        writeObject.getMeldingStatus().setDraaidatum(LocalDateTime.now());
        List<WriteObject> writeObjectList = Collections.singletonList(writeObject);

        given(gmvService.sendToGmv(writeObject.getMelding())).willAnswer( invocation -> { throw new SkippedInWriterException("SkipTest"); });

        //WHEN
        Exception caughtException = null;
        try {
            meldingWriter.write(writeObjectList);
        } catch (Exception exception) {
            caughtException = exception;
        }

        //THEN
        assertTrue(caughtException instanceof SkippedInWriterException);
        ArgumentCaptor<MeldingStatus> argumentCaptor =
                ArgumentCaptor.forClass(MeldingStatus.class);

        Mockito.verify(meldingStatusRepository, Mockito.times(1)).save(argumentCaptor.capture());
        MeldingStatus meldingStatus = argumentCaptor.getValue();
        assertNotNull(meldingStatus.getModified());


    }
}
