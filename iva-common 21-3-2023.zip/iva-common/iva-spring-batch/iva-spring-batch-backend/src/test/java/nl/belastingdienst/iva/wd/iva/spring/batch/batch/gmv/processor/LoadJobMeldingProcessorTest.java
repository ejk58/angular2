package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.PersoonNewDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.PrioriteitDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mapper.MeldingDAC6Mapper;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippableException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Melding;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingKey;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Model;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.MeldingRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import nl.belastingdienst.iva.wd.iva.spring.batch.validator.MeldingValidator;

class LoadJobMeldingProcessorTest {

    @Mock
    MeldingStatusRepository meldingStatusRepository;

    @Mock
    MeldingDAC6Mapper meldingDAC6Mapper;

    @Mock
    MeldingValidator meldingValidator;

    @Mock
    GmvService gmvService;

    @Mock
    MeldingRepository meldingRepository;

    @InjectMocks
    private LoadJobMeldingProcessor loadJobMeldingProcessor;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void processOK() throws JsonProcessingException, JSONException {
        //GIVEN

        Melding melding = new Melding();
        String disclosureId = "disclosureId";
        LocalDateTime draaidatum = LocalDateTime.now();
        melding.setDisclosureId(disclosureId);
        Model model = new Model();
        model.setDraaiDatum(draaidatum);
        melding.setModel(model);
        melding.setDraaiDatum(draaidatum);

        MeldingKey meldingId = new MeldingKey();
        meldingId.setDraaiDatum(melding.getDraaiDatum());
        meldingId.setDisclosureId(melding.getDisclosureId());

        MeldingDAC6NewUpdateDTO meldingDAC6NewUpdateDTO = new MeldingDAC6NewUpdateDTO();
        meldingDAC6NewUpdateDTO.setArrangementId("arrangementId");
        meldingDAC6NewUpdateDTO.setDisclosureId(disclosureId);
        meldingDAC6NewUpdateDTO.setDisclosureVolgnr(1);
        meldingDAC6NewUpdateDTO.setMeldingselectieInd(true);
        meldingDAC6NewUpdateDTO.setBelastingMiddelen("middelen");
        meldingDAC6NewUpdateDTO.setDisclosureTimestamp(LocalDateTime.MIN);
        meldingDAC6NewUpdateDTO.setImplementatieDatum(LocalDate.MAX);
        meldingDAC6NewUpdateDTO.setSamenvatting("samenvatting");
        meldingDAC6NewUpdateDTO.setPersonen(List.of(new PersoonNewDTO()));
        meldingDAC6NewUpdateDTO.setPrioriteiten(List.of(new PrioriteitDAC6NewUpdateDTO()));
        Mockito.when(meldingDAC6Mapper.map(melding)).thenReturn(meldingDAC6NewUpdateDTO);

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        MeldingStatus status = new MeldingStatus();
        status.setInError(Boolean.FALSE);
        status.setExecutionMessage(null);
        status.setValidationErrors(null);
        status.setMessage(ow.writeValueAsString(meldingDAC6NewUpdateDTO));
        Mockito.when(gmvService.getGmvId(disclosureId, draaidatum)).thenReturn(null);
        Mockito.when(meldingRepository.findById(Mockito.any())).thenReturn(Optional.of(melding));

        Mockito.when(meldingStatusRepository.findMeldingStatusByDisclosureIdAndDraaidatum(disclosureId, draaidatum)).thenReturn(Optional.of(status));

        //WHEN
        WriteObject writeObject = this.loadJobMeldingProcessor.process(status);

        //THEN
        assertNotNull(writeObject);
        assertNotNull(writeObject.getMelding());
        assertNull(writeObject.getMeldingStatus().getExecutionMessage());
        assertNull(writeObject.getMeldingStatus().getValidationErrors());
        assertFalse(writeObject.getMeldingStatus().getInError());
        assertThat(writeObject.getMelding(), samePropertyValuesAs(meldingDAC6NewUpdateDTO));
    }

    @Test
    void processSkipIsPresentInGMV() {
        //GIVEN
        Melding melding = new Melding();
        String disclosureId = "disclosureId";
        LocalDateTime draaidatum = LocalDateTime.now();
        melding.setDisclosureId(disclosureId);
        melding.setDraaiDatum(draaidatum);
        Model model = new Model();
        model.setDraaiDatum(draaidatum);
        melding.setModel(model);

        MeldingStatus status = new MeldingStatus();
        status.setDraaidatum(melding.getDraaiDatum());
        status.setDisclosureId(melding.getDisclosureId());

        Mockito.when(gmvService.getGmvId(disclosureId, draaidatum)).thenReturn("gmvId");

        Mockito.when(meldingRepository.findById(Mockito.any())).thenReturn(Optional.of(melding));

        Mockito.when(meldingStatusRepository.findMeldingStatusByDisclosureIdAndDraaidatum(disclosureId, draaidatum)).thenReturn(Optional.empty());
        //WHEN
        Exception caughtException = null;
        WriteObject writeObject = null;
        try {
            writeObject = this.loadJobMeldingProcessor.process(status);
        } catch (Exception exception) {
            caughtException = exception;
        }

        //THEN
        assertTrue(caughtException instanceof SkippableException);
        assertNull(writeObject); //when null then process is skipped
        ArgumentCaptor<MeldingStatus> argumentCaptor = ArgumentCaptor.forClass(MeldingStatus.class);
        Mockito.verify(this.meldingStatusRepository, times(1)).save(argumentCaptor.capture());
        List<MeldingStatus> meldingStatus = argumentCaptor.getAllValues();

        assertNotNull(meldingStatus);
        assertEquals("gmvId", meldingStatus.get(0).getGmvId());
        assertEquals("Overgeslagen. Deze melding is al verwerkt in GMV (JobId was onbekend in laadapplicatie)",
                meldingStatus.get(0).getExecutionMessage());
        assertFalse(meldingStatus.get(0).getInError());
    }

    @Test
    void processSkip() {
        //GIVEN
        MeldingStatus status = new MeldingStatus();
        status.setGmvId("gmvId");

        Mockito.when(meldingStatusRepository.findMeldingStatusByDisclosureIdAndDraaidatum(Mockito.any(), Mockito.any())).thenReturn(Optional.of(status));
        //WHEN
        Exception caughtException = null;
        WriteObject writeObject = null;
        try {
            writeObject = this.loadJobMeldingProcessor.process(new MeldingStatus());
        } catch (Exception exception) {
            caughtException = exception;
        }

        //THEN
        assertTrue(caughtException instanceof SkippableException);
        assertNull(writeObject); //when null then process is skipped
    }
}
