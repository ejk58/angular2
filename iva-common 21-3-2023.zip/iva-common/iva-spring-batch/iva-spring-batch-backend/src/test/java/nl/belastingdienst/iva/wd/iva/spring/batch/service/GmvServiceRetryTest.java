/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: ConsoleTest.java
 *             Auteur: veldb13
 *    Creatietijdstip: 8-2-2023 11:34
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.iva.spring.batch.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import java.util.List;


import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.HallmarkDAC6;
import nl.belastingdienst.iva.wd.iva.spring.batch.config.RetryConfig;

import lombok.extern.log4j.Log4j2;

@Log4j2
@SpringBootTest(classes = { GmvService.class, RetryConfig.class })
@ActiveProfiles({"ont", "unittest"})
class GmvServiceRetryTest {
	@Autowired
	private GmvService gmvService;

	@MockBean
	private RestTemplate restTemplate;

	@Test
	void happyRetryGetHallmarksTest() {
		//Given
		HallmarkDAC6 hallmarkDAC6 = new HallmarkDAC6();

		Mockito.when(restTemplate.exchange(anyString(), any(HttpMethod.class),
						any(HttpEntity.class), any(ParameterizedTypeReference.class)))
				.thenThrow(RestClientResponseException.class)
				.thenThrow(RestClientResponseException.class)
				.thenReturn(ResponseEntity.ok(List.of(hallmarkDAC6)));

		//When
		List<HallmarkDAC6> resultList = gmvService.getHallmarks();

		//Then
		assertThat(resultList, hasSize(1));
	}

	@Test
	void exhaustedRetriesGetHallmarksTest() {
		//Given
		Mockito.when(restTemplate.exchange(anyString(), any(HttpMethod.class),
						any(HttpEntity.class), any(ParameterizedTypeReference.class)))
				.thenThrow(RestClientResponseException.class)
				.thenThrow(RestClientResponseException.class)
				.thenThrow(RestClientResponseException.class);

		//When
		Exception exception = null;
		try {
			List<HallmarkDAC6> resultList = gmvService.getHallmarks();
		} catch (Exception e) {
			exception = e;
		}

		//Then
		assertThat(exception, is(notNullValue()));
		assertThat(exception, isA(CommonException.class));
	}

	@Test
	void retrySendToGmvTest() {
		//Given
		Mockito.when(restTemplate.exchange(anyString(), any(HttpMethod.class),
						any(HttpEntity.class), any(Class.class)))
				.thenThrow(RestClientResponseException.class)
				.thenThrow(RestClientResponseException.class)
				.thenReturn(ResponseEntity.ok("body"));

		//When
		String responseBody = gmvService.sendToGmv(null);

		//Then
		assertThat(responseBody, is("body"));
	}

	@Test
	void retryGetGmvIdTest() {
		//Given
		Mockito.when(restTemplate.exchange(anyString(), any(HttpMethod.class),
						any(HttpEntity.class), any(Class.class)))
				.thenThrow(RestClientResponseException.class)
				.thenReturn(ResponseEntity.ok("id"));

		//When
		String responseBody = gmvService.getGmvId(null, null);

		//Then
		assertThat(responseBody, is("id"));
	}
}
