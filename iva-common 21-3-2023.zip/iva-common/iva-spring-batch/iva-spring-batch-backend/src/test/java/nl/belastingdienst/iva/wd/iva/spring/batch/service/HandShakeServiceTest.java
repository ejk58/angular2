package nl.belastingdienst.iva.wd.iva.spring.batch.service;


import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.OppositeSideIsProcessingException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeGMV;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.HandshakeMDR;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.HandshakeGmvRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.HandshakeMdrRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Collections;
import java.util.List;

import static nl.belastingdienst.iva.wd.iva.spring.batch.service.HandshakeService.MDR;
import static nl.belastingdienst.iva.wd.iva.spring.batch.service.HandshakeService.RUN_END;
import static nl.belastingdienst.iva.wd.iva.spring.batch.service.HandshakeService.RUN_START;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

@ExtendWith(MockitoExtension.class)
class HandShakeServiceTest {
    private HandshakeService handshakeService;

    @Mock
    private HandshakeGmvRepository handshakeGmvRepository;

    @Mock
    private HandshakeMdrRepository handshakeMdrRepository;

    @BeforeEach
    void init() {
        handshakeService = new HandshakeService(handshakeGmvRepository, handshakeMdrRepository, true);
    }

    @Test
    void gmvIsAllowedToProcessTest() {
        //Given
        HandshakeMDR handshakeMDR = new HandshakeMDR();
        handshakeMDR.setEventName(RUN_END);
        handshakeMDR.setProduct(MDR);
        handshakeMDR.setCreated(Timestamp.from(Instant.now()));
        HandshakeGMV handshakeGMV = new HandshakeGMV();
        handshakeGMV.setProduct(MDR);
        handshakeGMV.setEventName(RUN_END);
        handshakeGMV.setCreated(Timestamp.from(Instant.EPOCH));

        Mockito.when(handshakeMdrRepository.findAll()).thenReturn(List.of(handshakeMDR));
        Mockito.when(handshakeGmvRepository.findAll()).thenReturn(List.of(handshakeGMV));

        //When
        OppositeSideIsProcessingException oppositeSideIsProcessingException = null;
        try {
            handshakeService.checkIfGmvIsAllowedToProcess();
        } catch (OppositeSideIsProcessingException ex) {
            oppositeSideIsProcessingException = ex;
        }

        //Then
        assertThat(oppositeSideIsProcessingException, is(nullValue()));
    }

    @Test
    void exceptionMessageIfMDRHasNeverWrittenTest() {
        //Given
        Mockito.when(handshakeMdrRepository.findAll()).thenReturn(Collections.emptyList());

        //When
        OppositeSideIsProcessingException oppositeSideIsProcessingException = null;
        try {
            handshakeService.checkIfGmvIsAllowedToProcess();
        } catch (OppositeSideIsProcessingException ex) {
            oppositeSideIsProcessingException = ex;
        }

        //Then
        assertThat(oppositeSideIsProcessingException, is(notNullValue()));
        assertThat(oppositeSideIsProcessingException, isA(OppositeSideIsProcessingException.class));
        assertThat(oppositeSideIsProcessingException.getMessage(),
                containsStringIgnoringCase("MDR has never written to the handshake table before. Cannot start job."));
    }

    @Test
    void exceptionMessageIfMDRIsStillProcessingTest() {
        //Given
        HandshakeMDR handshakeMDR = new HandshakeMDR();
        handshakeMDR.setEventName(RUN_START);
        handshakeMDR.setProduct(MDR);
        Mockito.when(handshakeMdrRepository.findAll()).thenReturn(List.of(handshakeMDR));

        //When
        OppositeSideIsProcessingException oppositeSideIsProcessingException = null;
        try {
            handshakeService.checkIfGmvIsAllowedToProcess();
        } catch (OppositeSideIsProcessingException ex) {
            oppositeSideIsProcessingException = ex;
        }

        //Then
        assertThat(oppositeSideIsProcessingException, is(notNullValue()));
        assertThat(oppositeSideIsProcessingException, isA(OppositeSideIsProcessingException.class));
        assertThat(oppositeSideIsProcessingException.getMessage(),
                containsStringIgnoringCase("MDR is still processing. Cannot start job."));
    }

    @Test
    void exceptionMessageIfNoNewDataSinceLastRunTest() {
        //Given
        HandshakeMDR handshakeMDR = new HandshakeMDR();
        handshakeMDR.setCreated(Timestamp.from(Instant.EPOCH));
        handshakeMDR.setEventName(RUN_END);
        handshakeMDR.setProduct(MDR);
        HandshakeGMV handshakeGMV = new HandshakeGMV();
        handshakeGMV.setCreated(Timestamp.from(Instant.now()));
        handshakeGMV.setEventName(RUN_END);
        handshakeGMV.setProduct(MDR);

        Mockito.when(handshakeMdrRepository.findAll()).thenReturn(List.of(handshakeMDR));
        Mockito.when(handshakeGmvRepository.findAll()).thenReturn(List.of(handshakeGMV));

        //When
        OppositeSideIsProcessingException oppositeSideIsProcessingException = null;
        try {
            handshakeService.checkIfGmvIsAllowedToProcess();
        } catch (OppositeSideIsProcessingException ex) {
            oppositeSideIsProcessingException = ex;
        }

        //Then
        assertThat(oppositeSideIsProcessingException, is(notNullValue()));
        assertThat(oppositeSideIsProcessingException, isA(OppositeSideIsProcessingException.class));
        assertThat(oppositeSideIsProcessingException.getMessage(),
                containsStringIgnoringCase("MDR has not provided new batch data since last run. Cannot start job."));
    }

    @Test
    void skipHandshakeTest() {
        //Given
        handshakeService = new HandshakeService(handshakeGmvRepository, handshakeMdrRepository, false);

        //When
        OppositeSideIsProcessingException oppositeSideIsProcessingException = null;
        try {
            handshakeService.checkIfGmvIsAllowedToProcess();
        } catch (OppositeSideIsProcessingException ex) {
            oppositeSideIsProcessingException = ex;
        }

        //Then
        assertThat(oppositeSideIsProcessingException, is(nullValue()));
    }
}
