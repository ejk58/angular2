package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import nl.belastingdienst.iva.common.springboot.exceptions.ApiValidationError;
import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.mapper.MeldingDAC6Mapper;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.exceptions.SkippableException;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Melding;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.MeldingKey;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.entity.Model;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.teradata.repository.MeldingRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvService;
import nl.belastingdienst.iva.wd.iva.spring.batch.validator.MeldingValidator;

class CheckJobMeldingProcessorTest {

    @Mock
    MeldingStatusRepository meldingStatusRepository;

    @Mock
    MeldingDAC6Mapper meldingDAC6Mapper;

    @Mock
    MeldingValidator meldingValidator;

    @Mock
    GmvService gmvService;

    @Mock
    MeldingRepository meldingRepository;

    @InjectMocks
    private CheckJobMeldingProcessor checkJobMeldingProcessor;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void processOK() {
        //GIVEN

        Melding melding = new Melding();
        String disclosureId = "disclosureId";
        LocalDateTime draaidatum = LocalDateTime.now();
        melding.setDisclosureId(disclosureId);
        Model model = new Model();
        model.setDraaiDatum(draaidatum);
        melding.setModel(model);

        MeldingKey meldingId = new MeldingKey();
        meldingId.setDraaiDatum(melding.getDraaiDatum());
        meldingId.setDisclosureId(melding.getDisclosureId());

        MeldingStatus status = new MeldingStatus();
        status.setInError(Boolean.TRUE);
        status.setExecutionMessage("fout");
        status.setValidationErrors("validatiefouten");
        Mockito.when(gmvService.getGmvId(disclosureId, draaidatum)).thenReturn(null);
        Mockito.when(meldingRepository.findById(Mockito.any())).thenReturn(Optional.of(melding));


        Mockito.when(meldingStatusRepository
                .findMeldingStatusByDisclosureIdAndDraaidatum(disclosureId, draaidatum)).thenReturn(Optional.of(status));
        MeldingDAC6NewUpdateDTO meldingDAC6NewUpdateDTO = new MeldingDAC6NewUpdateDTO();
        Mockito.when(meldingDAC6Mapper.map(melding)).thenReturn(meldingDAC6NewUpdateDTO);

        //WHEN
        WriteObject writeObject = this.checkJobMeldingProcessor.process(meldingId);

        //THEN
        assertNotNull(writeObject);
        assertNotNull(writeObject.getMelding());
        assertNull(writeObject.getMeldingStatus().getExecutionMessage());
        assertNull(writeObject.getMeldingStatus().getValidationErrors());
        assertFalse(writeObject.getMeldingStatus().getInError());
        assertSame(meldingDAC6NewUpdateDTO,writeObject.getMelding());
    }

    @Test
    void processSkipIsPresentInGMV() {
        //GIVEN
        Melding melding = new Melding();
        String disclosureId = "disclosureId";
        LocalDateTime draaidatum = LocalDateTime.now();
        melding.setDisclosureId(disclosureId);
        melding.setDraaiDatum(draaidatum);
        Model model = new Model();
        model.setDraaiDatum(draaidatum);
        melding.setModel(model);

        MeldingKey meldingId = new MeldingKey();
        meldingId.setDraaiDatum(melding.getDraaiDatum());
        meldingId.setDisclosureId(melding.getDisclosureId());

        Mockito.when(gmvService.getGmvId(disclosureId, draaidatum)).thenReturn("gmvId");

        Mockito.when(meldingRepository.findById(Mockito.any())).thenReturn(Optional.of(melding));

        Mockito.when(meldingStatusRepository
                .findMeldingStatusByDisclosureIdAndDraaidatum(disclosureId, draaidatum)).thenReturn(Optional.empty());
        //WHEN
        Exception caughtException = null;
        WriteObject writeObject = null;
        try {
            writeObject = this.checkJobMeldingProcessor.process(meldingId);
        } catch (Exception exception) {
            caughtException = exception;
        }

        //THEN
        assertTrue(caughtException instanceof SkippableException);
        assertNull(writeObject); //when null then process is skipped
        ArgumentCaptor<MeldingStatus> argumentCaptor = ArgumentCaptor.forClass(MeldingStatus.class);
        Mockito.verify(this.meldingStatusRepository, times(1)).save(argumentCaptor.capture());
        List<MeldingStatus> meldingStatus = argumentCaptor.getAllValues();

        assertNotNull(meldingStatus);
        assertEquals("gmvId", meldingStatus.get(0).getGmvId());
        assertEquals("Overgeslagen. Deze melding is al verwerkt in GMV (JobId was onbekend in laadapplicatie)", meldingStatus.get(0).getExecutionMessage());
        assertFalse(meldingStatus.get(0).getInError());
    }


    @Test
    void processSkip() {
        //GIVEN
        MeldingStatus status = new MeldingStatus();
        status.setGmvId("gmvId");

        Mockito.when(meldingStatusRepository
                .findMeldingStatusByDisclosureIdAndDraaidatum(Mockito.any(), Mockito.any())).thenReturn(Optional.of(status));
        //WHEN
        Exception caughtException = null;
        WriteObject writeObject = null;
        try {
            writeObject = this.checkJobMeldingProcessor.process(new MeldingKey());
        } catch (Exception exception) {
            caughtException = exception;
        }

        //THEN
        assertTrue(caughtException instanceof SkippableException);
        assertNull(writeObject); //when null then process is skipped
    }

    @Test
    void processValidationErrors() {
        //GIVEN
        Mockito.when(meldingStatusRepository
                .findMeldingStatusByDisclosureIdAndDraaidatum(Mockito.any(), Mockito.any())).thenReturn(Optional.of(new MeldingStatus()));
        Melding melding = new Melding();

        MeldingDAC6NewUpdateDTO meldingDAC6NewUpdateDTO = new MeldingDAC6NewUpdateDTO();
        Mockito.when(meldingDAC6Mapper.map(melding)).thenReturn(meldingDAC6NewUpdateDTO);
        ApiValidationError error = new ApiValidationError("field", "value", "message");
        Mockito.when(meldingValidator.validate(melding)).thenReturn(Collections.singletonList(error));
        Mockito.when(meldingRepository.findById(Mockito.any())).thenReturn(Optional.of(melding));


        //WHEN
        Exception caughtException = null;
        WriteObject writeObject = null;
        try {
            writeObject = this.checkJobMeldingProcessor.process(new MeldingKey());
        } catch (Exception exception) {
            caughtException = exception;
        }
        Mockito.when(meldingRepository.findById(Mockito.any())).thenReturn(Optional.of(melding));
        //THEN
        assertThat(caughtException, is(notNullValue()));
        assertThat(caughtException, isA(CommonException.class));
        ArgumentCaptor<MeldingStatus> argumentCaptor = ArgumentCaptor.forClass(MeldingStatus.class);
        Mockito.verify(this.meldingStatusRepository, times(1)).save(argumentCaptor.capture());
        List<MeldingStatus> meldingStatus = argumentCaptor.getAllValues();

        assertNull(writeObject);
        assertNotNull(meldingStatus);

        assertNull(meldingStatus.get(0).getExecutionMessage());
        assertNotNull(meldingStatus.get(0).getValidationErrors());
        assertTrue(meldingStatus.get(0).getInError());
        assertEquals("field field, value value, message", meldingStatus.get(0).getValidationErrors());
    }
}
