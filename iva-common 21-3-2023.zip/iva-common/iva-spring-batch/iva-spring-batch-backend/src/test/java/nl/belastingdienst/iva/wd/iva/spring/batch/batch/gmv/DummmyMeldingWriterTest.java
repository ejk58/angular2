package nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv;

import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.dto.MeldingDAC6NewUpdateDTO;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.WriteObject;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.MeldingStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.MeldingStatusRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;


import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

class DummmyMeldingWriterTest {

    @Mock
    MeldingStatusRepository meldingStatusRepository;

    @InjectMocks
    DummmyMeldingWriter dummmyMeldingWriter;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void write() {
        //GIVEN
        WriteObject writeObject = new WriteObject(new MeldingStatus(), new MeldingDAC6NewUpdateDTO());
        writeObject.getMelding().setDisclosureId("discl1");

        //WHEN
        dummmyMeldingWriter.write(Collections.singletonList(writeObject));
        ArgumentCaptor<MeldingStatus> argumentCaptor =
                ArgumentCaptor.forClass(MeldingStatus.class);

        Mockito.verify(meldingStatusRepository, Mockito.times(1)).save(argumentCaptor.capture());
        MeldingStatus meldingStatus = argumentCaptor.getValue();
        assertNotNull(meldingStatus.getModified());
    }
}