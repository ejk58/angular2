package nl.belastingdienst.iva.wd.iva.spring.batch.controller;

import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.iva.spring.batch.batch.gmv.model.JobResultStatus;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.entity.ApiKey;
import nl.belastingdienst.iva.wd.iva.spring.batch.persistence.db2.repository.ApiKeyRepository;
import nl.belastingdienst.iva.wd.iva.spring.batch.service.GmvJobService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_APIKEY;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Slf4j
@ExtendWith(SpringExtension.class)
@WebMvcTest(JobFailuresController.class)
class JobFailuresControllerTest {

    @MockBean
    GmvJobService gmvJobService;

    @Autowired
    private MockMvc mvc;

    @MockBean
    CacheManager cacheManager;

    @MockBean
    ClientHttpRequestFactory clientHttpRequestFactory;

    @MockBean
    ApiKeyRepository apiKeyRepository;

    protected static final String START_REQUEST = "/api/external";


    @BeforeEach
    void setup() {
        ApiKey apiKey = new ApiKey();
        apiKey.setId(1);
        given(apiKeyRepository.findApiKeyByKey("AAA")).willReturn(Optional.of(apiKey));
    }

    @Test
    void getAllFailures() throws Exception {
        given(gmvJobService.getAllFailuresEver()).willReturn("failures");
        mvc.perform(get(START_REQUEST + "/getAllFailures").header(HEADER_APIKEY, "AAA").header("accept", "text/plain").contentType(MediaType.TEXT_PLAIN_VALUE))
                .andExpect(status().isOk()).andExpect(content().string("failures"));
    }

    @Test
    void getFailuresForJobId() throws Exception {
        given(gmvJobService.getFailuresForJobId(1L)).willReturn("failures");
        mvc.perform(get(START_REQUEST + "/getFailures/1").header(HEADER_APIKEY, "AAA").header("accept", "text/plain").contentType(MediaType.TEXT_PLAIN_VALUE))
                .andExpect(status().isOk()).andExpect(content().string("failures"));
    }

    @Test
    void getFailuresMostRecentJob() throws Exception {
        given(gmvJobService.getMostRecentFailures()).willReturn("failures");
        mvc.perform(get(START_REQUEST + "/getFailuresMostRecentJob").header(HEADER_APIKEY, "AAA").header("accept", "text/plain").contentType(MediaType.TEXT_PLAIN_VALUE))
                .andExpect(status().isOk()).andExpect(content().string("failures"));
    }
}
