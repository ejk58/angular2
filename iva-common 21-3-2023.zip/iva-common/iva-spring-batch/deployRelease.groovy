pipelineDeployArtifactFromHarbor {	
	deploymentId = "iva-spring-batch"
	integrationPipeline = "iva-spring-batch-test"
	packageChoices = "iva-spring-batch"
                applicationVersionChoices = "1.14.0\n1.13.0\n1.12.0\n1.11.0\n1.10.0"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "1\n2\n3\n4\n5\n6"
	gitopsRepo = "ivacommon/iva-spring-batch-deploy.git"
	quayRepo = "wd-iva-spring-batch"
}
