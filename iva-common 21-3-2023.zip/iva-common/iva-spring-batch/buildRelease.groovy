pipelineRelease_openshift_v2 {
	deploymentId = "iva-spring-batch"
	deployPipeline = "iva-spring-batch_deploy_release"
	integrationPipeline = "iva-spring-batch-test"
	environmentChoices = "tst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6"
	mvnVersion = "maven36-openjdk11"
}
