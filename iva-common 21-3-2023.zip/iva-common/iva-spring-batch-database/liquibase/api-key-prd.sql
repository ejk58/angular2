DELETE FROM API_KEY;

insert into api_key (key) values
('234KG45KJKVKJ5J1')
;

