-- drop default schema !
DROP SCHEMA IVA_FSV_IMP1 RESTRICT;

