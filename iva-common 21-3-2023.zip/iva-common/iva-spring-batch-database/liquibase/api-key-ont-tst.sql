DELETE FROM API_KEY;

insert into api_key (key) values
('AAA')
;