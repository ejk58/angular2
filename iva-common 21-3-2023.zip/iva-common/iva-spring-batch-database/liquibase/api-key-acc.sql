DELETE FROM API_KEY;

insert into api_key (key) values
  ('2IFJH4IFJKE3UHDJ')
;
