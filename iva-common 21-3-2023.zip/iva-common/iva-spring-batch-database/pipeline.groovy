pipelineDatabase_v2_openshift {
	deploymentId = "iva-spring-batch-database"
	environmentChoices = "ont\ntst"
	streetChoices = "1\n2\n3\n4\n5\n6"
	codePipeline = []
}
