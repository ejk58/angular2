pipelineDatabaseRelease_openshift {
	deploymentId = "iva-spring-batch-database"
	deployPipeline = "iva-spring-batch-database_deploy_release"
	integrationPipeline = "iva-spring-batch-database-test"
	environmentChoices = "tst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6"
}
