@Library("GENERIC") _
    pipelineDeployArtifactFromNexus_v1 {
	baseDirectory = "iva_common-jar"
	deploymentId = "iva-common"
	integrationPipeline = ""
	packageChoices = "iva-common\n"
	applicationVersionChoices = "2.2.0\n2.1.0\n2.0.0\n0.10.0\n0.9.0"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
}
