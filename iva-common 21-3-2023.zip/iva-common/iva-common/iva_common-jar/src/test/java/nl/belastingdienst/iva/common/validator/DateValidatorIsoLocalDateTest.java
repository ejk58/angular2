package nl.belastingdienst.iva.common.validator;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class DateValidatorIsoLocalDateTest {

	@Test
	public void testDate() {
		DateTimeValidator validator = new DateValidatorIsoLocalDate();
		assertFalse(validator.isValid("01-01-2020"));
		assertFalse(validator.isValid("2020-01-01T10:00:00"));
		assertFalse(validator.isValid("2020-01-32"));
		assertTrue(validator.isValid("2020-01-01"));
	}

}
