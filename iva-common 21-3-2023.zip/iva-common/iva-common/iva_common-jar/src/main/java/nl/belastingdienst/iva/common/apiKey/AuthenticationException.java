package nl.belastingdienst.iva.common.apiKey;

import javax.ejb.ApplicationException;
import javax.ws.rs.core.Response.Status;

@ApplicationException(inherited=true, rollback=true)
public class AuthenticationException extends RuntimeException {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private final Status status;
    private final String application;
    private final String method;

    AuthenticationException(Status status, String application, String method) {
        this.status = status;
        this.application = application;
        this.method = method;
    }

    public Status getStatus() {
        return status;
    }

	public String getMethod() {
		return method;
	}

	public String getApplication() {
		return application;
	}

}
