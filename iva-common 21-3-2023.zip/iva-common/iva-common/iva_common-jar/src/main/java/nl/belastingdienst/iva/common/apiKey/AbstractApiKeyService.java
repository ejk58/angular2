package nl.belastingdienst.iva.common.apiKey;

import java.util.*;

import javax.annotation.PostConstruct;
import javax.ejb.Schedule;
import javax.ejb.Timer;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.common.errorhandling.CommonException;

public abstract class AbstractApiKeyService {

	private static final Logger logger = LoggerFactory.getLogger(AbstractApiKeyService.class);

	private boolean dbErrorFound = false;

	private Map<String, Set<String>> apiKeyCache = new HashMap<>();
	private Map<String, String> applicationIdCache = new HashMap<>();

	public abstract EntityManager getEntityManager();

	@PostConstruct
	public void refresh() {
		logger.debug("Refreshing....");
		Map<String, Set<String>> methodsByApikey = new HashMap<>();
		Map<String, String> applicationIdByApikey = new HashMap<>();
		try {
			for (ApiKey apiKey : findAllApiKeys()) {
				String theKey = apiKey.getApiKey();
				Set<String> theMethods = new HashSet<>(Arrays.asList(apiKey.getAuthorizedMethods().split(",")));
				if (methodsByApikey.containsKey(theKey)) {
					methodsByApikey.get(theKey).addAll(theMethods);
				} else {
					methodsByApikey.put(theKey, theMethods);
				}
				applicationIdByApikey.put(theKey, apiKey.getCustomer());
			}
			apiKeyCache = methodsByApikey;
			applicationIdCache = applicationIdByApikey;
			if (dbErrorFound) {
				dbErrorFound = false;
				logger.info("Problem retrieving api_keys solved by refreshing.");
			}
		} catch (Exception e) {
			dbErrorFound = true;
			logger.error("Problem retrieving api_keys.", e);
		}
		logger.debug("Finished....");
	}

	public Status checkValidApiKey(String key, String method) {
		Set<String> methods = findMethodsForApikey(key);
		if (key == null || methods == null) {
			if (dbErrorFound) {
				throw new CommonException("Error while accessing the database!");
			}
			return Status.UNAUTHORIZED;
		}
		String cleanMethod = method.replaceAll("V\\d*$", "");
		if (!methods.contains(cleanMethod)) {
			return Status.FORBIDDEN;
		}
		return Status.OK;
	}

	public String getApplicationId(String apiKey) {
		String customer = applicationIdCache.get(apiKey);
		return customer == null ? "<onbekend>" : customer;
	}

	private Set<String> findMethodsForApikey(String key) {
		Set<String> methods = apiKeyCache.get(key);
		if (methods == null) {
			logger.info("Onbekende apikey gebruikt");
		}
		return methods;
	}

	private List<ApiKey> findAllApiKeys() {
		if (this.getEntityManager() != null) {
			TypedQuery<ApiKey> query = getEntityManager().createNamedQuery("ApiKey.findAll", ApiKey.class);
			return query.getResultList();
		}
		return new ArrayList<>();
	}

	@Schedule(minute = "0", hour = "5", persistent = false)
	public void execute(Timer timer) {
		refresh();
	}
}
