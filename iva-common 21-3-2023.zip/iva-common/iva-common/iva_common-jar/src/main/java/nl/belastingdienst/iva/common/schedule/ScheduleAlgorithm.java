package nl.belastingdienst.iva.common.schedule;

import nl.belastingdienst.iva.common.errorhandling.CommonException;

@FunctionalInterface
public interface ScheduleAlgorithm {

	public void execute() throws CommonException;

}
