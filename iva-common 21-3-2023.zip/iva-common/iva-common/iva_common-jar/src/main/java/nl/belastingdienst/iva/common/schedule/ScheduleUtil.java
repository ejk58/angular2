package nl.belastingdienst.iva.common.schedule;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.ejb.EJBException;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cronutils.model.CronType;
import com.cronutils.model.definition.CronDefinitionBuilder;
import com.cronutils.model.time.ExecutionTime;
import com.cronutils.parser.CronParser;

import nl.belastingdienst.iva.common.errorhandling.ValidationException;

public final class ScheduleUtil {

	private static final Logger logger = LoggerFactory.getLogger(ScheduleUtil.class);

	private static CronParser parser = new CronParser(CronDefinitionBuilder.instanceDefinitionFor(CronType.UNIX));

	private ScheduleUtil() {
		throw new AssertionError("Instantiating utility class...");
	}

	@SuppressWarnings("rawtypes")
	public static ScheduleAlgorithm instantiateScheduleAlgorithm(String className) throws ValidationException {
		BeanManager bm = null;
		InitialContext context;
		try {
			context = new InitialContext();
			bm = (BeanManager) context.lookup("java:comp/BeanManager");
		} catch (NamingException e1) {
			throw new RuntimeException("Unable to fetch the BeanManager.", e1);
		}

		Class scheduleAlgorithmClass = null;
		try {
			scheduleAlgorithmClass = Class.forName(className);
		} catch (ClassNotFoundException e) {
			throw new ValidationException("ScheduleAlgorithm", className, "ScheduleAlgorithm unknown: " + className);
		}
		Set<Bean<?>> scheduleAlgorithmBeans = bm.getBeans(scheduleAlgorithmClass);
		if (scheduleAlgorithmBeans.isEmpty()) {
			throw new ValidationException("ScheduleAlgorithm", className,
					"ScheduleAlgorithm can't be instantiated: " + className + ".");
		}
		if (scheduleAlgorithmBeans.size() > 1) {
			Set<Bean<?>> tempAlgoritmBeans = new HashSet<>();
			for (Bean tempBean : scheduleAlgorithmBeans) {
				String beanName = tempBean.getBeanClass().getName();
				if (className.equals(beanName)) {
					tempAlgoritmBeans.add(tempBean);
				}
			}
			if (tempAlgoritmBeans.size() > 1) {
				throw new ValidationException(
						"ScheduleAlgorithm", className, "Multiple instances found for ScheduleAlgorithm.");
			}
			scheduleAlgorithmBeans = tempAlgoritmBeans;
		}
		Bean scheduleAlgorithmBean = scheduleAlgorithmBeans.iterator().next();
		@SuppressWarnings("unchecked")
		CreationalContext<ScheduleAlgorithm> ctx = bm.createCreationalContext(scheduleAlgorithmBean);
		return (ScheduleAlgorithm) bm.getReference(scheduleAlgorithmBean, scheduleAlgorithmClass, ctx);
	}

	public static boolean mustRun(String cronExpression, Date lastRun) {

		ZonedDateTime now = ZonedDateTime.now();
		ExecutionTime executionTime = ExecutionTime.forCron(parser.parse(cronExpression));

		// Get date for last expected execution
		Optional<ZonedDateTime> expectedLastExecution = executionTime.lastExecution(now);

		// Get date of real last execution
		ZonedDateTime realLastExecution = lastRun != null ? ZonedDateTime.ofInstant(lastRun.toInstant(), ZoneId.systemDefault())
				: null;

		if (expectedLastExecution.isPresent()) {
			return realLastExecution != null ? expectedLastExecution.get().isAfter(realLastExecution)
					: expectedLastExecution.get().isBefore(now);
		}
		return true;
	}

	public static void handleException(String message, Exception e) {

		if (e instanceof EJBException) {
			logger.error(message, ((EJBException) e).getCausedByException());
		} else {
			logger.error(message, e);
		}
	}

}
