package nl.belastingdienst.iva.common.apiKey;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.ws.rs.core.Response.Status;

public class ApiKeyInterceptor {

    @Inject
    ApiKeyService apiKeyService;

    @AroundInvoke
    public Object process(InvocationContext invocationContext) throws Exception {
        String apiKey = (String) invocationContext.getParameters()[0];
        String method = invocationContext.getMethod().getName();
        String application = apiKeyService.getApplicationId(apiKey);
        Status status = apiKeyService.checkValidApiKey(apiKey, method);
        if (!status.equals(Status.OK)) {
            throw new AuthenticationException(status, application, method);
        }

        return invocationContext.proceed();
    }
}
