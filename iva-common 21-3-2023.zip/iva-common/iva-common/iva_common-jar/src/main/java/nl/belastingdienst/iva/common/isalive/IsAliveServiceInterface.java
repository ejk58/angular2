package nl.belastingdienst.iva.common.isalive;

public interface IsAliveServiceInterface {

	public IsAliveResponse check();

}