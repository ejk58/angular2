package nl.belastingdienst.iva.common.isalive;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

public class IsAliveResponse {
	private boolean isAlive;
	private Map<String, Long> components;
	private Map<String, Long> startingTimes;
	private String serverName;

	public boolean isAlive() {
		return isAlive;
	}

	public IsAliveResponse() {
		super();
		components = new HashMap<>();
		startingTimes = new HashMap<>();
		isAlive = true;
		try {
			this.serverName = InetAddress.getLocalHost().toString();
		} catch (UnknownHostException e) {
			this.serverName = "Onbekend";
		}
	}
	public Response returnResponse() {
		if (!this.isAlive()) {
			return Response.status(Status.SERVICE_UNAVAILABLE).build();
		}
		return Response.ok(this).build();
	}

	public void startComponent(String component) {
		this.startingTimes.put(component, System.currentTimeMillis());
	}
	
	public void finishComponent(String component) {
		this.components.put(component, System.currentTimeMillis() - this.startingTimes.get(component));
		this.startingTimes.remove(component);
	}
	
	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	public Map<String, Long> getComponents() {
		return components;
	}

	public String getServerName() {
		return serverName;
	}

	@Override
	public String toString() {
		return "IsAliveResponse [isAlive=" + isAlive + ", components=" + components + ", serverName=" + serverName + "]";
	}
}
