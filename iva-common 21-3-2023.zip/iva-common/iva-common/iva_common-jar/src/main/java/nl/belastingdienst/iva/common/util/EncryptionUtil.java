package nl.belastingdienst.iva.common.util;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * Utility klasse voor het encrypten en het decrypten van Strings
 */
public final class EncryptionUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(EncryptionUtil.class);

	private static EncryptionUtil instance = null;

	private KeySpec keySpec;

	private SecretKeyFactory keyFactory;

	private Cipher cipher;

	/**
	 * Constructor
	 */
	private EncryptionUtil() {
		try {
			this.keySpec = new DESKeySpec("a05b98ea61194ca898b7118d37e0e31c".getBytes("UTF8"));
			this.keyFactory = SecretKeyFactory.getInstance("DES");
			this.cipher = Cipher.getInstance("DES");
		} catch (InvalidKeyException e) {
			LOGGER.error(e.getMessage());
		} catch (UnsupportedEncodingException e) {
			LOGGER.error(e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error(e.getMessage());
		} catch (NoSuchPaddingException e) {
			LOGGER.error(e.getMessage());
		}
	}

	/**
	 * Deze methode retourneert een instantie van de EncryptionUtil.
	 * 
	 * @return EncryptionUtil
	 */
	public static synchronized EncryptionUtil getInstance() {
		if (instance == null) {
			instance = new EncryptionUtil();
		}
		return instance;
	}

	/**
	 * Deze methode biedt de mogelijkheid om een String te decrypten
	 * 
	 * @param input
	 * @return String
	 */
	public String decrypt(String input) {
		String result = null;
		if (StringUtils.trimToNull(input) != null) {

			try {
				SecretKey key = this.keyFactory.generateSecret(this.keySpec);
				this.cipher.init(Cipher.DECRYPT_MODE, key);

				byte[] decodedResult = Base64.getDecoder().decode(input);
				byte[] cipherWoord = this.cipher.doFinal(decodedResult);

				result = new String(cipherWoord);
			} catch (InvalidKeySpecException e) {
				LOGGER.error(e.getMessage());
			} catch (InvalidKeyException e) {
				LOGGER.error(e.getMessage());
			}

			catch (IllegalBlockSizeException e) {
				LOGGER.error(e.getMessage());
			} catch (BadPaddingException e) {
				LOGGER.error(e.getMessage());
			}
		}
		return result;
	}

	/**
	 * Deze methode biedt de mogelijkheid om een String te encrypten
	 * 
	 * @param input
	 * @return String
	 */
	public String encrypt(String input) {
		String result = null;
		if (StringUtils.trimToNull(input) != null) {
			try {
				SecretKey key = this.keyFactory.generateSecret(this.keySpec);
				this.cipher.init(Cipher.ENCRYPT_MODE, key);
				byte[] cipherWoord = this.cipher.doFinal(input.getBytes("UTF8"));
				result = Base64.getEncoder().encodeToString(cipherWoord);
			} catch (InvalidKeySpecException e) {
				LOGGER.error(e.getMessage());
			} catch (InvalidKeyException e) {
				LOGGER.error(e.getMessage());
			} catch (UnsupportedEncodingException e) {
				LOGGER.error(e.getMessage());
			} catch (IllegalBlockSizeException e) {
				LOGGER.error(e.getMessage());
			} catch (BadPaddingException e) {
				LOGGER.error(e.getMessage());
			}
		}
		return result;
	}
}
