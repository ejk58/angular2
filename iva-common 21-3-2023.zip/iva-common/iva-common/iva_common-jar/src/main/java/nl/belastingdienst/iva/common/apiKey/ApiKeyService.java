package nl.belastingdienst.iva.common.apiKey;

import javax.ejb.Timer;
import javax.ws.rs.core.Response;

import nl.belastingdienst.iva.common.errorhandling.CommonException;

/**
 * TODO: weera09: beschrijf deze klasse !
 *
 * @author weera09
 */
public interface ApiKeyService {
	void refresh();
	Response.Status checkValidApiKey(String key, String method) throws CommonException;
	String getApplicationId(String apiKey);
	public void execute(Timer timer);
}
