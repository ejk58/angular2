package nl.belastingdienst.iva.common.schedule;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class ScheduleStatusService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleStatusService.class);

	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		LOGGER.debug("call setEntityManager: " + entityManager);
		this.entityManager = entityManager;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public boolean start(Long id) {
		Schedule schedule = entityManager.find(Schedule.class, id, LockModeType.PESSIMISTIC_WRITE);
		if (!schedule.isStarted() && ScheduleUtil.mustRun(schedule.getCron(), schedule.getLastRun())) {
			schedule.setStarted(true);
			schedule.setLastRun(new Date());
			return true;
		}
		return false;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void stop(Long id) {
		Schedule schedule = entityManager.find(Schedule.class, id, LockModeType.PESSIMISTIC_WRITE);
		if (schedule.isStarted()) {
			schedule.setStarted(false);
		}
	}

	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<Schedule> retrieveActiveNotStartedSchedules() {
		LOGGER.debug("Entitymanager: " + entityManager);
		TypedQuery<Schedule> query = entityManager.createNamedQuery("Schedule.retrieveActiveNotStartedSchedules", Schedule.class);
		return query.getResultList();
	}
}
