package nl.belastingdienst.iva.common.errorhandling;

import javax.ejb.ApplicationException;

import org.apache.http.HttpResponse;

@ApplicationException
public class UpstreamWebWrapperException extends Exception {

	private static final long serialVersionUID = 6460438690363404315L;
	private final transient HttpResponse response;

	public UpstreamWebWrapperException(Exception e) {
		super(e);
		this.response = null;
	}

	/**
	 * @param response
	 */
	public UpstreamWebWrapperException(HttpResponse response) {
		this.response = response;
	}

	public HttpResponse getResponse() {
		return response;
	}

}