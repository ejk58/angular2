package nl.belastingdienst.iva.common.errorhandling;

import javax.ejb.ApplicationException;
import javax.ws.rs.core.Response;

import org.apache.http.HttpResponse;

@ApplicationException
public class InterceptedException extends Exception {
	private static final long serialVersionUID = 9089908005989795456L;
	private final UserContext context;
	private final Integer statusCode;

	public enum Type {
		WEB, EXCEPTION
	};

	private final Type type;

	public InterceptedException(Response response, UserContext context) {
		super();
		this.statusCode = response.getStatus();
		this.context = context;
		this.type = Type.WEB;
	}

	public InterceptedException(HttpResponse response, UserContext context) {
		super();
		this.statusCode = response.getStatusLine().getStatusCode();
		this.context = context;
		this.type = Type.WEB;
	}

	public InterceptedException(UserContext context, UpstreamWebWrapperException e) {
		super();
		if (e.getResponse() != null) {
			this.statusCode = e.getResponse().getStatusLine().getStatusCode();
		} else {
			this.statusCode = null;
		}
		this.context = context;
		this.type = Type.WEB;
	}

	public InterceptedException(UserContext context, Exception e) {
		super(e);
		this.statusCode = null;
		this.context = context;
		this.type = Type.EXCEPTION;
	}

	public UserContext getContext() {
		return context;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public Type getType() {
		return type;
	}
}
