## Release notes
| version | datum    | user    | Aanpassingen                            |
|---------|----------|---------|-----------------------------------------|
| 2.2.0   | 20220818 | corna00 | AbstractTeraDataClient aangepast. Return type van getTeradataRestUrl veranderd van String in URL.|
| 2.1.0   | 20220817 | corna00 | AbstractApiKeyService aangepast. Reset van property dbErrorFound indien deze true is bij succesvolle refresh.|
| 2.0.0   | 20220125 | weera09 | AbstractTeraDataClient aangepast. Het heeft nu geen resources meer en 3 extra abstracte methodes. Deze methodes zullen geïmplementeerd moeten worden.|
| 0.2.0   | 20210311 | weera09 | Schedule domain class voorzien van version member met @Version annotatie. Bij nader inzien was dit niet echt nodig omdat bij het starten van een ealgoritme een pessimistic lock wordt gebruikt wat lezen of schrijven door een ander proces verhindert. Ik heb de @Version wel laten staan en ook het afvangen van de OptimisticLockException in AbstractScheduleService.|
