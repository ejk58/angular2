package nl.belastingdienst.iva.wd.reference;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(scanBasePackageClasses = { nl.belastingdienst.iva.wd.reference.Application.class,
		nl.belastingdienst.iva.common.springboot.security2.BdWebdevAutoconfiguration.class })
@EnableScheduling
@EnableCaching
public class Application {
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}
