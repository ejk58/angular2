pipelineCode_openshift_v4b {
	deploymentId = "springboot-reference"
	integrationPipeline = "springboot-reference-test"
	environmentChoices = "ont\ntst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6\n"
	nodeVersion = "nodejs16"
	mvnVersion = "maven36-openjdk11"
	vervangenOpenjdk11Image = true // gebruik steeds het laatse openjdk image
	gitopsRepo = "<bitbucket projectnaam>/springboot-reference-deploy.git"
	skipSonar = false
	environmentType = "springboot" // of openliberty 
}
