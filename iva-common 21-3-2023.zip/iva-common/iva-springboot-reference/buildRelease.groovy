pipelineRelease_openshift_v2 {
	deploymentId = "springboot-reference"
	deployPipeline = "springboot-reference_deploy_release"
	integrationPipeline = "springboot-reference-test"
	environmentChoices = "tst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6"
	mvnVersion = "maven36-openjdk11"
	environmentType = "springboot"
}
