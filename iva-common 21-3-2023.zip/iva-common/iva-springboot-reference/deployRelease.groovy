pipelineDeployArtifactFromHarbor {	
	deploymentId = "springboot-reference"
	integrationPipeline = "springboot-reference-test"
	packageChoices = "springboot-reference"
	applicationVersionChoices = ""
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "1\n2\n3\n4\n5\n6"
	gitopsRepo = "<bitbucket projectnaam>/springboot-reference-deploy.git"
	quayRepo = "wd-springboot-reference"
}
