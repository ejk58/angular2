import { NgModule } from '@angular/core';
import { IvFrameworkLibComponent } from './iv-framework-lib.component';


@NgModule({
  declarations: [IvFrameworkLibComponent],
  imports: [
  ],
    exports: [IvFrameworkLibComponent]
})
export class IvFrameworkLibModule { }
