export interface MenuItem {
  text: string,
  route: string,
  icon?: string,
  submenu?: Array<MenuItem>,
  opened?: boolean
}
