import {Injectable} from '@angular/core';
import {Feedback} from './shared/feedback';
import {VersionInformation} from './shared/version-information';
import {Observable} from 'rxjs';

@Injectable()
export abstract class FeedbackApi {

  addFeedback: (feedback: Feedback) => Observable<Feedback>;
  getVersionInformation: () => Observable<VersionInformation>;
}
