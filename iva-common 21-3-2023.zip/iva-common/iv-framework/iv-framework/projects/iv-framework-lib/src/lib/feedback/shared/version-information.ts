export interface VersionInformation {
    application: string;
    version: string;
    buildNumber: string;
    buildTime: string;
  }