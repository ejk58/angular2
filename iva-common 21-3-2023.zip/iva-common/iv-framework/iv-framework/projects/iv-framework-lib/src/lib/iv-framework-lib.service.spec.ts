import { TestBed } from '@angular/core/testing';

import { IvFrameworkLibService } from './iv-framework-lib.service';

describe('IvFrameworkLibService', () => {
  let service: IvFrameworkLibService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IvFrameworkLibService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
