export class IvMenuItem {
  constructor(public name: string,
              public contents?: any,
              public url?: string) {}
}
