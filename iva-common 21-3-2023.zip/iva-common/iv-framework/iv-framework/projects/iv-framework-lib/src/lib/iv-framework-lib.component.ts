import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-iv-framework-lib',
  template: `
    <p>
      iv-framework-lib works!
    </p>
  `,
  styles: [
  ]
})
export class IvFrameworkLibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
