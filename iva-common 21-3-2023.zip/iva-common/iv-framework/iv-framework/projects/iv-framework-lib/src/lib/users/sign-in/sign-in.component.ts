import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {NgForm} from '@angular/forms';
import {UserApi} from '../user-api';
import {ConfigurationService} from '../../services/configuration.service';

@Component({
  selector: 'ivfw-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent implements OnInit {

  formError: string;
  submitting = false;

  constructor(private userApi: UserApi, private router: Router, public configService: ConfigurationService) {
  }

  ngOnInit(): void {
  }

  onSubmit(signInForm: NgForm): void {
    if (signInForm.valid) {
      this.submitting = true;
      this.formError = null;

      this.userApi.signIn(signInForm.value.username, signInForm.value.password)
        .subscribe(() => {
            this.router.navigate([this.userApi.getAuthenticatedRoute()]);
          },
          (err) => {
            console.log('error: ' + err.message);
            this.submitting = false;
            this.formError = `Geen geldige inloggegevens opgegeven`;
          }
        );
    }
  }
}
