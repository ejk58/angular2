import {Component, ElementRef, HostBinding, HostListener, Input, OnInit} from '@angular/core';
import {MenuService} from '../../services/menu.service';
import {NavigationEnd, Router} from '@angular/router';
import {ConfigurationService} from "../../services/configuration.service";
import {MenuItem} from "./menu-item.interface";

@Component({
  selector: 'ivfw-menu-item',
  templateUrl: './menu-item.component.html',
  styleUrls: ['./menu-item.component.scss']
})
export class MenuItemComponent implements OnInit {

  @Input() item: MenuItem;
  @Input() ariaLabelledBy: string;
  @HostBinding('class.parent-is-popup')
  @Input() parentIsPopup = true;
  isActiveRoute = false;

  mouseInItem = false;
  mouseInPopup = false;
  popupLeft = 0;
  popupTop = 34;

  constructor(private configService: ConfigurationService,
              public menuService: MenuService,
              private router: Router,
              private el: ElementRef) { }

  checkActiveRoute(route: string): void {
    this.isActiveRoute = (route === '/' + this.item.route);
  }

  ngOnInit(): void {
    this.checkActiveRoute(this.router.url);

    this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationEnd) {
          this.checkActiveRoute(event.url);
        }
      })
  }

  @HostListener('click', ['$event'])
  onClick(event): void {
    let route = this.item.route;
    event.stopPropagation();
    if (this.item.submenu) {
      if (this.menuService.isVertical) {
        this.mouseInPopup = !this.mouseInPopup;
        this.item.opened = !this.item.opened;
      }
      route = this.item.submenu[0].route;
    }
    if (route) {
      const newEvent = new MouseEvent('mouseleave', {bubbles: true});
      this.el.nativeElement.dispatchEvent(newEvent);
      this.router.navigate(['/' + route]);
    }
  }

  // onPopupMouseEnter(event): void {
  //   if (!this.menuService.isVertical) {
  //     this.mouseInPopup = true;
  //     this.item.opened = true;
  //   }
  // }
  //
  // onPopupMouseLeave(event): void {
  //   if (!this.menuService.isVertical) {
  //     this.mouseInPopup = false;
  //     this.item.opened = false;
  //   }
  // }

  @HostListener('mouseleave', ['$event'])
  onMouseLeave(event): void {
    if(!this.menuService.isVertical) {
      this.mouseInItem = false;
    }
  }

  @HostListener('mouseenter', ['$event'])
  onMouseEnter(event): void {
    if(!this.menuService.isVertical) {
      if(this.item.submenu) {
        this.mouseInItem = true;
        if(this.parentIsPopup) {
          this.popupLeft = 160;
          this.popupTop = 0;
        }
      }


    }
  }

  showMenuItemLeft(): string {
    return this.configService.showLeftIconForMenuItem === true ? 'item.icon' : '';
  }

  showIconsForRightSide(icon: string): string {
    return this.configService.allowedOnRightSide(icon);
  }

}
