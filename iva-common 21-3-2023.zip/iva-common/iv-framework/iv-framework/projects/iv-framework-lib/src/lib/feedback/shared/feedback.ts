import {VersionInformation} from './version-information';
export interface Feedback {
  naam?: string;
  email?: string;
  userId?: string;
  melding: string;
  pagina: string;
  versionInformation?: VersionInformation;
}
