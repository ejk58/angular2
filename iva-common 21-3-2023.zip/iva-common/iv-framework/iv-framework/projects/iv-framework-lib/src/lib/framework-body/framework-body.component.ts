import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'ivfw-framework-body',
  templateUrl: './framework-body.component.html',
  styleUrls: ['./framework-body.component.scss']
})
export class FrameworkBodyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
