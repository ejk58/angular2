import {Component, OnInit} from '@angular/core';
import {Feedback} from './shared/feedback';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router';
import {FeedbackApi} from './feedback-api';
import {ConfigurationService} from '../services/configuration.service';
import {VersionInformation} from './shared/version-information';

@Component({
  selector: 'ivfw-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  constructor(private feedbackApi: FeedbackApi, private router: Router, private configurationService: ConfigurationService) { }
  useFeedback = false;
  display = false;
  display_success = false;
  feedback: Feedback;
  versionInfo: VersionInformation;

  meldingLimit = this.configurationService.feedbackFormMeldingCharLimit;
  useGebruikersnaam = this.configurationService.feedbackFormUseGebruikersNaam;

  ngOnInit(): void {
    this.useFeedback = this.configurationService.useFeedback;
    this.resetFeedback();
    this.feedbackApi.getVersionInformation().subscribe(res => this.versionInfo = res);
  }

  resetFeedback() {
    this.feedback = {
      naam: null,
      email: null,
      melding: null,
      pagina: null
    };
  }

  save(form: NgForm) {
    if (form.valid) {
      this.feedback.pagina = this.router.url;
      this.feedback.versionInformation = this.versionInfo;
      return this.feedbackApi.addFeedback(this.feedback).subscribe(() => {
        this.resetFeedback();
        this.display_success = true;
      });
    }
  }

  cancel() {
    this.resetFeedback();
    this.display = false;
    this.display_success = false;
  }

}
