import {Component, OnInit} from '@angular/core';
import {MenuService} from '../../services/menu.service';
import {ScreenService} from '../../services/screen.service';
import {ConfigurationService} from '../../services/configuration.service';

@Component({
  selector: 'ivfw-menu-hide-vertical',
  templateUrl: './menu-hide-vertical.component.html',
  styleUrls: ['./menu-hide-vertical.component.scss']
})
export class MenuHideVerticalComponent implements OnInit {

  showHideLeftSideMenuViaContentButton = true;

  constructor(
    public menuService: MenuService,
    public screenService: ScreenService,
    private configService: ConfigurationService
  ) {
  }

  ngOnInit(): void {

  }


  showMenuButtonShowHideMenuVertical(): boolean {
    return this.configService.showMenuButtonShowHideMenuVertical;
  }


  showChevron(): string {
    return this.showHideLeftSideMenuViaContentButton
    && this.menuService.showingLeftSideMenu ? 'fas fa-chevron-left' : 'fas fa-chevron-right';
  }

  showHideVerticalMenu(): void {
    console.log('toggle');
    this.menuService.toggleLeftSideMenu();
  }
}
