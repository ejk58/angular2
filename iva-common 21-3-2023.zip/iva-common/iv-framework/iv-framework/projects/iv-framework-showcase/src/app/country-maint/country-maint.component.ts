import {Component, OnInit} from '@angular/core';
import {AppDataService} from '../services/app-data.service';
import {Router} from '@angular/router';
import {Country} from '../view-models/country';
import {Observable} from 'rxjs';
import {UserApi} from 'iv-framework-lib';

@Component({
  selector: 'app-country-maint',
  templateUrl: './country-maint.component.html',
  styleUrls: ['./country-maint.component.css']
})
export class CountryMaintComponent implements OnInit {

  countries$: Observable<Country[]>;
  deleteError: string;
  deleteId: number;
  isDeleting = false;

  constructor(private dataService: AppDataService, private router: Router, private userApi: UserApi) {
    this.countries$ = dataService.getCountries();
  }

  cancelDelete() {
    this.isDeleting = false;
    this.deleteId = null;
  }

  ngOnInit(): void {
    this.countries$ = this.dataService.getCountries();
  }

  showCountryDetail(id: number) {
    this.router.navigate([this.userApi.getAuthenticatedRoute() + '/country-detail', id, 'details']);
  }

  createCountry() {
    this.router.navigate([this.userApi.getAuthenticatedRoute() + '/country-detail', 0, 'create' ]);
  }

  editCountry(id: number) {
    this.router.navigate([this.userApi.getAuthenticatedRoute() + '/country-detail', id, 'edit' ]);
  }

  deleteCountryQuestion(id: number) {
    this.deleteError = null;
    this.deleteId = id;
  }

  deleteCountry(id: number) {
    this.isDeleting = true;
    this.dataService.deleteCountry(id).subscribe(
      c => this.cancelDelete(),
      error => { this.deleteError = error; this.isDeleting = false; }
    );
  }
}
