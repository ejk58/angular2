import {Component} from '@angular/core';

@Component({
  selector: 'app-body-header',
  templateUrl: './body-header.component.html',
  styleUrls: ['./body-header.component.css']
})
export class BodyHeaderComponent {
  headerText = '== Body header ==';
}
