import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AuthenticatedUserComponent} from './authenticated-user/authenticated-user.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {SettingsComponent} from './settings/settings.component';
import {CountryMaintComponent} from './country-maint/country-maint.component';
import {CountryDetailComponent} from './country-detail/country-detail.component';
import {CountryListComponent} from './country-list/country-list.component';
import {DatapageComponent} from './datapage/datapage.component';
import {PATH_AUTHENTICATED, PATH_SIGN_IN} from './app.paths';
import {AuthGuard, SignInComponent} from 'iv-framework-lib';

const routes: Routes = [
  { path: PATH_SIGN_IN, component: SignInComponent },
  { path: PATH_AUTHENTICATED, component: AuthenticatedUserComponent, canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'datapage', component: DatapageComponent },
      { path: 'country-list/:count', component: CountryListComponent},
      { path: 'country-detail/:id/:operation', component: CountryDetailComponent},
      { path: 'country-maint', component: CountryMaintComponent},
      { path: 'settings', component: SettingsComponent },
    ]
  },
  { path: '', component: SignInComponent },
  { path: '**', component: SignInComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
