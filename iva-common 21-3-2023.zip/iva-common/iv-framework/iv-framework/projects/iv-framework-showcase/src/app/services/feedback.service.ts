import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {Feedback, FeedbackApi, VersionInformation} from 'iv-framework-lib';

@Injectable()
export class FeedbackService implements FeedbackApi{

  constructor() { }
  getVersionInformation(): Observable<VersionInformation> {
    return of({
      application: 'Klantbehandelsysteem',
      version: '0.0.1-SNAPSHOT',
      buildNumber: 'abcdef123456',
      buildTime: '30-09-2021 08:39:36'
    });
  }

  addFeedback(feedback: Feedback): Observable<Feedback> {
    console.log('Add feedback');
    return of(feedback);
  }

}
