import {Injectable} from '@angular/core';
import {Country} from '../view-models/country';
import {UserService} from './user.service';
import {Observable, of} from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AppDataService {

  countries: Array<Country> = [
    {id: 1, name:"Switzerland", epiIndex: 87.67},
    {id: 2, name:"Luxembourg", epiIndex: 83.29},
    {id: 3, name:"Australia", epiIndex: 82.4},
    {id: 4, name:"Singapore", epiIndex: 87.78},
    {id: 5, name:"Czech Republic", epiIndex: 81.47},
  ]

  constructor(private userService: UserService) {
  }

  getCountries(): Observable<any> {
    return of(this.countries)
  }

  getCountry(id: number): Observable<Country> {
    const country = this.countries.find(c => c.id == id);
    return of(country);
  }

  createCountry(vm: Country): Observable<any> {
    let id =0;
    this.countries.forEach(c => { if (c.id >= id) id = c.id+1 });
    vm.id = id;
    this.countries.push(vm);
    return of(vm);
  }

  deleteCountry(id: number): Observable<any> {
    return of(this.countries.splice(this.countries.findIndex(c => c.id == id), 1));
  }

  updateCountry(updatedCountry: Country): Observable<any> {
    const country = this.countries.find(c => c.id == updatedCountry.id);
    Object.assign(country, updatedCountry);
    return of(country);
  }

}
