import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {PATH_AUTHENTICATED, PATH_SIGN_IN} from '../app.paths';
import {UserApi} from 'iv-framework-lib';

@Injectable()
export class UserService implements UserApi {

  private static readonly KEY_USER = 'user';

  constructor() {
  }

  getSignInRoute(): string {
    return `/${PATH_SIGN_IN}`;
  }

  getAuthenticatedRoute(): string {
    return `/${PATH_AUTHENTICATED}`;
  }

  isSignedIn(): boolean {
    return this.getUsername() !== null;
  }

  getUsername(): string | null {
    return localStorage.getItem(UserService.KEY_USER);
  }

  /**
   * Example implementation:
   * <pre>
   * signIn(username: string, password: string): Observable<any> {
   *   return this.httpClient.post('/api/login', {username, password});
   * }
   * </pre>
   */
  signIn(username: string, password: string): Observable<any> {
    localStorage.setItem(UserService.KEY_USER, username);
    return of({});
  }

  /**
   * Example implementation:
   * <pre>
   * signOut(): Observable<any> {
   *   return this.httpClient.get('/api/logout');
   * }
   * </pre>
   */
  signOut(): Observable<any> {
    localStorage.removeItem(UserService.KEY_USER);
    return of({});
  }
}
