## 0.0.56
- upgrade to angular ^14.3.0
- Added header-sticky to framework-body / content to be used for content projection

## 0.0.54 (2023-01-02)
upgrade primeng to v14.

## 0.0.45 (2022-12-20)

Added aria-labelledBy in the menu-items to experiment with controling the menu=items by the Dragon software.

## 0.0.40 (2022-08-29)

### Features

Added body-header and body-footer to framework-body / content to be used
for content projection

## 0.0.34-6 (2022-03-23)

Due to problems with the Jenkins job, a version number has been skipped

### Features

Feedback form has two new parameters for max character limit for the message 
field and boolean for using either user id or combination of name and email.
Added missing modules.

## 0.0.28 (2021-10-27)

### Features

Added extra method to the feedback-api to be able to supply application information
The application information is show on the feeback screen
The application information is inserted into the feedback

### Bug Fixes

## 0.0.27 (2021-08-02)


### Features

When a menuoption is selected that contains a route the the browser will navigate to that page. (Unchanged)

When a menuoption is selected that contains a submenu then the browser wil navigate to the page indicates by the first menuoption from that submenu. (Changed)

When a menuoption is selected that contains a submenu and the first element of that submenu also contains a submenu then the browser will nog change the page. (Unchanged)


### Bug Fixes

. . . 
