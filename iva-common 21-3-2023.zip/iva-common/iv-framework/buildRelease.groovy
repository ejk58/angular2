#!groovy

def gitUser = 'jenkins'                             // nodig voor git commit config omdat die niet geconfigureerd is. Wordt vervangen door tool configuratie
def gitUserEmail = 'jenkins@belastingdienst.nl'     // idem

def gitUrl = scm.userRemoteConfigs[0].url
def gitBranch = scm.branches[0].name
if (gitBranch.startsWith("*/")) {
    gitBranch = gitBranch.substring(2)
}
echo "gitUrl: ${gitUrl}; gitBranch: ${gitBranch}"
def currentBranch = gitBranch

pipeline {
    agent { node { label 'nodejs14' } }
    options {
        disableConcurrentBuilds()
        timeout(time: 2, unit: 'HOURS')
    }
    parameters {
        choice(name: 'RELEASE_TYPE', choices: ['patch', 'minor', 'major'], description: 'Pick one')
    }
    environment {
        RELEASE_TYPE = "${params.RELEASE_TYPE}"
        GIT_USER = "${gitUser}"
        GIT_EMAIL = "${gitUserEmail}"
        GIT_BRANCH = "${currentBranch}"
    }
    stages {
        stage('NPM Install') {
            steps {
                dir("iv-framework") {
                    sh '''
                        export PATH=$PATH:/opt/node/bin
                        export NODE_TLS_REJECT_UNAUTHORIZED=0
                        npm config set strict-ssl false

                        node --version
                        npm --version
                        npm install --registry=https://nexus.belastingdienst.nl/nexus/repository/npm
                    '''
                }
            }
        }
        stage('NPM Release') {
            steps {
                dir("iv-framework") {
                    withCredentials([string(credentialsId: 'NEXUS_NPM_HOSTED_PUBLISH_KEY_SECRET', variable: 'TOKEN')]) {
                        script {
                            sh '''
                                export PATH=$PATH:/opt/node/bin
                                export NODE_TLS_REJECT_UNAUTHORIZED=0

                                npm config set registry https://nexus.belastingdienst.nl/nexus/repository/npm/
                                npm config set //nexus.belastingdienst.nl/nexus/repository/npm-hosted/:_authToken $TOKEN
                                npm config set user.email ${GIT_EMAIL}
                                npm config set user.name ${GIT_USER}

                                versionNumber=`grep \\"version\\": projects/iv-framework-lib/package.json | cut -d \\" -f4`
                                majorNr=`echo ${versionNumber} | cut -d . -f 1`
                                minorNr=`echo ${versionNumber} | cut -d . -f 2`
                                patchNr=`echo ${versionNumber} | cut -d . -f 3`
                                newMajorNr=${majorNr}
                                newMinorNr=${minorNr}
                                newPatchNr=${patchNr}
                                if [ ${RELEASE_TYPE} == 'major' ] ; then
                                    newMajorNr=$(( ${newMajorNr} + 1 ))
                                    newMinorNr=0
                                    newPatchNr=0
                                elif [ ${RELEASE_TYPE} == 'minor'  ] ; then
                                    newMinorNr=$(( ${newMinorNr} + 1 ))
                                    newPatchNr=0
                                else
                                    newPatchNr=$(( ${newPatchNr} + 1 ))
                                fi
                                newVersion=${newMajorNr}.${newMinorNr}.${newPatchNr}
                                echo Current version: ${versionNumber}, new version: ${newVersion}
                                sed -i "s/\\"version\\": \\"${versionNumber}\\"/\\"version\\": \\"${newVersion}\\"/" projects/iv-framework-lib/package.json
                                
                                npm run buildProd

                                cd dist/iv-framework-lib
                                npm publish
                                cd ../..

                                git config user.email ${GIT_EMAIL}
                                git config user.name ${GIT_USER}
                                git checkout ${GIT_BRANCH}
                                git status
                                git add projects/iv-framework-lib/package.json
                                git commit -m "Updated framework version to ${newVersion}"
                                git branch --set-upstream-to=origin/${GIT_BRANCH} ${GIT_BRANCH}
                                git pull
                                git push
                                git config user.email --unset
                                git config user.name --unset

                                npm config rm //nexus.belastingdienst.nl/nexus/repository/npm-hosted/:_authToken
                                npm config rm email

                            '''
                        }
                    }
                }
            }
        }
        // stage('merge to master'){
        //     steps {
        //         sh '''
        //             git checkout master
        //             git pull origin develop
        //             git push
        //         '''
        //     }
        // }
    }
}