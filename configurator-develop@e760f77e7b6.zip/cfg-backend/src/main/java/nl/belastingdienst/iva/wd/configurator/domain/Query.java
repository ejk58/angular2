package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "conf_query")
public class Query implements HasOwnerDomain {
    @Id
    private Integer id;

    private Integer type;
    private String viewname;
    private String querytemplate;
    private String key;

    @OneToMany()
    @JoinColumn(name = "QUERY_ID")
    @OrderBy(value = "index")
    private List<QueryColumn> columnList;

    @OneToMany()
    @JoinColumn(name = "QUERY_ID")
    private List<QueryFilter> queryFilterList;

    @OneToMany()
    @JoinColumn(name = "QUERY_ID")
    @OrderBy(value = "key")
    private List<QueryAttribute> queryAttributeList;

    @ManyToOne()
    @JoinColumn(name = "DATASOURCE_ID")
    private Datasource datasource;

    @ManyToOne()
    @JoinColumn(name = "OWNER_DOMAIN_ID")
    private Domain ownerDomain;
}
