package nl.belastingdienst.iva.wd.configurator.domain.robot;

public class RobotTestCheckNumberOfDataRecords {

    private RobotTestCheckNumberOfDataRecords() { throw new UnsupportedOperationException(); }

    public static String toRobot() {
        return
            "REST Check Number of Data Records\n" +
            "    [Tags]  REST\n" +
            "    REST Check Number Of Rows In Result  0\n";
    }

}

/*

REST Check Number of Data Records
    [Tags]  REST
    REST Check Number Of Rows In Result  35

 */
