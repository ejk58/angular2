package nl.belastingdienst.iva.wd.configurator;

import nl.belastingdienst.iva.wd.configurator.domain.HasOwnerDomain;
import nl.belastingdienst.iva.wd.configurator.security.JwtUtils;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import nl.belastingdienst.iva.wd.configurator.util.ControllerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.sql.DataSource;

@SpringBootApplication
@EnableScheduling
public class Application {

    @Autowired
    private Environment env;

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public LdapContextSource contextSource() {
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(env.getRequiredProperty("ldap.url"));
        contextSource.setUserDn(env.getRequiredProperty("ldap.user"));
        contextSource.setPassword(env.getRequiredProperty("ldap.password"));
        return contextSource;
    }

    @Bean
    public LdapTemplate ldapTemplate() {
        return new LdapTemplate(contextSource());
    }

    @Bean(name = "datasource_db2")
    @ConfigurationProperties("spring.datasource")
    @Primary
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "datasource_td")
    @ConfigurationProperties("spring.td.datasource")
    public DataSource dataSourceTD() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    JdbcTemplate jdbcTemplate() {
        return new JdbcTemplate(dataSourceTD());
    }

    @Bean
    NamedParameterJdbcTemplate namedJdbcTemplateConfigurator() {
        return new NamedParameterJdbcTemplate(dataSource());
    }

    @Bean
    public ConversionService conversionService() {
        return new DefaultConversionService();
    }

    @Bean
    public ApplicationUtils applicationUtils() {
        return new ApplicationUtils();
    }

    @Bean
    public ControllerUtils<HasOwnerDomain> controllerUtils() {
        return new ControllerUtils<>();
    }

    @Bean
    public JwtUtils jwtUtils() {
        return new JwtUtils(env);
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
