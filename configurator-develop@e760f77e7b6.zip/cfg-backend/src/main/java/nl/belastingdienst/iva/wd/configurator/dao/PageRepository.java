package nl.belastingdienst.iva.wd.configurator.dao;

import nl.belastingdienst.iva.wd.configurator.domain.Page;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PageRepository extends CrudRepository<Page, Integer> {
    Page findByKey(String key);

    @Query("SELECT DISTINCT page.key FROM Page page ORDER BY page.key ASC")
    List<String> findAllPageKeysOrderByNameAsc();

    @Query("SELECT page.key FROM Page page JOIN page.ownerDomain domain WHERE domain.key = :domainkey ORDER BY page.key ASC")
    List<String> findAllAllowedPageKeysOrderByNameAsc(@Param("domainkey") String domainKey);

    @Query("SELECT page.key FROM PageDomain pageDomain LEFT JOIN pageDomain.page page LEFT JOIN pageDomain.domain domain WHERE domain.key = :domainKey and page.ownerDomain IS NULL ORDER BY page.key ASC")
    List<String> findGenericPageKeysForDomainOrderByNameAsc(@Param("domainKey") String domainKey);

}
