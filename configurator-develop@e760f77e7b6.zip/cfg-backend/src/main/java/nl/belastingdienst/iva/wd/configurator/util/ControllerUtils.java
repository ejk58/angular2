package nl.belastingdienst.iva.wd.configurator.util;

import nl.belastingdienst.iva.wd.configurator.constants.DomainConstants;
import nl.belastingdienst.iva.wd.configurator.domain.HasOwnerDomain;
import nl.belastingdienst.iva.wd.configurator.domain.exception.NotAllowedDomainChangeException;

public class ControllerUtils<T extends HasOwnerDomain> {

    public void checkForNotAllowedDomainChange(T objectBeforeMutation, String currentDomainKey) {
        if (objectBeforeMutation != null) {
            String originalDomainKey = objectBeforeMutation.getOwnerDomain() != null ? objectBeforeMutation.getOwnerDomain().getKey() : null;
            if (DomainConstants.ADMIN.equals(currentDomainKey)) {
                if (originalDomainKey != null) {
                    throw new NotAllowedDomainChangeException();
                }
            } else {
                if (!currentDomainKey.equals(originalDomainKey)) {
                    throw new NotAllowedDomainChangeException();
                }
            }
        }
    }


}
