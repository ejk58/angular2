package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "CONF_DOMAIN_MENUGROUP")
public class DomainMenugroup {
    @Id
    private int id;

    private Integer index;
    private String title;
    private String iconname;
}
