package nl.belastingdienst.iva.wd.configurator.dao;

import nl.belastingdienst.iva.wd.configurator.domain.WidgetAttribute;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface WidgetAttributeRepository extends CrudRepository<WidgetAttribute, Long> {

    @Query("SELECT DISTINCT widgetAttribute.key FROM WidgetAttribute widgetAttribute ORDER BY widgetAttribute.key ASC")
    List<String> findAllWidgetAttributeKeysByOrderByKeyAsc();
}
