package nl.belastingdienst.iva.wd.configurator.filter;

import nl.belastingdienst.iva.wd.configurator.exception.GlobalExceptionHandler;
import nl.belastingdienst.iva.wd.configurator.security.WebSecurity;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Class with which errors that occur in a filter can still be handled by {@link GlobalExceptionHandler},
 * whereas that class normally only handles errors from controllers because it is annotated with '@RestControllerAdvice'.
 * The class itself is also a filter that must be executed before any other filter (see {@link WebSecurity}).
 */
public class FilterExceptionHandlerFilter extends OncePerRequestFilter {

    private static final Logger LOGGER = LogManager.getLogger(FilterExceptionHandlerFilter.class);
    private final HandlerExceptionResolver handlerExceptionResolver;

    public FilterExceptionHandlerFilter(HandlerExceptionResolver handlerExceptionResolver) {
        this.handlerExceptionResolver = handlerExceptionResolver;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
        try {
            filterChain.doFilter(request, response);
        } catch (Exception e) {
            LOGGER.error("Er is een fout opgetreden in een filter:", e);
            handlerExceptionResolver.resolveException(request, response, null, e);
        }
    }
}
