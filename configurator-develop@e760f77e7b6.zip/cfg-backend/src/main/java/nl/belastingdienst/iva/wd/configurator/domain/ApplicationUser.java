package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Data;

@Data
//@Entity
public class ApplicationUser {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String username;
    private String password;
}

