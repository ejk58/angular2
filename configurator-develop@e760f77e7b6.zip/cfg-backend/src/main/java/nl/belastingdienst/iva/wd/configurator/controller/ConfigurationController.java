package nl.belastingdienst.iva.wd.configurator.controller;

import nl.belastingdienst.iva.wd.configurator.dao.DomainRepository;
import nl.belastingdienst.iva.wd.configurator.dao.PageRepository;
import nl.belastingdienst.iva.wd.configurator.dao.PageWidgetRepository;
import nl.belastingdienst.iva.wd.configurator.dao.WidgetRepository;
import nl.belastingdienst.iva.wd.configurator.domain.*;
import nl.belastingdienst.iva.wd.configurator.factory.*;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/configuration")
public class ConfigurationController {

    @Autowired
    private DomainRepository domainRepository;

    @Autowired
    private WidgetRepository widgetRepository;

    @Autowired
    private PageRepository pageRepository;

    @Autowired
    private PageWidgetRepository pageWidgetRepository;

    @Autowired
    private ConfigurationSqlFactory configurationSqlFactory;

    @Autowired
    private DomainSqlFactory domainSqlFactory;

    @Autowired
    private QuerySqlFactory querySqlFactory;

    @Autowired
    private WidgetSqlFactory widgetSqlFactory;

    @Autowired
    private PageSqlFactory pageSqlFactory;

    @Autowired
    private ApplicationUtils applicationUtils;

    @GetMapping(value = "/export/{domainId}")
    public ResponseEntity<String[]> getDomainConfiguration(@PathVariable String domainId) {
        if (!applicationUtils.userHasAccessToDomain(domainId)) {
            throw new AccessDeniedException(domainId);
        }
        StringBuilder resultSql = new StringBuilder();
        resultSql.append(getConfigurationInitiateSql(domainId));
        resultSql.append(getDomainSql(domainId));
        resultSql.append(getWidgetsSql(domainId));
        resultSql.append(getPagesSql(domainId));
        String[] sql = new String[]{resultSql.toString()};
        return ResponseEntity.ok(sql);
    }

    private StringBuilder getConfigurationInitiateSql(String domainId) {
        StringBuilder resultSql = new StringBuilder(getSectionCommentLine("INIT SQL"));
        resultSql.append(configurationSqlFactory.getDeleteScript(domainId));
        return resultSql;
    }

    private StringBuilder getDomainSql(String domainId) {
        StringBuilder resultSql = new StringBuilder(getSectionCommentLine("DOMAIN"));
        Domain domain = domainRepository.findByKey(domainId);

        // domain queries
        resultSql.append(getDomainQuerySql(domain.getSubjectQuery()));
        resultSql.append(getDomainQuerySql(domain.getRelationVipQuery()));
        resultSql.append(getDomainQuerySql(domain.getRelationNoVipQuery()));
        resultSql.append(getDomainQuerySql(domain.getSearchVipQuery()));
        resultSql.append(getDomainQuerySql(domain.getSearchNoVipQuery()));

        resultSql.append(domainSqlFactory.getInsertScript(domain));

        return resultSql;
    }

    private String getDomainQuerySql(Query query) {
        if (query != null && query.getOwnerDomain() != null) {
            return querySqlFactory.getInsertScript(query);
        }
        return "";
    }

    private StringBuilder getWidgetsSql(String domainId) {
        StringBuilder resultSql = new StringBuilder(getSectionCommentLine("WIDGETS & QUERIES"));

        // all widgets without a parent container defined are single widgets or container widgets
        List<String> widgetNames = widgetRepository.findAllWidgetNamesWithoutParentContainerForDomainOrderByNameAsc(domainId);

        for (String widgetName : widgetNames) {
            Widget widget = widgetRepository.findByName(widgetName);
            resultSql.append(widgetSqlFactory.getInsertScript(widget, domainId));
        }
        return resultSql;
    }

    private StringBuilder getPagesSql(String domainId) {
        StringBuilder resultSql = new StringBuilder(getSectionCommentLine("PAGES"));

        List<String> pageKeys = pageRepository.findAllAllowedPageKeysOrderByNameAsc(domainId);
        for (String pageKey : pageKeys) {
            Page page = pageRepository.findByKey(pageKey);
            List<PageWidget> widgets = pageWidgetRepository.findByPage(page);
            resultSql.append(pageSqlFactory.getInsertScript(page, widgets));
        }

        // Add generic pages used for this domain
        pageKeys = pageRepository.findGenericPageKeysForDomainOrderByNameAsc(domainId);
        for (String pageKey : pageKeys) {
            Page page = pageRepository.findByKey(pageKey);
            resultSql.append(pageSqlFactory.getInsertScriptGenericPage(page, domainId));
        }
        return resultSql;
    }

    private String getSectionCommentLine(String sectionName) {
        String SECTION_COMMENT_LINE = "-- %1$s------------------------------------------------------------------------------------------------\n\n";
        String extendedSectionName = sectionName;
        if (sectionName.length() < 25) {
            extendedSectionName = (sectionName + " -------------------------").substring(0, 25);
        }
        return String.format(SECTION_COMMENT_LINE, extendedSectionName);
    }
}
