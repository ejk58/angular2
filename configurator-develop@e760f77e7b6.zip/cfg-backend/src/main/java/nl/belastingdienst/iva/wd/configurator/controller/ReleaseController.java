package nl.belastingdienst.iva.wd.configurator.controller;

import nl.belastingdienst.iva.wd.configurator.datasource.configurator.ConfiguratorChangeRepository;
import nl.belastingdienst.iva.wd.configurator.datasource.configurator.ConfiguratorReleaseEnvironmentRepository;
import nl.belastingdienst.iva.wd.configurator.datasource.configurator.ConfiguratorReleaseRepository;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.*;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ReleaseInsertFailedException;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ReleaseRollbackFailedException;
import nl.belastingdienst.iva.wd.configurator.dto.GroupDomainDto;
import nl.belastingdienst.iva.wd.configurator.dto.ReleaseRollbackDto;
import nl.belastingdienst.iva.wd.configurator.dto.ReleaseRolloutDto;
import nl.belastingdienst.iva.wd.configurator.exception.ResponseMessages;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/api/release")
public class ReleaseController {

    @Autowired
    private ConfiguratorReleaseRepository configuratorReleaseRepository;

    @Autowired
    private ConfiguratorReleaseEnvironmentRepository configuratorReleaseEnvironmentRepository;

    @Autowired
    private ConfiguratorChangeRepository configuratorChangeRepository;

    @Autowired
    private ApplicationUtils applicationUtils;

    @GetMapping(value = "/notDeployed/{domainKey}")
    public ResponseEntity<List<Release>> getReleasesNotDeployedForDomain(@PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }
        List<Release> releases = configuratorReleaseRepository.getReleasesNotDeployed(domainKey);
        return ResponseEntity.ok(releases);
    }

    @GetMapping(value = "/deployed")
    public ResponseEntity<List<ReleaseEnvironment>> getReleaseDeployed() {
        List<String> domainKeys = applicationUtils.getDomainList().stream().map(GroupDomainDto::getDomainId).collect(Collectors.toList());
        List<ReleaseEnvironment> releaseEnvironments = configuratorReleaseEnvironmentRepository.getReleaseEnvironments(domainKeys);
        return ResponseEntity.ok(releaseEnvironments);
    }

    @GetMapping(value = "/allReleaseTags")
    public ResponseEntity<List<String>> getAllReleaseTags() {
        List<String> allReleaseTags = configuratorReleaseRepository.getAllReleaseTags();
        return ResponseEntity.ok(allReleaseTags);
    }

    @GetMapping(value = "/rolloutInfo/{environmentname}/{domainKey}")
    public ResponseEntity<ReleaseRolloutInfo> getReleaseRolloutInfoForEnvironmentAndDomain(@PathVariable String environmentname, @PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }

        ReleaseRolloutInfo releaseRolloutInfo = new ReleaseRolloutInfo();
        Release currentRelease = configuratorReleaseRepository.getCurrentRelease(domainKey, environmentname);
        Release nextRelease = configuratorReleaseRepository.getNextRelease(domainKey, environmentname);
        if (currentRelease != null) {
            releaseRolloutInfo.setCurrentRelease(currentRelease);
        }
        if (nextRelease != null) {
            releaseRolloutInfo.setNextRelease(nextRelease);
        }
        return ResponseEntity.ok(releaseRolloutInfo);
    }

    @GetMapping(value = "/currentRelease/{environmentname}/{domainKey}")
    public ResponseEntity<Release> getCurrentReleaseForEnvironmentAndDomain(@PathVariable String environmentname, @PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }

        Release currentRelease = configuratorReleaseRepository.getCurrentRelease(domainKey, environmentname);
        return ResponseEntity.ok(currentRelease);
    }

    @Transactional
    @PostMapping(value = "/save")
    public ResponseEntity<String> saveRelease(@RequestBody ReleaseAndChanges releaseAndChanges) {
        GroupDomainDto groupDomain = releaseAndChanges.getGroupDomain();
        if (!applicationUtils.userHasAccessToDomain(groupDomain.getDomainId())) {
            throw new AccessDeniedException(groupDomain.getDomainName());
        }

        if (configuratorReleaseRepository.checkUniqueReleaseTag(releaseAndChanges.getRelease().getTag())) {
            releaseAndChanges.getRelease().setDomainKey(groupDomain.getDomainId());
            releaseAndChanges.getRelease().setAdministrator(applicationUtils.getUserId());
            releaseAndChanges.getRelease().setDate(new Date());
            configuratorReleaseRepository.saveRelease(releaseAndChanges.getRelease());

            for (Change change : releaseAndChanges.getChanges()) {
                configuratorChangeRepository.saveChangeReleaseId(change, releaseAndChanges.getRelease().getTag());
            }

            return ResponseEntity.ok(ResponseMessages.OK);
        }

        throw new ReleaseInsertFailedException(ResponseMessages.RELEASE_EXISTS);
    }

    @Transactional
    @DeleteMapping(value = "/delete/{releaseId}")
    public ResponseEntity<String> deleteRelease(@PathVariable Integer releaseId) {
        configuratorReleaseRepository.deleteRelease(releaseId);
        return ResponseEntity.ok(ResponseMessages.RELEASE_DELETE_OK);
    }

    @Transactional
    @PostMapping(value = "/rollout")
    public ResponseEntity<String> rolloutRelease(@RequestBody ReleaseRolloutDto releaseRolloutDto) throws SQLException {
        GroupDomainDto groupDomain = releaseRolloutDto.getGroupDomain();
        if (!applicationUtils.userHasAccessToDomain(groupDomain.getDomainId())) {
            throw new AccessDeniedException(groupDomain.getDomainName());
        }

        String environmentName = releaseRolloutDto.getEnvironment();
        String releaseTag = releaseRolloutDto.getReleaseRolloutInfo().getNextRelease().getTag();
        String domainKey = groupDomain.getDomainId();
        DbConnection dbConnection = createDbConnection(environmentName);
        ConfigurationLog configurationLog = createConfigurationLog(domainKey, releaseTag);
        List<Change> changes = configuratorChangeRepository.getChangesOfRelease(domainKey, releaseTag);

        return handleRolloutRelease(dbConnection, environmentName, changes, configurationLog);
    }

    @Transactional
    @PostMapping(value = "/rollback")
    public ResponseEntity<String> rollbackRelease(@RequestBody ReleaseRollbackDto releaseRollbackDto) throws SQLException {
        GroupDomainDto groupDomain = releaseRollbackDto.getGroupDomain();
        if (!applicationUtils.userHasAccessToDomain(groupDomain.getDomainId())) {
            throw new AccessDeniedException(groupDomain.getDomainName());
        }

        String environmentName = releaseRollbackDto.getEnvironment();
        String releaseTag = releaseRollbackDto.getCurrentRelease().getTag();
        String domainKey = groupDomain.getDomainId();

        Release currentRelease = configuratorReleaseRepository.getCurrentRelease(domainKey, environmentName);
        if (currentRelease == null) {
            throw new ReleaseRollbackFailedException(ResponseMessages.RELEASE_NOT_EXISTS);
        }
        if (!releaseRollbackDto.getCurrentRelease().getId().equals(currentRelease.getId())) {
            throw new ReleaseRollbackFailedException(ResponseMessages.RELEASE_NOT_MOST_RECENT);
        }

        DbConnection dbConnection = createDbConnection(environmentName);
        ConfigurationLog configurationLog = createConfigurationLog(domainKey, releaseTag);
        List<Change> changes = configuratorChangeRepository.getChangesOfReleaseInReverseOrder(domainKey, releaseTag);

        return handleRollbackRelease(dbConnection, changes, configurationLog);
    }

    private ResponseEntity<String> handleRolloutRelease(DbConnection dbConnection, String environmentName, List<Change> changes, ConfigurationLog configurationLog) throws SQLException {
        configuratorReleaseRepository.rolloutRelease(dbConnection.getConnection(), dbConnection.getDbSchema(), changes, configurationLog);
        configuratorReleaseEnvironmentRepository.saveReleaseRollout(configurationLog, environmentName);
        return ResponseEntity.ok(ResponseMessages.RELEASE_ROLLOUT_OK);
    }

    private ResponseEntity<String> handleRollbackRelease(DbConnection dbConnection, List<Change> changes, ConfigurationLog configurationLog) throws SQLException {
        configuratorReleaseRepository.rollbackRelease(dbConnection.getConnection(), dbConnection.getDbSchema(), changes, configurationLog);
        configuratorReleaseEnvironmentRepository.deleteReleaseRollout(configurationLog);
        return ResponseEntity.ok(ResponseMessages.RELEASE_ROLLBACK_OK);
    }

    private DbConnection createDbConnection(String environmentName) throws SQLException {
        String schemaKey;
        String datasourceKey;
        if (environmentName.contains(".")) {
            String[] environmentPart = StringUtils.split(environmentName, ".");
            datasourceKey = environmentPart != null ? environmentPart[0] : "";
            schemaKey = environmentPart != null ? environmentPart[1] + "_schema" : "";
        } else {
            datasourceKey = environmentName;
            schemaKey = environmentName + "_schema";
        }
        DbConnection dbConnection = new DbConnection();
        dbConnection.setConnection(applicationUtils.getConnectionForEnvironment(datasourceKey));
        dbConnection.setDbSchema(applicationUtils.getDatabaseSchema(schemaKey));
        return dbConnection;
    }

    private ConfigurationLog createConfigurationLog(String domainKey, String releaseTag) {
        ConfigurationLog configurationLog = new ConfigurationLog();
        configurationLog.setDomainKey(domainKey);
        configurationLog.setReleaseTag(releaseTag);
        configurationLog.setAdministratorname(applicationUtils.getUserId());
        configurationLog.setDate(new Date());
        return configurationLog;
    }
}
