package nl.belastingdienst.iva.wd.configurator.datasource.configurator;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ConfiguratorEnvironmentRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedJdbcTemplateConfigurator;

    @Value("${configurator.db.schema}")
    private String schema;

    public List<Environment> getEnvironments() {
        String sql = "SELECT * FROM " + schema + ".environment ORDER BY NAME";
        return namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Environment.class));
    }

}
