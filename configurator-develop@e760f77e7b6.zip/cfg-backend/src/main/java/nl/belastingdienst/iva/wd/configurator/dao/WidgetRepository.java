package nl.belastingdienst.iva.wd.configurator.dao;

import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WidgetRepository extends CrudRepository<Widget, Long> {
    Widget findByName(String name);

    @Query("SELECT DISTINCT widget.type FROM Widget widget ORDER BY widget.type ASC")
    List<String> findAllWidgetTypesByOrderByTypeAsc();

    @Query("SELECT DISTINCT widget.name FROM Widget widget ORDER BY widget.name ASC")
    List<String> findAllWidgetNamesByOrderByNameAsc();

    @Query("SELECT widget FROM Widget widget WHERE widget.name = :widgetName")
    Widget findWidgetByName(@Param("widgetName") String widgetName);

    @Query("SELECT widget.name FROM Widget widget JOIN widget.ownerDomain domain WHERE domain.key = :domainKey ORDER BY widget.name ASC")
    List<String> findAllWidgetNamesForDomainOrderByNameAsc(@Param("domainKey") String domainKey);

    @Query("SELECT widget.name FROM Widget widget JOIN widget.ownerDomain domain WHERE domain.key = :domainKey AND widget.containerWidget IS NULL ORDER BY widget.name ASC")
    List<String> findAllWidgetNamesWithoutParentContainerForDomainOrderByNameAsc(@Param("domainKey") String domainKey);

    @Query("SELECT widget.name FROM Widget widget LEFT JOIN widget.ownerDomain domain WHERE (domain.key = :domainKey OR widget.ownerDomain IS NULL) ORDER BY widget.name ASC")
    List<String> findAllWidgetNamesForDomainAndGenericOrderByNameAsc(@Param("domainKey") String domainKey);

    @Query("SELECT widget.name FROM Widget widget WHERE widget.ownerDomain IS NULL ORDER BY widget.name ASC")
    List<String> findAllWidgetNamesForGenericOrderByNameAsc();
}
