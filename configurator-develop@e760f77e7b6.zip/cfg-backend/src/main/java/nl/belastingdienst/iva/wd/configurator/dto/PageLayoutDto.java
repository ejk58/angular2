package nl.belastingdienst.iva.wd.configurator.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import nl.belastingdienst.iva.wd.configurator.domain.Page;
import nl.belastingdienst.iva.wd.configurator.domain.PageWidget;

import java.util.List;

@Data
@Getter
@Setter
public class PageLayoutDto {

    private Page page;
    private List<PageWidget> initialWidgets;
    private List<PageWidget> widgets;
    private GroupDomainDto groupDomain;
    private String tag;

    public PageLayoutDto(Page page, List<PageWidget> initialWidgets, List<PageWidget> widgets, String tag) {
        this.page = page;
        this.initialWidgets = initialWidgets;
        this.widgets = widgets;
        this.tag = tag;
    }
}
