package nl.belastingdienst.iva.wd.configurator.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "CONF_WIDGET")
public class Widget implements HasOwnerDomain {

    @Id
    private Integer id;
    private Integer index;
    private String name;
    private String type;
    private String title;
    private String description;
    private boolean refreshinfo;
    private boolean visible;

    @OneToOne()
    @JoinColumn(name = "QUERY_ID")
    private Query query;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RULE_GROUP_ID")
    private RuleGroup ruleGroup;

    @OneToMany()
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "rowIndex, columnIndex")
    @JsonBackReference
    private List<PageWidget> pageWidgetList;

    @OneToMany()
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "key")
    private List<WidgetAttribute> attributeList;

    @OneToMany()
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "index")
    private List<WidgetColumn> columnList;

    @ManyToOne()
    @JoinColumn(name = "CONTAINER_WIDGET_ID")
    private Widget containerWidget;

    @OneToMany()
    @JoinColumn(name = "CONTAINER_WIDGET_ID")
    @OrderBy(value = "index")
    private List<Widget> widgetList;

    @OneToMany()
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "index")
    private List<WidgetHelp> helpList;

    @ManyToOne()
    @JoinColumn(name = "OWNER_DOMAIN_ID")
    private Domain ownerDomain;
}
