package nl.belastingdienst.iva.wd.configurator.controller;

import nl.belastingdienst.iva.wd.configurator.constants.DomainConstants;
import nl.belastingdienst.iva.wd.configurator.dao.PageRepository;
import nl.belastingdienst.iva.wd.configurator.dao.PageWidgetRepository;
import nl.belastingdienst.iva.wd.configurator.domain.Domain;
import nl.belastingdienst.iva.wd.configurator.domain.HasOwnerDomain;
import nl.belastingdienst.iva.wd.configurator.domain.Page;
import nl.belastingdienst.iva.wd.configurator.domain.PageWidget;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ChangeInsertFailedException;
import nl.belastingdienst.iva.wd.configurator.dto.PageDto;
import nl.belastingdienst.iva.wd.configurator.dto.PageLayoutDto;
import nl.belastingdienst.iva.wd.configurator.exception.ResponseMessages;
import nl.belastingdienst.iva.wd.configurator.factory.PageSqlFactory;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import nl.belastingdienst.iva.wd.configurator.util.ControllerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/page")
public class PageController extends AbstractController {

    @Autowired
    private PageRepository pageRepository;

    @Autowired
    private PageWidgetRepository pageWidgetRepository;

    @Autowired
    private PageSqlFactory pageSqlFactory;

    @Autowired
    private ApplicationUtils applicationUtils;

    @Autowired
    private ControllerUtils<HasOwnerDomain> controllerUtils;

    @GetMapping(value = "/keys")
    public ResponseEntity<List<String>> getAllPageKeys() {
        List<String> pageKeys = pageRepository.findAllPageKeysOrderByNameAsc();

        return ResponseEntity.ok(pageKeys);
    }

    @GetMapping(value = "/keys/{domainKey}")
    public ResponseEntity<List<String>> getPageKeysForDomain(@PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }
        List<String> pageKeys = pageRepository.findAllAllowedPageKeysOrderByNameAsc(domainKey);

        return ResponseEntity.ok(pageKeys);
    }

    @GetMapping(value = "/{pageKey}")
    public ResponseEntity<PageDto> getPage(@PathVariable String pageKey) {
        Page page = pageRepository.findByKey(pageKey);
        List<PageWidget> pageWidgetList = pageWidgetRepository.findByPage(page);
        PageDto pageDto = new PageDto(page.getKey(), page.getTitle(), pageWidgetList, page.getType());
        return ResponseEntity.ok(pageDto);
    }

    @GetMapping(value = "/layout/{pageKey}")
    public ResponseEntity<PageLayoutDto> getPageLayout(@PathVariable String pageKey) {
        Page page = pageRepository.findByKey(pageKey);

        // to avoid (deep) cloning we get the data 2 times.
        List<PageWidget> initialWidgets = pageWidgetRepository.findByPage(page);
        List<PageWidget> widgets = pageWidgetRepository.findByPage(page);

        PageLayoutDto pageLayoutDto = new PageLayoutDto(page, initialWidgets, widgets, "");
        return ResponseEntity.ok(pageLayoutDto);
    }

    @Transactional
    @PostMapping(value = "/changeLayout")
    public ResponseEntity<String> changePageLayout(@RequestBody PageLayoutDto pageLayoutDto) throws SQLException {
        if (!applicationUtils.userHasAccessToDomain(pageLayoutDto.getGroupDomain().getDomainId())) {
            throw new AccessDeniedException(pageLayoutDto.getGroupDomain().getDomainName());
        }
        if (configuratorChangeRepository.checkUniqueChangeTag(pageLayoutDto.getTag())) {
            // Setting the domain for the page is done in the backend for security reasons
            pageLayoutDto.getPage().setOwnerDomain(createDomain(pageLayoutDto.getGroupDomain().getDomainId()));
            Change change = createAndStoreChangeForChangedPageLayout(pageLayoutDto);
            return handleRolloutChangeOnSourceDatabase(change);
        }
        throw new ChangeInsertFailedException(ResponseMessages.CHANGE_EXISTS);
    }

    @Transactional
    @PostMapping(value = "/new")
    public ResponseEntity<String> newPage(@RequestBody PageDto pageDto) throws SQLException {
        if (!applicationUtils.userHasAccessToDomain(pageDto.getGroupDomain().getDomainId())) {
            throw new AccessDeniedException(pageDto.getGroupDomain().getDomainName());
        }
        if (configuratorChangeRepository.checkUniqueChangeTag(pageDto.getTag())) {
            Change change = createAndStoreChangeForNewPage(pageDto);
            return handleRolloutChangeOnSourceDatabase(change);
        }
        throw new ChangeInsertFailedException(ResponseMessages.CHANGE_EXISTS);
    }

    private Domain createDomain(String key) {
        Domain domain = new Domain();
        domain.setKey(key);
        return key.equals(DomainConstants.ADMIN) ? null : domain;
    }

    private Change createAndStoreChangeForNewPage(PageDto pageDto) {
        Page page = createPage(pageDto);
        Change change = new Change();
        change.setDomain(pageDto.getGroupDomain().getDomainName());
        change.setDomainKey(pageDto.getGroupDomain().getDomainId());
        change.setTag(pageDto.getTag());
        change.setSequenceNo(new Date().getTime()); // - Sequence number is now just the timestamp so more or less redundant with the date.
        change.setAdministrator(applicationUtils.getUserId());
        change.setDate(new Date());
        change.setSql(pageDto.getWidgets() == null ? pageSqlFactory.getInsertScript(page, new ArrayList<>()) : pageSqlFactory.getInsertScript(page, pageDto.getWidgets()));
        change.setRollbackSql(pageSqlFactory.getDeleteScript(page));
        configuratorChangeRepository.saveChange(change);
        return change;
    }

    private Page createPage(PageDto pageDto) {
        Page page = new Page();
        page.setKey(pageDto.getKey());
        page.setTitle(pageDto.getTitle());
        page.setType(pageDto.getType());
        // Setting the domain for the page is done in the backend for security reasons
        page.setOwnerDomain(createDomain(pageDto.getGroupDomain().getDomainId()));
        return page;
    }

    private Change createAndStoreChangeForChangedPageLayout(PageLayoutDto pageLayoutDto) {
        Page pageOriginal = pageRepository.findByKey(pageLayoutDto.getPage().getKey());
        this.controllerUtils.checkForNotAllowedDomainChange(pageOriginal, pageLayoutDto.getGroupDomain().getDomainId());

        Change change = new Change();
        change.setDomain(pageLayoutDto.getGroupDomain().getDomainName());
        change.setDomainKey(pageLayoutDto.getGroupDomain().getDomainId());
        change.setTag(pageLayoutDto.getTag());
        change.setSequenceNo(new Date().getTime()); // - Sequence number is now just the timestamp so more or less redundant with the date.
        change.setAdministrator(applicationUtils.getUserId());
        change.setDate(new Date());
        change.setSql(createPageWidgetsSqlStatements(pageLayoutDto.getPage().getKey(), pageLayoutDto.getWidgets()));
        change.setRollbackSql(createPageWidgetsSqlStatements(pageLayoutDto.getPage().getKey(), pageLayoutDto.getInitialWidgets()));
        configuratorChangeRepository.saveChange(change);
        return change;
    }

    private String createPageWidgetsSqlStatements(String pageKey, List<PageWidget> pageWidgetList) {
        return this.pageSqlFactory.getUpdateScript(pageKey, pageWidgetList);
    }

}
