package nl.belastingdienst.iva.wd.configurator.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CONF_PAGE_WIDGET")
public class PageWidget {

    @Id
    private Integer id;

    @Column(name = "GRID_COLUMNS")
    private Integer gridColumns;

    @Column(name = "ROW_INDEX")
    private Integer rowIndex;

    @Column(name = "COLUMN_INDEX")
    private Integer columnIndex;

    @ManyToOne()
    @JoinColumn(name = "PAGE_ID")
    private Page page;

    @ManyToOne()
    @JoinColumn(name = "WIDGET_ID")
    @JsonIgnoreProperties("widgetList")
    private Widget widget;
}
