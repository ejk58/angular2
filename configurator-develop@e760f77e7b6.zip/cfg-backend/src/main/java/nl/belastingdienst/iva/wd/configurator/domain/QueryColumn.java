package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;
import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "CONF_QUERY_COLUMN")
public class QueryColumn {

    @Id
    private Integer id;
    private Integer query_id;
    private Integer composite_column_id;

    private Integer index;
    private String name;
    private String alias;
    private String value;
    private String key;
    private String type;
    private boolean maskable;

    @OneToMany
    @JoinColumn(name = "COMPOSITE_COLUMN_ID")
    @OrderBy(value = "index")
    private List<QueryColumn> columnList;
}
