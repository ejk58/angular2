package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.*;
import nl.belastingdienst.iva.wd.configurator.util.ExportUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public class DomainSqlFactory {

    private static final String CONF_QUERY = "CONF_QUERY";
    private static final String CONF_DOMAIN = "CONF_DOMAIN";

    public String getInsertScript(Domain domain) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- Domain " + domain.getKey() + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("MERGE INTO \"CONF_DOMAIN\" AS D USING (VALUES (");
        sqlBuilder.append(ExportUtils.getString(domain.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domain.getName()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domain.getIconname()) + ", ");
        sqlBuilder.append(domain.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_QUERY, "KEY", getQueryKey(domain.getSubjectQuery())) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_QUERY, "KEY", getQueryKey(domain.getRelationVipQuery())) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_QUERY, "KEY", getQueryKey(domain.getRelationNoVipQuery())) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_QUERY, "KEY", getQueryKey(domain.getSearchVipQuery())) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_QUERY, "KEY", getQueryKey(domain.getSearchNoVipQuery())));

        sqlBuilder.append(")) AS X(KEY, NAME, ICONNAME, INDEX, SUBJECT_QUERY_ID, RELATION_VIP_QUERY_ID, RELATION_NOVIP_QUERY_ID, SEARCH_VIP_QUERY_ID, SEARCH_NOVIP_QUERY_ID) ON D.KEY = X.KEY" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN MATCHED THEN UPDATE SET KEY = X.KEY, NAME = X.NAME, ICONNAME = X.ICONNAME, INDEX = X.INDEX, SUBJECT_QUERY_ID = X.SUBJECT_QUERY_ID, RELATION_VIP_QUERY_ID = X.RELATION_VIP_QUERY_ID, RELATION_NOVIP_QUERY_ID = X.RELATION_NOVIP_QUERY_ID, SEARCH_VIP_QUERY_ID = X.SEARCH_VIP_QUERY_ID, SEARCH_NOVIP_QUERY_ID = X.SEARCH_NOVIP_QUERY_ID" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN NOT MATCHED THEN INSERT (KEY, NAME, ICONNAME, INDEX, SUBJECT_QUERY_ID, RELATION_VIP_QUERY_ID, RELATION_NOVIP_QUERY_ID, SEARCH_VIP_QUERY_ID, SEARCH_NOVIP_QUERY_ID) VALUES (X.KEY, X.NAME, X.ICONNAME, X.INDEX, X.SUBJECT_QUERY_ID, X.RELATION_VIP_QUERY_ID, X.RELATION_NOVIP_QUERY_ID, X.SEARCH_VIP_QUERY_ID, X.SEARCH_NOVIP_QUERY_ID);" + SqlFactoryConstants.NEWLINE);

        sqlBuilder.append(getInsertScriptForDomainProperties(domain));

        sqlBuilder.append(getDomainQueryUpdateScript(domain));

        return sqlBuilder.toString();
    }

    private String getDomainQueryUpdateScript(Domain domain) {
        StringBuilder sqlBuilder = new StringBuilder();
        ArrayList<String> keyList = new ArrayList<>();
        addDomainQueryKey(domain.getSubjectQuery(), keyList);
        addDomainQueryKey(domain.getRelationVipQuery(), keyList);
        addDomainQueryKey(domain.getRelationNoVipQuery(), keyList);
        addDomainQueryKey(domain.getSearchVipQuery(), keyList);
        addDomainQueryKey(domain.getSearchNoVipQuery(), keyList);

        if (!keyList.isEmpty()) {
            sqlBuilder.append("UPDATE \"CONF_QUERY\" SET OWNER_DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = '" + domain.getKey() + "') WHERE KEY IN (");
            for (String key: keyList) {
                sqlBuilder.append("'" + key + "', ");
            }
            sqlBuilder.deleteCharAt(sqlBuilder.lastIndexOf(","));
            sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE + SqlFactoryConstants.NEWLINE);
        }

        return sqlBuilder.toString();
    }

    private String getInsertScriptForDomainProperties(Domain domain) {
        StringBuilder sqlBuilder = new StringBuilder();

        if (domain.getDomainRoleList() != null) {
            domain.getDomainRoleList().stream().forEach(domainRole -> sqlBuilder.append(getInsertScriptForDomainRole(domain, domainRole)));
        }

        if (domain.getDomainPathkeyList() != null) {
            domain.getDomainPathkeyList().stream().forEach(domainPathkey -> sqlBuilder.append(getInsertScriptForDomainPathkey(domain, domainPathkey)));
        }

        if (domain.getDomainMenugroupList() != null) {
            domain.getDomainMenugroupList().stream().forEach(domainMenugroup -> sqlBuilder.append(getInsertScriptForDomainMenugroup(domain, domainMenugroup)));
        }

        if (domain.getDomainAttributeList() != null) {
            domain.getDomainAttributeList().stream().forEach(domainAttribute -> sqlBuilder.append(getInsertScriptForDomainAttribute(domain, domainAttribute)));
        }

        if (domain.getDomainSubjecttypeList() != null) {
            domain.getDomainSubjecttypeList().stream().forEach(domainSubjecttype -> sqlBuilder.append(getInsertScriptForDomainSubjecttype(domain, domainSubjecttype)));
        }

        sqlBuilder.append(SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForDomainRole(Domain domain, DomainRole domainRole) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_DOMAIN_ROLE\"(DOMAIN_ID, TYPE, ROLE, VIPACCESS) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_DOMAIN, "KEY", domain.getKey()) + ", ");
        sqlBuilder.append(domainRole.getType() + ", ");
        sqlBuilder.append(ExportUtils.getString(domainRole.getRole()) + ", ");
        sqlBuilder.append(domainRole.getVipaccess());
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForDomainPathkey(Domain domain, DomainPathkey domainPathkey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_DOMAIN_PATHKEY\"(DOMAIN_ID, KEY, NAME, TITLE, TYPE, INDEX, PRIMARY, MANDATORY) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_DOMAIN, "KEY", domain.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainPathkey.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainPathkey.getName()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainPathkey.getTitle()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainPathkey.getType()) + ", ");
        sqlBuilder.append(domainPathkey.getIndex() + ", ");
        sqlBuilder.append(domainPathkey.getPrimary() + ", ");
        sqlBuilder.append(domainPathkey.getMandatory());
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForDomainMenugroup(Domain domain, DomainMenugroup domainMenugroup) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_DOMAIN_MENUGROUP\"(DOMAIN_ID, TITLE, ICONNAME, INDEX) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_DOMAIN, "KEY", domain.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainMenugroup.getTitle()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainMenugroup.getIconname()) + ", ");
        sqlBuilder.append(domainMenugroup.getIndex());
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForDomainAttribute(Domain domain, DomainAttribute domainAttribute) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_DOMAIN_ATTRIBUTE\"(DOMAIN_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_DOMAIN, "KEY", domain.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainAttribute.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainAttribute.getValue()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForDomainSubjecttype(Domain domain, DomainSubjecttype domainSubjecttype) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_DOMAIN_SUBJECTTYPE\"(DOMAIN_ID, NAME, TYPE) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_DOMAIN, "KEY", domain.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainSubjecttype.getName()) + ", ");
        sqlBuilder.append(ExportUtils.getString(domainSubjecttype.getType()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getQueryKey(Query query) {
        return query == null ? null : query.getKey();
    }

    private void addDomainQueryKey(Query query, ArrayList<String> keyList) {
        if (query != null && query.getOwnerDomain() != null) {
            keyList.add(getQueryKey(query));
        }
    }
}
