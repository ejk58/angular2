package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import lombok.Getter;
import lombok.Setter;

import java.sql.Connection;

@Getter
@Setter
public class DbConnection {
    private Connection connection;
    private String dbSchema;
}
