package nl.belastingdienst.iva.wd.configurator.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import nl.belastingdienst.iva.wd.configurator.domain.PageWidget;

import java.util.List;

@Data
@Getter
@Setter
public class PageDto {
    private String key;
    private String title;
    private List<PageWidget> widgets;
    private String type;
    private GroupDomainDto groupDomain;
    private String tag;

    public PageDto(String key, String title, List<PageWidget> widgets, String type) {
        this.key = key;
        this.title = title;
        this.widgets = widgets;
        this.type = type;
    }
}
