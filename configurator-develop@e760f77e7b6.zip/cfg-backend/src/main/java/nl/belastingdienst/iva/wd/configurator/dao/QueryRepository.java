package nl.belastingdienst.iva.wd.configurator.dao;

import nl.belastingdienst.iva.wd.configurator.domain.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QueryRepository extends CrudRepository<Query, Integer> {
    Query findByKey(String key);

    @org.springframework.data.jpa.repository.Query("SELECT DISTINCT query.key FROM Query query ORDER BY query.key ASC")
    List<String> findAllQueryKeysOrderByNameAsc();

    @org.springframework.data.jpa.repository.Query("SELECT DISTINCT query.key FROM Query query JOIN query.ownerDomain domain WHERE domain.key = :domainkey AND NOT EXISTS (SELECT widget.id FROM Widget widget WHERE widget.query.id = query.id) ORDER BY query.key ASC")
    List<String> findAllQueryKeysWithoutWidgetForDomainOrderByNameAsc(@Param("domainkey") String domainKey);
}
