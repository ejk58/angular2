package nl.belastingdienst.iva.wd.configurator.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CONF_PAGE_PATHKEY")
public class PagePathkey {

    @Id
    private Integer id;
    private String name;

    @JsonBackReference
    @ManyToOne()
    @JoinColumn(name = "PAGE_ID")
    private Page page;
}
