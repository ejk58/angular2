package nl.belastingdienst.iva.wd.configurator.domain.exception;

public class JWTInvalidException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public JWTInvalidException(String message) {
        super(message);
    }

    public JWTInvalidException(String message, Throwable cause) {
        super(message, cause);
    }
}
