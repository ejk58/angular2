package nl.belastingdienst.iva.wd.configurator.factory;

import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.configurator.domain.*;
import nl.belastingdienst.iva.wd.configurator.dto.WidgetDto;

@Component
public class WidgetMapper {

    public Widget map(WidgetDto widgetDto) {
        Widget widget = null;

        if (widgetDto != null) {
            widget = new Widget();
            widget.setId(widgetDto.getId());
            widget.setIndex(widgetDto.getIndex());
            widget.setName(widgetDto.getName());
            widget.setType(widgetDto.getType());
            widget.setTitle(widgetDto.getTitle());
            widget.setDescription(widgetDto.getDescription());
            widget.setRefreshinfo(widgetDto.isRefreshinfo());
            widget.setVisible(widgetDto.isVisible());
            widget.setOwnerDomain(widgetDto.getOwnerDomain());
            widget.setQuery(widgetDto.getQuery());
            widget.setColumnList(widgetDto.getColumnList());
            widget.setAttributeList(widgetDto.getAttributeList());
            widget.setPageWidgetList(widgetDto.getPageWidgetList());
        }

        return widget;
    }
}
