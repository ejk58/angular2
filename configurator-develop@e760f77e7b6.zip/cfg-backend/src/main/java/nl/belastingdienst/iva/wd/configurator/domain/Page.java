package nl.belastingdienst.iva.wd.configurator.domain;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "CONF_PAGE")
public class Page implements HasOwnerDomain {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String key;
    private String title;
    private String type;

    @ManyToOne()
    @JoinColumn(name = "OWNER_DOMAIN_ID")
    private Domain ownerDomain;

    @OneToMany()
    @JoinColumn(name = "PAGE_ID")
    @OrderBy(value = "key")
    private List<PageAttribute> pageAttributeList;

    @JsonManagedReference
    @OneToMany()
    @JoinColumn(name = "PAGE_ID")
    @OrderBy(value = "name")
    private List<PagePathkey> pagePathkeyList;

    @JsonManagedReference
    @OneToMany()
    @JoinColumn(name = "PAGE_ID")
    private List<PageDomain> pageDomainList;
}
