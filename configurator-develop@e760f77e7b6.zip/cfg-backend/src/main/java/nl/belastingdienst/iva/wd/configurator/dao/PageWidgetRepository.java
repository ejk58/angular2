package nl.belastingdienst.iva.wd.configurator.dao;

import nl.belastingdienst.iva.wd.configurator.domain.Page;
import nl.belastingdienst.iva.wd.configurator.domain.PageWidget;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface PageWidgetRepository extends CrudRepository<PageWidget, Integer> {
    List<PageWidget> findByPage(Page page);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM {h-schema}CONF_PAGE_WIDGET WHERE PAGE_ID = :pageId",
           nativeQuery = true)
    void deletePageWidgetsByPageId(@Param("pageId") Integer pageId);

    @Transactional
    @Modifying
    @Query(value = "INSERT INTO {h-schema}CONF_PAGE_WIDGET (ID, PAGE_ID, WIDGET_ID, GRID_COLUMNS, ROW_INDEX, COLUMN_INDEX) VALUES (:id, :pageId, :widgetId, :gridColumns, :rowIndex, :columnIndex)",
           nativeQuery = true)
    void insertPageWidget(
            @Param("id") Integer id,
            @Param("pageId") Integer pageId,
            @Param("widgetId") Integer widgetId,
            @Param("gridColumns") Integer gridColumns,
            @Param("rowIndex") Integer rowIndex,
            @Param("columnIndex") Integer columnIndex);
}