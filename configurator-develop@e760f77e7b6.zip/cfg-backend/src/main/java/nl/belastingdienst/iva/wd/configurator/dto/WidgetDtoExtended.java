package nl.belastingdienst.iva.wd.configurator.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class WidgetDtoExtended {
	
    private String tag;
    private WidgetDto widget;
    private GroupDomainDto groupDomain;
}
