package nl.belastingdienst.iva.wd.configurator.domain;

public interface HasOwnerDomain {

    Domain getOwnerDomain();
}
