package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CONF_QUERY_FILTER")
public class QueryFilter {

	@Id
	private Integer id;
	
	private String parameter;
	
	@Column(name = "FILTERTEMPLATE")
	private String filterTemplate;

	@Column(name = "NOFILTERTEMPLATE")
    private String noFilterTemplate;
}
