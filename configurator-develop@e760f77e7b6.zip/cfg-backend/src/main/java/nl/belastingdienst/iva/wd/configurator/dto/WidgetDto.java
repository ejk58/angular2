package nl.belastingdienst.iva.wd.configurator.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import nl.belastingdienst.iva.wd.configurator.domain.*;

import java.util.ArrayList;
import java.util.List;

@Data
@Getter
@Setter
public class WidgetDto {

	private Integer id;
    private Integer index;
    private String name;
    private String type;
    private String title;
    private String description;
    private boolean refreshinfo;
    private boolean visible;
    private Query query;
    private Domain ownerDomain;

    private List<PageWidget> pageWidgetList = new ArrayList<>();
    private List<WidgetAttribute> attributeList = new ArrayList<>();
    private List<WidgetColumn> columnList = new ArrayList<>();
    private List<Widget> widgetList = new ArrayList<>();
}
