package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class Release {
    private Integer id;
    private String domainKey;
    private String tag;
    private String administrator;
    private Date date;
}
