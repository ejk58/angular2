package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "CONF_DOMAIN")
public class Domain {
    @Id
    private Integer id;
    private String key;
    private String name;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RELATION_VIP_QUERY_ID")
    private Query relationVipQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RELATION_NOVIP_QUERY_ID")
    private Query relationNoVipQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SEARCH_VIP_QUERY_ID")
    private Query searchVipQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SEARCH_NOVIP_QUERY_ID")
    private Query searchNoVipQuery;

    private Integer index;
    private String iconname;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SUBJECT_QUERY_ID")
    private Query subjectQuery;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "key")
    private List<DomainAttribute> domainAttributeList;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "index")
    private List<DomainMenugroup> domainMenugroupList;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "index")
    private List<DomainPathkey> domainPathkeyList;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "role")
    private List<DomainRole> domainRoleList;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "name")
    private List<DomainSubjecttype> domainSubjecttypeList;
}
