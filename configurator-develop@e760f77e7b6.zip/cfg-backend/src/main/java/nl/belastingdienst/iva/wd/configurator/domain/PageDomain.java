package nl.belastingdienst.iva.wd.configurator.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CONF_PAGE_DOMAIN")
public class PageDomain {

    @Id
    private Integer id;

    @Column(name = "GROUP_INDEX")
    private Integer groupIndex;

    @Column(name = "MEMBER_INDEX")
    private Integer memberIndex;

    @JsonBackReference
    @ManyToOne()
    @JoinColumn(name = "PAGE_ID")
    private Page page;

    @ManyToOne()
    @JoinColumn(name = "DOMAIN_ID")
    private Domain domain;
}
