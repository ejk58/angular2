package nl.belastingdienst.iva.wd.configurator.datasource.configurator;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ConfigurationLog;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Release;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ReleaseDeleteFailedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

@Repository
public class ConfiguratorReleaseRepository implements ConfiguratorRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedJdbcTemplateConfigurator;

    @Value("${configurator.db.schema}")
    private String schema;

    public Release getCurrentRelease(String domainKey, String environmentName) {
        String sql = "SELECT * FROM " + schema + ".release WHERE id IN (SELECT re.release_id FROM " + schema + ".release_environment re JOIN " + schema + ".environment e ON re.environment_id = e.id WHERE e.name = '" + environmentName + "') AND domain_key = '" + domainKey + "' ORDER BY date DESC FETCH FIRST 1 ROWS ONLY";
        List<Release> currentRelease = namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Release.class));
        return (currentRelease.isEmpty()) ? null : currentRelease.get(0);
    }

    public Release getNextRelease(String domainKey, String environmentName) {
        String sql = "SELECT * FROM " + schema + ".release WHERE id NOT IN (SELECT re.release_id FROM " + schema + ".release_environment re JOIN " + schema + ".environment e ON re.environment_id = e.id WHERE e.name = '" + environmentName + "') AND domain_key = '" + domainKey + "' ORDER BY date FETCH FIRST 1 ROWS ONLY";
        List<Release> nextRelease = namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Release.class));
        return (nextRelease.isEmpty()) ? null : nextRelease.get(0);
    }

    public List<Release> getReleasesNotDeployed(String domainKey) {
        String sql = "SELECT * FROM " + schema + ".release WHERE id NOT IN (SELECT release_id FROM  " + schema + ".release_environment WHERE domain_key = '" + domainKey + "') AND domain_key = '" + domainKey + "' ORDER BY DATE ASC";
        return namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Release.class));
    }

    public List<String> getAllReleaseTags() {
        String sql = "SELECT tag FROM " + schema + ".release ORDER BY DATE ASC";
        return namedJdbcTemplateConfigurator.query(sql, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet resultSet, int i) throws SQLException {
                return resultSet.getString(1);
            }
        });
    }

    public boolean checkUniqueReleaseTag(String releaseTag) {
        String sql = "SELECT tag FROM " + schema + ".release WHERE tag = '" + releaseTag + "'";
        List<String> tags = namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(String.class));
        return tags.isEmpty();
    }

    public void saveRelease(Release release) {
        String sqlStatement =
            "insert into " + schema + ".release (domain_key, tag, administrator, date)" +
                " values(:domainKey, :tag, :administrator, :date)";

        BeanPropertySqlParameterSource paramSource = new BeanPropertySqlParameterSource(release);
        namedJdbcTemplateConfigurator.update(sqlStatement, paramSource);
    }

    public void deleteRelease(Integer releaseId) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("releaseId", releaseId);

        String sqlUpdateStatement =
            "update " + schema + ".change set release_id = null where release_id = :releaseId";

        String sqlDeleteStatement =
            "delete from " + schema + ".release where id = :releaseId";

        if (!isReleaseRolledOut(releaseId)) {
            namedJdbcTemplateConfigurator.update(sqlUpdateStatement, paramSource);
            namedJdbcTemplateConfigurator.update(sqlDeleteStatement, paramSource);
        } else {
            throw new ReleaseDeleteFailedException();
        }
    }

    public void rolloutRelease(Connection connection, String schema, List<Change> changes, ConfigurationLog configurationLog) throws SQLException {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateStr = dateFormat.format(configurationLog.getDate());
        String rolloutSql = "set schema '" + schema + "';";
        for (Change change : changes) {
            rolloutSql += change.getSql();
        }
        rolloutSql += "INSERT INTO CONFIGURATION_LOG (domain_key, release_tag, administratorname, date) VALUES ('" + configurationLog.getDomainKey() + "', '" + configurationLog.getReleaseTag() + "', '" + configurationLog.getAdministratorname() + "', '" + currentDateStr + "');";
        runSqlScript(connection, rolloutSql, true);
    }

    public void rollbackRelease(Connection connection, String schema, List<Change> changes, ConfigurationLog configurationLog) throws SQLException {
        String rollbackSql = "set schema '" + schema + "';";
        for (Change change : changes) {
            rollbackSql += change.getRollbackSql();
        }
        rollbackSql += "DELETE FROM CONFIGURATION_LOG WHERE domain_key = '" + configurationLog.getDomainKey() + "' AND release_tag ='" + configurationLog.getReleaseTag() + "'";
        runSqlScript(connection, rollbackSql, true);
    }

    private boolean isReleaseRolledOut(Integer releaseId) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("releaseId", releaseId);

        String sql =
            "SELECT COUNT(release_id) FROM " + schema + ".release_environment WHERE release_id = :releaseId";

        return namedJdbcTemplateConfigurator.queryForObject(sql, paramSource, Integer.class) > 0;
    }

}
