filename1 = 'file1.sql'
filename2 = 'file2.sql'

sortedList1 = list()
sortedList2 = list()

with open (filename1) as fin:
    for line in fin:
        if line.strip():
            sortedList1.append(line.strip().lower().lstrip(' '))

with open (filename2) as fin:
    for line in fin:
        if line.strip():
            sortedList2.append(line.strip().lower().lstrip(' '))

result1 = list(set(sortedList1) - set(sortedList2))
result2 = list(set(sortedList2) - set(sortedList1))

if (len(result1) == 0 and len(result2) == 0):
    print(f'\nFile "{filename1}" en "{filename2}" bevatten dezelfde regels. (volgorde en casing zijn eventueel wel verschillend)\n')
else:
    print (f'\n==\n== VERSCHILLEN IN LOWERCASE van "{filename1}" met "{filename2}":\n==')
    result1.sort()
    for line in result1:
        print(line)

    print (f'\n==\n== VERSCHILLEN IN LOWERCASE van "{filename2}" met "{filename1}":\n==')
    result2.sort()
    for line in result2:
        print(line)
