package nl.belastingdienst.iva.wd.configurator.domain;

public class DomainRoleBuilder {

    private DomainRole domainRole;
    
    public DomainRoleBuilder() {
        this.domainRole = new DomainRole();
    }
    
    public DomainRole build() {
        return this.domainRole;
    }
    
    public DomainRoleBuilder withType(int type){
        this.domainRole.setType(type);
        return this;
    }
    
    public DomainRoleBuilder withRole(String role) {
        this.domainRole.setRole(role);
        return this;
    }
    
    public DomainRoleBuilder withVipAccess(int vipAccess){
        this.domainRole.setVipaccess(vipAccess);
        return this;
    }

    public static DomainRole build(int type, String role, int vipAccess) {
        return new DomainRoleBuilder()
                .withType(type)
                .withRole(role)
                .withVipAccess(vipAccess)
                .build();
    }
}
