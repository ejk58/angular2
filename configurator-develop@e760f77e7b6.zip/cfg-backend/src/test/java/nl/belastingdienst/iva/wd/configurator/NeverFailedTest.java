package nl.belastingdienst.iva.wd.configurator;

import org.junit.Assert;
import org.junit.Test;

public class NeverFailedTest {

    @Test
    public void neverFailedTest() {
        Assert.assertTrue(true);
    }
}