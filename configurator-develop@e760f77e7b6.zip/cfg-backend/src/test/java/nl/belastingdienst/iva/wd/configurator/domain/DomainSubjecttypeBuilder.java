package nl.belastingdienst.iva.wd.configurator.domain;

public class DomainSubjecttypeBuilder {
    private DomainSubjecttype domainSubjecttype;

    public DomainSubjecttypeBuilder() {
        this.domainSubjecttype = new DomainSubjecttype();
    }

    public DomainSubjecttype build() {
        return this.domainSubjecttype;
    }

    public DomainSubjecttypeBuilder withKey(String name){
        this.domainSubjecttype.setName(name);
        return this;
    }

    public DomainSubjecttypeBuilder withValue(String type) {
        this.domainSubjecttype.setType(type);
        return this;
    }

    public static DomainSubjecttype build(String name, String type) {
        return new DomainSubjecttypeBuilder()
                .withKey(name)
                .withValue(type)
                .build();
    }
}
