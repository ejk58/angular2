package nl.belastingdienst.iva.wd.configurator.domain;

public class DomainAttributeBuilder {

    private DomainAttribute domainAttribute;

    public DomainAttributeBuilder() {
        this.domainAttribute = new DomainAttribute();
    }

    public DomainAttribute build() {
        return this.domainAttribute;
    }

    public DomainAttributeBuilder withKey(String key){
        this.domainAttribute.setKey(key);
        return this;
    }

    public DomainAttributeBuilder withValue(String value) {
        this.domainAttribute.setValue(value);
        return this;
    }

    public static DomainAttribute build(String key, String value) {
        return new DomainAttributeBuilder()
                .withKey(key)
                .withValue(value)
                .build();
    }
}
