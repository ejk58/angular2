package nl.belastingdienst.iva.wd.configurator.domain;

public class PageBuilder {
	
	private Page page;
	
	public PageBuilder() {
		this.page = new Page();
	}
	
	public Page build() {
		return this.page;
	}

	public PageBuilder withKey(String key) {
		this.page.setKey(key);
		return this;
	}
	
	public PageBuilder withTitle(String title) {
		this.page.setTitle(title);
		return this;
	}
	
	public PageBuilder withType(String type) {
		this.page.setType(type);
		return this;
	}
	
	public PageBuilder withOwnerDomain(Domain ownerDomain) {
		this.page.setOwnerDomain(ownerDomain);
		return this;
	}
}
