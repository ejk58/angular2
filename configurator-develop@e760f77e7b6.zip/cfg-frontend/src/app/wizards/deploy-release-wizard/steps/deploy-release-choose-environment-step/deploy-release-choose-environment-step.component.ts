import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {DeployReleaseWizardService} from '../../deploy-release-wizard.service';
import {EnvironmentService} from '../../../../services/environment.service';
import {SelectItem} from '../../../../common/select-item';

@Component({
  selector: 'c-deploy-release-choose-environment-step',
  templateUrl: './deploy-release-choose-environment-step.component.html',
  styleUrls: ['./deploy-release-choose-environment-step.component.scss']
})

export class DeployReleaseChooseEnvironmentStepComponent extends AbstractWizardStep implements OnInit {

  public environments: SelectItem[] = [];
  public selectedEnvironment: string;

  constructor(private deployReleaseWizardService: DeployReleaseWizardService,
              private environmentService: EnvironmentService) {
    super();
  }

  ngOnInit(): void {
    this.selectedEnvironment = this.deployReleaseWizardService.wizardData.environment;
    this.getEnvironments();
  }

  onSelectedEnvironment(): void {
    this.deployReleaseWizardService.initializeWizard();
    this.deployReleaseWizardService.wizardData.environment = this.selectedEnvironment;
  }

  private getEnvironments() {
    this.environmentService.getEnvironments().subscribe(environments => {
      this.environments = environments ? environments.map(environment => ({label: environment.name, value: environment.name})) : [];
    });
  }

  isStepValid(): void {
    this.deployReleaseWizardService.isCurrentStepValid = this.selectedEnvironment != null;
  }

}
