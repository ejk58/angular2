import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {DeployReleaseWizardService} from '../../deploy-release-wizard.service';
import {Release} from '../../../../domain/release/release';
import {ReleaseService} from 'src/app/services/release.service';
import {Observable} from 'rxjs';
import {TableColumn} from '../../../../domain/table/table-column';
import {TableData} from '../../../../domain/table/table-data';
import {DateTimePipe} from '../../../../components/pipes/date-time.pipe';

@Component({
  selector: 'c-deploy-release-summary-step',
  templateUrl: './deploy-release-summary-step.component.html',
  styleUrls: ['./deploy-release-summary-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: DeployReleaseSummaryStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class DeployReleaseSummaryStepComponent extends AbstractWizardStep implements OnInit {

  public summaryTableTitle: string;
  public summaryTableCols: TableColumn[];
  public nextReleaseData: TableData[];

  constructor(private readonly deployReleaseWizardService: DeployReleaseWizardService,
              private readonly releaseService: ReleaseService,
              private readonly dateTimePipe: DateTimePipe) {
    super();
  }

  ngOnInit(): void {
    this.setDataForNextReleaseTable();
  }

  public executeChanges(): Observable<string> {
    return this.releaseService.rollout(this.deployReleaseWizardService.wizardData);
  }

  public isStepValid(): void {
    this.deployReleaseWizardService.isCurrentStepValid = true;
  }

  private setDataForNextReleaseTable(): void {
    const environment: string = this.deployReleaseWizardService.wizardData.environment;
    const nextRelease: Release = this.deployReleaseWizardService.wizardData.releaseRolloutInfo.nextRelease;

    this.summaryTableTitle = 'Weet u zeker dat u onderstaande release wilt installeren op "' + environment + '"?';
    this.summaryTableCols = [{field: 'label', header: 'Release'}, {field: 'value', header: 'Waarde'}];
    this.nextReleaseData = [
      {label: 'Klantbeeld', value: nextRelease.domainKey},
      {label: 'Naam', value: nextRelease.tag},
      {label: 'Gemaakt op', value: this.dateTimePipe.transform(nextRelease.date)},
      {label: 'Door', value: nextRelease.administrator}
    ];
  }

}
