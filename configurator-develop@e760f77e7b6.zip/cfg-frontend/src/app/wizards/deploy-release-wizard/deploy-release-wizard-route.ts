import {WizardRoute} from '../../domain/wizard/wizard-route';

export class DeployReleaseWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when DeployReleaseWizardService is used in DeployReleaseWizardRouteConfig.
}
