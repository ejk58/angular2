import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {DeployReleaseWizardRoute} from './deploy-release-wizard-route';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {DeployReleaseWizardData} from './deploy-release-wizard-data';
import {Execution} from '../../domain/execution/execution';

@Injectable()
export class DeployReleaseWizardService extends AbstractWizardService<DeployReleaseWizardData> {

  constructor(private readonly deployReleaseWizardRoute: DeployReleaseWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(deployReleaseWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {environment: undefined, releaseRolloutInfo: undefined, execution};
  }

}
