import {RobotTestsDataEntryStepComponent} from './robot-tests-data-entry-step/robot-tests-data-entry-step.component';
import {RobotTestsSummaryStepComponent} from './robot-tests-summary-step/robot-tests-summary-step.component';
import {RobotTestsWidgetSelectionStepComponent} from './robot-tests-widget-selection-step/robot-tests-widget-selection-step.component';

export const list = [
  RobotTestsWidgetSelectionStepComponent,
  RobotTestsDataEntryStepComponent,
  RobotTestsSummaryStepComponent
];
