import {Component, OnInit, ViewChild} from '@angular/core';
import {QueryFilter} from '../../../../domain/query/query-filter';
import {Query} from '../../../../domain/query/query';
import {WidgetWizardService} from '../../common/widget-wizard.service';
import * as _ from 'lodash-es';
import {Table} from 'primeng/table';

@Component({
  selector: 'c-query-filter',
  templateUrl: './query-filter.component.html',
  styleUrls: ['./query-filter.component.scss']
})
export class QueryFilterComponent implements OnInit {

  @ViewChild('dtqueryfilters', {static: false}) dtQueryFilters: Table;

  private clonedQueryFilterList: QueryFilter[] = [];
  private lastIssuedQueryFilterId: number; // To prevent reuse of id's because of 'dataKey="id"' in p-table

  public query: Query;
  public queryFilterList: QueryFilter[] = [];

  constructor(private readonly widgetWizardService: WidgetWizardService) { }

  ngOnInit(): void {
    this.queryFilterList = this.widgetWizardService.wizardData.widget.query.queryFilterList;
    this.lastIssuedQueryFilterId = Math.max(...this.queryFilterList.map(queryFilter => queryFilter.id), 0);
  }

  public addQueryFilter(): void {
    this.lastIssuedQueryFilterId++;
    const newQueryFilter: QueryFilter = {id: this.lastIssuedQueryFilterId, filterTemplate: '', noFilterTemplate: null, parameter: null};
    this.queryFilterList.push(newQueryFilter);
    this.dtQueryFilters.initRowEdit(newQueryFilter); // Put row in edit mode
    this.onRowEditInit(newQueryFilter);
  }

  public removeQueryFilter(index: number): void {
    const clonedIndex: number = this.clonedQueryFilterList.findIndex(clonedQueryFilter => clonedQueryFilter.id === this.queryFilterList[index].id);
    this.queryFilterList.splice(index, 1);
    this.removeClonedQueryFilter(clonedIndex);
  }

  public onRowEditInit(queryFilter: QueryFilter): void {
    const clonedQueryFilter: QueryFilter = _.cloneDeep(queryFilter);
    this.clonedQueryFilterList.push(clonedQueryFilter);
  }

  public onRowEditSave(queryFilter: QueryFilter): void {
    const clonedIndex: number = this.clonedQueryFilterList.findIndex(clonedQueryFilter => clonedQueryFilter.id === queryFilter.id);
    this.removeClonedQueryFilter(clonedIndex);
  }

  public onRowEditCancel(queryFilter: QueryFilter, index: number): void {
    const clonedIndex: number = this.clonedQueryFilterList.findIndex(clonedQueryFilter => clonedQueryFilter.id === queryFilter.id);
    this.queryFilterList[index] = this.clonedQueryFilterList[clonedIndex];
    this.removeClonedQueryFilter(clonedIndex);
  }

  private removeClonedQueryFilter(index: number): void {
    if (index > -1) {
      this.clonedQueryFilterList.splice(index, 1);
    }
  }

}
