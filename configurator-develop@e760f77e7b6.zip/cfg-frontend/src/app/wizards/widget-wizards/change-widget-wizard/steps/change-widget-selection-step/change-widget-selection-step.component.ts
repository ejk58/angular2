import {Component, OnDestroy, OnInit} from '@angular/core';
import {WidgetService} from 'src/app/services/widget.service';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import {WidgetWizardService} from '../../../common/widget-wizard.service';
import {SelectItem} from '../../../../../common/select-item';
import {Subscription} from 'rxjs';

@Component({
  selector: 'c-change-widget-selection-step',
  templateUrl: './change-widget-selection-step.component.html',
  styleUrls: ['./change-widget-selection-step.component.scss']
})
export class ChangeWidgetSelectionStepComponent extends AbstractWizardStep implements OnInit, OnDestroy {

  public widgetNames: SelectItem[] = [];
  public selectedWidgetName: string;
  private subscription: Subscription;

  constructor(private readonly widgetService: WidgetService,
              private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.selectedWidgetName = this.widgetWizardService.wizardData.widget.name;
    this.getWidgetNamesForDomainOrGeneric();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onSelectedWidgetNameChange(): void {
    this.widgetWizardService.initializeWizard();
    this.widgetWizardService.wizardData.widget.name = this.selectedWidgetName;
  }

  public isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid =
      this.selectedWidgetName !== ''
      && this.selectedWidgetName !== undefined
      && this.selectedWidgetName !== null;
  }

  private getWidgetNamesForDomainOrGeneric() {
    this.subscription = this.widgetService.getWidgetNamesForDomainOrGeneric().subscribe(widgetNames => {
      this.widgetNames = widgetNames ? widgetNames.map(widgetName => ({label: widgetName, value: widgetName})) : [];
      if (this.hasDomainChangeTakenPlace(widgetNames)) {
        this.initializeDataOnDomainChange();
      }
    });
  }

  private hasDomainChangeTakenPlace(widgetNames: string[]) {
    return this.selectedWidgetName && !widgetNames.includes(this.selectedWidgetName);
  }

  private initializeDataOnDomainChange(): void {
    this.widgetWizardService.initializeWizard();
    this.selectedWidgetName = this.widgetWizardService.wizardData.widget.name;
  }

}
