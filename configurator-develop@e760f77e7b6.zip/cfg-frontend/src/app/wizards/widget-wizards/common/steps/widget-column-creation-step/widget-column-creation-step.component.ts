import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import * as _ from 'lodash-es';
import {Widget} from 'src/app/domain/widget/widget';
import {WidgetColumn} from 'src/app/domain/widget/widget-column';
import {TeradataView} from 'src/app/domain/widget/teradata-view';
import {WidgetWizardService} from '../../widget-wizard.service';
import {SelectItem} from '../../../../../common/select-item';

@Component({
  selector: 'c-widget-column-creation-step',
  templateUrl: './widget-column-creation-step.component.html',
  styleUrls: ['./widget-column-creation-step.component.scss']
})

export class WidgetColumnCreationStepComponent extends AbstractWizardStep implements OnInit {

  public widget: Widget;
  public teradataView: TeradataView;
  private lastId = 0;

  public clonedColumns: WidgetColumn[] = [];
  public viewColumnSelectItems: SelectItem[] = [];
  public viewColumn: string;

  public typeOptions: any[] = [{label: 'STRING', value: 'STRING'}, {label: 'NUMBER', value: 'NUMBER'}, {label: 'MONEY', value: 'MONEY'},
    {label: 'PERCENTAGE', value: 'PERCENTAGE'},{label: 'DRILLDOWNSTRING', value: 'DRILLDOWNSTRING'},{label: 'PAGELINKSTRING', value: 'PAGELINKSTRING'},
    {label: 'ASSPECIFIED', value: 'ASSPECIFIED'}];
  public behaviourOptions: any[] = [{label: 'Visible', value: 'visible'}, {label: 'Invisible', value: 'invisible'}, {label: 'Sortable', value: 'sortable'}, {label: 'Summable', value: 'summable'}];
  public filterOptions: any[] = [{label: '', value: null}, {label: 'Text', value: 'text'}];

  constructor(private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.widget = this.widgetWizardService.wizardData.widget;
    this.teradataView = this.widgetWizardService.wizardData.teradataView;

    if (this.teradataView) {
      this.viewColumnSelectItems = this.teradataView.columns.map(viewColumn => {
        return { label: viewColumn, value: viewColumn };
      });
      this.viewColumn = this.viewColumnSelectItems[0] ? this.viewColumnSelectItems[0].value : undefined;
    } else {
      this.viewColumnSelectItems = [];
    }
  }

  public addColumn(): void {
    const queryColumn = {index: 0, name: this.viewColumn, alias: '', value: '', key: '', type: '', maskable: false , columnList: []};
    const widgetColumn: WidgetColumn = {index: 0, type: '', label: '', description: '', behaviour: '', filter: '', queryColumn: queryColumn, columnAttributes: []};
    widgetColumn.id = this.lastId++;
    this.widget.columnList.push(widgetColumn);
    this.onReorderColumnRow();
  }

  public removeColumn(index: number): void {
    this.widget.columnList.splice(index, 1);
    this.onReorderColumnRow();
  }

  onRowEditInit(column: WidgetColumn): void {
    this.clonedColumns[column.id] = _.cloneDeep(column);
  }

  onRowEditSave(column: WidgetColumn): void {
    delete this.clonedColumns[column.id];
  }

  onRowEditCancel(column: WidgetColumn, index: number): void {
    this.widget.columnList[index] = this.clonedColumns[column.id];
    delete this.clonedColumns[column.id];
  }

  onReorderColumnRow(): void {
    this.widget.columnList.forEach((column: WidgetColumn, index: number) => {
      column.queryColumn.index = index + 1;
      column.index = index + 1;
    });
  }

  isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid = true;
  }

}
