import {Injectable} from '@angular/core';
import {Widget} from '../../../domain/widget/widget';
import {Query} from '../../../domain/query/query';
import {AbstractWizardService} from '../../../services/abstract-wizard.service';
import {WidgetWizardData} from './widget-wizard-data';
import {WidgetWizardRoute} from './widget-wizard-route';
import {WizardStore} from '../../../domain/wizard/wizard-store';
import {TeradataView} from '../../../domain/widget/teradata-view';
import {Execution} from '../../../domain/execution/execution';

@Injectable()
export class WidgetWizardService extends AbstractWizardService<WidgetWizardData> {

  private static createNewWidget(): Widget {
    return {
      id: -1,
      containerWidgetId: null,
      index: null,
      name: null,
      type: 'Table',
      title: '',
      description: null,
      refreshinfo: false,
      visible: false,
      query: WidgetWizardService.createNewQuery(),
      pageWidgetList: [],
      attributeList: [],
      columnList: []
    };
  }

  private static createNewQuery(): Query {
    return {
      id: -1,
      type: 1,
      viewname: null,
      querytemplate: '',
      key: '',
      datasource: 1,
      columnList: [],
      queryFilterList: []
    };
  }

  constructor(private readonly widgetWizardRoute: WidgetWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(widgetWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const widget: Widget = WidgetWizardService.createNewWidget();
    const teradataView: TeradataView = {name: undefined, columns: undefined};
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {widget, teradataView, tag: undefined, execution};
  }

}
