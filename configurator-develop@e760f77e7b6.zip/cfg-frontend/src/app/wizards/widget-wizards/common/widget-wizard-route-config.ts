import {WizardRouteStep} from '../../../domain/wizard/wizard-route-step';
import {WidgetWizardData} from './widget-wizard-data';
import {WizardRouteStepType} from '../../../domain/wizard/wizard-route-step-type';
import {WizardRouteSection} from '../../../domain/wizard/wizard-route-section';
import {WidgetWizardService} from './widget-wizard.service';
import {AppInjector} from '../../../app-injector';
import {ExecutionStatus} from '../../../domain/execution/execution-status';
import {WizardRouteSplit} from '../../../domain/wizard/wizard-route-split';
import {WizardRoute} from '../../../domain/wizard/wizard-route';
import {WidgetWizardRoute} from './widget-wizard-route';

// Steps
const widgetSelectionStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('widgetSelectionStep', WizardRouteStepType.Selection, 'Selecteer een widget');
const widgetCreationStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('widgetCreationStep', WizardRouteStepType.Selection, 'Maak widget');
const queryCreationStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('queryCreationStep', WizardRouteStepType.Selection, 'Maak query');
const widgetColumnCreationStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('widgetColumnCreationStep', WizardRouteStepType.Selection, 'Configureer widget kolommen');
const queryColumnCreationStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('queryColumnCreationStep', WizardRouteStepType.Selection, 'Configureer query kolommen');
const widgetQueryValidationStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('widgetQueryValidationStep', WizardRouteStepType.Selection, 'Query validatie');
const widgetAttributeStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('widgetAttributeStep', WizardRouteStepType.Selection, 'Maak widget attributen');
const widgetSummaryStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('widgetSummaryStep', WizardRouteStepType.Execution, 'Samenvatting');
const successStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('successStep', WizardRouteStepType.Success, 'Succes');
const errorStep: WizardRouteStep<WidgetWizardData> = new WizardRouteStep('errorStep', WizardRouteStepType.Error, 'Fout');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([widgetSelectionStep, widgetCreationStep, queryCreationStep, widgetColumnCreationStep,
  queryColumnCreationStep, widgetQueryValidationStep, widgetAttributeStep, widgetSummaryStep]);
const sectionSuccess: WizardRouteSection = new WizardRouteSection([successStep]);
const sectionError: WizardRouteSection = new WizardRouteSection([errorStep]);
const sections: WizardRouteSection[] = [sectionMain, sectionSuccess, sectionError];

// Split-functions
const splitFunctionMain = (): WizardRouteSection => {
  const widgetWizardService: WidgetWizardService = AppInjector.get(WidgetWizardService);
  if (widgetWizardService.wizardData.execution.status === ExecutionStatus.Success) {
    return sectionSuccess;
  } else {
    return sectionError;
  }
};

// Splits
const splitMain: WizardRouteSplit = new WizardRouteSplit(sectionMain, splitFunctionMain);
const splits: WizardRouteSplit[] = [splitMain];

// RouteConfig
export const WidgetWizardRouteConfig: WizardRoute = new WizardRoute(WidgetWizardRoute.name, sections, splits, sectionMain);
