import {Widget} from '../../../domain/widget/widget';
import {TeradataView} from '../../../domain/widget/teradata-view';
import {Execution} from '../../../domain/execution/execution';

export interface WidgetWizardData {
  widget: Widget;
  teradataView: TeradataView;
  tag: string;
  execution: Execution;
}
