import {Component, OnInit} from '@angular/core';
import {WidgetWizardService} from '../common/widget-wizard.service';
import {AbstractWizard} from '../../../common/abstract-wizard';
import {WizardStore} from '../../../domain/wizard/wizard-store';
import {WidgetWizardRoute} from '../common/widget-wizard-route';
import {SpinnerService} from '../../../services/spinner.service';

@Component({
  selector: 'c-root',
  templateUrl: './new-widget-wizard.component.html',
  styleUrls: ['./new-widget-wizard.component.scss']
})
export class NewWidgetWizardComponent extends AbstractWizard implements OnInit {

  constructor(public readonly widgetWizardService: WidgetWizardService,
              private readonly spinnerService: SpinnerService,
              private readonly widgetWizardRoute: WidgetWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(widgetWizardService, spinnerService, widgetWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.widgetWizardService.initializeWizard();
  }

}
