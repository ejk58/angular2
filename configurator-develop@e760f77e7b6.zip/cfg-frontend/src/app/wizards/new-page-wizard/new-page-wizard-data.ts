import {PageDto} from '../../domain/dto/page-dto';
import {Execution} from '../../domain/execution/execution';

export interface NewPageWizardData {
  pageKey: string;
  pageDto: PageDto;
  execution: Execution;
}

