import {NewPageCreationStepComponent} from './new-page-creation-step/new-page-creation-step.component';
import {NewPageSelectionStepComponent} from './new-page-selection-step/new-page-selection-step.component';
import {NewPageSummaryStepComponent} from './new-page-summary-step/new-page-summary-step.component';

export const list = [
  NewPageSelectionStepComponent,
  NewPageCreationStepComponent,
  NewPageSummaryStepComponent
];
