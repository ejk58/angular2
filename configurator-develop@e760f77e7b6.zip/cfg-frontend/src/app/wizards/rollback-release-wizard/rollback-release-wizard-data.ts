import {Execution} from '../../domain/execution/execution';
import {Release} from '../../domain/release/release';

export interface RollbackReleaseWizardData {
  environment: string;
  currentRelease: Release;
  execution: Execution;
}

