import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {Execution} from '../../domain/execution/execution';
import {RollbackReleaseWizardData} from './rollback-release-wizard-data';
import {RollbackReleaseWizardRoute} from './rollback-release-wizard-route';

@Injectable()
export class RollbackReleaseWizardService extends AbstractWizardService<RollbackReleaseWizardData> {

  constructor(private readonly rollbackReleaseWizardRoute: RollbackReleaseWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(rollbackReleaseWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {environment: undefined, currentRelease: undefined, execution};
  }

}
