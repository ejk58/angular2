import {PageLayoutDto} from '../../domain/dto/page-layout-dto';
import {Execution} from '../../domain/execution/execution';

export interface ChangePageWizardData {
  pageKey: string;
  pageLayoutDto: PageLayoutDto;
  execution: Execution;
}
