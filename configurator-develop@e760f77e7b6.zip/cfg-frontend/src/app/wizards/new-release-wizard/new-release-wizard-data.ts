import {Change} from '../../domain/change/change';
import {Release} from '../../domain/release/release';
import {Execution} from '../../domain/execution/execution';

export interface NewReleaseWizardData {
  changes: Change[];
  release: Release;
  execution: Execution;
}
