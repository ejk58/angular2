import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {NewReleaseWizardRoute} from './new-release-wizard-route';
import {NewReleaseWizardData} from './new-release-wizard-data';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';
import {AppInjector} from '../../app-injector';
import {ExecutionStatus} from '../../domain/execution/execution-status';
import {NewReleaseWizardService} from './new-release-wizard.service';

// Steps
const newReleaseChangesSelectionStep: WizardRouteStep<NewReleaseWizardData> = new WizardRouteStep('newReleaseChangesSelectionStep', WizardRouteStepType.Selection, 'Selecteer aanpassingen');
const newReleaseNameStep: WizardRouteStep<NewReleaseWizardData> = new WizardRouteStep('newReleaseNameStep', WizardRouteStepType.Selection, 'Geef naam');
const newReleaseSummaryStep: WizardRouteStep<NewReleaseWizardData> = new WizardRouteStep('newReleaseSummaryStep', WizardRouteStepType.Execution, 'Samenvatting');
const successStep: WizardRouteStep<NewReleaseWizardData> = new WizardRouteStep('successStep', WizardRouteStepType.Success, 'Succes');
const errorStep: WizardRouteStep<NewReleaseWizardData> = new WizardRouteStep('errorStep', WizardRouteStepType.Error, 'Fout');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([newReleaseChangesSelectionStep, newReleaseNameStep, newReleaseSummaryStep]);
const sectionSuccess: WizardRouteSection = new WizardRouteSection([successStep]);
const sectionError: WizardRouteSection = new WizardRouteSection([errorStep]);
const sections: WizardRouteSection[] = [sectionMain, sectionSuccess, sectionError];

// Split-functions
const splitFunctionMain = (): WizardRouteSection => {
  const newReleaseWizardService: NewReleaseWizardService = AppInjector.get(NewReleaseWizardService);
  if (newReleaseWizardService.wizardData.execution.status === ExecutionStatus.Success) {
    return sectionSuccess;
  } else {
    return sectionError;
  }
};

// Splits
const splitMain: WizardRouteSplit = new WizardRouteSplit(sectionMain, splitFunctionMain);
const splits: WizardRouteSplit[] = [splitMain];

// RouteConfig
export const NewReleaseWizardRouteConfig: WizardRoute = new WizardRoute(NewReleaseWizardRoute.name, sections, splits, sectionMain);
