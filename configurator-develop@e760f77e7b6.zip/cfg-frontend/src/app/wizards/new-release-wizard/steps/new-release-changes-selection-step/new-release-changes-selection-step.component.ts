import {Component, OnDestroy, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {NewReleaseWizardService} from '../../new-release-wizard.service';
import {ChangeService} from '../../../../services/change.service';
import {Subscription} from 'rxjs';

@Component({
  selector: 'c-new-release-changes-selection-step',
  templateUrl: './new-release-changes-selection-step.component.html',
  styleUrls: ['./new-release-changes-selection-step.component.scss']
})

export class NewReleaseChangesSelectionStepComponent extends AbstractWizardStep implements OnInit, OnDestroy {

  public changeSelectItems: any[] = [];
  public selectedChange: any;
  private subscription: Subscription;

  constructor(private newReleaseWizardService: NewReleaseWizardService, private readonly changeService: ChangeService) {
    super();
  }

  ngOnInit(): void {
    this.getChangesForDomain();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  getChangesForDomain(): void {
    this.subscription = this.changeService.getChangesForDomain().subscribe(changes => {
      this.changeSelectItems = changes;
    });
  }

  onSelectedChangeChange(): void {
    this.newReleaseWizardService.wizardData.changes = this.changeSelectItems.filter(change => change.date <= this.selectedChange.date);
  }

  isStepValid(): void {
    this.newReleaseWizardService.isCurrentStepValid = this.selectedChange != null;
  }

}
