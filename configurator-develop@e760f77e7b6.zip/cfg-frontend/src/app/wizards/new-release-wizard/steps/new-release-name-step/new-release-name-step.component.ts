import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {NewReleaseWizardService} from '../../new-release-wizard.service';
import {Release} from '../../../../domain/release/release';
import {Tag} from '../../../../domain/tag/tag';

@Component({
  selector: 'c-new-release-name-step',
  templateUrl: './new-release-name-step.component.html',
  styleUrls: ['./new-release-name-step.component.scss']
})

export class NewReleaseNameStepComponent extends AbstractWizardStep implements OnInit {

  private isTagUnique: boolean = false;

  public changes: any[];
  public release: Release;

  constructor(private readonly newReleaseWizardService: NewReleaseWizardService) {
    super();
  }

  ngOnInit(): void {
    this.changes = this.newReleaseWizardService.wizardData.changes;
    this.release = {id: undefined, tag: this.newReleaseWizardService.wizardData.release?.tag};
    this.newReleaseWizardService.wizardData.release = this.release;
  }

  public onTagChanged(tag: Tag): void {
    this.release.tag = tag.tag;
    this.isTagUnique = tag.isUnique;
  }

  isStepValid(): void {
    this.newReleaseWizardService.isCurrentStepValid = this.release.tag != null && this.release.tag != '' && this.isTagUnique;
  }

}
