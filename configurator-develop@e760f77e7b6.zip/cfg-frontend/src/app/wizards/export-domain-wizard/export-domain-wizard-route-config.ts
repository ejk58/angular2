import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {ExportDomainWizardRoute} from './export-domain-wizard-route';
import {ExportDomainWizardData} from './export-domain-wizard-data';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';

// Steps
const exportDomainSelectionStep: WizardRouteStep<ExportDomainWizardData> = new WizardRouteStep('exportDomainSelectionStep', WizardRouteStepType.Selection, 'Klantbeeld');
const exportDomainSummaryStep: WizardRouteStep<ExportDomainWizardData> = new WizardRouteStep('exportDomainSummaryStep', WizardRouteStepType.Selection, 'Samenvatting');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([exportDomainSelectionStep, exportDomainSummaryStep]);
const sections: WizardRouteSection[] = [sectionMain];

// Split-functions

// Splits
const splits: WizardRouteSplit[] = [];

// RouteConfig
export const ExportDomainWizardRouteConfig: WizardRoute = new WizardRoute(ExportDomainWizardRoute.name, sections, splits, sectionMain);
