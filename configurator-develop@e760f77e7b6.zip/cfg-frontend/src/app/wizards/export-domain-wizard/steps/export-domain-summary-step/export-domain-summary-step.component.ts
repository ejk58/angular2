import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {ExportDomainWizardService} from '../../export-domain-wizard.service';
import {DomainService} from '../../../../services/domain.service';
import {ConfigurationService} from '../../../../services/configuration.service';
import {Clipboard} from '@angular/cdk/clipboard';
import {SpinnerService} from '../../../../services/spinner.service';

@Component({
  selector: 'c-export-domain-summary-step',
  templateUrl: './export-domain-summary-step.component.html',
  styleUrls: ['./export-domain-summary-step.component.scss']
})

export class ExportDomainSummaryStepComponent extends AbstractWizardStep implements OnInit {

  public domainSql: string;

  constructor(private readonly exportDomainWizardService: ExportDomainWizardService,
              private configurationService: ConfigurationService,
              private domainService: DomainService,
              private spinnerService: SpinnerService,
              private readonly clipboard: Clipboard) {
    super();
  }

  ngOnInit(): void {
    this.getDomainSql();
  }

  public getDomainSql(): void {
    this.spinnerService.show();
    this.configurationService.getDomainSql(this.domainService.activeDomain.domainId).subscribe(domainSql => {
      this.spinnerService.hide();
      this.domainSql = domainSql;
    });
  }

  public isStepValid(): void {
    this.exportDomainWizardService.isCurrentStepValid = true;
  }

  public copyTextarea(): void {
    this.clipboard.copy(this.domainSql);
  }


}
