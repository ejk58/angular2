import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {ExportDomainWizardService} from '../../export-domain-wizard.service';
import {Observable} from 'rxjs';
import {DomainService} from '../../../../services/domain.service';
import {ApplicationDomain} from '../../../../domain/application/application-domain';

@Component({
  selector: 'c-export-domain-selection-step',
  templateUrl: './export-domain-selection-step.component.html',
  styleUrls: ['./export-domain-selection-step.component.scss']
})

export class ExportDomainSelectionStepComponent extends AbstractWizardStep implements OnInit {

  public activeDomain$: Observable<ApplicationDomain>;

  constructor(private exportDomainWizardService: ExportDomainWizardService, private domainService: DomainService) {
    super();
  }

  ngOnInit(): void {
    this.activeDomain$ = this.domainService.activeDomain$;
  }

  isStepValid(): void {
    this.activeDomain$.subscribe(domain => {
      this.exportDomainWizardService.isCurrentStepValid = domain.domainId !== 'admin';
    });
  }

}
