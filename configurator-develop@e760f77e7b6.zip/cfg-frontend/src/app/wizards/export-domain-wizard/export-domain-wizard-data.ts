import {Execution} from '../../domain/execution/execution';

export interface ExportDomainWizardData {
  execution: Execution;
}
