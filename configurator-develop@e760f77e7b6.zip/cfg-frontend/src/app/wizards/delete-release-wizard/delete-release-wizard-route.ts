import {WizardRoute} from '../../domain/wizard/wizard-route';

export class DeleteReleaseWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when DeleteReleaseWizardService is used in DeleteReleaseWizardRouteConfig.
}
