import {DeleteReleaseSelectionStepComponent} from './delete-release-selection-step/delete-release-selection-step.component';
import {DeleteReleaseSummaryStepComponent} from './delete-release-summary-step/delete-release-summary-step.component';

export const list = [
  DeleteReleaseSelectionStepComponent,
  DeleteReleaseSummaryStepComponent
];
