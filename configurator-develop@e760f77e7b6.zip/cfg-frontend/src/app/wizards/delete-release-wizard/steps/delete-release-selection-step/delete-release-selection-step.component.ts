import {Component, OnDestroy, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {DeleteReleaseWizardService} from '../../delete-release-wizard.service';
import {ReleaseService} from '../../../../services/release.service';
import {Release} from '../../../../domain/release/release';
import {Subscription} from 'rxjs';

@Component({
  selector: 'c-delete-release-selection-step',
  templateUrl: './delete-release-selection-step.component.html',
  styleUrls: ['./delete-release-selection-step.component.scss']
})

export class DeleteReleaseSelectionStepComponent extends AbstractWizardStep implements OnInit, OnDestroy {

  public releaseSelectItems: Release[];
  public selectedRelease: Release;
  private subscription: Subscription;

  constructor(private deleteReleaseWizardService: DeleteReleaseWizardService, private readonly releaseService: ReleaseService) {
    super();
  }

  ngOnInit(): void {
    this.getReleasesNotDeployedForDomain();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  getReleasesNotDeployedForDomain(): void {
    this.subscription = this.releaseService.getReleasesNotDeployedForDomain().subscribe(releases => {
      this.releaseSelectItems = releases.map(release => {
        return JSON.parse(JSON.stringify(release));
      });
    });
  }

  onSelectedReleaseChange(): void {
    this.deleteReleaseWizardService.wizardData.release = this.releaseSelectItems.find(releaseItem => releaseItem.id === this.selectedRelease.id);
  }

  isStepValid(): void {
    this.deleteReleaseWizardService.isCurrentStepValid = this.selectedRelease != null;
  }

}
