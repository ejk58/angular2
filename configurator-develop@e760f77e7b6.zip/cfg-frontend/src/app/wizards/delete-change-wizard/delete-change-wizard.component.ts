import {Component, OnInit} from '@angular/core';
import {DeleteChangeWizardService} from './delete-change-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {DeleteChangeWizardRoute} from './delete-change-wizard-route';
import {SpinnerService} from '../../services/spinner.service';

@Component({
  selector: 'c-delete-change-wizard',
  templateUrl: './delete-change-wizard.component.html',
  styleUrls: ['./delete-change-wizard.component.scss']
})
export class DeleteChangeWizardComponent extends AbstractWizard implements OnInit {

  constructor(public deleteChangeWizardService: DeleteChangeWizardService,
              private readonly spinnerService: SpinnerService,
              private readonly deleteChangeWizardRoute: DeleteChangeWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(deleteChangeWizardService, spinnerService, deleteChangeWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.deleteChangeWizardService.initializeWizard();
  }

}
