import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {Observable} from 'rxjs';
import {Change} from '../../../../domain/change/change';
import {DeleteChangeWizardService} from '../../delete-change-wizard.service';
import {ChangeService} from '../../../../services/change.service';

@Component({
  selector: 'c-delete-change-step',
  templateUrl: './delete-change-step.component.html',
  styleUrls: ['./delete-change-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: DeleteChangeStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class DeleteChangeStepComponent extends AbstractWizardStep implements OnInit {

  public change: Change;
  public deleteChange: boolean;

  constructor(private readonly deleteChangeWizardService: DeleteChangeWizardService,
              private readonly changeService: ChangeService) {
    super();
  }

  ngOnInit(): void {
    this.change = this.deleteChangeWizardService.wizardData.change;
  }

  public executeChanges(): Observable<string> {
    return this.changeService.delete(this.deleteChangeWizardService.wizardData.change.id);
  }

  isStepValid(): void {
    this.deleteChangeWizardService.isCurrentStepValid = this.deleteChange != null && this.deleteChange != false;
  }

}
