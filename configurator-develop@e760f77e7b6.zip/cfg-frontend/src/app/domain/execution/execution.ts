import {ExecutionStatus} from './execution-status';

export interface Execution {
  status: ExecutionStatus;
  message: string;
}
