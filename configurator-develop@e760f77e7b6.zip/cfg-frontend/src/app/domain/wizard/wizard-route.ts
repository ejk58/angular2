import {WizardRouteSection} from './wizard-route-section';
import {WizardRouteSplit} from './wizard-route-split';
import {WizardStep} from './wizard-step';

export class WizardRoute {

  // Data about the route (= the route configuration)
  private readonly nameLocal: string;
  private readonly sectionsLocal: WizardRouteSection[];
  private readonly splitsLocal: WizardRouteSplit[];
  private readonly startSectionLocal: WizardRouteSection;

  // Data about the current route (= the route as far as the user has progressed)
  private currentSectionsLocal: WizardRouteSection[];
  private currentStepsLocal: WizardStep[];
  private currentSectionLocal: WizardRouteSection;
  private currentStepLocal: WizardStep;

  constructor(name: string, sections: WizardRouteSection[], splits: WizardRouteSplit[], startSection: WizardRouteSection) {
    this.nameLocal = name;
    this.sectionsLocal = [...sections];
    this.splitsLocal = [...splits];
    this.startSectionLocal = startSection;
    this.reset();
  }

  get name(): string {
    return this.nameLocal;
  }

  get sections(): WizardRouteSection[] {
    return this.sectionsLocal;
  }

  get splits(): WizardRouteSplit[] {
    return this.splitsLocal;
  }

  get currentSections(): WizardRouteSection[] {
    return this.currentSectionsLocal;
  }

  get currentSteps(): WizardStep[] {
    return this.currentStepsLocal;
  }

  get currentSection(): WizardRouteSection {
    return this.currentSectionLocal;
  }

  set currentSection(currentSection: WizardRouteSection) {
    this.currentSectionLocal = currentSection;
  }

  get currentStep(): WizardStep {
    return this.currentStepLocal;
  }

  set currentStep(currentStep: WizardStep) {
    this.currentStepLocal = currentStep;
  }

  public reset(): void {
    this.currentSteps?.forEach(step => step.data = undefined);
    this.currentSectionsLocal = [this.startSectionLocal];
    this.currentStepsLocal = [...this.startSectionLocal.steps];
    this.currentSection = this.startSectionLocal;
    this.currentStep = this.currentSection.steps[0];
    this.addSeqNrToSteps();
  }

  public addSeqNrToSteps(): void {
    this.currentSteps.forEach((step, index) => step.seqNr = index);
  }

  public getCurrentSplit(): WizardRouteSplit {
    return this.splits.find(split => split.belongsToRouteSection === this.currentSection);
  }

  public getPreviousSection(): WizardRouteSection {
    const index = this.currentSections.indexOf(this.currentSection);
    return this.currentSections[index - 1];
  }

  public getNextStep(): WizardStep {
    const index = this.currentSteps.indexOf(this.currentStep);
    return this.currentSteps[index + 1];
  }

  public getPreviousStep(): WizardStep {
    const index = this.currentSteps.indexOf(this.currentStep);
    return this.currentSteps[index - 1];
  }

  public isCurrentStepFirstStepInRoute(): boolean {
    return this.currentStep.name === this.currentSteps[0].name;
  }

  public isCurrentStepLastStepInRoute(): boolean {
    return this.isCurrentStepLastStepInCurrentSection() && !this.isSplitInCurrentSection();
  }

  public isCurrentStepInCurrentSection(): boolean {
    return this.currentSection.steps.some(step => step.name === this.currentStep.name);
  }

  public isCurrentStepLastStepInCurrentSection(): boolean {
    return this.currentSection.steps[this.currentSection.steps.length - 1].name === this.currentStep.name;
  }

  public isSplitInCurrentSection(): boolean {
    return this.getCurrentSplit() !== undefined;
  }

}
