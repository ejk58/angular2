import {PageWidget} from '../page/page-widget';

export interface PageDto {
  id: number;
  key: string;
  title: string;
  widgets: PageWidget[];
  type: 'main' | 'detail';
  domainKey: string;
  tag: string;
}
