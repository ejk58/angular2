import {Widget} from '../widget/widget';
import {ApplicationDomain} from '../application/application-domain';

export interface WidgetDtoExtended {
  widget: Widget;
  tag: string;
  groupDomain: ApplicationDomain;
}
