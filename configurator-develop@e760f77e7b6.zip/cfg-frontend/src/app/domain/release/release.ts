
export interface Release {
  id: number;
  tag: string;
  domainKey?: string;
  date?: string;
  administrator?: string;
}
