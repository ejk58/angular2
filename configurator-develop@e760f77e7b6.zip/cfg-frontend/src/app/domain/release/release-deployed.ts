import {Environment} from '../environment/environment';
import {Release} from './release';

export interface ReleaseDeployed {
  domainKey: string;
  release: Release;
  environment: Environment;
  administrator: string;
  deploymentDate: Date;
}
