export interface Page {
  id: number;
  key: string;
  title: string;
  type: 'main'|'detail';
}
