export interface ApplicationDomain {
    domainId: string;
    domainName: string;
}
