export interface TableColumn {
  field: string;
  header: string
}
