import {QueryColumn} from './query-column';
import {QueryFilter} from './query-filter';

export interface Query {
  id: number;
  type: number;
  viewname: string;
  querytemplate: string;
  key: string;
  datasource: number;
  columnList: QueryColumn[];
  queryFilterList: QueryFilter[];
}
