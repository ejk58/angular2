export class QueryFilter {
  public id: number;
  public filterTemplate: string;
  public noFilterTemplate?: string;
  public parameter?: string;
}
