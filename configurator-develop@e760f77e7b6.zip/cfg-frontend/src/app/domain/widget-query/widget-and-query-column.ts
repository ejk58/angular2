import {QueryColumn} from '../query/query-column';
import {WidgetColumn} from '../widget/widget-column';

export class WidgetAndQueryColumn {
  public id: number;
  public queryColumn: QueryColumn;
  public widgetColumn: WidgetColumn;
}
