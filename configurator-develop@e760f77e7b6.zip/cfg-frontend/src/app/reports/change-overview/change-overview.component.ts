import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {ChangeService} from '../../services/change.service';
import {ChangeReleaseEnvironmentInfo} from '../../domain/change/change-release-environment-info';
import {Table} from 'primeng/table';

@Component({
  selector: 'c-change-overview',
  templateUrl: './change-overview.component.html',
  styleUrls: ['./change-overview.component.scss']
})
export class ChangeOverviewComponent implements OnInit {

  public changesReleaseEnvironmentInfo: ChangeReleaseEnvironmentInfo[] = [];

  @ViewChild('globalFilter', {static: false}) globalFilterInput: ElementRef<HTMLInputElement>;
  @ViewChild('dtchanges', {static: false}) dtchanges: Table;

  constructor(private readonly changeService: ChangeService) { }

  ngOnInit(): void {
    this.getChangesReleaseEnvironmentInfo();
  }

  private getChangesReleaseEnvironmentInfo(): void {
    this.changeService.getChangesReleaseEnvironmentInfo().subscribe(changesReleaseEnvironmentInfo => {
      this.changesReleaseEnvironmentInfo = changesReleaseEnvironmentInfo;
    });
  }

  clear(table: Table): void {
    table.clear();
    this.globalFilterInput.nativeElement.value = '';
    this.dtchanges.filterGlobal('', 'contains');
  }
}
