import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Subject} from 'rxjs';
import {ErrorService} from './services/error.service';
import {takeUntil} from 'rxjs/operators';
import {ErrorComponent} from './components/error/error.component';
import {DialogService} from 'primeng/dynamicdialog';

@Component({
  selector: 'c-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit, OnDestroy {

  // Necessary to show modal ErrorComponent automatically
  @ViewChild('hiddenModalBtn', {read: ElementRef}) myHiddenModalBtn: ElementRef;

  private readonly ngUnsubscribe$ = new Subject();
  private errorDialogOpen: boolean = false;

  constructor(private readonly errorService: ErrorService, private readonly dialogService: DialogService) {
  }

  ngOnInit(): void {
    this.initializeModalForErrorMessage();
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe$.next();
    this.ngUnsubscribe$.complete();
  }

  // Only necessary to show modal ErrorComponent automatically.
  public openModalForErrorMessage(): void {
    // Intentionally left empty.
  }

  private initializeModalForErrorMessage(): void {
    this.errorService
      .getErrorMessage()
      .pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe(errorMessage => {
        if (!this.errorDialogOpen) {
          const ref = this.dialogService.open(ErrorComponent, {data: {errorMessage}, header: 'Foutmelding', width: '50%'});
          this.errorDialogOpen = true;
          this.myHiddenModalBtn.nativeElement.click(); // Show modal ErrorComponent automatically
          ref.onClose.subscribe(() => this.errorDialogOpen = false);
        }
      });
  }

}
