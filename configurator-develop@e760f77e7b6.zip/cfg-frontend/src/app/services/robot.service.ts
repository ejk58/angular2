import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {RobotTests} from '../domain/dto/robot-tests';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class RobotService {

  private readonly robotUrl = 'api/robot';

  constructor(private readonly http: HttpClient) { }

  exportRobotScript(dto: RobotTests): Observable<string> {
    return this.http.post(`${this.robotUrl}/export`, dto, {responseType: 'text'});
  }

}
