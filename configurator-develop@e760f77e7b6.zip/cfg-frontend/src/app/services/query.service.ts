import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {Query} from '../domain/query/query';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class QueryService {

  private readonly queryUrl = 'api/query';

  constructor(private readonly http: HttpClient) { }

  getQueryKeys(): Observable<string[]> {
    return this.http.get<string[]>(`${this.queryUrl}/keys`);
  }

  getQuery(key: string): Observable<Query> {
    return this.http.get<Query>(`${this.queryUrl}/${key}`);
  }

}
