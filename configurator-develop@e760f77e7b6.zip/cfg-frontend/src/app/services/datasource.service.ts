import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class DatasourceService {

  private readonly datasourcesUrl = '/api/datasources';

  constructor(private readonly http: HttpClient) { }

  getDatasourceViews(): Observable<any> {
    return this.http.get(this.datasourcesUrl + '/views');
  }

  getViewColumns(viewName: string): Observable<string[]> {
    return this.http.get<string[]>(this.datasourcesUrl + '/columns/' + viewName);
  }

  getQueryValidation(queryTemplate: string): Observable<string> {
    return this.http.get(this.datasourcesUrl + '/validate/' + queryTemplate, {responseType: 'text'});
  }
}
