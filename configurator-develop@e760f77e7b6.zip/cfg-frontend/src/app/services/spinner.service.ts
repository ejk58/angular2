import {BehaviorSubject, Observable} from 'rxjs';

export class SpinnerService {

  private isSpinningLocal$: BehaviorSubject<boolean> = new BehaviorSubject(false);

  public show(): void {
    this.isSpinningLocal$.next(true);
  }

  public hide(): void {
    this.isSpinningLocal$.next(false);
  }

  get isSpinning$(): Observable<boolean> {
    return this.isSpinningLocal$.asObservable();
  }
}
