import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {map, switchMap} from 'rxjs/operators';
import {Observable, of} from 'rxjs';
import {Widget} from '../domain/widget/widget';
import {WidgetWizardData} from '../wizards/widget-wizards/common/widget-wizard-data';
import {DomainService} from './domain.service';
import {WidgetDtoExtended} from '../domain/dto/widget-dto-extended';

@Injectable()
export class WidgetService {

  private readonly widgetUrl = 'api/widget';

  constructor(private readonly http: HttpClient, private readonly domainService: DomainService) { }

  getWidget(name: string): Observable<Widget> {
    return this.http.get<Widget>(`${this.widgetUrl}/${name}`);
  }

  getWidgetNamesForDomainOrGeneric(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return domain.domainId === 'admin' ? this.getWidgetNamesForGeneric() : this.getWidgetNamesForDomain(domain.domainId);
          } else {
            return of(undefined);
          }
        })
      );
  }

  getWidgetNamesForDomainAndGeneric(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string[]>(`${this.widgetUrl}/names/generic/${domain.domainId}`)
              .pipe(map(widgetNames => widgetNames ? widgetNames : undefined));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getAllWidgetNames(): Observable<string[]> {
    return this.http.get<string[]>(`${this.widgetUrl}/names`);
  }

  getWidgetTypes(): Observable<string[]> {
    return this.http.get<string[]>(`${this.widgetUrl}/types`);
  }

  saveWidget(widgetWizardData: WidgetWizardData): Observable<string> {
    const widgetDtoExtended: WidgetDtoExtended = {
      widget: widgetWizardData.widget,
      tag: widgetWizardData.tag,
      groupDomain: this.domainService.activeDomain
    };
    return this.http.post(`${this.widgetUrl}/save`, widgetDtoExtended, {responseType: 'text'});
  }

  private getWidgetNamesForDomain(domainId: string): Observable<string[]> {
    return this.http.get<string[]>(`${this.widgetUrl}/names/${domainId}`)
      .pipe(map(widgetNames => widgetNames ? widgetNames : undefined));
  }

  private getWidgetNamesForGeneric() {
    return this.http.get<string[]>(`${this.widgetUrl}/names/generic`)
      .pipe(map(widgetNames => widgetNames ? widgetNames : undefined));
  }

}
