import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class ConfigurationService {

  private readonly configurationUrl = 'api/configuration';

  constructor(private readonly http: HttpClient) { }

  getDomainSql(domainId: string): Observable<string> {
    return this.http.get<string>(`${this.configurationUrl}/export/${domainId}`);
  }
}
