import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {map, switchMap} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {DomainService} from './domain.service';
import {ChangeReleaseEnvironmentInfo} from '../domain/change/change-release-environment-info';
import {Change} from '../domain/change/change';

@Injectable()
export class ChangeService {

  private readonly changeUrl = 'api/change';

  constructor(private readonly http: HttpClient, private readonly domainService: DomainService) { }

  getMostRecentChange(): Observable<string> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string>(`${this.changeUrl}/mostRecent/${domain.domainId}`)
              .pipe(map(change => change ? change : undefined));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getChangesForDomain(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string[]>(`${this.changeUrl}/changes/${domain.domainId}`)
              .pipe(map(changes => changes ? changes : undefined));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getAllChangeTags(): Observable<string[]> {
    return this.http.get<string[]>(`${this.changeUrl}/allChangeTags`);
  }

  getChangesReleaseEnvironmentInfo(): Observable<ChangeReleaseEnvironmentInfo[]> {
    return this.http.get<ChangeReleaseEnvironmentInfo[]>(`${this.changeUrl}/overview`);
  }

  getChange(changeId: number): Observable<Change> {
    return this.http.get<Change>(`${this.changeUrl}/${changeId}`);
  }

  delete(changeId: number): Observable<string> {
    return this.http.delete(`${this.changeUrl}/delete/${changeId}`, {responseType: 'text'});
  }

}
