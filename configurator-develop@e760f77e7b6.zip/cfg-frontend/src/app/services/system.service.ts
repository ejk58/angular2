import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {Version} from '../domain/system/version';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class SystemService {

  private readonly systemUrl = 'api/system';

  constructor(private readonly http: HttpClient) { }

  getVersion(): Observable<Version> {
    return this.http.get<Version>(`${this.systemUrl}/version`);
  }
}
