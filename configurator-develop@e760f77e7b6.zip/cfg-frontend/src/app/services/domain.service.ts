import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {ApplicationDomain} from '../domain/application/application-domain';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class DomainService  {

  private readonly domainUrl = 'api/domain';
  private activeDomainLocal$: BehaviorSubject<ApplicationDomain> = new BehaviorSubject({domainId: '', domainName: ''});
  private activeDomainLocal: ApplicationDomain;

  constructor(private readonly http: HttpClient) { }

  get activeDomain$(): Observable<ApplicationDomain> {
    return this.activeDomainLocal$.asObservable();
  }

  get activeDomain(): ApplicationDomain {
    return this.activeDomainLocal;
  }

  getDomains(): Observable<ApplicationDomain[]> {
    return this.http.get<ApplicationDomain[]>(`${this.domainUrl}`);
  }

  activateDomain(domain: ApplicationDomain): void {
    this.activeDomainLocal$.next(domain);
    this.activeDomainLocal = domain;
  }
}
