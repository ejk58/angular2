import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {map, switchMap} from 'rxjs/operators';
import {PageLayoutDto} from '../domain/dto/page-layout-dto';
import {PageDto} from '../domain/dto/page-dto';
import {DomainService} from './domain.service';

@Injectable()
export class PageService {

  private readonly pageUrl = 'api/page';

  constructor(private readonly http: HttpClient, private readonly domainService: DomainService) {
  }

  getAllPageKeys(): Observable<string[]> {
    return this.http.get<string[]>(`${this.pageUrl}/keys`);
  }

  getPageKeysForDomain(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string[]>(`${this.pageUrl}/keys/${domain.domainId}`)
              .pipe(map(pageKeys => pageKeys ? pageKeys : undefined));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getPage(pageKey: string): Observable<PageDto> {
    return this.http.get<PageDto>(`${this.pageUrl}/${pageKey}`);
  }

  getPageLayout(pageKey: string): Observable<PageLayoutDto> {
    return this.http.get<PageLayoutDto>(`${this.pageUrl}/layout/${pageKey}`);
  }

  changePageLayout(layout: PageLayoutDto): Observable<string> {
    const layoutWithDomain = {...layout, groupDomain: this.domainService.activeDomain};
    return this.http.post(`${this.pageUrl}/changeLayout`, layoutWithDomain, {responseType: 'text'});
  }

  newPage(pageDto: PageDto): Observable<string> {
    const pageDtoWithDomain = {...pageDto, groupDomain: this.domainService.activeDomain};
    return this.http.post(`${this.pageUrl}/new`, pageDtoWithDomain, {responseType: 'text'});
  }
}
