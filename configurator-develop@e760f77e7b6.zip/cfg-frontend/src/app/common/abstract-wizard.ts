import {WizardRoute} from '../domain/wizard/wizard-route';
import {MenuItem} from 'primeng/api';
import {WizardRouteSection} from '../domain/wizard/wizard-route-section';
import {WizardStore} from '../domain/wizard/wizard-store';
import {WizardStep} from '../domain/wizard/wizard-step';
import {Directive, OnDestroy, ViewChild} from '@angular/core';
import {WizardRouteStepType} from '../domain/wizard/wizard-route-step-type';
import {AbstractWizardStep} from './abstract-wizard-step';
import {AbstractWizardService} from '../services/abstract-wizard.service';
import {WizardData} from '../domain/wizard/wizard-data';
import {ExecutionStatus} from '../domain/execution/execution-status';
import {SpinnerService} from '../services/spinner.service';
import {finalize} from 'rxjs/operators';

@Directive()
// eslint-disable-next-line @angular-eslint/directive-class-suffix
export abstract class AbstractWizard implements OnDestroy {

  private readonly serviceLocal: AbstractWizardService<WizardData>;
  private readonly spinnerServiceLocal: SpinnerService;
  private readonly routeLocal: WizardRoute;
  private readonly storeLocal: WizardStore;
  private readonly menuItemsLocal: MenuItem[] = [];

  @ViewChild(AbstractWizardStep) executionWizardStep: AbstractWizardStep;

  protected constructor(service: AbstractWizardService<WizardData>, spinnerService: SpinnerService, route: WizardRoute, store: WizardStore) {
    this.serviceLocal = service;
    this.spinnerServiceLocal = spinnerService;
    this.routeLocal = route;
    this.storeLocal = store;
    this.addMenuItems(this.route.currentSteps);
    this.store.broadcastIsCurrentStepFirstStep(this.route.isCurrentStepFirstStepInRoute()); // Broadcast 'is current step first step in route'
  }

  get service(): AbstractWizardService<WizardData> {
    return this.serviceLocal;
  }

  get route(): WizardRoute {
    return this.routeLocal;
  }

  get store(): WizardStore {
    return this.storeLocal;
  }

  get menuItems(): MenuItem[] {
    return this.menuItemsLocal;
  }

  // Necessary for use of WizardRouteStepType in html
  get wizardRouteStepType(): typeof WizardRouteStepType {
    return WizardRouteStepType;
  }

  ngOnDestroy(): void {
    this.route.reset();
    this.store.resetDataForWizard(this.route.name);
  }

  public isCurrentStepValid(): boolean {
    return this.service.isCurrentStepValid;
  }

  public nextStep(): void {

    if (this.route.isCurrentStepLastStepInCurrentSection()) {
      const currentSplit = this.route.getCurrentSplit();
      if (currentSplit) {
        const nextSection = currentSplit.goesToRouteSection();
        this.route.currentSection = nextSection;
        this.addSectionToCurrentRoute(nextSection);
        this.addStepsToCurrentRoute(nextSection.steps);
        this.addMenuItems(nextSection.steps);
      }
    }

    this.store.saveDataForWizard(this.route.name, this.route.currentStep.data); // Save data of current step in store
    this.route.currentStep.data = undefined; // Remove data from current step
    this.route.currentStep = this.route.getNextStep(); // Set current step to next step
    this.route.currentStep.data = this.store.getDataForWizard(this.route.name); // Set data for next step
    this.store.broadcastIsCurrentStepFirstStep(this.route.isCurrentStepFirstStepInRoute()); // Broadcast 'is current step first step in route'
  }

  public previousStep(): void {

    this.store.saveDataForWizard(this.route.name, this.route.currentStep.data); // Save data of current step in store
    this.route.currentStep.data = undefined; // Remove data from current step
    this.route.currentStep = this.route.getPreviousStep(); // Set current step to previous step
    this.route.currentStep.data = this.store.getDataForWizard(this.route.name); // Set data for previous step
    this.store.broadcastIsCurrentStepFirstStep(this.route.isCurrentStepFirstStepInRoute()); // Broadcast 'is current step first step in route'

    if (!this.route.isCurrentStepInCurrentSection()) {
      this.route.currentSection = this.route.getPreviousSection();
      const deletedSection = this.deleteSectionFromCurrentRoute();
      const numberOfStepsToDelete = deletedSection.steps.length;
      this.deleteStepsFromCurrentRoute(numberOfStepsToDelete);
      this.deleteMenuItems(numberOfStepsToDelete);
    }
  }

  public firstStep(): void {
    this.service.initializeWizard(); // Initialize route, store and data for wizard
    this.menuItems.length = 0; // Empty menuItems array
    this.addMenuItems(this.route.currentSteps);
    this.store.broadcastIsCurrentStepFirstStep(this.route.isCurrentStepFirstStepInRoute()); // Broadcast 'is current step first step in route'
  }

  public executeChanges(): void {
    this.spinnerServiceLocal.show();
    this.executionWizardStep.executeChanges()
      .pipe(
        finalize(() => {
          this.spinnerServiceLocal.hide();
        }))
      .subscribe(
        response => {
          this.service.wizardData.execution.status = ExecutionStatus.Success;
          this.service.wizardData.execution.message = response;
          this.nextStep();
        },
        error => {
          this.service.wizardData.execution.status = ExecutionStatus.Failure;
          this.service.wizardData.execution.message = `${error.error} (${error.status})`;
          if (error.status === 401 || error.status === 403) {
            localStorage.removeItem('id_token');
          }
          this.nextStep();
        });
  }

  private addSectionToCurrentRoute(nextSection: WizardRouteSection) {
    this.route.currentSections.push(nextSection);
  }

  private deleteSectionFromCurrentRoute(): WizardRouteSection {
    return this.route.currentSections.pop();
  }

  private addStepsToCurrentRoute(steps: WizardStep[]): void {
    this.route.currentSteps.push(...steps);
    this.route.addSeqNrToSteps();
  }

  private deleteStepsFromCurrentRoute(numberOfStepsToDelete: number): void {
    const currentNumberOfSteps = this.route.currentSteps.length;
    this.route.currentSteps.splice(currentNumberOfSteps - numberOfStepsToDelete, numberOfStepsToDelete);
  }

  private addMenuItems(steps: WizardStep[]): void {
    const newMenuItems: MenuItem[] = steps.map(step => ({step: step.seqNr, label: step.label}));
    this.menuItems.push(...newMenuItems);
  }

  private deleteMenuItems(numberOfItemsToDelete: number): void {
    const currentNumberOfMenuItems = this.menuItems.length;
    this.menuItems.splice(currentNumberOfMenuItems - numberOfItemsToDelete, numberOfItemsToDelete);
  }

}
