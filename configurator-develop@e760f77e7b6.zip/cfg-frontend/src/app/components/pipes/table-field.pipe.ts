import {Pipe, PipeTransform} from '@angular/core';
import {TableColumn} from '../../domain/table/table-column';

@Pipe({
  name: 'tableField'
})
/**
 * Gets the value for normal ('description') and nested ('widget.name') fields in a table-column.
 */
export class TableFieldPipe implements PipeTransform {

  transform(value: any, column: TableColumn): any {
    let result = value;
    column.field.split('.').forEach(propName => result = result[propName]);
    return result;
  }
}
