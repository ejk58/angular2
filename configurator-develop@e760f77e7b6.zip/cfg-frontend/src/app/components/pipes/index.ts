import {TableFieldPipe} from './table-field.pipe';
import {DateTimePipe} from './date-time.pipe';

export const list = [
  TableFieldPipe,
  DateTimePipe
];
