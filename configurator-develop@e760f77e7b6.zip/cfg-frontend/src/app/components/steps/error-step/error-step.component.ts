import {Component, Input} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';

@Component({
  selector: 'c-error-step',
  templateUrl: './error-step.component.html',
  styleUrls: ['./error-step.component.scss']
})

export class ErrorStepComponent extends AbstractWizardStep {

  @Input() message: string;

  constructor() {
    super();
  }

  isStepValid(): void {
    // Intentionally left blank
  }

}
