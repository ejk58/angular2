import {Component, Input} from '@angular/core';
import {TableColumn} from '../../domain/table/table-column';

@Component({
  selector: 'c-summary-table',
  templateUrl: './summary-table.component.html',
  styleUrls: ['./summary-table.component.scss']
})

export class SummaryTableComponent {

  @Input() title: string;
  @Input() data: any[];
  @Input() cols: TableColumn[];
  @Input() firstColSmall: boolean = false;

}
