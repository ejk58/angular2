import {Component, EventEmitter, Input, Output} from '@angular/core';
import {PageWidget} from 'src/app/domain/page/page-widget';
import {Direction} from '../../domain/page/direction';

@Component({
  selector: 'c-widget-card',
  templateUrl: './widget-card.component.html',
  styleUrls: ['./widget-card.component.scss']
})

export class WidgetCardComponent {

  @Input() pageWidget: PageWidget;
  @Input() upDisabled: boolean;
  @Input() downDisabled: boolean;
  @Input() leftDisabled: boolean;
  @Input() rightDisabled: boolean;

  @Output() rowMove: EventEmitter<number> = new EventEmitter();
  @Output() columnMove: EventEmitter<number> = new EventEmitter();
  @Output() widthChange: EventEmitter<number> = new EventEmitter();
  @Output() remove: EventEmitter<void> = new EventEmitter();

  moveUp(): void {
    this.rowMove.emit(Direction.Up);
  }

  moveDown(): void {
    this.rowMove.emit(Direction.Down);
  }

  moveLeft(): void {
    this.columnMove.emit(Direction.Left);
  }

  moveRight(): void {
    this.columnMove.emit(Direction.Right);
  }

  changeWidth(width: number): void {
    this.widthChange.emit(width);
  }

  delete(): void {
    this.remove.emit();
  }

}
