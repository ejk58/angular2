import {Component, OnInit} from '@angular/core';
import {DynamicDialogConfig} from 'primeng/dynamicdialog';

@Component({
  selector: 'c-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss']
})
export class ErrorComponent implements OnInit {

  public errorMessage: string;

  constructor(public config: DynamicDialogConfig) { }

  ngOnInit(): void {
    this.errorMessage = this.config.data ? this.config.data.errorMessage : '';
  }

}
