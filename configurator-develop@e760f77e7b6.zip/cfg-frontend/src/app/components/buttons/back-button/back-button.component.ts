import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'c-back-button',
  templateUrl: './back-button.component.html',
  styleUrls: ['./back-button.component.scss']
})
export class BackButtonComponent {

  @Input() hide: boolean;
  @Output() clicked: EventEmitter<void> = new EventEmitter<void>();

  public back(): void {
    this.clicked.emit();
  }

}
