import {Component, EventEmitter, Input, Output} from '@angular/core';
import {AbstractWizardService} from '../../../services/abstract-wizard.service';
import {WizardData} from '../../../domain/wizard/wizard-data';

@Component({
  selector: 'c-execute-button',
  templateUrl: './execute-button.component.html',
  styleUrls: ['./execute-button.component.scss']
})
export class ExecuteButtonComponent {

  @Input() hide: boolean;
  @Input() label: string;
  @Input() wizardService: AbstractWizardService<WizardData>;
  @Output() clicked: EventEmitter<void> = new EventEmitter<void>();

  public execute(): void {
    this.clicked.emit();
  }

}
