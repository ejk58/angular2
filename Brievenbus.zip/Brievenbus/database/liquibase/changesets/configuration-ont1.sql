DELETE FROM ivab01.configuration;

INSERT INTO ivab01.configuration("key", "value") VALUES ('noOfDaysFileIsAvailable', '14');
INSERT INTO ivab01.configuration("key", "value") VALUES ('maxFileSizeMb', '2000');