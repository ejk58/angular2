'use strict'

export const APPURL = {
  baseUrl: {
    adp: 'https://adp-wd-brievenbus.apps.dtap.belastingdienst.nl/',
    dwb: 'https://dwb-wd-brievenbus.apps.dtap.belastingdienst.nl/'
  },
  pageId: {
    login: 'login'
    }
}

export const BRIEVENBUS_USER = {
  user: {
    ivatest1: 'ivatest1',
    ivatest2: 'ivatest2',
    password: 'Welkom01'
  }
}
