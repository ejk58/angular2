import {checkRegion} from '../../../../shared/imageCompare';
import {Login} from '../../../../shared/login';
import {BRIEVENBUS_USER} from '../../../../shared/shared.constants';
import SelectPo from '../select/select.po';
import CheckPo from '../check/check.po';
import SendPo from './send.po';
import {browser} from 'protractor';

describe('Send (adp): Send', () => {

  let remote = require('selenium-webdriver/remote');
  let login, selectPo, checkPo, sendPo;

  beforeAll(async () => {
    login = new Login();
    selectPo = new SelectPo();
    checkPo = new CheckPo();
    sendPo = new SendPo();

    await browser.setFileDetector(new remote.FileDetector());
    await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
    await selectPo.receiversUserid.sendKeys('ivatest2');
    await selectPo.receiversButtonPlus.click();
    await selectPo.fileUploadInput.sendKeys(`${process.cwd()}/src/test/e2e/resources/upload.txt`);
    await selectPo.buttonContainerConfirm.click();
  });

  afterAll(async () => {
    await login.logoutFromApp();
  });

  describe('Send', () => {

    it('should show initial send page', async () => {
      await sendPo.wizardContinue.click();
      await checkRegion(sendPo.wizardContainer,'sendSendInitial',false,false);
    });

    it('should show a new delivery page', async () => {
      await sendPo.wizardContinue.click();
      await checkRegion(sendPo.wizardContainer,'sendSendNewDelivery',false,false);
    });

  });

});
