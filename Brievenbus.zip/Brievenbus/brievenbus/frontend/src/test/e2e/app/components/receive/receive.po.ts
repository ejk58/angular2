'use strict'

import {by, element} from 'protractor';

export default class ReceivePo {
  checkCheckBox = element(by.css('.p-checkbox-box'));
  downloadButton = element(by.css('button.continue'));
  toast = element.all(by.css('p-toastitem'));
  appMessage = element(by.css('app-receive'));
}
