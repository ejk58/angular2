import {checkRegion, checkWindow} from '../../../shared/imageCompare';
import {Login} from '../../../shared/login';
import {BRIEVENBUS_USER} from '../../../shared/shared.constants';
import ReceivePo from './receive.po';
import {setLocation} from '../../../shared/general';

describe('Receive (dwb): Download', () => {

  let login, receivePo;

  beforeAll(async () => {
    login = new Login();
    receivePo = new ReceivePo();

    await login.loginToApp('dwb', BRIEVENBUS_USER.user.ivatest2, BRIEVENBUS_USER.user.password);
  });

  afterAll(async () => {
    await login.logoutFromApp();
  });

  describe('Download', () => {

    it('should show initial recieve page when logged in without uuid', async () => {
      await checkWindow('receiveLoggedInInitialWithoutUUID');
    });

    it('should show recieve page with invalid uuid', async () => {
      await setLocation('receive?8fba387d-5954-424b-9999-6d2306215a12');
      await expect(receivePo.appMessage.getText()).toEqual('Probleem\nKlik op de link in de mail om een levering op te halen.');
    });

    it('should show initial recieve page with valid uuid', async () => {
      await setLocation('receive?uuid=a60b683b-cd31-41f5-8c50-1ad4a6d5cdac');
      await checkWindow('receiveWithValidUUID');
    });

    it('should show disabled downloaded button', async () => {
      await expect(receivePo.downloadButton.getAttribute('disabled')).toBe("true");
    });

    it('should show file downloaded toast', async () => {
      await receivePo.checkCheckBox.click();
      await expect(receivePo.downloadButton.getAttribute('disabled')).toBe(null);
      await receivePo.downloadButton.click();
      await checkRegion(receivePo.toast.get(0),'receiveFileDownloaded',false,false);
    });

  });

});
