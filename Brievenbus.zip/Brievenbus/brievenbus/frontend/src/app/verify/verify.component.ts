import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Delivery} from '../domain/delivery';
import {DisclaimerType} from '../domain/disclaimer-type';

@Component({
  selector: 'b-verify',
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.scss']
})

export class VerifyComponent {
  @Input() readonly delivery: Delivery;
  @Output() changeChecked: EventEmitter<boolean> = new EventEmitter<boolean>();

  public readonly disclaimerType: DisclaimerType = 'verify';

  public onChangeChecked(isChecked: boolean): void {
    this.changeChecked.emit(isChecked);
  }
}
