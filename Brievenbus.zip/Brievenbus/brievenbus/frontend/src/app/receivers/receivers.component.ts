import {Component, ElementRef, EventEmitter, Input, Output, ViewChild} from '@angular/core';
import {ReceiverService} from '../services/receiver.service';
import {MessageService} from 'primeng/api';
import {Receiver} from '../domain/receiver';

@Component({
  selector: 'b-receivers',
  templateUrl: './receivers.component.html',
  styleUrls: ['./receivers.component.scss'],
  providers: [MessageService]
})
export class ReceiversComponent {

  @Input() receivers: Receiver[];
  @Input() readOnly: boolean;
  @Output() changeReceivers: EventEmitter<Receiver[]> = new EventEmitter<Receiver[]>();

  @ViewChild('userIdInput') userIdInput: ElementRef;

  public loading = false;

  constructor(
    private readonly messageService: MessageService,
    private readonly receiverService: ReceiverService) {
  }

  public addReceiver(): void {
    this.loading = true;
    const userId = this.userIdInput.nativeElement.value;

    if (userId === null || userId.match(/^ *$/) !== null) {
      this.messageService.add({
        closable: true,
        sticky: true,
        severity: 'error',
        summary: `Ontvanger mag niet leeg zijn`
      });
      this.loading = false;
    } else {
      this.receiverService.getReceiver(userId).subscribe(employee => {
        if (employee != null) {
          this.messageService.add({
            closable: false,
            severity: 'success',
            summary: `Ontvanger is toegevoegd`,
            detail: `${employee.name}`
          });
          this.receivers.push(employee);
          this.userIdInput.nativeElement.value = '';
          this.changeReceivers.emit(this.receivers);
          this.loading = false;
        } else {
          this.messageService.add({
            closable: true,
            sticky: true,
            severity: 'error',
            summary: `Ontvanger niet gevonden`,
            detail: `${userId} is onbekend`
          });
          this.loading = false;
        }
      }, err => {
        this.messageService.add({
          closable: true,
          sticky: true,
          severity: 'error',
          summary: `Er is iets misgegaan (${err.status})`,
          detail: `${(err.error.message) ? err.error.message : ''}`
        });
        this.loading = false;
      });
    }
  }

  public removeReceiver(index: number): void {
    this.messageService.add({
      closable: false,
      severity: 'success',
      summary: `Ontvanger verwijderd`,
      detail: `${this.receivers[index].name} is verwijderd`
    });
    this.receivers.splice(index, 1);
    this.changeReceivers.emit(this.receivers);
  }
}
