export type DisclaimerType = 'verify' | 'receive';
