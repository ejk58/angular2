export interface Receiver {
  userId: string;
  email: string;
  name: string;
}
