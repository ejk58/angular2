import {Component, OnInit} from '@angular/core';
import {LoginService} from '../services/login.service';
import {Router} from '@angular/router';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public form: FormGroup;
  public submitted = false;

  public errorMessage: string;
  public loading = false;

  constructor(private router: Router,
              private formBuilder: FormBuilder,
              private loginService: LoginService) {
    this.form = this.formBuilder.group({
      userId: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.form.valueChanges.subscribe(_ => this.errorMessage = null);
  }

  public login() {
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    this.loginService.login(this.form.value).subscribe(
      (data) => {
        this.router.navigate(['/'], {queryParamsHandling: 'preserve'});
      },
      (err: any) => {
        console.warn(err);
        this.errorMessage = err;
        this.loading = false;
      });
  }

  // Convenience getter for easy access to form fields
  get formControl(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
}
