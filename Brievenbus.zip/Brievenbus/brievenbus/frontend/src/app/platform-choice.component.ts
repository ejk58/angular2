import {Component, OnInit} from '@angular/core';
import {ApplicationPlatform} from './domain/application-platform';
import {Router} from '@angular/router';
import {AppConfigService} from './services/app-config.service';

@Component({
  selector: 'app-platform-choice',
  template: ''
})
export class PlatformChoiceComponent implements OnInit {

  constructor(private appConfigService: AppConfigService,
                private router: Router) { }

  ngOnInit() {
    if (this.appConfigService.getApplicationPlatform() === ApplicationPlatform.ADP) {
      this.router.navigate(['send'], {queryParamsHandling: 'preserve'});
    } else if (this.appConfigService.getApplicationPlatform() === ApplicationPlatform.DWB) {
      this.router.navigate(['receive'], {queryParamsHandling: 'preserve'});
    } else {
      this.router.navigate(['login']);
    }
  }
}
