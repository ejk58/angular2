import {Component, OnInit} from '@angular/core';
import {LoginService} from './services/login.service';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  title = 'Brievenbus';
  isLoggedIn$: Observable<boolean>;
  loggedInUser$: Observable<string>;

  constructor(private loginService: LoginService) { }

  ngOnInit(): void {
    this.isLoggedIn$ = this.loginService.isLoggedIn();
    this.loggedInUser$ = this.loginService.loggedInUser();
  }

  logout(): void {
    this.loginService.logout();
  }

}
