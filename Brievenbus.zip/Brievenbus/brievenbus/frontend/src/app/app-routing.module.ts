import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoginComponent} from './login/login.component';
import {LoggedInGuard} from './guards/logged-in.guard';
import {WizardComponent} from './wizard/wizard.component';
import {SendGuard} from './guards/send.guard';
import {ReceiveComponent} from './receive/receive.component';
import {ReceiveGuard} from './guards/receive.guard';
import {PlatformChoiceComponent} from './platform-choice.component';
import {ErrorComponent} from './error/error.component';

const routes: Routes = [
  {path: 'error', component: ErrorComponent},
  {path: 'login', component: LoginComponent},
  {path: 'send', component: WizardComponent, canActivate: [LoggedInGuard, SendGuard]},
  {path: 'receive', component: ReceiveComponent, canActivate: [LoggedInGuard, ReceiveGuard]},
  {path: '', component: PlatformChoiceComponent, canActivate: [LoggedInGuard]},
  {path: '**', redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, enableTracing: false, relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
