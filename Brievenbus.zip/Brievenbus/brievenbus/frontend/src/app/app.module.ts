import {BrowserModule} from '@angular/platform-browser';
import {APP_INITIALIZER, NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {LoginComponent} from './login/login.component';
import {ErrorComponent} from './error/error.component';
import {AuthInterceptor} from './login/auth-interceptor';
import {LoginService} from './services/login.service';
import {FileUploadModule} from 'primeng/fileupload';
import {FieldsetModule} from 'primeng/fieldset';
import {FileUploadComponent} from './file-upload/file-upload.component';
import {ReceiversComponent} from './receivers/receivers.component';
import {VerifyComponent} from './verify/verify.component';
import {SendSuccessComponent} from './send-success/send-success.component';
import {FileComponent} from './file/file.component';
import {DisclaimerComponent} from './disclaimer/disclaimer.component';
import {WizardComponent} from './wizard/wizard.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ReceiverService} from './services/receiver.service';
import {DeliveryService} from './services/delivery.service';
import {TableModule} from 'primeng/table';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ToastModule} from 'primeng/toast';
import {DialogModule} from 'primeng/dialog';
import {ReceiveComponent} from './receive/receive.component';
import {AppConfigService} from './services/app-config.service';
import {LoggedInGuard} from './guards/logged-in.guard';
import {SendGuard} from './guards/send.guard';
import {ReceiveGuard} from './guards/receive.guard';
import {BlobErrorHttpInterceptor} from './receive/receive-interceptor';
import {PlatformChoiceComponent} from './platform-choice.component';
import {StepsModule} from 'primeng/steps';
import {CheckboxModule} from 'primeng/checkbox';

const initializeAppConfigFn = (appConfigService: AppConfigService) => {
  return () => {
    return appConfigService.loadAppConfig();
  };
};

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ErrorComponent,
    FileUploadComponent,
    ReceiversComponent,
    SendSuccessComponent,
    VerifyComponent,
    FileComponent,
    DisclaimerComponent,
    WizardComponent,
    ReceiveComponent,
    PlatformChoiceComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    FileUploadModule,
    FieldsetModule,
    ReactiveFormsModule,
    TableModule,
    ConfirmDialogModule,
    ToastModule,
    DialogModule,
    StepsModule,
    CheckboxModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: BlobErrorHttpInterceptor,
      multi: true
    },
    {
      provide: APP_INITIALIZER,
      useFactory: initializeAppConfigFn,
      multi: true,
      deps: [AppConfigService],
    },
    LoggedInGuard,
    SendGuard,
    ReceiveGuard,
    AppConfigService,
    LoginService,
    ReceiverService,
    DeliveryService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
