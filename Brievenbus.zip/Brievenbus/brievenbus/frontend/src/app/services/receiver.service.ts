import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {Injectable} from '@angular/core';

@Injectable()
export class ReceiverService {
  constructor(protected http: HttpClient) {
  }

  public getReceiver(userId: string): Observable<any> {
    return this.http.get('api/employee/find/' + userId);
  }

  protected handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      if (error.status === 401 || error.status === 403) {
        return throwError(new Error('U bent niet (meer) geautoriseerd. Log opnieuw in'));
      }
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${JSON.stringify(error.error)}`);
    }
    // return an observable with a user-facing error message
    return throwError(new Error('Er is iets fout gegaan bij het ophalen; Probeer het later opnieuw.'));
  }
}
