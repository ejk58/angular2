import {Injectable} from '@angular/core';
import {catchError, finalize, map} from 'rxjs/operators';
import {ApplicationUser} from '../domain/application-user';
import {AbstractDataService} from './abstract-data.service';
import {JwtHelperService} from '@auth0/angular-jwt';
import {HttpClient} from '@angular/common/http';
import {Router} from '@angular/router';
import {BehaviorSubject, Observable} from 'rxjs';

@Injectable()
export class LoginService extends AbstractDataService {

  private isLoggedIn$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private loggedInUser$: Observable<string>;

  private jwtHelper: JwtHelperService = new JwtHelperService();

  constructor(http: HttpClient, private router: Router) {
    super(http);
    this.isLoggedIn$.next(this.isLoggedInNow());

    this.loggedInUser$ = this.isLoggedIn().pipe(
      map(isLoggedIn => {
        if (!isLoggedIn) {
          return '';
        } else {
          const token = localStorage.getItem('id_token');
          const decoded = this.jwtHelper.decodeToken(token);
          return decoded.sub;
        }
      })
    );
  }

  isLoggedIn(): Observable<boolean> {
    return this.isLoggedIn$.asObservable();
  }

  loggedInUser(): Observable<string> {
    return this.loggedInUser$;
  }

  isLoggedInNow(): boolean {
    const token = localStorage.getItem('id_token');
    if (token == null) {
      return false;
    }
    const isExpired = this.jwtHelper.isTokenExpired(token);
    if (isExpired) {
      this.isLoggedIn$.next(false);
    }
    return !isExpired;
  }

  login(user: ApplicationUser) {
    const usernamePassword = {username: user.userId, password: user.password};
    return this.http.post('/api/login', usernamePassword)
      .pipe(
        catchError(this.handleError),
        finalize(() => {
          this.isLoggedIn$.next(this.isLoggedInNow());
        })
      );
  }

  logout(): void {
    localStorage.removeItem('id_token');
    this.isLoggedIn$.next(false);
    this.router.navigate(['login']);
  }
}
