package resttests;

import nl.belastingdienst.iva.wd.brievenbus.domain.ReceiverBuilder;
import org.springframework.http.HttpStatus;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import java.io.File;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

public class UploadControllerRestTest {

    private static final String BASE_PATH = "/api/upload/offer/";

    @BeforeMethod
    public void setup() {
        RestUtils.setBaseURI(RestConstants.BASE_ADP_URI);
        RestUtils.setBasePort(RestConstants.PORT);
        RestUtils.setBasePath(BASE_PATH);
        RestUtils.setRelaxedHTTPSValidation();
    }

    @AfterMethod
    public void afterTest (){
        RestUtils.resetBaseURI();
        RestUtils.resetBasePort();
        RestUtils.resetBasePath();
    }

    @Test
    @Ignore
    public void post_offer_with_correct_request() {
        String response =
            given()
                .contentType("multipart/form-data")
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1))
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(2))
                .multiPart("file", new File("./src/main/resources/log4j2.xml"))
                .post()
            .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
            .extract()
                .asString();

        System.out.println("RESPONSE");
        System.out.println(response);

        assertNotNull(response);
        assertEquals(response, "{\"message\": \"bestandje ok\"}");
    }

    @Test
    @Ignore
    public void post_offer_with_incorrect_request() {
        given()
                .contentType("multipart/form-data; boundary=----WebKitFormBoundaryjjpCUE9oy1c6NEnE")
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1))
                .multiPart("file", "String")
                .post()
            .then()
                .assertThat()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Ignore
    public void post_offer_with_more_than_allowed_recievers() {
        given()
                .contentType("multipart/form-data; boundary=----WebKitFormBoundaryjjpCUE9oy1c6NEnE")
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1))
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(2))
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(3))
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(4))
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(5))
                .multiPart("receivers", ReceiverBuilder.buildIvaTestReceiverJson(6))
                .multiPart("file", new File("./src/main/resources/log4j2.xml"))
                .post()
            .then()
                .assertThat()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

}