package resttests;

import io.restassured.http.ContentType;

public class RestConstants {
//   public static final String BASE_ADP_URI = "http://localhost";
    public static final String BASE_ADP_URI = "https://adp-wd-brievenbus.apps.dtap.belastingdienst.nl";
    public static final String BASE_DWB_URI = "https://dwb-wd-brievenbus.apps.dtap.belastingdienst.nl";
    public static final Integer PORT = 8080;
    public static final ContentType HEADER = ContentType.JSON;

    public RestConstants() {
    }
}