package nl.belastingdienst.iva.wd.brievenbus.service;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.FileRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.ReceiverRepository;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.PersistenceException;
import javax.xml.bind.DatatypeConverter;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/upload")
@Transactional
public class UploadController {

    public static final String FILE_WRITE_ERROR = "Er is iets misgegaan bij het schrijven van de file";
    public static final String RECEIVER_SAVE_ERROR = "Opslaan van receiver is niet gelukt";
    public static final String FILE_SAVE_ERROR = "Opslaan van file is niet gelukt";
    private static final String DELIVERY_SAVE_ERROR = "Opslaan van delivery is niet gelukt";

    private static final Logger LOGGER = LogManager.getLogger(UploadController.class);

    @Value("${max.receivers}")
    private int maxReceivers;

    @Value("${link.expiration.period.in.weeks}")
    private int linkExpirationPeriodInWeeks;

    @Autowired
    private DeliveryRepository deliveryRepository;

    @Autowired
    private FileRepository fileRepository;

    @Autowired
    private ReceiverRepository receiverRepository;

    @Autowired
    private MailService mailService;

    @Autowired
    private FileService fileService;

    @PostMapping(value="/offer", consumes= MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> offer(@RequestParam("file") MultipartFile file,
                                        @RequestParam("receivers") List<ReceiverJson> receivers,
                                        Principal sender) {
        if (receivers.size() > maxReceivers) {
            return ResponseEntity.badRequest().body("{\"error\": \"max " + maxReceivers + " receivers\"}");
        }

        AuditService.logUserAction("Starten opslaan delivery en verzenden email", sender.getName(), file.getOriginalFilename());

        Delivery deliveryEntity = new Delivery();
        deliveryEntity.setUuid(UUID.randomUUID());

        // update database
        persistNewDeliveryEntity(deliveryEntity, sender);
        for(ReceiverJson receiver : receivers) {
            persistNewReceiverEntity(deliveryEntity, receiver);
        }
        persistNewFileEntity(deliveryEntity, file);

        // write file
        fileService.writeFileToDirectoryOnSystem(deliveryEntity, file, sender.getName());

        // send mail
        mailService.createAndSendMail(deliveryEntity, receivers);

        AuditService.logUserAction("Einde opslaan delivery en verzenden email", sender.getName(), file.getOriginalFilename(), deliveryEntity.getUuid());
        return ResponseEntity.ok("{\"message\": \"Bestand goed verwerkt!\", \"deliveryUUID\": \"" + deliveryEntity.getUuid() + "\"}");
    }

    private void persistNewReceiverEntity(Delivery deliveryEntity, ReceiverJson receiver) {
        Receiver receiverEntity = new Receiver();

        receiverEntity.setDelivery(deliveryEntity);
        receiverEntity.setUserid(receiver.getUserId());

        AuditService.logUserAction("Starten met opslaan van receiver", deliveryEntity.getUuid());
        try {
            this.receiverRepository.save(receiverEntity);
            AuditService.logUserAction("Opslaan van receiver is gelukt", deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            AuditService.logUserAction(RECEIVER_SAVE_ERROR, deliveryEntity.getUuid());
            throw new UnprocessableException(RECEIVER_SAVE_ERROR, e);
        }
    }

    private void persistNewFileEntity(Delivery deliveryEntity, MultipartFile file) {
        File fileEntity = new File();
        String hash = getFileHash(file, "SHA-256");

        fileEntity.setHash(hash);
        fileEntity.setName(file.getOriginalFilename());
        fileEntity.setBytes(file.getSize());
        fileEntity.setDelivery(deliveryEntity);

        AuditService.logUserAction("Starten met opslaan van file", deliveryEntity.getUuid());
        try {
            this.fileRepository.save(fileEntity);
            AuditService.logUserAction("Opslaan van file is gelukt", deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            AuditService.logUserAction(FILE_SAVE_ERROR, deliveryEntity.getUuid());
            throw new UnprocessableException(FILE_SAVE_ERROR, e);
        }
    }

    private Delivery persistNewDeliveryEntity(Delivery deliveryEntity, Principal sender) {
        LocalDateTime created = LocalDateTime.now();
        LocalDateTime expiration = created.plusWeeks(linkExpirationPeriodInWeeks);

        deliveryEntity.setSender(sender.getName());
        deliveryEntity.setCreated(created);
        deliveryEntity.setExpiration(expiration);

        AuditService.logUserAction("Starten met opslaan van delivery", deliveryEntity.getUuid());
        try {
            this.deliveryRepository.save(deliveryEntity);
            AuditService.logUserAction("Opslaan van delivery is gelukt", deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            AuditService.logUserAction(DELIVERY_SAVE_ERROR, deliveryEntity.getUuid());
            throw new UnprocessableException(DELIVERY_SAVE_ERROR, e);
        }

        return deliveryEntity;
    }

    private String getFileHash(MultipartFile file, String algorithm) {
        try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            md.update(file.getBytes());
            byte[] digested = md.digest();
            return DatatypeConverter.printHexBinary(digested).toUpperCase();
        } catch (NoSuchAlgorithmException nsae) {
            LOGGER.error(nsae);
        } catch (IOException ioe) {
            LOGGER.error(ioe);
        }

        return "no-hash-generated-due-to-error";
    }

}
