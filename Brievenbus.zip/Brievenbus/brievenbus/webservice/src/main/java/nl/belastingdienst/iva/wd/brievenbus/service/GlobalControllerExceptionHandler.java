package nl.belastingdienst.iva.wd.brievenbus.service;

import nl.belastingdienst.iva.wd.brievenbus.domain.exception.ErrorResponse;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.NotFoundException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.ValidationException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class GlobalControllerExceptionHandler {

    private static final Logger LOGGER = LogManager.getLogger(GlobalControllerExceptionHandler.class);

    // General exception handling
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(Exception exception) {
        return createErrorResponse(exception, HttpStatus.INTERNAL_SERVER_ERROR, true);
    }

    // Validation exception handling
    @ExceptionHandler(ValidationException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(ValidationException exception) {
        return createErrorResponse(exception, HttpStatus.PRECONDITION_FAILED, false);
    }

    // Not found exception handling
    @ExceptionHandler(NotFoundException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(NotFoundException exception) {
        return createErrorResponse(exception, HttpStatus.NOT_FOUND, false);
    }

    // Unprocessable exception handling
    @ExceptionHandler(UnprocessableException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(UnprocessableException exception) {
        return createErrorResponse(exception, HttpStatus.UNPROCESSABLE_ENTITY, true);
    }

    private ResponseEntity<ErrorResponse> createErrorResponse(Exception exception, HttpStatus httpStatus, boolean logError) {
        if (logError) {
            LOGGER.error(exception.getMessage(), exception);
        }
        return new ResponseEntity<>(new ErrorResponse(exception.getMessage()), httpStatus);
    }
}
