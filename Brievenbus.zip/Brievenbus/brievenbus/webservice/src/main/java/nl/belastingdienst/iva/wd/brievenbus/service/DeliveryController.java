package nl.belastingdienst.iva.wd.brievenbus.service;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/delivery")
public class DeliveryController {

    @Autowired
    private DeliveryRepository deliveryRepository;

    @GetMapping("/get/{uuid}")
    public ResponseEntity<Delivery> getDelivery(@PathVariable("uuid") String uuid) {
        Delivery delivery = deliveryRepository.findFirstByUuid(UUID.fromString(uuid));
        return delivery != null ? ResponseEntity.ok(delivery) : ResponseEntity.notFound().build();
    }
}
