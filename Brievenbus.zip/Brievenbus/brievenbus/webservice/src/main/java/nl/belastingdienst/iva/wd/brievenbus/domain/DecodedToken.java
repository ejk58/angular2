package nl.belastingdienst.iva.wd.brievenbus.domain;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class DecodedToken {
    @NotBlank(message = "message is mandatory")
    String message;

    public boolean isValid() {
        return message != null;
    }
}
