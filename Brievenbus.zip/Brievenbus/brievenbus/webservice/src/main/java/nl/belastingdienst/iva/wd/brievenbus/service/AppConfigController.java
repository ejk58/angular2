package nl.belastingdienst.iva.wd.brievenbus.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/appconfig")
public class AppConfigController {

    @Value("${application.platform}")
    private String applicationPlatform;

    @GetMapping("/applicationplatform")
    public String getApplicationPlatform() {
        return "{\"applicationPlatform\": \"" + applicationPlatform + "\"}";
    }
}
