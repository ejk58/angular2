package nl.belastingdienst.iva.wd.brievenbus.service;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

    @Autowired
    private LdapDwbClient ldapDwbClient;

    @GetMapping("/find/{userId}")
    public ResponseEntity<Person> requestEntity(@PathVariable("userId") String userId) {
            return findEmployee(userId);
    }

    private ResponseEntity<Person> findEmployee(String userId) {
        List<Person> persons = ldapDwbClient.getPersons(userId);
        Person person = persons.isEmpty() ? null : persons.get(0);
        return new ResponseEntity<>(person, HttpStatus.OK);
    }
}
