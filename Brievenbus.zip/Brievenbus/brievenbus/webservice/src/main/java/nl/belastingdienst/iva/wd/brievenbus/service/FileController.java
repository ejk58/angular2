package nl.belastingdienst.iva.wd.brievenbus.service;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.NotFoundException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.UUID;


@RestController
@RequestMapping("/api/download")
public class FileController {

    public static final String DELIVERY_NOT_FOUND_WITH_UUID = "Levering met dit uuid niet gevonden ";
    public static final String NOT_IN_RECEIVER_LIST = " komt niet voor in lijst met ontvangers";
    public static final String DOWNLOAD_PERIOD_EXPIRED = "De download periode is verstreken";

    @Autowired
    private FileService fileService;

    @Autowired
    private DeliveryRepository deliveryRepository;

    @GetMapping(value = "/{deliveryUUID}")
    public Resource getFileFromFileSystem(@PathVariable("deliveryUUID") UUID deliveryUUID, Principal receiver, HttpServletResponse response) {
        String receiverUserId = receiver.getName();

        Delivery delivery = getDeliveryIfAllowed(receiverUserId, deliveryUUID);
        String uuid = delivery.getUuid().toString();
        String filename = delivery.getFile().getName();

        AuditService.logUserAction("Start opzoeken file " + uuid + "/" + filename, receiverUserId, filename);
        Resource fileFromSystem = fileService.getFileSystem(uuid, filename, response);
        if (!fileFromSystem.exists()) {
            AuditService.logUserAction("File " + uuid + "/" + filename + " niet gevonden", receiverUserId, filename);
            throw new NotFoundException("File " + uuid + "/" + filename + " niet gevonden");
        } else {
            AuditService.logUserAction("Einde opzoeken file " + uuid + "/" + filename, receiverUserId, filename);
        }
        return fileFromSystem;
    }

    private Delivery getDeliveryIfAllowed(String userId, UUID deliveryUUID) {
        Delivery delivery = this.deliveryRepository.findFirstByUuid(deliveryUUID);

        if (delivery == null) {
            AuditService.logUserAction(DELIVERY_NOT_FOUND_WITH_UUID + deliveryUUID, userId);
            throw new NotFoundException(DELIVERY_NOT_FOUND_WITH_UUID + deliveryUUID);

        }

        Receiver receiver = delivery.getReceivers().stream().filter(rec -> rec.getUserid().equalsIgnoreCase(userId)).findAny().orElse(null);
        if (receiver == null) {
            AuditService.logUserAction(userId + NOT_IN_RECEIVER_LIST, userId);
            throw new ValidationException(userId + NOT_IN_RECEIVER_LIST);
        }

        if (LocalDateTime.now().isAfter(delivery.getExpiration())) {
            AuditService.logUserAction(DOWNLOAD_PERIOD_EXPIRED, userId);
            throw new ValidationException(DOWNLOAD_PERIOD_EXPIRED);
        }
        
        return delivery;
    }
}