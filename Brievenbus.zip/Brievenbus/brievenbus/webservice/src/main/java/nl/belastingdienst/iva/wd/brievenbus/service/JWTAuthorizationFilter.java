package nl.belastingdienst.iva.wd.brievenbus.service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationPlatform;
import org.springframework.core.env.Environment;
import org.springframework.security.access.AuthorizationServiceException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class JWTAuthorizationFilter extends BasicAuthenticationFilter {

    private static final List<String> ADP_ALLOWED_POST_REST_CALLS = Arrays.asList("/api/upload/offer");

    private Environment env;

    JWTAuthorizationFilter(Environment env, AuthenticationManager authManager) {
        super(authManager);
        this.env = env;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain) throws IOException, ServletException {
        String header = req.getHeader(SecurityConstants.HEADER_STRING);

        if (header == null || !header.startsWith(SecurityConstants.TOKEN_PREFIX)) {
            chain.doFilter(req, res);
            return;
        }

        if (req.getMethod().equals("POST") && !isPostAllowed(req)) {
            AuditService.logUserAction("Er is geprobeerd een ongeautoriseerde POST uit te voeren", getUserFromToken(req));
            throw new AuthorizationServiceException("Restcall niet toegestaan");
        }

        UsernamePasswordAuthenticationToken authentication = getAuthentication(req);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        chain.doFilter(req, res);
    }

    private boolean isPostAllowed(HttpServletRequest request) {
        String applicationPlatform = env.getRequiredProperty("application.platform", String.class);
        String url = request.getRequestURL().toString();
        String postRestCall = url.substring(url.indexOf("/api"));
        return request.getMethod().equals("POST")
                && ADP_ALLOWED_POST_REST_CALLS.contains(postRestCall)
                && ApplicationPlatform.ADP.getPlatform().equals(applicationPlatform);
    }

    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
        String user = getUserFromToken(request);
        if (user != null) {
            return new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
        }
        return null;
    }

    private String getUserFromToken(HttpServletRequest request) {
        String token = request.getHeader(SecurityConstants.HEADER_STRING);
        if (token != null) {
            try {
                // parse the token.
                return JWT.require(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes()))
                        .build()
                        .verify(token.replace(SecurityConstants.TOKEN_PREFIX, ""))
                        .getSubject();
            } catch (Exception e) {
                // Any exception (eg: expired token) will be treated as if there was no token.
                // The client will have to login again
                return null;
            }
        }
        return null;
    }
}
