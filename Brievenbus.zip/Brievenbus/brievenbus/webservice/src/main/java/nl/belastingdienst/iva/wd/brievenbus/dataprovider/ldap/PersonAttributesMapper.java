package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import org.springframework.ldap.core.AttributesMapper;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

public class PersonAttributesMapper implements AttributesMapper<Person> {

    public Person mapFromAttributes(Attributes attributes) throws NamingException {
        Person person = new Person();
        person.setUserId((String) attributes.get("cn").get());
        person.setName((String) attributes.get("displayName").get());
        person.setEmail((String) attributes.get("userPrincipalName").get());

        NamingEnumeration<? extends Attribute> i = attributes.getAll();
        while (i.hasMore()) {
            Attribute attribute = i.next();
        }
        return person;
    }

}
