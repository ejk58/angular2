package nl.belastingdienst.iva.wd.brievenbus.dao;

import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface DeliveryRepository extends CrudRepository<Delivery, Long> {
    Delivery findFirstByUuid(UUID uuid);
}
