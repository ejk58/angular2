package nl.belastingdienst.iva.wd.brievenbus.service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@Slf4j
public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private LdapTemplate ldapTemplate;
    private Environment env;

    JWTAuthenticationFilter(Environment env, LdapTemplate ldapTemplate) {
        this.env = env;
        this.ldapTemplate = ldapTemplate;
        setFilterProcessesUrl("/api/login");
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest req,
                                                HttpServletResponse res) {
        try {
            ApplicationUser user = new ObjectMapper().readValue(req.getInputStream(), ApplicationUser.class);

            // ldap authentication accepts empty passwords!
            if (user.getPassword().isEmpty()) {
                user.setPassword(null);
            }

            String applicationPlatform = env.getRequiredProperty("application.platform", String.class).toLowerCase();
            String partitionSuffix = env.getRequiredProperty("ldap." + applicationPlatform + ".partitionSuffix");

            if (!ldapTemplate.authenticate(partitionSuffix, "(cn=" + user.getUsername() + ")", user.getPassword())) {
                AuditService.logUserAction("Er is geprobeerd in te loggen met een verkeerd userid of password", user.getUsername());
                throw new BadCredentialsException("Verkeerd userid of password");
            }
            return new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword(), null);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest req,
                                            HttpServletResponse res,
                                            FilterChain chain,
                                            Authentication auth) {
        long validityPeriod = Long.parseLong(env.getRequiredProperty("jwt.validity.period.in.days")) * 24 * 60 * 60 * 1000;

        String token = JWT.create()
                .withSubject(auth.getPrincipal().toString())
                .withExpiresAt(new Date(System.currentTimeMillis() + validityPeriod))
                .sign(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes()));

        res.addHeader(SecurityConstants.HEADER_STRING, SecurityConstants.TOKEN_PREFIX + token);
    }
}