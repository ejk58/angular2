#!groovy
def protractorCmd = "node ./node_modules/protractor-flake/bin/protractor-flake --parser=./my-custom-parser.js --max-attempts=4 --color=yellow -- ./protractor.conf.js"
def appName = "brievenbus"
def version
def project = env.PROJECT_NAME

pipeline {
    agent {
        label "jos-agent-nodejs-10"
    }
    options {
        skipDefaultCheckout()
    }
    stages {
        stage('Check out') {
            steps {
                checkout scm
            }
        }
        stage('Protractor') {
            steps {
                sh(script: "cd frontend; npm ci --ignore-scripts; ${protractorCmd}")
            }
        }
    }
}
