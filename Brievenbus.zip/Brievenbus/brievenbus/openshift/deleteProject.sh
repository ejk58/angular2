#!/bin/bash
oc delete project wd-brievenbus
sleep 10
