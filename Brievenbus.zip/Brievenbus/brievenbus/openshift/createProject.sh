#!/bin/bash
oc new-project wd-brievenbus --description="Team Inge" --display-name="Brievenbus"
oc process openshift//jenkins-cpet | oc create -f -
oc import-image registry.chp.belastingdienst.nl/redhatio/openjdk-11-rhel7:latest --confirm
./process "rolebinding-Alle teamleden.yaml"
./process brievenbus-pipeline.yaml
./process brievenbus-protractor-pipeline.yaml
