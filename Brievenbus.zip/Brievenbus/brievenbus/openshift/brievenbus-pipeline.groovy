#!groovy

// Deze variabelen zijn project specifiek
def projectBase = "brievenbus"

// Deze variabelen alleen als je niet de standaard volgt
def backendName = "webservice"
def backendArtifactName = "bvb-backend"
def frontendName = "frontend"
def openshiftDeploymentGeneric = "brievenbus"
def openshiftDeploymentADP = "adp"
def openshiftDeploymentDWB = "dwb"

// Deze variabelen in principe niet veranderen
def mvnCmd = "mvn -B -s openshift/maven-settings.xml"
def mvnRestCmd = "mvn -pl webservice test -Dtest=resttests.*RestTest -DfailIfNoTests=false"

pipeline {
    agent none
    options {
		skipDefaultCheckout()
	}
    stages {
        stage('Checkout') {
            agent {
                label "maven35-openjdk11"
            }
            steps {
                checkout scm
                // ITT Jeroen's versie, .git niet excluden omdat die voor de git-commit plugin nodig is
                stash(name: 'ws', includes: '**', excludes: '**/node_modules/**')
            }
        }
        stage('NPM') {
            agent {
                label "nodejs10"
            }
            steps {
                unstash 'ws'
                dir(frontendName) {
                    sh(script: "npm i") // Dit moet later nog npm ci worden
                    sh(script: "npm run build")
                    // Onderstaand is afhankelijk van de "name": "frontend" in package.json
                    stash(name: 'frontend', includes: 'dist/frontend/**')
                }
            }
        }
        stage('Maven package') {
            agent {
                label "maven35-openjdk11"
            }
            steps {
                unstash 'ws'
                dir(frontendName) {
                    unstash 'frontend'
                }
                sh(script: "${mvnCmd} -DskipId -pl ${backendName} package -Ps2i")
                stash name: 'jar', includes: '**/target/**/*'
            }
            post {
                success {
                    junit '**/surefire-reports/**/*.xml'
                }
            }
        }
//        stage('Maven sonar') {
//            agent {
//                label "maven35-openjdk11"
//            }
//            steps {
//                unstash 'ws'
//                sh(script: "${mvnCmd} sonar:sonar")
//            }
//		}
        stage('Create Image Builder') {
            when {
                expression {
                    openshift.withCluster() {
                        return !openshift.selector("bc", openshiftDeploymentGeneric).exists()
                    }
                }
            }
            steps {
                script {
                    openshift.withCluster() {
                        openshift.newBuild("--name=${openshiftDeploymentGeneric}", "-i=openjdk-11-rhel7", "--binary=true")
                    }
                }
            }
        }
        stage('Build Image') {
            agent {
                label "maven35-openjdk11"
            }
            steps {
                script {
                    unstash 'jar'
                    openshift.withCluster() {
                        openshift.selector("bc", openshiftDeploymentGeneric).startBuild("--from-file=${backendName}/target/${backendArtifactName}.jar", "--wait=true")
                    }
                }
            }
        }
        stage('Create ADP deployment in O') {
            when {
                expression {
                    openshift.withCluster() {
                        return openshift.selector('dc', openshiftDeploymentADP).exists()
                    }
                }
            }
            agent {
                label "maven35-openjdk11"
            }
            steps {
                script {
                    unstash 'ws'
                    openshift.withCluster() {
                        // ruim eerst de objecten als die zijn blijven staan
                        if (openshift.selector('dc', openshiftDeploymentADP).exists()) {
                            openshift.selector('dc', openshiftDeploymentADP).delete()
                        }
                        if (openshift.selector('svc', openshiftDeploymentADP).exists()) {
                            openshift.selector('svc', openshiftDeploymentADP).delete()
                        }
                        if (openshift.selector('route', openshiftDeploymentADP).exists()) {
                            openshift.selector('route', openshiftDeploymentADP).delete()
                        }

                        result = openshift.raw("apply", "-f openshift/${openshiftDeploymentADP}-template.yaml")
                        // dit template moet een deployment hebben van het image met tag 'latest'
                        // er zit geen trigger in om te deployen bij image change

                        // stel dat het trigger er toch is, deze op manual zetten, Jenkins is in control
                        openshift.set("triggers", "dc/${openshiftDeploymentADP}", "--manual")
                    }
                }
            }
        }
        stage('Create DWB deployment in O') {
            when {
                expression {
                    openshift.withCluster() {
                        return openshift.selector('dc', openshiftDeploymentDWB).exists()
                    }
                }
            }
            agent {
                label "maven35-openjdk11"
            }
            steps {
                script {
                    unstash 'ws'
                    openshift.withCluster() {
                        // ruim eerst de objecten als die zijn blijven staan
                        if (openshift.selector('dc', openshiftDeploymentDWB).exists()) {
                            openshift.selector('dc', openshiftDeploymentDWB).delete()
                        }
                        if (openshift.selector('svc', openshiftDeploymentDWB).exists()) {
                            openshift.selector('svc', openshiftDeploymentDWB).delete()
                        }
                        if (openshift.selector('route', openshiftDeploymentDWB).exists()) {
                            openshift.selector('route', openshiftDeploymentDWB).delete()
                        }

                        result = openshift.raw("apply", "-f openshift/${openshiftDeploymentDWB}-template.yaml")
                        // dit template moet een deployment hebben van het image met tag 'latest'
                        // er zit geen trigger in om te deployen bij image change

                        // stel dat het trigger er toch is, deze op manual zetten, Jenkins is in control
                        openshift.set("triggers", "dc/${openshiftDeploymentDWB}", "--manual")
                    }
                }
            }
        }
        stage('Deploy ADP in O') {
            steps {
                script {
                    openshift.withCluster() {
//                        openshift.tag("ont:latest", "ont:${gitVersion}")
                        def dc = openshift.selector("dc", openshiftDeploymentADP)
                        dc.rollout().latest()
                        // wachten tot alle replicas beschikbaar zijn.
                        while (dc.object().spec.replicas != dc.object().status.availableReplicas) {
                            echo "Wait for all replicas are available"
                            sleep 10
                        }
                    }
                }
            }
        }
        stage('Deploy DWB in O') {
            steps {
                script {
                    openshift.withCluster() {
//                        openshift.tag("ont:latest", "ont:${gitVersion}")
                        def dc = openshift.selector("dc", openshiftDeploymentDWB)
                        dc.rollout().latest()
                        // wachten tot alle replicas beschikbaar zijn.
                        while (dc.object().spec.replicas != dc.object().status.availableReplicas) {
                            echo "Wait for all replicas are available"
                            sleep 10
                        }
                    }
                }
            }
        }
        stage('REST Assured Tests') {
            agent {
                label "maven35-openjdk11"
            }
            steps {
                unstash 'ws'
                sh(script: "${mvnRestCmd}")
                stash name: 'jar', includes: '**/target/**/*'
            }
            post {
                success {
                    junit '**/surefire-reports/**/*.xml'
                }
            }
        }
    }
}
