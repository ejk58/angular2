@Library("GENERIC") _
    pipelineTest {
		deploymentId= "inzicht"
        project = "inzicht"
        robotTestPath = "testsuites"
        robotIncludes = "FinalANDSequential"
        robotExcludes = "NIGHTLY"
        robotNonCriticals = "NONCRITICAL"
        pabotProcesses = "4"
        pabotIncludes = "FinalNOTSequential"
    }