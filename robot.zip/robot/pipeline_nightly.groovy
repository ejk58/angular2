@Library("GENERIC") _
    pipelineTest {
		deploymentId = "inzicht"
        robotTestPath = "testsuites"
        robotIncludes = "FinalANDSequential"
        robotExcludes = "NONE"
        robotNonCriticals = "NONCRITICAL"
        pabotProcesses = "3"
        pabotIncludes = "FinalNOTSequential"
		pipelineTrigger = [cron('H 21 * * *')]
    }