#!/bin/bash  
echo "Starting performance test"  
./jmeter -n -Jusername= -Jpassword= -Jenvironment=. -JtaxYear=2015 -Jusers=125 -Jloops=5 -JnwBsnCsv=bsn2014.csv -JdiBsnCsv=bsnMKB.csv -JinvBsnCsv=bsnMKB.csv -t Inzicht.jmx -l results1.jtl -e -o ./dashboard1
./jmeter -n -Jusername= -Jpassword= -Jenvironment=. -JtaxYear=2015 -Jusers=150 -Jloops=5 -JnwBsnCsv=bsn2014.csv -JdiBsnCsv=bsnMKB.csv -JinvBsnCsv=bsnMKB.csv -t Inzicht.jmx -l results2.jtl -e -o ./dashboard2
./jmeter -n -Jusername= -Jpassword= -Jenvironment=. -JtaxYear=2015 -Jusers=175 -Jloops=5 -JnwBsnCsv=bsn2014.csv -JdiBsnCsv=bsnMKB.csv -JinvBsnCsv=bsnMKB.csv -t Inzicht.jmx -l results3.jtl -e -o ./dashboard3