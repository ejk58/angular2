INSERT INTO "ANN_IHSV_NP_BURGSTAAT_EVENTS" (finr,finr_partner,burgerl_staat_event,datum_burgstaat_event,BELJAAR) VALUES (61,67.0,'Scheiding',{d '2011-11-15'},2014);
INSERT INTO "ANN_IHSV_NP_BURGSTAAT_EVENTS" (finr,finr_partner,burgerl_staat_event,datum_burgstaat_event,BELJAAR) VALUES (67,61.0,'Scheiding',{d '2011-11-15'},2014);
