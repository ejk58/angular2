
create VIEW IVAI_DEV_VIEW.IHSV_SUM_AG_HEFFINGSKRT    AS  locking row for access ( SELECT  
 FINR AS FINR
 , BELJAAR AS BELJAAR
 , VOLGNR AS VOLGNR
 , VOLGNR2 AS VOLGNR2
 , ATTRIBUUT AS ATTRIBUUT
 , BRON AS BRON
 ,  /*3-2-2017: korte termijn oplossing voor samenvattingstabel IACK*/ case when volgnr = 3 then '<i>Zie tabel IACK en arbeidsinkomen</i>' else BRONGEGEVEN end   AS BRONGEGEVEN
 , ABS_TYPE AS ABS_TYPE
 , case when volgnr = 3 /*3-2-2017: korte termijn oplossing voor samenvattingstabel IACK*/
 then' &nbsp; ' else 
 CASE WHEN SUBSTR(ABS_WAARDE,1,1) =  '€' THEN TRANSLATE(SUBSTR(ABS_WAARDE,2) USING LATIN_TO_UNICODE) ELSE TRANSLATE(ABS_WAARDE USING LATIN_TO_UNICODE) END 
 end 
 AS ABS_WAARDE, 
 case when volgnr = 3 /*3-2-2017: korte termijn oplossing voor samenvattingstabel IACK*/ 
 then' &nbsp; ' else 
 CASE WHEN SUBSTR(BRON_WAARDE,1,1) =  '€' THEN TRANSLATE(SUBSTR(BRON_WAARDE,2) USING LATIN_TO_UNICODE) ELSE TRANSLATE(BRON_WAARDE USING LATIN_TO_UNICODE) END 
 end 
 AS BRON_WAARDE, 
 case when volgnr = 3 /*3-2-2017: korte termijn oplossing voor samenvattingstabel IACK*/ 
 then' &nbsp; ' else 
 CASE WHEN SUBSTR(VERSCHIL_WAARDE,1,1) =  '€' THEN TRANSLATE(SUBSTR(VERSCHIL_WAARDE,2) USING LATIN_TO_UNICODE) ELSE TRANSLATE(VERSCHIL_WAARDE USING LATIN_TO_UNICODE) 
 end 
 END AS VERSCHIL_WAARDE
 , VERSCHIL_WAARDE_N AS VERSCHIL_WAARDE_N
FROM IVAI_DEV_TABLE.ANN_IHSV_SUM_AG_HEFFINGSKRT  );