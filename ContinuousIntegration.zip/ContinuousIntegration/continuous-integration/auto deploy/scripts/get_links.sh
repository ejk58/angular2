#!/bin/sh

#Path
source $HOME/.bash_profile
PATH=$PATH:/usr/local/bin:/usr/local/sbin:/usr/sbin:/sbin

if [ "$1" != "" ]; then
    cellId="$1"
else
    cellId="ont85"
fi


ad liststreets --csv --dinq $cellId | cut -d';' -f8 | sed 's/"//g' | grep '^http' | sort -u

