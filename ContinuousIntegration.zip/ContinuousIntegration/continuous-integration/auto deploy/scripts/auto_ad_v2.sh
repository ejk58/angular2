#!/bin/sh
# Cronjob to check on new files in the wasUpload directory and lock the ad process if needed

#Props
wasUpload="/prj/wasUpload"
#buildInfoProp="adBuildInfo.properties"
adLockFile="$HOME/ad.lock"
#regex="^package-([a-zA-Z-]*)-([0-9a-zA-Z.-]*).zip$"
regexAS="^package-([a-zA-Z-]*)-as-([0-9a-zA-Z.-]*).zip$"
adScriptLocation="/home/virtuser/script/ad_v2.sh"
asProject=false

# shopt -s nocasematch

printf "\n**************************************************************"
printf "\n** Auto deployment script ** `basename $0` **********************"
printf "\n** CoE Maatwerk **********************************************"
printf "\n** 2017 ******************************************************"
printf "\n**************************************************************"
printf "\n\n"


usage="$(basename "$0") [-h] -c value -C value -s value -f value -e value -b value

where:
    -h  show this help text
    -a  ApplicationId of the application, used to retrieve the configuration information. For example: note
    -c  Id of cell of environment, for example: ont85 or tst85
    -C  cluster name, for example: CLS_IVA-NOTE_O
    -s  Street for deployment, for example str11 or str14
    -f  File to deploy. Example : package-application-name-1.0.0-SNAPSHOT.zip
    -e  the Id of the enviroment (ont, tst, acc or prd)
    -b  Unique buildnummer of deployed artifact, this is used for a validation check"

while getopts ":h:a:c:C:s:f:b:e:" opt; do
     case $opt in
          h)   echo "$usage"
               exit
               ;;
          a)   appId="$OPTARG"
               ;;
          c)   cellId="$OPTARG"
               ;;
          C)   clusterId="$OPTARG"
               ;;
          s)   streetId="$OPTARG"
               ;;
          f)   fileName="$OPTARG"
	       fileName=`basename ${fileName}`
               ;;
          b)   buildNumber="$OPTARG"
               ;;
          e)   environment="$OPTARG"
               ;;
          :)   printf "\nMissing arguments for -%s\n" "$OPTARG" >&2
               echo "$usage" >&2
               exit 1
               ;;
          \?)  printf "\nInvalid option: -%s -$OPTARG\n" >&2
               echo "$usage" >&2
               exit 1
               ;;
     esac
done

echo(){
	printf "`date`: $1\n"
}

printInfo() {
	printf "\n"
	printf "\n**************************************************************"
	printf "\n** auto_ad_v2.sh: input:"
	printf "\n** cellId = $cellId"
	printf "\n** appId = $appId"
	printf "\n** environment = $environment"
	printf "\n** street = $streetId"
	printf "\n** fileName = $fileName"
	printf "\n** cluster = $clusterId"
	printf "\n**************************************************************"
	printf "\n"
}

getProcessLock() {
	echo "getting lock for this process."
	if [ -e "$adLockFile" ]; then
		lockCmd="cat $adLockFile"
		lock=`$lockCmd`
	fi

	if [ "$lock" == "true" ]; then
		printf "AD proces is locked\n"
		exit;
	fi
	 
	printf "true" > $adLockFile
}

removeProcessLock() {
	echo "removing process lock."
	rm $adLockFile
}

checkCluster() {
	hostId=`hostname`
	echo "checkCluster: checking if cluster $clusterId exists on this deploymentManager"
	cad listclusters --csv $cellId | cut -d \; -f 2 | grep $clusterId - > /dev/null
	if [ $? -ne 0 ] ; then
		echo "cluster ${clusterId} does not exist on this deploymentManager (${hostId})"
		exit
	fi
}

#processingBuildInfoFile() {
#	echo "processingBuildInfoFile: Match on file $entry, Try to get all information from included $buildInfoProp"
#	adBuildInfoCmd="unzip -p $wasUpload/$fileName $buildInfoProp"
#	for line in `$adBuildInfoCmd`  
#	do   
#		lineExt="printf $line"
#		lineN=`$lineExt | tr -d '\n' | tr -d '\r'`
#		if [ $fileName =~ $regexBuildnumber ] ; then
#			eval $lineN
#			printf "\nDeploying build $buildnumber"
#		fi
#	done
#}
main() {
	# Removing check. If no application is deployed in a cluster, it is not shown.
	#checkCluster
	getProcessLock
#	if test "$(ls -A "$wasUpload")"; then
	#	if [[ -f $wasUpload/$fileName -a -r  $wasUpload/$fileName -a -s  $wasUpload/$fileName ]]; then
#		echo "Looking for $wasUpload/$fileName"
#		if [ -f $wasUpload/$fileName ] ; then
#			if [[ $fileName =~ $regexAS ]]; then
#				asProject=true
#			fi

#			processingBuildInfoFile

			printInfo
			sh $adScriptLocation -c $cellId -s $streetId -f $fileName -C $clusterId -e $environment
#		else
#			echo "no match ignore file $entry"
#		fi
#	else
#		echo "no file found in $wasUpload"
#	fi
	removeProcessLock
}

main
