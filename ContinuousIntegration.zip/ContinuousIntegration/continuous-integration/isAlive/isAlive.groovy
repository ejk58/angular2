import groovy.json.JsonSlurper

node {
    checkout scm
    def applications = [:]
    def lockLabel

//  Let op, GSV, ont en str11 is case-sensitive 
    // ONTWIKKEL
    applications["gsv str11 ont"] = [buildLock: true, prefix: 'GSV', env: 'ont', street: 'str11', url: 'https://iva-gsv.str11.ont.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["settlement str11 ont"] = [buildLock: true, prefix: 'settlement', env: 'ont', street: 'str11', url: 'https://iva-settlement.str11.ont.belastingdienst.nl/iva-settlement/rest/monitor/overall']
    applications["ivad str11 ont"] = [buildLock: true, prefix: 'iva-datadashboard', env: 'ont', street: 'str11', url: 'https://iva-datadashboard.str11.ont.belastingdienst.nl/iva-datadashboard-ws/rest/isalive']
    applications["brievenbus adp ont"] = [buildLock: false, url: 'https://adp-wd-brievenbus.apps.dtap.belastingdienst.nl/actuator/health']
    applications["brievenbus dwb ont"] = [buildLock: false, url: 'https://dwb-wd-brievenbus.apps.dtap.belastingdienst.nl/actuator/health']
    applications["thl str11 ont"] = [buildLock: true, prefix: 'iva-thl', env: 'ont', street: 'str11', url: 'https://iva-thl.str11.ont.belastingdienst.nl/thl/rest/isAlive']
    applications["thl str12 ont"] = [buildLock: true, prefix: 'iva-thl', env: 'ont', street: 'str12', url: 'https://iva-thl.str12.ont.belastingdienst.nl/thl/rest/isAlive']
    applications["thl str13 ont"] = [buildLock: true, prefix: 'iva-thl', env: 'ont', street: 'str13', url: 'https://iva-thl.str13.ont.belastingdienst.nl/thl/rest/isAlive']
    //applications["configurator ont"] = [buildLock: false, url: 'https://ont-wd-inzicht-configurator.apps.dtap.belastingdienst.nl/actuator/health']
    // applications["settlement-proxy portal"] = [buildLock: true, prefix: 'settlement-proxy', env: 'ont', street: 'Portal', url: 'https://dx-portaal-01.ont.belastingdienst.nl/iva-settlement-proxy/api/healthcheck']
    // applications["settlement-proxy openshift"] = [buildLock: true, prefix: 'settlement-proxy', env: 'ont', street: 'OpenShift', url: 'https://iva-settlement-proxy-ivamaatwerkgeneriek.cloudapps.belastingdienst.nl/iva-settlement-proxy/api/healthcheck']
    // applications["gsv str12 ont"] = [buildLock: true, prefix: 'GSV', env: 'ont', street: 'str12', url: 'https://iva-gsv.str12.ont.belastingdienst.nl/iva-gsv/rest/isalive']
    // TEST
    //applications["gsv str11 tst"] = [buildLock: true, prefix: 'GSV', env: 'tst', street: 'str11', url: 'https://iva-gsv.str11.tst.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["gsv str12 tst"] = [buildLock: true, prefix: 'GSV', env: 'tst', street: 'str12', url: 'https://iva-gsv.str12.tst.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["settlement str11 tst"] = [buildLock: true, prefix: 'settlement', env: 'tst', street: 'str11', url: 'https://iva-settlement.str11.tst.belastingdienst.nl/iva-settlement/rest/monitor/overall']
    applications["settlement str12 tst"] = [buildLock: true, prefix: 'settlement', env: 'tst', street: 'str12', url: 'https://iva-settlement.str12.tst.belastingdienst.nl/iva-settlement/rest/monitor/overall']
    applications["KEC str11 tst"] = [buildLock: true, prefix: 'GSV', env: 'tst', street: 'str11', url: 'https://iva-kvk-event-consumer.str11.tst.belastingdienst.nl/iva-kvk-event-consumer-ws/rest/isalive']
    applications["KEC str12 tst"] = [buildLock: true, prefix: 'GSV', env: 'tst', street: 'str12', url: 'https://iva-kvk-event-consumer.str12.tst.belastingdienst.nl/iva-kvk-event-consumer-ws/rest/isalive']
    applications["KEC str12 tst"] = [buildLock: true, prefix: 'GSV', env: 'tst', street: 'str12', url: 'https://iva-kvk-event-consumer.str12.tst.belastingdienst.nl/iva-kvk-event-consumer-ws/rest/isalive']
    applications["ZAAK tst1"] = [buildLock: false, url: 'https://tst1-wd-zaakadministratie.apps.dtap.belastingdienst.nl/actuator/health']
    applications["ZAAK tst2"] = [buildLock: false, url: 'https://tst2-wd-zaakadministratie.apps.dtap.belastingdienst.nl/actuator/health']
    applications["REGIE tst1"] = [buildLock: false, url: 'https://tst1-wd-regie.apps.dtap.belastingdienst.nl/actuator/health']
    applications["BAT tst1"] = [buildLock: false, url: 'https://tst1-wd-bat.apps.dtap.belastingdienst.nl/actuator/health']
    applications["BAT tst2"] = [buildLock: false, url: 'https://tst2-wd-bat.apps.dtap.belastingdienst.nl/actuator/health']
    applications["BAT tst-pat"] = [buildLock: false, url: 'https://tst-pat-wd-bat.apps.dtap.belastingdienst.nl/actuator/health']
    applications["BAT tst-baa"] = [buildLock: false, url: 'https://tst-baa-wd-bat.apps.dtap.belastingdienst.nl/actuator/health']
    // applications["inzicht str11 ont"] = [buildLock: true, prefix: 'inzicht', env: 'ont', street: 'str11', url: 'https://inzicht.str11.ont.belastingdienst.nl/inzicht/rest/system/isalive']
    // applications["inzicht str12 ont"] = [buildLock: true, prefix: 'inzicht', env: 'ont', street: 'str12', url: 'https://inzicht.str12.ont.belastingdienst.nl/inzicht/rest/system/isalive']
    // ACCEPTATIE
    applications["gsv str11 acc"] = [buildLock: true, prefix: 'GSV', env: 'acc', street: 'str11', url: 'https://iva-gsv.str11.acc.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["gsv str12 acc"] = [buildLock: true, prefix: 'GSV', env: 'acc', street: 'str12', url: 'https://iva-gsv.str12.acc.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["gsv str13 acc"] = [buildLock: true, prefix: 'GSV', env: 'acc', street: 'str13', url: 'https://iva-gsv.str13.acc.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["settlement str11 acc"] = [buildLock: true, prefix: 'settlement', env: 'acc', street: 'str11', url: 'https://iva-settlement.str11.acc.belastingdienst.nl/iva-settlement/rest/monitor/overall']
    applications["settlement str12 acc"] = [buildLock: true, prefix: 'settlement', env: 'acc', street: 'str12', url: 'https://iva-settlement.str12.acc.belastingdienst.nl/iva-settlement/rest/monitor/overall']
    applications["gsv-tsl str11 acc"] = [buildLock: true, prefix: 'GSV', env: 'acc', street: 'str11', url: 'https://iva-gsv-tsl.str11.acc.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["gsv-tsl str12 acc"] = [buildLock: true, prefix: 'GSV', env: 'acc', street: 'str12', url: 'https://iva-gsv-tsl.str12.acc.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["gsv-tsl str13 acc"] = [buildLock: true, prefix: 'GSV', env: 'acc', street: 'str13', url: 'https://iva-gsv-tsl.str13.acc.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["KEC str11 acc"] = [buildLock: true, prefix: 'GSV', env: 'acc', street: 'str11', url: 'https://iva-kvk-event-consumer.str11.acc.belastingdienst.nl/iva-kvk-event-consumer-ws/rest/isalive']
    applications["KEC str12 acc"] = [buildLock: true, prefix: 'GSV', env: 'acc', street: 'str12', url: 'https://iva-kvk-event-consumer.str12.acc.belastingdienst.nl/iva-kvk-event-consumer-ws/rest/isalive']
    applications["ZAAK acc1"] = [buildLock: false, url: 'https://acc1-wd-zaakadministratie.apps.dtap.belastingdienst.nl/actuator/health']
    applications["ZAAK acc2"] = [buildLock: false, url: 'https://acc2-wd-zaakadministratie.apps.dtap.belastingdienst.nl/actuator/health']
    applications["REGIE acc1"] = [buildLock: false, url: 'https://acc1-wd-regie.apps.dtap.belastingdienst.nl/actuator/health']
    applications["REGIE acc2"] = [buildLock: false, url: 'https://acc2-wd-regie.apps.dtap.belastingdienst.nl/actuator/health']
    applications["BAT acc1"] = [buildLock: false, url: 'https://acc1-wd-bat.apps.dtap.belastingdienst.nl/actuator/health']
    applications["BAT acc2"] = [buildLock: false, url: 'https://acc2-wd-bat.apps.dtap.belastingdienst.nl/actuator/health']
    applications["ORG acc1"] = [buildLock: false, url: 'https://acc1-wd-org.apps.dtap.belastingdienst.nl/actuator/health']
    applications["ORG acc2"] = [buildLock: false, url: 'https://acc2-wd-org.apps.dtap.belastingdienst.nl/actuator/health']
    // PRODUCTIE
    applications["gsv"] = [buildLock: false, url: 'https://iva-gsv.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["gsv-tsl"] = [buildLock: false, url: 'https://iva-gsv-tsl.belastingdienst.nl/iva-gsv/rest/isalive']
    applications["beheermodule"] = [buildLock: false, url: 'https://gsv-beheermodule.belastingdienst.nl/gsv-beheermodule/rest/isalive']
    applications["KvkEventConsumer"] = [buildLock: false, url: 'https://iva-kvk-event-consumer.belastingdienst.nl/iva-kvk-event-consumer-ws/rest/isalive']
    applications["settlement"] = [buildLock: false, url: 'https://iva-settlement.belastingdienst.nl/iva-settlement/rest/monitor/overall']
    applications["ORG"] = [buildLock: false, url: 'https://prod-wd-org-prod.apps.dtap.belastingdienst.nl/actuator/health']
    applications["ZAAK"] = [buildLock: false, url: 'https://prod-wd-zaakadministratie-prod.apps.dtap.belastingdienst.nl/actuator/health']
    applications["BAT"] = [buildLock: false, url: 'https://prod-wd-bat-prod.apps.dtap.belastingdienst.nl/actuator/health']
    applications["REGIE"] = [buildLock: false, url: 'https://prod-wd-regie-prod.apps.dtap.belastingdienst.nl/actuator/health']
    applications["FLAT"] = [buildLock: false, url: 'https://prod-wd-flat-prod.apps.dtap.belastingdienst.nl/actuator/health']

//    applications["ivad str11 tst"] = [buildLock: true, prefix: 'IVAD', env: 'tst', street: 'str11', url: 'https://iva-datadashboard.str11.tst.belastingdienst.nl/iva-datadashboard-ws/rest/isalive']
//    applications["ivad str11 acc"] = [buildLock: true, prefix: 'IVAD', env: 'acc', street: 'str11', url: 'https://iva-datadashboard.str11.acc.belastingdienst.nl/iva-datadashboard-ws/rest/isalive']
//    applications["ivad"] = [buildLock: false, url: 'https://iva-datadashboard.belastingdienst.nl/iva-datadashboard-ws/rest/isalive']
//    applications["StiVers str11 ont"] = [buildLock: true, prefix: 'stivers', env: 'ont', street: 'str11', url: 'https://iva-stivers.str11.ont.belastingdienst.nl/iva-stivers/rest/isalive']
//    applications["StiVers str11 tst"] = [buildLock: true, prefix: 'stivers', env: 'tst', street: 'str11', url: 'https://iva-stivers.str11.tst.belastingdienst.nl/iva-stivers/rest/isalive']
//    applications["StiVers str11 acc"] = [buildLock: true, prefix: 'stivers', env: 'acc', street: 'str11', url: 'https://iva-stivers.str11.acc.belastingdienst.nl/iva-stivers/rest/isalive']
//    applications["StiVers"] = [buildLock: false, url: 'https://iva-stivers.belastingdienst.nl/iva-stivers/rest/isalive']

    for (def hostItem in mapToList(applications)) {
        if ( hostItem.value.buildLock ) {
            lockLabel = hostItem.value.prefix + "_" + hostItem.value.env + "_" + hostItem.value.street
            lock (lockLabel) {
                checkApplication(hostItem)
            }
        } else {
            checkApplication(hostItem)
        }
    }
}

@NonCPS
def checkApplication(hostItem) {
        try { 

            def connection = new URL( hostItem.value.url ).openConnection() as HttpURLConnection
            connection.setRequestProperty( 'User-Agent', 'Jenkins' )
            connection.setRequestProperty( 'Accept', 'text/plain, text/html, application/json' )

            if ( connection.responseCode == 200 ) {
                def slurper = new groovy.json.JsonSlurper()
                def json = slurper.parseText(connection.inputStream.text)

                // mattermostSend channel: '#maatwerk-test', text: "${hostItem.key}", message: "${json.serverName} is alive. ${json.components}", color: 'good'
            } else {
                mattermostSend channel: '#maatwerk-operations', text: "${hostItem.key}", message: "reageert niet Http returncode: ${connection.responseCode}", color: 'danger'
            }
        } catch(Exception ex) {
            mattermostSend channel: '#maatwerk-operations', text: "${hostItem.key}", message: "Exception when trying to connect (${ex.getMessage()})", color: 'danger'
        }
}

@NonCPS
def mapToList(depmap) {
    def dlist = []
    for (def entry2 in depmap) {
        dlist.add(new java.util.AbstractMap.SimpleImmutableEntry(entry2.key, entry2.value))
    }
    dlist
}

@NonCPS
def sortByValue(m){
    return m.sort { a, b -> a.key <=> b.key }
}