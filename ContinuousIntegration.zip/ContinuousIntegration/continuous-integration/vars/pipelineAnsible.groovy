def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrlPrefix = ApplicationConfiguration.getNexusUrlPrefix()

    def sonarUrl = ApplicationConfiguration.getSonarUrl()
    def sonarToken = ApplicationConfiguration.getSonarToken()
    
    def nexusUrl = ApplicationConfiguration.getNexusUrl()
    def dinqUrl = ApplicationConfiguration.getDinqUrl()
    def dinq_credential_id = ApplicationConfiguration.getDinqCredentials()

    def mvnDinqPlugin = ApplicationConfiguration.getMavenDinqPlugin()
    
    def clusterSyncDelaySeconds = 5

    def stageDeployMavenArgs = ''

    def dryRun = false
    def baseDir = '.'
    def lockLabel = 'XXXX'

	def exclude_committer_users = ApplicationConfiguration.getExcludeCommitterUsers()

    if (config.baseDirectory != null) {
	baseDir = config.baseDirectory
    }

    node {
		deleteDir()

		try {
			stage ('Clone') {

				checkout scm

				properties([
					disableConcurrentBuilds(),
					pipelineTriggers([pollSCM('')])  
				])

				committerName = sh (
      				script: 'git --no-pager show -s --format=\'%cn\'',
      				returnStdout: true
				).trim()

				commitMessage = sh (
      				script: 'git log -1 HEAD --pretty=format:\'%s\'',
      				returnStdout: true
				).trim()

						
				excludeCommitMessage = '@NOPOLLING@'
				if (commitMessage.indexOf(excludeCommitMessage) < 0) {
					echo "BUILDEN"
					index = commitMessage.indexOf(excludeCommitMessage)
					echo "index: ${index}"
				}
				else {
					echo "we kunnen stoppen"
				}



				if (committerName != 'jenkins') {
					echo "gewoon doorgaan"
				}
				else {
					echo "committerName: ${committerName}"									
				}

				echo "commitMessage: ${commitMessage}"

			}
			if (! exclude_committer_users.contains(committerName)) {
				stage('Build') {
					echo "Build stage"
				}
				stage ("Sonar"){
					echo "Sonar stage"
				}
				stage('Publish Reports') {
					echo "Reports stage"
				}
				stage('Deploy') {
					echo "Deploy stage"
				}
			} 
			else {
				echo "build, Sonar, Publish Reports and Deploy not executed, because committer is jenkins"
			}
							
			currentBuild.result = 'SUCCESS'

		} catch (any) {
			currentBuild.result = 'FAILURE'
			throw any
		} finally {
			emailNotification()
		}
    }
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
	def gav = new GAV()
	def project = new XmlSlurper().parseText( pomContent )
	gav.groupId = project.groupId.toString()
	gav.artifactId = project.artifactId.toString()
	gav.version = project.version.toString()
	gav
}

class GAV {
	String groupId
	String artifactId
	String version

	def String groupIdPath() {
		groupId.replaceAll("\\.", "/")
	}
	def String versionWithoutSnapshot() {
		if (version.endsWith("-SNAPSHOT")) {
			version.substring(0, version.length() - 9)
		}
		else {
			version
		}
	}
	def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
