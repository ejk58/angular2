def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
	def lockLabel = 'XXXX'

    def robotExtraVariables = ''
    if (config.robotExtraVariables != null) {
        robotExtraVariables = config.robotExtraVariables
    }
    
    node {

        try {
            stage ('Clone') {
                cleanWs()
                checkout scm
                
                if (config.pipelineTrigger != null){
                        pipelineTrigger = config.pipelineTrigger
                } else {
                        pipelineTrigger = [pollSCM('')]
                }

                properties([
                    parameters([
                        choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
						choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                        choice(name: 'reRunFailed', choices: 'NO\nYES', description: 'Rerun failed test suites only?')
                        
                    ]),
                    disableConcurrentBuilds(),
                    pipelineTriggers(pipelineTrigger)
                ])
            }

        stage ("Integration"){
            lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
            lock(lockLabel) {
                def reRun = false
                def environment = params.street + "." + params.environment
                def robotLock = "Lock Robot ${JOB_NAME} ${environment}"
                try{
                    if (config.robotTestPath != null && params.reRunFailed == 'NO') {
                        // rbtLocal(params.street + "." + params.environment, config.robotArguments, config.robotTestPath)
                        lock(robotLock) {
                            echo "Going to run robot tests for ${JOB_NAME}"

                            wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                                sh "robot ${config.robotNonCriticals} ${config.robotArguments} -v ENVIRONMENT:${environment} ${config.robotTestPath}"
                            }
                        }
                    }
                    else {
                        echo "Robot tests skipped."
                    }
                }catch(e){
                    reRun = true
                }  

                if (reRun || params.reRunFailed == 'YES' ) {
                    echo "Rerun started"
//                    rbtReRun(params.street + "." + params.environment, config.robotExcludes, config.robotIncludes, config.robotNonCriticals, config.robotTestPath)
                    def env = (params.environment == "acc") ? "ACC" : "DEV" 

                    lock(robotLock) {
                        echo "Going to run robot tests for ${JOB_NAME}"

                        wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                            sh """
                            set +e \\
                            ;robot ${config.robotNonCriticals} ${config.robotArguments} --rerunfailedsuites output.xml --runemptysuite --output rerun.xml -v ENVIRONMENT:${environment} -v ENV:${env} ${config.robotTestPath} \\
                            ;rebot --processemptysuite ${config.robotNonCriticals} --output output.xml --merge output.xml rerun.xml 
                            """
                        }
                    }

                }
            }
        }
        currentBuild.result = 'SUCCESS'

        } catch (e) {
            currentBuild.result = 'FAILURE'
            throw e
        } finally {
            if (config.robotTestPath != null){ 
                step([$class              : 'RobotPublisher',
                    disableArchiveOutput: false,
                    logFileName         : 'log.html',
                    otherFiles          : '',
                    outputFileName      : '*output.xml',
                    outputPath          : '.',
                    passThreshold       : 100,
                    reportFileName      : '*report.html',
                    unstableThreshold   : 0]);
            }
            emailNotification()
        }
    }
}
