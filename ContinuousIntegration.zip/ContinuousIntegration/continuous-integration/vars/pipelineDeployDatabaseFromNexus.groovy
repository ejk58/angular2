def call(body) {

    def config = [:]
    def approver = ""

    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrlPrefix = ApplicationConfiguration.getNexusUrlPrefix()
    def nexusUrl = ApplicationConfiguration.getNexusUrl()
    def clusterSyncDelay = 0
    def stageDeployMavenArgs = ''

    def dryRun = false
    if (config.dryRun != null) {
		dryRun = config.dryRun
    }
    def contextIsEnvPlusStreet = false
    if (config.contextIsEnvPlusStreet != null) {
		contextIsEnvPlusStreet = config.contextIsEnvPlusStreet
    }
	def extraLiquibaseContext = false
	if (config.extraLiquibaseContext != null) {
		extraLiquibaseContext = config.extraLiquibaseContext
    }
    def baseDir = '.'
    if (config.baseDirectory != null) {
		baseDir = config.baseDirectory
    }

	def channel=ApplicationConfiguration.getMMChannel(config.deploymentId, params.environment)

    // variables for creating Jira release
	def jiraServerUrl = ApplicationConfiguration.getJiraServerUrl()
	def jiraUserCredentialId = ApplicationConfiguration.getJiraUserCredentialId()
	def jiraProjectName = ApplicationConfiguration.getJiraProject(config.deploymentId)
	def jiraReleasePrefix = ApplicationConfiguration.getJiraProjectRlsePref(config.deploymentId)

	// Start deep copy van params omdat params unmodifyable is
    def paramsCopy = [UpdateParametersOnly: params.UpdateParametersOnly
					, environment: params.environment
					, street: params.street
					, run_it_test: params.run_it_test
					, package: params.package
					, application_version: params.application_version
					, version: params.version
					]

	// End deep copy van params omdat params unmodifyable is

    node {
	deleteDir()

	try {
	    stage ('Clone') {
			checkout scm

			properties([
				parameters([
					choice(name: 'package', description: 'The package to be deployed', choices: config.packageChoices),
					choice(name: 'application_version', description: 'The version of the application to be deployed', choices: config.applicationVersionChoices),
					choice(name: 'environment', description: 'Environment to run this script', choices: config.environmentChoices),
					choice(name: 'street', description: 'Which street?', choices: config.streetChoices),
					choice(name: 'run_it_test', description: 'Run the integration tests?', choices: 'NO\nYES'),
                    choice(name: 'UpdateParametersOnly', description: 'Run script only to update the parameters?', choices: 'NO\nYES'),
				]),
				disableConcurrentBuilds()
			])
            onlyParamsUpdate = paramsCopy.UpdateParametersOnly == "YES"
            if (onlyParamsUpdate) {
                    echo "Only updating the parameters."
                }
            else {
                if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                    streets = paramsCopy.street.split('/')
                    if (streets.length > 1) {
                        paramsCopy.street = streets[1]
                    } else {
                        paramsCopy.street = 'productie'
                    }
                    paramsCopy.run_it_test = 'NO'
                    approver = input(id: 'EnterApprover', message: 'Enter user name approver and proceed or abort?', parameters: [
                        [$class: 'StringParameterDefinition', description: 'Approver', name: 'name'],
                    ])
                    if (approver.isEmpty() ) {
                        throw new Exception("Deployment to PRD aborted (Invalid approver).")
                    }
                }
                else {
                    paramsCopy.street = paramsCopy.street.split('/')[0]
                }
            }
		}

	    stage('Deploy') {
			dir(baseDir) {
                if (! onlyParamsUpdate) {
                    projectInfo = getInfoFromPom(readFile("pom.xml"))
                    if (paramsCopy.package != null && ! paramsCopy.package.isEmpty()) {
                        projectInfo.artifactId = paramsCopy.package
                    }
                    if (paramsCopy.application_version != null && ! paramsCopy.application_version.isEmpty()) {
                        projectInfo.version = paramsCopy.application_version
                    }
                    context = paramsCopy.environment.toUpperCase()
                    if (contextIsEnvPlusStreet) {
                        context = paramsCopy.environment.toLowerCase() + "-" + paramsCopy.street.toLowerCase()
                    }
                    if (extraLiquibaseContext) {
                        context = paramsCopy.environment.toUpperCase() + "," + config.extraLiquibaseContext
                    }
                    stage = ApplicationConfiguration.getStageId(paramsCopy.environment.toUpperCase())
                    dbUrl = ApplicationConfiguration.getDbUrl(config.deploymentId, paramsCopy.environment.toUpperCase())
                    dbUserCredentials = ApplicationConfiguration.getJenkinsDbCredentials(config.deploymentId, paramsCopy.environment.toUpperCase())
                    schemaName = ApplicationConfiguration.getSchemaName(config.deploymentId, paramsCopy.environment.toUpperCase(), paramsCopy.street)
                    dbConnectString = ApplicationConfiguration.getDbUrl(config.deploymentId, paramsCopy.environment.toUpperCase())
                    lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street

                    echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** Version          = ${projectInfo.version}\n" +
                        "**  \n" +
                        "** environment      = ${paramsCopy.environment}\n" +
                        "** street           = ${paramsCopy.street}\n" +
                        "** stage            = ${stage}\n" +
                        "**  \n" +
                        "** DB url           = ${dbUrl}\n" +
                        "** DB credentials   = ${dbUserCredentials}\n" +
                        "** context          = ${context}\n" +
                        "** schema           = ${schemaName}\n" +
                        "** contextIsEnvPlusStreet = ${contextIsEnvPlusStreet}\n" +
                        "**  \n" +
                        "** Run IT test      = ${paramsCopy.run_it_test}\n" +
                        "**************************************************************"
                    if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                        echo "**************************************************************\n" +
                        "** Approver	 = ${approver}\n" +
                        "**************************************************************"
                    }
                    
                    if ( paramsCopy.environment.toUpperCase() == "TST" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                        message = "Start uitrol van ${config.deploymentId} versie ${projectInfo.version} op ${paramsCopy.environment} - ${paramsCopy.street}"
                        if (channel?.trim()) {
                        mattermostSend channel: "${channel}", message: "${message}"
                        }
                    }
                    lock (lockLabel) {
                        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: dbUserCredentials, passwordVariable: 'DB_WW', usernameVariable: 'DB_USER']]) {
                            mvnArguments = "-PdeployDB -DversionToDeploy=${projectInfo.version} -Dliquibase.url=${dbUrl} -Dliquibase.username=${env.DB_USER} -Dliquibase.contexts=${context} -Dliquibase.defaultSchemaName=${schemaName} "
                            if (dryRun) {
                                echo "DRYRUN: Deploying database using maven with arguments:\n" +
                                    "- mvnArguments            : ${mvnArguments}\n"
                                echo "**************************************************************"
                            }
                            else {
                                def syncDelay = clusterSyncDelay * 60
                                mvnArguments = "${mvnArguments}  -Dliquibase.password=${env.DB_WW}"
                                sh "mvn deploy ${mvnArguments} "
                            }
                        }
                    }
                }
			}
		}
        stage('Merge2Master') {
            if (! onlyParamsUpdate) {
                if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                    echo "**************************************************************\n" +
                    "**      Merge release branch naar master en delete de branch\n" +
                    "**  \n" +
                    "** release parameters:\n" +
                    "** deploymentId     = ${config.deploymentId}\n" +
                    "** GroupId          = ${projectInfo.groupId}\n" +
                    "** ArtifactId       = ${projectInfo.artifactId}\n" +
                    "** version          = ${projectInfo.version}\n" +
                    "**  \n" +
                    "**************************************************************"                     
                    echo "merge release naar master en delete branch"
                    merge2Master(projectInfo.version)
                }
            }
        }
        stage('jiraReleased') {
            if (! onlyParamsUpdate) {
                if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                    jiraRelease = jiraReleasePrefix + projectInfo.version
                    echo "**************************************************************\n" +
                    "**      set status release in Jira project to released\n" +
                    "**  \n" +
                    "** release parameters:\n" +
                    "** deploymentId     = ${config.deploymentId}\n" +
                    "** GroupId          = ${projectInfo.groupId}\n" +
                    "** ArtifactId       = ${projectInfo.artifactId}\n" +
                    "** version          = ${projectInfo.version}\n" +
                    "**  \n" +
                    "** Jira Project     = ${jiraProjectName}\n" +
                    "** Jira Release     = ${jiraRelease}\n" +
                    "**************************************************************"
                    if (jiraProjectName != null) {
                        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "JIRA_USER", passwordVariable: 'JIRA_WW', usernameVariable: 'JIRA_USER']]) {
                            script="releaseJira.py"
                            def yourScriptAsaString = libraryResource "../resources/${script}" 
                            writeFile file: "${script}", text: yourScriptAsaString
                            sh "python3 -u ${script} ${jiraProjectName} '${jiraRelease}' ${JIRA_USER} ${JIRA_WW} ${jiraServerUrl}"
                        }	
                        echo "release ${jiraProjectName} ${jiraRelease} heeft nu status released "
                    }
                    else {
                        println "No creating Jira project release configured for ${config.deploymentId}"
                    }
                }
            }
        }
		stage('Publish') {
			if (dryRun) {
				echo "Publishing deployed version to MatterMost."
			} else {
                if (! onlyParamsUpdate) {
                    if ( paramsCopy.environment.toUpperCase() == "TST" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                        // if the channel is defined in ApplicationConfiguration
                        if (channel?.trim()) {
                        message = "Einde uitrol van ${config.deploymentId} versie ${projectInfo.version} op ${paramsCopy.environment} - ${paramsCopy.street}"
                        mattermostSend channel: "${channel}", message: "${message}"
                        }
                    }
                    if ( paramsCopy.environment.toUpperCase() == "PRD" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                        message = "${config.deploymentId} versie ${projectInfo.version} uitgerold op ${paramsCopy.environment} - ${paramsCopy.street}"
                        mattermostSend channel: '#maatwerk-deployment', message: "${message}"
                    }
                }
			}
		}
		stage('Start test') {
                if (! onlyParamsUpdate) {
                    if (paramsCopy.run_it_test ==~ /(YES)/) {
                        if (dryRun) {
                            echo "DRYRUN: Running integration tests using parameters:\n" +
                            "- environment      : ${paramsCopy.environment}\n" +
                            "- street           : ${paramsCopy.street}"
                        }
                        else {
                            if (paramsCopy.environment.toUpperCase() == 'PRD') {
                                throw new GroovyRuntimeException("Running tests in production environment is not allowed.")
                            }
                            build job: config.integrationPipeline, parameters: [string(name: 'environment', value: paramsCopy.environment.toLowerCase()), string(name: 'street', value: paramsCopy.street)], propagate: false, wait: false
                        }
                    } else {
                    echo "'run_it_test' set to false >> Robot tests skipped."
                    }
                }
			}
	    currentBuild.result = 'SUCCESS'

	} catch (any) {
	    currentBuild.result = 'FAILURE'
	    throw any
	} finally {
	    emailNotification()
	}
    }
}
@NonCPS
def GAV getInfoFromPom(String pomContent) {
	def gav = new GAV()
	def project = new XmlSlurper().parseText( pomContent )
	gav.groupId = project.groupId.toString()
	gav.artifactId = project.artifactId.toString()
	gav.version = project.version.toString()
	gav
}

class GAV {
	String groupId
	String artifactId
	String version

	def String groupIdPath() {
		groupId.replaceAll("\\.", "/")
	}
	def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}

