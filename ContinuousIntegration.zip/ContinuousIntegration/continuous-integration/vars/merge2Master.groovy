def call(releaseNumber) {
    echo "merge release ${releaseNumber} naar master"
    sh "git checkout master"
    sh "git pull"
    try {
        sh "git checkout release/${releaseNumber}"
        sh "git pull"
        sh "git merge --no-ff --strategy=ours master"
        sh "git push origin HEAD"
        sh "git checkout master"
        sh "git merge release/${releaseNumber}"
        sh "git push"
        sh "git checkout develop"
        sh "git merge release/${releaseNumber}"
        sh "git push"
        sh "git push origin --delete release/${releaseNumber}"
    }
    catch (any) {
        echo "${releaseNumber} is al gemerged"
    }
    
}


