def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrlPrefix = ApplicationConfiguration.getNexusUrlPrefix()
    def nexusUrl = ApplicationConfiguration.getNexusUrl()

    def dryRun = false
    def baseDir = '.'

    if (config.baseDirectory != null) {
		baseDir = config.baseDirectory
    }
	
	gitUrl = scm.userRemoteConfigs[0].url
	gitBranch = scm.branches[0].name
	if (gitBranch.startsWith("*/")) {
		gitBranch = gitBranch.substring(2)
	}
	echo "gitUrl: ${gitUrl}; gitBranch: ${gitBranch}"

    node {
		deleteDir()

		try {
			stage ('Clone') {

				properties([ disableConcurrentBuilds() ])

				sh "git clone --recurse-submodules ${gitUrl} ."
			}
			stage('Update Submodules') {
				dir(baseDir) {
					for (submodule in config.subModuleList.split(",")) {
						echo "Updating ${submodule}."
						sh "cd ${submodule}; pwd; git pull origin develop; cd .."
					}
				}
			}
			stage ("Update version") {
				dir(baseDir) {
					gav = getInfoFromPom(readFile("pom.xml"))
					newVersionNr = gav.getNextVersion()
					echo "New version: ${newVersionNr}"
					sh "mvn versions:set -DnewVersion=${newVersionNr} -DgenerateBackupPoms=false"
				}
			}
			stage('Generate package') {
				if (dryRun) {
					echo "DRYRUN: Generate package using mvn install (package is not uploaded to nexus).\n"
				}
				else {
					wrap([$class: 'ConfigFileBuildWrapper', managedFiles: [[fileId: ApplicationConfiguration.getJenkinsMavenSettingsId(), variable: 'PROJECT_MAVEN_SETTINGS' ]]]) {
						sh "mvn -B -V -U -gs /srv/maven/settings.xml  -s ${env.PROJECT_MAVEN_SETTINGS} clean deploy "
					}
					// sh clean deploy"
				}
			}
			stage('Update GIT') {
				if (dryRun) {
					echo "DRYRUN: Pushing changes to GIT repository\n"
				}
				else {
					sh "git add --all"
					sh "git commit -m \"Updated version.\""
					sh "git status"
					sh "git pull --rebase origin $gitBranch"
					sh "git push origin $gitBranch"
				}
			}
			currentBuild.result = 'SUCCESS'

		} catch (any) {
			currentBuild.result = 'FAILURE'
			throw any
		} finally {
			emailNotification()
		}
    }
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
	def gav = new GAV()
	def project = new XmlSlurper().parseText( pomContent )
	gav.groupId = project.groupId.toString()
	gav.artifactId = project.artifactId.toString()
	gav.version = project.version.toString()
	gav
}

class GAV {
	String groupId
	String artifactId
	String version

	def String groupIdPath() {
		groupId.replaceAll("\\.", "/")
	}
	def String versionWithoutSnapshot() {
		if (version.endsWith("-SNAPSHOT")) {
			version.substring(0, version.length() - 9)
		}
		else {
			version
		}
	}
	def String getNextVersion() {
		def oldVersion = versionWithoutSnapshot()
		def versionParts = oldVersion.split("\\.")
		def previousNumber = versionParts[versionParts.length - 1].toInteger()
		def newVersion = versionParts[0]
		for (def i = 1; i < versionParts.length - 1; i++) {
			newVersion = "${newVersion}.${versionParts[i]}"
		}
		newVersion = "${newVersion}.${previousNumber + 1}"
		if (version.endsWith("-SNAPSHOT")) {
			newVersion = "${newVersion}-SNAPSHOT"
		}
		newVersion
	}
	def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
