def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    if (config.projectDir == null) {
        config.projectDir = './ivai-war'
    }
    if (config.dirToLint == null) {
        config.dirToLint = 'src/main/webapp/app/'
    }
    if (config.eslintConfDir == null) {
        config.eslintConfDir = '.'
    }

    node {

        try {
            stage('Clone') {

                checkout scm

                properties([
                        parameters([
                                string(name: 'projectDir', defaultValue: config.projectDir, description: 'Where is the project located?'),
                                string(name: 'dirToLint', defaultValue: config.dirToLint, description: 'Where is the directory to lint located?'),
                                string(name: 'eslintConfDir', defaultValue: config.eslintConfDir, description: 'Where is .eslintrc.json located?')
                        ]),
                        disableConcurrentBuilds(),
                ])
            }

            stage("Eslint") {
                try {
                    eslint(params.projectDir, params.dirToLint, params.eslintConfDir)
                    currentBuild.result = 'SUCCESS'
                } catch (e) {
                    currentBuild.result = 'FAILURE'
                }
            }

        } catch (e) {
            currentBuild.result = 'FAILURE'
            throw e
        } finally {
            emailNotification()
        }
    }
}