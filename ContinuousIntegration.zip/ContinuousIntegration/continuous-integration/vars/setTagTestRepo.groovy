def call(gitTag) {
    echo "merge tag ${gitTag} naar master"
    sh "git checkout develop"
    sh "git pull"
    sh "git tag ${gitTag}"
    sh "git push origin ${gitTag}"
    sh "git checkout master"
    sh "git pull"
    sh "git merge --strategy=ours develop"
    sh "git push"
}
