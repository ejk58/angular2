def call(body) {

    def config = [:]
    def approver = ""

    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrl = ApplicationConfiguration.getNexusUrl()
    def nexusUrlPrefix = ApplicationConfiguration.getNexusUrlPrefix()
    
    def dinqUrl = ApplicationConfiguration.getDinqUrl()
    def dinq_credential_id = ApplicationConfiguration.getDinqCredentials()
    def annaUrl = ApplicationConfiguration.getAnnaUrl()
    def anna_credential_id = ApplicationConfiguration.getAnnaCredentials()

    def mvnDinqPlugin = ApplicationConfiguration.getMavenDinqPlugin()

    def clusterSyncDelaySeconds = 5

    def stageDeployMavenArgs = ''

    def dryRun = false
    def baseDir = '.'
    def lockLabel = 'XXXX'
    
    if (config.baseDirectory != null) {
        baseDir = config.baseDirectory
    }

    def channel=ApplicationConfiguration.getMMChannel(config.deploymentId, params.environment)

    // variables for creating Jira release
	def jiraServerUrl = ApplicationConfiguration.getJiraServerUrl()
	def jiraUserCredentialId = ApplicationConfiguration.getJiraUserCredentialId()
	def jiraProjectName = ApplicationConfiguration.getJiraProject(config.deploymentId)
	def jiraReleasePrefix = ApplicationConfiguration.getJiraProjectRlsePref(config.deploymentId)

    // creating silence in alertmanager, so it's not firing during deployment
    def silenceId = ""

    // Start deep copy van params omdat params unmodifyable is
    def paramsCopy = [UpdateParametersOnly: params.UpdateParametersOnly
                    , environment: params.environment
                    , street: params.street
                    , run_it_test: params.run_it_test
                    , package: params.package
                    , application_version: params.application_version
                    , version: params.version
                    ]

    // End deep copy van params omdat params unmodifyable is

    node {
    deleteDir()

    try {
        stage ('Clone') {
            checkout scm

            properties([
                parameters([
                    choice(name: 'package', description: 'The package to be deployed', choices: config.packageChoices),
                    choice(name: 'application_version', description: 'The version of the application to be deployed', choices: config.applicationVersionChoices),
                    choice(name: 'AS_version', description: 'The version of the activationSpecification package to be deployed', choices: config.asVersionChoices),
                    choice(name: 'environment', description: 'Environment to run this script', choices: config.environmentChoices),
                    choice(name: 'street', description: 'Which street?', choices: config.streetChoices),
                    choice(name: 'run_it_test', description: 'Run the integration tests?', choices: 'NO\nYES'),
                    choice(name: 'UpdateParametersOnly', description: 'Run script only to update the parameters?', choices: 'NO\nYES')
                ]),
                disableConcurrentBuilds()
            ])

            onlyParamsUpdate = paramsCopy.UpdateParametersOnly == "YES"
            dir(baseDir) {
                projectInfo = getInfoFromPom(readFile("pom.xml"))
                if (onlyParamsUpdate) {
                    echo "Only updating the parameters."
                }
                else {
                    echo "Environment: ${paramsCopy.environment.size()}"
                    echo paramsCopy.environment.toUpperCase()

                    if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                        streets = paramsCopy.street.split('/')
                        if (streets.length > 1) {
                            paramsCopy.street = streets[1]
                        } else {
                            paramsCopy.street = 'productie'

                        }
                        paramsCopy.run_it_test = 'NO'
                        approver = input(id: 'EnterApprover', message: 'Enter user name approver and proceed or abort?', parameters: [
                            [$class: 'StringParameterDefinition', description: 'Approver', name: 'name'],
                        ])
                        if (approver.isEmpty() ) {
                            throw new Exception("Deployment to PRD aborted (Invalid approver).")
                        }
                    }
                    else {
                        paramsCopy.street = paramsCopy.street.split('/')[0]
                    }
                    if (paramsCopy.package != null && ! paramsCopy.package.isEmpty()) {
                        projectInfo.artifactId = paramsCopy.package
                    }
                    if (paramsCopy.application_version != null && ! paramsCopy.application_version.isEmpty()) {
                        projectInfo.version = paramsCopy.application_version
                    }
                    
                    lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
                    echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** Version          = ${paramsCopy.version}\n" +
                        "**  \n" +
                        "** environment      = ${paramsCopy.environment}\n" +
                        "** street           = ${paramsCopy.street}\n" +
                        "**  \n" +
                        "** Run IT test      = ${paramsCopy.run_it_test}\n" +
                        "** lockLabel        = ${lockLabel}\n" +
                        "**************************************************************"
                    if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                        echo "**************************************************************\n" +
                        "** Approver         = ${approver}\n" +
                        "**************************************************************"
                    }
                }
            }
        }

        stage('Deploy') {
            lock(lockLabel) {
                dir(baseDir) {
                    if (! onlyParamsUpdate) {
                        artifactUrl = "${nexusUrl}/${nexusUrlPrefix}/${projectInfo.groupIdPath()}/package-${projectInfo.artifactId}/${projectInfo.version}/package-${projectInfo.artifactId}-${projectInfo.version}.zip"
                        stage = ApplicationConfiguration.getStageId(paramsCopy.environment)
                        destinations = ApplicationConfiguration.getDestinations(config.deploymentId, paramsCopy.environment)

                        echo "**************************************************************\n" +
                            "** Deployment parameters:\n" +
                            "** deploymentId     = ${config.deploymentId}\n" +
                            "** GroupId          = ${projectInfo.groupId}\n" +
                            "** ArtifactId       = ${projectInfo.artifactId}\n" +
                            "** Version          = ${projectInfo.version}\n" +
                            "**  \n" +
                            "** environment      = ${paramsCopy.environment}\n" +
                            "** street           = ${paramsCopy.street}\n" +
                            "** dinqUrl          = ${dinqUrl}\n" +
                            "** dinq_credential  = ${dinq_credential_id}\n" +
                            "** artifactUrl      = ${artifactUrl}\n" +
                            "** stage            = ${stage}\n" +
                            "** destinations     = ${destinations}\n" +
                            "**  \n" +
                            "** Run IT test      = ${paramsCopy.run_it_test}\n" +
                            "**************************************************************"
                        if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                            echo "**************************************************************\n" +
                            "** Approver     = ${approver}\n" +
                            "**************************************************************"
                        }

                        if (dryRun) {
                            def lb_selector =  ApplicationConfiguration.getLbSelector(config.deploymentId, paramsCopy.environment)
                            def nummer = 0
                            for (destination in destinations) {
                                mvnArguments = "-DrepositoryArtifactUrl=$artifactUrl -DdinqEndpoint=$dinqUrl -Dstage=$stage \"-Ddestination=$destination\" -Dparams=\"street=${paramsCopy.street}\" -DdinqAccount=${env.DINQ_ACCOUNT} -DapiKey=${env.DINQ_APIKEY} ${stageDeployMavenArgs}"
                                echo "DRYRUN v11: Deploying artifact using maven with arguments:\n" +
                                    "- stageDeployMavenArgs    : ${stageDeployMavenArgs}\n" +
                                    "- mvnArguments            : ${mvnArguments}\n"
                                echo "**************************************************************"
                                echo "lb_selector: ${lb_selector}"
                                if (lb_selector?.trim()) {
                                    linksStr = sh(
                                                script: "python ~/scripts/listMembers.py ${lb_selector}",
                                                returnStdout: true
                                            ).trim();
                                    echo "output listmembers : ${linksStr}"
                                    def member_hostname =  ApplicationConfiguration.getMemberHostnames(config.deploymentId,  paramsCopy.environment)[nummer]
                                    def member_selector =  ApplicationConfiguration.getMemberSelectors(config.deploymentId,  paramsCopy.environment)[nummer]
                                    echo "selector: ${member_selector} hostname ${member_hostname}"
                                    echo "delete member ${member_selector}"
                                    result = sh(
                                                script: "python ~/scripts/delMember.py ${lb_selector} ${member_selector}",
                                                returnStdout: true
                                            ).trim();
                                    members2 = sh(
                                                script: "python ~/scripts/listMembers.py ${lb_selector}",
                                                returnStdout: true
                                            ).trim()
                                    echo "output listmembers ${members2}"
                                    echo "add member ${member_hostname}"
                                    result1 = sh(
                                                script: "python ~/scripts/addMember.py ${lb_selector} ${member_hostname}",
                                                returnStdout: true
                                            ).trim();
                                    result2 = sh(
                                                script: "python ~/scripts/listMembers.py ${lb_selector}",
                                                returnStdout: true
                                            ).trim();
                                    nummer++
                                }
                                else {
                                  echo "Er is geen LoadBalancer voor ${config.deploymentId} in de ${paramsCopy.environment} omgeving gedefineerd"
                                }
                            }
                        }
                        else {
                            if (! onlyParamsUpdate) {
                                if ( paramsCopy.environment.toUpperCase() == "TST" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                                    message = "Start uitrol van ${config.deploymentId} versie ${projectInfo.version} op ${paramsCopy.environment} - ${paramsCopy.street}"
                                    // if the channel is defined in ApplicationConfiguration
                                    if (channel?.trim()) {
                                    mattermostSend channel: "${channel}", message: "${message}"
                                    }
                                }
                            }
                            def syncDelay = clusterSyncDelaySeconds * 1000
                            def nummer = 0
                            def lb_selector =  ApplicationConfiguration.getLbSelector(config.deploymentId, paramsCopy.environment)
                            // creating silence in alertmanager. So alertmanager won't fire  
                            // host not available message during deploy
                            if ( params.environment.toUpperCase() == "PRD" ) {
                                omgeving = ""
                            }
                            else {
                                omgeving = ".${params.street}.${params.environment}"
                            }
                            instance = "${projectInfo.artifactId}${omgeving}.belastingdienst.nl"
                            script="add_silence.py"
                            def yourScriptAsaString = libraryResource "../resources/${script}" 
                            writeFile file: "${script}", text: yourScriptAsaString
                            silenceId = sh( script: "python3 -u ${script} ${instance}",
                                          returnStdout: true
                                          ).trim();
                            echo "${instance} is ge-silenced in alertmanager met id ${silenceId}"
                            // end of add silence
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: dinq_credential_id, passwordVariable: 'DINQ_APIKEY', usernameVariable: 'DINQ_ACCOUNT']]) {
                                for (destination in destinations) {
                                    if (lb_selector?.trim()) {
                                        def member_hostname =  ApplicationConfiguration.getMemberHostnames(config.deploymentId,  paramsCopy.environment)[nummer]
                                        def member_selector =  ApplicationConfiguration.getMemberSelectors(config.deploymentId,  paramsCopy.environment)[nummer]
                                        echo "DELETE MEMBER selector: ${member_selector} hostname: ${member_hostname}"
                                        result = sh(
                                                    script: "python ~/scripts/delMember.py ${lb_selector} ${member_selector}",
                                                    returnStdout: true
                                                ).trim();
                                        mvnArguments = "-DrepositoryArtifactUrl=$artifactUrl -DdinqEndpoint=$dinqUrl -Dstage=$stage \"-Ddestination=$destination\" -Dparams=\"street=${paramsCopy.street}\" -DdinqAccount=${env.DINQ_ACCOUNT} -DapiKey=${env.DINQ_APIKEY} ${stageDeployMavenArgs} -Ddinq.maven.plugin.was.cluster.sync.time=${syncDelay}"
                                        echo "mvnArguments: ${mvnArguments}"
                                        // sh "mvn ${mvnDinqPlugin}:undeploy ${mvnArguments} "
                                        // sh "mvn ${mvnDinqPlugin}:deleteOrphans ${mvnArguments} "
                                        sh "mvn ${mvnDinqPlugin}:deploy ${mvnArguments} "
                                        echo "ADD MEMBER selector: ${member_selector} hostname: ${member_hostname}"
                                        result1 = sh(
                                                    script: "python ~/scripts/addMember.py ${lb_selector} ${member_hostname}",
                                                    returnStdout: true
                                                ).trim();
                                        nummer++
                                    }
                                    else {
                                        echo "Er is geen LoadBalancer voor ${config.deploymentId} in de ${paramsCopy.environment} omgeving gedefineerd"
                                        mvnArguments = "-DrepositoryArtifactUrl=$artifactUrl -DdinqEndpoint=$dinqUrl -Dstage=$stage \"-Ddestination=$destination\" -Dparams=\"street=${paramsCopy.street}\" -DdinqAccount=${env.DINQ_ACCOUNT} -DapiKey=${env.DINQ_APIKEY} ${stageDeployMavenArgs} -Ddinq.maven.plugin.was.cluster.sync.time=${syncDelay}"
                                        echo "mvnArguments: ${mvnArguments}"
                                        // sh "mvn ${mvnDinqPlugin}:undeploy ${mvnArguments} "
                                        // sh "mvn ${mvnDinqPlugin}:deleteOrphans ${mvnArguments} "
                                        sh "mvn ${mvnDinqPlugin}:deploy ${mvnArguments} "
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        stage('Merge2Master') {
            if (! onlyParamsUpdate) {
                if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                    echo "**************************************************************\n" +
                    "**      Merge release branch naar master en delete de branch\n" +
                    "**  \n" +
                    "** release parameters:\n" +
                    "** deploymentId     = ${config.deploymentId}\n" +
                    "** GroupId          = ${projectInfo.groupId}\n" +
                    "** ArtifactId       = ${projectInfo.artifactId}\n" +
                    "** version          = ${projectInfo.version}\n" +
                    "**  \n" +
                    "**************************************************************"                     
                    echo "merge release naar master en delete branch"
                    merge2Master(projectInfo.version)
                }
            }
        }
        stage('jiraReleased') {
            if (! onlyParamsUpdate) {
                if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                    jiraRelease = jiraReleasePrefix + projectInfo.version
                    echo "**************************************************************\n" +
                    "**      set status release in Jira project to released\n" +
                    "**  \n" +
                    "** release parameters:\n" +
                    "** deploymentId     = ${config.deploymentId}\n" +
                    "** GroupId          = ${projectInfo.groupId}\n" +
                    "** ArtifactId       = ${projectInfo.artifactId}\n" +
                    "** version          = ${projectInfo.version}\n" +
                    "**  \n" +
                    "** Jira Project     = ${jiraProjectName}\n" +
                    "** Jira Release     = ${jiraRelease}\n" +
                    "**************************************************************"
                    if (jiraProjectName != null) {
                        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "JIRA_USER", passwordVariable: 'JIRA_WW', usernameVariable: 'JIRA_USER']]) {
                            script="releaseJira.py"
                            def yourScriptAsaString = libraryResource "../resources/${script}" 
                            writeFile file: "${script}", text: yourScriptAsaString
                            sh "python3 -u ${script} ${jiraProjectName} '${jiraRelease}' ${JIRA_USER} ${JIRA_WW} ${jiraServerUrl}"
                        }	
                        echo "release ${jiraProjectName} ${jiraRelease} heeft nu status released "
                    }
                    else {
                        println "No creating Jira project release configured for ${config.deploymentId}"
                    }
                }
            }
        }
        stage('Publish') {
            if (dryRun) {
                           message = "DRYRUN  ${config.deploymentId} versie ${projectInfo.version} uitgerold op ${paramsCopy.environment} - ${paramsCopy.street}"
                           echo "${message}"
                           }
            else {
                if (! onlyParamsUpdate) {
                    if ( paramsCopy.environment.toUpperCase() == "TST" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                    // if the channel is defined in ApplicationConfiguration
                        if (channel?.trim()) {
                            message = "Einde uitrol van ${config.deploymentId} versie ${projectInfo.version} op ${paramsCopy.environment} - ${paramsCopy.street}"
                            mattermostSend channel: "${channel}", message: "${message}"
                        }
                    }
                    if  ( paramsCopy.environment.toUpperCase() == "PRD" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                        message = "${config.deploymentId} versie ${projectInfo.version} uitgerold op ${paramsCopy.environment} - ${paramsCopy.street}"
                        mattermostSend channel: '#maatwerk-deployment', message: "${message}"
                    }
                }
            }
        }
        stage('Start test') {
            if (! onlyParamsUpdate) {
                if (paramsCopy.run_it_test ==~ /(YES)/) {
                    if (dryRun) {
                        echo "DRYRUN: Running integration tests using parameters:\n" +
                        "- environment      : ${paramsCopy.environment}\n" +
                        "- street           : ${paramsCopy.street}"
                    }
                    else {
                        if (paramsCopy.environment.toUpperCase() == 'PRD') {
                            throw new GroovyRuntimeException("Running tests in production environment is not allowed.")
                        }
                        build job: config.integrationPipeline, parameters: [string(name: 'environment', value: paramsCopy.environment.toLowerCase()), string(name: 'street', value: paramsCopy.street)], propagate: false, wait: false
                    }
                } else {
                echo "'run_it_test' set to false >> Robot tests skipped."
                }
            }
        }
        stage('Start third party test') {
            thirdPartyJobs = ApplicationConfiguration.getThirdPartyJobs(config.deploymentId, paramsCopy.environment)
            if (thirdPartyJobs != null) {
                for (job in thirdPartyJobs['PARTIES']) {
                    println "If enabled the job ${job['DESCRIPTION']} would have been triggered."
                    // sh "curl -X POST ${job['JOBURL']} --user ${job['TOKEN']}"
                }
            }
            else {
                println "No third party jobs configured for ${config.deploymentId}, ${paramsCopy.environment}"
            }
        }
        currentBuild.result = 'SUCCESS'
	
    } catch (any) {
        currentBuild.result = 'FAILURE'
        throw any
    } finally {
        script="del_silence.py"
        def yourScriptAsaString = libraryResource "../resources/${script}" 
        writeFile file: "${script}", text: yourScriptAsaString
          result = sh( script: "python3 -u ${script} ${silenceId}",
          returnStdout: true
        ).trim();
        echo "${instance} wordt weer gemonitord"
        emailNotification()
    }
    }
}
@NonCPS
def GAV getInfoFromPom(String pomContent) {
    def gav = new GAV()
    def project = new XmlSlurper().parseText( pomContent )
    gav.groupId = project.groupId.toString()
    gav.artifactId = project.artifactId.toString()
    gav.version = project.version.toString()
    gav
}

class GAV {
    String groupId
    String artifactId
    String version

    def String groupIdPath() {
        groupId.replaceAll("\\.", "/")
    }
    def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}

