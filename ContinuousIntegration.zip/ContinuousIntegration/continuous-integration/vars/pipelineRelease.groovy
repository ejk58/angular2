import groovy.io.FileType

def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrlPrefix = ApplicationConfiguration.getNexusUrlPrefix()

    def sonarUrl = ApplicationConfiguration.getSonarUrl()
    def sonarToken = ApplicationConfiguration.getSonarToken()
    
    def dryRun = false
    def baseDir = '.'
    if (config.baseDirectory != null) {
		baseDir = config.baseDirectory
    }
    def gitUrl = scm.userRemoteConfigs[0].url
    def gitBranch = scm.branches[0].name
    if (gitBranch.startsWith("*/")) {
		gitBranch = gitBranch.substring(2)
    }
    echo "gitUrl: ${gitUrl}; gitBranch: ${gitBranch}"
    def currentBranch = gitBranch
    def isNormalRelease = "NO"
    if (gitBranch ==~ /(develop)/) {
		isNormalRelease = "YES"
    }

	// variables for creating tags in test repo
	def bitbProject = ApplicationConfiguration.getBitbucketProject(config.deploymentId)
	def	bitbTestRepo = ApplicationConfiguration.getBitbucketTestRepo(config.deploymentId)
	def tmpRepoDir = "/tmp/testrepo"
	def gitServerUrl = ApplicationConfiguration.getGitServerUrl()

	// variables for creating Jira release
	def jiraServerUrl = ApplicationConfiguration.getJiraServerUrl()
	def jiraUserCredentialId = ApplicationConfiguration.getJiraUserCredentialId()
	def jiraProjectName = ApplicationConfiguration.getJiraProject(config.deploymentId)
	def jiraReleasePrefix = ApplicationConfiguration.getJiraProjectRlsePref(config.deploymentId)

    node {
		deleteDir()

		try {
			stage ('Clone') {

				// http://javadoc.jenkins.io/plugin/git/hudson/plugins/git/GitSCM.html
				checkout([$class: 'GitSCM', branches: [[name: gitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CloneOption', depth: 1, noTags: false, reference: '', shallow: false ], [$class: 'MessageExclusion', excludedMessage: '.*\\[maven-release-plugin\\].*'], [$class: 'LocalBranch', localBranch: gitBranch]], submoduleCfg: [], userRemoteConfigs: [[url: gitUrl]]])

				properties([
					parameters([
						choice(name: 'build_application', choices: 'NO\nYES', description: 'Build application before making a new release?'),
						choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
						choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
						choice(name: 'run_it_test', choices: 'YES\nNO', description: 'Run the integration tests?')
					]),
					disableConcurrentBuilds()
				])

			}
			stage('Build') {
				dir(baseDir) {
					projectInfo = getInfoFromPom(readFile("pom.xml"))
					if (params.build_application ==~ /(YES)/) {
						dir(baseDir) {
							snapshotFilename = "DummySnapshotFilename"
							buildnumber = "DummyBuildNumber"
							if (dryRun) {
								echo "DRYRUN: Running maven clean deploy\n"
							}
							else {
								sh "mvn clean deploy -DExtraVersionInformation=-${params.environment}-${params.street} | tee mvn.log "
								snapshotFilenameGrepTxt = "Uploading.*package-${projectInfo.artifactId}-${projectInfo.versionWithoutSnapshot()}-[0123456789]*.[0123456789-]*.zip"

								stdOut = sh script: "grep \"${snapshotFilenameGrepTxt}\" mvn.log", returnStdout: true
								stdOut = stdOut.trim()
								snapshotFilename = stdOut.substring(stdOut.lastIndexOf('/') + 1)
							}
							echo "Project information: ${projectInfo}\nSnapshotFilename: ${snapshotFilename}\n"
						}
					}
					else {
						echo "Skipping maven build\n"
					}
				}
			}
			stage ("Sonar"){
				if (params.build_application ==~ /(YES)/) {
					if (dryRun) {
						echo "DRYRUN: Running sonar check\n"
					}
					else {
						checkout(changelog: false, scm: scm)
						dir(baseDir) {
							sh "mvn clean verify sonar:sonar -Dsonar.host.url=${sonarUrl} -Dsonar.login=${sonarToken}"
						}
					}
				}
				else {
					echo "Skipping Sonar check\n"
				}
			}
			stage('Publish Reports') {
				if (params.build_application ==~ /(YES)/) {
					if (dryRun) {
						echo "DRYRUN: Not publishing reports\n"
					}
					else {
						junit allowEmptyResults: true, testResults: '**/surefire-reports/*.xml'
					}
				}
				else {
					echo "Skip publishing report\n"
				}
			}
			stage('Release prepare') {
				dir(baseDir) {
					releaseVersion = projectInfo.versionWithoutSnapshot()
					echo "**************************************************************\n" +
						"** release parameters:\n" +
						"** deploymentId     = ${config.deploymentId}\n" +
						"** GroupId          = ${projectInfo.groupId}\n" +
						"** ArtifactId       = ${projectInfo.artifactId}\n" +
						"** version          = ${projectInfo.version}\n" +
						"** releaseVersion   = ${releaseVersion}\n" +
						"**  \n" +
						"** Run IT test      = ${params.run_it_test}\n" +
						"** Normal release   = ${isNormalRelease}\n" +
						"**************************************************************"
					if (dryRun) {
						echo "DRYRUN: Running maven release:prepare\n"
					}
					else {
						if (isNormalRelease ==~ /(YES)/) {
							sh "mvn -B -V -U  build-helper:parse-version release:prepare \
								-DdevelopmentVersion=\\\${parsedVersion.majorVersion}.\\\${parsedVersion.nextMinorVersion}.0-SNAPSHOT -DskipTests"
						}
						else {
							sh "mvn -B -V -U  release:prepare -DskipTests"
						}
					}
				}
			}
			stage('Release perform') {
				dir(baseDir) {
					if (dryRun) {
						echo "DRYRUN: Running maven release:perform\n"
					}
					else {
						wrap([$class: 'ConfigFileBuildWrapper', managedFiles: [[fileId: ApplicationConfiguration.getJenkinsMavenSettingsId(), variable: 'PROJECT_MAVEN_SETTINGS' ]]]) {
							sh "mvn -B -V -U  release:perform -DskipTests"
						}
					}
				}
			}
			stage('Git push') {
				if (dryRun) {
					echo "DRYRUN: Pushing git changes to server\n"
				}
				else {
					sh "git status"
					sh "git checkout $currentBranch"
					sh "git pull --rebase origin $currentBranch"
					sh "git status"
					if (isNormalRelease ==~ /(NO)/) {
						echo "We are now on ${gitBranch}, checking out develop branch."
						sh "git push origin ${gitBranch}"
						sh "git checkout develop"
						currentBranch = "develop"
					}

					stdOut = sh script: "pwd", returnStdout: true
					currentDir = new File(stdOut.trim())
					updateVersionsInDeployReleaseScript(releaseVersion)
					sh "git commit -m \"Added new version to pipeline script.\""
					sh "git status"
					sh "git pull --rebase origin $currentBranch"
					sh "git push --tags origin $currentBranch"
					// Only creating a release branch when building an normal release.
					if (isNormalRelease ==~ /(YES)/) {
						releaseBranch = "release/${releaseVersion}"
						sh "git branch ${releaseBranch} ${projectInfo.artifactId}-${releaseVersion}"
						sh "git checkout ${releaseBranch}"
						dir(baseDir) {
							sh "mvn -B -V -U  build-helper:parse-version versions:set -DgenerateBackupPoms=false \
								-DnewVersion=\\\${parsedVersion.majorVersion}.\\\${parsedVersion.minorVersion}.\\\${parsedVersion.nextIncrementalVersion}-SNAPSHOT -DskipTests"
							sh "git add --all"
							sh "git commit -m \"Preparing version for hotfixes.\""
							sh "git push origin ${releaseBranch}"
							// Preparing develop for merges from the release branch
							sh "git checkout develop"
							sh "git pull origin develop"
							sh "git merge -s ours ${releaseBranch}"
							sh "git push origin develop"
						}
						// Only creating a release branch for Test repo when building an normal release.
						echo "**************************************************************\n" +
						"**      Create tag in test repo en merge naar master\n" +
						"**  \n" +
						"** release parameters:\n" +
						"** deploymentId     = ${config.deploymentId}\n" +
						"** GroupId          = ${projectInfo.groupId}\n" +
						"** ArtifactId       = ${projectInfo.artifactId}\n" +
						"** version          = ${projectInfo.version}\n" +
						"** releaseVersion   = ${releaseVersion}\n" +
						"**  \n" +
						"** Test Repo        = ${gitServerUrl}/${bitbProject}/${bitbTestRepo}\n" +
						"** Working Dir      = ${tmpRepoDir}\n" +
						"** Normal release   = ${isNormalRelease}\n" +
						"**************************************************************"
						applicatie = projectInfo.artifactId
												
						if (bitbProject != null) {
							
                            echo "pull request test repo afhandelen"
                            // plaats een tag, zodat je de test versie in
                            // sync loppt met de code versie
							sh "rm -r ${tmpRepoDir} || true"
							sh "mkdir -p ${tmpRepoDir}"
							println "git clone ${gitServerUrl}/${bitbProject}/${bitbTestRepo} ${tmpRepoDir}"
							sh "git clone ${gitServerUrl}/${bitbProject}/${bitbTestRepo} ${tmpRepoDir}"
							dir(tmpRepoDir) {
								gitTag = applicatie + '-' + releaseVersion
                                setTagTestRepo(gitTag)
							}
							sh "rm -r ${tmpRepoDir} || true"
						}
						else {
							println "No creating release branch in test repo configured for ${config.deploymentId}"
						}
						dir(baseDir) {
							projectInfo = getInfoFromPom(readFile("pom.xml"))
							newReleaseVersion = projectInfo.versionWithoutSnapshot()
							jiraRelease = jiraReleasePrefix + newReleaseVersion
							echo "**************************************************************\n" +
							"**      Create release in Jira project\n" +
							"**  \n" +
							"** release parameters:\n" +
							"** deploymentId     = ${config.deploymentId}\n" +
							"** GroupId          = ${projectInfo.groupId}\n" +
							"** ArtifactId       = ${projectInfo.artifactId}\n" +
							"** version          = ${projectInfo.version}\n" +
							"** releaseVersion   = ${newReleaseVersion}\n" +
							"**  \n" +
							"** Jira Project     = ${jiraProjectName}\n" +
							"** Jira Release     = ${jiraRelease}\n" +
							"** Normal release   = ${isNormalRelease}\n" +
							"**************************************************************"
							if (jiraProjectName != null) {
								withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "JIRA_USER", passwordVariable: 'JIRA_WW', usernameVariable: 'JIRA_USER']]) {
									script="createJiraRelease.py"
									def yourScriptAsaString = libraryResource "../resources/${script}" 
									writeFile file: "${script}", text: yourScriptAsaString
									sh "python3 -u ${script} ${jiraProjectName} '${jiraRelease}' ${JIRA_USER} ${JIRA_WW} ${jiraServerUrl}"
								}	
							}
							else {
								println "No creating Jira project release configured for ${config.deploymentId}"
							}
						}
					}
				}
			}	
			stage('Deploying') {
				if (dryRun) {
					echo "DRYRUN: Deploying release\n"
				}
				else {
					runItTests = 'NO'
					if (params.environment.toUpperCase() == 'TST' && params.street.toUpperCase() == 'STR11') {
						runItTests = 'YES'
					}
                    // afvraging is nodig, omdat na aanmaken release voor ivacommon er
                    // geen deployment nodig is. Daarvoor in de buildRelease.groovy de
                    // deployPipeline="" opgegeven.
                    if (config.deployPipeline != "") {
                        echo "Deploying new release to ${params.environment}-${params.street}\n"
                        build job: config.deployPipeline, parameters: [string(name: 'UpdateParametersOnly', value: "YES"), string(name: 'environment', value: params.environment), string(name: 'street', value: params.street)], propagate: false, wait: true
                        build job: config.deployPipeline, parameters: [
                            string(name: 'environment', value: params.environment), 
                            string(name: 'street', value: params.street),
                            string(name: 'run_it_test', value: runItTests)
                            ], propagate: false, wait: false
                    }
                    else {
                        echo "deployPipeline is leeg er hoeft/kan niet worden gedeployed"
                    }
				}
			}
			currentBuild.result = 'SUCCESS'
            cleanWs()

		} catch (any) {
			currentBuild.result = 'FAILURE'
			throw any
		} finally {
			emailNotification()
		}
    }
}

@NonCPS
def updateVersionsInDeployReleaseScript(String versionToAdd) {
	def found = []
	def filenames = []
	currentDir.eachFileMatch(FileType.ANY, ~/deployRelease.*groovy/) {
		found << it
		filenames << it.name
	}
	echo "Number of files to process: ${found.size()}"
	found.each{
		echo "Processing: ${it}"
		File orgFile = new File("${it}")
		File outputFile = new File("${it}.tmp")
		File tempFile = new File("/tmp/${it.name}.old")
		if (tempFile.exists()) {
			tempFile.delete()
		}
		it.withReader { reader ->
			while ((line = reader.readLine())!=null) {
				tempFile << "${line}\n"
				if (line.contains('applicationVersionChoices')) {
					choicesTxt = line.substring(line.indexOf('"') + 1, line.lastIndexOf('"'))
					choices = choicesTxt.split("\\\\n")
					outputFile << line.substring(0, line.indexOf("\"") + 1)
					outputFile << versionToAdd
					for (i = 0; i < Math.min(4, choices.length); i++) {
						outputFile << "\\n${choices[i]}"
					}
					outputFile << "\"\n"
				}
				else {
					outputFile << "${line}\n"
				}
			}
		}
		outputFile.renameTo(orgFile)
	}
	sh "git add ${filenames.join(' ')}"
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
	def gav = new GAV()
	def project = new XmlSlurper().parseText( pomContent )
	gav.groupId = project.groupId.toString()
	gav.artifactId = project.artifactId.toString()
	gav.version = project.version.toString()
	gav
}

class GAV {
	String groupId
	String artifactId
	String version

	def String groupIdPath() {
		groupId.replaceAll("\\.", "/")
	}
	def String versionWithoutSnapshot() {
		if (version.endsWith("-SNAPSHOT")) {
			version.substring(0, version.length() - 9)
		}
		else {
			version
		}
	}
	def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
