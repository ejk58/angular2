def call(String gitUrlDb, String gitBranchDb, String dbUser, String dbUrl, String defaultSchemaName, String changelogFile, String contexts) {
	
			checkout(
				changelog: false,
				scm: [$class: 'GitSCM',
				branches: [[name: "*/${gitBranchDb}"]], 
				doGenerateSubmoduleConfigurations: false, 
				extensions: [[$class: 'CleanCheckout'], [$class: 'RelativeTargetDirectory', relativeTargetDir: "${gitBranchDb}"]], 
				submoduleCfg: [], 
				userRemoteConfigs: [[credentialsId: 'Jenkins ssh', url: "${gitUrlDb}" ]]])
			
			withCredentials([[$class: 'UsernamePasswordMultiBinding',
				credentialsId: "${dbUser}",
                usernameVariable: 'USERNAME',
				passwordVariable: 'PASSWORD']]) {
					sh "/mnt/data/liquibase/liquibase --url=${dbUrl} --defaultSchemaName=${defaultSchemaName} --username=${env.USERNAME} --password=${env.PASSWORD} --logLevel=info --classpath=${WORKSPACE}/${gitBranchDb}/Liquibase --changeLogFile=dropTables.xml --contexts=${contexts} update"
				}
			
			checkout(
				changelog: false,
				scm: [$class: 'GitSCM', 
				branches: [[name: '*/master']], 
				doGenerateSubmoduleConfigurations: false, 
				extensions: [[$class: 'CleanCheckout'], [$class: 'RelativeTargetDirectory', relativeTargetDir: 'master']], 
				submoduleCfg: [], 
				userRemoteConfigs: [[credentialsId: 'Jenkins ssh', url: "${gitUrlDb}" ]]])

			if (fileExists("master/Liquibase/${changelogFile}")) {
				echo 'Changelog exists on master. Executing changelog from master'
				
				withCredentials([[$class: 'UsernamePasswordMultiBinding',
					credentialsId: "${dbUser}",
					usernameVariable: 'USERNAME',
					passwordVariable: 'PASSWORD']]) {
						sh "/mnt/data/liquibase/liquibase --url=${dbUrl} --defaultSchemaName=${defaultSchemaName} --username=${env.USERNAME} --password=${env.PASSWORD} --logLevel=info --classpath=${WORKSPACE}/master/Liquibase --changeLogFile=${changelogFile} --contexts=${contexts} update"
					}
			} else {
				echo 'Skipped liquibase update from master. Changelogfile does not exist.'
			}
			
			checkout(
				changelog: false,
				scm: [$class: 'GitSCM',
				branches: [[name: "*/${gitBranchDb}"]], 
				doGenerateSubmoduleConfigurations: false, 
				extensions: [[$class: 'CleanCheckout'], [$class: 'RelativeTargetDirectory', relativeTargetDir: "${gitBranchDb}"]], 
				submoduleCfg: [], 
				userRemoteConfigs: [[credentialsId: 'Jenkins ssh', url: "${gitUrlDb}" ]]])
}