import ApplicationConfiguration
import groovy.io.FileType

println 'Checking credentials'
def credentials =  ApplicationConfiguration.getJenkinsDbCredentials('ont')
assert credentials == '27a2a787-f5b2-4d17-b13c-44c7c2598504'
credentials =  ApplicationConfiguration.getJenkinsDbCredentials('TST')
assert credentials == '27a2a787-f5b2-4d17-b13c-44c7c2598504'
credentials =  ApplicationConfiguration.getJenkinsDbCredentials('acc')
assert credentials != null
credentials =  ApplicationConfiguration.getJenkinsDbCredentials('PRD')
assert credentials != null

println 'Checking schema names'
def schema = ApplicationConfiguration.getSchemaName('iva-note-database', 'ont', 'str11')
assert schema == 'IVANOTE1'
schema = ApplicationConfiguration.getSchemaName('iva-note-database', 'TST', 'str13')
assert schema == 'IVANOTE3'
schema = ApplicationConfiguration.getSchemaName('gsv-database', 'PRD', 'str11')
assert schema == 'GSV01'
schema = ApplicationConfiguration.getSchemaName('gsv-database', 'acc', 'str18')
assert schema == 'GSV08'
schema = ApplicationConfiguration.getSchemaName('stivers-database', 'ONT', 'str14')
assert schema == 'IVASTIVERS04'
schema = ApplicationConfiguration.getSchemaName('ivabat-database', 'ONT', '_pat')
assert schema == 'IVABAT_PAT'

println 'Checking DB url'
def dbUrl = ApplicationConfiguration.getDbUrl('iva-note-database', 'ont')
assert dbUrl == 'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'
dbUrl = ApplicationConfiguration.getDbUrl('gsv-database-tsl', 'Acc')
assert dbUrl == 'jdbc:db2://gsv-tsl-db.acc.belastingdienst.nl:50000/gsvdb02'
dbUrl = ApplicationConfiguration.getDbUrl('iva-settlement-database', 'prd')
assert dbUrl == 'jdbc:db2://ivas-db.belastingdienst.nl:50000/ivas01'

println 'Checking database configuration'
for(key in ApplicationConfiguration.dbConfig.keySet()) {
	if (key == 'transfer-database') continue

	assert ApplicationConfiguration.getJenkinsDbCredentials(key, "ONT")
	assert ApplicationConfiguration.getDbUrl(key, "ONT")
	assert ApplicationConfiguration.getSchemaName(key, "ONT", "str11")
}

println 'Checking loadbalancer selector'
def lbselector = ApplicationConfiguration.getLbSelector('note','ONT')
assert lbselector == ''
lbselector = ApplicationConfiguration.getLbSelector('note','ACC')
assert lbselector == '277e0605c3594d93ac87955123674b1a'

println 'Checking member hostname'
def memberHostname = ApplicationConfiguration.getMemberHostnames('note','ONt')
assert memberHostname == ['', '']
memberHostname = ApplicationConfiguration.getMemberHostnames('note','ACC')
assert memberHostname[1] == 'ac2p0039.acc.belastingdienst.nl'

println 'Checking OpenSift projectBase'
def projectBase = ApplicationConfiguration.getOSprojectBase('zaakadministratie','ONT')
assert projectBase == 'zaakadministratie'
projectBase = ApplicationConfiguration.getOSprojectBase('BLA','')
assert projectBase == null
projectBase = ApplicationConfiguration.getOSprojectBase('zaakadministratie','BLA')
assert projectBase == null

println 'Checking OpenShift configuration'
for(key in ApplicationConfiguration.OSConfig.keySet()) {
	
	assert ApplicationConfiguration.getOSprojectBase(key, "ONT")
	assert ApplicationConfiguration.getOSprojectName(key, "ONT")
}

println 'Checking MM notification channel projectBase'
def mmchannel = ApplicationConfiguration.getMMChannel('gsv-database-config','TST')
assert mmchannel == '#wd-omgevingen'
mmchannel = ApplicationConfiguration.getMMChannel('BLA','')
assert mmchannel == null

println 'Checking repo config bitbucket project name'
def repoconfig = ApplicationConfiguration.getBitbucketProject('tbm')
assert repoconfig == 'ivatbm'
repoconfig = ApplicationConfiguration.getBitbucketProject('BLA')
assert repoconfig == null

println 'Checking repo config jira project name'
def jiraproj = ApplicationConfiguration.getJiraProject('iva-gsv')
assert jiraproj == 'PGSV'
jiraproj = ApplicationConfiguration.getJiraProject('ivaflat')
assert jiraproj == 'IVAFLAT'
jiraproj = ApplicationConfiguration.getJiraProject('BLA')
assert jiraproj == null


def fileCnt=0
new File(".").eachFile(FileType.FILES) {
	file -> fileCnt++;
}
println "Number of files found: ${fileCnt}."
assert fileCnt > 0

println "Number of files found: ${new File(".").listFiles().length}."
assert new File(".").listFiles().length > 0
println "Current directory is: ${new File('.').getAbsolutePath()}."

println "Checking thirdParty configuration"
assert ApplicationConfiguration.getThirdPartyJobs('DMM', 'ONT') == null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ONT') == null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'BLA') == null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC') != null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC')['PARTIES'] != null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC')['PARTIES'].size() == 1
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC')['PARTIES'][0] != null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC')['PARTIES'][1] == null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC')['PARTIES'][0]['DESCRIPTION'] != null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC')['PARTIES'][0]['DESCRIPTION'] == 'Acc testen van Document Management'
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC')['PARTIES'][0]['JOBURL'] != null
assert ApplicationConfiguration.getThirdPartyJobs('iva-gsv', 'ACC')['PARTIES'][0]['JOBURL'].size() > 20

def config = new Configuration()
def params = new Parameters()
config.deploymentId = 'DMM'
params.environment = 'ONT'
testMethod(config,params)
config.deploymentId = 'iva-gsv'
params.environment = 'ONT'
testMethod(config,params)
config.deploymentId = 'iva-gsv'
params.environment = 'BLA'
testMethod(config,params)
config.deploymentId = 'iva-gsv'
params.environment = 'ACC'
testMethod(config,params)
config.deploymentId = 'dummy application'
params.environment = 'ONT'
testMethod(config,params)
config.deploymentId = 'dummy application'
params.environment = 'TST'
testMethod(config,params)
config.deploymentId = 'dummy application'
params.environment = 'ACC'
testMethod(config,params)
config.deploymentId = 'dummy application'
params.environment = 'PRD'
testMethod(config,params)


def testMethod(config, paramsCopy) {
	// thirdPartyJobs = ApplicationConfiguration.getThirdPartyJobs(deploymentId, environment)
	// if (thirdPartyJobs != null) {
	// 	for (job in thirdPartyJobs['PARTIES']) {
	// 		println "If enabled the job ${job['DESCRIPTION']} would have been triggered."
	// 	}
	// }
	// else {
	// 	println "No third party jobs configured for ${deploymentId}, ${environment}"
	// }
	thirdPartyJobs = ApplicationConfiguration.getThirdPartyJobs(config.deploymentId, paramsCopy.environment)
	if (thirdPartyJobs != null) {
		for (job in thirdPartyJobs['PARTIES']) {
			println "If enabled the job ${job['DESCRIPTION']} would have been triggered."
			// sh "curl -X POST ${job['JOBURL']} --user ${job['TOKEN']}"
		}
	}
	else {
		println "No third party jobs configured for ${config.deploymentId}, ${paramsCopy.environment}"
	}
}

class Configuration {
	String deploymentId
}
class Parameters {
	String environment
}