def call(body) {

    def config = [:]

    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def dryRun = false
    def baseDir = '.'
    if (config.baseDirectory != null) {
		baseDir = config.baseDirectory
    }

    node {
	deleteDir()

	try {
	    stage ('Clone') {
			checkout scm

			properties([
				disableConcurrentBuilds()
			])
		}

	    stage('Run') {
			dir(baseDir) {
                for(omgeving in config.omgevingen) {
                    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: omgeving['SECRET'], passwordVariable: 'DB_WW', usernameVariable: 'DB_USER']]) {
                        if (dryRun) {
                            echo "DRYRUN: Running maven exec naar ${omgeving['ID']}, host: ${omgeving['HOST']}, schema: ${omgeving['SCHEMA']}, user: ${env.DB_USER}\n"
                        } else {
                            echo "Running maven exec naar ${omgeving['ID']}\n"
                            sh "mvn exec:java -Dexec.args=\"-h ${omgeving['HOST']} -s ${omgeving['SCHEMA']} -u ${env.DB_USER} -p ${env.DB_WW}\""
                        }
                    }
                }
			}
		}
	    currentBuild.result = 'SUCCESS'

	} catch (any) {
		currentBuild.result = 'FAILURE'
		throw any
	} finally {
		emailNotification()
	}
    }
}
