def call(String environment, String excludes, String includes, String nonCriticals, String testPath, String processes, String includesPabot) {
    def robotLock = "Lock Robot ${JOB_NAME} ${environment}"

    def robotExcludes = defineInOrExcludes(excludes, "exclude")
    def robotIncludes = defineInOrExcludes(includes, "include")
	def robotNonCriticals = defineInOrExcludes(nonCriticals, "noncritical")
	def env = (environment[-3..-1] == "acc") ? "ACC" : "DEV" 
	
    if (includesPabot != null) {
        robotIncludesPabot = defineInOrExcludes(includesPabot, "include")
    }

    lock(robotLock) {
        echo "Going to run robot tests for ${JOB_NAME}"

        wrap([$class: "Xvfb", autoDisplayName: true]) {
            if (includesPabot == null) {
                sh "robot ${robotIncludes} ${robotExcludes} ${robotNonCriticals} -v ENVIRONMENT:${environment} ${testPath}"
            } else {
                sh """
                set +e \\
                ;robot ${robotIncludes} ${robotExcludes} ${robotNonCriticals} -v ENVIRONMENT:${environment} -v ENV:${env} -o sequential-output.xml -l sequential-log.html -r sequential-report.html ${testPath} \\
                ;pabot --processes ${processes} ${robotIncludesPabot} ${robotExcludes} ${robotNonCriticals} -v ENVIRONMENT:${environment} -v ENV:${env} ${testPath} \\
				;rebot --processemptysuite ${robotNonCriticals} --output output.xml --merge output.xml sequential-output.xml 
                """
            }
        }
    }
}