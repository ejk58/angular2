def call() {
    step([$class              : 'RobotPublisher',
        disableArchiveOutput: false,
        logFileName         : 'log.html',
        otherFiles          : '',
        outputFileName      : '*output.xml',
        outputPath          : '.',
        passThreshold       : 100,
        reportFileName      : '*report.html',
        unstableThreshold   : 0]);
}