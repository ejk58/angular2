#!/usr/bin/bash
hostName=$1
version=$2
assemblyId=$3
ansibleCmd="ansible-playbook -i /srv/git/ansible/hosts -l ${hostName} /srv/git/ansible/playbooks/script.yml -e \"scripts_version=${version} assembly_id=${assemblyId} \""

echo "ansibleCmd=> ${ansibleCmd}"

ssh ansible@oqsoel14827.ont.belastingdienst.nl "${ansibleCmd}"
