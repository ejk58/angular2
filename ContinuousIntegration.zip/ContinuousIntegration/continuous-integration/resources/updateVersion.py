#!/usr/bin/env python3

import argparse
import sys
import glob
import re
from shutil import copyfile
import fileinput
import subprocess

parser = argparse.ArgumentParser(description='update version in deploy groovy script')
parser.add_argument("version",  help="new version of application")

args = parser.parse_args()
version = args.version

files=glob.glob("deployRelease*.groovy")

for file in files:
   dest= "/tmp/" + file + ".bck"
   copyfile(file, dest)
   # fileinput kun je een regel in een file aan passen.
   for line in fileinput.input(file, inplace=1):
     if 'applicationVersionChoices' in line:
           string=line.split('"')[1]
           if not string:
             versionsStr =  version
           else:
             versions=string.split('\\n')
             versions.insert(0,version)
             # gooi de laatste uit de list weg
             if len(versions) > 5:
               versions.pop()
             versionsStr=""
             for i in versions:
                versionsStr = versionsStr + i + "\\n"
           if versionsStr.endswith('\\n'):
             versionsStr = versionsStr[:-2]
           newline = "                applicationVersionChoices = \"" + versionsStr + "\"\n"
           line = line.replace(line,newline)
     sys.stdout.write(line)
   try:
     res = subprocess.check_output(["git", "add",file])
   except subprocess.CalledProcessError as e:
     print(e.output)
sys.exit()