#!/usr/bin/python3

import requests
from requests.packages import urllib3
from jira import JIRA
import argparse


# Initialize Jira connection and project settings

parser = argparse.ArgumentParser(description='create a new Jira project release')
parser.add_argument("projectName",  help="jira project name")
parser.add_argument("version",  help="new version of application for project")
parser.add_argument("userName",  help="jira user name")
parser.add_argument("p",  help="jira password")
parser.add_argument("jiraUrl", nargs="?", default="https://jira.belastingdienst.nl", help="url van jiraServer")

args = parser.parse_args()
projectName = args.projectName.upper()
version = args.version
userName = args.userName
p = args.p
jira_url = args.jiraUrl

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Create Jira connection
options = { 'server': jira_url, 'verify': False }
jira = JIRA(options, basic_auth = (userName, p), get_server_info = False)


def createReleaseMap(jira, project):
    versions = jira.project_versions(project)
    prjList = {}

    # Make a map from version name -> version release date
    for version in versions:
        try:
            prjList[version.name] = version

        # if no release date is set for this version,
        # do something else, e.g., use the name as value instead of the date
        except AttributeError:
            prjList[version.name] = version.name

    return prjList

if createReleaseMap(jira, projectName).get(version) is None:
  jira.create_version(version, projectName , description=None, releaseDate=None, startDate=None, archived=False, released=False)
  print(version + " Added")
else:
  print("versie " + version + " bestaat reeds")


