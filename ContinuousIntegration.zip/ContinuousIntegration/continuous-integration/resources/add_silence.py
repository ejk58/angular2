#!/usr/bin/python3
import requests
import socket
import datetime
import time
import argparse
import json

parser = argparse.ArgumentParser(description='add silence for instance alertmanager and return silenceID')
parser.add_argument("instance",  help="silence ID")

args = parser.parse_args()
instance = args.instance


res = requests.post("http://coewd-grafana.belastingdienst.nl:9093/api/v2/silences", json={
    "matchers": [
        {"name": "instance", "value": "{0}".format(instance) , "isRegex": False}
        ],
    "startsAt": datetime.datetime.utcfromtimestamp(time.time()).isoformat(),
    "endsAt": datetime.datetime.utcfromtimestamp(time.time() + 4*3600).isoformat(),
    "comment": "Rollout on {0}".format(instance),
    "createdBy": "jenkins",
    },
    )
res.raise_for_status()
silenceId = res.json()["silenceID"]
print(silenceId)
