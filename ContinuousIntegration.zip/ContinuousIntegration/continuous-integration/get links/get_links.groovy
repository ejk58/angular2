node {
    checkout scm

    def hosts = [:]

    //hosts["on03p369.ont.belastingdienst.nl"] = [cell: 'ont85', links: [:], secret: 'ont_p3_virtuser']
    hosts["on2p0056.ont.belastingdienst.nl"] = [cell: 'ont85', links: [:], secret: 'ont_p2_virtuser']
    hosts["on2p0062.ont.belastingdienst.nl"] = [cell: 'ont85', links: [:], secret: 'ont_p2_virtuser']
    //hosts["ts03p601.tst.belastingdienst.nl"] = [cell: 'tst85', links: [:], secret: 'tst_p3_virtuser']
    hosts["ts1p1010.tst.belastingdienst.nl"] = [cell: 'tst85', links: [:], secret: 'tst_p1_virtuser']
    hosts["ts1p1014.tst.belastingdienst.nl"] = [cell: 'tst85', links: [:], secret: 'tst_p1_virtuser']
    // Acc
    hosts["ac1p1007.acc.belastingdienst.nl"] = [cell: 'acc85', links: [:], secret: 'acc_p1_virtuser']
    hosts["ac2p0040.acc.belastingdienst.nl"] = [cell: 'acc85', links: [:], secret: 'acc_p2_virtuser']
    // Prod
    hosts["pr1p1014.prod.belastingdienst.nl"] = [cell: 'prd85', links: [:], secret: 'prd_p1_virtuser']
    hosts["pr2p0016.prod.belastingdienst.nl"] = [cell: 'prd85', links: [:], secret: 'prd_p2_virtuser']
    //hosts["on03p651.ont.belastingdienst.nl"] = [cell: 'ont85', links: [:]]
    //hosts["ts03p692.tst.belastingdienst.nl"] = [cell: 'tst85', links: [:]]
    //hosts["on03p679.ont.belastingdienst.nl"] = [cell: 'ont85', links: [:], secret: 'ont_p3_virtuser']
    // jhop was 4.3.1 tbv 8.5.5.12 en MQ migratie
    //hosts["on03p321.ont.belastingdienst.nl"] = [cell: 'ont85', links: [:], secret: 'ont_p3_virtuser']
	//hosts["ts03p636.tst.belastingdienst.nl"] = [cell: 'tst85', links: [:], secret: 'tst_p3_virtuser']
    //inzicht dmgr servers
    //hosts["on03p443.ont.belastingdienst.nl"] = [cell: 'ont85', links: [:], secret: 'ont_p3_virtuser']
	//hosts["ts03p649.tst.belastingdienst.nl"] = [cell: 'tst85', links: [:], secret: 'tst_p3_virtuser']

    def links = getLinksByHosts(hosts);
    makeLinksUnique(links)
    def htmlReplacement = getHtmlByHosts(links)

    //Copy styles from CI repo
    //Files are copied by Root crontab to /var/www/html/links
    def cssFile = new File('/srv/jenkins/data/links/style.css')
    cssFile.write(readFile("${env.WORKSPACE}/get links/style.css"), 'UTF-8')

    def indexFile = new File('/srv/jenkins/data/links/index.html')
    indexFile.write(htmlReplacement.toString(), 'UTF-8')
}

def getDMGUser() {
    return "virtuser"
}

def getDMGpsw() {
    return "admin"
}

def getHtmlHeader() {
    return "<!DOCTYPE html><html><head><link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\"><title>CoE Maatwerk Links</title></head><body><div class=\"header\">CoE Maatwerk Applicaties</div>"
}

def getHtmlFooter() {
    return "</body><footer>CoE Maatwerk</footer></html>"
}

def getLinksByHosts(hosts) {
    def links = [:]
    def linksStr = ""
    for (def hostItem in mapToList(hosts)) {
        echo "**************************************************************\n" +
            "** Processing host:   ${hostItem.key}\n" +
            "** cell             = ${hostItem.value.cell}\n" +
            "** credentials      = ${hostItem.value.secret}\n" +
            "**************************************************************\n"

		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: hostItem.value.secret, passwordVariable: 'USER_WW', usernameVariable: 'USER_NAME']]) {
            linksStr = sh(
                    script: "sshpass -p \"${USER_WW}\" ssh ${USER_NAME}@${hostItem.key} 'sh /home/virtuser/script/get_links.sh ${hostItem.value.cell} || true'",
                    returnStdout: true
            ).trim();
        }
        String[] linksArr = linksStr.split(/(;|,|\n)/);
        for (i = 0; i < linksArr.length; i++) {
            def url = transformUrl(linksArr[i]);
            def linkStatus = getUrlStatus(url)
            if(linkStatus.equals("000")){
                url = url.replaceAll("https://", "http://")
                linkStatus = getUrlStatus(url)
            }
            def urlArr = url =~ /(http|https)(\:\/\/)([a-z-]*).*/
            if (urlArr.matches()) {
                def appName = urlArr[0][3]
                if(links[appName] == null){
                    links[appName] = []
                }
                links[appName] << [index: i, url: url.toString(), status: linkStatus]
            }
            else {
                echo "Bad url: ${url}"
            }
        }
        links = sortByValue(links)
    }
    return links
}

def getHtmlByHosts(links) {
    def htmlReplacement = getHtmlHeader();
    for (def app in mapToList(links)) {
        htmlReplacement = htmlReplacement << "<div class=\"container\"><label for=\"showContent${app.key}\">${app.key}</label><input type=\"checkbox\" id=\"showContent${app.key}\" class=\"showContent\" /><div class=\"content\"><table>"
        for (def link in app.value) {
            def urlStatus = "<td class='ok'>OK</td>";
            if (!link.status.equals("200")) {
                urlStatus = "<td class='fail'>FAIL</td>";
            }
            htmlReplacement = htmlReplacement << "<tr><td><a href='$link.url' target=\"_blank\">${link.url}</a></td>${urlStatus}"
        }
        htmlReplacement = htmlReplacement << "</table></div></div>"
    }
    return htmlReplacement << getHtmlFooter();
}

def transformUrl(url) {
    url = url.replaceAll("nl//", "nl/")
    if (!url.endsWith("/")) {
        url = url << "/"
    }
    return url
}

def getUrlStatus(url){
    return sh(
            script: "curl -s -o /dev/null -I -w \"%{http_code}\" ${url} --insecure || true",
            returnStdout: true
    ).trim();
}

@NonCPS
void makeLinksUnique(Map links) {
    def records2Delete = []
    def urls = []
    links.each{entry -> 
        previousUrl = ''
        records2Delete = []
        urls = []
        for(i=0;i<entry.value.size();i++) {
            if (urls.contains(entry.value[i].get('url'))) records2Delete.add(i)
            else urls.add(entry.value[i].get('url'))
        }
        if (records2Delete.size() > 0) {
            for(i=records2Delete.size()-1; i >= 0; i--) entry.value.remove(records2Delete[i])
        }
    }
}

@NonCPS
def mapToList(depmap) {
    def dlist = []
    for (def entry2 in depmap) {
        dlist.add(new java.util.AbstractMap.SimpleImmutableEntry(entry2.key, entry2.value))
    }
    dlist
}

@NonCPS
def sortByValue(m){
    return m.sort { a, b -> a.key <=> b.key }
}
