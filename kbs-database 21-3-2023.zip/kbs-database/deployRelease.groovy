@Library("GENERIC") _
	pipelineDeployDatabaseFromNexus_openshift {
		deploymentId = "kbs-database"
		integrationPipeline = "iva-kbs_test-Robot"
		packageChoices = "iva-kbs-database"
                applicationVersionChoices = "1.19.0\n1.18.0\n1.17.0\n1.16.2\n1.16.1"
		environmentChoices = "tst\nacc\nprd"
		streetChoices = "1\n2\n3\n4"
	}
