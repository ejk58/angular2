@Library("GENERIC") _
    pipelineDatabase_v2_openshift {
		deploymentId = "kbs-database"
		environmentChoices = "tst\nont\nacc"
		streetChoices = "1\n2\n3\n4"
		codePipeline = []
    }
