@Library("GENERIC") _
    pipelineDatabaseRelease_openshift {
		deploymentId = "kbs-database"
		deployPipeline = "iva-kbs_database-deploy-release"
		integrationPipeline = "iva-kbs_test-Robot"
		environmentChoices = "tst\nacc"
		streetChoices = "1\n2\n3\n4"
	}
