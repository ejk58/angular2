## KBS Database

### Setup Liquibase

Install Liquibase.\
Add Path to Path vars for you system setup .\
For windows: Configuratiescherm\Alle Configuratiescherm-onderdelen\Systeem\
Add: at the end of the PATH variable your location of Liquibase: C:\ws\apps\liquibase-3

check in a new/restarted cli if Liquibase is working by\
```liquibase --version```


### Setup Database

1. Create Liquibase.properties from liquibase.properties.template with your personal settings.
2. defaultScheme adjust to <PERSONAL_ID>_IVAKBS01
3. Download and install liquibase-3 to the ws/apps folder.

### Usage
Make sure you have a correct liquibase.properties file. You can duplicate a liquibase.properties.template file for your usage.

Navigate in terminal from kbs-database to Liquibase/ folder\

```cd Liquibase```


Aside: When running liquibase it will process the queries from ivadm.xml. Which will also call other xml from within. Those xmls's can have the name of the Jira issue for reference comfort.

Use Liquibase/generateH2Schema.sh to generate schema.sql for the spring boot integration tests.

#### commands

first drop your database:\
```liquibase dropAll```\

(tip: check if everything is deleted.)

then build it up:\
```liquibase update```\
  
Pushing to develop is highly likely to trigger a change on develop enviroment str11. Double check the Jenkins settings for the configured results.   
[view Jenkins Server](https://jenkins-wd-build-team3.apps.dtap.belastingdienst.nl/)
