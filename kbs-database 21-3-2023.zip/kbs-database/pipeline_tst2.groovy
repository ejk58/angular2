@Library("GENERIC") _
    pipelineDatabase_v2_openshift {
		deploymentId = "kbs-database"
		environmentChoices = "tst"
		streetChoices = "2"
		codePipeline = []
    }
