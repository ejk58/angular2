@Library("GENERIC") _
    pipelineDatabase_v2_openshift {
		deploymentId = "kbs-database"
		environmentChoices = "ont\ntst\nacc"
		streetChoices = "1\n2\n3\n4"
		codePipeline = ["iva-kbs"]
    }
