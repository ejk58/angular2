#!/bin/bash

outputFile=generated_schema.h2.sql
TESTRESOURCESDIR="../../kbs-klantbehandelsysteem/kbs-backend/src/test/resources"
clear
printf "\n\nGeneration of a sql-script with the ddl definition of a database as defined in the liquibase.properties file.\n"
printf "The generated file will be copied to the resources directory used by the H2 integration tests.
\n\n"
read -p "Press ENTER to continue"

schemas=($(cat liquibase.properties | grep "defaultSchemaName:" | grep -v "#defaultSchemaName:"))
schema=${schemas[1]}
liquibase --changelog-file=$outputFile generate-changelog --schemas=${schema} --overwriteOutputFile=true --exclude-objects=DATABASECHANGELOG,DATABASECHANGELOGLOCK

sed -i -e "s/\"$schema\".//g" $outputFile
sed -i -e "s/CREATE TABLE/CREATE TABLE IF NOT EXISTS/g" $outputFile
sed -i -e "s/CREATE INDEX/CREATE INDEX IF NOT EXISTS/g" $outputFile
sed -i -e "s/-- liquibase formatted sql/--- This file is generated using liquibase using generateH2Schema.sh (located in the database repo dir) /g" $outputFile
sed -i -e '/^-- /d' $outputFile

printf "\n\n"
read -n1 -p "Copy $outputFile to ${TESTRESOURCESDIR} dir (Y/n)? " choice
if  echo $choice | grep '^[Yy]\?$'; then
	cp ./$outputFile ${TESTRESOURCESDIR}/schema.sql; printf "\nFile ${TESTRESOURCESDIR}/schema.sql updated\n\n"
else
	printf "\nGenerated sql file NOT copied to test directory.\n\n"
fi