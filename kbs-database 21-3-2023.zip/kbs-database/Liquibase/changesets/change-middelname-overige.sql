UPDATE KENMERK
SET KENMERK = 'Klantcoördinator'
WHERE KENMERK='overige';
