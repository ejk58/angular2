DELETE FROM API_KEY;
COMMIT;

INSERT INTO API_KEY (API_KEY, CUSTOMER, AUTHORIZED_METHODS) VALUES 
 ('U9T7RR5C2XX5QVIP', 'WEBDEVMQ', 'clearErrorQueue,getErrorMessage,getErrorQueueMessageCount,mqPlaceTextOnSignalQueue,getSignalQueueMessageCount,getSignalMessage,clearSignalQueue')
;
COMMIT;
