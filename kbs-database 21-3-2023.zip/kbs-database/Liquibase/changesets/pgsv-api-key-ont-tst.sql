DELETE FROM API_KEY;
COMMIT;

INSERT INTO API_KEY (API_KEY, CUSTOMER, AUTHORIZED_METHODS) VALUES 
 ('F9NI3P1XYOTODS8C', 'ROBOTZK', 'createZaak,addStatus,retrieveZaken,retrieveAllZaken,setResultaat,retrieveZaakPayload,retrieveZaakDocument,retrieveZaakDocuments,updateZaakPayload') 
;
COMMIT;
