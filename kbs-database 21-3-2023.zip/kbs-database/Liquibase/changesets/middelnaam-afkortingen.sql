MERGE INTO MIDDELNAAM_AFKORTING AS k USING (VALUES
(12, 'Vennootschapsbelasting','VPB', 1),
(13, 'Omzetbelasting','OB', 2),
(14, 'Loonheffingen c.s.','LH', 3),
(15, 'Inkomstenbelasting en premie volksverzekeringen','IH', 4),
(16, 'Schenk- en Erfbelasting','S&E', 5),
(17, 'Energiebelasting','EB', 6),
(18, 'Bankenbelasting','BANKBEL', 7),
(19, 'Assurantiebelasting','ASSBEL', 8),
(20, 'Overdrachtsbelasting','OVB', 9),
(21, 'Verhuurdersheffing','VHH', 10),
(22, 'Invordering','INV', 11),
(23, 'Belasting op Personenauto''s en Motorrijwielen','BPM', 12),
(24, 'Dividendbelasting','DIVBEL', 13),
(25, 'Kansspelbelasting','KSB', 14),
(26, 'Mijnbouwwet','MIJN', 15),
(27, 'Milieubelasting','MIL', 16),
(28, 'Motorrijtuigenbelasting','MRB', 17),
(29, 'Vliegbelasting','VLG', 18),
(30, 'Zorgverzekeringswet','ZVW', 19),
(141, 'Controle', 'Controle', NULL),
(142, 'Klantcoördinator', 'KC', NULL)
) AS X(MIDDEL_ID, NAAM, AFKORTING, RANK)
ON k.MIDDEL_ID = X.MIDDEL_ID
WHEN NOT MATCHED THEN
    INSERT (MIDDEL_ID, NAAM, AFKORTING, RANK) VALUES (X.MIDDEL_ID, X.NAAM, X.AFKORTING, X.RANK)
WHEN MATCHED THEN
    UPDATE SET NAAM = X.NAAM, AFKORTING = X.AFKORTING, RANK = X.RANK;
COMMIT;