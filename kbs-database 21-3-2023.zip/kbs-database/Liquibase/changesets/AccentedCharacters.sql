-- Dit is een test file om characters met accenten mbv. Liquibase in de database te zetten.
-- Deze file is gegenereerd met test-class SbiCodes2Sql (methode: accentedCharactersInSqlfile()) in het kbs project.
MERGE INTO KENMERK AS k USING (VALUES
(-1,  'TEST', 'Umlaut: e-ëË, a-äÄ, o-öÖ, i-ïÏ u-üÜ', null)
) AS X(ID, GROEP, KENMERK, KENMERK_PARENT_ID)
ON k.ID = X.ID
WHEN NOT MATCHED THEN
    INSERT (ID, GROEP, KENMERK, KENMERK_PARENT_ID) VALUES (X.ID, X.GROEP, X.KENMERK, KENMERK_PARENT_ID)
WHEN MATCHED THEN
    UPDATE SET GROEP = X.GROEP, KENMERK = X.KENMERK, KENMERK_PARENT_ID = X.KENMERK_PARENT_ID;
COMMIT;
