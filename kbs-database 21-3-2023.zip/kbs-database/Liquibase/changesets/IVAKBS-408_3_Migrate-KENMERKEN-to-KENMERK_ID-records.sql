/*
Based on https://dba.stackexchange.com/a/241488

- Testdata: -
INSERT INTO ENTITEIT_KENMERK (BSN_RSIN, KENMERKEN, KENMERK_TYPE, VALUES) VALUES
(1234, '25,66,1028', 'BCAV', ''),
(8080, '443', 'SECTR', ''),
(27001, '22000,22001,20000,65465', 'CK', '');

- Expected results after migration: -
SELECT * FROM ENTITEIT_KENMERK;

#	BSN_RSIN	KENMERK_TYPE	VALUES	KENMERK_ID
1	1234		BCAV			''		25
2	1234		BCAV			''		66
3	1234		BCAV			''		1028
4	8080		SECTR			''		443
5	27001		CK				''		20000
6	27001		CK				''		22000
7	27001		CK				''		22001
8	27001		CK				''		65465
*/

-- Define a temporary table copy based on the columns of the real table
DECLARE GLOBAL TEMPORARY TABLE SESSION.ENTITEIT_KENMERK_TEMP AS (
    SELECT BSN_RSIN, KENMERKEN, KENMERK_TYPE, VALUES, KENMERK_ID
    FROM ENTITEIT_KENMERK
) DEFINITION ONLY;

-- Copy contents
INSERT INTO SESSION.ENTITEIT_KENMERK_TEMP
    SELECT BSN_RSIN, KENMERKEN, KENMERK_TYPE, VALUES, KENMERK_ID
    FROM ENTITEIT_KENMERK;

-- Empty the real table so we won't run into trouble with existing records
DELETE FROM ENTITEIT_KENMERK;

-- Fill the real table based on combined data of the temporary table and XML table
INSERT INTO ENTITEIT_KENMERK
    -- Combine information from temporary table with KENMERK_ID's from XML table:
    SELECT EK_TEMP.BSN_RSIN, EK_TEMP.KENMERKEN, EK_TEMP.KENMERK_TYPE, EK_TEMP.VALUES,
        EK_XML.ITEM AS KENMERK_ID
    FROM SESSION.ENTITEIT_KENMERK_TEMP AS EK_TEMP,
    -- Interpret records from temporary table as collections of XML documents:
    XMLTABLE('$doc/items/item'
        PASSING XMLPARSE(
                    DOCUMENT CAST(
                        '<items><item><value>'
                            -- Split up comma-separated values in KENMERKEN by replacing comma's with closing and starting tags of new items
                            || replace(EK_TEMP.KENMERKEN, ',', '</value></item><item><value>')
                            || '</value></item></items>' AS CLOB
                    )
        ) as "doc"
        COLUMNS
            -- Automatically cast the VARCHAR in ITEM to an INTEGER
            ITEM     INTEGER    PATH 'value'
    ) AS EK_XML;

-- Destroy the temporary table
DROP TABLE SESSION.ENTITEIT_KENMERK_TEMP;
