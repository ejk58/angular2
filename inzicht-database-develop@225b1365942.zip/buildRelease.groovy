@Library("GENERIC") _
    pipelineDatabaseRelease {
		deploymentId = "inzicht-database"
		deployPipeline = "inzicht-database_deploy_release"
		integrationPipeline = "inzicht-test"
		environmentChoices = "ont\ntst\nacc"
		streetChoices = "str11\nstr12\nstr13\nstr14"
	}
