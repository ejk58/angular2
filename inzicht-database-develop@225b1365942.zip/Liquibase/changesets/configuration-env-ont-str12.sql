DELETE FROM "CONF_DATASOURCE_PARAM";

INSERT INTO "CONF_DATASOURCE_PARAM"("DATASOURCE_ID", "KEY", "VALUE") VALUES 
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialMappingJAAS', 'rest/teradata/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'restUrl', 'https://tdrest.ont.belastingdienst.nl/tdrest/systems/TeradataVM802/queries'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'teradataSchema', 'IVAI_DEV_VIEW'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'slowQueryThreshold', '2000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'retryOnTimeout', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'acceptHeader', 'application/vnd.com.teradata.rest-v1.0+json'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'contentTypeHeader', 'application/json'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsType', 'APIKEY'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialMappingJAAS', 'rest/zaakadministratie/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'restUrl', 'https://iva-gsv.str15.tst.belastingdienst.nl/iva-gsv/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'credentialMappingJAAS', 'ivai/bvv/login'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'restUrl', 'https://bvv.str10.tst.belastingdienst.nl/bvv'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsType', 'URLPARAMETER'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialMappingJAAS', 'rest/documenten/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'restUrl', 'http://document-viewer-dmge-microservices-stage.apps.dtap.belastingdienst.nl/'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'connectTimeout', '20000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'readTimeout', '20000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'restUrl', 'https://jira-opleiding.belastingdienst.nl/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialMappingJAAS', 'rest/jirafeedback/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'restUrl', 'https://inzicht.str12.ont.belastingdienst.nl/inzicht/rest/'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'credentialsType', 'LTPA2TOKEN'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'restUrl', 'https://iva-mihproxyservice-stub.str12.ont.belastingdienst.nl/iva-mihproxyservice-stub/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'credentialsType', 'LTPA2TOKEN'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'slowQueryThreshold', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'wsaAddressHeader', 'http://servicespecifications.belastingdienst.nl/ivaccent/zaakadministratie');

INSERT INTO "CONF_DOMAIN_ROLE"("DOMAIN_ID", "TYPE", "ROLE", "VIPACCESS") VALUES 
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'di'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'di'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'invordering'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'invordering'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'documenten'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'documenten'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'zaakadministratie'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'zaakadministratie'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'erf'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'erf'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantgeg'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantgeg'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'ib_kis'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'ib_kis'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'upi'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'upi'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'schenk'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'schenk'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'analytics'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'analytics'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'reflection'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'reflection'), 0, 'aug_IVA_maatwerk_dev', 0);

-- Switch the KTA-link to the test-environment
UPDATE "CONF_ATTRIBUTE" SET VALUE = 'kta.str25.tst' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'ktaEnvironment';

-- Use the MIH-proxy (stub) as the access-provider
UPDATE "CONF_ATTRIBUTE" SET VALUE = 'Teradata' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'accessPermissionProvider';

-- Jira
UPDATE "CONF_ATTRIBUTE" SET VALUE = '10102' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'jiraFeedbackProject';
UPDATE "CONF_ATTRIBUTE" SET VALUE = 'Ontwikkeling' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'jiraFeedbackEnvironment';

-- Attribute-group JIRA_FEEDBACK_COMPONENTS
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 1, 'niet_winst', 'Niet-Winst: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 2, 'di', 'MKB / GO: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 3, 'invordering', 'Invordering: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 4, 'documenten', 'Documenten: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 5, 'zaakadministratie', 'Zaakadministratie: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 6, 'analytics', 'Analytics: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 7, 'reflection', 'Reflectie: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 8, 'presentation', 'Presentatie: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 9, 'erf', 'Erfbelasting: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 10, 'ib_kis', 'I&B KI&S: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 11, 'upi', 'UPI: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 12, 'schenk', 'Schenkbelasting: Te beoordelen');

-- Attribute-group JIRA_FEEDBACK_TOPIC_FIX_VERSIONS
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 1, 'De getoonde gegevens zijn onjuist, onvolledig of niet actueel.', '10404');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 2, 'De snelheid waarmee de applicatie reageert of foutmeldingen die in beeld verschijnen.', '10403');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 3, 'Onderdelen van de applicatie of velden die verwarring oproepen.', '10402');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 4, 'Gebruikersgemak.', '10401');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 5, 'Overige wensen.', '10400');
