DELETE FROM "CONF_DATASOURCE_PARAM";

INSERT INTO "CONF_DATASOURCE_PARAM"("DATASOURCE_ID", "KEY", "VALUE") VALUES 
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialMappingJAAS', 'ivai/teradata2/login'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'restUrl', 'https://tdrest.prod.belastingdienst.nl/tdrest/systems/TDrest-Unity/queries'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'teradataSchema', 'DG_I_A_50PRO_INZ'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'connectTimeout', '10000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'readTimeout', '10000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'slowQueryThreshold', '2000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'retryOnTimeout', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'acceptHeader', 'application/vnd.com.teradata.rest-v1.0+json'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'contentTypeHeader', 'application/json'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'restUrl', 'https://'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsType', 'APIKEY'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialMappingJAAS', 'ivai/zaakadministratie/apikey'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'restUrl', 'https://iva-gsv.belastingdienst.nl/iva-gsv/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'trustAllCertificates', 'false'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsType', 'URLPARAMETER'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialMappingJAAS', 'ivai/documenten/apikey'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'restUrl', 'https://appsiva.belastingdienst.nl/DocumentViewer'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'trustAllCertificates', 'false'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'connectTimeout', '20000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'readTimeout', '20000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'credentialMappingJAAS', 'ivai/bvv/login'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'restUrl', 'https://bvv.belastingdienst.nl/bvv'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'trustAllCertificates', 'false'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/BVV'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'restUrl', 'https://inzicht.opleiding.belastingdienst.nl/inzicht/rest/'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'credentialsType', 'LTPA2TOKEN'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'restUrl', 'https://jira.belastingdienst.nl/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialMappingJAAS', 'ivai/jirafeedback/login'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'trustAllCertificates', 'false'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'slowQueryThreshold', '5000');

UPDATE "CONF_DOMAIN_ROLE" SET ROLE = CONCAT(ROLE, '_pilot') WHERE TYPE = 0 AND ROLE LIKE 'aug_IVAI_%' AND ROLE NOT LIKE '%_pilot';

INSERT INTO "CONF_DOMAIN_ROLE"("DOMAIN_ID", "TYPE", "ROLE", "VIPACCESS") VALUES 
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'di'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'di'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'invordering'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'invordering'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'documenten'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'documenten'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'zaakadministratie'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'zaakadministratie'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'erf'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'erf'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantgeg'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantgeg'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'ib_kis'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'ib_kis'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'upi'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'upi'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'schenk'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'schenk'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'analytics'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'analytics'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'reflection'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'reflection'), 0, 'aug_IVA_maatwerk_ops', 0);

-- Jira
UPDATE "CONF_ATTRIBUTE" SET VALUE = '13011' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'jiraFeedbackProject';
UPDATE "CONF_ATTRIBUTE" SET VALUE = 'Opleiding' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'jiraFeedbackEnvironment';

-- Attribute-group JIRA_FEEDBACK_COMPONENTS
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 1, 'niet_winst', 'Niet-Winst: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 2, 'di', 'MKB/GO Toezicht: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 3, 'invordering', 'Invordering: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 4, 'documenten', 'Documenten: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 5, 'zaakadministratie', 'Zaakadministratie: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 6, 'analytics', 'Analytics: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 7, 'reflection', 'Reflectie: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 8, 'klantgeg', 'Klant- en entiteitsgegevens: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 9, 'erf', 'Erfbelasting: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 10, 'ib_kis', 'I&B KI&S: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 11, 'upi', 'UPI: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 12, 'schenk', 'Schenkbelasting: Te beoordelen');

-- Attribute-group JIRA_FEEDBACK_TOPIC_FIX_VERSIONS
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 1, 'De getoonde gegevens zijn onjuist, onvolledig of niet actueel.', '22044');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 2, 'De snelheid waarmee de applicatie reageert of foutmeldingen die in beeld verschijnen.', '22045');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 3, 'Onderdelen van de applicatie of velden die verwarring oproepen.', '22046');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 4, 'Gebruikersgemak.', '22047');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 5, 'Overige wensen.', '22048');

DELETE FROM CONF_PAGE_DOMAIN WHERE domain_id = (SELECT id FROM CONF_DOMAIN WHERE key = 'invordering') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'invordering-betalingen');
DELETE FROM CONF_PAGE_WIDGET WHERE widget_id = (SELECT id FROM CONF_WIDGET WHERE name = 'OVERZICHT_VORDERINGEN_WIDGET') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'di-invordering');

DELETE FROM CONF_PAGE_WIDGET WHERE widget_id = (SELECT id FROM CONF_WIDGET WHERE name = 'BESLAGVRIJEVOET_WIDGET') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'invordering-invordering');
DELETE FROM CONF_PAGE_WIDGET WHERE widget_id = (SELECT id FROM CONF_WIDGET WHERE name = 'OVERZICHT_VORDERINGEN_WIDGET') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'invordering-vorderingen');

DELETE FROM CONF_PAGE_DOMAIN WHERE domain_id = (SELECT id FROM CONF_DOMAIN WHERE key = 'ib_kis') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'ibkis-betalingen');
DELETE FROM CONF_PAGE_WIDGET WHERE widget_id = (SELECT id FROM CONF_WIDGET WHERE name = 'BESLAGVRIJEVOET_WIDGET') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'ibkis-invordering');
DELETE FROM CONF_PAGE_WIDGET WHERE widget_id = (SELECT id FROM CONF_WIDGET WHERE name = 'OVERZICHT_VORDERINGEN_WIDGET') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'ibkis-vorderingen');

DELETE FROM CONF_PAGE_DOMAIN WHERE domain_id = (SELECT id FROM CONF_DOMAIN WHERE key = 'upi') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'upi-betalingen');
DELETE FROM CONF_PAGE_WIDGET WHERE widget_id = (SELECT id FROM CONF_WIDGET WHERE name = 'OVERZICHT_VORDERINGEN_WIDGET') AND page_id = (SELECT id FROM CONF_PAGE WHERE key = 'upi-vorderingen');
