#!/bin/bash 
. ./env.sh

# Checking if the user is logged in
oc whoami >> /dev/null
if [ $? -ne 0 ] ; then
	echo You must first login.
	exit -1
fi

namespace=${basenamespace}-${branch}
echo Openshift namespace ${namespace}

echo stage 'Check or Create Namespace'
oc get projects | grep ${namespace} >> /dev/null
projectExists=$?
if [ ${projectExists} -eq 0 ] ;  then
	echo Namespace ${namespace} exists
else
	./createProject.sh ${basenamespace} ${branch}
fi

echo stage 'Apply kustomized content'
kustomizePath=overlays/${branch}

oc apply -k ./${kustomizePath}

if [ ${projectExists} -eq 0 ] ;  then
	echo stage 'Apply kustomized content'
	oc rollout latest dc/kbs-backend -n ${namespace}
fi
