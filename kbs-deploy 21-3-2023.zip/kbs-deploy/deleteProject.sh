#!/bin/bash

if [ $# -ne 2 ] ; then
	. ./env.sh
else
	basenamespace=$1
	branch=$2
fi

if [ ${branch} = productie -o ${branch} = acceptatie ] ; then
	echo Branch ${branch} can not be deleted.
	exit -1
fi


namespace=${basenamespace}-${branch}

echo stage 'Removing Namespace'
oc label namespace ${namespace} dcs.itsmoplosgroep- --overwrite
oc delete project "${namespace}" 


while oc get projects | grep ${namespace} ; do
	sleep 2
done
