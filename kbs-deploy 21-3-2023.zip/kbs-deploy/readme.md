## Deploying KBS


Voor develop project: zorg er voor dat het serviceaccout van het project wd-kbs-develop als image puller bekent is in het wd-kbs project.

```
oc policy add-role-to-user system:image-puller system:serviceaccount:wd-tima-develop:default

```

### Sealed secrets aanmaken/bijwerken
Allerbelangrijkste info staat hier beschreven, dus volg altijd deze pagina: https://confluence.belastingdienst.nl/display/CPET/Recipe+-+Secrets+veilig+opslaan+in+GIT+met+Sealed+Secrets

Switch naar de Git branch `acceptatie` en pull de nieuwste commits.
Zorg dat je in je omgevingsvariabelen de volgende env. var hebt staan: `SEALED_SECRETS_CONTROLLER_NAMESPACE=sealed-secrets`
Download `kubeseal-0.17.1-windows-amd64.tar.gz` en pak deze uit zodat je het `kubeseal` commando op je command line kan uitvoeren (bijv. in `C:\ws\apps` naast de `oc.exe`)

Voor het gemak: vraag bij Roel zijn invulling van `createSecrets.sh` op, en werk die bij of breid die uit.

Indien niet beschikbaar, kopieer dan `createSecrets.sh.template` naar `createSecrets.sh`. Verander de TIMA namespace en projectnaam naar die van `wd-kbs-acceptatie`. Vul alle literals in met de bestaande SealedSecrets uit het bestand `kbs-deploy\overlays\acceptatie\kbs-sealedsecrets.yaml` en gebruik voor de values van deze secrets de KeePass entries.

Run `createSecrets.sh` en volg stap 2 op Confluence.
Overschrijf daarna `kbs-deploy\overlays\acceptatie\kbs-sealedsecrets.yaml` met de nieuwe invulling.
Run `deploy.sh` en commit daarna alle changes.
Start eventueel een nieuwe rollout om de pod van `wd-kbs-acceptatie` bij te werken