#!/bin/bash

if [ $# -ne 2 ] ; then
	. ./env.sh
else
	basenamespace=$1
	branch=$2
fi

# Check env.sh for the namespace and the branch
namespace=${basenamespace}-${branch}

echo stage 'Check or Create Namespace'
oc new-project "${namespace}" "--description=Branch ${branch} of ${basenamespace}" "--display-name=${basenamespace} -- ${branch} branch"
oc label namespace ${namespace} dcs.itsmoplosgroep=IVA01000 --overwrite
oc -n ${namespace} apply -f base/wd-rolebinding-alle-teamleden.yaml
## oc policy add-role-to-user edit system:serviceaccount:wd-build-team3:jenkins -n ${namespace}
oc policy add-role-to-user system:image-puller system:serviceaccount:${namespace}:default -n ${basenamespace}
oc import-image registry.chp.belastingdienst.nl/redhatio/openjdk-11-rhel7:latest --confirm -n ${namespace}

##oc get secret webdevelopment-robot-pull-secret -n wd-pastebin -o yaml | sed 's/namespace: wd-pastebin/namespace: wd-build-team3/g' | oc create -f -
oc -n ${namespace} apply -f base/wd-robot-pull-secret.yaml
oc secrets link default webdevelopment-robot-pull-secret --for=pull -n ${namespace}
oc secrets link builder webdevelopment-robot-pull-secret -n ${namespace}

