#!/bin/bash
. ./env.sh

namespace=${basenamespace}-${branch}

echo stage 'Removing Namespace'
oc label namespace ${namespace} dcs.itsmoplosgroep- --overwrite
oc delete project "${namespace}" 


while oc get projects | grep ${namespace} ; do
	sleep 2
done
