#!groovy
def deployments = ["cars-backend", "cars-frontend"]
def basenamespace = "cpet"
def rollout_timeout = "1m30s"
def tokenFile = '/run/secrets/kubernetes.io/serviceaccount/token'
def fixedBranches = ['develop', 'test', 'acceptatie', 'productie']

pipeline {
    agent {
        label "ocptools"
    }
    environment {
      branch = "$GIT_BRANCH"
    }
    options {
        disableConcurrentBuilds() 
    }
    stages {
        stage('Check or Create Namespace') {
            /*
              Controleer of project al bestaat
                - Ja, ga vrolijk verder.
                - Nee, maak project aan.
              N.B. Voor het aanmaken van projecten heeft het jenkins
              serviceaccount "self-provisioner" rechten nodig.
            */
            steps {
              script {
                openshift.withCluster() {
                  try {
                    myproject = openshift.selector('project', "${basenamespace}-${branch}")
                    myprojectExists = myproject.exists()
                  } catch (e) {
                    myprojectExists = false
                  } 
                  if ( myprojectExists ) {
                    echo("Project ${basenamespace}-${branch} found")
                  } else {
                    echo("Project ${basenamespace}-${branch} NOT found, attempting to create")
                    openshift.newProject("${basenamespace}-${branch}", "--description", "'Branch ${branch} of ${basenamespace}'", "--display-name", "'${basenamespace} -- ${branch} branch'")
                    openshift.withProject("${basenamespace}-cicd"){
                        openshift.policy("add-role-to-user", "system:image-puller", "system:serviceaccount:${basenamespace}-${branch}:default")
                    }
                  }
                }
              }
            }    
        }

        stage('Apply kustomized content') {
            steps {
              script {
                echo "Working on branch: ${branch}"
                // Check for Kustomize overlay
                if (fileExists('overlays/${branch}')) {
                  kustomizePath = "overlays/${branch}"
                } else {
                  kustomizePath = "base"
                }
                kustomizeFile = findFiles(glob: "${kustomizePath}/kustomization.y*ml")[0].name
                kustomizationFileYAML = readYaml(file: "${kustomizePath}/${kustomizeFile}")
                // Tag image to branch name if branch is a `fixed`branch
                if ( fixedBranches.contains(branch) ) {
                  TOKEN = readFile(file: tokenFile)
                  kustomizationFileYAML.images.each {
                    print "Tagging ${it.newName} from @${it.digest} to :${branch}"
                    sh """
                      skopeo copy docker://${it.newName}@${it.digest} docker://${it.newName}:${branch} --src-tls-verify=false --dest-tls-verify=false --screds="jenkins:${TOKEN}" --dcreds="jenkins:${TOKEN}"
                    """
                  }
                }
                

                /*
                  Op deze plek zou een
                  ```
                  kustomize edit set namespace ${basenamespace}-${branch}
                  ```
                  gedaan kunnen worden, maar de openshift.withProject
                  hieronder heeft hetzelfde resultaat, *MITS* geen enkele
                  resource een namespace genoemd heeft staan. Wanneer we een
                  image met het kustomize commando hebben is het netjes om deze stap
                  hier toe te voegen
                */
                /*
                sh ```
                  pushd base
                  kustomize edit set namespace ${basenamespace}-${branch}
                  popd
                ```
                */
 
                // Uncomment to show what Kustomize will apply
                // sh "oc kustomize ${kustomizePath}"


                // Use "oc apply -k" to apply kustomized content.
                // "kustomize build ${kustomizePath} | oc apply -f -
                // would achieve the same result.
                openshift.withCluster() {
                  openshift.withProject("${basenamespace}-${branch}") {
                    openshift.apply('-k', kustomizePath)

                    // Wait for deployments to complete
                    // TODO: Add "oc rollout undo" on error
                    def errors = []
                    deployments.each {
                      rollout = openshift.selector("deploy/${it}").rollout()
                      try {
                        rollout.status("--timeout=${rollout_timeout}")
                        echo "rollout for ${it} succeeded"
                      } catch(err) {
                        errors.add(it)
                        echo "ERROR: rollout for ${it} failed, trying to revert"
                        rollout.undo()
                        rollout.status()
                      }
                    }
                    if ( errors.size() == 0 ) {
                      echo("All deployments completed succesfully")
                    } else {
                      echo("Not all deployments completed succesfully")
                      errors.each {
                        echo("- ${it}")
                      }
                      error("Stopping pipeline. See previous output.")
                    }
                  } 
                }

              } 
            }    
        }

        stage('Perform Robot Test') {
            steps {
              /*
               Dit is waar geautomagiseerde (smoke,e2e) tests plaats vinden.
              */ 
              script {
                echo 'FIXME'
              }
            }
        }
    }
}
