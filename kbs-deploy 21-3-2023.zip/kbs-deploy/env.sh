basenamespace=wd-kbs
# Checking the git branch we are at
branch=`git branch --show-current`
echo Using branch ${branch}

