export class SelectItem {
  label: string;
  value: any;
}
