import {Component, OnDestroy, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {Change} from '../../../../generated/models';
import {DeleteChangeWizardService} from '../../delete-change-wizard.service';
import {ChangeService} from '../../../../services/change.service';
import {Subscription} from 'rxjs';

@Component({
  selector: 'c-delete-change-selection-step',
  templateUrl: './delete-change-selection-step.component.html',
  styleUrls: ['./delete-change-selection-step.component.scss']
})

export class DeleteChangeSelectionStepComponent extends AbstractWizardStep implements OnInit, OnDestroy {

  public mostRecentChange: Change;
  public isMostRecentChangeInRelease: boolean = false;
  private subscription: Subscription;

  constructor(private deleteChangeWizardService: DeleteChangeWizardService, private readonly changeService: ChangeService) {
    super();
  }

  ngOnInit(): void {
    this.getChange();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private getChange(): void {
    this.subscription = this.changeService.getMostRecentChange().subscribe({
      next: change => {
        this.mostRecentChange = change ? JSON.parse(JSON.stringify(change)) : undefined;
        this.deleteChangeWizardService.wizardData.change = this.mostRecentChange;
        this.isMostRecentChangeInRelease = !!this.mostRecentChange?.releaseId;
      }
    });
  }

  isStepValid(): void {
    this.deleteChangeWizardService.isCurrentStepValid = this.mostRecentChange && !this.isMostRecentChangeInRelease;
  }

}
