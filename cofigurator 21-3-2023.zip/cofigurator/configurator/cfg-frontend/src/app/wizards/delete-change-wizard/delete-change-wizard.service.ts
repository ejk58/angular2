import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {DeleteChangeWizardRoute} from './delete-change-wizard-route';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {DeleteChangeWizardData} from './delete-change-wizard-data';
import {Execution} from '../../domain/execution/execution';

@Injectable()
export class DeleteChangeWizardService extends AbstractWizardService<DeleteChangeWizardData> {

  constructor(private readonly deleteChangeWizardRoute: DeleteChangeWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(deleteChangeWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {change: undefined, execution};
  }

}
