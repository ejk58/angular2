import {Execution} from '../../domain/execution/execution';
import {Change} from '../../generated/models';

export interface DeleteChangeWizardData {
  change: Change;
  execution: Execution;
}
