import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {DeleteChangeWizardRoute} from './delete-change-wizard-route';
import {DeleteChangeWizardData} from './delete-change-wizard-data';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';
import {AppInjector} from '../../app-injector';
import {ExecutionStatus} from '../../domain/execution/execution-status';
import {DeleteChangeWizardService} from './delete-change-wizard.service';

// Steps
const deleteChangeSelectionStep: WizardRouteStep<DeleteChangeWizardData> = new WizardRouteStep('deleteChangeSelectionStep', WizardRouteStepType.Selection, 'Selecteer change');
const deleteChangeStep: WizardRouteStep<DeleteChangeWizardData> = new WizardRouteStep('deleteChangeStep', WizardRouteStepType.Execution, 'Samenvatting');
const successStep: WizardRouteStep<DeleteChangeWizardData> = new WizardRouteStep('successStep', WizardRouteStepType.Success, 'Succes');
const errorStep: WizardRouteStep<DeleteChangeWizardData> = new WizardRouteStep('errorStep', WizardRouteStepType.Error, 'Fout');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([deleteChangeSelectionStep, deleteChangeStep]);
const sectionSuccess: WizardRouteSection = new WizardRouteSection([successStep]);
const sectionError: WizardRouteSection = new WizardRouteSection([errorStep]);
const sections: WizardRouteSection[] = [sectionMain, sectionSuccess, sectionError];

// Split-functions
const splitFunctionMain = (): WizardRouteSection => {
  const deleteChangeWizardService: DeleteChangeWizardService = AppInjector.get(DeleteChangeWizardService);
  if (deleteChangeWizardService.wizardData.execution.status === ExecutionStatus.Success) {
    return sectionSuccess;
  } else {
    return sectionError;
  }
};

// Splits
const splitMain: WizardRouteSplit = new WizardRouteSplit(sectionMain, splitFunctionMain);
const splits: WizardRouteSplit[] = [splitMain];

// RouteConfig
export const DeleteChangeWizardRouteConfig: WizardRoute = new WizardRoute(DeleteChangeWizardRoute.name, sections, splits, sectionMain);
