import {NewReleaseChangesSelectionStepComponent} from './new-release-changes-selection-step/new-release-changes-selection-step.component';
import {NewReleaseNameStepComponent} from './new-release-name-step/new-release-name-step.component';
import {NewReleaseSummaryStepComponent} from './new-release-summary-step/new-release-summary-step.component';

export const list = [
  NewReleaseChangesSelectionStepComponent,
  NewReleaseNameStepComponent,
  NewReleaseSummaryStepComponent
];
