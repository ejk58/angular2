import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {Change, Release} from '../../../../generated/models';
import {ReleaseService} from 'src/app/services/release.service';
import {Observable} from 'rxjs';
import {TableColumn} from '../../../../domain/table/table-column';
import {TableData} from '../../../../domain/table/table-data';
import {DateTimePipe} from '../../../../components/pipes/date-time.pipe';
import {NewReleaseWizardService} from '../../new-release-wizard.service';

@Component({
  selector: 'c-new-release-summary-step',
  templateUrl: './new-release-summary-step.component.html',
  styleUrls: ['./new-release-summary-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: NewReleaseSummaryStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class NewReleaseSummaryStepComponent extends AbstractWizardStep implements OnInit {

  public summaryTableTitle: string;
  public summaryTableCols: TableColumn[];
  public newReleaseData: TableData[];

  constructor(private readonly newReleaseWizardService: NewReleaseWizardService,
              private readonly releaseService: ReleaseService,
              private readonly dateTimePipe: DateTimePipe) {
    super();
  }

  ngOnInit(): void {
    this.setDataForNewReleaseTable();
  }

  public executeChanges(): Observable<string> {
    return this.releaseService.save(this.newReleaseWizardService.wizardData);
  }

  public isStepValid(): void {
    this.newReleaseWizardService.isCurrentStepValid = true;
  }

  private setDataForNewReleaseTable(): void {
    const newRelease: Release = this.newReleaseWizardService.wizardData.release;
    const changes: Change[] = this.newReleaseWizardService.wizardData.changes;

    this.summaryTableTitle = 'Weet u zeker dat u onderstaande release wilt aanmaken?';
    this.summaryTableCols = [{field: 'label', header: 'Release'}, {field: 'value', header: 'Waarde'}];
    this.newReleaseData = [{label: 'Naam', value: newRelease.tag}];
    changes.map(change =>
      this.newReleaseData.push({
        label: 'Change',
        value: `${change.tag} (${this.dateTimePipe.transform(change.date)} ${change.administrator})`
      })
    );
  }
}
