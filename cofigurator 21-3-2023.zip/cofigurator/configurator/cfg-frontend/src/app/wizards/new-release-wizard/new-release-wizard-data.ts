import {Change, Release} from '../../generated/models';
import {Execution} from '../../domain/execution/execution';

export interface NewReleaseWizardData {
  changes: Change[];
  release: Release;
  execution: Execution;
}
