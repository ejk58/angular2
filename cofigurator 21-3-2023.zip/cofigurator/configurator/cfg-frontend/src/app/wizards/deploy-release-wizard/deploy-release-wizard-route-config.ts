import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {DeployReleaseWizardRoute} from './deploy-release-wizard-route';
import {DeployReleaseWizardData} from './deploy-release-wizard-data';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';
import {AppInjector} from '../../app-injector';
import {ExecutionStatus} from '../../domain/execution/execution-status';
import {DeployReleaseWizardService} from './deploy-release-wizard.service';

// Steps
const deployReleaseChooseEnvironmentStep: WizardRouteStep<DeployReleaseWizardData> = new WizardRouteStep('deployReleaseChooseEnvironmentStep', WizardRouteStepType.Selection, 'Selecteer een omgeving');
const deployReleaseChooseReleaseStep: WizardRouteStep<DeployReleaseWizardData> = new WizardRouteStep('deployReleaseChooseReleaseStep', WizardRouteStepType.Selection, 'Selecteer een release');
const deployReleaseSummaryStep: WizardRouteStep<DeployReleaseWizardData> = new WizardRouteStep('deployReleaseSummaryStep', WizardRouteStepType.Execution, 'Samenvatting');
const successStep: WizardRouteStep<DeployReleaseWizardData> = new WizardRouteStep('successStep', WizardRouteStepType.Success, 'Succes');
const errorStep: WizardRouteStep<DeployReleaseWizardData> = new WizardRouteStep('errorStep', WizardRouteStepType.Error, 'Fout');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([deployReleaseChooseEnvironmentStep, deployReleaseChooseReleaseStep, deployReleaseSummaryStep]);
const sectionSuccess: WizardRouteSection = new WizardRouteSection([successStep]);
const sectionError: WizardRouteSection = new WizardRouteSection([errorStep]);
const sections: WizardRouteSection[] = [sectionMain, sectionSuccess, sectionError];

// Split-functions
const splitFunctionMain = (): WizardRouteSection => {
  const deployReleaseWizardService: DeployReleaseWizardService = AppInjector.get(DeployReleaseWizardService);
  if (deployReleaseWizardService.wizardData.execution.status === ExecutionStatus.Success) {
    return sectionSuccess;
  } else {
    return sectionError;
  }
};

// Splits
const splitMain: WizardRouteSplit = new WizardRouteSplit(sectionMain, splitFunctionMain);
const splits: WizardRouteSplit[] = [splitMain];

// RouteConfig
export const DeployReleaseWizardRouteConfig: WizardRoute = new WizardRoute(DeployReleaseWizardRoute.name, sections, splits, sectionMain);
