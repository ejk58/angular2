import {ReleaseRolloutInfo} from '../../generated/models/release-rollout-info';
import {Execution} from '../../domain/execution/execution';

export interface DeployReleaseWizardData {
  environment: string;
  releaseRolloutInfo: ReleaseRolloutInfo;
  execution: Execution;
}
