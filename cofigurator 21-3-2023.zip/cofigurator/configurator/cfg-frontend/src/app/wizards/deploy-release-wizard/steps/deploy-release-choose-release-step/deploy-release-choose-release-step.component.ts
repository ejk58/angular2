import {Component, OnDestroy, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {DeployReleaseWizardService} from '../../deploy-release-wizard.service';
import {Release} from '../../../../generated/models';
import {ReleaseService} from 'src/app/services/release.service';
import {Subscription} from 'rxjs';

@Component({
  selector: 'c-deploy-release-choose-release-step',
  templateUrl: './deploy-release-choose-release-step.component.html',
  styleUrls: ['./deploy-release-choose-release-step.component.scss']
})
export class DeployReleaseChooseReleaseStepComponent extends AbstractWizardStep implements OnInit, OnDestroy {

  public selectedEnvironment: string;
  public currentRelease: Release;
  public nextRelease: Release;
  public isChecked: boolean;
  private subscription: Subscription;

  constructor(private readonly deployReleaseWizardService: DeployReleaseWizardService,
              private readonly releaseService: ReleaseService) {
    super();
  }

  ngOnInit(): void {
    this.selectedEnvironment = this.deployReleaseWizardService.wizardData.environment;
    this.getReleaseRolloutInfoForDomain();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private getReleaseRolloutInfoForDomain(): void {
    this.subscription = this.releaseService.getRolloutInfoForDomain(this.selectedEnvironment).subscribe({
      next: releaseRolloutInfo => {
        this.deployReleaseWizardService.wizardData.releaseRolloutInfo = releaseRolloutInfo;
        this.initializeData();
      }
    });
  }

  private initializeData() {
    this.currentRelease = this.deployReleaseWizardService.wizardData.releaseRolloutInfo.currentRelease;
    this.nextRelease = this.deployReleaseWizardService.wizardData.releaseRolloutInfo.nextRelease;
  }

  isStepValid(): void {
    this.deployReleaseWizardService.isCurrentStepValid = this.isChecked;
  }

}
