import {DeployReleaseChooseEnvironmentStepComponent} from './deploy-release-choose-environment-step/deploy-release-choose-environment-step.component';
import {DeployReleaseChooseReleaseStepComponent} from './deploy-release-choose-release-step/deploy-release-choose-release-step.component';
import {DeployReleaseSummaryStepComponent} from './deploy-release-summary-step/deploy-release-summary-step.component';

export const list = [
  DeployReleaseChooseEnvironmentStepComponent,
  DeployReleaseChooseReleaseStepComponent,
  DeployReleaseSummaryStepComponent
];
