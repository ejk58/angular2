import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {ExportDomainWizardRoute} from './export-domain-wizard-route';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {ExportDomainWizardData} from './export-domain-wizard-data';
import {Execution} from '../../domain/execution/execution';

@Injectable()
export class ExportDomainWizardService extends AbstractWizardService<ExportDomainWizardData> {

  constructor(private readonly exportDomainWizardRoute: ExportDomainWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(exportDomainWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {execution};
  }

}
