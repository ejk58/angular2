import {WizardRoute} from '../../domain/wizard/wizard-route';

export class ExportDomainWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when ExportDomainWizardService is used in ExportDomainWizardRouteConfig.
}
