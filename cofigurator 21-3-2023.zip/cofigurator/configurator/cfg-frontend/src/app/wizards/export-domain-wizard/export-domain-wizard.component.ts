import {Component, OnInit} from '@angular/core';
import {ExportDomainWizardService} from './export-domain-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {ExportDomainWizardRoute} from './export-domain-wizard-route';
import {SpinnerService} from '../../services/spinner.service';

@Component({
  selector: 'c-export-domain-wizard',
  templateUrl: './export-domain-wizard.component.html',
  styleUrls: ['./export-domain-wizard.component.scss']
})
export class ExportDomainWizardComponent extends AbstractWizard implements OnInit {

  constructor(public exportDomainWizardService: ExportDomainWizardService,
              private readonly spinnerService: SpinnerService,
              private readonly exportDomainWizardRoute: ExportDomainWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(exportDomainWizardService, spinnerService, exportDomainWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.exportDomainWizardService.initializeWizard();
  }

}
