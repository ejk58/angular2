import {ExportDomainSelectionStepComponent} from './export-domain-selection-step/export-domain-selection-step.component';
import {ExportDomainSummaryStepComponent} from './export-domain-summary-step/export-domain-summary-step.component';


export const list = [
  ExportDomainSelectionStepComponent,
  ExportDomainSummaryStepComponent
];
