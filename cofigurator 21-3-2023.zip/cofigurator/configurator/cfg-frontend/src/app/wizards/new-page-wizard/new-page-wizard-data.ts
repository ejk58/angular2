import {Execution} from '../../domain/execution/execution';
import {PageDto} from '../../generated/models';

export interface NewPageWizardData {
  pageKey: string;
  pageDto: PageDto;
  execution: Execution;
}

