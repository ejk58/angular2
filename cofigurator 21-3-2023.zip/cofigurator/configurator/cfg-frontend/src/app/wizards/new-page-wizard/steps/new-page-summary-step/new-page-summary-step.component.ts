import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from '../../../../common/abstract-wizard-step';
import {PageService} from '../../../../services/page.service';
import {NewPageWizardService} from '../../new-page-wizard.service';
import {TableData} from '../../../../domain/table/table-data';
import {TableColumn} from '../../../../domain/table/table-column';
import {Tag} from '../../../../domain/tag/tag';
import {Observable} from 'rxjs';
import {PageDto} from '../../../../generated/models';

@Component({
  selector: 'c-new-page-summary-step',
  templateUrl: './new-page-summary-step.component.html',
  styleUrls: ['./new-page-summary-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: NewPageSummaryStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class NewPageSummaryStepComponent extends AbstractWizardStep implements OnInit {

  private isTagUnique: boolean = false;

  public pageDto: PageDto;
  public newPageData: TableData[];
  public defaultCols: TableColumn[] = [{field: 'label', header: 'Naam'}, {field: 'value', header: 'Waarde'}];

  constructor(private readonly pageService: PageService,
              private newPageWizardService: NewPageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.pageDto = this.newPageWizardService.wizardData.pageDto;
    this.setDataForNewPageTable();
  }

  public onTagChanged(tag: Tag): void {
    this.pageDto.tag = tag.tag;
    this.isTagUnique = tag.isUnique;
  }

  public executeChanges(): Observable<string> {
    return this.pageService.newPage(this.newPageWizardService.wizardData.pageDto);
  }

  public isStepValid(): void {
    this.newPageWizardService.isCurrentStepValid = this.pageDto.tag !== '' &&
      this.pageDto.tag !== undefined &&
      this.pageDto.tag !== null &&
      this.isTagUnique;
  }

  private setDataForNewPageTable(): void {
    const pageWidgetNames = (this.pageDto.widgets !== undefined) ? this.pageDto.widgets.map((page) => page.widget.name).join(', ') : undefined;

    this.newPageData = [
      {label: 'Type', value: this.pageDto.type},
      {label: 'Key', value: this.pageDto.key},
      {label: 'Title', value: this.pageDto.title},
      {label: 'Widgets', value: pageWidgetNames}
    ];
  }

}
