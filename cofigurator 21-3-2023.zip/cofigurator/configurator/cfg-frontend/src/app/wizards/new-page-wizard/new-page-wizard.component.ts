import {Component, OnInit} from '@angular/core';
import {NewPageWizardService} from './new-page-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {NewPageWizardRoute} from './new-page-wizard-route';
import {SpinnerService} from '../../services/spinner.service';

@Component({
  selector: 'c-new-page-wizard',
  templateUrl: './new-page-wizard.component.html',
  styleUrls: ['./new-page-wizard.component.scss']
})
export class NewPageWizardComponent extends AbstractWizard implements OnInit {

  constructor(public newPageWizardService: NewPageWizardService,
              private readonly spinnerService: SpinnerService,
              private readonly newPageWizardRoute: NewPageWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(newPageWizardService, spinnerService, newPageWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.newPageWizardService.initializeWizard();
  }

}
