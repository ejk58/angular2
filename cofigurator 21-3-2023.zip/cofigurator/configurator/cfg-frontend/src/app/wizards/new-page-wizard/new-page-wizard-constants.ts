export const NieuwePagina: string = 'Nieuwe Pagina';
