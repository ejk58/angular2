import {Component, OnInit} from '@angular/core';
import {PageService} from 'src/app/services/page.service';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {NewPageWizardService} from '../../new-page-wizard.service';
import {NieuwePagina} from '../../new-page-wizard-constants';
import {SelectItem} from '../../../../common/select-item';

@Component({
  selector: 'c-new-page-selection-step',
  templateUrl: './new-page-selection-step.component.html',
  styleUrls: ['./new-page-selection-step.component.scss']
})

export class NewPageSelectionStepComponent extends AbstractWizardStep implements OnInit {

  public pageSelectItems: SelectItem[] = [];
  public selectedPageKey: string;

  constructor(private readonly pageService: PageService,
              private newPageWizardService: NewPageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.selectedPageKey = this.newPageWizardService.wizardData.pageKey;
    this.getAllPageKeys();
  }

  onSelectedPageKeyChange(): void {
    this.newPageWizardService.initializeWizard();
    this.newPageWizardService.wizardData.pageKey = this.selectedPageKey !== NieuwePagina ? this.selectedPageKey : null;
  }

  private getAllPageKeys(): void {
    this.pageService.getAllPageKeys().subscribe({
      next: pageKeys => {
        this.pageSelectItems = pageKeys.map(pageKey => ({label: pageKey, value: pageKey}));
        this.pageSelectItems.unshift({label: NieuwePagina, value: NieuwePagina});
      }
    });
  }

  isStepValid(): void {
    this.newPageWizardService.isCurrentStepValid = this.selectedPageKey != null;
  }

}
