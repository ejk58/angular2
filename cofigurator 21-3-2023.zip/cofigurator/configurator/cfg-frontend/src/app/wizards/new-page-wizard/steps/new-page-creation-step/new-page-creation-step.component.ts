import {Component, OnInit} from '@angular/core';
import {PageService} from 'src/app/services/page.service';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {NewPageWizardService} from '../../new-page-wizard.service';
import {PageDto} from '../../../../generated/models';

@Component({
  selector: 'c-new-page-creation-step',
  templateUrl: './new-page-creation-step.component.html',
  styleUrls: ['./new-page-creation-step.component.scss']
})

export class NewPageCreationStepComponent extends AbstractWizardStep implements OnInit {

  private pageKey: string;
  private existingPageKeys: string[] = [];
  public pageDto: PageDto;
  public isPageKeyUnique: boolean = true;

  constructor(private readonly pageService: PageService,
              private newPageWizardService: NewPageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.pageKey = this.newPageWizardService.wizardData.pageKey;
    this.pageDto = this.newPageWizardService.wizardData.pageDto;
    this.getAndCheckPageKeys();
  }

  private getAndCheckPageKeys(): void {
    this.pageService.getAllPageKeys().subscribe({
      next: pageKeys => {
        this.existingPageKeys = pageKeys;
        if (this.isUserCreatingNewPage()) {
          this.isPageKeyUnique = true;
        } else if (this.isUserExecutingStepForTheFirstTime()) {
          this.getPageAndFillPageDto(this.pageKey);
        } else {
          this.checkPageKey(this.pageDto.key);
        }
      }
    });
  }

  private isUserCreatingNewPage(): boolean {
    return this.pageKey === null || this.pageKey === undefined;
  }

  private isUserExecutingStepForTheFirstTime(): boolean {
    return this.pageDto.key === undefined &&
      this.pageDto.title === undefined &&
      this.pageDto.type === undefined &&
      this.pageDto.tag === undefined;
  }

  private getPageAndFillPageDto(key: string): void {
    this.pageService.getPage(key).subscribe({
      next: page => {
        this.pageDto.key = page.key;
        this.pageDto.title = page.title;
        this.pageDto.type = page.type;
        this.pageDto.widgets = page.widgets;
        this.checkPageKey(page.key);
      }
    });
  }

  private checkPageKey(key: string): void {
    this.isPageKeyUnique = !this.existingPageKeys.includes(key.trim());
  }

  public onPageDtoKeyChange(key: string): void {
    this.pageDto.key = key;
    this.checkPageKey(key);
  }

  isStepValid(): void {
    this.newPageWizardService.isCurrentStepValid =
      this.pageDto.key != undefined && this.pageDto.key.trim().length > 0 && this.isPageKeyUnique &&
      this.pageDto.title != undefined && this.pageDto.title.trim().length > 0 &&
      this.pageDto.type != undefined;
  }

}
