import {RobotTestsDto} from '../../generated/models';
import {Execution} from '../../domain/execution/execution';

export interface RobotTestsWizardData {
  robotTestsDto: RobotTestsDto;
  execution: Execution;
}
