import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {WidgetService} from 'src/app/services/widget.service';
import {RobotTestsWizardService} from '../../robot-tests-wizard.service';
import {SelectItem} from '../../../../common/select-item';

@Component({
  selector: 'c-robot-tests-widget-selection-step',
  templateUrl: './robot-tests-widget-selection-step.component.html',
  styleUrls: ['./robot-tests-widget-selection-step.component.scss']
})

export class RobotTestsWidgetSelectionStepComponent extends AbstractWizardStep implements OnInit {

  public widgetNames: SelectItem[] = [];
  public selectedWidgetName: string;

  constructor(private readonly widgetService: WidgetService,
              private readonly robotTestsWizardService: RobotTestsWizardService) {
    super();
  }

  ngOnInit(): void {
    this.selectedWidgetName = this.robotTestsWizardService.wizardData.robotTestsDto.widgetName;
    this.reloadWidgetNames();
  }

  onSelectedWidgetNameChange(): void {
    this.robotTestsWizardService.initializeWizard();
    this.robotTestsWizardService.wizardData.robotTestsDto.widgetName = this.selectedWidgetName;
  }

  private reloadWidgetNames() {
    this.widgetService.getAllWidgetNames().subscribe({
      next: widgetNames => {
        this.widgetNames = widgetNames ? widgetNames.map(widgetName => ({label: widgetName, value: widgetName})) : [];
      }
    });
  }

  isStepValid(): void {
    this.robotTestsWizardService.isCurrentStepValid = this.selectedWidgetName != null;
  }

}
