import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {RobotTestsWizardRoute} from './robot-tests-wizard-route';
import {RobotTestsWizardData} from './robot-tests-wizard-data';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {RobotTestsDto} from '../../generated/models';
import {Execution} from '../../domain/execution/execution';

@Injectable()
export class RobotTestsWizardService extends AbstractWizardService<RobotTestsWizardData> {

  constructor(private readonly robotTestsWizardRoute: RobotTestsWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(robotTestsWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const robotTestsDto: RobotTestsDto = {widgetName: undefined, domain: undefined, page: undefined, user: undefined};
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {robotTestsDto, execution};
  }

}
