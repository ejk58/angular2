import {WizardRoute} from '../../domain/wizard/wizard-route';

export class RobotTestsWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when RobotTestsWizardService is used in RobotTestsWizardRouteConfig.
}
