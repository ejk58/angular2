import {Component, OnInit} from '@angular/core';
import {RobotService} from 'src/app/services/robot.service';
import {AbstractWizardStep} from '../../../../common/abstract-wizard-step';
import {RobotTestsWizardService} from '../../robot-tests-wizard.service';

@Component({
  selector: 'c-robot-tests-summary-step',
  templateUrl: './robot-tests-summary-step.component.html',
  styleUrls: ['./robot-tests-summary-step.component.scss']
})

export class RobotTestsSummaryStepComponent extends AbstractWizardStep implements OnInit {

  public exportValue: string;

  constructor(private readonly robotService: RobotService,
              private readonly robotTestsWizardService: RobotTestsWizardService) {
    super();
  }

  ngOnInit(): void {
    this.robotService.exportRobotScript(this.robotTestsWizardService.wizardData.robotTestsDto)
      .subscribe({
        next: script => this.exportValue = script
      });
  }

  public copyTextarea() {
    const copyTextarea: HTMLTextAreaElement = document.querySelector('#exportInputArea');
    copyTextarea.select();
    document.execCommand('copy');
    copyTextarea.setSelectionRange(0, 0);
  }

  public isStepValid(): void {
    this.robotTestsWizardService.isCurrentStepValid = true;
  }
}
