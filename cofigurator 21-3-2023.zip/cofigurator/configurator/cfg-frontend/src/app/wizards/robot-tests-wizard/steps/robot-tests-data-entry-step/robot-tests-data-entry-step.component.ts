import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {RobotTestsDto} from '../../../../generated/models';
import {RobotTestsWizardService} from '../../robot-tests-wizard.service';

@Component({
  selector: 'c-robot-tests-data-entry-step',
  templateUrl: './robot-tests-data-entry-step.component.html',
  styleUrls: ['./robot-tests-data-entry-step.component.scss']
})

export class RobotTestsDataEntryStepComponent extends AbstractWizardStep implements OnInit {

  public robotTestsDto: RobotTestsDto;

  constructor(private readonly robotTestsWizardService: RobotTestsWizardService) {
    super();
  }

  ngOnInit(): void {
    this.robotTestsDto = this.robotTestsWizardService.wizardData.robotTestsDto;
  }

  isStepValid(): void {
    this.robotTestsWizardService.isCurrentStepValid = (
      this.robotTestsDto.domain != null && (this.robotTestsDto.domain.trim().length !== 0) &&
      this.robotTestsDto.page != null && (this.robotTestsDto.page.trim().length !== 0) &&
      this.robotTestsDto.user != null && (this.robotTestsDto.user.trim().length !== 0)
    );
  }

}
