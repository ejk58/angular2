import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {RobotTestsWizardRoute} from './robot-tests-wizard-route';
import {RobotTestsWizardData} from './robot-tests-wizard-data';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';

// Steps
const robotTestsWidgetSelectionStep: WizardRouteStep<RobotTestsWizardData> = new WizardRouteStep('robotTestsWidgetSelectionStep', WizardRouteStepType.Selection, 'Selecteer een widget');
const robotTestsDataEntryStep: WizardRouteStep<RobotTestsWizardData> = new WizardRouteStep('robotTestsDataEntryStep', WizardRouteStepType.Selection, 'Data invoer');
const robotTestsSummaryStep: WizardRouteStep<RobotTestsWizardData> = new WizardRouteStep('robotTestsSummaryStep', WizardRouteStepType.Selection, 'Samenvatting');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([robotTestsWidgetSelectionStep, robotTestsDataEntryStep, robotTestsSummaryStep]);
const sections: WizardRouteSection[] = [sectionMain];

// Split-functions

// Splits
const splits: WizardRouteSplit[] = [];

// RouteConfig
export const RobotTestsWizardRouteConfig: WizardRoute = new WizardRoute(RobotTestsWizardRoute.name, sections, splits, sectionMain);
