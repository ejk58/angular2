import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {ChangePageWizardRoute} from './change-page-wizard-route';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {ChangePageWizardData} from './change-page-wizard-data';
import {Execution} from '../../domain/execution/execution';
import {PageLayoutDto} from '../../generated/models';

@Injectable()
export class ChangePageWizardService extends AbstractWizardService<ChangePageWizardData> {

  constructor(private readonly changePageWizardRoute: ChangePageWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(changePageWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const pageKey: string = undefined;
    const pageLayoutDto: PageLayoutDto = {page: undefined, initialWidgets: undefined, widgets: undefined, tag: undefined};
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {pageKey, pageLayoutDto: pageLayoutDto, execution};
  }

}
