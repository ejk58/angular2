import {Execution} from '../../domain/execution/execution';
import {PageLayoutDto} from '../../generated/models';

export interface ChangePageWizardData {
  pageKey: string;
  pageLayoutDto: PageLayoutDto;
  execution: Execution;
}
