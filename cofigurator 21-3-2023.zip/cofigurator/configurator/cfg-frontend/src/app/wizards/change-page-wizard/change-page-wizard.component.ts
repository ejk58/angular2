import {Component, OnInit} from '@angular/core';
import {ChangePageWizardService} from './change-page-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {ChangePageWizardRoute} from './change-page-wizard-route';
import {SpinnerService} from '../../services/spinner.service';

@Component({
  selector: 'c-page-wizard',
  templateUrl: './change-page-wizard.component.html',
  styleUrls: ['./change-page-wizard.component.scss']
})
export class ChangePageWizardComponent extends AbstractWizard implements OnInit {

  constructor(public changePageWizardService: ChangePageWizardService,
              private readonly spinnerService: SpinnerService,
              private readonly changePageWizardRoute: ChangePageWizardRoute,
              private readonly wizardStore: WizardStore,) {
    super(changePageWizardService, spinnerService, changePageWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.changePageWizardService.initializeWizard();
  }

}
