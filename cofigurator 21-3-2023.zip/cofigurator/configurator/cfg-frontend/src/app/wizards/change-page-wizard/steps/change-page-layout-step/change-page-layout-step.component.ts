import {Component, OnInit} from '@angular/core';
import {Page, PageWidget} from '../../../../generated/models';
import {PageService} from 'src/app/services/page.service';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {ChangePageWizardService} from '../../change-page-wizard.service';
import {Direction} from '../../../../domain/page/direction';
import {SelectItem} from '../../../../common/select-item';
import {WidgetService} from '../../../../services/widget.service';
import * as _ from 'lodash-es';

@Component({
  selector: 'c-change-page-layout-step',
  templateUrl: './change-page-layout-step.component.html',
  styleUrls: ['./change-page-layout-step.component.scss']
})

export class ChangePageLayoutStepComponent extends AbstractWizardStep implements OnInit {

  public pageKey: string;
  public page: Page;
  public pageWidgetList: PageWidget[] = [];
  public rows: PageWidget[][] = [];

  public widgetNames: SelectItem[] = [];
  public selectedWidgetName: string;

  constructor(private readonly pageService: PageService,
              private readonly widgetService: WidgetService,
              private readonly changePageWizardService: ChangePageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.getWidgetNamesForDomainAndGeneric();
    this.pageKey = this.changePageWizardService.wizardData.pageKey;
    if (this.changePageWizardService.wizardData.pageLayoutDto.page === undefined) {
      this.getPageInfoAndInitializeData();
    } else {
      this.initializeData();
    }
  }

  public moveWidgetToRow(currentRowIndex: number, currentPageWidgetIndex: number, direction: Direction): void {
    if (this.cantMoveToRow(currentRowIndex, direction)) {
      return;
    }

    // When moving at the extremes, add a new empty row at beginning or end of array
    const isFirstRow: boolean = currentRowIndex === 0;
    const isLastRow: boolean = currentRowIndex === this.rows.length - 1;
    if (isFirstRow && direction === Direction.Up) {
      this.rows.unshift([]);
      currentRowIndex++; // Add 1 to currentRowIndex because new row is inserted at beginning of array
    }
    if (isLastRow && direction === Direction.Down) {
      this.rows.push([]);
    }

    // Move
    const pageWidgetToMove = this.rows[currentRowIndex][currentPageWidgetIndex];
    this.rows[currentRowIndex].splice(currentPageWidgetIndex, 1);
    this.rows[currentRowIndex + direction].splice(currentPageWidgetIndex, 0, pageWidgetToMove);

    // Remove row if empty and update row and column indices
    this.removeRowIfEmpty(currentRowIndex);
    this.updateRowAndColumnIndices();
  }

  public moveWidgetInRow(row: PageWidget[], pageWidgetIndex: number, direction: Direction): void {
    if (this.cantMoveLeft(pageWidgetIndex, direction) || this.cantMoveRight(row, pageWidgetIndex, direction)) {
      return;
    }

    // Swap
    const pageWidgetIndexToSwapWith = pageWidgetIndex + direction;
    [row[pageWidgetIndex], row[pageWidgetIndexToSwapWith]] = [row[pageWidgetIndexToSwapWith], row[pageWidgetIndex]];

    // Update row and column indices
    this.updateRowAndColumnIndices();
  }

  public setPageWidgetWidth(pageWidget: PageWidget, gridColumns: number): void {
    pageWidget.gridColumns = gridColumns;

    // Update row and column indices
    this.updateRowAndColumnIndices();
  }

  public removeWidgetFromRow(rowIndex: number, pageWidgetIndex: number): void {
    // Remove
    const pageWidgetToBeRemoved: PageWidget = this.rows[rowIndex][pageWidgetIndex];
    this.rows[rowIndex].splice(pageWidgetIndex, 1);
    const index = this.pageWidgetList.findIndex(pageWidget =>
      pageWidget.id === pageWidgetToBeRemoved.id
      && pageWidget.rowIndex === pageWidgetToBeRemoved.rowIndex
      && pageWidget.columnIndex === pageWidgetToBeRemoved.columnIndex);
    this.pageWidgetList.splice(index, 1);

    // Remove row if empty and update row and column indices
    this.removeRowIfEmpty(rowIndex);
    this.updateRowAndColumnIndices();
  }

  public addWidgetAtEndOfPage(): void {
    // Update row and column indices
    this.updateRowAndColumnIndices();

    // Add
    this.widgetService.getWidget(this.selectedWidgetName).subscribe({
      next: widget => {
        const newPageWidget: PageWidget = {
          id: undefined,
          gridColumns: 4,                   // Default: maximum width
          rowIndex: this.rows.length + 1,   // Default: at the end of the page
          columnIndex: 1,                   // Default: starts left
          page: this.page,
          widget: widget
        };
        this.pageWidgetList.push(newPageWidget);
        this.rows.push([]);
        this.rows[this.rows.length - 1].push(newPageWidget);

        // Refresh dropdown
        this.selectedWidgetName = undefined;
      }
    });
  }

  public cantMoveToRow(rowIndex: number, direction: Direction): boolean {
    const isAloneAtTheTop = rowIndex === 0 && this.rows[rowIndex].length === 1;
    const isAloneAtTheBottom = rowIndex === this.rows.length - 1 && this.rows[this.rows.length - 1].length === 1;
    return (isAloneAtTheTop && direction === Direction.Up) || (isAloneAtTheBottom && direction === Direction.Down);
  }

  public cantMoveLeft(pageWidgetIndex: number, direction: Direction): boolean {
    const isFirstPageWidgetInRow = pageWidgetIndex === 0;
    return isFirstPageWidgetInRow && direction === Direction.Left;
  }

  public cantMoveRight(row: PageWidget[], pageWidgetIndex: number, direction: Direction): boolean {
    const isLastPageWidgetInRow = pageWidgetIndex === row.length - 1;
    return isLastPageWidgetInRow && direction === Direction.Right;
  }

  public isRowTooWide(row: PageWidget[]): boolean {
    return row.reduce((total, pageWidget) => total + pageWidget.gridColumns, 0) > 4;
  }

  // Necessary for use of direction in html
  public get direction(): typeof Direction {
    return Direction;
  }

  private removeRowIfEmpty(rowIndex: number) {
    if (this.rows[rowIndex].length === 0) {
      this.rows.splice(rowIndex, 1);
    }
  }

  private updateRowAndColumnIndices() {
    this.rows.forEach((row, rowIndex) => {
      let newColumnIndex: number;
      row.forEach((pageWidget, pageWidgetIndex) => {
        pageWidget.rowIndex = rowIndex + 1;
        newColumnIndex = pageWidgetIndex === 0 ? 1 : newColumnIndex + this.rows[rowIndex][pageWidgetIndex - 1].gridColumns;
        pageWidget.columnIndex = newColumnIndex;
      });
    });
  }

  private getPageInfoAndInitializeData(): void {
    this.pageService.getPageLayout(this.pageKey).subscribe({
      next: pageLayoutDto => {
        this.changePageWizardService.wizardData.pageLayoutDto = pageLayoutDto;
        this.initializeData();
      }
    });
  }

  private initializeData() {
    this.page = this.changePageWizardService.wizardData.pageLayoutDto.page;
    this.pageWidgetList = this.changePageWizardService.wizardData.pageLayoutDto.widgets;
    this.transformPageWidgetsIntoRows();
    this.updateRowAndColumnIndices();
  }

  private transformPageWidgetsIntoRows(): void {
    _.sortBy(this.pageWidgetList, ['rowIndex', 'columnIndex']);
    this.pageWidgetList.forEach(pageWidget => {
      if (!this.rows[pageWidget.rowIndex - 1]) {
        this.rows[pageWidget.rowIndex - 1] = [];
      }
      this.rows[pageWidget.rowIndex - 1].push(pageWidget);
    });
    this.rows = this.rows.filter(() => true); // Remove 'holes' in array (due to settings in configuration file)
  }

  private getWidgetNamesForDomainAndGeneric() {
    this.widgetService.getWidgetNamesForDomainAndGeneric().subscribe({
      next: widgetNames => {
        this.widgetNames = widgetNames ? widgetNames.map(widgetName => ({label: widgetName, value: widgetName})) : [];
      }
    });
  }

  isStepValid(): void {
    this.changePageWizardService.isCurrentStepValid = !this.rows.some(row => this.isRowTooWide(row));
  }

}
