import {Component, OnDestroy, OnInit} from '@angular/core';
import {PageService} from 'src/app/services/page.service';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {ChangePageWizardService} from '../../change-page-wizard.service';
import {SelectItem} from '../../../../common/select-item';
import {Subscription} from 'rxjs';

@Component({
  selector: 'c-change-page-selection-step',
  templateUrl: './change-page-selection-step.component.html',
  styleUrls: ['./change-page-selection-step.component.scss']
})
export class ChangePageSelectionStepComponent extends AbstractWizardStep implements OnInit, OnDestroy {

  public pageSelectItems: SelectItem[] = [];
  public selectedPageKey: string;
  private subscription: Subscription;

  constructor(private readonly pageService: PageService,
              private changePageWizardService: ChangePageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.selectedPageKey = this.changePageWizardService.wizardData.pageKey;
    this.getPageKeysForDomain();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onSelectedPageKeyChange(): void {
    this.changePageWizardService.initializeWizard();
    this.changePageWizardService.wizardData.pageKey = this.selectedPageKey;
  }

  public isStepValid(): void {
    this.changePageWizardService.isCurrentStepValid =
      this.selectedPageKey !== ''
      && this.selectedPageKey !== undefined
      && this.selectedPageKey !== null;
  }

  private getPageKeysForDomain(): void {
    this.subscription = this.pageService.getPageKeysForDomain().subscribe({
      next: pageKeys => {
        this.pageSelectItems = pageKeys ? pageKeys.map(pageKey => ({label: pageKey, value: pageKey})) : [];
        if (this.hasDomainChangeTakenPlace(pageKeys)) {
          this.initializeDataOnDomainChange();
        }
      }
    });
  }

  private hasDomainChangeTakenPlace(pageKeys: string[]) {
    return this.selectedPageKey && !pageKeys.includes(this.selectedPageKey);
  }

  private initializeDataOnDomainChange(): void {
    this.changePageWizardService.initializeWizard();
    this.selectedPageKey = this.changePageWizardService.wizardData.pageKey;
  }

}
