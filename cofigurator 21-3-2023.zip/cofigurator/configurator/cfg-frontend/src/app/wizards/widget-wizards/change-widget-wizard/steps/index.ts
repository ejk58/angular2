import {ChangeWidgetSelectionStepComponent} from './change-widget-selection-step/change-widget-selection-step.component';
import {ChangeWidgetCreationStepComponent} from './change-widget-creation-step/change-widget-creation-step.component';
import {ChangeQueryCreationStepComponent} from './change-query-creation-step/change-query-creation-step.component';

export const list = [
  ChangeWidgetSelectionStepComponent,
  ChangeWidgetCreationStepComponent,
  ChangeQueryCreationStepComponent
];
