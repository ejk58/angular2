import {Execution} from '../../domain/execution/execution';
import {Release} from '../../generated/models';

export interface RollbackReleaseWizardData {
  environment: string;
  currentRelease: Release;
  execution: Execution;
}

