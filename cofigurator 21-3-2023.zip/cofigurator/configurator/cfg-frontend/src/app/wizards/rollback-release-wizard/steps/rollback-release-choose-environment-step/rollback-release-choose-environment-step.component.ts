import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {EnvironmentService} from '../../../../services/environment.service';
import {SelectItem} from '../../../../common/select-item';
import {RollbackReleaseWizardService} from '../../rollback-release-wizard.service';

@Component({
  selector: 'c-rollback-release-choose-environment-step',
  templateUrl: './rollback-release-choose-environment-step.component.html',
  styleUrls: ['./rollback-release-choose-environment-step.component.scss']
})

export class RollbackReleaseChooseEnvironmentStepComponent extends AbstractWizardStep implements OnInit {

  public environments: SelectItem[] = [];
  public selectedEnvironment: string;

  constructor(private rollbackReleaseWizardService: RollbackReleaseWizardService,
              private environmentService: EnvironmentService) {
    super();
  }

  ngOnInit(): void {
    this.selectedEnvironment = this.rollbackReleaseWizardService.wizardData.environment;
    this.getEnvironments();
  }

  onSelectedEnvironment(): void {
    this.rollbackReleaseWizardService.initializeWizard();
    this.rollbackReleaseWizardService.wizardData.environment = this.selectedEnvironment;
  }

  private getEnvironments() {
    this.environmentService.getEnvironments().subscribe({
      next: environments => {
        this.environments = environments ? environments.map(environment => ({label: environment.name, value: environment.name})) : [];
      }
    });
  }

  isStepValid(): void {
    this.rollbackReleaseWizardService.isCurrentStepValid = this.selectedEnvironment != null;
  }

}
