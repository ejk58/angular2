import {Component, OnDestroy, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {Release} from '../../../../generated/models';
import {ReleaseService} from 'src/app/services/release.service';
import {Subscription} from 'rxjs';
import {RollbackReleaseWizardService} from '../../rollback-release-wizard.service';

@Component({
  selector: 'c-rollback-release-choose-release-step',
  templateUrl: './rollback-release-choose-release-step.component.html',
  styleUrls: ['./rollback-release-choose-release-step.component.scss']
})

export class RollbackReleaseChooseReleaseStepComponent extends AbstractWizardStep implements OnInit, OnDestroy {

  public selectedEnvironment: string;
  public currentRelease: Release;
  public isChecked: boolean;
  private subscription: Subscription;

  constructor(private readonly rollbackReleaseWizardService: RollbackReleaseWizardService,
              private readonly releaseService: ReleaseService) {
    super();
  }

  ngOnInit(): void {
    this.selectedEnvironment = this.rollbackReleaseWizardService.wizardData.environment;
    this.getCurrentReleaseForDomain();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private getCurrentReleaseForDomain(): void {
    this.subscription = this.releaseService.getCurrentReleaseForDomain(this.selectedEnvironment).subscribe({
      next: currentRelease => {
        this.rollbackReleaseWizardService.wizardData.currentRelease = currentRelease;
        this.initializeData();
      }
    });
  }

  private initializeData() {
    this.currentRelease = this.rollbackReleaseWizardService.wizardData.currentRelease;
  }

  isStepValid(): void {
    this.rollbackReleaseWizardService.isCurrentStepValid = this.isChecked;
  }

}
