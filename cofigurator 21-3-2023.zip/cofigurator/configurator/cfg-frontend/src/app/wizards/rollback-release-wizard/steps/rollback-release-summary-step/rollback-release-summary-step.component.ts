import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {Release} from '../../../../generated/models';
import {ReleaseService} from 'src/app/services/release.service';
import {Observable} from 'rxjs';
import {TableColumn} from '../../../../domain/table/table-column';
import {TableData} from '../../../../domain/table/table-data';
import {DateTimePipe} from '../../../../components/pipes/date-time.pipe';
import {RollbackReleaseWizardService} from '../../rollback-release-wizard.service';

@Component({
  selector: 'c-rollback-release-summary-step',
  templateUrl: './rollback-release-summary-step.component.html',
  styleUrls: ['./rollback-release-summary-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: RollbackReleaseSummaryStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class RollbackReleaseSummaryStepComponent extends AbstractWizardStep implements OnInit {

  public summaryTableTitle: string;
  public summaryTableCols: TableColumn[];
  public rollbackReleaseData: TableData[];

  constructor(private readonly rollbackReleaseWizardService: RollbackReleaseWizardService,
              private readonly releaseService: ReleaseService,
              private readonly dateTimePipe: DateTimePipe) {
    super();
  }

  ngOnInit(): void {
    this.setDataForRollbackReleaseTable();
  }

  public executeChanges(): Observable<string> {
    return this.releaseService.rollback(this.rollbackReleaseWizardService.wizardData);
  }

  public isStepValid(): void {
    this.rollbackReleaseWizardService.isCurrentStepValid = true;
  }

  private setDataForRollbackReleaseTable(): void {
    const environment: string = this.rollbackReleaseWizardService.wizardData.environment;
    const rollbackRelease: Release = this.rollbackReleaseWizardService.wizardData.currentRelease;

    this.summaryTableTitle = 'Weet u zeker dat u onderstaande release wilt terugdraaien op "' + environment + '"?';
    this.summaryTableCols = [{field: 'label', header: 'Release'}, {field: 'value', header: 'Waarde'}];
    this.rollbackReleaseData = [
      {label: 'Klantbeeld', value: rollbackRelease.domainKey},
      {label: 'Naam', value: rollbackRelease.tag},
      {label: 'Gemaakt op', value: this.dateTimePipe.transform(rollbackRelease.date)},
      {label: 'Door', value: rollbackRelease.administrator}
    ];
  }

}
