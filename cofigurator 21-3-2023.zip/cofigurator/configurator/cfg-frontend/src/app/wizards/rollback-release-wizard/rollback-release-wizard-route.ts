import {WizardRoute} from '../../domain/wizard/wizard-route';

export class RollbackReleaseWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when RollbackReleaseWizardService is used in RollbackReleaseWizardRouteConfig.
}
