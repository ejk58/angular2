import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {DeleteReleaseWizardRoute} from './delete-release-wizard-route';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {DeleteReleaseWizardData} from './delete-release-wizard-data';
import {Execution} from '../../domain/execution/execution';

@Injectable()
export class DeleteReleaseWizardService extends AbstractWizardService<DeleteReleaseWizardData> {

  constructor(private readonly deleteReleaseWizardRoute: DeleteReleaseWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(deleteReleaseWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {release: undefined, execution};
  }

}
