import {Release} from '../../generated/models';
import {Execution} from '../../domain/execution/execution';

export interface DeleteReleaseWizardData {
  release: Release;
  execution: Execution;
}
