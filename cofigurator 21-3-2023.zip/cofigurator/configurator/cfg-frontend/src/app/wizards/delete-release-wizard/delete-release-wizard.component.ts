import {Component, OnInit} from '@angular/core';
import {DeleteReleaseWizardService} from './delete-release-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {DeleteReleaseWizardRoute} from './delete-release-wizard-route';
import {SpinnerService} from '../../services/spinner.service';

@Component({
  selector: 'c-delete-release-wizard',
  templateUrl: './delete-release-wizard.component.html',
  styleUrls: ['./delete-release-wizard.component.scss']
})
export class DeleteReleaseWizardComponent extends AbstractWizard implements OnInit {

  constructor(public deleteReleaseWizardService: DeleteReleaseWizardService,
              private readonly spinnerService: SpinnerService,
              private readonly deleteReleaseWizardRoute: DeleteReleaseWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(deleteReleaseWizardService, spinnerService, deleteReleaseWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.deleteReleaseWizardService.initializeWizard();
  }

}
