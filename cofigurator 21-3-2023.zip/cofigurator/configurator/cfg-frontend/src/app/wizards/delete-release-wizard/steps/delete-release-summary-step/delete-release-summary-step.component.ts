import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {DeleteReleaseWizardService} from '../../delete-release-wizard.service';
import {ReleaseService} from '../../../../services/release.service';
import {Observable} from 'rxjs';
import {Release} from '../../../../generated/models';
import {TableColumn} from '../../../../domain/table/table-column';
import {TableData} from '../../../../domain/table/table-data';
import {DateTimePipe} from '../../../../components/pipes/date-time.pipe';

@Component({
  selector: 'c-delete-release-summary-step',
  templateUrl: './delete-release-summary-step.component.html',
  styleUrls: ['./delete-release-summary-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: DeleteReleaseSummaryStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class DeleteReleaseSummaryStepComponent extends AbstractWizardStep implements OnInit {

  public summaryTableTitle: string;
  public summaryTableCols: TableColumn[];
  public deleteReleaseData: TableData[];

  constructor(private readonly deleteReleaseWizardService: DeleteReleaseWizardService,
              private readonly releaseService: ReleaseService,
              private readonly dateTimePipe: DateTimePipe) {
    super();
  }

  ngOnInit(): void {
    this.setDataForDeleteReleaseTable();
  }

  public executeChanges(): Observable<string> {
    return this.releaseService.delete(this.deleteReleaseWizardService.wizardData.release.id);
  }

  isStepValid(): void {
    this.deleteReleaseWizardService.isCurrentStepValid = true;
  }

  private setDataForDeleteReleaseTable(): void {
    const deleteRelease: Release = this.deleteReleaseWizardService.wizardData.release;

    this.summaryTableTitle = 'Weet u zeker dat u onderstaande release wilt verwijderen?';
    this.summaryTableCols = [{field: 'label', header: 'Release'}, {field: 'value', header: 'Waarde'}];
    this.deleteReleaseData = [
      {label: 'Klantbeeld', value: deleteRelease.domainKey},
      {label: 'Naam', value: deleteRelease.tag},
      {label: 'Gemaakt op', value: this.dateTimePipe.transform(deleteRelease.date)},
      {label: 'Door', value: deleteRelease.administrator}
    ];
  }

}
