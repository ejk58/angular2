export enum ExecutionStatus {
  Success = 0,
  Failure = 1
}
