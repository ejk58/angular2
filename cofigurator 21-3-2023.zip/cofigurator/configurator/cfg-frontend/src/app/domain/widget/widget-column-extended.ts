import {WidgetColumn} from '../../generated/models';

export interface WidgetColumnExtended extends WidgetColumn {
  unique?: number;
}
