import {QueryColumnExtended} from '../query/query-column-extended';
import {WidgetColumnExtended} from '../widget/widget-column-extended';

export class WidgetAndQueryColumnExtended {
  public id: number;
  public queryColumnExtended: QueryColumnExtended;
  public widgetColumnExtended: WidgetColumnExtended;
  public unique?: number;
}
