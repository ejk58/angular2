export enum Direction {
  Up = -1,
  Down = 1,
  Left = -1,
  Right = 1
}
