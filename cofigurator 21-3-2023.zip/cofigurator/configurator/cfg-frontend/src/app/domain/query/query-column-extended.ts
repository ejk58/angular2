import {QueryColumn} from '../../generated/models';

export interface QueryColumnExtended extends QueryColumn {
  mandatory?: boolean;
  unique?: number;
  expand?: boolean;
}
