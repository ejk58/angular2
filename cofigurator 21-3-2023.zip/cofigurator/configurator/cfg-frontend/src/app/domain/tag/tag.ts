export interface Tag {
  tag: string,
  isUnique: boolean
}
