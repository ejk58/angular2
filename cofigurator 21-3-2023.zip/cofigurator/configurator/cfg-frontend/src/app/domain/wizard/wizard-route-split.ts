import {WizardRouteSection} from './wizard-route-section';

export class WizardRouteSplit {

  private readonly belongsToRouteSectionLocal: WizardRouteSection;
  private readonly splitFunctionLocal: () => WizardRouteSection;

  constructor(belongsToRouteSection: WizardRouteSection, splitFunction: () => WizardRouteSection) {
    this.belongsToRouteSectionLocal = belongsToRouteSection;
    this.splitFunctionLocal = splitFunction;
  }

  get belongsToRouteSection(): WizardRouteSection {
    return this.belongsToRouteSectionLocal;
  }

  public goesToRouteSection(): WizardRouteSection {
    return this.splitFunctionLocal();
  }

}
