import {WizardData} from './wizard-data';
import * as _ from 'lodash-es';
import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';

@Injectable()
export class WizardStore {

  // Made 'public readonly' instead of 'private readonly' because of showing data as JSON
  public readonly wizardDataLocal: Map<string, WizardData> = new Map<string, WizardData>();

  private isCurrentStepFirstStepLocal$: BehaviorSubject<boolean> = new BehaviorSubject(false);

  /**
   * Saves the specified data for the specified wizard.
   *
   * @param wizardName name of the wizard to which the data belongs
   * @param wizardData data to save
   */
  public saveDataForWizard(wizardName: string, wizardData: WizardData): void {
    this.wizardDataLocal.set(wizardName, _.cloneDeep(wizardData) as WizardData);
  }

  /**
   * Returns data for the next or previous step in the wizard-route.
   *
   * @param wizardName name of the wizard to which the data belongs
   */
  public getDataForWizard(wizardName: string): WizardData {
    return _.cloneDeep(this.wizardDataLocal.get(wizardName));
  }

  /**
   * Deletes the data for the specified wizard.
   *
   * @param wizardName name of the wizard for which the data has to be deleted
   */
  public resetDataForWizard(wizardName: string): void {
    this.wizardDataLocal.delete(wizardName);
  }

  /**
   * Returns BehaviorSubject 'isCurrentStepFirstStepLocal$' as Observable.
   */
  get isCurrentStepFirstStep$(): Observable<boolean> {
    return this.isCurrentStepFirstStepLocal$.asObservable();
  }

  /**
   * Broadcast new value for isCurrentStepFirstStep.
   *
   * @param isCurrentStepFirstStep 'true' if current step in wizard is first step, else 'false'
   */
  public broadcastIsCurrentStepFirstStep(isCurrentStepFirstStep: boolean): void {
    this.isCurrentStepFirstStepLocal$.next(isCurrentStepFirstStep);
  }

}
