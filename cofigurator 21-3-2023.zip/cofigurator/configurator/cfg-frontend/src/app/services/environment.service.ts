import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {Environment} from '../generated/models';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class EnvironmentService {

  private readonly environmentUrl = 'api/environment';

  constructor(private readonly http: HttpClient) { }

  getEnvironments(): Observable<Environment[]> {
    return this.http.get<Environment[]>(`${this.environmentUrl}`);
  }

}
