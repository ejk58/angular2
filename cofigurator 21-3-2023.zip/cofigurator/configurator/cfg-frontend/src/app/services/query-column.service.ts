import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable()
export class QueryColumnService {
  private queryColumnUrl = 'api/querycolumn';

  constructor(private http: HttpClient) { }


  getQueryColumnTypes = (): Observable<Array<string>> => {
    return this.http.get<Array<string>>(`${this.queryColumnUrl}/types`);
  };
}
