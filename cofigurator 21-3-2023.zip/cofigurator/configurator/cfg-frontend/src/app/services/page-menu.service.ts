import {Injectable} from '@angular/core';
import {Router} from '@angular/router';

@Injectable()
export class PageMenuService {

  public pageMenu: any[] = [
    {title: 'Widget', options: [{label: 'Nieuw widget', key: ''}, {label: 'Widget aanpassen', key: 'changeWidget'}]},
    {title: 'Pagina', options: [{label: 'Nieuwe pagina', key: 'newPage'}, {label: 'Pagina aanpassen', key: 'changePage'}]},
    {title: 'Change', options: [{label: 'Change verwijderen', key: 'deleteChange'}]},
    {
      title: 'Release',
      options: [{label: 'Nieuwe release', key: 'newRelease'},
        {label: 'Release uitrollen', key: 'deployRelease'},
        {label: 'Release terugdraaien', key: 'rollbackRelease'},
        {label: 'Release verwijderen', key: 'deleteRelease'}
      ]
    },
    {title: 'Configuratie', options: [{label: 'Klantbeeld exporteren', key: 'exportDomain'}]},
    {title: 'Robot', options: [{label: 'Testopzet maken', key: 'robot'}]},
    {title: 'Overzichten', options: [{label: 'Overzicht changes', key: 'changeOverview'}, {label: 'Overzicht deployments', key: 'releaseOverview'}]}
  ];

  constructor(private readonly router: Router) {
  }

  getPageMenuItems(): any {
    return this.pageMenu;
  }

  getCurrentMenuLabel(): string {
    const key = this.router.url.substring(1);
    let menuItem: string = '';
    this.pageMenu.forEach(mainMenu => {
      const result = (mainMenu.options.filter(item => item.key === key));
      if (result.length > 0) {
        menuItem = result[0]['label'];
      }
    });
    return menuItem;
  }

}
