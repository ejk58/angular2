import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {map, switchMap} from 'rxjs/operators';
import {DomainService} from './domain.service';
import {NewReleaseWizardData} from '../wizards/new-release-wizard/new-release-wizard-data';
import {DeployReleaseWizardData} from '../wizards/deploy-release-wizard/deploy-release-wizard-data';
import {Release, ReleaseEnvironment, ReleaseRolloutInfo} from '../generated/models';
import {RollbackReleaseWizardData} from '../wizards/rollback-release-wizard/rollback-release-wizard-data';

@Injectable()
export class ReleaseService {

  private readonly releaseUrl = 'api/release';

  constructor(private readonly http: HttpClient, private readonly domainService: DomainService) {
  }

  getReleasesDeployed(): Observable<ReleaseEnvironment[]> {
    return this.http.get<ReleaseEnvironment[]>(`${this.releaseUrl}/deployed`);
  }

  getReleasesNotDeployedForDomain(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string[]>(`${this.releaseUrl}/notDeployed/${domain.domainId}`)
              .pipe(map(releases => releases ? releases : undefined));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getAllReleaseTags(): Observable<string[]> {
    return this.http.get<string[]>(`${this.releaseUrl}/allReleaseTags`);
  }

  getRolloutInfoForDomain(environment: string): Observable<ReleaseRolloutInfo> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<ReleaseRolloutInfo>(`${this.releaseUrl}/rolloutInfo/${environment}/${domain.domainId}`)
              .pipe(map(releaseRolloutInfo => releaseRolloutInfo ? releaseRolloutInfo : undefined));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getCurrentReleaseForDomain(environment: string): Observable<Release> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<Release>(`${this.releaseUrl}/currentRelease/${environment}/${domain.domainId}`)
              .pipe(map(release => release ? release : undefined));
          } else {
            return of(undefined);
          }
        })
      );
  }

  save(releaseAndChanges: NewReleaseWizardData): Observable<string> {
    const releaseAndChangesWithDomain = {...releaseAndChanges, applicationDomain: this.domainService.activeDomain};
    return this.http.post(`${this.releaseUrl}/save`, releaseAndChangesWithDomain, {responseType: 'text'});
  }

  delete(releaseId: number): Observable<string> {
    return this.http.delete(`${this.releaseUrl}/delete/${releaseId}`, {responseType: 'text'});
  }

  rollout(deployReleaseWizardData: DeployReleaseWizardData): Observable<string> {
    const dataWithDomain = {...deployReleaseWizardData, applicationDomain: this.domainService.activeDomain};
    return this.http.post(`${this.releaseUrl}/rollout`, dataWithDomain, {responseType: 'text'});
  }

  rollback(rollbackReleaseWizardData: RollbackReleaseWizardData): Observable<string> {
    const dataWithDomain = {...rollbackReleaseWizardData, applicationDomain: this.domainService.activeDomain};
    return this.http.post(`${this.releaseUrl}/rollback`, dataWithDomain, {responseType: 'text'});
  }

}
