import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {QueryType} from '../wizards/widget-wizards/components/query-types/query-types.interface';

@Injectable()
export class DatasourceService {

  private readonly datasourcesUrl = '/api/datasources';

  constructor(private readonly http: HttpClient) { }

  getDatasourceViews(): Observable<any> {
    return this.http.get(this.datasourcesUrl + '/views');
  }

  getViewColumns(viewName: string): Observable<string[]> {
    return this.http.get<string[]>(this.datasourcesUrl + '/columns/' + viewName);
  }

  getQueryValidation(queryTemplate: string): Observable<string> {
    return this.http.get(this.datasourcesUrl + '/validate/' + queryTemplate, {responseType: 'text'});
  }

  getQueryTypes(): Observable<Array<QueryType>> {
    return this.http.get<Array<QueryType>>(this.datasourcesUrl + '/types', {
      observe: 'body'
    });
  }
}
