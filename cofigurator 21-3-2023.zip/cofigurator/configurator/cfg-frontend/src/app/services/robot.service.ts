import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {RobotTestsDto} from '../generated/models/robot-tests-dto';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class RobotService {

  private readonly robotUrl = 'api/robot';

  constructor(private readonly http: HttpClient) {
  }

  exportRobotScript(robotTestsDto: RobotTestsDto): Observable<string> {
    return this.http.post(`${this.robotUrl}/export`, robotTestsDto, {responseType: 'text'});
  }

}
