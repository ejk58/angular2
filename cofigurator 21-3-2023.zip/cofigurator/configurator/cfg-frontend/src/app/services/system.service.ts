import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {VersionDto} from '../generated/models';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class SystemService {

  private readonly systemUrl = 'api/system';

  constructor(private readonly http: HttpClient) { }

  getVersion(): Observable<VersionDto> {
    return this.http.get<VersionDto>(`${this.systemUrl}/version`);
  }
}
