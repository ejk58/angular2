import {Component, OnInit} from '@angular/core';
import {ReleaseEnvironment} from '../../generated/models';
import {ReleaseService} from '../../services/release.service';

@Component({
  selector: 'c-release-overview',
  templateUrl: './release-overview.component.html',
  styleUrls: ['./release-overview.component.scss']
})
export class ReleaseOverviewComponent implements OnInit {

  public releasesDeployed: ReleaseEnvironment[] = [];

  constructor(private readonly releaseService: ReleaseService) {
  }

  ngOnInit(): void {
    this.getReleasesDeployed();
  }

  private getReleasesDeployed(): void {
    this.releaseService.getReleasesDeployed().subscribe({
      next: releasesDeployed => {
        this.releasesDeployed = releasesDeployed;
      }
    });
  }
}
