import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Clipboard} from '@angular/cdk/clipboard';
import {ChangeService} from '../../../services/change.service';
import {Change} from '../../../generated/models';

@Component({
  selector: 'c-change-overview-detail',
  templateUrl: './change-overview-detail.component.html',
  styleUrls: ['./change-overview-detail.component.scss']
})
export class ChangeOverviewDetailComponent implements OnInit {

  public change: Change;

  constructor(private readonly route: ActivatedRoute,
              private readonly router: Router,
              private readonly clipboard: Clipboard,
              private readonly changeService: ChangeService) {
  }

  ngOnInit(): void {
    this.route.params.subscribe({
      next: routeParams => {
        this.getChangeById(routeParams.changeId as number);
      }
    });
  }

  private getChangeById(changeIdFromRoute: number): void {
    this.changeService.getChange(changeIdFromRoute).subscribe({
      next: change => this.change = change
    });
  }

  public copyTextarea(changePropertyName: string): void {
    this.clipboard.copy(this.change[changePropertyName] as string);
  }

  public backToOverview(): void {
    this.router.navigate([`/changeOverview`]);
  }

}
