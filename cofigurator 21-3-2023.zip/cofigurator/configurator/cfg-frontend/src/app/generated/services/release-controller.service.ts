/* tslint:disable */
import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpHeaders } from '@angular/common/http';
import { BaseService as __BaseService } from '../base-service';
import { ApiConfiguration as __Configuration } from '../api-configuration';
import { StrictHttpResponse as __StrictHttpResponse } from '../strict-http-response';
import { Observable as __Observable } from 'rxjs';
import { map as __map, filter as __filter } from 'rxjs/operators';

import { Release } from '../models/release';
import { ReleaseEnvironment } from '../models/release-environment';
import { ReleaseRollbackDto } from '../models/release-rollback-dto';
import { ReleaseRolloutDto } from '../models/release-rollout-dto';
import { ReleaseRolloutInfo } from '../models/release-rollout-info';
import { ReleaseAndChanges } from '../models/release-and-changes';

/**
 * Release Controller
 */
@Injectable({
  providedIn: 'root',
})
class ReleaseControllerService extends __BaseService {
  static readonly getAllReleaseTagsUsingGETPath = '/api/release/allReleaseTags';
  static readonly getCurrentReleaseForEnvironmentAndDomainUsingGETPath = '/api/release/currentRelease/{environmentname}/{domainKey}';
  static readonly deleteReleaseUsingDELETEPath = '/api/release/delete/{releaseId}';
  static readonly getReleaseDeployedUsingGETPath = '/api/release/deployed';
  static readonly getReleasesNotDeployedForDomainUsingGETPath = '/api/release/notDeployed/{domainKey}';
  static readonly rollbackReleaseUsingPOSTPath = '/api/release/rollback';
  static readonly rolloutReleaseUsingPOSTPath = '/api/release/rollout';
  static readonly getReleaseRolloutInfoForEnvironmentAndDomainUsingGETPath = '/api/release/rolloutInfo/{environmentname}/{domainKey}';
  static readonly saveReleaseUsingPOSTPath = '/api/release/save';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * getAllReleaseTags
   * @return OK
   */
  getAllReleaseTagsUsingGETResponse(): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/release/allReleaseTags`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getAllReleaseTags
   * @return OK
   */
  getAllReleaseTagsUsingGET(): __Observable<Array<string>> {
    return this.getAllReleaseTagsUsingGETResponse().pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getCurrentReleaseForEnvironmentAndDomain
   * @param domainKey domainKey
   * @param environmentname environmentname
   * @return OK
   */
  getCurrentReleaseForEnvironmentAndDomainUsingGETResponse(domainKey: string,
    environmentname: string): __Observable<__StrictHttpResponse<Release>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/release/currentRelease/${encodeURIComponent(String(environmentname))}/${encodeURIComponent(String(domainKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Release>;
      })
    );
  }
  /**
   * getCurrentReleaseForEnvironmentAndDomain
   * @param domainKey domainKey
   * @param environmentname environmentname
   * @return OK
   */
  getCurrentReleaseForEnvironmentAndDomainUsingGET(domainKey: string,
    environmentname: string): __Observable<Release> {
    return this.getCurrentReleaseForEnvironmentAndDomainUsingGETResponse(domainKey, environmentname).pipe(
      __map(_r => _r.body as Release)
    );
  }

  /**
   * deleteRelease
   * @param releaseId releaseId
   * @return OK
   */
  deleteReleaseUsingDELETEResponse(releaseId: number): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'DELETE',
      this.rootUrl + `/api/release/delete/${encodeURIComponent(String(releaseId))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * deleteRelease
   * @param releaseId releaseId
   * @return OK
   */
  deleteReleaseUsingDELETE(releaseId: number): __Observable<string> {
    return this.deleteReleaseUsingDELETEResponse(releaseId).pipe(
      __map(_r => _r.body as string)
    );
  }

  /**
   * getReleaseDeployed
   * @return OK
   */
  getReleaseDeployedUsingGETResponse(): __Observable<__StrictHttpResponse<Array<ReleaseEnvironment>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/release/deployed`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<ReleaseEnvironment>>;
      })
    );
  }
  /**
   * getReleaseDeployed
   * @return OK
   */
  getReleaseDeployedUsingGET(): __Observable<Array<ReleaseEnvironment>> {
    return this.getReleaseDeployedUsingGETResponse().pipe(
      __map(_r => _r.body as Array<ReleaseEnvironment>)
    );
  }

  /**
   * getReleasesNotDeployedForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getReleasesNotDeployedForDomainUsingGETResponse(domainKey: string): __Observable<__StrictHttpResponse<Array<Release>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/release/notDeployed/${encodeURIComponent(String(domainKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<Release>>;
      })
    );
  }
  /**
   * getReleasesNotDeployedForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getReleasesNotDeployedForDomainUsingGET(domainKey: string): __Observable<Array<Release>> {
    return this.getReleasesNotDeployedForDomainUsingGETResponse(domainKey).pipe(
      __map(_r => _r.body as Array<Release>)
    );
  }

  /**
   * rollbackRelease
   * @param releaseRollbackDto releaseRollbackDto
   * @return OK
   */
  rollbackReleaseUsingPOSTResponse(releaseRollbackDto: ReleaseRollbackDto): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = releaseRollbackDto;
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/release/rollback`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * rollbackRelease
   * @param releaseRollbackDto releaseRollbackDto
   * @return OK
   */
  rollbackReleaseUsingPOST(releaseRollbackDto: ReleaseRollbackDto): __Observable<string> {
    return this.rollbackReleaseUsingPOSTResponse(releaseRollbackDto).pipe(
      __map(_r => _r.body as string)
    );
  }

  /**
   * rolloutRelease
   * @param releaseRolloutDto releaseRolloutDto
   * @return OK
   */
  rolloutReleaseUsingPOSTResponse(releaseRolloutDto: ReleaseRolloutDto): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = releaseRolloutDto;
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/release/rollout`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * rolloutRelease
   * @param releaseRolloutDto releaseRolloutDto
   * @return OK
   */
  rolloutReleaseUsingPOST(releaseRolloutDto: ReleaseRolloutDto): __Observable<string> {
    return this.rolloutReleaseUsingPOSTResponse(releaseRolloutDto).pipe(
      __map(_r => _r.body as string)
    );
  }

  /**
   * getReleaseRolloutInfoForEnvironmentAndDomain
   * @param domainKey domainKey
   * @param environmentname environmentname
   * @return OK
   */
  getReleaseRolloutInfoForEnvironmentAndDomainUsingGETResponse(domainKey: string,
    environmentname: string): __Observable<__StrictHttpResponse<ReleaseRolloutInfo>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/release/rolloutInfo/${encodeURIComponent(String(environmentname))}/${encodeURIComponent(String(domainKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<ReleaseRolloutInfo>;
      })
    );
  }
  /**
   * getReleaseRolloutInfoForEnvironmentAndDomain
   * @param domainKey domainKey
   * @param environmentname environmentname
   * @return OK
   */
  getReleaseRolloutInfoForEnvironmentAndDomainUsingGET(domainKey: string,
    environmentname: string): __Observable<ReleaseRolloutInfo> {
    return this.getReleaseRolloutInfoForEnvironmentAndDomainUsingGETResponse(domainKey, environmentname).pipe(
      __map(_r => _r.body as ReleaseRolloutInfo)
    );
  }

  /**
   * saveRelease
   * @param releaseAndChanges releaseAndChanges
   * @return OK
   */
  saveReleaseUsingPOSTResponse(releaseAndChanges: ReleaseAndChanges): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = releaseAndChanges;
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/release/save`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * saveRelease
   * @param releaseAndChanges releaseAndChanges
   * @return OK
   */
  saveReleaseUsingPOST(releaseAndChanges: ReleaseAndChanges): __Observable<string> {
    return this.saveReleaseUsingPOSTResponse(releaseAndChanges).pipe(
      __map(_r => _r.body as string)
    );
  }
}

module ReleaseControllerService {
}

export { ReleaseControllerService }
