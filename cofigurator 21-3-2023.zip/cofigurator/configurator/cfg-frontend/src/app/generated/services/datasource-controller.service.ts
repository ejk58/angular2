/* tslint:disable */
import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpHeaders } from '@angular/common/http';
import { BaseService as __BaseService } from '../base-service';
import { ApiConfiguration as __Configuration } from '../api-configuration';
import { StrictHttpResponse as __StrictHttpResponse } from '../strict-http-response';
import { Observable as __Observable } from 'rxjs';
import { map as __map, filter as __filter } from 'rxjs/operators';

import { Datasource } from '../models/datasource';
import { DatasourceViewDto } from '../models/datasource-view-dto';

/**
 * Datasource Controller
 */
@Injectable({
  providedIn: 'root',
})
class DatasourceControllerService extends __BaseService {
  static readonly getTDViewColumnsUsingGETPath = '/api/datasources/columns/{viewName}';
  static readonly getDatasourceTypesUsingGETPath = '/api/datasources/types';
  static readonly getTDQueryValidationUsingGETPath = '/api/datasources/validate/{queryTemplate}';
  static readonly getTDViewRecordsUsingGETPath = '/api/datasources/views';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * getTDViewColumns
   * @param viewName viewName
   * @return OK
   */
  getTDViewColumnsUsingGETResponse(viewName: string): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/datasources/columns/${encodeURIComponent(String(viewName))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getTDViewColumns
   * @param viewName viewName
   * @return OK
   */
  getTDViewColumnsUsingGET(viewName: string): __Observable<Array<string>> {
    return this.getTDViewColumnsUsingGETResponse(viewName).pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getDatasourceTypes
   * @return OK
   */
  getDatasourceTypesUsingGETResponse(): __Observable<__StrictHttpResponse<Array<Datasource>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/datasources/types`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<Datasource>>;
      })
    );
  }
  /**
   * getDatasourceTypes
   * @return OK
   */
  getDatasourceTypesUsingGET(): __Observable<Array<Datasource>> {
    return this.getDatasourceTypesUsingGETResponse().pipe(
      __map(_r => _r.body as Array<Datasource>)
    );
  }

  /**
   * getTDQueryValidation
   * @param queryTemplate queryTemplate
   * @return OK
   */
  getTDQueryValidationUsingGETResponse(queryTemplate: string): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/datasources/validate/${encodeURIComponent(String(queryTemplate))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * getTDQueryValidation
   * @param queryTemplate queryTemplate
   * @return OK
   */
  getTDQueryValidationUsingGET(queryTemplate: string): __Observable<string> {
    return this.getTDQueryValidationUsingGETResponse(queryTemplate).pipe(
      __map(_r => _r.body as string)
    );
  }

  /**
   * getTDViewRecords
   * @return OK
   */
  getTDViewRecordsUsingGETResponse(): __Observable<__StrictHttpResponse<Array<DatasourceViewDto>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/datasources/views`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<DatasourceViewDto>>;
      })
    );
  }
  /**
   * getTDViewRecords
   * @return OK
   */
  getTDViewRecordsUsingGET(): __Observable<Array<DatasourceViewDto>> {
    return this.getTDViewRecordsUsingGETResponse().pipe(
      __map(_r => _r.body as Array<DatasourceViewDto>)
    );
  }
}

module DatasourceControllerService {
}

export { DatasourceControllerService }
