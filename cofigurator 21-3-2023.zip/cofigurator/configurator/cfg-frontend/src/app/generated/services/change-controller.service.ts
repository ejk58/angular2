/* tslint:disable */
import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpHeaders } from '@angular/common/http';
import { BaseService as __BaseService } from '../base-service';
import { ApiConfiguration as __Configuration } from '../api-configuration';
import { StrictHttpResponse as __StrictHttpResponse } from '../strict-http-response';
import { Observable as __Observable } from 'rxjs';
import { map as __map, filter as __filter } from 'rxjs/operators';

import { Change } from '../models/change';
import { ChangeReleaseEnvironment } from '../models/change-release-environment';

/**
 * Change Controller
 */
@Injectable({
  providedIn: 'root',
})
class ChangeControllerService extends __BaseService {
  static readonly getAllChangeTagsUsingGETPath = '/api/change/allChangeTags';
  static readonly getChangesForDomainUsingGETPath = '/api/change/changes/{domainKey}';
  static readonly deleteChangeUsingDELETEPath = '/api/change/delete/{changeId}';
  static readonly getMostRecentChangeForDomainUsingGETPath = '/api/change/mostRecent/{domainKey}';
  static readonly getChangesOverviewUsingGETPath = '/api/change/overview';
  static readonly getChangeUsingGETPath = '/api/change/{changeId}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * getAllChangeTags
   * @return OK
   */
  getAllChangeTagsUsingGETResponse(): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/change/allChangeTags`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getAllChangeTags
   * @return OK
   */
  getAllChangeTagsUsingGET(): __Observable<Array<string>> {
    return this.getAllChangeTagsUsingGETResponse().pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getChangesForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getChangesForDomainUsingGETResponse(domainKey: string): __Observable<__StrictHttpResponse<Array<Change>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/change/changes/${encodeURIComponent(String(domainKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<Change>>;
      })
    );
  }
  /**
   * getChangesForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getChangesForDomainUsingGET(domainKey: string): __Observable<Array<Change>> {
    return this.getChangesForDomainUsingGETResponse(domainKey).pipe(
      __map(_r => _r.body as Array<Change>)
    );
  }

  /**
   * deleteChange
   * @param changeId changeId
   * @return OK
   */
  deleteChangeUsingDELETEResponse(changeId: number): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'DELETE',
      this.rootUrl + `/api/change/delete/${encodeURIComponent(String(changeId))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * deleteChange
   * @param changeId changeId
   * @return OK
   */
  deleteChangeUsingDELETE(changeId: number): __Observable<string> {
    return this.deleteChangeUsingDELETEResponse(changeId).pipe(
      __map(_r => _r.body as string)
    );
  }

  /**
   * getMostRecentChangeForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getMostRecentChangeForDomainUsingGETResponse(domainKey: string): __Observable<__StrictHttpResponse<Change>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/change/mostRecent/${encodeURIComponent(String(domainKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Change>;
      })
    );
  }
  /**
   * getMostRecentChangeForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getMostRecentChangeForDomainUsingGET(domainKey: string): __Observable<Change> {
    return this.getMostRecentChangeForDomainUsingGETResponse(domainKey).pipe(
      __map(_r => _r.body as Change)
    );
  }

  /**
   * getChangesOverview
   * @return OK
   */
  getChangesOverviewUsingGETResponse(): __Observable<__StrictHttpResponse<Array<ChangeReleaseEnvironment>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/change/overview`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<ChangeReleaseEnvironment>>;
      })
    );
  }
  /**
   * getChangesOverview
   * @return OK
   */
  getChangesOverviewUsingGET(): __Observable<Array<ChangeReleaseEnvironment>> {
    return this.getChangesOverviewUsingGETResponse().pipe(
      __map(_r => _r.body as Array<ChangeReleaseEnvironment>)
    );
  }

  /**
   * getChange
   * @param changeId changeId
   * @return OK
   */
  getChangeUsingGETResponse(changeId: number): __Observable<__StrictHttpResponse<Change>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/change/${encodeURIComponent(String(changeId))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Change>;
      })
    );
  }
  /**
   * getChange
   * @param changeId changeId
   * @return OK
   */
  getChangeUsingGET(changeId: number): __Observable<Change> {
    return this.getChangeUsingGETResponse(changeId).pipe(
      __map(_r => _r.body as Change)
    );
  }
}

module ChangeControllerService {
}

export { ChangeControllerService }
