/* tslint:disable */
import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpHeaders } from '@angular/common/http';
import { BaseService as __BaseService } from '../base-service';
import { ApiConfiguration as __Configuration } from '../api-configuration';
import { StrictHttpResponse as __StrictHttpResponse } from '../strict-http-response';
import { Observable as __Observable } from 'rxjs';
import { map as __map, filter as __filter } from 'rxjs/operators';

import { PageLayoutDto } from '../models/page-layout-dto';
import { PageDto } from '../models/page-dto';

/**
 * Page Controller
 */
@Injectable({
  providedIn: 'root',
})
class PageControllerService extends __BaseService {
  static readonly changePageLayoutUsingPOSTPath = '/api/page/changeLayout';
  static readonly getAllPageKeysUsingGETPath = '/api/page/keys';
  static readonly getPageKeysForDomainUsingGETPath = '/api/page/keys/{domainKey}';
  static readonly getPageLayoutUsingGETPath = '/api/page/layout/{pageKey}';
  static readonly newPageUsingPOSTPath = '/api/page/new';
  static readonly getPageUsingGETPath = '/api/page/{pageKey}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * changePageLayout
   * @param pageLayoutDto pageLayoutDto
   * @return OK
   */
  changePageLayoutUsingPOSTResponse(pageLayoutDto: PageLayoutDto): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = pageLayoutDto;
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/page/changeLayout`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * changePageLayout
   * @param pageLayoutDto pageLayoutDto
   * @return OK
   */
  changePageLayoutUsingPOST(pageLayoutDto: PageLayoutDto): __Observable<string> {
    return this.changePageLayoutUsingPOSTResponse(pageLayoutDto).pipe(
      __map(_r => _r.body as string)
    );
  }

  /**
   * getAllPageKeys
   * @return OK
   */
  getAllPageKeysUsingGETResponse(): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/page/keys`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getAllPageKeys
   * @return OK
   */
  getAllPageKeysUsingGET(): __Observable<Array<string>> {
    return this.getAllPageKeysUsingGETResponse().pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getPageKeysForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getPageKeysForDomainUsingGETResponse(domainKey: string): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/page/keys/${encodeURIComponent(String(domainKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getPageKeysForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getPageKeysForDomainUsingGET(domainKey: string): __Observable<Array<string>> {
    return this.getPageKeysForDomainUsingGETResponse(domainKey).pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getPageLayout
   * @param pageKey pageKey
   * @return OK
   */
  getPageLayoutUsingGETResponse(pageKey: string): __Observable<__StrictHttpResponse<PageLayoutDto>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/page/layout/${encodeURIComponent(String(pageKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<PageLayoutDto>;
      })
    );
  }
  /**
   * getPageLayout
   * @param pageKey pageKey
   * @return OK
   */
  getPageLayoutUsingGET(pageKey: string): __Observable<PageLayoutDto> {
    return this.getPageLayoutUsingGETResponse(pageKey).pipe(
      __map(_r => _r.body as PageLayoutDto)
    );
  }

  /**
   * newPage
   * @param pageDto pageDto
   * @return OK
   */
  newPageUsingPOSTResponse(pageDto: PageDto): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = pageDto;
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/page/new`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * newPage
   * @param pageDto pageDto
   * @return OK
   */
  newPageUsingPOST(pageDto: PageDto): __Observable<string> {
    return this.newPageUsingPOSTResponse(pageDto).pipe(
      __map(_r => _r.body as string)
    );
  }

  /**
   * getPage
   * @param pageKey pageKey
   * @return OK
   */
  getPageUsingGETResponse(pageKey: string): __Observable<__StrictHttpResponse<PageDto>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/page/${encodeURIComponent(String(pageKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<PageDto>;
      })
    );
  }
  /**
   * getPage
   * @param pageKey pageKey
   * @return OK
   */
  getPageUsingGET(pageKey: string): __Observable<PageDto> {
    return this.getPageUsingGETResponse(pageKey).pipe(
      __map(_r => _r.body as PageDto)
    );
  }
}

module PageControllerService {
}

export { PageControllerService }
