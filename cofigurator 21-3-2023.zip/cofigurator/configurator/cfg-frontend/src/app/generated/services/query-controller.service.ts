/* tslint:disable */
import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpHeaders } from '@angular/common/http';
import { BaseService as __BaseService } from '../base-service';
import { ApiConfiguration as __Configuration } from '../api-configuration';
import { StrictHttpResponse as __StrictHttpResponse } from '../strict-http-response';
import { Observable as __Observable } from 'rxjs';
import { map as __map, filter as __filter } from 'rxjs/operators';

import { Query } from '../models/query';

/**
 * Query Controller
 */
@Injectable({
  providedIn: 'root',
})
class QueryControllerService extends __BaseService {
  static readonly getQueryKeysUsingGETPath = '/api/query/keys';
  static readonly getQueryUsingGETPath = '/api/query/{viewName}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * getQueryKeys
   * @return OK
   */
  getQueryKeysUsingGETResponse(): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/query/keys`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getQueryKeys
   * @return OK
   */
  getQueryKeysUsingGET(): __Observable<Array<string>> {
    return this.getQueryKeysUsingGETResponse().pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getQuery
   * @param viewName viewName
   * @return OK
   */
  getQueryUsingGETResponse(viewName: string): __Observable<__StrictHttpResponse<Query>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/query/${encodeURIComponent(String(viewName))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Query>;
      })
    );
  }
  /**
   * getQuery
   * @param viewName viewName
   * @return OK
   */
  getQueryUsingGET(viewName: string): __Observable<Query> {
    return this.getQueryUsingGETResponse(viewName).pipe(
      __map(_r => _r.body as Query)
    );
  }
}

module QueryControllerService {
}

export { QueryControllerService }
