/* tslint:disable */
import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpHeaders } from '@angular/common/http';
import { BaseService as __BaseService } from '../base-service';
import { ApiConfiguration as __Configuration } from '../api-configuration';
import { StrictHttpResponse as __StrictHttpResponse } from '../strict-http-response';
import { Observable as __Observable } from 'rxjs';
import { map as __map, filter as __filter } from 'rxjs/operators';

import { WidgetDtoExtended } from '../models/widget-dto-extended';
import { Widget } from '../models/widget';

/**
 * Widget Controller
 */
@Injectable({
  providedIn: 'root',
})
class WidgetControllerService extends __BaseService {
  static readonly getWidgetAttributeKeysUsingGETPath = '/api/widget/attributekeys';
  static readonly getWidgetNamesUsingGETPath = '/api/widget/names';
  static readonly getWidgetNamesForGenericUsingGETPath = '/api/widget/names/generic';
  static readonly getWidgetNamesForDomainAndGenericUsingGETPath = '/api/widget/names/generic/{domainKey}';
  static readonly getWidgetNamesForDomainUsingGETPath = '/api/widget/names/{domainKey}';
  static readonly saveWidgetUsingPOSTPath = '/api/widget/save';
  static readonly getWidgetTypesUsingGETPath = '/api/widget/types';
  static readonly getWidgetUsingGETPath = '/api/widget/{name}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * getWidgetAttributeKeys
   * @return OK
   */
  getWidgetAttributeKeysUsingGETResponse(): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/widget/attributekeys`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getWidgetAttributeKeys
   * @return OK
   */
  getWidgetAttributeKeysUsingGET(): __Observable<Array<string>> {
    return this.getWidgetAttributeKeysUsingGETResponse().pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getWidgetNames
   * @return OK
   */
  getWidgetNamesUsingGETResponse(): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/widget/names`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getWidgetNames
   * @return OK
   */
  getWidgetNamesUsingGET(): __Observable<Array<string>> {
    return this.getWidgetNamesUsingGETResponse().pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getWidgetNamesForGeneric
   * @return OK
   */
  getWidgetNamesForGenericUsingGETResponse(): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/widget/names/generic`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getWidgetNamesForGeneric
   * @return OK
   */
  getWidgetNamesForGenericUsingGET(): __Observable<Array<string>> {
    return this.getWidgetNamesForGenericUsingGETResponse().pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getWidgetNamesForDomainAndGeneric
   * @param domainKey domainKey
   * @return OK
   */
  getWidgetNamesForDomainAndGenericUsingGETResponse(domainKey: string): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/widget/names/generic/${encodeURIComponent(String(domainKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getWidgetNamesForDomainAndGeneric
   * @param domainKey domainKey
   * @return OK
   */
  getWidgetNamesForDomainAndGenericUsingGET(domainKey: string): __Observable<Array<string>> {
    return this.getWidgetNamesForDomainAndGenericUsingGETResponse(domainKey).pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getWidgetNamesForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getWidgetNamesForDomainUsingGETResponse(domainKey: string): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/widget/names/${encodeURIComponent(String(domainKey))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getWidgetNamesForDomain
   * @param domainKey domainKey
   * @return OK
   */
  getWidgetNamesForDomainUsingGET(domainKey: string): __Observable<Array<string>> {
    return this.getWidgetNamesForDomainUsingGETResponse(domainKey).pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * saveWidget
   * @param widgetDtoExtended widgetDtoExtended
   * @return OK
   */
  saveWidgetUsingPOSTResponse(widgetDtoExtended: WidgetDtoExtended): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = widgetDtoExtended;
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/widget/save`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }
  /**
   * saveWidget
   * @param widgetDtoExtended widgetDtoExtended
   * @return OK
   */
  saveWidgetUsingPOST(widgetDtoExtended: WidgetDtoExtended): __Observable<string> {
    return this.saveWidgetUsingPOSTResponse(widgetDtoExtended).pipe(
      __map(_r => _r.body as string)
    );
  }

  /**
   * getWidgetTypes
   * @return OK
   */
  getWidgetTypesUsingGETResponse(): __Observable<__StrictHttpResponse<Array<string>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/widget/types`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<string>>;
      })
    );
  }
  /**
   * getWidgetTypes
   * @return OK
   */
  getWidgetTypesUsingGET(): __Observable<Array<string>> {
    return this.getWidgetTypesUsingGETResponse().pipe(
      __map(_r => _r.body as Array<string>)
    );
  }

  /**
   * getWidget
   * @param name name
   * @return OK
   */
  getWidgetUsingGETResponse(name: string): __Observable<__StrictHttpResponse<Widget>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/widget/${encodeURIComponent(String(name))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Widget>;
      })
    );
  }
  /**
   * getWidget
   * @param name name
   * @return OK
   */
  getWidgetUsingGET(name: string): __Observable<Widget> {
    return this.getWidgetUsingGETResponse(name).pipe(
      __map(_r => _r.body as Widget)
    );
  }
}

module WidgetControllerService {
}

export { WidgetControllerService }
