/* tslint:disable */
import { ApplicationDomain } from './application-domain';
import { Widget } from './widget';
export interface WidgetDtoExtended {
  applicationDomain: ApplicationDomain;
  tag: string;
  widget: Widget;
}
