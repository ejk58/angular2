/* tslint:disable */
export interface Rule {
  id: number;
  index: number;
  value: string;
}
