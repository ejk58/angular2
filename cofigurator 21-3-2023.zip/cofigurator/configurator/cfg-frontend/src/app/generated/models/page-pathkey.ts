/* tslint:disable */
import { Page } from './page';
export interface PagePathkey {
  id: number;
  name: string;
  page: Page;
}
