/* tslint:disable */
export interface DomainPathkey {
  id: number;
  index: number;
  key: string;
  mandatory: number;
  name: string;
  title: string;
  type: string;
}
