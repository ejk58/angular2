/* tslint:disable */
export interface QueryAttribute {
  id: number;
  key?: string;
  value?: string;
}
