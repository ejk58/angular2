/* tslint:disable */
export interface DomainRole {
  id: number;
  role: string;
  type: number;
  vipaccess: number;
}
