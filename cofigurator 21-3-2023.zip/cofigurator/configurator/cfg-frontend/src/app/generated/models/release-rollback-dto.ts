/* tslint:disable */
import { ApplicationDomain } from './application-domain';
import { Release } from './release';
export interface ReleaseRollbackDto {
  applicationDomain: ApplicationDomain;
  currentRelease: Release;
  environment: string;
}
