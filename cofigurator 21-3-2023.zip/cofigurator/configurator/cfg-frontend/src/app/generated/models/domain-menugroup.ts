/* tslint:disable */
export interface DomainMenugroup {
  iconname?: string;
  id: number;
  index: number;
  title: string;
}
