/* tslint:disable */
import { Domain } from './domain';
export interface Help {
  content: string;
  id: number;
  key: string;
  ownerDomain?: Domain;
  title: string;
}
