/* tslint:disable */
import { Change } from './change';
import { ReleaseEnvironment } from './release-environment';
export interface ChangeReleaseEnvironment {
  change: Change;
  releaseEnvironment: ReleaseEnvironment;
}
