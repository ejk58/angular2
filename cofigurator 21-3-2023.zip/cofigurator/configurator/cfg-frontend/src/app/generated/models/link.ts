/* tslint:disable */
export interface Link {
  href?: string;
  templated?: boolean;
}
