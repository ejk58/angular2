/* tslint:disable */
export interface QueryColumn {
  alias?: string;
  columnList?: Array<QueryColumn>;
  composite_column_id?: number;
  id: number;
  index: number;
  key?: string;
  maskable: boolean;
  name: string;
  query_id?: number;
  type?: string;
  value?: string;
}
