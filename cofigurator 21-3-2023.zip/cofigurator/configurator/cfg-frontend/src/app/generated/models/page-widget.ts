/* tslint:disable */
import { Page } from './page';
import { Widget } from './widget';
export interface PageWidget {
  columnIndex: number;
  gridColumns: number;
  id: number;
  page: Page;
  rowIndex: number;
  widget: Widget;
}
