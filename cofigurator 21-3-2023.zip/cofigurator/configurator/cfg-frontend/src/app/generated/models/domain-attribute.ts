/* tslint:disable */
export interface DomainAttribute {
  id: number;
  key: string;
  value: string;
}
