/* tslint:disable */
export interface DatasourceViewDto {
  columnNames: Array<string>;
  viewName: string;
}
