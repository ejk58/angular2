/* tslint:disable */
import { WidgetAttribute } from './widget-attribute';
import { WidgetColumn } from './widget-column';
import { WidgetHelp } from './widget-help';
import { Domain } from './domain';
import { PageWidget } from './page-widget';
import { Query } from './query';
import { RuleGroup } from './rule-group';
export interface Widget {
  attributeList?: Array<WidgetAttribute>;
  columnList?: Array<WidgetColumn>;
  containerWidget?: Widget;
  description?: string;
  helpList?: Array<WidgetHelp>;
  id: number;
  index?: number;
  name: string;
  ownerDomain?: Domain;
  pageWidgetList?: Array<PageWidget>;
  query?: Query;
  refreshinfo: boolean;
  ruleGroup?: RuleGroup;
  title?: string;
  type: string;
  visible: boolean;
  widgetList?: Array<Widget>;
}
