/* tslint:disable */
export interface QueryFilter {
  filterTemplate: string;
  id: number;
  noFilterTemplate?: string;
  parameter?: string;
}
