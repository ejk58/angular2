/* tslint:disable */
export interface DomainSubjecttype {
  id: number;
  index: number;
  label: string;
  searchfilter?: string;
  searchkey: string;
}
