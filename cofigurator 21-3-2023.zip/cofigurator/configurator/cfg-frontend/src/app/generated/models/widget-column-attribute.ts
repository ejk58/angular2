/* tslint:disable */
export interface WidgetColumnAttribute {
  id: number;
  key: string;
  value: string;
}
