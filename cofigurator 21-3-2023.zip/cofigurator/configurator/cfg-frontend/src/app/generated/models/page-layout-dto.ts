/* tslint:disable */
import { ApplicationDomain } from './application-domain';
import { PageWidget } from './page-widget';
import { Page } from './page';
export interface PageLayoutDto {
  applicationDomain?: ApplicationDomain;
  initialWidgets: Array<PageWidget>;
  page: Page;
  tag: string;
  widgets: Array<PageWidget>;
}
