/* tslint:disable */
import { Domain } from './domain';
import { PageAttribute } from './page-attribute';
import { PageDomain } from './page-domain';
import { PagePathkey } from './page-pathkey';
export interface Page {
  id: number;
  key: string;
  ownerDomain?: Domain;
  pageAttributeList?: Array<PageAttribute>;
  pageDomainList?: Array<PageDomain>;
  pagePathkeyList?: Array<PagePathkey>;
  title?: string;
  type: string;
}
