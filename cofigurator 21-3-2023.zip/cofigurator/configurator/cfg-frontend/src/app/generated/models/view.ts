/* tslint:disable */
export interface View {
  contentType?: string;
}
