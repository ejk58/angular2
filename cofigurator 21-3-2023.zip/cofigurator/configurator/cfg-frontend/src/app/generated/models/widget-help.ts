/* tslint:disable */
import { Help } from './help';
export interface WidgetHelp {
  help: Help;
  id: number;
  index: number;
}
