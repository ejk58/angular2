/* tslint:disable */
import { DomainAttribute } from './domain-attribute';
import { DomainMenugroup } from './domain-menugroup';
import { DomainPathkey } from './domain-pathkey';
import { DomainRole } from './domain-role';
import { DomainSubjecttype } from './domain-subjecttype';
import { Query } from './query';
export interface Domain {
  domainAttributeList?: Array<DomainAttribute>;
  domainMenugroupList?: Array<DomainMenugroup>;
  domainPathkeyList?: Array<DomainPathkey>;
  domainRoleList?: Array<DomainRole>;
  domainSubjecttypeList?: Array<DomainSubjecttype>;
  iconname?: string;
  id: number;
  index: number;
  key: string;
  name: string;
  relationNoVipQuery?: Query;
  relationVipQuery?: Query;
  searchNoVipQuery?: Query;
  searchVipQuery?: Query;
  subjectQuery?: Query;
}
