/* tslint:disable */
import { QueryColumn } from './query-column';
import { Datasource } from './datasource';
import { Domain } from './domain';
import { QueryAttribute } from './query-attribute';
import { QueryFilter } from './query-filter';
export interface Query {
  columnList: Array<QueryColumn>;
  datasource: Datasource;
  id: number;
  key: string;
  ownerDomain?: Domain;
  queryAttributeList?: Array<QueryAttribute>;
  queryFilterList: Array<QueryFilter>;
  querytemplate: string;
  type: number;
  viewname: string;
}
