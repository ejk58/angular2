/* tslint:disable */
export interface RobotTestsDto {
  domain: string;
  page: string;
  user: string;
  widgetName: string;
}
