/* tslint:disable */
export interface Datasource {
  id: number;
  key: string;
}
