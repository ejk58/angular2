/* tslint:disable */
import { Domain } from './domain';
import { Rule } from './rule';
export interface RuleGroup {
  id: number;
  key: string;
  ownerDomain?: Domain;
  ruleList: Array<Rule>;
}
