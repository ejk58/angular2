/* tslint:disable */
export interface Change {
  administrator: string;
  appVersion: string;
  date: string;
  domainKey: string;
  id: number;
  releaseId?: number;
  rollbackSql: string;
  sequenceNo: number;
  sql: string;
  tag: string;
}
