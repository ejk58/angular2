/* tslint:disable */
import { WidgetColumnAttribute } from './widget-column-attribute';
import { QueryColumn } from './query-column';
export interface WidgetColumn {
  behaviour?: string;
  columnAttributeList?: Array<WidgetColumnAttribute>;
  description?: string;
  filter?: string;
  id: number;
  index: number;
  label?: string;
  queryColumn?: QueryColumn;
  type: string;
}
