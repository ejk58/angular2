/* tslint:disable */
export interface VersionDto {
  commitDate: string;
  commitId: string;
  version: string;
}
