/* tslint:disable */
export interface Release {
  administrator: string;
  date: string;
  domainKey: string;
  id: number;
  tag: string;
}
