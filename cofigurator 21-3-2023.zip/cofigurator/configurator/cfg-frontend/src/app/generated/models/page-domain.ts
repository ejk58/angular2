/* tslint:disable */
import { Domain } from './domain';
import { Page } from './page';
export interface PageDomain {
  domain: Domain;
  groupIndex?: number;
  id: number;
  memberIndex?: number;
  page: Page;
}
