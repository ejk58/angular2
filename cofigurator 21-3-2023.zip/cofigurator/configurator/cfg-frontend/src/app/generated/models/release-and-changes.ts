/* tslint:disable */
import { ApplicationDomain } from './application-domain';
import { Change } from './change';
import { Release } from './release';
export interface ReleaseAndChanges {
  applicationDomain: ApplicationDomain;
  changes: Array<Change>;
  release: Release;
}
