/* tslint:disable */
export interface Environment {
  name: string;
  type: string;
}
