/* tslint:disable */
export interface PageAttribute {
  id: number;
  key: string;
  value: string;
}
