/* tslint:disable */
import { ApplicationDomain } from './application-domain';
import { ReleaseRolloutInfo } from './release-rollout-info';
export interface ReleaseRolloutDto {
  applicationDomain: ApplicationDomain;
  environment: string;
  releaseRolloutInfo: ReleaseRolloutInfo;
}
