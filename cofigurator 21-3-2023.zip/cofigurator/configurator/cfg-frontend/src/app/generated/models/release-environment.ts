/* tslint:disable */
import { Environment } from './environment';
import { Release } from './release';
export interface ReleaseEnvironment {
  administrator: string;
  deploymentDate: string;
  domainKey: string;
  environment: Environment;
  release: Release;
}
