/* tslint:disable */
import { ApplicationDomain } from './application-domain';
import { PageWidget } from './page-widget';
export interface PageDto {
  applicationDomain: ApplicationDomain;
  key: string;
  tag: string;
  title: string;
  type: string;
  widgets: Array<PageWidget>;
}
