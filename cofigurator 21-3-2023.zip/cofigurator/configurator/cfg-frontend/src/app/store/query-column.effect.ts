import {Injectable} from '@angular/core';

import {Actions, createEffect, ofType} from '@ngrx/effects';
import {Store} from '@ngrx/store';
import {concatMap, filter, map, switchMap, withLatestFrom} from 'rxjs/operators';
import {of} from 'rxjs';

import {QueryColumnActions} from './query-column.action';
import {fromQueryColumn} from './query-column.selector';
import {QueryColumnAppState, QueryColumnTypes} from './query-column.reducer';

import {QueryColumnService} from '../services/query-column.service';

@Injectable()
export class QueryColumnEffect {

  constructor(
        private actions$: Actions,
        private queryColumnService: QueryColumnService,
        private store: Store<QueryColumnAppState>
  ) {}

  getQueryColumnTypes$ = createEffect(() =>
    this.actions$.pipe(
      ofType(QueryColumnActions.get),
      concatMap((action) =>
        of(action).pipe(
          withLatestFrom(this.store.select(fromQueryColumn.selectLoadStatus))
        )
      ),
      filter(([action, loadStatus]) => loadStatus === 'NOT_LOADED'),
      map(() => QueryColumnActions.load())
    )
  );

  loadQueryColumnTypes$ = createEffect(() =>
    this.actions$.pipe(
      ofType(QueryColumnActions.load),
      switchMap(() => this.queryColumnService.getQueryColumnTypes().pipe(
        map((cct) => QueryColumnActions.loaded({ queryColumnTypes: this.createQueryColumnTypes(cct) }))
      ))
    )
  );

  private createQueryColumnTypes = (array: Array<string>): Array<QueryColumnTypes> => {
    return array.reduce((acc, value) => {
      return [...acc, {label: value, value: value}];
    }, Array<QueryColumnTypes>());
  };
}
