import {Action, createReducer, on} from '@ngrx/store';

import {QueryColumnActions} from './query-column.action';

export const queryColumnFeatureKey = 'QueryColumnTypes';

export interface State {
    loadStatus: 'NOT_LOADED' | 'LOADING' | 'LOADED',
    queryColumnTypes: Array<{ label: string, value: string }>
}

export interface QueryColumnAppState {
    [queryColumnFeatureKey]: State
}

export interface QueryColumnTypes {
    label: string,
    value: string
}

export const initialState: State = {
  loadStatus: 'NOT_LOADED',
  queryColumnTypes: new Array<QueryColumnTypes>()
};

const QueryColumnReducer = createReducer<State>(
  initialState,
  on(QueryColumnActions.load, (state) => ({
    ...state,
    loadStatus: 'LOADING'
  })),
  on(QueryColumnActions.loaded, (state, { queryColumnTypes }) => ({
    ...state,
    loadStatus: 'LOADED',
    queryColumnTypes
  }))
);

export function queryColumnReducer(state: State | undefined, action: Action) {
  return QueryColumnReducer(state, action);
}
