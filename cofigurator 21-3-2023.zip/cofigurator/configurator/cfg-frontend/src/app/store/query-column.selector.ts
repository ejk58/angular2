import {createFeatureSelector, createSelector} from '@ngrx/store';
import {queryColumnFeatureKey, State} from './query-column.reducer';

const selectQueryColumnState = createFeatureSelector<State>(queryColumnFeatureKey);

const selectLoadStatus = createSelector(
  selectQueryColumnState,
  (state) => state.loadStatus
);

const isLoaded = createSelector(
  selectLoadStatus,
  (loadStatus) => loadStatus === 'LOADED'
);

export const fromQueryColumn = {
  selectLoadStatus,
  isLoaded
};
