import {createAction, props} from '@ngrx/store';

import {QueryColumnTypes} from './query-column.reducer';

const get = createAction('[QueryColumnTypes] Get');
const load = createAction('[QueryColumnTypes] Load');
const loaded = createAction(
  '[QueryColumnTypes] Loaded',
  props<{ queryColumnTypes: Array<QueryColumnTypes>}>()
);

export const QueryColumnActions = {
  get,
  load,
  loaded
};
