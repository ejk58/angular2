import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoginComponent} from './login/login.component';
import {ReleaseOverviewComponent} from './reports/release-overview/release-overview.component';
import {LoggedInGuard} from './guards/logged-in.guard';
import {ChangePageWizardComponent} from './wizards/change-page-wizard/change-page-wizard.component';
import {NewPageWizardComponent} from './wizards/new-page-wizard/new-page-wizard.component';
import {RobotTestsWizardComponent} from './wizards/robot-tests-wizard/robot-tests-wizard.component';
import {DeleteReleaseWizardComponent} from './wizards/delete-release-wizard/delete-release-wizard.component';
import {NewReleaseWizardComponent} from './wizards/new-release-wizard/new-release-wizard.component';
import {DeployReleaseWizardComponent} from './wizards/deploy-release-wizard/deploy-release-wizard.component';
import {DeleteChangeWizardComponent} from './wizards/delete-change-wizard/delete-change-wizard.component';
import {RollbackReleaseWizardComponent} from './wizards/rollback-release-wizard/rollback-release-wizard.component';
import {NewWidgetWizardComponent} from './wizards/widget-wizards/new-widget-wizard/new-widget-wizard.component';
import {ChangeWidgetWizardComponent} from './wizards/widget-wizards/change-widget-wizard/change-widget-wizard.component';
import {ChangeOverviewComponent} from './reports/change-overview/change-overview.component';
import {ChangeOverviewDetailComponent} from './reports/change-overview/change-overview-detail/change-overview-detail.component';
import {ExportDomainWizardComponent} from './wizards/export-domain-wizard/export-domain-wizard.component';

const routes: Routes = [
  {path: 'login', component: LoginComponent},
  {path: '', component: NewWidgetWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'changeWidget', component: ChangeWidgetWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'changePage', component: ChangePageWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'newPage', component: NewPageWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'deleteChange', component: DeleteChangeWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'newRelease', component: NewReleaseWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'deployRelease', component: DeployReleaseWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'rollbackRelease', component: RollbackReleaseWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'deleteRelease', component: DeleteReleaseWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'exportDomain', component: ExportDomainWizardComponent, canActivate: [LoggedInGuard]},
  {path: 'releaseOverview', component: ReleaseOverviewComponent, canActivate: [LoggedInGuard]},
  {path: 'changeOverview', component: ChangeOverviewComponent, canActivate: [LoggedInGuard]},
  {path: 'changeOverview/:changeId', component: ChangeOverviewDetailComponent, canActivate: [LoggedInGuard]},
  {path: 'robot', component: RobotTestsWizardComponent, canActivate: [LoggedInGuard]},
  {path: '**', redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true, enableTracing: false, relativeLinkResolution: 'legacy'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
