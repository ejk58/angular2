import {HttpClientModule} from '@angular/common/http';
import {ErrorHandler, Injector, NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ButtonModule} from 'primeng/button';
import {DropdownModule} from 'primeng/dropdown';
import {InputNumberModule} from 'primeng/inputnumber';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {InputTextModule} from 'primeng/inputtext';
import {RadioButtonModule} from 'primeng/radiobutton';
import {StepsModule} from 'primeng/steps';
import {TableModule} from 'primeng/table';
import {CheckboxModule} from 'primeng/checkbox';
import {CardModule} from 'primeng/card';
import {MenuModule} from 'primeng/menu';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {TreeTableModule} from 'primeng/treetable';
import { EffectsModule } from '@ngrx/effects';
import {StoreModule} from '@ngrx/store';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {HeaderComponent} from './components/header/header.component';
import {FooterComponent} from './components/footer/footer.component';
import {PageMenuComponent} from './components/page-menu/page-menu.component';
import {WidgetCardComponent} from './components/widget-card/widget-card.component';
import {LoggedInGuard} from './guards/logged-in.guard';
import {LoginComponent} from './login/login.component';
import {ReleaseOverviewComponent} from './reports/release-overview/release-overview.component';
import {ChangePageWizardComponent} from './wizards/change-page-wizard/change-page-wizard.component';
import {NewPageWizardComponent} from './wizards/new-page-wizard/new-page-wizard.component';
import * as changePageSteps from './wizards/change-page-wizard/steps';
import * as newPageSteps from './wizards/new-page-wizard/steps';
import * as newReleaseSteps from './wizards/new-release-wizard/steps';
import * as deleteReleaseSteps from './wizards/delete-release-wizard/steps';
import * as deployReleaseSteps from './wizards/deploy-release-wizard/steps';
import * as rollbackReleaseSteps from './wizards/rollback-release-wizard/steps';
import * as newWidgetSteps from './wizards/widget-wizards/new-widget-wizard/steps';
import * as changeWidgetSteps from './wizards/widget-wizards/change-widget-wizard/steps';
import * as commonWidgetSteps from './wizards/widget-wizards/common/steps';
import * as robotSteps from './wizards/robot-tests-wizard/steps';
import * as deleteChangeSteps from './wizards/delete-change-wizard/steps';
import * as exportDomainSteps from './wizards/export-domain-wizard/steps';
import {DatasourceService} from './services/datasource.service';
import {LoginService} from './services/login.service';
import {DomainService} from './services/domain.service';
import {ConfigurationService} from './services/configuration.service';
import {PageService} from './services/page.service';
import {ChangeService} from './services/change.service';
import {ReleaseService} from './services/release.service';
import {EnvironmentService} from './services/environment.service';
import {ChangePageWizardService} from './wizards/change-page-wizard/change-page-wizard.service';
import {NewPageWizardService} from './wizards/new-page-wizard/new-page-wizard.service';
import {NewReleaseWizardService} from './wizards/new-release-wizard/new-release-wizard.service';
import {NewReleaseWizardComponent} from './wizards/new-release-wizard/new-release-wizard.component';
import {DeleteReleaseWizardService} from './wizards/delete-release-wizard/delete-release-wizard.service';
import {DeleteReleaseWizardComponent} from './wizards/delete-release-wizard/delete-release-wizard.component';
import {DeployReleaseWizardComponent} from './wizards/deploy-release-wizard/deploy-release-wizard.component';
import {DeployReleaseWizardService} from './wizards/deploy-release-wizard/deploy-release-wizard.service';
import {QueryService} from './services/query.service';
import {WidgetAttributeService} from './services/widget-attribute.service';
import {WidgetService} from './services/widget.service';
import {RobotService} from './services/robot.service';
import {NewWidgetWizardComponent} from './wizards/widget-wizards/new-widget-wizard/new-widget-wizard.component';
import {ChangeWidgetWizardComponent} from './wizards/widget-wizards/change-widget-wizard/change-widget-wizard.component';
import {PageMenuService} from './services/page-menu.service';
import {WidgetWizardService} from './wizards/widget-wizards/common/widget-wizard.service';
import {RobotTestsWizardComponent} from './wizards/robot-tests-wizard/robot-tests-wizard.component';
import {RobotTestsWizardService} from './wizards/robot-tests-wizard/robot-tests-wizard.service';
import {DeleteChangeWizardComponent} from './wizards/delete-change-wizard/delete-change-wizard.component';
import {DeleteChangeWizardService} from './wizards/delete-change-wizard/delete-change-wizard.service';
import {setAppInjector} from './app-injector';
import {WizardStore} from './domain/wizard/wizard-store';
import {WidgetWizardRoute} from './wizards/widget-wizards/common/widget-wizard-route';
import {ChangePageWizardRoute} from './wizards/change-page-wizard/change-page-wizard-route';
import {NewPageWizardRoute} from './wizards/new-page-wizard/new-page-wizard-route';
import {NewReleaseWizardRoute} from './wizards/new-release-wizard/new-release-wizard-route';
import {DeleteReleaseWizardRoute} from './wizards/delete-release-wizard/delete-release-wizard-route';
import {DeployReleaseWizardRoute} from './wizards/deploy-release-wizard/deploy-release-wizard-route';
import {RobotTestsWizardRoute} from './wizards/robot-tests-wizard/robot-tests-wizard-route';
import {DeleteChangeWizardRoute} from './wizards/delete-change-wizard/delete-change-wizard-route';
import {WidgetWizardRouteConfig} from './wizards/widget-wizards/common/widget-wizard-route-config';
import {ChangePageWizardRouteConfig} from './wizards/change-page-wizard/change-page-wizard-route-config';
import {NewPageWizardRouteConfig} from './wizards/new-page-wizard/new-page-wizard-route-config';
import {NewReleaseWizardRouteConfig} from './wizards/new-release-wizard/new-release-wizard-route-config';
import {DeleteReleaseWizardRouteConfig} from './wizards/delete-release-wizard/delete-release-wizard-route-config';
import {DeployReleaseWizardRouteConfig} from './wizards/deploy-release-wizard/deploy-release-wizard-route-config';
import {RobotTestsWizardRouteConfig} from './wizards/robot-tests-wizard/robot-tests-wizard-route-config';
import {DeleteChangeWizardRouteConfig} from './wizards/delete-change-wizard/delete-change-wizard-route-config';
import {SystemService} from './services/system.service';
import {BackButtonComponent} from './components/buttons/back-button/back-button.component';
import {ContinueButtonComponent} from './components/buttons/continue-button/continue-button.component';
import {ChangeTagComponent} from './components/tags/change-tag/change-tag.component';
import {ReleaseTagComponent} from './components/tags/release-tag/release-tag.component';
import {ExecuteButtonComponent} from './components/buttons/execute-button/execute-button.component';
import {ErrorStepComponent} from './components/steps/error-step/error-step.component';
import {SuccessStepComponent} from './components/steps/success-step/success-step.component';
import {WizardNameComponent} from './components/wizard-name/wizard-name.component';
import * as httpInterceptorProviders from './interceptors';
import {SummaryTableComponent} from './components/summary-table/summary-table.component';
import {RollbackReleaseWizardComponent} from './wizards/rollback-release-wizard/rollback-release-wizard.component';
import {RollbackReleaseWizardRoute} from './wizards/rollback-release-wizard/rollback-release-wizard-route';
import {RollbackReleaseWizardRouteConfig} from './wizards/rollback-release-wizard/rollback-release-wizard-route-config';
import {RollbackReleaseWizardService} from './wizards/rollback-release-wizard/rollback-release-wizard.service';
import {ChangeOverviewComponent} from './reports/change-overview/change-overview.component';
import {ChangeOverviewDetailComponent} from './reports/change-overview/change-overview-detail/change-overview-detail.component';
import * as pipes from './components/pipes/index';
import {DatePipe} from '@angular/common';
import {SpinnerComponent} from './components/spinner/spinner.component';
import {SpinnerService} from './services/spinner.service';
import {AgainButtonComponent} from './components/buttons/again-button/again-button.component';
import {ErrorComponent} from './components/error/error.component';
import {GlobalErrorHandler} from './error-handling/global-error-handler';
import {ErrorService} from './services/error.service';
import {DialogModule} from 'primeng/dialog';
import {DialogService, DynamicDialogConfig, DynamicDialogRef} from 'primeng/dynamicdialog';
import {QueryFilterComponent} from './wizards/widget-wizards/components/query-filter/query-filter.component';
import {ExportDomainWizardRoute} from './wizards/export-domain-wizard/export-domain-wizard-route';
import {ExportDomainWizardRouteConfig} from './wizards/export-domain-wizard/export-domain-wizard-route-config';
import {ExportDomainWizardComponent} from './wizards/export-domain-wizard/export-domain-wizard.component';
import {ExportDomainWizardService} from './wizards/export-domain-wizard/export-domain-wizard.service';
import {QueryTypesComponent} from './wizards/widget-wizards/components/query-types/query-types.component';
import {QueryColumnEffect} from './store/query-column.effect';
import {queryColumnFeatureKey, queryColumnReducer} from './store/query-column.reducer';
import {QueryColumnService} from './services/query-column.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ReleaseOverviewComponent,
    ChangeOverviewComponent,
    ChangeOverviewDetailComponent,
    ErrorStepComponent,
    SuccessStepComponent,
    NewWidgetWizardComponent,
    ChangeWidgetWizardComponent,
    ChangePageWizardComponent,
    NewPageWizardComponent,
    NewReleaseWizardComponent,
    DeleteReleaseWizardComponent,
    DeployReleaseWizardComponent,
    RollbackReleaseWizardComponent,
    RobotTestsWizardComponent,
    DeleteChangeWizardComponent,
    ExportDomainWizardComponent,
    HeaderComponent,
    FooterComponent,
    PageMenuComponent,
    WidgetCardComponent,
    BackButtonComponent,
    ContinueButtonComponent,
    ChangeTagComponent,
    ReleaseTagComponent,
    ExecuteButtonComponent,
    WizardNameComponent,
    SummaryTableComponent,
    SpinnerComponent,
    AgainButtonComponent,
    ErrorComponent,
    QueryFilterComponent,
    pipes.list,
    newWidgetSteps.list,
    changeWidgetSteps.list,
    commonWidgetSteps.list,
    changePageSteps.list,
    newPageSteps.list,
    newReleaseSteps.list,
    deleteReleaseSteps.list,
    deployReleaseSteps.list,
    rollbackReleaseSteps.list,
    robotSteps.list,
    deleteChangeSteps.list,
    exportDomainSteps.list,
    QueryTypesComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    DropdownModule,
    StepsModule,
    InputNumberModule,
    TableModule,
    CardModule,
    MenuModule,
    RadioButtonModule,
    InputTextareaModule,
    InputTextModule,
    CheckboxModule,
    ProgressSpinnerModule,
    DialogModule,
    TreeTableModule,
    StoreModule.forRoot([]),
    StoreModule.forFeature(
      queryColumnFeatureKey, queryColumnReducer
    ),
    EffectsModule.forRoot([
      QueryColumnEffect
    ])
  ],
  providers: [
    httpInterceptorProviders.list,
    LoggedInGuard,
    LoginService,
    DomainService,
    ConfigurationService,
    WidgetService,
    RobotService,
    WidgetAttributeService,
    QueryService,
    QueryColumnService,
    PageService,
    ChangeService,
    ReleaseService,
    DatasourceService,
    PageMenuService,
    WidgetWizardService,
    ChangePageWizardService,
    NewPageWizardService,
    NewReleaseWizardService,
    DeleteReleaseWizardService,
    DeployReleaseWizardService,
    RollbackReleaseWizardService,
    EnvironmentService,
    RobotTestsWizardService,
    DeleteChangeWizardService,
    ExportDomainWizardService,
    SystemService,
    SpinnerService,
    ErrorService,
    DialogService,
    DynamicDialogConfig,
    DynamicDialogRef,
    WizardStore,
    DatePipe,
    pipes.list,
    {provide: ErrorHandler, useClass: GlobalErrorHandler},
    {provide: WidgetWizardRoute, useValue: WidgetWizardRouteConfig},
    {provide: ChangePageWizardRoute, useValue: ChangePageWizardRouteConfig},
    {provide: NewPageWizardRoute, useValue: NewPageWizardRouteConfig},
    {provide: NewReleaseWizardRoute, useValue: NewReleaseWizardRouteConfig},
    {provide: DeleteReleaseWizardRoute, useValue: DeleteReleaseWizardRouteConfig},
    {provide: DeployReleaseWizardRoute, useValue: DeployReleaseWizardRouteConfig},
    {provide: RollbackReleaseWizardRoute, useValue: RollbackReleaseWizardRouteConfig},
    {provide: RobotTestsWizardRoute, useValue: RobotTestsWizardRouteConfig},
    {provide: DeleteChangeWizardRoute, useValue: DeleteChangeWizardRouteConfig},
    {provide: ExportDomainWizardRoute, useValue: ExportDomainWizardRouteConfig}
  ],
  bootstrap: [AppComponent]
})

export class AppModule {

  constructor(private injector: Injector) {
    setAppInjector(injector);
  }

}
