import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'c-again-button',
  templateUrl: './again-button.component.html',
  styleUrls: ['./again-button.component.scss']
})
export class AgainButtonComponent {

  @Input() hide: boolean;
  @Output() clicked: EventEmitter<void> = new EventEmitter<void>();

  public again(): void {
    this.clicked.emit();
  }

}
