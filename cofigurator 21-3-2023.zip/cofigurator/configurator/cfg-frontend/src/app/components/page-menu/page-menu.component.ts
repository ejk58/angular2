import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Router} from '@angular/router';
import {PageMenuService} from '../../services/page-menu.service';

@Component({
  selector: 'c-page-menu',
  templateUrl: './page-menu.component.html',
  styleUrls: ['./page-menu.component.scss']
})

export class PageMenuComponent implements OnInit {
  @Output() pageMenuOpen: EventEmitter<boolean> = new EventEmitter();

  public pageMenu: any[];
  public currentPageKey: string;

  constructor(private pageMenuService: PageMenuService, private router: Router) {
  }

  ngOnInit(): void {
    this.pageMenu = this.pageMenuService.getPageMenuItems();
    this.currentPageKey = this.router.url.substring(1);
  }

  changePage(pageMenuTitleIndex, pageMenuOptionIndex): void {
    const menuOption = this.pageMenu[pageMenuTitleIndex].options[pageMenuOptionIndex];
    this.router.navigate([menuOption.key]);
    this.currentPageKey = menuOption.key;
    this.pageMenuOpen.emit(false);
  }

}
