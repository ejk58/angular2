import {Component, OnInit} from '@angular/core';
import {SystemService} from '../../services/system.service';
import {VersionDto} from '../../generated/models';

@Component({
  selector: 'c-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})

export class FooterComponent implements OnInit {

  public versionDto: VersionDto;

  constructor(private readonly systemService: SystemService) { }

  ngOnInit(): void {
    this.systemService.getVersion().subscribe({
      next: (versionDto) => {
        this.versionDto = versionDto;
      }
    });
  }
}
