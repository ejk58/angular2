import {Component, OnDestroy, OnInit} from '@angular/core';
import {LoginService} from '../../services/login.service';
import {Observable, Subject} from 'rxjs';
import {ApplicationDomain} from '../../generated/models';
import {DomainService} from '../../services/domain.service';
import {MenuItem} from 'primeng/api';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {takeUntil} from 'rxjs/operators';

@Component({
  selector: 'c-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent implements OnInit, OnDestroy {
  private readonly ngUnsubscribe$ = new Subject<void>();
  public isLoggedIn$: Observable<boolean>;
  public loggedInUser: string;
  public domainMenuItems: MenuItem[] = [];
  public activeDomain$: Observable<ApplicationDomain>;
  public accountMenuOpen: boolean = false;
  public pageMenuOpen: boolean = false;
  public isCurrentStepFirstStep$: Observable<boolean>;

  constructor(private loginService: LoginService, private domainService: DomainService, private wizardStore: WizardStore) {  }

  ngOnInit(): void {
    this.isLoggedIn$ = this.loginService.isLoggedIn();
    this.activeDomain$ = this.domainService.activeDomain$;
    this.isCurrentStepFirstStep$ = this.wizardStore.isCurrentStepFirstStep$;

    this.loginService.loggedInUser().subscribe({
      next: (user) => {
        this.loggedInUser = user;
        if (this.loggedInUser) {
          this.getDomains();
        }
      }
    });
  }

  logout(): void {
    this.accountMenuOpen = false;
    this.pageMenuOpen = false;
    this.loginService.logout();
  }

  public toggleAccountMenu(): boolean {
    return this.accountMenuOpen = !this.accountMenuOpen;
  }

  public togglePageMenu(): boolean {
    return this.pageMenuOpen = !this.pageMenuOpen;
  }

  public handlePageMenuOpen(event: boolean): void {
    this.pageMenuOpen = event;
  }

  private getDomains(): void {
    this.domainService.getDomains().pipe(
      takeUntil(this.ngUnsubscribe$)
    ).subscribe({
      next: (domains) => {
        this.domainMenuItems = domains.map(domain => {
          return {label: domain.domainName, command: () => this.domainService.activateDomain(domain)};
        });
        this.domainService.activateDomain(domains[0]);
      }
    });
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe$.next();
    this.ngUnsubscribe$.complete();
  }
}
