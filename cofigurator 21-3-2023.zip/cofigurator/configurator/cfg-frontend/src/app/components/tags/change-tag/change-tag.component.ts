import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Tag} from '../../../domain/tag/tag';
import {ChangeService} from '../../../services/change.service';

@Component({
  selector: 'c-change-tag',
  templateUrl: './change-tag.component.html',
  styleUrls: ['./change-tag.component.scss']
})
export class ChangeTagComponent implements OnInit {

  @Input() tag: string;
  @Output() tagChanged: EventEmitter<Tag> = new EventEmitter();

  private changeTags: string[];

  public isTagUnique: boolean = true;

  constructor(private readonly changeService: ChangeService) {
  }

  ngOnInit(): void {
    this.getAllChangeTags();
  }

  getAllChangeTags(): void {
    this.changeService.getAllChangeTags().subscribe({
      next: (changeTags) => {
        this.changeTags = changeTags;
        this.onTagChange();
      }
    });
  }

  onTagChange(): void {
    this.tag = this.tag?.trim();
    this.isTagUnique = !this.changeTags.includes(this.tag);
    const tag: Tag = {tag: this.tag, isUnique: this.isTagUnique};
    this.tagChanged.emit(tag);
  }

}
