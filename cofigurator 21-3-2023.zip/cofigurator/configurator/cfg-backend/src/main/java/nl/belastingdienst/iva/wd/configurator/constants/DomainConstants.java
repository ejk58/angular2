package nl.belastingdienst.iva.wd.configurator.constants;

public class DomainConstants {

    private DomainConstants() {}

    public static final String ADMIN = "admin";
}
