package nl.belastingdienst.iva.wd.configurator.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import nl.belastingdienst.iva.wd.configurator.domain.ApplicationDomain;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class WidgetDtoExtended {

	@JsonProperty(required = true)
	private String tag;

	@JsonProperty(required = true)
	private Widget widget;

	@JsonProperty(required = true)
	private ApplicationDomain applicationDomain;
}
