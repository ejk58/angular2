package nl.belastingdienst.iva.wd.configurator.domain.configurator.mapper;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.Environment;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class EnvironmentMapper implements RowMapper<Environment> {

    @Override
    public Environment mapRow(ResultSet resultSet, int i) throws SQLException {
        Environment environment = new Environment();
        environment.setName(resultSet.getString("environment_name"));
        environment.setType(resultSet.getString("environment_type"));
        return environment;
    }

}
