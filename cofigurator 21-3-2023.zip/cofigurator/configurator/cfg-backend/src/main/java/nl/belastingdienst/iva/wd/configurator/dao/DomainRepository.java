package nl.belastingdienst.iva.wd.configurator.dao;

import nl.belastingdienst.iva.wd.configurator.domain.Domain;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DomainRepository extends CrudRepository<Domain, Integer> {
    Domain findByKey(String key);
}
