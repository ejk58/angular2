package nl.belastingdienst.iva.wd.configurator.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_PAGE_DOMAIN")
public class PageDomain {

	@Id
	@JsonProperty(required = true)
	private Integer id;

	@Column(name = "GROUP_INDEX")
	private Integer groupIndex;

	@Column(name = "MEMBER_INDEX")
	private Integer memberIndex;

	@JsonBackReference
	@ManyToOne()
	@JoinColumn(name = "PAGE_ID")
	@JsonProperty(required = true)
	private Page page;

	@ManyToOne()
	@JoinColumn(name = "DOMAIN_ID")
	@JsonProperty(required = true)
	private Domain domain;
}
