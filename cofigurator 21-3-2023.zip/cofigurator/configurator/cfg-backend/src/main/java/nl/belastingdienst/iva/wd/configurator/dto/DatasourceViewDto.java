package nl.belastingdienst.iva.wd.configurator.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DatasourceViewDto {

	@JsonProperty(required = true)
	private String viewName;

	@JsonProperty(required = true)
	private List<String> columnNames;

	public DatasourceViewDto(String viewName) {
		this.viewName = viewName;
	}

	public void addColumnName(String columnName) {
		if (this.columnNames == null) {
			this.columnNames = new ArrayList<>();
		}

		this.columnNames.add(columnName);
	}
}
