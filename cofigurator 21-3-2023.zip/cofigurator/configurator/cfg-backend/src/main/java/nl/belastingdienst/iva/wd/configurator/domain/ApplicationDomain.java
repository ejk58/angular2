package nl.belastingdienst.iva.wd.configurator.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class ApplicationDomain {

	@JsonProperty(required = true)
	private String domainId;

	@JsonProperty(required = true)
	private String domainName;
}
