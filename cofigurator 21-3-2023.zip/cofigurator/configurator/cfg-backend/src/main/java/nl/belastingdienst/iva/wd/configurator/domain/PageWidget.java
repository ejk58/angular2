package nl.belastingdienst.iva.wd.configurator.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_PAGE_WIDGET")
public class PageWidget {

    @Id
    @JsonProperty(required = true)
    private Integer id;

    @Column(name = "GRID_COLUMNS")
    @JsonProperty(required = true)
    private Integer gridColumns;

    @Column(name = "ROW_INDEX")
    @JsonProperty(required = true)
    private Integer rowIndex;

    @Column(name = "COLUMN_INDEX")
    @JsonProperty(required = true)
    private Integer columnIndex;

    @ManyToOne()
    @JoinColumn(name = "PAGE_ID")
    @JsonProperty(required = true)
    private Page page;

    @ManyToOne()
    @JoinColumn(name = "WIDGET_ID")
    @JsonProperty(required = true)
    @JsonIgnoreProperties("widgetList")
    private Widget widget;
}
