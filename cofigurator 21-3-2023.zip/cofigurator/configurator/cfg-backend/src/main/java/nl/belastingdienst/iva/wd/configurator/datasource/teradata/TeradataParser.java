package nl.belastingdienst.iva.wd.configurator.datasource.teradata;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import nl.belastingdienst.iva.wd.configurator.dto.DatasourceViewDto;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class TeradataParser {

    private static final Logger LOGGER = LogManager.getLogger(TeradataParser.class);

    private static final String VIEW_QUERY = "SELECT c.TableName, c.ColumnName FROM dbc.Columns c " +
            "WHERE c.DatabaseName = ? ORDER BY c.TableName ASC, c.ColumnId ASC";

    private static final String COLUMNS_PER_QUERY = "SELECT c.ColumnName FROM dbc.Columns c " +
            "WHERE c.DatabaseName = ? AND c.TableName = ? ORDER BY c.ColumnId ASC";

    @Value("${spring.td.datasource.database}")
    private String database;

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public TeradataParser(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Collection<String> getTeradataViewColumns(String viewName) {
        return this.jdbcTemplate.query(COLUMNS_PER_QUERY, new Object[]{this.database, viewName},
                (rs, rowNum) -> rs.getString("ColumnName").trim());
    }

    public Collection<DatasourceViewDto> getTeradataViews() {
        Map<String, DatasourceViewDto> datasourceViewDtoMap = new HashMap<>();
        this.jdbcTemplate.query(VIEW_QUERY, new Object[]{this.database}, (rs, rowNum) -> {
            String viewName = rs.getString("TableName").trim();
            String columnName = rs.getString("ColumnName").trim();

            datasourceViewDtoMap.computeIfAbsent(viewName, k -> new DatasourceViewDto(viewName));
            DatasourceViewDto datasourceViewDto = datasourceViewDtoMap.get(viewName);
            datasourceViewDto.addColumnName(columnName);
            return null;
        });

        List<DatasourceViewDto> datasourceViewDtoList = new ArrayList<>();
        datasourceViewDtoList.addAll(datasourceViewDtoMap.values());
        datasourceViewDtoList.sort(Comparator.comparing(DatasourceViewDto::getViewName));

        return datasourceViewDtoList;
    }

    public String getQueryValidation(String queryTemplate) throws JsonProcessingException {
        String widgetQuery = queryTemplate.replace("{teradataSchema:config}", database);
        try {
            List<Map<String, Object>> queryResult = jdbcTemplate.queryForList(widgetQuery);
            ObjectMapper om = new ObjectMapper();
            return om.writeValueAsString(queryResult);
        } catch (Exception e) {
            String message = "Query is niet goed gedefineerd. Er is een fout opgetreden: ";
            LOGGER.error(message, e);
            return (message + e.getMessage());
        }

    }

}
