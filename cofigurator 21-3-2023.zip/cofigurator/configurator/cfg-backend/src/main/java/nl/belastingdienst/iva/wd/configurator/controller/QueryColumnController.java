package nl.belastingdienst.iva.wd.configurator.controller;

import nl.belastingdienst.iva.wd.configurator.dao.QueryColumnRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/querycolumn")
public class QueryColumnController {

    @Autowired
    private QueryColumnRepository queryColumnRepository;

    @GetMapping("/types")
    public ResponseEntity<List<String>> getQueryColumnTypes() {
        return ResponseEntity.ok(queryColumnRepository.findAllQueryColumnTypes());
    }
}