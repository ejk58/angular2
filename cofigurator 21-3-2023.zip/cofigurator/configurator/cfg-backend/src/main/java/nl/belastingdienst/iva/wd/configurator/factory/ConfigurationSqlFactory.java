package nl.belastingdienst.iva.wd.configurator.factory;

import org.springframework.stereotype.Component;

@Component
public class ConfigurationSqlFactory {

    private static final String DELETE_TABLE_FOR_DOMAIN_SQL = "DELETE FROM \"%1$s\" WHERE %2$s = (SELECT ID FROM CONF_DOMAIN WHERE KEY = '%3$s');" + SqlFactoryConstants.NEWLINE;
    private static final String DELETE_PAGE_CHILD_TABLE_SQL = "DELETE FROM \"%1$s\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P JOIN CONF_DOMAIN D ON P.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = '%2$s');" + SqlFactoryConstants.NEWLINE;
    private static final String DELETE_WIDGETCOLUMN_CHILD_TABLE_SQL = "DELETE FROM \"%1$s\" WHERE WIDGET_COLUMN_ID IN (SELECT WC.ID FROM CONF_WIDGET_COLUMN WC JOIN CONF_WIDGET W ON WC.WIDGET_ID = W.ID JOIN CONF_DOMAIN D ON W.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = '%2$s');" + SqlFactoryConstants.NEWLINE;
    private static final String DELETE_WIDGET_CHILD_TABLE_SQL = "DELETE FROM \"%1$s\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W JOIN CONF_DOMAIN D ON W.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = '%2$s');" + SqlFactoryConstants.NEWLINE;
    private static final String DELETE_ATTRIBUTE_TABLE_SQL = "DELETE FROM \"%1$s\" WHERE ATTRIBUTE_GROUP_ID IN (SELECT AG.ID FROM CONF_ATTRIBUTE_GROUP AG JOIN CONF_DOMAIN D ON AG.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = '%2$s');" + SqlFactoryConstants.NEWLINE;
    private static final String DELETE_RULE_TABLE_SQL = "DELETE FROM \"%1$s\" WHERE RULE_GROUP_ID IN (SELECT RG.ID FROM CONF_RULE_GROUP RG JOIN CONF_DOMAIN D ON RG.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = '%2$s');" + SqlFactoryConstants.NEWLINE;
    private static final String DELETE_QUERYCOLUMN_TABLE_1_SQL = "DELETE FROM \"%1$s\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC2.ID FROM CONF_QUERY_COLUMN QC2 JOIN CONF_QUERY_COLUMN QC ON QC2.COMPOSITE_COLUMN_ID = QC.ID JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID JOIN CONF_DOMAIN D ON Q.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = '%2$s');" + SqlFactoryConstants.NEWLINE;
    private static final String DELETE_QUERYCOLUMN_TABLE_2_SQL = "DELETE FROM \"%1$s\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC.ID FROM CONF_QUERY_COLUMN QC JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID JOIN CONF_DOMAIN D ON Q.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = '%2$s');" + SqlFactoryConstants.NEWLINE;
    private static final String DELETE_QUERY_CHILD_TABLE_SQL = "DELETE FROM \"%1$s\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q JOIN CONF_DOMAIN D ON Q.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = '%2$s');" + SqlFactoryConstants.NEWLINE;
    private static final String UPDATE_DOMAIN_TABLE_SQL = "UPDATE \"CONF_DOMAIN\" SET SUBJECT_QUERY_ID = NULL, RELATION_VIP_QUERY_ID = NULL, RELATION_NOVIP_QUERY_ID = NULL, SEARCH_VIP_QUERY_ID = NULL, SEARCH_NOVIP_QUERY_ID = NULL WHERE KEY = '%1$s';" + SqlFactoryConstants.NEWLINE;
    private static final String OWNER_DOMAIN_ID = "OWNER_DOMAIN_ID";
    private static final String DOMAIN_ID = "DOMAIN_ID";
    private static final String CONF_QUERY_COLUMN = "CONF_QUERY_COLUMN";

    public String getDeleteScript(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(getDeleteScriptForDomainConfiguration(domainId));
        return sqlBuilder.toString();
    }

    private StringBuilder getDeleteScriptForDomainConfiguration(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(getDeleteScriptForPage(domainId));
        sqlBuilder.append(getDeleteScriptForWidget(domainId));
        sqlBuilder.append(getDeleteScriptForDomain(domainId));
        sqlBuilder.append(getDeleteScriptForHelp(domainId));
        sqlBuilder.append(getDeleteScriptForAttribute(domainId));
        sqlBuilder.append(getDeleteScriptForRule(domainId));
        sqlBuilder.append(getDeleteScriptForQuery(domainId));
        return sqlBuilder;
    }

    private StringBuilder getDeleteScriptForPage(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(String.format(DELETE_PAGE_CHILD_TABLE_SQL, "CONF_PAGE_PATHKEY", domainId));
        sqlBuilder.append(String.format(DELETE_PAGE_CHILD_TABLE_SQL, "CONF_PAGE_WIDGET", domainId));
        sqlBuilder.append(String.format(DELETE_PAGE_CHILD_TABLE_SQL, "CONF_PAGE_DOMAIN", domainId));
        sqlBuilder.append(String.format(DELETE_PAGE_CHILD_TABLE_SQL, "CONF_PAGE_ATTRIBUTE", domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_PAGE", OWNER_DOMAIN_ID, domainId));
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        return sqlBuilder;
    }

    private StringBuilder getDeleteScriptForWidget(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(String.format(DELETE_WIDGETCOLUMN_CHILD_TABLE_SQL, "CONF_WIDGET_COLUMN_ATTRIBUTE", domainId));
        sqlBuilder.append(String.format(DELETE_WIDGET_CHILD_TABLE_SQL, "CONF_WIDGET_COLUMN", domainId));
        sqlBuilder.append(String.format(DELETE_WIDGET_CHILD_TABLE_SQL, "CONF_WIDGET_HELP", domainId));
        sqlBuilder.append(String.format(DELETE_WIDGET_CHILD_TABLE_SQL, "CONF_WIDGET_ATTRIBUTE", domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_WIDGET", OWNER_DOMAIN_ID, domainId));
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        return sqlBuilder;
    }

    private StringBuilder getDeleteScriptForDomain(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_DOMAIN_ROLE", DOMAIN_ID, domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_DOMAIN_PATHKEY", DOMAIN_ID, domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_DOMAIN_MENUGROUP", DOMAIN_ID, domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_DOMAIN_ATTRIBUTE", DOMAIN_ID, domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_DOMAIN_SUBJECTTYPE", DOMAIN_ID, domainId));
        sqlBuilder.append(String.format(UPDATE_DOMAIN_TABLE_SQL, domainId));
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        return sqlBuilder;
    }

    private StringBuilder getDeleteScriptForHelp(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_HELP", OWNER_DOMAIN_ID, domainId));
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        return sqlBuilder;
    }

    private StringBuilder getDeleteScriptForAttribute(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(String.format(DELETE_ATTRIBUTE_TABLE_SQL, "CONF_ATTRIBUTE", domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_ATTRIBUTE_GROUP", OWNER_DOMAIN_ID, domainId));
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        return sqlBuilder;
    }

    private StringBuilder getDeleteScriptForRule(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(String.format(DELETE_RULE_TABLE_SQL, "CONF_RULE", domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_RULE_GROUP", OWNER_DOMAIN_ID, domainId));
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        return sqlBuilder;
    }

    private StringBuilder getDeleteScriptForQuery(String domainId) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(String.format(DELETE_QUERYCOLUMN_TABLE_1_SQL, CONF_QUERY_COLUMN, domainId));
        sqlBuilder.append(String.format(DELETE_QUERYCOLUMN_TABLE_2_SQL, CONF_QUERY_COLUMN, domainId));
        sqlBuilder.append(String.format(DELETE_QUERY_CHILD_TABLE_SQL, CONF_QUERY_COLUMN, domainId));
        sqlBuilder.append(String.format(DELETE_QUERY_CHILD_TABLE_SQL, "CONF_QUERY_FILTER", domainId));
        sqlBuilder.append(String.format(DELETE_QUERY_CHILD_TABLE_SQL, "CONF_QUERY_ATTRIBUTE", domainId));
        sqlBuilder.append(String.format(DELETE_TABLE_FOR_DOMAIN_SQL, "CONF_QUERY", OWNER_DOMAIN_ID, domainId));
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        return sqlBuilder;
    }
}
