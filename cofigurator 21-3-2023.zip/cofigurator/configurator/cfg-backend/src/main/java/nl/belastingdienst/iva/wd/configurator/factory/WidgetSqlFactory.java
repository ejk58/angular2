package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.*;
import nl.belastingdienst.iva.wd.configurator.util.ExportUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class WidgetSqlFactory {

    private static final String CONF_WIDGET = "CONF_WIDGET";
    private static final String CONF_DOMAIN = "CONF_DOMAIN";
    private final QuerySqlFactory querySqlFactory;

    @Autowired
    public WidgetSqlFactory(QuerySqlFactory querySqlFactory) {
        this.querySqlFactory = querySqlFactory;
    }

    public String getInsertScript(Widget widget, String ownerDomainKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getSingleWidgetInsertScript(widget, ownerDomainKey));
        for (Widget innerWidget : widget.getWidgetList()) {
            if (innerWidget.getOwnerDomain() != null && innerWidget.getOwnerDomain().getKey().equals(ownerDomainKey)) {
                // recursion to create the sql for all inner widgets
                sqlBuilder.append(getInsertScript(innerWidget, ownerDomainKey));
            }
        }
        return sqlBuilder.toString();
    }

    public String getUpdateScript(Widget widget) {
        String widgetName = widget.getName();
        Query query = widget.getQuery();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getDeleteScriptForWidgetProperties(widgetName));

        if (query != null) {
            sqlBuilder.append(SqlFactoryConstants.NEWLINE);
            sqlBuilder.append(this.querySqlFactory.getUpdateScript(query));
            sqlBuilder.append(SqlFactoryConstants.NEWLINE);
            sqlBuilder.append(getPrefixScriptForWidget(widgetName));
        }

        sqlBuilder.append(getMergeScriptForWidget(widget));
        sqlBuilder.append(getInsertScriptForWidgetProperties(widget));

        return sqlBuilder.toString();
    }

    public String getDeleteScript(Widget widget) {
        String widgetName = widget.getName();
        Query query = widget.getQuery();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getDeleteScriptForWidgetProperties(widgetName));
        sqlBuilder.append(getDeleteScriptForWidget(widgetName));

        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        if (query != null) {
            sqlBuilder.append(this.querySqlFactory.getDeleteScript(query));
        }

        return sqlBuilder.toString();
    }

    private String getPrefixScriptForWidget(String widgetName) {
        return String.format(SqlFactoryConstants.DETAIL_COMMENT_LINE, "Widget", widgetName);
    }

    private String getPrefixScriptForDeleteWidget(String widgetName) {
        return String.format(SqlFactoryConstants.DETAIL_COMMENT_LINE, "Delete", widgetName);
    }

    private String getPrefixScriptForHelp(String helpName) {
        return String.format(SqlFactoryConstants.DETAIL_COMMENT_LINE, "Help", helpName);
    }

    private String getPrefixScriptForRuleGroup(String ruleGroupName) {
        return String.format(SqlFactoryConstants.DETAIL_COMMENT_LINE, "Rule-group", ruleGroupName);
    }

    private String getSingleWidgetInsertScript(Widget widget, String ownerDomainKey) {
        String widgetName = widget.getName();
        StringBuilder sqlBuilder = new StringBuilder();

        RuleGroup ruleGroup = widget.getRuleGroup();
        if (ruleGroup != null && ruleGroup.getOwnerDomain() != null && ruleGroup.getOwnerDomain().getKey().equals(ownerDomainKey)) {
            sqlBuilder.append(getMergeScriptForRuleGroup(widget.getRuleGroup()));
        }

        if (widget.getHelpList() != null) {
            widget.getHelpList().stream().forEach(widgetHelp -> {
                Help help = widgetHelp.getHelp();
                if (help != null && help.getOwnerDomain() != null && help.getOwnerDomain().getKey().equals(ownerDomainKey)) {
                    sqlBuilder.append(getMergeScriptForWidgetHelp(help));
                }
            });
        }

        Query query = widget.getQuery();
        if (query != null && query.getOwnerDomain() != null && query.getOwnerDomain().getKey().equals(ownerDomainKey)) {
            sqlBuilder.append(this.querySqlFactory.getInsertScript(query));
        }

        sqlBuilder.append(getPrefixScriptForWidget(widgetName));
        sqlBuilder.append(getMergeScriptForWidget(widget));
        sqlBuilder.append(getInsertScriptForWidgetProperties(widget));
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getMergeScriptForWidget(Widget widget) {
        Query query = widget.getQuery();
        String queryKey = query == null ? null : query.getKey();
        Domain ownerDomain = widget.getOwnerDomain();
        String ownerDomainKey = ownerDomain == null ? null : ownerDomain.getKey();
        Widget containerWidget = widget.getContainerWidget();
        String containerWidgetName = containerWidget == null ? null : containerWidget.getName();
        RuleGroup ruleGroup = widget.getRuleGroup();
        String ruleGroupKey = ruleGroup == null ? null : ruleGroup.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("MERGE INTO \"CONF_WIDGET\" AS W USING (VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_QUERY", "KEY", queryKey) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_RULE_GROUP", "KEY", ruleGroupKey) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_WIDGET, "NAME", containerWidgetName) + ", ");
        sqlBuilder.append(widget.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getString(widget.getName()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widget.getType()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widget.getTitle()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widget.getDescription()) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(widget.isRefreshinfo()) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(widget.isVisible()) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_DOMAIN, "KEY", ownerDomainKey));
        sqlBuilder.append(")) AS X(QUERY_ID, RULE_GROUP_ID, CONTAINER_WIDGET_ID, INDEX, NAME, TYPE, TITLE, DESCRIPTION, REFRESHINFO, VISIBLE, OWNER_DOMAIN_ID) ON W.NAME = X.NAME" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN MATCHED THEN UPDATE SET QUERY_ID = X.QUERY_ID, RULE_GROUP_ID = X.RULE_GROUP_ID, CONTAINER_WIDGET_ID = X.CONTAINER_WIDGET_ID, INDEX = X.INDEX, NAME = X.NAME, TYPE = X.TYPE, TITLE = X.TITLE, DESCRIPTION = X.DESCRIPTION, REFRESHINFO = X.REFRESHINFO, VISIBLE = X.VISIBLE, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN NOT MATCHED THEN INSERT (QUERY_ID, RULE_GROUP_ID, CONTAINER_WIDGET_ID, INDEX, NAME, TYPE, TITLE, DESCRIPTION, REFRESHINFO, VISIBLE, OWNER_DOMAIN_ID) VALUES (X.QUERY_ID, X.RULE_GROUP_ID, X.CONTAINER_WIDGET_ID, X.INDEX, X.NAME, X.TYPE, X.TITLE, X.DESCRIPTION, X.REFRESHINFO, X.VISIBLE, X.OWNER_DOMAIN_ID);" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getMergeScriptForWidgetHelp(Help help) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(getPrefixScriptForHelp(help.getKey()));
        sqlBuilder.append("MERGE INTO \"CONF_HELP\" AS H USING (VALUES ('");
        sqlBuilder.append(help.getKey() + "', '");
        sqlBuilder.append(help.getTitle() + "', '");
        sqlBuilder.append(help.getContent() + "', ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_DOMAIN, "KEY", help.getOwnerDomain().getKey()));
        sqlBuilder.append(")) AS X(KEY, TITLE, CONTENT, OWNER_DOMAIN_ID) ON H.KEY = X.KEY" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN MATCHED THEN UPDATE SET KEY = X.KEY, TITLE = X.TITLE, CONTENT = X.CONTENT, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN NOT MATCHED THEN INSERT (KEY, TITLE, CONTENT, OWNER_DOMAIN_ID) VALUES (X.KEY, X.TITLE, X.CONTENT, X.OWNER_DOMAIN_ID);" + SqlFactoryConstants.NEWLINE + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getMergeScriptForRuleGroup(RuleGroup ruleGroup) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(getPrefixScriptForRuleGroup(ruleGroup.getKey()));
        sqlBuilder.append("MERGE INTO \"CONF_RULE_GROUP\" AS RG USING (VALUES ('");
        sqlBuilder.append(ruleGroup.getKey() + "', ");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_DOMAIN, "KEY", ruleGroup.getOwnerDomain().getKey()));
        sqlBuilder.append(")) AS X(KEY, OWNER_DOMAIN_ID) ON RG.KEY = X.KEY" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN MATCHED THEN UPDATE SET KEY = X.KEY, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN NOT MATCHED THEN INSERT (KEY, OWNER_DOMAIN_ID) VALUES (X.KEY, X.OWNER_DOMAIN_ID);" + SqlFactoryConstants.NEWLINE);

        if (ruleGroup.getRuleList() != null) {
            ruleGroup.getRuleList().stream().forEach(rule -> sqlBuilder.append(getInsertScriptForRule(ruleGroup.getKey(), rule)));
        }

        sqlBuilder.append(SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForRule(String ruleGroupKey, Rule rule) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("INSERT INTO \"CONF_RULE\"(RULE_GROUP_ID, INDEX, VALUE) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_RULE_GROUP", "KEY", ruleGroupKey) + ", ");
        sqlBuilder.append(rule.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getString(rule.getValue()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getDeleteScriptForWidget(String widgetName) {
        return "DELETE FROM \"CONF_WIDGET\" WHERE NAME = '" + widgetName + "';" + SqlFactoryConstants.NEWLINE;
    }

    private String getInsertScriptForWidgetProperties(Widget widget) {
        String widgetName = widget.getName();
        Query query = widget.getQuery();
        StringBuilder sqlBuilder = new StringBuilder();

        if (widget.getAttributeList() != null) {
            widget.getAttributeList().stream().forEach(widgetAttribute -> sqlBuilder.append(getInsertScriptForWidgetAttribute(widgetName, widgetAttribute)));
        }

        if (widget.getColumnList() != null) {
            widget.getColumnList().stream().forEach(widgetColumn -> sqlBuilder.append(getInsertScriptForWidgetColumn(widgetName, query.getKey(), widgetColumn)));
        }

        if (widget.getHelpList() != null) {
            widget.getHelpList().stream().forEach(widgetHelp -> sqlBuilder.append(getInsertScriptForWidgetHelp(widgetName, widgetHelp)));
        }

        return sqlBuilder.toString();
    }

    private String getDeleteScriptForWidgetProperties(String widgetName) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForDeleteWidget(widgetName));
        sqlBuilder.append("DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\" WHERE WIDGET_COLUMN_ID IN (SELECT WC.ID FROM CONF_WIDGET_COLUMN WC JOIN CONF_WIDGET W ON WC.WIDGET_ID = W.ID WHERE W.NAME = '" + widgetName + "');");
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("DELETE FROM \"CONF_WIDGET_COLUMN\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = '" + widgetName + "');");
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("DELETE FROM \"CONF_WIDGET_HELP\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = '" + widgetName + "');");
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("DELETE FROM \"CONF_WIDGET_ATTRIBUTE\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = '" + widgetName + "');");
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);
        return sqlBuilder.toString();
    }

    private String getInsertScriptForWidgetColumn(String widgetName, String queryKey, WidgetColumn widgetColumn) {
        List<WidgetColumnAttribute> widgetColumnAttributes = widgetColumn.getColumnAttributeList();
        QueryColumn queryColumn = widgetColumn.getQueryColumn();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_COLUMN\"(WIDGET_ID, QUERY_COLUMN_ID, INDEX, TYPE, LABEL, DESCRIPTION, BEHAVIOUR, FILTER) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_WIDGET, "NAME", widgetName) + ", ");
        sqlBuilder.append("(SELECT qc.ID FROM CONF_QUERY_COLUMN qc JOIN CONF_QUERY q ON q.ID = qc.QUERY_ID WHERE q.KEY = '" + queryKey + "' AND qc.INDEX = " + queryColumn.getIndex() + "), ");
        sqlBuilder.append(widgetColumn.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getType()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getLabel()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getDescription()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getBehaviour()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getFilter()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        if (widgetColumnAttributes != null) {
            widgetColumnAttributes.stream()
                    .forEach(widgetColumnAttribute -> sqlBuilder.append(getInsertScriptForWidgetColumnAttribute(widgetColumnAttribute, widgetName, widgetColumn.getIndex())));
        }

        return sqlBuilder.toString();
    }

    private String getInsertScriptForWidgetColumnAttribute(WidgetColumnAttribute widgetColumnAttribute, String widgetName, int widgetColumnIndex) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_COLUMN_ATTRIBUTE\"(WIDGET_COLUMN_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append("(SELECT ID FROM \"CONF_WIDGET_COLUMN\" WHERE WIDGET_ID = " + ExportUtils.getSelectId(CONF_WIDGET, "NAME", widgetName) + " AND INDEX = " + widgetColumnIndex + "), ");
        sqlBuilder.append(ExportUtils.getString(widgetColumnAttribute.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumnAttribute.getValue()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForWidgetAttribute(String widgetName, WidgetAttribute widgetAttribute) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_ATTRIBUTE\"(WIDGET_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_WIDGET, "NAME", widgetName) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetAttribute.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetAttribute.getValue()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForWidgetHelp(String widgetName, WidgetHelp widgetHelp) {
        Help help = widgetHelp.getHelp();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_HELP\"(WIDGET_ID, INDEX, HELP_ID) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_WIDGET, "NAME", widgetName) + ", ");
        sqlBuilder.append(widgetHelp.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_HELP", "KEY", help.getKey()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }
}
