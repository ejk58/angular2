package nl.belastingdienst.iva.wd.configurator.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_HELP")
public class Help {

	@Id
	@JsonProperty(required = true)
	private int id;

	@JsonProperty(required = true)
	private String key;

	@JsonProperty(required = true)
	private String title;

	@JsonProperty(required = true)
	private String content;

	@ManyToOne()
	@JoinColumn(name = "OWNER_DOMAIN_ID")
	private Domain ownerDomain;
}
