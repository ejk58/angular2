package nl.belastingdienst.iva.wd.configurator.domain.exception;

public class NotAllowedDomainChangeException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public NotAllowedDomainChangeException() { super(); }

    public NotAllowedDomainChangeException(String message) { super(message); }
}
