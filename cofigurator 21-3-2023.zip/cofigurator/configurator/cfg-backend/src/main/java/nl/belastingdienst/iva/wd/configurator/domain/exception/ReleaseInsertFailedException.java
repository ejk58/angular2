package nl.belastingdienst.iva.wd.configurator.domain.exception;

public class ReleaseInsertFailedException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public ReleaseInsertFailedException() { super(); }

    public ReleaseInsertFailedException(String message) { super(message); }
}
