package nl.belastingdienst.iva.wd.configurator.domain.exception;

public class ReleaseRollbackFailedException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public ReleaseRollbackFailedException() { super(); }

    public ReleaseRollbackFailedException(String message) { super(message); }
}
