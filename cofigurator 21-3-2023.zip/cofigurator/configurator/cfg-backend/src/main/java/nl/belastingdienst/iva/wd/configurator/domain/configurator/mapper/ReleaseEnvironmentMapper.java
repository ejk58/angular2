package nl.belastingdienst.iva.wd.configurator.domain.configurator.mapper;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.Environment;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Release;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ReleaseEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ReleaseEnvironmentMapper implements RowMapper<ReleaseEnvironment> {

    @Autowired
    private ReleaseMapper releaseMapper;

    @Autowired
    private EnvironmentMapper environmentMapper;

    @Override
    public ReleaseEnvironment mapRow(ResultSet resultSet, int i) throws SQLException {
        ReleaseEnvironment releaseEnvironment = new ReleaseEnvironment();

        Release release = this.releaseMapper.mapRow(resultSet, i);
        releaseEnvironment.setRelease(release);

        Environment environment = this.environmentMapper.mapRow(resultSet, i);
        releaseEnvironment.setEnvironment(environment);

        releaseEnvironment.setDomainKey(resultSet.getString("release_environment_domain_key"));
        releaseEnvironment.setAdministrator(resultSet.getString("release_environment_administrator"));
        releaseEnvironment.setDeploymentDate(resultSet.getTimestamp("release_environment_deployment_date"));

        return releaseEnvironment;
    }

}
