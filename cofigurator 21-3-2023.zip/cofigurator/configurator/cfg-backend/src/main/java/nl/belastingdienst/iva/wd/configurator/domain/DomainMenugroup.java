package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Getter
@Setter
@Entity
@Table(name = "CONF_DOMAIN_MENUGROUP")
public class DomainMenugroup {

    @Id
    @JsonProperty(required = true)
    private int id;

    @JsonProperty(required = true)
    private Integer index;

    @JsonProperty(required = true)
    private String title;

    private String iconname;
}
