package nl.belastingdienst.iva.wd.configurator.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RobotTestsDto {

	@JsonProperty(required = true)
	private String widgetName;

	@JsonProperty(required = true)
	private String domain;

	@JsonProperty(required = true)
	private String page;

	@JsonProperty(required = true)
	private String user;
}
