package nl.belastingdienst.iva.wd.configurator.domain.configurator.mapper;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ChangeReleaseEnvironment;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ReleaseEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ChangeReleaseEnvironmentMapper  implements RowMapper<ChangeReleaseEnvironment> {

    @Autowired
    private ChangeMapper changeMapper;

    @Autowired
    private ReleaseEnvironmentMapper releaseEnvironmentMapper;

    @Override
    public ChangeReleaseEnvironment mapRow(ResultSet resultSet, int i) throws SQLException {
        ChangeReleaseEnvironment changeReleaseEnvironment = new ChangeReleaseEnvironment();

        Change change = this.changeMapper.mapRow(resultSet,i);
        ReleaseEnvironment releaseEnvironment = this.releaseEnvironmentMapper.mapRow(resultSet, i);

        changeReleaseEnvironment.setChange(change);
        changeReleaseEnvironment.setReleaseEnvironment(releaseEnvironment);

        return changeReleaseEnvironment;
    }
}
