package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class ReleaseEnvironment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonIgnore
	private Integer id;

	@JsonProperty(required = true)
	private String domainKey;

	@JsonProperty(required = true)
	private String administrator;

	@JsonProperty(required = true)
	private Date deploymentDate;

	@ManyToOne()
	@JoinColumn(name = "RELEASE_ID")
	@JsonProperty(required = true)
	private Release release;

	@ManyToOne()
	@JoinColumn(name = "ENVIRONMENT_ID")
	@JsonProperty(required = true)
	private Environment environment;
}
