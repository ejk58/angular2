package nl.belastingdienst.iva.wd.configurator.dao;

import nl.belastingdienst.iva.wd.configurator.domain.QueryColumn;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QueryColumnRepository extends CrudRepository<QueryColumn, Integer> {

    @org.springframework.data.jpa.repository.Query("SELECT DISTINCT cqc.type FROM QueryColumn cqc WHERE cqc.type IS NOT NULL ORDER BY cqc.type ASC")
    List<String> findAllQueryColumnTypes();
}