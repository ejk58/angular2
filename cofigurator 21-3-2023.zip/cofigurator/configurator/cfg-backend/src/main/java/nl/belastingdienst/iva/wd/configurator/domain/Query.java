package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "conf_query")
public class Query implements HasOwnerDomain {

	@Id
	@JsonProperty(required = true)
	private Integer id;

	@JsonProperty(required = true)
	private Integer type;

	@JsonProperty(required = true)
	private String viewname;

	@JsonProperty(required = true)
	private String querytemplate;

	@JsonProperty(required = true)
	private String key;

	@OneToMany()
	@JoinColumn(name = "QUERY_ID")
	@OrderBy(value = "index")
    @JsonProperty(required = true)
	private List<QueryColumn> columnList;

	@OneToMany()
	@JoinColumn(name = "QUERY_ID")
    @JsonProperty(required = true)
	private List<QueryFilter> queryFilterList;

	@OneToMany()
	@JoinColumn(name = "QUERY_ID")
	@OrderBy(value = "key")
	private List<QueryAttribute> queryAttributeList;

	@ManyToOne()
	@JoinColumn(name = "DATASOURCE_ID")
    @JsonProperty(required = true)
	private Datasource datasource;

	@ManyToOne()
	@JoinColumn(name = "OWNER_DOMAIN_ID")
	private Domain ownerDomain;
}
