package nl.belastingdienst.iva.wd.configurator.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.configurator.domain.Datasource;

@Repository
public interface DatasourceRepository extends CrudRepository<Datasource, Integer>{

}
