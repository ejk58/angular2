package nl.belastingdienst.iva.wd.configurator.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_DOMAIN_ROLE")
public class DomainRole {

	@Id
	@JsonProperty(required = true)
	private int id;

	@JsonProperty(required = true)
	private String role;

	@JsonProperty(required = true)
	private Integer type;

	@JsonProperty(required = true)
	private Integer vipaccess;
}
