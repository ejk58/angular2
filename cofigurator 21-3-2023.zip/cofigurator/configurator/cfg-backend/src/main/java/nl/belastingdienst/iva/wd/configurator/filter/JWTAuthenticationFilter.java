package nl.belastingdienst.iva.wd.configurator.filter;

import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.configurator.security.JwtUtils;
import nl.belastingdienst.iva.wd.configurator.security.SecurityConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@Slf4j
public class JWTAuthenticationFilter extends BasicAuthenticationFilter {

    protected static final Logger LOGGER = LogManager.getLogger(JWTAuthenticationFilter.class);

    private final JwtUtils jwtUtils;

    public JWTAuthenticationFilter(JwtUtils jwtUtils, AuthenticationManager authenticationManager) {
        super(authenticationManager);
        this.jwtUtils = jwtUtils;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws IOException, ServletException {
        String headerAuthorization = request.getHeader(SecurityConstants.HEADER_AUTHORIZATION);
        if (headerAuthorization != null && headerAuthorization.startsWith(SecurityConstants.TOKEN_PREFIX)) {
            String token = headerAuthorization.replace(SecurityConstants.TOKEN_PREFIX, "");
            String user = jwtUtils.validateJwtToken(token).getSubject();
            SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>()));
        }
        chain.doFilter(request, response);
    }
}