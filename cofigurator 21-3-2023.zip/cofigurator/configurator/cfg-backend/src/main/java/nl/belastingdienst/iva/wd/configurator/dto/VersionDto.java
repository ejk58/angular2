package nl.belastingdienst.iva.wd.configurator.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class VersionDto {

	@JsonProperty(required = true)
	private String version;

	@JsonProperty(required = true)
	private String commitDate;

	@JsonProperty(required = true)
	private String commitId;
}
