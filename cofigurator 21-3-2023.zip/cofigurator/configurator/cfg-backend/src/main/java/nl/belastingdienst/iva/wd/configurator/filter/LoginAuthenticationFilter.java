package nl.belastingdienst.iva.wd.configurator.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.security.LdapPersonAttributesMapper;
import nl.belastingdienst.iva.wd.configurator.domain.ApplicationUser;
import nl.belastingdienst.iva.wd.configurator.security.JwtUtils;
import nl.belastingdienst.iva.wd.configurator.security.SecurityConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class LoginAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    protected static final Logger LOGGER = LogManager.getLogger(LoginAuthenticationFilter.class);

    private final Environment env;
    private final LdapTemplate ldapTemplate;
    private final JwtUtils jwtUtils;
    private final List<String> configuratorGroups;

    public LoginAuthenticationFilter(Environment env, LdapTemplate ldapTemplate, JwtUtils jwtUtils) {
        this.env = env;
        this.ldapTemplate = ldapTemplate;
        this.jwtUtils = jwtUtils;
        this.configuratorGroups = Arrays.asList(env.getRequiredProperty("configurator.groups").split("\\s*,\\s*"));
        setFilterProcessesUrl("/api/login");
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        try {
            ApplicationUser user = new ObjectMapper().readValue(request.getInputStream(), ApplicationUser.class);

            // ldap authentication accepts empty passwords!
            if (user.getPassword().isEmpty()) {
                user.setPassword(null);
            }

            String partitionSuffix = env.getRequiredProperty("ldap.partitionSuffix");

            if (!ldapTemplate.authenticate(partitionSuffix, "(cn=" + user.getUsername() + ")", user.getPassword())) {
                throw new BadCredentialsException("Wrong userid or password");
            }

            if (!userHasAtLeastOneOfRequiredGroups(user.getUsername())) {
                throw new BadCredentialsException("Userid is not connected to any group required to use configurator");
            }

            return new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword(), null);
        } catch (IOException e) {
            String message = "Exception raised while authenticating user: " + e.getMessage();
            LOGGER.warn(message);
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request,
                                            HttpServletResponse response,
                                            FilterChain chain,
                                            Authentication authentication) {
        String token = jwtUtils.generateJwtToken(authentication);
        response.addHeader(SecurityConstants.HEADER_AUTHORIZATION, SecurityConstants.TOKEN_PREFIX + token);
    }

    private boolean userHasAtLeastOneOfRequiredGroups(String userid) {
        LdapPerson ldapPerson = getPerson(userid).get(0);
        List<String> adGroepen = ldapPerson.getAdGroepen().stream().map(String::toLowerCase).collect(Collectors.toList());
        return adGroepen.stream().anyMatch(this.configuratorGroups::contains);
    }

    private List<LdapPerson> getPerson(String userid) {
        LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(1)
            .base(env.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
            .is(userid.trim());
        return ldapTemplate.search(query, new LdapPersonAttributesMapper(null));
    }
}