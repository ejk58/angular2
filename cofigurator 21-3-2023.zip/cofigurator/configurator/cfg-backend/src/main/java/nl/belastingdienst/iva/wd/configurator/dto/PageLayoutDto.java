package nl.belastingdienst.iva.wd.configurator.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import nl.belastingdienst.iva.wd.configurator.domain.ApplicationDomain;
import nl.belastingdienst.iva.wd.configurator.domain.Page;
import nl.belastingdienst.iva.wd.configurator.domain.PageWidget;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class PageLayoutDto {

	@JsonProperty(required = true)
	private Page page;

	@JsonProperty(required = true)
	private List<PageWidget> initialWidgets;

	@JsonProperty(required = true)
	private List<PageWidget> widgets;

	private ApplicationDomain applicationDomain;

	@JsonProperty(required = true)
	private String tag;

	public PageLayoutDto(Page page, List<PageWidget> initialWidgets, List<PageWidget> widgets, String tag) {
		this.page = page;
		this.initialWidgets = initialWidgets;
		this.widgets = widgets;
		this.tag = tag;
	}
}
