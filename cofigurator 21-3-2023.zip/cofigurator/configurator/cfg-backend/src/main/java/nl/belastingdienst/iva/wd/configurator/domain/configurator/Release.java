package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Release {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonProperty(required = true)
	private Integer id;

	@JsonProperty(required = true)
	private String domainKey;

	@JsonProperty(required = true)
	private String tag;

	@JsonProperty(required = true)
	private String administrator;

	@JsonProperty(required = true)
	private Date date;
}
