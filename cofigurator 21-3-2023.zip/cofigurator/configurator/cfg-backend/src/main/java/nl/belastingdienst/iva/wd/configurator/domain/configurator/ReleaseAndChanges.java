package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import lombok.Getter;
import lombok.Setter;
import nl.belastingdienst.iva.wd.configurator.domain.ApplicationDomain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

@Getter
@Setter
public class ReleaseAndChanges {
    @JsonProperty(required = true)
    private List<Change> changes;

    @JsonProperty(required = true)
    private Release release;

    @JsonProperty(required = true)
    private ApplicationDomain applicationDomain;
}


