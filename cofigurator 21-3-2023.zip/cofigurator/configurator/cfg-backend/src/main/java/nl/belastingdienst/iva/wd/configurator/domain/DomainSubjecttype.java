package nl.belastingdienst.iva.wd.configurator.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_DOMAIN_SUBJECTTYPE")
public class DomainSubjecttype {

	@Id
	@JsonProperty(required = true)
	private int id;

	@JsonProperty(required = true)
	private String label;

	@JsonProperty(required = true)
	private String searchkey;

	@JsonProperty(required = true)
	private int index;

	@JsonProperty(required = false)
	private String searchfilter;
}
