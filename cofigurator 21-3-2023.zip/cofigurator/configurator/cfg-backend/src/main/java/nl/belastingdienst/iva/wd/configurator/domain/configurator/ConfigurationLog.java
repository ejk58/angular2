package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class ConfigurationLog {
    private String domainKey;
    private String releaseTag;
    private String administratorname;
    private Date date;
}
