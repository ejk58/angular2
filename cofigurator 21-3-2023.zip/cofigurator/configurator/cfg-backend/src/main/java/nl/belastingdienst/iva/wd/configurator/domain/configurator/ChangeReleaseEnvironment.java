package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChangeReleaseEnvironment {

	@Id
	@JsonIgnore
	private Integer id;

	@JsonProperty(required = true)
	Change change;

	@JsonProperty(required = true)
	ReleaseEnvironment releaseEnvironment;
}
