package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_WIDGET_COLUMN")
public class WidgetColumn {

	@Id
	@JsonProperty(required = true)
	private int id;

	@JsonProperty(required = true)
	private int index;

	@JsonProperty(required = true)
	private String type;

	private String label;

	private String description;

	private String behaviour;

	private String filter;

	@OneToOne
	@JoinColumn(name = "QUERY_COLUMN_ID")
	private QueryColumn queryColumn;

	@OneToMany()
	@JoinColumn(name = "WIDGET_COLUMN_ID")
	private List<WidgetColumnAttribute> columnAttributeList;
}
