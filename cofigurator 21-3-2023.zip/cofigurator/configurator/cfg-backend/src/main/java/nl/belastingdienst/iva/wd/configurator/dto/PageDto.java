package nl.belastingdienst.iva.wd.configurator.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import nl.belastingdienst.iva.wd.configurator.domain.ApplicationDomain;
import nl.belastingdienst.iva.wd.configurator.domain.PageWidget;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class PageDto {

	@JsonProperty(required = true)
	private String key;

	@JsonProperty(required = true)
	private String title;

	@JsonProperty(required = true)
	private List<PageWidget> widgets;

	@JsonProperty(required = true)
	private String type;

	@JsonProperty(required = true)
	private ApplicationDomain applicationDomain;

	@JsonProperty(required = true)
	private String tag;

	public PageDto(String key, String title, List<PageWidget> widgets, String type) {
		this.key = key;
		this.title = title;
		this.widgets = widgets;
		this.type = type;
	}
}
