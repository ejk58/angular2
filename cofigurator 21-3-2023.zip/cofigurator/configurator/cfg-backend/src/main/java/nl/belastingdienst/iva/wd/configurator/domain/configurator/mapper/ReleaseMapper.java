package nl.belastingdienst.iva.wd.configurator.domain.configurator.mapper;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.Release;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ReleaseMapper implements RowMapper<Release> {

    @Override
    public Release mapRow(ResultSet resultSet, int i) throws SQLException {
        Release release = new Release();
        release.setId(resultSet.getInt("release_id"));
        release.setDomainKey(resultSet.getString("release_domain_key"));
        release.setTag(resultSet.getString("release_tag"));
        release.setAdministrator(resultSet.getString("release_administrator"));
        release.setDate(resultSet.getTimestamp("release_date"));
        return release;
    }

}
