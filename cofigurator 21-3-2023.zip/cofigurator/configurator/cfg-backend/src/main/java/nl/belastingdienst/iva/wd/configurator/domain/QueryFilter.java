package nl.belastingdienst.iva.wd.configurator.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_QUERY_FILTER")
public class QueryFilter {

	@Id
	@JsonProperty(required = true)
	private Integer id;

    private String key;

    private String parameter;

	@Column(name = "FILTERTEMPLATE")
	@JsonProperty(required = true)
	private String filterTemplate;

	@Column(name = "NOFILTERTEMPLATE")
	private String noFilterTemplate;
}
