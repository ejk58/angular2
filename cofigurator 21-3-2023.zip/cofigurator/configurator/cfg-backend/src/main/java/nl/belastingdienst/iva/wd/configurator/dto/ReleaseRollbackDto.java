package nl.belastingdienst.iva.wd.configurator.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import nl.belastingdienst.iva.wd.configurator.domain.ApplicationDomain;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Release;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class ReleaseRollbackDto {

	@JsonProperty(required = true)
	private String environment;

	@JsonProperty(required = true)
	private Release currentRelease;

	@JsonProperty(required = true)
	private ApplicationDomain applicationDomain;
}
