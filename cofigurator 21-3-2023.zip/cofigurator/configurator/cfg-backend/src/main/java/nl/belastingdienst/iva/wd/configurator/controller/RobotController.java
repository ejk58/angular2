package nl.belastingdienst.iva.wd.configurator.controller;

import nl.belastingdienst.iva.wd.configurator.dao.WidgetRepository;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.domain.robot.*;
import nl.belastingdienst.iva.wd.configurator.dto.RobotTestsDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/robot")
public class RobotController {

    @Autowired
    private WidgetRepository widgetRepository;

    @PostMapping(value = "/export")
    public ResponseEntity<String> exportRobotScript(@RequestBody RobotTestsDto robotTestsDto) {
        Widget widget = widgetRepository.findByName(robotTestsDto.getWidgetName());

        StringBuilder robotBuilder = new StringBuilder();
        robotBuilder.append(RobotTestSettings.toRobot(widget, robotTestsDto));
        robotBuilder.append("\n\n");
        robotBuilder.append(RobotTestVariables.toRobot(widget, robotTestsDto));
        robotBuilder.append("\n\n");
        robotBuilder.append(RobotTestCases.toRobot());
        robotBuilder.append("\n\n");
        robotBuilder.append(RobotTestCheckWidgetOptions.toRobot(widget));
        robotBuilder.append("\n\n");
        robotBuilder.append(RobotTestCheckNumberOfDataRecords.toRobot());

        return ResponseEntity.ok(robotBuilder.toString());
    }

}
