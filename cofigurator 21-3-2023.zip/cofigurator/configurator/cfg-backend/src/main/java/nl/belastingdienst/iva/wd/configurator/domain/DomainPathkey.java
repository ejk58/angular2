package nl.belastingdienst.iva.wd.configurator.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_DOMAIN_PATHKEY")
public class DomainPathkey {

	@Id
	@JsonProperty(required = true)
	private int id;

	@JsonProperty(required = true)
	private String key;

	@JsonProperty(required = true)
	private String name;

	@JsonProperty(required = true)
	private String title;

	@JsonProperty(required = true)
	private String type;

	@JsonProperty(required = true)
	private Integer index;

	@JsonProperty(required = true)
	private Integer mandatory;
}
