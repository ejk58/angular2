package nl.belastingdienst.iva.wd.configurator.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "CONF_DOMAIN")
public class Domain {

    @Id
    @JsonProperty(required = true)
    private Integer id;

    @JsonProperty(required = true)
    private String key;

    @JsonProperty(required = true)
    private String name;

    @JsonProperty(required = true)
    private Integer index;

    private String iconname;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RELATION_QUERY_ID")
    @JsonIgnoreProperties({"ownerDomain"})
    private Query relationQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SEARCH_QUERY_ID")
    @JsonIgnoreProperties({"ownerDomain"})
    private Query searchQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SUBJECT_QUERY_ID")
    @JsonIgnoreProperties({"ownerDomain"})
    private Query subjectQuery;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "key")
    private List<DomainAttribute> domainAttributeList;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "index")
    private List<DomainMenugroup> domainMenugroupList;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "index")
    private List<DomainPathkey> domainPathkeyList;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "role")
    private List<DomainRole> domainRoleList;

    @OneToMany()
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "label")
    private List<DomainSubjecttype> domainSubjecttypeList;
}
