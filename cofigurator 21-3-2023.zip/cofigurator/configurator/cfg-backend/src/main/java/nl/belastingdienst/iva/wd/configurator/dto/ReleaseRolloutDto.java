package nl.belastingdienst.iva.wd.configurator.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import nl.belastingdienst.iva.wd.configurator.domain.ApplicationDomain;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ReleaseRolloutInfo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class ReleaseRolloutDto {

	@JsonProperty(required = true)
	private String environment;

	@JsonProperty(required = true)
	private ReleaseRolloutInfo releaseRolloutInfo;

	@JsonProperty(required = true)
	private ApplicationDomain applicationDomain;
}
