package nl.belastingdienst.iva.wd.configurator.domain.exception;

public class ChangeDeleteFailedException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public ChangeDeleteFailedException() { super(); }

    public ChangeDeleteFailedException(String message) { super(message); }
}
