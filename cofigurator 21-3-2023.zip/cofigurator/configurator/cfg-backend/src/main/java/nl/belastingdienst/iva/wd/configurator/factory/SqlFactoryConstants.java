package nl.belastingdienst.iva.wd.configurator.factory;

public abstract class SqlFactoryConstants {

    public static final String NEWLINE = "\n";
    public static final String DETAIL_COMMENT_LINE = "-- %1$s %2$s " + NEWLINE;

    private SqlFactoryConstants() {
    }
}
