package nl.belastingdienst.iva.wd.configurator.controller;

import nl.belastingdienst.iva.wd.configurator.datasource.configurator.ConfiguratorEnvironmentRepository;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/environment")
public class EnvironmentController {
    @Autowired
    private ConfiguratorEnvironmentRepository configuratorEnvironmentRepository;


    @GetMapping()
    public ResponseEntity<List<Environment>> getEnvironments() {
        List<Environment> environments = configuratorEnvironmentRepository.getEnvironments();
        return ResponseEntity.ok(environments);
    }
}
