package nl.belastingdienst.iva.wd.configurator.controller;

import com.fasterxml.jackson.core.JsonProcessingException;

import nl.belastingdienst.iva.wd.configurator.dao.DatasourceRepository;
import nl.belastingdienst.iva.wd.configurator.dao.QueryRepository;
import nl.belastingdienst.iva.wd.configurator.datasource.teradata.TeradataParser;
import nl.belastingdienst.iva.wd.configurator.domain.Datasource;
import nl.belastingdienst.iva.wd.configurator.dto.DatasourceViewDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value = "/api/datasources")
public class DatasourceController {

    @Autowired
    private DatasourceRepository datasourceRepository;

    private final TeradataParser teradataParser;

    @Autowired
    public DatasourceController(TeradataParser teradataParser) {
        this.teradataParser = teradataParser;
    }

    @GetMapping(path = "/views")
    @ResponseBody
    public Collection<DatasourceViewDto> getTDViewRecords() {
        return teradataParser.getTeradataViews();
    }

    @GetMapping(path = "/columns/{viewName}")
    @ResponseBody
    public Collection<String> getTDViewColumns(@PathVariable String viewName) {
        return teradataParser.getTeradataViewColumns(viewName);
    }

    @GetMapping(path = "/validate/{queryTemplate}")
    @ResponseBody
    public String getTDQueryValidation(@PathVariable String queryTemplate) throws JsonProcessingException {
        return teradataParser.getQueryValidation(queryTemplate);
    }
    
    @GetMapping(path = "/types")
    public ResponseEntity<List<Datasource>> getDatasourceTypes() {
        return ResponseEntity.ok((List<Datasource>)datasourceRepository.findAll());
    }

}
