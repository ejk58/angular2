package nl.belastingdienst.iva.wd.configurator.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import nl.belastingdienst.iva.wd.configurator.domain.exception.ChangeDeleteFailedException;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ChangeInsertFailedException;
import nl.belastingdienst.iva.wd.configurator.domain.exception.JWTInvalidException;
import nl.belastingdienst.iva.wd.configurator.domain.exception.NotAllowedDomainChangeException;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ReleaseDeleteFailedException;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ReleaseInsertFailedException;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ReleaseRollbackFailedException;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected String handle(Exception ex) {
        logger.error(ex);
        return ResponseMessages.SERVER_ERROR;
    }

    @ExceptionHandler({AccessDeniedException.class})
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    protected String handleAccessDenied(RuntimeException ex) {
        logger.error(ex);
        return ResponseMessages.UNAUTHORIZED + " " + handleMessage(ex.getMessage());
    }

    @ExceptionHandler(JWTInvalidException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public String handleJWTInvalid(JWTInvalidException ex) {
        logger.error(ex);
        return ResponseMessages.JWT_INVALID;
    }

    @ExceptionHandler(NotAllowedDomainChangeException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public String handleNotAllowedDomainChange(NotAllowedDomainChangeException ex) {
        logger.error(ex);
        return ResponseMessages.NOT_ALLOWED_DOMAIN_CHANGE;
    }

    @ExceptionHandler({ChangeDeleteFailedException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected String handleChangeDeleteFailed(RuntimeException ex) {
        logger.warn(ex);
        return ResponseMessages.CHANGE_DELETE_NOK + " " + handleMessage(ex.getMessage());
    }

    @ExceptionHandler({ReleaseDeleteFailedException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected String handleReleaseDeleteFailed(RuntimeException ex) {
        logger.warn(ex);
        return ResponseMessages.RELEASE_DELETE_NOK + " " + handleMessage(ex.getMessage());
    }

    @ExceptionHandler({ReleaseRollbackFailedException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected String handleReleaseRollbackFailed(RuntimeException ex) {
        logger.warn(ex);
        return ResponseMessages.RELEASE_ROLLBACK_NOK + " " + handleMessage(ex.getMessage());
    }

    @ExceptionHandler({ChangeInsertFailedException.class, ReleaseInsertFailedException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected String handleInsertFailed(RuntimeException ex) {
        logger.warn(ex);
        return handleMessage(ex.getMessage());
    }

	// Had to override this method for handling the HttpMessageNotReadableException.
	// Adding @ExceptionHandler for this exception is not possible because it is already caught in the superclass ResponseEntityExceptionHandler.
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		logger.error(ex);
		return ResponseEntity.badRequest().body(ResponseMessages.REQUEST_INVALID);
	}

    private String handleMessage(String message) {
        return message != null ? message : "";
    }
}
