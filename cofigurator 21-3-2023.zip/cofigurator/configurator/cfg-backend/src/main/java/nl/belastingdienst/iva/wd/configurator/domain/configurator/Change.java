package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Change {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonProperty(required = true)
	private Integer id;

	private Long releaseId;

	@JsonIgnore
	private String domain;

	@JsonProperty(required = true)
	private String domainKey;

	@JsonProperty(required = true)
	private String tag;

	@JsonProperty(required = true)
	private long sequenceNo;

	@JsonProperty(required = true)
	private String administrator;

	@JsonProperty(required = true)
	private Date date;

	@Column(length = 60000)
	@JsonProperty(required = true)
	private String sql;

	@Column(length = 60000)
	@JsonProperty(required = true)
	private String rollbackSql;

	@JsonProperty(required = true)
	private String appVersion;
}
