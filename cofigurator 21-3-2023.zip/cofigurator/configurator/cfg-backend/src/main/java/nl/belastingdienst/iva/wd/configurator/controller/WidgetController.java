package nl.belastingdienst.iva.wd.configurator.controller;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.configurator.constants.DomainConstants;
import nl.belastingdienst.iva.wd.configurator.dao.WidgetAttributeRepository;
import nl.belastingdienst.iva.wd.configurator.dao.WidgetRepository;
import nl.belastingdienst.iva.wd.configurator.domain.ApplicationDomain;
import nl.belastingdienst.iva.wd.configurator.domain.Domain;
import nl.belastingdienst.iva.wd.configurator.domain.HasOwnerDomain;
import nl.belastingdienst.iva.wd.configurator.domain.Query;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ChangeInsertFailedException;
import nl.belastingdienst.iva.wd.configurator.dto.WidgetDtoExtended;
import nl.belastingdienst.iva.wd.configurator.exception.ResponseMessages;
import nl.belastingdienst.iva.wd.configurator.factory.WidgetSqlFactory;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import nl.belastingdienst.iva.wd.configurator.util.ControllerUtils;

@RestController
@RequestMapping("/api/widget")
public class WidgetController extends AbstractController {

    @Autowired
    private WidgetRepository widgetRepository;

    @Autowired
    private WidgetAttributeRepository widgetAttributeRepository;

    @Autowired
    private WidgetSqlFactory widgetSqlFactory;

    @Autowired
    private ApplicationUtils applicationUtils;

    @Autowired
    private ControllerUtils<HasOwnerDomain> controllerUtils;

    @GetMapping(value = "/names")
    public ResponseEntity<List<String>> getWidgetNames() {
        List<String> widgetNames = widgetRepository.findAllWidgetNamesByOrderByNameAsc();
        return ResponseEntity.ok(widgetNames);
    }

    @GetMapping(value = "/names/{domainKey}")
    public ResponseEntity<List<String>> getWidgetNamesForDomain(@PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }
        List<String> widgetNames = widgetRepository.findAllWidgetNamesForDomainOrderByNameAsc(domainKey);
        return ResponseEntity.ok(widgetNames);
    }

    @GetMapping(value = "/names/generic")
    public ResponseEntity<List<String>> getWidgetNamesForGeneric() {
        if (!applicationUtils.userHasAccessToDomain(DomainConstants.ADMIN)) {
            throw new AccessDeniedException(DomainConstants.ADMIN);
        }
        List<String> widgetNames = widgetRepository.findAllWidgetNamesForGenericOrderByNameAsc();
        return ResponseEntity.ok(widgetNames);
    }

    @GetMapping(value = "/names/generic/{domainKey}")
    public ResponseEntity<List<String>> getWidgetNamesForDomainAndGeneric(@PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }
        List<String> widgetNames = widgetRepository.findAllWidgetNamesForDomainAndGenericOrderByNameAsc(domainKey);
        return ResponseEntity.ok(widgetNames);
    }

    @GetMapping(value = "/types")
    public ResponseEntity<List<String>> getWidgetTypes() {
        List<String> widgetTypes = widgetRepository.findAllWidgetTypesByOrderByTypeAsc();
        return ResponseEntity.ok(widgetTypes);
    }

    @GetMapping(value = "/attributekeys")
    public ResponseEntity<List<String>> getWidgetAttributeKeys() {
        List<String> widgetAttributeKeys = widgetAttributeRepository.findAllWidgetAttributeKeysByOrderByKeyAsc();
        return ResponseEntity.ok(widgetAttributeKeys);
    }

    @GetMapping(value = "/{name}")
    public ResponseEntity<Widget> getWidget(@PathVariable String name) {
        Widget widget = widgetRepository.findByName(name);
        return ResponseEntity.ok(widget);
    }

    @Transactional
    @PostMapping(value = "/save")
    public ResponseEntity<String> saveWidget(@RequestBody WidgetDtoExtended widgetDtoExtended) throws SQLException {
        ApplicationDomain applicationDomain = widgetDtoExtended.getApplicationDomain();
        if (!applicationUtils.userHasAccessToDomain(applicationDomain.getDomainId())) {
            throw new AccessDeniedException(applicationDomain.getDomainName());
        }

        if (configuratorChangeRepository.checkUniqueChangeTag(widgetDtoExtended.getTag())) {
            setDomainForWidgetAndQuery(widgetDtoExtended);
            Change change = createAndStoreNewWidget(widgetDtoExtended);
            return handleRolloutChangeOnSourceDatabase(change);
        }

        throw new ChangeInsertFailedException(ResponseMessages.CHANGE_EXISTS);
    }

    private void setDomainForWidgetAndQuery(WidgetDtoExtended widgetDtoExtended) {
        // Setting the domain for the widget and query is done in the backend for security reasons
        Domain ownerDomain = createDomain(widgetDtoExtended.getApplicationDomain().getDomainId());
        widgetDtoExtended.getWidget().setOwnerDomain(ownerDomain);
        if (widgetDtoExtended.getWidget().getQuery() != null) {
            widgetDtoExtended.getWidget().getQuery().setOwnerDomain(ownerDomain);
        }
    }

    private Domain createDomain(String key) {
        Domain domain = new Domain();
        domain.setKey(key);
        return key.equals(DomainConstants.ADMIN) ? null : domain;
    }

    private Change createAndStoreNewWidget(WidgetDtoExtended widgetDtoExtended) {
        ApplicationDomain applicationDomain = widgetDtoExtended.getApplicationDomain();
        Widget widgetOriginal = widgetRepository.findWidgetByName(widgetDtoExtended.getWidget().getName());
        this.controllerUtils.checkForNotAllowedDomainChange(widgetOriginal, applicationDomain.getDomainId());
        Query queryOriginal = widgetOriginal != null ? widgetOriginal.getQuery() : null;
        this.controllerUtils.checkForNotAllowedDomainChange(queryOriginal, applicationDomain.getDomainId());

        Change change = new Change();
        change.setDomain(applicationDomain.getDomainName());
        change.setDomainKey(applicationDomain.getDomainId());
        change.setTag(widgetDtoExtended.getTag());
        change.setSequenceNo(new Date().getTime()); // Sequence number is now just the timestamp so more or less redundant with the date.
        change.setAdministrator(applicationUtils.getUserId());
        change.setDate(new Date());
        change.setSql(this.widgetSqlFactory.getUpdateScript(widgetDtoExtended.getWidget()));
        if (widgetOriginal == null) {
            change.setRollbackSql(this.widgetSqlFactory.getDeleteScript(widgetDtoExtended.getWidget()));
        } else {
            change.setRollbackSql(this.widgetSqlFactory.getUpdateScript(widgetOriginal));
        }

        configuratorChangeRepository.saveChange(change);
        return change;
    }
}
