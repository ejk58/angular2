package nl.belastingdienst.iva.wd.configurator.datasource.configurator;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.ConfigurationLog;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ReleaseEnvironment;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.mapper.ReleaseEnvironmentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ConfiguratorReleaseEnvironmentRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedJdbcTemplateConfigurator;

    @Autowired
    private ReleaseEnvironmentMapper releaseEnvironmentMapper;

    @Value("${configurator.db.schema}")
    private String schema;

    public List<ReleaseEnvironment> getReleaseEnvironments(List<String> domainKeys) {
        String sql = "SELECT re.id, re.domain_key as release_environment_domain_key, re.release_id, re.environment_id, re.administrator as release_environment_administrator, re.deployment_date as release_environment_deployment_date, " +
            "r.id as release_id, r.domain_key as release_domain_key, r.tag as release_tag, r.administrator as release_administrator, r.date as release_date, " +
            "e.name as environment_name, e.type as environment_type " +
            "FROM " + schema + ".release_environment re " +
            "LEFT JOIN " + schema + ".release r ON r.id = re.release_id " +
            "LEFT JOIN " + schema + ".environment e ON e.id = re.environment_id " +
            "WHERE re.domain_key IN (:DOMAIN_KEYS)" +
            "ORDER BY re.DEPLOYMENT_DATE";

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("DOMAIN_KEYS", domainKeys);

        return namedJdbcTemplateConfigurator.query(sql, parameters, releaseEnvironmentMapper);
    }

    public void saveReleaseRollout(ConfigurationLog configurationLog, String environmentName) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("domainKey", configurationLog.getDomainKey());
        paramSource.addValue("releaseTag", configurationLog.getReleaseTag());
        paramSource.addValue("environmentName", environmentName);
        paramSource.addValue("administratorname", configurationLog.getAdministratorname());
        paramSource.addValue("deploymentDate", configurationLog.getDate());

        String sqlStatement =
            "insert into " + schema + ".release_environment (domain_key, release_id, environment_id, administrator, deployment_date) " +
                "values (:domainKey, (select id from " + schema + ".release where tag = :releaseTag), (select id from " + schema + ".environment where name = :environmentName), :administratorname, :deploymentDate)";
        namedJdbcTemplateConfigurator.update(sqlStatement, paramSource);
    }

    public void deleteReleaseRollout(ConfigurationLog configurationLog) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("domainKey", configurationLog.getDomainKey());
        paramSource.addValue("releaseTag", configurationLog.getReleaseTag());

        String sqlStatement =
            "delete from " + schema + ".release_environment where domain_key = :domainKey and release_id = (select id from " + schema + ".release where tag = :releaseTag)";
        namedJdbcTemplateConfigurator.update(sqlStatement, paramSource);
    }

}
