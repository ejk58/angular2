package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.*;
import nl.belastingdienst.iva.wd.configurator.util.ExportUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PageSqlFactory {

    private static final String CONF_PAGE = "CONF_PAGE";

    public String getInsertScript(Page page, List<PageWidget> pageWidgetList) {
        String pageKey = page.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        sqlBuilder.append(getMergeScriptForPage(page));
        sqlBuilder.append(getInsertScriptForPageProperties(page, pageWidgetList));

        return sqlBuilder.toString();
    }

    public String getInsertScriptGenericPage(Page page, String domainId) {
        String pageKey = page.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        if (page.getPageDomainList() != null) {
            page.getPageDomainList().stream().forEach(pageDomain -> {
                if (pageDomain.getDomain().getKey().equals(domainId)) {
                    sqlBuilder.append(getInsertScriptForPageDomain(page, pageDomain));
                }
            });
        }
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    public String getUpdateScript(Page page, List<PageWidget> pageWidgetList) {
        String pageKey = page.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        sqlBuilder.append(getDeleteScriptForPageProperties(pageKey));
        sqlBuilder.append(getMergeScriptForPage(page));
        sqlBuilder.append(getInsertScriptForPageProperties(page, pageWidgetList));

        return sqlBuilder.toString();
    }

    public String getUpdateScript(String pageKey, List<PageWidget> pageWidgetList) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        sqlBuilder.append(getDeleteScriptForPageWidgets(pageKey));
        sqlBuilder.append(getInsertScriptForPageWidgets(pageKey, pageWidgetList));

        return sqlBuilder.toString();
    }

    public String getDeleteScript(Page page) {
        String pageKey = page.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        sqlBuilder.append(getDeleteScriptForPageProperties(pageKey));
        sqlBuilder.append(getDeleteScriptForPage(pageKey));

        return sqlBuilder.toString();
    }

    private String getPrefixScriptForPage(String pageKey) {
        return String.format(SqlFactoryConstants.DETAIL_COMMENT_LINE, "Page", pageKey);
    }

    private String getMergeScriptForPage(Page page) {
        Domain ownerDomain = page.getOwnerDomain();
        String ownerDomainKey = ownerDomain == null ? null : ownerDomain.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("MERGE INTO \"CONF_PAGE\" AS P USING (VALUES (");
        sqlBuilder.append(ExportUtils.getString(page.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(page.getTitle()) + ", ");
        sqlBuilder.append(ExportUtils.getString(page.getType()) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_DOMAIN", "KEY", ownerDomainKey));
        sqlBuilder.append(")) AS X(KEY, TITLE, TYPE, OWNER_DOMAIN_ID) ON P.KEY = X.KEY" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN MATCHED THEN UPDATE SET TITLE = X.TITLE, TYPE = X.TYPE, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("  WHEN NOT MATCHED THEN INSERT (KEY, TITLE, TYPE, OWNER_DOMAIN_ID) VALUES (X.KEY, X.TITLE, X.TYPE, X.OWNER_DOMAIN_ID);" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getDeleteScriptForPage(String pageKey) {
        return "DELETE FROM \"CONF_PAGE\" WHERE KEY = '" + pageKey + "';" + SqlFactoryConstants.NEWLINE;
    }

    private String getInsertScriptForPageProperties(Page page, List<PageWidget> pageWidgetList) {
        String pageKey = page.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        if (page.getPageDomainList() != null) {
            page.getPageDomainList().stream().forEach(pageDomain -> sqlBuilder.append(getInsertScriptForPageDomain(page, pageDomain)));
        }

        if (page.getPagePathkeyList() != null) {
            page.getPagePathkeyList().stream().forEach(pagePathkey -> sqlBuilder.append(getInsertScriptForPagePathkey(page, pagePathkey)));
        }

        if (page.getPageAttributeList() != null) {
            page.getPageAttributeList().stream().forEach(pageAttribute -> sqlBuilder.append(getInsertScriptForPageAttribute(page, pageAttribute)));
        }

        sqlBuilder.append(getInsertScriptForPageWidgets(pageKey, pageWidgetList));

        return sqlBuilder.toString();
    }

    private String getInsertScriptForPageDomain(Page page, PageDomain pageDomain) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_PAGE_DOMAIN\"(PAGE_ID, DOMAIN_ID, GROUP_INDEX, MEMBER_INDEX) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_PAGE, "KEY", page.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_DOMAIN", "KEY", pageDomain.getDomain().getKey()) + ", ");
        sqlBuilder.append(pageDomain.getGroupIndex() + ", ");
        sqlBuilder.append(pageDomain.getMemberIndex());
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForPagePathkey(Page page, PagePathkey pagePathkey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_PAGE_PATHKEY\"(PAGE_ID, NAME) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_PAGE, "KEY", page.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(pagePathkey.getName()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForPageAttribute(Page page, PageAttribute pageAttribute) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_PAGE_ATTRIBUTE\"(PAGE_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_PAGE, "KEY", page.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(pageAttribute.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(pageAttribute.getValue()));
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForPageWidgets(String pageKey, List<PageWidget> pageWidgetList) {
        StringBuilder sqlBuilder = new StringBuilder();

        if (pageWidgetList != null) {
            pageWidgetList.stream().forEach(pageWidget -> sqlBuilder.append(getInsertScriptForPageWidget(pageKey, pageWidget)));
        }
        sqlBuilder.append(SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getDeleteScriptForPageProperties(String pageKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("DELETE FROM \"CONF_PAGE_PATHKEY\" WHERE PAGE_ID = (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append(getDeleteScriptForPageWidgets(pageKey));
        sqlBuilder.append("DELETE FROM \"CONF_PAGE_DOMAIN\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + SqlFactoryConstants.NEWLINE);
        sqlBuilder.append("DELETE FROM \"CONF_PAGE_ATTRIBUTE\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }

    private String getDeleteScriptForPageWidgets(String pageKey) {
        return "DELETE FROM \"CONF_PAGE_WIDGET\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + SqlFactoryConstants.NEWLINE;
    }

    private String getInsertScriptForPageWidget(String pageKey, PageWidget pageWidget) {
        Widget widget = pageWidget.getWidget();
        String widgetName = widget == null ? null : widget.getName();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_PAGE_WIDGET\"(PAGE_ID, WIDGET_ID, GRID_COLUMNS, ROW_INDEX, COLUMN_INDEX) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId(CONF_PAGE, "KEY", pageKey) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_WIDGET", "NAME", widgetName) + ", ");
        sqlBuilder.append(pageWidget.getGridColumns() + ", ");
        sqlBuilder.append(pageWidget.getRowIndex() + ", ");
        sqlBuilder.append(pageWidget.getColumnIndex());
        sqlBuilder.append(");" + SqlFactoryConstants.NEWLINE);

        return sqlBuilder.toString();
    }
}
