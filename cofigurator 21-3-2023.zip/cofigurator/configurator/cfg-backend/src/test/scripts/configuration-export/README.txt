De te vergelijken files opgeven in de eerste 2 regels van de .py file.
Vervolgens draaien met:

	python file-compare.py
	
De files worden vergeleken op basis van de regels in de file waarbij de volgorde van de regels niet van belang is 
en ook de casing ge-ignored wordt.

Omdat er veel verschillen verschijnen die eigenlijk geen echt verschil zijn bij het testen van de erf belasting configuratie file,
is er ook een file-compare-with-substitutions.py die er voor zorgt dat de files beter te vergelijken zijn.
In de file kan je zien welke substitutions gedaan worden, zie method: strip_and_replace(line).