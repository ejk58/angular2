import re

filename1 = 'file1.sql'
filename2 = 'file2.sql'

sortedList1 = list()
sortedList2 = list()

def strip_and_replace(line):
    # remove ", make lowercase, strip and remove - at the left
    line = re.sub('"', '', line.strip().lower().lstrip(' ').rstrip('-'))

    # remove all table aliases
    line = re.sub('select ag.id from conf_rule_group ag where ag.key', 'select id from conf_rule_group where key', line)
    line = re.sub('select rg.id from conf_rule_group rg where rg.key', 'select id from conf_rule_group where key', line)
    line = re.sub('select q.id from conf_query q where q.key', 'select id from conf_query where key', line)
    line = re.sub('select w.id from conf_widget w where w.name', 'select id from conf_widget where name', line)

    # add space when forgotten
    line = re.sub('where key=\'', 'where key = \'', line)
    line = re.sub(',1,', ', 1,', line)
    line = re.sub('\' \);', '\');', line)

    # add rule_group_id and it's value everywhere
    line = re.sub('as x\(query_id, container_widget_id, index', 'as x(query_id, rule_group_id, container_widget_id, index', line)
    line = re.sub('when matched then update set query_id = x.query_id, container_widget_id = x.container_widget_id, index = x.index', 'when matched then update set query_id = x.query_id, rule_group_id = x.rule_group_id, container_widget_id = x.container_widget_id, index = x.index', line)
    line = re.sub('when not matched then insert \(query_id, container_widget_id, index', 'when not matched then insert (query_id, rule_group_id, container_widget_id, index', line)
    line = re.sub('query\'\), \(select id from conf_widget', 'query\'), null, (select id from conf_widget', line)
    line = re.sub('query\'\), null, null, \'', 'query\'), null, null, null, \'', line)
    line = re.sub('query\'\), null, 1, \'', 'query\'), null, null, 1, \'', line)
    line = re.sub('using \(values \(null, null, 1, \'', 'using (values (null, null, null, 1, \'', line)
    line = re.sub('using \(values \(null, null, null, \'', 'using (values (null, null, null, null, \'', line)
    line = re.sub('values \(x.query_id, x.container_widget_id', 'values (x.query_id, x.rule_group_id, x.container_widget_id', line)

    return line

with open (filename1) as fin:
    for line in fin:
        if line.strip():
            sortedList1.append(strip_and_replace(line))

with open (filename2) as fin:
    for line in fin:
        if line.strip():
            sortedList2.append(strip_and_replace(line))

result1 = list(set(sortedList1) - set(sortedList2))
result2 = list(set(sortedList2) - set(sortedList1))

if (len(result1) == 0 and len(result2) == 0):
    print(f'\nFile "{filename1}" en "{filename2}" bevatten dezelfde regels. (volgorde en casing zijn eventueel wel verschillend)\n')
else:
    print (f'\n==\n== VERSCHILLEN IN LOWERCASE van "{filename1}" met "{filename2}":\n==')
    result1.sort()
    for line in result1:
        print(line)

    print (f'\n==\n== VERSCHILLEN IN LOWERCASE van "{filename2}" met "{filename1}":\n==')
    result2.sort()
    for line in result2:
        print(line)
