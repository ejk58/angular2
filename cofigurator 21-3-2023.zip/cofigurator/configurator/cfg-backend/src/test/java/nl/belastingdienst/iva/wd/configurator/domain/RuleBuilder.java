package nl.belastingdienst.iva.wd.configurator.domain;

public class RuleBuilder {

    private Rule rule;

    public RuleBuilder() {
        this.rule = new Rule();
    }

    public Rule build() {
        return this.rule;
    }

    public RuleBuilder withIndex(Integer index) {
        this.rule.setIndex(index);
        return this;
    }

    public RuleBuilder withValue(String value) {
        this.rule.setValue(value);
        return this;
    }

    public static Rule build(Integer index, String value) {
        return new RuleBuilder()
                .withIndex(index)
                .withValue(value)
                .build();
    }

}
