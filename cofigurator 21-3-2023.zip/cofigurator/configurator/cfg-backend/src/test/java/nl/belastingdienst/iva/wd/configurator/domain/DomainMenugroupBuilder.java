package nl.belastingdienst.iva.wd.configurator.domain;


public class DomainMenugroupBuilder {

    private DomainMenugroup domainMenugroup;
    
    public DomainMenugroupBuilder() {
        this.domainMenugroup = new DomainMenugroup();
    }
    
    public DomainMenugroup build() {
        return this.domainMenugroup;
    }

    public DomainMenugroupBuilder withTitle(String title) {
        this.domainMenugroup.setTitle(title);
        return this;
    }

    public DomainMenugroupBuilder withIndex(int index) {
        this.domainMenugroup.setIndex(index);
        return this;
    }

    public DomainMenugroupBuilder withIcon(String iconname) {
        this.domainMenugroup.setIconname(iconname);
        return this;
    }

    public static DomainMenugroup build(String title, Integer index, String iconname) {
        return new DomainMenugroupBuilder()
                .withTitle(title)
                .withIndex(index)
                .withIcon(iconname)
                .build();
    }
}
