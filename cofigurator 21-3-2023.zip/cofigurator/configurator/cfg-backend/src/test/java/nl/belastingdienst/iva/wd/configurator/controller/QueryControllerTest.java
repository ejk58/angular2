package nl.belastingdienst.iva.wd.configurator.controller;


import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.wd.configurator.dao.QueryRepository;
import nl.belastingdienst.iva.wd.configurator.domain.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.ArrayList;
import java.util.List;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@Log4j2
@RunWith(SpringRunner.class)
@WebMvcTest(QueryController.class)
public class QueryControllerTest  extends AbstractControllerTest {

    @MockBean
    QueryRepository queryRepository;

    @MockBean
    ClientHttpRequestFactory clientHttpRequestFactory;

    @Autowired
    private MockMvc mvc;

    static String authorizationValue;

    @Before
    public void setUp() throws Exception {
        authorizationValue = loginIvaall(mvc, status().isOk());
    }

    @Test
    public void getQueryKeysTest() throws Exception {
        given(queryRepository.findAllQueryKeysOrderByNameAsc()).willReturn(createQueryKeys());
        mvc.perform(get("/api/query/keys").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(2)))
            .andExpect(jsonPath("$[0]", is("QKey_1")))
            .andExpect(jsonPath("$[1]", is("QKey_2")));
    }

    @Test
    public void getQueryByKeyTest() throws Exception {
        given(queryRepository.findByKey("QUERY_KEY")).willReturn(createQuery("QUERY_KEY"));
        mvc.perform(get("/api/query/QUERY_KEY").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.key", is("QUERY_KEY" )));
    }

    @Test
    public void getQueryByKeyNothingFoundTest() throws Exception {
        given(queryRepository.findByKey("QUERY_KEY_DOES_NOT_EXIST")).willReturn(createQuery("QUERY_KEY_DOES_NOT_EXIST"));
        MvcResult result = mvc.perform(get("/api/query/QUERY_KEY_DOES_NOT_EXIST").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(""))
                .andReturn();


        // alternative to check the result by testing the MvcResult
        assertNull(result.getResponse().getContentType());
    }

    @Test
    public void getQueryByKeyExceptionTest() throws Exception {
        given(queryRepository.findByKey("QUERY_LEADS_TO_EXCEPTION")).willThrow(new RuntimeException("Something went terrible wrong!"));
        MvcResult result = mvc.perform(get("/api/query/QUERY_LEADS_TO_EXCEPTION").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(content().string("Er is een fout opgetreden op de server."))
                .andReturn();

        // alternative to check the result by testing the MvcResult
        assertEquals("Er is een fout opgetreden op de server.", result.getResponse().getContentAsString());
    }

    private List<String> createQueryKeys() {
        List<String> queryKeyList = new ArrayList<>();
        queryKeyList.add("QKey_1");
        queryKeyList.add("QKey_2");
        return queryKeyList;
    }

    private Query createQuery(String key) throws Exception {
        if (key.equals("QUERY_KEY")) {
            Query query = new Query();
            query.setKey("QUERY_KEY");
            return query;
        } else {
            return null;
        }
    }

}
