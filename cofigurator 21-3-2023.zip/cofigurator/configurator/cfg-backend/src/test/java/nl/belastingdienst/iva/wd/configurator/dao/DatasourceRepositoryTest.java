/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: DatasourceRepositoryTest.java
 *             Auteur: vermr09
 *    Creatietijdstip: 21-2-2022 16:09
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.configurator.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import nl.belastingdienst.iva.wd.configurator.domain.Datasource;

import lombok.extern.log4j.Log4j2;

@RunWith(SpringRunner.class)
@Log4j2
@DataJpaTest
public class DatasourceRepositoryTest {
	@MockBean
	NamedParameterJdbcTemplate namedJdbcTemplateConfigurator;

	@Autowired
	DatasourceRepository datasourceRepository;

	@Test
	public void getDatasources() {
		List<Datasource> datasourceList = (List<Datasource>) this.datasourceRepository.findAll();
		assertEquals(2, datasourceList.size());
		assertEquals(1, datasourceList.get(0).getId());
		assertEquals("Teradata/IVAI", datasourceList.get(0).getKey());
		assertEquals(2, datasourceList.get(1).getId());
		assertEquals("Rest/Inzicht", datasourceList.get(1).getKey());
	}
}
