package nl.belastingdienst.iva.wd.configurator.domain;

public class PageAttributeBuilder {
    private PageAttribute pageAttribute;

    public PageAttributeBuilder() {
        this.pageAttribute = new PageAttribute();
    }

    public PageAttribute build() {
        return this.pageAttribute;
    }

    public PageAttributeBuilder withKey(String key){
        this.pageAttribute.setKey(key);
        return this;
    }

    public PageAttributeBuilder withValue(String value) {
        this.pageAttribute.setValue(value);
        return this;
    }

    public static PageAttribute build(String key, String value) {
        return new PageAttributeBuilder()
                .withKey(key)
                .withValue(value)
                .build();
    }
}
