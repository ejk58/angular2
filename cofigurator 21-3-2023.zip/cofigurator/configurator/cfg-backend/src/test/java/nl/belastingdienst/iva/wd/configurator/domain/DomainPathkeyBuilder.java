package nl.belastingdienst.iva.wd.configurator.domain;

public class DomainPathkeyBuilder {

	private DomainPathkey domainPathkey;

    public DomainPathkeyBuilder() {
        this.domainPathkey = new DomainPathkey();
    }
	
	public DomainPathkey build() {
		return this.domainPathkey;
	}

	public DomainPathkeyBuilder withKey(String key) {
		this.domainPathkey.setKey(key);
		return this;
	}

    public DomainPathkeyBuilder withName(String name) {
        this.domainPathkey.setName(name);
        return this;
    }

    public DomainPathkeyBuilder withTitle(String title){
        this.domainPathkey.setTitle(title);
        return this;
    }
    
    public DomainPathkeyBuilder withType(String type){
        this.domainPathkey.setType(type);
        return this;
    }
    
    public DomainPathkeyBuilder withIndex(int index){
        this.domainPathkey.setIndex(index);
        return this;
    }

    
    public DomainPathkeyBuilder withMandatory(int mandatory) {
        this.domainPathkey.setMandatory(mandatory);
        return this;
    }

    public static DomainPathkey build(String key, String name, String title, String type, int index, int mandatory) {
        return new DomainPathkeyBuilder()
                .withKey(key)
                .withName(name)
                .withTitle(title)
                .withType(type)
                .withIndex(index)
                .withMandatory(mandatory)
                .build();
    }
}
