package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.*;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;

public class PageSqlFactoryTest {

	private PageSqlFactory pageSqlFactory;
	
	public PageSqlFactoryTest() {
		this.pageSqlFactory = new PageSqlFactory();
	}
	
	@Test
	public void testPageSqlFactoryForInsertScriptWithSimplePage() {
		Page page = new PageBuilder()
				.withKey("new-page")
				.withTitle("Nieuwe pagina")
				.withType("main")
				.withOwnerDomain(DomainBuilder.build("owner-key", "Eigenaar", 1, "bd_icon1"))
				.build();
		
		String result = this.pageSqlFactory.getInsertScript(page, Collections.emptyList());
		
		Assert.assertTrue(result.startsWith("-- Page new-page"));
		Assert.assertTrue(result.contains("('new-page', 'Nieuwe pagina', 'main', (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'owner-key'))"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_PAGE\""));
	}

	@Test
	public void testPageSqlFactoryForInsertMultiUsedPage() {
		Page page = getMultiUsedPage();
		String result = this.pageSqlFactory.getInsertScriptGenericPage(page, "Klantbeeld1");

		Assert.assertTrue(result.startsWith("-- Page multi_used_page"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_DOMAIN\"(PAGE_ID, DOMAIN_ID, GROUP_INDEX, MEMBER_INDEX) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'multi_used_page'), (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1'), 1, 2);"));
		Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_PAGE_DOMAIN\""));
	}

	@Test
	public void testPageSqlFactoryForInsertMultiUsedPageButNotForThisKlantbeeld() {
		Page page = getMultiUsedPage();
		String result = this.pageSqlFactory.getInsertScriptGenericPage(page, "Klantbeeld3");

		Assert.assertTrue(result.startsWith("-- Page multi_used_page"));
		Assert.assertEquals(0, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_PAGE_DOMAIN\""));
	}


	@Test
	public void testPageSqlFactoryForInsertWithCompletePage() {
		Page page = getCompletePage();
		String result = this.pageSqlFactory.getInsertScript(page, Collections.emptyList());

		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_DOMAIN\"(PAGE_ID, DOMAIN_ID, GROUP_INDEX, MEMBER_INDEX) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'complete_page'), (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1'), 1, 2);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_DOMAIN\"(PAGE_ID, DOMAIN_ID, GROUP_INDEX, MEMBER_INDEX) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'complete_page'), (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld2'), 1, 3);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_PATHKEY\"(PAGE_ID, NAME) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'complete_page'), 'pp_name_1');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_PATHKEY\"(PAGE_ID, NAME) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'complete_page'), 'pp_name_2');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_ATTRIBUTE\"(PAGE_ID, KEY, VALUE) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'complete_page'), 'pa_key_1', 'pa_value_1');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_ATTRIBUTE\"(PAGE_ID, KEY, VALUE) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'complete_page'), 'pa_key_2', 'pa_value_2');"));
		Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_PAGE\""));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_PAGE_DOMAIN\""));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_PAGE_PATHKEY\""));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_PAGE_ATTRIBUTE\""));
	}

	@Test
	public void testGetUpdateScriptWithPagekey() {
		Page page = getMultiUsedPage();
		Widget widget1 = getWidget("widget_1");
		Widget widget2 = getWidget("widget_2");
		ArrayList<PageWidget> pageWidgetList = new ArrayList<>();
		pageWidgetList.add(PageWidgetBuilder.build(page, widget1, 4, 2, 1));
		pageWidgetList.add(PageWidgetBuilder.build(page, widget2, 4, 4, 1));

		String result = this.pageSqlFactory.getUpdateScript(page.getKey(), pageWidgetList);

		Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_WIDGET\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = 'multi_used_page');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_WIDGET\"(PAGE_ID, WIDGET_ID, GRID_COLUMNS, ROW_INDEX, COLUMN_INDEX) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'multi_used_page'), (SELECT ID FROM CONF_WIDGET WHERE NAME = 'widget_1'), 4, 2, 1);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_WIDGET\"(PAGE_ID, WIDGET_ID, GRID_COLUMNS, ROW_INDEX, COLUMN_INDEX) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'multi_used_page'), (SELECT ID FROM CONF_WIDGET WHERE NAME = 'widget_2'), 4, 4, 1);"));
		Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_PAGE_WIDGET\""));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_PAGE_WIDGET\""));
	}

	@Test
	public void testGetUpdateScript() {
		Page page = getMultiUsedPage();
		Widget widget1 = getWidget("widget_1");
		Widget widget2 = getWidget("widget_2");
		ArrayList<PageWidget> pageWidgetList = new ArrayList<>();
		pageWidgetList.add(PageWidgetBuilder.build(page, widget1, 4, 2, 1));
		pageWidgetList.add(PageWidgetBuilder.build(page, widget2, 4, 4, 1));

		String result = this.pageSqlFactory.getUpdateScript(page, pageWidgetList);

		Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_WIDGET\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = 'multi_used_page');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_WIDGET\"(PAGE_ID, WIDGET_ID, GRID_COLUMNS, ROW_INDEX, COLUMN_INDEX) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'multi_used_page'), (SELECT ID FROM CONF_WIDGET WHERE NAME = 'widget_1'), 4, 2, 1);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_PAGE_WIDGET\"(PAGE_ID, WIDGET_ID, GRID_COLUMNS, ROW_INDEX, COLUMN_INDEX) VALUES ((SELECT ID FROM CONF_PAGE WHERE KEY = 'multi_used_page'), (SELECT ID FROM CONF_WIDGET WHERE NAME = 'widget_2'), 4, 4, 1);"));
		Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_PAGE_WIDGET\""));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_PAGE_WIDGET\""));
	}

	@Test
	public void testGetDeleteScript() {
		Page page = getMultiUsedPage();
		String result = this.pageSqlFactory.getDeleteScript(page);

		Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_PATHKEY\" WHERE PAGE_ID = (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = 'multi_used_page');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_WIDGET\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = 'multi_used_page');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_DOMAIN\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = 'multi_used_page');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_ATTRIBUTE\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = 'multi_used_page');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE\" WHERE KEY = 'multi_used_page';"));
	}

	private Page getMultiUsedPage() {
		Page page = new PageBuilder()
				.withKey("multi_used_page")
				.withTitle("Pagina voor Klantbeeld1 en Klantbeeld2")
				.withType("main")
				.withOwnerDomain(null)
				.build();
		ArrayList<PageDomain> pageDomains = new ArrayList<>();
		pageDomains.add(PageDomainBuilder.build(1,2,null, DomainBuilder.build("Klantbeeld1", "Eigenaar", 1, "bd_icon1")));
		pageDomains.add(PageDomainBuilder.build(1,3,null, DomainBuilder.build("Klantbeeld2", "Eigenaar", 1, "bd_icon2")));
		page.setPageDomainList(pageDomains);
		return page;
	}

	private Page getCompletePage() {
		Page page = new PageBuilder()
				.withKey("complete_page")
				.withTitle("Pagina voor Klantbeeld1 en Klantbeeld2")
				.withType("main")
				.withOwnerDomain(null)
				.build();
		ArrayList<PageDomain> pageDomains = new ArrayList<>();
		pageDomains.add(PageDomainBuilder.build(1,2,null, DomainBuilder.build("Klantbeeld1", "Eigenaar", 1, "bd_icon1")));
		pageDomains.add(PageDomainBuilder.build(1,3,null, DomainBuilder.build("Klantbeeld2", "Eigenaar", 1, "bd_icon2")));
		page.setPageDomainList(pageDomains);

		ArrayList<PageAttribute> pageAttributes= new ArrayList<>();
		pageAttributes.add(PageAttributeBuilder.build("pa_key_1", "pa_value_1"));
		pageAttributes.add(PageAttributeBuilder.build("pa_key_2", "pa_value_2"));
		page.setPageAttributeList(pageAttributes);

		ArrayList<PagePathkey> pagePathkeys= new ArrayList<>();
		pagePathkeys.add(PagePathkeyBuilder.build("pp_name_1"));
		pagePathkeys.add(PagePathkeyBuilder.build("pp_name_2"));
		page.setPagePathkeyList(pagePathkeys);
		return page;
	}

	private Widget getWidget(String name) {
		return new WidgetBuilder()
				.withName(name)
				.withType("Table")
				.withTitle("Een widget met key " + name)
				.build();
	}

}
