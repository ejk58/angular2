package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.ArrayList;

public class DomainBuilder {

    private Domain domain;

    public DomainBuilder() {
        this.domain = new Domain();
        this.domain.setDomainRoleList(new ArrayList<>());
        this.domain.setDomainAttributeList(new ArrayList<>());
        this.domain.setDomainPathkeyList(new ArrayList<>());
        this.domain.setDomainMenugroupList(new ArrayList<>());
        this.domain.setDomainSubjecttypeList(new ArrayList<>());
    }

    public Domain build() {
        return this.domain;
    }

    public DomainBuilder withKey(String key) {
        this.domain.setKey(key);
        return this;
    }

    public DomainBuilder withName(String name) {
        this.domain.setName(name);
        return this;
    }

    public DomainBuilder withIndex(Integer index) {
        this.domain.setIndex(index);
        return this;
    }

    public DomainBuilder withIconname(String iconname) {
        this.domain.setIconname(iconname);
        return this;
    }

    public static Domain build(String key, String name, int index, String iconname) {
        return new DomainBuilder()
                .withKey(key)
                .withName(name)
                .withIndex(index)
                .withIconname(iconname)
                .build();
    }
}
