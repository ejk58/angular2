package nl.belastingdienst.iva.wd.configurator;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.common.springboot.security.LoginCredentials;
import nl.belastingdienst.iva.wd.configurator.constants.DomainConstants;
import nl.belastingdienst.iva.wd.configurator.controller.AbstractControllerTest;
import nl.belastingdienst.iva.wd.configurator.datasource.configurator.ConfiguratorChangeRepository;
import nl.belastingdienst.iva.wd.configurator.domain.ApplicationDomain;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.dto.WidgetDtoExtended;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class IntegrationTest extends AbstractControllerTest {

    String authorizationValue;

    @Autowired
    private MockMvc mvc;

    @SpyBean
    private ConfiguratorChangeRepository configuratorChangeRepository;

    @SpyBean
    private ApplicationUtils applicationUtils;

    @Before
    public void setUp() throws Exception {
        authorizationValue = loginIvaall(mvc, status().isOk());
    }

    @Test
    public void loginOk() throws Exception {
        LoginCredentials creds = new LoginCredentials();
        creds.setUsername("ivaall");
        creds.setPassword("Welkom01");
        String credsJson = new ObjectMapper().writeValueAsString(creds);
        mvc.perform(post(START_REQUEST + "/login").content(credsJson)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void loginNok() throws Exception {
        LoginCredentials creds = new LoginCredentials();
        creds.setUsername("ivaall");
        creds.setPassword("WatIsHetPasswordOokAlweer?");
        String credsJson = new ObjectMapper().writeValueAsString(creds);
        mvc.perform(post(START_REQUEST + "/login").content(credsJson)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void queryControllerGetQueryKeys() throws Exception {
        mvc.perform(get("/api/query/keys").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(8)))
                .andExpect(jsonPath("$[0]", is("QUERY_1")))
                .andExpect(jsonPath("$[1]", is("QUERY_2")))
                .andExpect(jsonPath("$[2]", is("QUERY_3")))
                .andExpect(jsonPath("$[3]", is("RELATION_NOVIP_QUERY")))
                .andExpect(jsonPath("$[4]", is("RELATION_VIP_QUERY")))
                .andExpect(jsonPath("$[5]", is("SEARCH_NOVIP_QUERY")))
                .andExpect(jsonPath("$[6]", is("SEARCH_VIP_QUERY")))
                .andExpect(jsonPath("$[7]", is("SUBJECT_QUERY")));
    }

    @Test
    public void queryControllerGetQuery() throws Exception {
        mvc.perform(get("/api/query/RELATION_VIP_QUERY").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.key", is("RELATION_VIP_QUERY")))
                .andExpect(jsonPath("$.type", is(1)))
                .andExpect(jsonPath("$.viewname", is("teradataview_3")))
                .andExpect(jsonPath("$.querytemplate", is("SELECT relation_vip_col FROM  teradataview_3 WHERE finr = 7777777")))
                .andExpect(jsonPath("$.columnList", hasSize(0)))
                .andExpect(jsonPath("$.queryFilterList", hasSize(0)))
                .andExpect(jsonPath("$.queryAttributeList", hasSize(0)))
                .andExpect(jsonPath("$.datasource.id", is(1)))
                .andExpect(jsonPath("$.datasource.key", is("Teradata/IVAI")))
                .andExpect(jsonPath("$.ownerDomain", nullValue()));
    }

    @Test
    public void queryControllerGetQueryWithDomain() throws Exception {
        mvc.perform(get("/api/query/QUERY_1").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.key", is("QUERY_1")))
                .andExpect(jsonPath("$.type", is(1)))
                .andExpect(jsonPath("$.viewname", is("teradataview_1")))
                .andExpect(jsonPath("$.querytemplate", is("SELECT col1, col2 FROM  teradataview_1 WHERE finr = 7777777 ORDER BY col1")))
                .andExpect(jsonPath("$.columnList", hasSize(3)))
                .andExpect(jsonPath("$.queryFilterList", hasSize(0)))
                .andExpect(jsonPath("$.queryAttributeList", hasSize(0)))
                .andExpect(jsonPath("$.datasource.id", is(1)))
                .andExpect(jsonPath("$.datasource.key", is("Teradata/IVAI")))
                .andExpect(jsonPath("$.ownerDomain.key", is("niet_winst")));
    }

    @Test
    public void widgetControllerGetWidgetNames() throws Exception {
        mvc.perform(get("/api/widget/names").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(3)))
                .andExpect(jsonPath("$[0]", is("WIDGET_1")))
                .andExpect(jsonPath("$[1]", is("WIDGET_2")))
                .andExpect(jsonPath("$[2]", is("WIDGET_3")));
    }

    @Test
    public void widgetControllerGetWidgetNamesForDomain() throws Exception {
        mvc.perform(get("/api/widget/names/niet_winst").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0]", is("WIDGET_1")));
    }

    @Test
    public void widgetControllerGetWidgetNamesForDomainButNotAuthorised() throws Exception {
        authorizationValue = loginIvatest1(mvc, status().isOk());
        mvc.perform(get("/api/widget/names/di").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string("Let op! Het opslaan is niet gelukt. Je hebt geen toegang tot klantbeeld  di"));
    }

    @Test
    public void widgetControllerGetWidgetNamesForGenericButUnauthorised() throws Exception {
        mvc.perform(get("/api/widget/names/generic").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string("Let op! Het opslaan is niet gelukt. Je hebt geen toegang tot klantbeeld  admin"));
    }

    @Test
    public void widgetControllerGetWidgetNamesForGeneric() throws Exception {
        doAnswer(invocation -> {
            Object arg0 = invocation.getArgument(0);
            String user = (String)arg0;

            assertEquals(DomainConstants.ADMIN, user);
           	return true;
        }).when(applicationUtils).userHasAccessToDomain(isA(String.class));

        mvc.perform(get("/api/widget/names/generic").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[0]", is("WIDGET_3")));

		verify(applicationUtils, times(1)).userHasAccessToDomain(isA(String.class));
  	}

    @Test
    public void widgetControllerGetWidgetNamesForDomainAndGeneric() throws Exception {
        mvc.perform(get("/api/widget/names/generic/niet_winst").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0]", is("WIDGET_1")))
                .andExpect(jsonPath("$[1]", is("WIDGET_3")));
    }

    @Test
    public void widgetControllerGetWidgetTypes() throws Exception {
        mvc.perform(get("/api/widget/types").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0]", is("List")))
                .andExpect(jsonPath("$[1]", is("Table")));
    }

    @Test
    public void widgetControllerGetWidgetAttributeKeys() throws Exception {
        mvc.perform(get("/api/widget/attributekeys").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0]", is("W1 A1 key1")))
                .andExpect(jsonPath("$[1]", is("W1 A2 key2")));
    }

    @Test
    public void widgetControllerGetWidget() throws Exception {
        mvc.perform(get("/api/widget/WIDGET_1").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.index", is(1)))
                .andExpect(jsonPath("$.name", is("WIDGET_1")))
                .andExpect(jsonPath("$.type", is("Table")))
                .andExpect(jsonPath("$.title", is("Titel widget 1")))
                .andExpect(jsonPath("$.description", is("Omschrijving widget 1")))
                .andExpect(jsonPath("$.refreshinfo", is(true)))
                .andExpect(jsonPath("$.visible", is(true)))
                .andExpect(jsonPath("$.query", notNullValue()))
                .andExpect(jsonPath("$.ruleGroup", nullValue()))
                .andExpect(jsonPath("$.attributeList", hasSize(2)))
                .andExpect(jsonPath("$.columnList", hasSize(3)))
                .andExpect(jsonPath("$.containerWidget", nullValue()))
                .andExpect(jsonPath("$.widgetList", hasSize(0)))
                .andExpect(jsonPath("$.helpList", hasSize(0)))
                .andExpect(jsonPath("$.ownerDomain.key", is("niet_winst")));
    }

    @Test
    public void widgetControllerSaveWidget() throws Exception {
        Widget wd = new Widget();
        wd.setId(30);
        wd.setIndex(1);
        wd.setName("WIDGET_TO_SAVE_1");
        wd.setType("Table");
        wd.setTitle("Widget to save");

        ApplicationDomain applicationDomain = new ApplicationDomain();
        applicationDomain.setDomainId("niet_winst");
        applicationDomain.setDomainName("Niet Winst");

        WidgetDtoExtended wde = new WidgetDtoExtended();
        wde.setTag("TestChange1");
        wde.setWidget(wd);
        wde.setApplicationDomain(applicationDomain);

        String wdeJson = new ObjectMapper().writeValueAsString(wde);

        // we mocken rolloutChangeOnSourceDatabase methode en checken de meegegeven Change parameter
        doAnswer(invocation -> {
            Object arg0 = invocation.getArgument(0);
            String sql = ((Change)arg0).getSql();

            assertEquals("TestChange1", ((Change)arg0).getTag());
            assertTrue(sql.contains("MERGE INTO \"CONF_WIDGET\" AS W USING (VALUES (null, null, null, 1, 'WIDGET_TO_SAVE_1', 'Table', 'Widget to save', null, 0, 0, (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst')))"));

            return null;
        }).when(configuratorChangeRepository).rolloutChangeOnSourceDatabase(isA(Change.class));

        // aanroepen van de save method van de controller
        mvc.perform(post("/api/widget/save").header(HEADER_STRING, authorizationValue).content(wdeJson).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());

        // controleren van de database (zit de nieuwe change in de database?)
        MvcResult result = mvc.perform(get("/api/change/mostRecent/niet_winst").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn();

        String content = result.getResponse().getContentAsString();
        assertTrue(content.contains("\"domainKey\":\"niet_winst\""));
        assertTrue(content.contains("\"tag\":\"TestChange1\""));

        // is de sql rollout method 1x aangeroepen met de juiste waarden?
        verify(configuratorChangeRepository, times(1)).rolloutChangeOnSourceDatabase(isA(Change.class));
    }

    @Test
    public void datasourceControllerGetDatasourceType() throws Exception {
        mvc.perform(get("/api/datasources/types").header(HEADER_STRING, authorizationValue).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].key", is("Teradata/IVAI")))
                .andExpect(jsonPath("$[1].id", is(2)))
                .andExpect(jsonPath("$[1].key", is("Rest/Inzicht")));
    }

    @Test
    public void widgetControllerSaveWidgetErrorDueToMappingProblem() throws Exception {
        String wdJson = "{\"widget\": \"er_klopt_niets_van\"}";

        // aanroepen van de save method van de controller
        mvc.perform(post("/api/widget/save").header(HEADER_STRING, authorizationValue).content(wdJson).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Let op! Het opslaan is niet gelukt. (De opmaak van) het verstuurde bericht is niet correct."));
    }

    // Onderstaande test kan gebruikt worden om te testen met een Json payload die je hebt opgevangen van het chrome network console.
    @Test
    public void widgetControllerSaveWidgetJsonPayloadTest() throws Exception {
        // vul hieronder de payload in en draai de test
        String payloadJson = "";
        if (payloadJson != null && !payloadJson.isEmpty()) {
            mvc.perform(post("/api/widget/save").header(HEADER_STRING, authorizationValue).content(payloadJson).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON_VALUE))
                    .andExpect(status().isOk());
        }
    }

    protected String loginWithUser(MockMvc mvc, String userid, String password, ResultMatcher resultMatcher)
            throws Exception {
        LoginCredentials creds = new LoginCredentials();
        creds.setUsername(userid);
        creds.setPassword(password);
        String credsJson = new ObjectMapper().writeValueAsString(creds);
        MvcResult result = mvc.perform(post(START_REQUEST + "/login").content(credsJson)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(resultMatcher)
                .andReturn();
        return result.getResponse()
                .getHeader(HEADER_STRING);
    }
}
