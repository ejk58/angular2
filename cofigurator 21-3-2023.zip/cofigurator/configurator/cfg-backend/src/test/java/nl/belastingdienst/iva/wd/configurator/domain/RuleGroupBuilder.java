package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.ArrayList;
import java.util.List;

public class RuleGroupBuilder {
    private RuleGroup ruleGroup;

    public RuleGroupBuilder() {
        this.ruleGroup = new RuleGroup();
        this.ruleGroup.setRuleList(new ArrayList<>());
    }

    public RuleGroup build() {
        return this.ruleGroup;
    }

    public RuleGroupBuilder withKey(String key) {
        this.ruleGroup.setKey(key);
        return this;
    }

    public RuleGroupBuilder withOwnerDomain(Domain ownerDomain) {
        this.ruleGroup.setOwnerDomain(ownerDomain);
        return this;
    }

    public RuleGroupBuilder withRuleColumns(List<Rule> rules) {
        this.ruleGroup.setRuleList(rules);
        return this;
    }

    public static RuleGroup build(String key, Domain ownerDomain, List<Rule> rules) {
        return new RuleGroupBuilder()
                .withKey(key)
                .withOwnerDomain(ownerDomain)
                .withRuleColumns(rules)
                .build();
    }
}
