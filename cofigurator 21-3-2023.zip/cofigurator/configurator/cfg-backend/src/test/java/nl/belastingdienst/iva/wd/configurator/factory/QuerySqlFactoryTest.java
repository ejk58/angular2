package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.*;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class QuerySqlFactoryTest {

    private QuerySqlFactory querySqlFactory;

    public QuerySqlFactoryTest() {
        this.querySqlFactory = new QuerySqlFactory();
    }

    @Test
    public void testQuerySqlFactoryForInsertScriptWithACorrectQueryWithNestedColumns() {
        Query query = getQuery();

        String result = this.querySqlFactory.getInsertScript(query);

        Assert.assertTrue(result.startsWith("-- Query TEST_QUERY"));
        Assert.assertTrue(result.contains("MERGE INTO \"CONF_QUERY\" AS Q USING (VALUES ('TEST_QUERY', 1, (SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'TEST_DATASOURCE'), 'TEST_TABLE', 'SELECT {resultColumns} FROM {viewname} WHERE EVERYBODY = HAPPY;', (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'TEST_DOMAIN'))) AS X(KEY, TYPE, DATASOURCE_ID, VIEWNAME, QUERYTEMPLATE, OWNER_DOMAIN_ID) ON Q.KEY = X.KEY\n" +
                "  WHEN MATCHED THEN UPDATE SET KEY = X.KEY, TYPE = X.TYPE, DATASOURCE_ID = X.DATASOURCE_ID, VIEWNAME = X.VIEWNAME, QUERYTEMPLATE = X.QUERYTEMPLATE, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID\n" +
                "  WHEN NOT MATCHED THEN INSERT (KEY, TYPE, DATASOURCE_ID, VIEWNAME, QUERYTEMPLATE, OWNER_DOMAIN_ID) VALUES (X.KEY, X.TYPE, X.DATASOURCE_ID, X.VIEWNAME, X.QUERYTEMPLATE, X.OWNER_DOMAIN_ID);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'TEST_QUERY'), null, 1, 'COLUMN_ID', 'columnId', null, null, 'NUMBER', 0);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES (null, (SELECT ID from CONF_QUERY_COLUMN WHERE QUERY_ID = (SELECT ID FROM CONF_QUERY WHERE KEY = 'TEST_QUERY') AND INDEX = 1), 1, 'INNER_COLUMN_ID', 'innerColumnId', null, null, 'NUMBER', 0);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'TEST_QUERY'), null, 2, 'COLUMN_TYPE', null, null, 'columnType', 'STRING', 0);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'TEST_QUERY'), null, 3, 'COLUMN_NAME', null, null, null, 'STRING', 0);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'TEST_QUERY'), null, 4, null, null, 'Fixed Value', 'columnValue', 'STRING', 0);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_FILTER\"(QUERY_ID, PARAMETER, FILTERTEMPLATE, NOFILTERTEMPLATE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'TEST_QUERY'), 'Filter-parameter', 'Filter-template', 'No-filter-template');"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_FILTER\"(QUERY_ID, KEY, VALUE) VALUES ((SELECT q.ID FROM CONF_QUERY q WHERE q.KEY = 'TEST_QUERY'), 'query_attribute_key1', 'query_attribute_value1');"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_FILTER\"(QUERY_ID, KEY, VALUE) VALUES ((SELECT q.ID FROM CONF_QUERY q WHERE q.KEY = 'TEST_QUERY'), 'query_attribute_key2', 'query_attribute_value2');"));

        Assert.assertEquals(5, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_QUERY_COLUMN\""));
        Assert.assertEquals(3, SqlScriptTestUtils.countOccurences(result, "\"CONF_QUERY_FILTER\""));
        Assert.assertEquals(9, SqlScriptTestUtils.countOccurences(result, "'TEST_QUERY'"));
    }

    private Query getQuery() {
        List<QueryColumn> queryColumns = new ArrayList<>();
        List<QueryColumn> innerQueryColumns = new ArrayList<>();
        innerQueryColumns.add(QueryColumnBuilder.build(1, "INNER_COLUMN_ID", "innerColumnId", null, null, "NUMBER", false, null));

        queryColumns.add(QueryColumnBuilder.build(1, "COLUMN_ID", "columnId", null, null, "NUMBER", false, innerQueryColumns));
        queryColumns.add(QueryColumnBuilder.build(2, "COLUMN_TYPE", null, null, "columnType", "STRING", false, null));
        queryColumns.add(QueryColumnBuilder.build(3, "COLUMN_NAME", null, null, null, "STRING", false, null));
        queryColumns.add(QueryColumnBuilder.build(4, null, null, "Fixed Value", "columnValue", "STRING", false, null));

        Query query = new QueryBuilder()
        		.withDatasource(DatasourceBuilder.build("TEST_DATASOURCE"))
        		.withKey("TEST_QUERY")
        		.withType(1)
        		.withViewname("TEST_TABLE")
        		.withQuerytemplate("SELECT {resultColumns} FROM {viewname} WHERE EVERYBODY = HAPPY;")
        		.withQueryColumns(queryColumns)
        		.withOwnerDomain(DomainBuilder.build("TEST_DOMAIN", "Nuclear Test Area", 1, "bd_icon1"))
        		.build();

        List<QueryAttribute> queryAttributeList = new ArrayList<>();
        QueryAttribute queryAttribute1 = getQueryAttribute("query_attribute_key1", "query_attribute_value1");
        QueryAttribute queryAttribute2 = getQueryAttribute("query_attribute_key2", "query_attribute_value2");
        queryAttributeList.add(queryAttribute1);
        queryAttributeList.add(queryAttribute2);
        query.setQueryAttributeList(queryAttributeList);

        List<QueryFilter> queryFilterList = new ArrayList<>();
        QueryFilter queryFilter = new QueryFilter();
        queryFilter.setFilterTemplate("Filter-template");
        queryFilter.setNoFilterTemplate("No-filter-template");
        queryFilter.setParameter("Filter-parameter");
        queryFilterList.add(queryFilter);
        query.setQueryFilterList(queryFilterList);

        return query;
    }

    private QueryAttribute getQueryAttribute(String key, String value) {
        QueryAttribute queryAttribute = new QueryAttribute();
        queryAttribute.setKey(key);
        queryAttribute.setValue(value);
        return queryAttribute;
    }
}
