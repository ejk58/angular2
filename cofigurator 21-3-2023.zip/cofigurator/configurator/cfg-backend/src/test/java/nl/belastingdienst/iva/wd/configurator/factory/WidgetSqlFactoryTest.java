package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.*;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class WidgetSqlFactoryTest {
	
	private WidgetSqlFactory widgetSqlFactory;
	
	public WidgetSqlFactoryTest() {
		QuerySqlFactory querySqlFactory = new QuerySqlFactory();
		this.widgetSqlFactory = new WidgetSqlFactory(querySqlFactory);
	}
	
	@Test
	public void testWidgetSqlFactoryForInsertScriptWithAWidgetWithoutAnything() {
		Widget widget = buildWidgetWithoutAnything();
		String result = this.widgetSqlFactory.getInsertScript(widget, widget.getOwnerDomain().getKey());

		Assert.assertTrue(result.startsWith("-- Widget HAPPY_WIDGET"));
		Assert.assertTrue(result.contains("(null, null, null, 1, 'HAPPY_WIDGET_CONTAINER', null, 'Een groepje blije widgets', 'Deze widgets zijn heel blij.', 0, 0, (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'happy-key'))"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_WIDGET\""));
	}
	
	@Test
	public void testWidgetSqlFactoryForInsertScriptWithAWidgetAndQuery() {
		Widget widget = buildWidgetWithQuery();
		String result = this.widgetSqlFactory.getInsertScript(widget, widget.getOwnerDomain().getKey());

		Assert.assertTrue(result.startsWith("-- Query SAD_QUERY"));
		Assert.assertTrue(result.contains("('SAD_QUERY', 1, (SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'HAPPY_SOURCE'), 'THE_BEST_VIEW', 'SELECT {resultColumns} FROM {viewname} WHERE EVERYTHING = GREAT', (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'sad-key'))"));
		Assert.assertTrue(result.contains("-- Widget SAD_WIDGET"));
		Assert.assertTrue(result.contains("((SELECT ID FROM CONF_QUERY WHERE KEY = 'SAD_QUERY'), null, null, 1, 'SAD_WIDGET', 'Table', 'Een treurige widget', 'Deze widget is niet blij.', 0, 0, (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'sad-key'))"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_QUERY\""));
        Assert.assertEquals(4, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_QUERY_COLUMN\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_WIDGET\""));
        Assert.assertEquals(4, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_WIDGET_COLUMN\""));
		Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_WIDGET_COLUMN_ATTRIBUTE\""));
	}
	
	@Test
	public void testWidgetSqlFactoryForDeleteScriptWithWidgetWithoutAnything() {
		Widget widget = buildWidgetWithoutAnything();
		String result = this.widgetSqlFactory.getDeleteScript(widget);
		
		Assert.assertTrue(result.startsWith("-- Delete HAPPY_WIDGET"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_COLUMN\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_HELP\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_ATTRIBUTE\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET\""));
	}

	@Test
	public void testWidgetSqlFactoryForDeleteScriptWithWidgetWithQuery() {
		Widget widget = buildWidgetWithQuery();
		String result = this.widgetSqlFactory.getDeleteScript(widget);

		Assert.assertTrue(result.startsWith("-- Delete SAD_WIDGET"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\" WHERE WIDGET_COLUMN_ID IN (SELECT WC.ID FROM CONF_WIDGET_COLUMN WC JOIN CONF_WIDGET W ON WC.WIDGET_ID = W.ID WHERE W.NAME = 'SAD_WIDGET');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_COLUMN\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = 'SAD_WIDGET');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_HELP\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = 'SAD_WIDGET');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_ATTRIBUTE\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = 'SAD_WIDGET');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET\" WHERE NAME = 'SAD_WIDGET';"));

		Assert.assertTrue(result.contains("-- Delete SAD_QUERY "));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC3.ID FROM CONF_QUERY_COLUMN QC3 JOIN CONF_QUERY_COLUMN QC2 ON QC3.COMPOSITE_COLUMN_ID = QC2.ID JOIN CONF_QUERY_COLUMN QC ON QC2.COMPOSITE_COLUMN_ID = QC.ID JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC2.ID FROM CONF_QUERY_COLUMN QC2 JOIN CONF_QUERY_COLUMN QC ON QC2.COMPOSITE_COLUMN_ID = QC.ID JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = 'SAD_QUERY');\n" +
				"DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC.ID FROM CONF_QUERY_COLUMN QC JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_FILTER\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_ATTRIBUTE\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY\" WHERE KEY = 'SAD_QUERY';"));


		Assert.assertEquals(12, SqlScriptTestUtils.countOccurences(result, "DELETE FROM "));
		Assert.assertEquals(5, SqlScriptTestUtils.countOccurences(result, "'SAD_WIDGET'"));
		Assert.assertEquals(7, SqlScriptTestUtils.countOccurences(result, "'SAD_QUERY'"));
	}
	
	@Test
	public void testWidgetSqlFactoryForUpdateScriptWithAWidgetWithoutAnything() {
		Widget widget = buildWidgetWithoutAnything();
		String result = this.widgetSqlFactory.getUpdateScript(widget);

		Assert.assertTrue(result.startsWith("-- Delete HAPPY_WIDGET"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_COLUMN\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_HELP\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_ATTRIBUTE\""));
		Assert.assertTrue(result.contains("(null, null, null, 1, 'HAPPY_WIDGET_CONTAINER', null, 'Een groepje blije widgets', 'Deze widgets zijn heel blij.', 0, 0, (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'happy-key'))"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_WIDGET\""));
	}

	@Test
	public void testWidgetSqlFactoryForUpdateScriptWithAWidgetWithQuery() {
		Widget widget = buildWidgetWithQuery();
		String result = this.widgetSqlFactory.getUpdateScript(widget);

		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\" WHERE WIDGET_COLUMN_ID IN (SELECT WC.ID FROM CONF_WIDGET_COLUMN WC JOIN CONF_WIDGET W ON WC.WIDGET_ID = W.ID WHERE W.NAME = 'SAD_WIDGET');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_COLUMN\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = 'SAD_WIDGET');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_HELP\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = 'SAD_WIDGET');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_ATTRIBUTE\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = 'SAD_WIDGET');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC3.ID FROM CONF_QUERY_COLUMN QC3 JOIN CONF_QUERY_COLUMN QC2 ON QC3.COMPOSITE_COLUMN_ID = QC2.ID JOIN CONF_QUERY_COLUMN QC ON QC2.COMPOSITE_COLUMN_ID = QC.ID JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC2.ID FROM CONF_QUERY_COLUMN QC2 JOIN CONF_QUERY_COLUMN QC ON QC2.COMPOSITE_COLUMN_ID = QC.ID JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC.ID FROM CONF_QUERY_COLUMN QC JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_FILTER\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_ATTRIBUTE\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = 'SAD_QUERY');"));
		Assert.assertTrue(result.contains("MERGE INTO \"CONF_QUERY\" AS Q USING (VALUES ('SAD_QUERY', 1, (SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'HAPPY_SOURCE'), 'THE_BEST_VIEW', 'SELECT {resultColumns} FROM {viewname} WHERE EVERYTHING = GREAT', (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'sad-key'))) AS X(KEY, TYPE, DATASOURCE_ID, VIEWNAME, QUERYTEMPLATE, OWNER_DOMAIN_ID) ON Q.KEY = X.KEY\n" +
				"  WHEN MATCHED THEN UPDATE SET KEY = X.KEY, TYPE = X.TYPE, DATASOURCE_ID = X.DATASOURCE_ID, VIEWNAME = X.VIEWNAME, QUERYTEMPLATE = X.QUERYTEMPLATE, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID\n" +
				"  WHEN NOT MATCHED THEN INSERT (KEY, TYPE, DATASOURCE_ID, VIEWNAME, QUERYTEMPLATE, OWNER_DOMAIN_ID) VALUES (X.KEY, X.TYPE, X.DATASOURCE_ID, X.VIEWNAME, X.QUERYTEMPLATE, X.OWNER_DOMAIN_ID);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'SAD_QUERY'), null, 1, 'COLUMN_ID', 'columnId', null, null, 'NUMBER', 0);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'SAD_QUERY'), null, 2, 'COLUMN_TYPE', null, null, 'columnType', 'STRING', 0);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'SAD_QUERY'), null, 3, 'COLUMN_NAME', null, null, null, 'STRING', 0);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'SAD_QUERY'), null, 4, null, null, 'Fixed Value', 'columnValue', 'STRING', 0);"));

		Assert.assertTrue(result.contains("MERGE INTO \"CONF_WIDGET\" AS W USING (VALUES ((SELECT ID FROM CONF_QUERY WHERE KEY = 'SAD_QUERY'), null, null, 1, 'SAD_WIDGET', 'Table', 'Een treurige widget', 'Deze widget is niet blij.', 0, 0, (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'sad-key'))) AS X(QUERY_ID, RULE_GROUP_ID, CONTAINER_WIDGET_ID, INDEX, NAME, TYPE, TITLE, DESCRIPTION, REFRESHINFO, VISIBLE, OWNER_DOMAIN_ID) ON W.NAME = X.NAME\n" +
				"  WHEN MATCHED THEN UPDATE SET QUERY_ID = X.QUERY_ID, RULE_GROUP_ID = X.RULE_GROUP_ID, CONTAINER_WIDGET_ID = X.CONTAINER_WIDGET_ID, INDEX = X.INDEX, NAME = X.NAME, TYPE = X.TYPE, TITLE = X.TITLE, DESCRIPTION = X.DESCRIPTION, REFRESHINFO = X.REFRESHINFO, VISIBLE = X.VISIBLE, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID\n" +
				"  WHEN NOT MATCHED THEN INSERT (QUERY_ID, RULE_GROUP_ID, CONTAINER_WIDGET_ID, INDEX, NAME, TYPE, TITLE, DESCRIPTION, REFRESHINFO, VISIBLE, OWNER_DOMAIN_ID) VALUES (X.QUERY_ID, X.RULE_GROUP_ID, X.CONTAINER_WIDGET_ID, X.INDEX, X.NAME, X.TYPE, X.TITLE, X.DESCRIPTION, X.REFRESHINFO, X.VISIBLE, X.OWNER_DOMAIN_ID);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_WIDGET_COLUMN\"(WIDGET_ID, QUERY_COLUMN_ID, INDEX, TYPE, LABEL, DESCRIPTION, BEHAVIOUR, FILTER) VALUES ((SELECT ID FROM CONF_WIDGET WHERE NAME = 'SAD_WIDGET'), (SELECT qc.ID FROM CONF_QUERY_COLUMN qc JOIN CONF_QUERY q ON q.ID = qc.QUERY_ID WHERE q.KEY = 'SAD_QUERY' AND qc.INDEX = 1), 1, 'NUMBER', 'Id', null, 'visible', null);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_WIDGET_COLUMN\"(WIDGET_ID, QUERY_COLUMN_ID, INDEX, TYPE, LABEL, DESCRIPTION, BEHAVIOUR, FILTER) VALUES ((SELECT ID FROM CONF_WIDGET WHERE NAME = 'SAD_WIDGET'), (SELECT qc.ID FROM CONF_QUERY_COLUMN qc JOIN CONF_QUERY q ON q.ID = qc.QUERY_ID WHERE q.KEY = 'SAD_QUERY' AND qc.INDEX = 2), 2, 'STRING', 'Type', null, 'visible', 'text');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_WIDGET_COLUMN_ATTRIBUTE\"(WIDGET_COLUMN_ID, KEY, VALUE) VALUES ((SELECT ID FROM \"CONF_WIDGET_COLUMN\" WHERE WIDGET_ID = (SELECT ID FROM CONF_WIDGET WHERE NAME = 'SAD_WIDGET') AND INDEX = 2), 'widget_column_attribute_key1', 'widget_column_attribute_value1');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_WIDGET_COLUMN\"(WIDGET_ID, QUERY_COLUMN_ID, INDEX, TYPE, LABEL, DESCRIPTION, BEHAVIOUR, FILTER) VALUES ((SELECT ID FROM CONF_WIDGET WHERE NAME = 'SAD_WIDGET'), (SELECT qc.ID FROM CONF_QUERY_COLUMN qc JOIN CONF_QUERY q ON q.ID = qc.QUERY_ID WHERE q.KEY = 'SAD_QUERY' AND qc.INDEX = 3), 3, 'STRING', 'Naam', null, 'visible', 'text');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_WIDGET_COLUMN\"(WIDGET_ID, QUERY_COLUMN_ID, INDEX, TYPE, LABEL, DESCRIPTION, BEHAVIOUR, FILTER) VALUES ((SELECT ID FROM CONF_WIDGET WHERE NAME = 'SAD_WIDGET'), (SELECT qc.ID FROM CONF_QUERY_COLUMN qc JOIN CONF_QUERY q ON q.ID = qc.QUERY_ID WHERE q.KEY = 'SAD_QUERY' AND qc.INDEX = 4), 4, 'STRING', 'Waarde', 'Deze waarde is constant', 'visible', null);"));

		Assert.assertEquals(10, SqlScriptTestUtils.countOccurences(result, "DELETE FROM "));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "MERGE INTO"));
		Assert.assertEquals(9, SqlScriptTestUtils.countOccurences(result, "INSERT INTO"));
		Assert.assertEquals(10, SqlScriptTestUtils.countOccurences(result, "'SAD_WIDGET'"));
		Assert.assertEquals(16, SqlScriptTestUtils.countOccurences(result, "'SAD_QUERY'"));
	}

	@Test
	public void testWidgetSqlFactoryForInsertWithWidgetWithAttributesAndHelp() {
		Widget widget = buildWidgetWithQueryAndAttributesAndHelpAndRules();
		String result = this.widgetSqlFactory.getInsertScript(widget, widget.getOwnerDomain().getKey());

		Assert.assertTrue(result.contains("INSERT INTO \"CONF_WIDGET_ATTRIBUTE\"(WIDGET_ID, KEY, VALUE) VALUES ((SELECT ID FROM CONF_WIDGET WHERE NAME = 'SAD_WIDGET'), 'widget_attribute_key1', 'widget_attribute_value1');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_WIDGET_ATTRIBUTE\"(WIDGET_ID, KEY, VALUE) VALUES ((SELECT ID FROM CONF_WIDGET WHERE NAME = 'SAD_WIDGET'), 'widget_attribute_key2', 'widget_attribute_value2');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_WIDGET_HELP\"(WIDGET_ID, INDEX, HELP_ID) VALUES ((SELECT ID FROM CONF_WIDGET WHERE NAME = 'SAD_WIDGET'), 1, (SELECT ID FROM CONF_HELP WHERE KEY = 'helpkey'));"));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_WIDGET_ATTRIBUTE\""));
		Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_WIDGET_HELP\""));
	}

	@Test
	public void testWidgetSqlFactoryForInsertWithWidgetWithRules() {
		Widget widget = buildWidgetWithQueryAndAttributesAndHelpAndRules();
		String result = this.widgetSqlFactory.getInsertScript(widget, widget.getOwnerDomain().getKey());

		Assert.assertTrue(result.startsWith("-- Rule-group RuleGroupKey"));
		Assert.assertTrue(result.contains("MERGE INTO \"CONF_RULE_GROUP\" AS RG USING (VALUES ('RuleGroupKey', (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'sad-key'))) AS X(KEY, OWNER_DOMAIN_ID) ON RG.KEY = X.KEY\n" +
				"  WHEN MATCHED THEN UPDATE SET KEY = X.KEY, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID\n" +
				"  WHEN NOT MATCHED THEN INSERT (KEY, OWNER_DOMAIN_ID) VALUES (X.KEY, X.OWNER_DOMAIN_ID);"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_RULE\"(RULE_GROUP_ID, INDEX, VALUE) VALUES ((SELECT ID FROM CONF_RULE_GROUP WHERE KEY = 'RuleGroupKey'), 1, 'rule1');"));
		Assert.assertTrue(result.contains("INSERT INTO \"CONF_RULE\"(RULE_GROUP_ID, INDEX, VALUE) VALUES ((SELECT ID FROM CONF_RULE_GROUP WHERE KEY = 'RuleGroupKey'), 1, 'rule1');"));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_RULE\""));
	}

	@Test
	public void testContainerWidgetSqlFactoryForInsert() {
		Widget containerWidget = buildContainerWidgetWithChildren();
		String result = this.widgetSqlFactory.getInsertScript(containerWidget, containerWidget.getOwnerDomain().getKey());
		int positieContainerWidget = (result.indexOf("-- Widget Z_CONTAINER_WIDGET"));
		int positieInnerWidget1 = (result.indexOf("-- Widget B_INNERWIDGET_1"));
		int positieInnerWidget2 = (result.indexOf("-- Widget A_INNERWIDGET_2"));
		int positieInnerInnerWidget1 = (result.indexOf("-- Widget D_INNERINNERWIDGET_1"));
		int positieInnerInnerWidget2 = (result.indexOf("-- Widget C_INNERINNERWIDGET_2"));

		Assert.assertTrue(result.startsWith("-- Widget Z_CONTAINER_WIDGET"));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "(SELECT ID FROM CONF_WIDGET WHERE NAME = 'Z_CONTAINER_WIDGET')"));
		Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "(SELECT ID FROM CONF_WIDGET WHERE NAME = 'A_INNERWIDGET_2')"));
		Assert.assertTrue(positieInnerInnerWidget2 > positieInnerInnerWidget1);
		Assert.assertTrue(positieInnerInnerWidget1 > positieInnerWidget2);
		Assert.assertTrue(positieInnerWidget2 > positieInnerWidget1);
		Assert.assertTrue(positieInnerWidget1 > positieContainerWidget);
	}

	private Widget buildWidgetWithoutAnything() {
		Domain ownerDomain = DomainBuilder.build("happy-key", "Blij Klantbeeld", 1, "bd_icon");
		
		return new WidgetBuilder()
				.withName("HAPPY_WIDGET_CONTAINER")
				.withTitle("Een groepje blije widgets")
				.withDescription("Deze widgets zijn heel blij.")
				.withIndex(1)
				.withOwnerDomain(ownerDomain)
				.build();
	}

	private Widget buildWidgetWithQuery() {
		List<QueryColumn> queryColumns = new ArrayList<>();
		queryColumns.add(QueryColumnBuilder.build(1, "COLUMN_ID", "columnId", null, null, "NUMBER", false, null));
		queryColumns.add(QueryColumnBuilder.build(2, "COLUMN_TYPE", null, null, "columnType", "STRING", false, null));
		queryColumns.add(QueryColumnBuilder.build(3, "COLUMN_NAME", null, null, null, "STRING", false, null));
		queryColumns.add(QueryColumnBuilder.build(4, null, null, "Fixed Value", "columnValue", "STRING", false, null));

		List<WidgetColumn> widgetColumns = new ArrayList<>();
		widgetColumns.add(WidgetColumnBuilder.build(1, "NUMBER", "Id", null, "visible", null, queryColumns.get(0), null));
		widgetColumns.add(WidgetColumnBuilder.build(2, "STRING", "Type", null, "visible", "text", queryColumns.get(1), null));
		widgetColumns.add(WidgetColumnBuilder.build(3, "STRING", "Naam", null, "visible", "text", queryColumns.get(2), null));
		widgetColumns.add(WidgetColumnBuilder.build(4, "STRING", "Waarde", "Deze waarde is constant", "visible", null, queryColumns.get(3), null));

		List<WidgetColumnAttribute> widgetColumnAttributes = new ArrayList<>();
		WidgetColumnAttribute widgetColumnAttribute = getWidgetColumnAttribute("widget_column_attribute_key1", "widget_column_attribute_value1");
		widgetColumnAttributes.add(widgetColumnAttribute);
		widgetColumns.get(1).setColumnAttributeList(widgetColumnAttributes);

		Domain ownerDomain = DomainBuilder.build("sad-key", "Treurig Klantbeeld", 1, "db_sadicon");
		
		Query query = new QueryBuilder()
				.withDatasource(DatasourceBuilder.build("HAPPY_SOURCE"))
				.withKey("SAD_QUERY")
				.withType(1)
				.withViewname("THE_BEST_VIEW")
				.withQuerytemplate("SELECT {resultColumns} FROM {viewname} WHERE EVERYTHING = GREAT")
				.withOwnerDomain(ownerDomain)
				.withQueryColumns(queryColumns)
				.build();

		return new WidgetBuilder()
				.withName("SAD_WIDGET")
				.withType("Table")
				.withTitle("Een treurige widget")
				.withDescription("Deze widget is niet blij.")
				.withIndex(1)
				.withQuery(query)
				.withWidgetColumns(widgetColumns)
				.withOwnerDomain(ownerDomain)
				.build();
	}

	private WidgetColumnAttribute getWidgetColumnAttribute(String key, String value) {
		WidgetColumnAttribute widgetColumnAttribute = new WidgetColumnAttribute();
		widgetColumnAttribute.setKey(key);
		widgetColumnAttribute.setValue(value);
		return widgetColumnAttribute;
	}

	private Widget buildWidgetWithQueryAndAttributesAndHelpAndRules() {
		Widget widget = buildWidgetWithQuery();

		List<WidgetAttribute> widgetAttributes = new ArrayList<>();
		WidgetAttribute widgetAttribute1 = getWidgetAttribute("widget_attribute_key1", "widget_attribute_value1");
		WidgetAttribute widgetAttribute2 = getWidgetAttribute("widget_attribute_key2", "widget_attribute_value2");

		widgetAttributes.add(widgetAttribute1);
		widgetAttributes.add(widgetAttribute2);
		widget.setAttributeList(widgetAttributes);

		List<WidgetHelp> widgetHelpList = new ArrayList<>();
		WidgetHelp widgetHelp = new WidgetHelp();
		widgetHelp.setIndex(1);
		widgetHelp.setHelp(getHelp(widget));
		widgetHelpList.add(widgetHelp);
		widget.setHelpList(widgetHelpList);

		List<Rule> ruleList = new ArrayList<>();
		Rule rule1 = RuleBuilder.build(1, "rule1");
		Rule rule2 = RuleBuilder.build(2, "rule2");
		ruleList.add(rule1);
		ruleList.add(rule2);
		RuleGroup ruleGroup = RuleGroupBuilder.build("RuleGroupKey", widget.getOwnerDomain(), ruleList);
		widget.setRuleGroup(ruleGroup);

		return widget;
	}

	private Widget buildContainerWidgetWithChildren() {
		Widget containerWidget = buildWidgetWithoutAnything();
		containerWidget.setName("Z_CONTAINER_WIDGET");
		containerWidget.setId(1);
		Widget innerWidget1 = buildWidgetWithoutAnything();
		innerWidget1.setName("B_INNERWIDGET_1");
		innerWidget1.setContainerWidget(containerWidget);
		Widget innerWidget2 = buildWidgetWithoutAnything();
		innerWidget2.setName("A_INNERWIDGET_2");
		innerWidget2.setContainerWidget(containerWidget);
		innerWidget2.setId(12);
		innerWidget2.setIndex(2);
		Widget innerInnerWidget21 = buildWidgetWithoutAnything();
		innerInnerWidget21.setName("D_INNERINNERWIDGET_1");
		innerInnerWidget21.setContainerWidget(innerWidget2);
		Widget innerInnerWidget22 = buildWidgetWithoutAnything();
		innerInnerWidget22.setName("C_INNERINNERWIDGET_2");
		innerInnerWidget22.setContainerWidget(innerWidget2);
		innerInnerWidget22.setIndex(2);

		List<Widget> innerInnerWidgetList = new ArrayList<>();
		innerInnerWidgetList.add(innerInnerWidget21);
		innerInnerWidgetList.add(innerInnerWidget22);
		innerWidget2.setWidgetList(innerInnerWidgetList);
		List<Widget> innerWidgetList = new ArrayList<>();
		innerWidgetList.add(innerWidget1);
		innerWidgetList.add(innerWidget2);
		containerWidget.setWidgetList(innerWidgetList);

		return containerWidget;
	}

	private Help getHelp(Widget widget) {
		Help help = new Help();
		help.setKey("helpkey");
		help.setTitle("helptitle");
		help.setContent("helpcontent");
		help.setOwnerDomain(widget.getOwnerDomain());
		return help;
	}

	private WidgetAttribute getWidgetAttribute(String key, String value) {
		WidgetAttribute widgetAttribute1 = new WidgetAttribute();
		widgetAttribute1.setKey(key);
		widgetAttribute1.setValue(value);
		return widgetAttribute1;
	}
}
