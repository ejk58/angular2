package nl.belastingdienst.iva.wd.configurator.controller;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.common.springboot.security.LoginCredentials;

public abstract class AbstractControllerTest {

    protected static final String START_REQUEST = "/api";

    protected String loginIvatest1(MockMvc mvc, ResultMatcher resultMatcher) throws Exception {
        return loginWithUser(mvc, "ivatest1", "Welkom01", resultMatcher);
    }

    protected String loginIvaall(MockMvc mvc, ResultMatcher resultMatcher) throws Exception {
        return loginWithUser(mvc, "ivaall", "Welkom01", resultMatcher);
    }

    protected String loginWithUser(MockMvc mvc, String userid, String password, ResultMatcher resultMatcher)
            throws Exception {
        LoginCredentials creds = new LoginCredentials();
        creds.setUsername(userid);
        creds.setPassword(password);
        String credsJson = new ObjectMapper().writeValueAsString(creds);
        MvcResult result = mvc.perform(post(START_REQUEST + "/login").content(credsJson)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(resultMatcher)
                .andReturn();
        return result.getResponse()
                .getHeader(HEADER_STRING);
    }
}
