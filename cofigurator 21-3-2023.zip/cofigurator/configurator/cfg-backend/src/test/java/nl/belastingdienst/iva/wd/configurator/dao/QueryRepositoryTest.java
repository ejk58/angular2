package nl.belastingdienst.iva.wd.configurator.dao;

import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.wd.configurator.domain.Datasource;
import nl.belastingdienst.iva.wd.configurator.domain.Query;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
@Log4j2
@DataJpaTest
public class QueryRepositoryTest {

    @MockBean
    NamedParameterJdbcTemplate namedJdbcTemplateConfigurator;

    @Autowired
    QueryRepository queryRepository;

    @Autowired
    DomainRepository domainRepository;

    @Test
    public void getQueryByKey() {
        Query query = this.queryRepository.findByKey("QUERY_1");
        assertEquals(1, query.getId());
        assertEquals(1, query.getType());
        assertEquals("teradataview_1", query.getViewname());
        assertEquals("SELECT col1, col2 FROM  teradataview_1 WHERE finr = 7777777 ORDER BY col1", query.getQuerytemplate());
        assertEquals("QUERY_1", query.getKey());
        assertEquals(1, query.getDatasource().getId());
        assertEquals("niet_winst", query.getOwnerDomain().getKey());
    }

    @Test
    public void getQueries() {
        List<Query> queryList = (List<Query>) this.queryRepository.findAll();
        assertEquals(8, queryList.size());
    }

    @Test
    public void getQueryKeysOrderByName() {
        List<String> queryNameList = this.queryRepository.findAllQueryKeysOrderByNameAsc();
        assertEquals("QUERY_1", queryNameList.get(0));
        assertEquals("QUERY_2", queryNameList.get(1));
        assertEquals("QUERY_3", queryNameList.get(2));
        assertEquals("RELATION_NOVIP_QUERY", queryNameList.get(3));
        assertEquals("RELATION_VIP_QUERY", queryNameList.get(4));
        assertEquals("SEARCH_NOVIP_QUERY", queryNameList.get(5));
        assertEquals("SEARCH_VIP_QUERY", queryNameList.get(6));
        assertEquals("SUBJECT_QUERY", queryNameList.get(7));
    }

    @Test
    public void saveQuery() {
        Query query = new Query();
        query.setId(20);
        query.setKey("NEW_QUERY");
        query.setType(1);
        query.setViewname("teradataview_new");
        query.setQuerytemplate("SELECT iets_nieuws FROM teradataview_new WHERE finr= 88888888");
        Datasource datasource = new Datasource();
        datasource.setId(1);
        query.setDatasource(datasource);
        query.setOwnerDomain(this.domainRepository.findByKey("niet_winst"));

        // precondition
        List<Query> queryList = (List<Query>) this.queryRepository.findAll();
        int numberOfQueries = queryList.size();

        // save action
        this.queryRepository.save(query);

        // test
        queryList = (List<Query>) this.queryRepository.findAll();
        assertEquals(numberOfQueries + 1, queryList.size());
        Query newQuery = this.queryRepository.findByKey("NEW_QUERY");
        assertEquals(1, newQuery.getType());
        assertEquals("teradataview_new", newQuery.getViewname());
        assertEquals("SELECT iets_nieuws FROM teradataview_new WHERE finr= 88888888", newQuery.getQuerytemplate());
        assertEquals("Teradata/IVAI", newQuery.getDatasource().getKey());
        assertEquals("niet_winst", newQuery.getOwnerDomain().getKey());
    }

    @Test
    public void changeQuery() {
        Query query = this.queryRepository.findByKey("QUERY_2");

        query.setKey("QUERY_2_CHANGED");
        query.setViewname("teradataview_2_changed");
        this.queryRepository.save(query);

        query = this.queryRepository.findByKey("QUERY_2_CHANGED");
        assertEquals("teradataview_2_changed", query.getViewname());
        assertEquals(2, query.getId());
    }

    @Test
    public void deleteQuery() {
        Query query = new Query();
        query.setId(21);
        query.setKey("NEW_QUERY_TO_DELETE");

        // save action
        this.queryRepository.save(query);

        List<Query> queryList = (List<Query>) this.queryRepository.findAll();
        int numberOfQueries = queryList.size();

        // delete action
        this.queryRepository.delete(query);

        queryList = (List<Query>) this.queryRepository.findAll();
        assertEquals(numberOfQueries - 1, queryList.size());
    }

    @Test(expected = DataIntegrityViolationException.class)
    public void deleteQueryThrowsException() {
        List<Query> queryList = (List<Query>) this.queryRepository.findAll();
        int numberOfQueries = queryList.size();

        Query query = this.queryRepository.findByKey("QUERY_1");

        this.queryRepository.delete(query);

        queryList = (List<Query>) this.queryRepository.findAll();
        assertEquals(numberOfQueries, queryList.size());
    }
}
