package nl.belastingdienst.iva.wd.configurator.domain;

public class DomainSubjecttypeBuilder {
    private DomainSubjecttype domainSubjecttype;

    public DomainSubjecttypeBuilder() {
        this.domainSubjecttype = new DomainSubjecttype();
    }

    public DomainSubjecttype build() {
        return this.domainSubjecttype;
    }

    public DomainSubjecttypeBuilder withLabel(String label){
        this.domainSubjecttype.setLabel(label);
        return this;
    }

    public DomainSubjecttypeBuilder withSearchkey(String searchkey) {
        this.domainSubjecttype.setSearchkey(searchkey);
        return this;
    }

    public DomainSubjecttypeBuilder withIndex(Integer index) {
        this.domainSubjecttype.setIndex(index);
        return this;
    }

    public DomainSubjecttypeBuilder withSearchfilter(String searchfilter) {
        this.domainSubjecttype.setSearchfilter(searchfilter);
        return this;
    }

    public static DomainSubjecttype build(String label, String searchkey, Integer index, String searchfilter) {
        return new DomainSubjecttypeBuilder()
                .withLabel(label)
                .withSearchkey(searchkey)
                .withIndex(index)
                .withSearchfilter(searchfilter)
                .build();
    }
}
