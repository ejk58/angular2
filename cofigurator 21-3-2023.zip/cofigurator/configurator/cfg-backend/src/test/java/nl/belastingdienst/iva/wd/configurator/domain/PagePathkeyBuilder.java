package nl.belastingdienst.iva.wd.configurator.domain;

public class PagePathkeyBuilder {
    private PagePathkey pagePathkey;

    public PagePathkeyBuilder() {
        this.pagePathkey = new PagePathkey();
    }

    public PagePathkey build() {
        return this.pagePathkey;
    }

    public PagePathkeyBuilder withName(String name){
        this.pagePathkey.setName(name);
        return this;
    }

    public static PagePathkey build(String name) {
        return new PagePathkeyBuilder()
                .withName(name)
                .build();
    }

}
