package nl.belastingdienst.iva.wd.configurator.domain;

public class PageDomainBuilder {
    private PageDomain pageDomain;

    public PageDomainBuilder() {
        this.pageDomain = new PageDomain();
    }

    public PageDomain build() {
        return this.pageDomain;
    }

    public PageDomainBuilder withGroupIndex(int groupIndex) {
        this.pageDomain.setGroupIndex(groupIndex);
        return this;
    }

    public PageDomainBuilder withMemberIndex(int memberIndex) {
        this.pageDomain.setMemberIndex(memberIndex);
        return this;
    }

    public PageDomainBuilder withPage(Page page) {
        this.pageDomain.setPage(page);
        return this;
    }

    public PageDomainBuilder withDomain(Domain domain) {
        this.pageDomain.setDomain(domain);
        return this;
    }

    public static PageDomain build(int groupIndex, int memberIndex, Page page, Domain domain) {
        return new PageDomainBuilder()
                .withGroupIndex(groupIndex)
                .withMemberIndex(memberIndex)
                .withPage(page)
                .withDomain(domain)
                .build();
    }

}
