package nl.belastingdienst.iva.wd.configurator.factory;

import org.junit.Assert;
import org.junit.Test;

public class ConfigurationSqlFactoryTest {

    private ConfigurationSqlFactory configurationSqlFactory;

    public ConfigurationSqlFactoryTest() {
        this.configurationSqlFactory = new ConfigurationSqlFactory();
    }

    @Test
    public void testInitialSqlStatementsForDomain() {

        String result = this.configurationSqlFactory.getDeleteScript("Klantbeeld1");

        Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_PATHKEY\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P JOIN CONF_DOMAIN D ON P.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_WIDGET\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P JOIN CONF_DOMAIN D ON P.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_DOMAIN\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P JOIN CONF_DOMAIN D ON P.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE_ATTRIBUTE\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P JOIN CONF_DOMAIN D ON P.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_PAGE\" WHERE OWNER_DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));

        Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\" WHERE WIDGET_COLUMN_ID IN (SELECT WC.ID FROM CONF_WIDGET_COLUMN WC JOIN CONF_WIDGET W ON WC.WIDGET_ID = W.ID JOIN CONF_DOMAIN D ON W.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_COLUMN\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W JOIN CONF_DOMAIN D ON W.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_HELP\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W JOIN CONF_DOMAIN D ON W.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET_ATTRIBUTE\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W JOIN CONF_DOMAIN D ON W.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_WIDGET\" WHERE OWNER_DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));

        Assert.assertTrue(result.contains("DELETE FROM \"CONF_DOMAIN_ROLE\" WHERE DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_DOMAIN_PATHKEY\" WHERE DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_DOMAIN_MENUGROUP\" WHERE DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_DOMAIN_ATTRIBUTE\" WHERE DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_DOMAIN_SUBJECTTYPE\" WHERE DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("UPDATE \"CONF_DOMAIN\" SET SUBJECT_QUERY_ID = NULL, RELATION_VIP_QUERY_ID = NULL, RELATION_NOVIP_QUERY_ID = NULL, SEARCH_VIP_QUERY_ID = NULL, SEARCH_NOVIP_QUERY_ID = NULL WHERE KEY = 'Klantbeeld1';"));

        Assert.assertTrue(result.contains("DELETE FROM \"CONF_HELP\" WHERE OWNER_DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));

        Assert.assertTrue(result.contains("DELETE FROM \"CONF_ATTRIBUTE\" WHERE ATTRIBUTE_GROUP_ID IN (SELECT AG.ID FROM CONF_ATTRIBUTE_GROUP AG JOIN CONF_DOMAIN D ON AG.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_ATTRIBUTE_GROUP\" WHERE OWNER_DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));

        Assert.assertTrue(result.contains("DELETE FROM \"CONF_RULE\" WHERE RULE_GROUP_ID IN (SELECT RG.ID FROM CONF_RULE_GROUP RG JOIN CONF_DOMAIN D ON RG.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_RULE_GROUP\" WHERE OWNER_DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));

        Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC2.ID FROM CONF_QUERY_COLUMN QC2 JOIN CONF_QUERY_COLUMN QC ON QC2.COMPOSITE_COLUMN_ID = QC.ID JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID JOIN CONF_DOMAIN D ON Q.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC.ID FROM CONF_QUERY_COLUMN QC JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID JOIN CONF_DOMAIN D ON Q.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q JOIN CONF_DOMAIN D ON Q.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_FILTER\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q JOIN CONF_DOMAIN D ON Q.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY_ATTRIBUTE\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q JOIN CONF_DOMAIN D ON Q.OWNER_DOMAIN_ID = D.ID WHERE D.KEY = 'Klantbeeld1');"));
        Assert.assertTrue(result.contains("DELETE FROM \"CONF_QUERY\" WHERE OWNER_DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'Klantbeeld1');"));

        Assert.assertEquals(27, SqlScriptTestUtils.countOccurences(result, "'Klantbeeld1'"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "UPDATE"));
        Assert.assertEquals(26, SqlScriptTestUtils.countOccurences(result, "DELETE FROM"));
    }

}
