package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.*;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class DomainSqlFactoryTest {

    private DomainSqlFactory domainSqlFactory;

    public DomainSqlFactoryTest() {
        this.domainSqlFactory = new DomainSqlFactory();
    }

    @Test
    public void testSqlStatementsForDomainWithoutChildren() {
        Domain domain = DomainBuilder.build("klantbeeld1-key", "Klantbeeld1 naam", 1, "bd_icon1");
        String result = this.domainSqlFactory.getInsertScript(domain);

        Assert.assertTrue(result.contains("MERGE INTO \"CONF_DOMAIN\" AS D USING (VALUES ('klantbeeld1-key', 'Klantbeeld1 naam', 'bd_icon1', 1, null, null, null, null, null)) AS X(KEY, NAME, ICONNAME, INDEX, SUBJECT_QUERY_ID, RELATION_QUERY_ID, SEARCH_QUERY_ID) ON D.KEY = X.KEY\n" +
                "  WHEN MATCHED THEN UPDATE SET KEY = X.KEY, NAME = X.NAME, ICONNAME = X.ICONNAME, INDEX = X.INDEX, SUBJECT_QUERY_ID = X.SUBJECT_QUERY_ID, RELATION_QUERY_ID = X.RELATION_QUERY_ID, SEARCH_QUERY_ID = X.SEARCH_QUERY_ID\n" +
                "  WHEN NOT MATCHED THEN INSERT (KEY, NAME, ICONNAME, INDEX, SUBJECT_QUERY_ID, RELATION_QUERY_ID, SEARCH_QUERY_ID) VALUES (X.KEY, X.NAME, X.ICONNAME, X.INDEX, X.SUBJECT_QUERY_ID, X.RELATION_QUERY_ID, X.SEARCH__QUERY_ID);"));
    }

    @Test
    public void testSqlStatementsForDomainWithRoles() {
        Domain domain = DomainBuilder.build("klantbeeld1-key", "Klantbeeld1 naam", 1, "bd_icon1");
        domain.setDomainRoleList(getDomainRoles());
        String result = this.domainSqlFactory.getInsertScript(domain);

        Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_ROLE\""));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_ROLE\"(DOMAIN_ID, TYPE, ROLE, VIPACCESS) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 0, 'aug_IVAI_user_klantbeeld1', 0);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_ROLE\"(DOMAIN_ID, TYPE, ROLE, VIPACCESS) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 0, 'aug_IVAI_vip_klantbeeld1', 1);"));
    }

    @Test
    public void testSqlStatementsForDomainWithPathkeys() {
        Domain domain = DomainBuilder.build("klantbeeld1-key", "Klantbeeld1 naam", 1, "bd_icon1");
        domain.setDomainPathkeyList(getDomainPathkeys());
        String result = this.domainSqlFactory.getInsertScript(domain);

        Assert.assertEquals(3, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_PATHKEY\""));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_PATHKEY\"(DOMAIN_ID, KEY, NAME, TITLE, TYPE, INDEX, MANDATORY) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'pk-key-1', 'pk-name-1', 'pk-title-1', 'NUMBER', 1, 0);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_PATHKEY\"(DOMAIN_ID, KEY, NAME, TITLE, TYPE, INDEX, MANDATORY) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'pk-key-2', 'pk-name-2', 'pk-title-2', 'STRING', 2, 0);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_PATHKEY\"(DOMAIN_ID, KEY, NAME, TITLE, TYPE, INDEX, MANDATORY) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'pk-key-1', 'pk-name-3', 'pk-title-3', 'YEAR', 3, 1);"));
    }

    @Test
    public void testSqlStatementsForDomainWithMenugroups() {
        Domain domain = DomainBuilder.build("klantbeeld1-key", "Klantbeeld1 naam", 1, "bd_icon1");
        domain.setDomainMenugroupList(getDomainMenugroups());
        String result = this.domainSqlFactory.getInsertScript(domain);

        Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_MENUGROUP\""));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_MENUGROUP\"(DOMAIN_ID, TITLE, ICONNAME, INDEX) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'menugroup-1', 'iconname1', 1);"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_MENUGROUP\"(DOMAIN_ID, TITLE, ICONNAME, INDEX) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'menugroup-2', 'iconname2', 2);"));
    }

    @Test
    public void testSqlStatementsForDomainWithAttributes() {
        Domain domain = DomainBuilder.build("klantbeeld1-key", "Klantbeeld1 naam", 1, "bd_icon1");
        domain.setDomainAttributeList(getDomainAttributes());
        String result = this.domainSqlFactory.getInsertScript(domain);

        Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_ATTRIBUTE\""));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_ATTRIBUTE\"(DOMAIN_ID, KEY, VALUE) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'subject', 'true');"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_ATTRIBUTE\"(DOMAIN_ID, KEY, VALUE) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'atribute2', 'value2');"));
    }

    @Test
    public void testSqlStatementsForDomainWithSubjecttypes() {
        Domain domain = DomainBuilder.build("klantbeeld1-key", "Klantbeeld1 naam", 1, "bd_icon1");
        domain.setDomainSubjecttypeList(getDomainSubjecttypes());
        String result = this.domainSqlFactory.getInsertScript(domain);

        Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_SUBJECTTYPE\""));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_SUBJECTTYPE\"(DOMAIN_ID, LABEL, SEARCHKEY, INDEX, SEARCHFILTER) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'Kenteken', 'KentekenId', 1, 'searchfilter1');"));
        Assert.assertTrue(result.contains("INSERT INTO \"CONF_DOMAIN_SUBJECTTYPE\"(DOMAIN_ID, LABEL, SEARCHKEY, INDEX, SEARCHFILTER) VALUES ((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key'), 'BSN/RSIN', 'subjectNr', 2, 'searchfilter2');"));
    }


    @Test
    public void testAllSqlStatementsForDomain() {
        Domain domain = buildCompleteDomain();
        String result = this.domainSqlFactory.getInsertScript(domain);

        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_DOMAIN\""));
        Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_ROLE\""));
        Assert.assertEquals(3, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_PATHKEY\""));
        Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_MENUGROUP\""));
        Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_ATTRIBUTE\""));
        Assert.assertEquals(2, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_DOMAIN_SUBJECTTYPE\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "UPDATE \"CONF_QUERY\" SET OWNER_DOMAIN_ID ="));

        Assert.assertTrue(result.contains("-- Domain klantbeeld1-key"));
        Assert.assertTrue(result.contains("(SELECT ID FROM CONF_QUERY WHERE KEY = 'klantbeeld1_SUBJECT')"));
        Assert.assertTrue(result.contains("(SELECT ID FROM CONF_QUERY WHERE KEY = 'klantbeeld1_RELATION')"));
        Assert.assertTrue(result.contains("(SELECT ID FROM CONF_QUERY WHERE KEY = 'klantbeeld1_SEARCH')"));
        Assert.assertTrue(result.contains("UPDATE \"CONF_QUERY\" SET OWNER_DOMAIN_ID = (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantbeeld1-key') WHERE KEY IN ('klantbeeld1_SUBJECT', 'klantbeeld1_RELATION_VIP', 'klantbeeld1_RELATION_NOVIP', 'klantbeeld1_SEARCH_VIP', 'klantbeeld1_SEARCH_NOVIP' );"));
    }

    private Domain buildCompleteDomain() {
        Domain domain = DomainBuilder.build("klantbeeld1-key", "Klantbeeld1 naam", 1, "bd_icon1");
        domain.setDomainRoleList(getDomainRoles());
        domain.setDomainPathkeyList(getDomainPathkeys());
        domain.setDomainMenugroupList(getDomainMenugroups());
        domain.setDomainAttributeList(getDomainAttributes());
        domain.setDomainSubjecttypeList(getDomainSubjecttypes());

        domain.setSubjectQuery(getQuery(domain, "klantbeeld1_SUBJECT"));
        domain.setRelationQuery(getQuery(domain, "klantbeeld1_RELATION"));
        domain.setSearchQuery(getQuery(domain, "klantbeeld1_SEARCH"));

        return domain;
    }

    private List<DomainSubjecttype> getDomainSubjecttypes() {
        List<DomainSubjecttype> domainSubjecttypes = new ArrayList<>();
        domainSubjecttypes.add(DomainSubjecttypeBuilder.build("Kenteken", "KentekenId", 1, "searchfilter1"));
        domainSubjecttypes.add(DomainSubjecttypeBuilder.build("BSN/RSIN", "subjectNr", 2, "searchfilter2"));
        return domainSubjecttypes;
    }

    private List<DomainAttribute> getDomainAttributes() {
        List<DomainAttribute> domainAttributes = new ArrayList<>();
        domainAttributes.add(DomainAttributeBuilder.build("subject", "true"));
        domainAttributes.add(DomainAttributeBuilder.build("atribute2", "value2"));
        return domainAttributes;
    }

    private List<DomainMenugroup> getDomainMenugroups() {
        List<DomainMenugroup> domainMenugroups = new ArrayList<>();
        domainMenugroups.add(DomainMenugroupBuilder.build("menugroup-1", 1, "iconname1"));
        domainMenugroups.add(DomainMenugroupBuilder.build("menugroup-2", 2, "iconname2"));
        return domainMenugroups;
    }

    private List<DomainPathkey> getDomainPathkeys() {
        List<DomainPathkey> domainPathkeys = new ArrayList<>();
        domainPathkeys.add(DomainPathkeyBuilder.build("pk-key-1", "pk-name-1", "pk-title-1", "NUMBER", 1, 0));
        domainPathkeys.add(DomainPathkeyBuilder.build("pk-key-2", "pk-name-2", "pk-title-2", "STRING", 2, 0));
        domainPathkeys.add(DomainPathkeyBuilder.build("pk-key-1", "pk-name-3", "pk-title-3", "YEAR", 3, 1));
        return domainPathkeys;
    }

    private List<DomainRole> getDomainRoles() {
        List<DomainRole> domainRoles = new ArrayList<>();
        domainRoles.add(DomainRoleBuilder.build(0, "aug_IVAI_user_klantbeeld1", 0));
        domainRoles.add(DomainRoleBuilder.build(0, "aug_IVAI_vip_klantbeeld1", 1));
        return domainRoles;
    }

    private Query getQuery(Domain ownerDomain, String queryKey) {
        List<QueryColumn> queryColumns = new ArrayList<>();
        queryColumns.add(QueryColumnBuilder.build(1, "COLUMN_ID", "columnId", null, null, "NUMBER", false, null));
        queryColumns.add(QueryColumnBuilder.build(2, "COLUMN_TYPE", null, null, "columnType", "STRING", false, null));
        queryColumns.add(QueryColumnBuilder.build(3, "COLUMN_NAME", null, null, null, "STRING", false, null));
        queryColumns.add(QueryColumnBuilder.build(4, null, null, "Fixed Value", "columnValue", "STRING", false, null));

        Query query = new QueryBuilder()
                .withDatasource(DatasourceBuilder.build("HAPPY_SOURCE"))
                .withKey(queryKey)
                .withType(1)
                .withViewname(queryKey + "_VIEW")
                .withQuerytemplate("SELECT {resultColumns} FROM {viewname} WHERE EVERYTHING = GREAT")
                .withOwnerDomain(ownerDomain)
                .withQueryColumns(queryColumns)
                .build();
        return query;
    }
}
