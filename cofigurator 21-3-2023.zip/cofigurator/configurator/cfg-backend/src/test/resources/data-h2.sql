-- INZICHT TABLES --
-- datasource
INSERT INTO CONF_DATASOURCE (ID,KEY) VALUES
    (1,'Teradata/IVAI'),
    (2,'Rest/Inzicht');

-- domain queries
INSERT INTO CONF_QUERY(ID,TYPE,VIEWNAME,QUERYTEMPLATE,KEY,DATASOURCE_ID,OWNER_DOMAIN_ID) VALUES
    (3, 1, 'teradataview_3', 'SELECT relation_vip_col FROM  teradataview_3 WHERE finr = 7777777', 'RELATION_VIP_QUERY', 1, null),
    (4, 1, 'teradataview_4', 'SELECT relation_novip_vol FROM  teradataview_4 WHERE finr = 7777777', 'RELATION_NOVIP_QUERY', 1, null),
    (5, 1, 'teradataview_5', 'SELECT search_vip_col FROM  teradataview_5 WHERE finr = 7777777 ', 'SEARCH_VIP_QUERY', 1, null),
    (6, 1, 'teradataview_6', 'SELECT search_novip_col FROM  teradataview_6 WHERE finr = 7777777', 'SEARCH_NOVIP_QUERY', 1, null),
    (7, 1, 'teradataview_7', 'SELECT subject_col FROM  teradataview_7 WHERE finr = 7777777', 'SUBJECT_QUERY', 1, null);

-- domain
INSERT INTO CONF_DOMAIN (ID,KEY,NAME,RELATION_VIP_QUERY_ID,RELATION_NOVIP_QUERY_ID,SEARCH_VIP_QUERY_ID,SEARCH_NOVIP_QUERY_ID,INDEX,ICONNAME,SUBJECT_QUERY_ID) VALUES
    (1,'niet_winst','Niet-Winst',3,4,5,6,1,'bd_nietwinst',7),
    (2,'di','MKB/GO Toezicht',3,4,5,6,2,'bd_toezicht',7);

-- queries
INSERT INTO CONF_QUERY(ID,TYPE,VIEWNAME,QUERYTEMPLATE,KEY,DATASOURCE_ID,OWNER_DOMAIN_ID) VALUES
    (1, 1, 'teradataview_1', 'SELECT col1, col2 FROM  teradataview_1 WHERE finr = 7777777 ORDER BY col1', 'QUERY_1', 1, 1),
    (2, 1, 'teradataview_2', 'SELECT col3, col4 FROM  teradataview_2 WHERE finr = 7777777 ORDER BY col4', 'QUERY_2', 2, 2),
    (8, 1, 'teradataview_3', 'SELECT col3, col4 FROM  teradataview_3 WHERE finr = 7777777 ORDER BY col4', 'QUERY_3', 2, null);

-- query columns
INSERT INTO CONF_QUERY_COLUMN (ID,QUERY_ID,COMPOSITE_COLUMN_ID,INDEX,NAME,ALIAS,MASKABLE,KEY,TYPE,VALUE) VALUES
    (1,1,null,1,'kantoor',null,0,null,'STRING',null),
    (2,1,null,2,'segment',null,0,null,'STRING',null),
    (3,1,null,3,'entiteit_naam',null,0,null,'STRING',null),
    (4,2,null,1,'entiteitnr',null,0,null,'NUMBER',null);

-- widget
INSERT INTO CONF_WIDGET (ID,QUERY_ID,CONTAINER_WIDGET_ID,NAME,TYPE,TITLE,DESCRIPTION,REFRESHINFO,INDEX,VISIBLE,RULE_GROUP_ID,OWNER_DOMAIN_ID) VALUES
    (1,1,null,'WIDGET_1','Table','Titel widget 1','Omschrijving widget 1',1,1,1,null,1),
    (2,2,null,'WIDGET_2','List','Titel widget 2','Omschrijving widget 2',1,1,1,null,2),
    (3,8,null,'WIDGET_3','List','Titel generic widget 3','Omschrijving generic widget 3',1,1,1,null,null);

-- widget columns
INSERT INTO CONF_WIDGET_COLUMN (ID,WIDGET_ID,QUERY_COLUMN_ID,INDEX,TYPE,LABEL,DESCRIPTION,BEHAVIOUR,FILTER) VALUES
    (1,1,1,1, 'STRING', 'Kantoor', null, 'visible', null),
    (2,1,1,1, 'STRING', 'Segment', null, 'visible', null),
    (3,1,1,1, 'STRING', 'Entiteitnaam', null, 'visible', null),
    (4,2,1,1, 'NUMBER', 'Entiteit nummer', null, 'visible', null);

-- widget attributes
INSERT INTO CONF_WIDGET_ATTRIBUTE (ID, WIDGET_ID, KEY, VALUE) VALUES
    (1, 1, 'W1 A1 key1', 'W1 A1 value1'),
    (2, 1, 'W1 A2 key2', 'W1 A2 value2');

-- pages
INSERT INTO CONF_PAGE (ID,KEY,TITLE,TYPE,OWNER_DOMAIN_ID) VALUES
    (1,'pag1','Pagina 1','main',1),
    (2,'pag2','Pagina 2','main',1),
    (3,'pag3','Pagina 3','main',2);

-- pathkeys
INSERT INTO CONF_PAGE_PATHKEY (ID,PAGE_ID,NAME) VALUES
    (1,1,'subjectNr'),
    (2,1,'taxYear'),
    (3,2,'entityNr');

-- page widgets
INSERT INTO CONF_PAGE_WIDGET (ID,PAGE_ID,WIDGET_ID,GRID_COLUMNS,ROW_INDEX,COLUMN_INDEX) VALUES
    (1,1,1,4,1,1),
    (2,2,2,2,2,1);

-- CONFIGURATOR TABLES --
-- environment
INSERT INTO ENVIRONMENT (ID,NAME,TYPE) VALUES
    (1,'ont.str11','development'),
    (2,'opleiding','acceptation'),
    (3,'production','production');
