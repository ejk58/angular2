#!/bin/sh
# Do auto deploy based on input

#Path
source $HOME/.bash_profile
PATH=$PATH:/usr/local/bin:/usr/local/sbin:/usr/sbin:/sbin

# Regex props
regex="^package-([a-zA-Z-]*)-([0-9a-zA-Z.-]*).zip$"
asRegex="^(.+)-as$"
versionRegex='s/\([^;]*;\)\{4\}"\([^"]*\)";.*$/\2/'

# Properties
wasadmin="/opt/IBM/WebSphere/AppServer/bin/wsadmin.sh"
getClusterScript="/home/virtuser/script/getCluster.jacl"
getWebserverScript="/home/virtuser/script/getWebserver.jacl"

wasUpload="/prj/wasUpload"
asProject=false

# Global variables
appId=""
newVersion=""
webserver=""
versionOld=""

printf "\n**************************************************************"
printf "\n** Auto deployment script ** `basename $0` ***************************"
printf "\n** CoE Maatwerk **********************************************"
printf "\n** 2017 ******************************************************"
printf "\n**************************************************************"
printf "\n\n"


usage="$(basename "$0") [-h] -c value -C value -s value -f value -f value -a value -e value

where:
    -h  show this help text
    -c  Id of cell of environment, for example ontJHoP01 or tstJHoP01
    -C  cluster name, for example: CLS_IVA-NOTE_O
    -s  Street for deployment, for example str11 or str14
    -f  File to deploy. Example : package-application-name-1.0.0-SNAPSHOT.zip
    -e  the Id of the enviroment (ont, tst, acc or prd)"

while getopts ":h:c:C:s:f:b:e:" opt; do
     case $opt in
          h)   echo "$usage"
               exit
               ;;
          c)   cellId="$OPTARG"
               ;;
          C)   clusterId="$OPTARG"
               ;;
          s)   street="$OPTARG"
               ;;
          f)   fileName="$OPTARG"
	       fileName=`basename ${fileName}`
               ;;
          e)   environment="$OPTARG"
               ;;
          :)   printf "\nMissing arguments for -%s\n" "$OPTARG" >&2
               echo "$usage" >&2
               exit 1
               ;;
          \?)     printf "\nInvalid option: -%s -$OPTARG\n" >&2
               echo "$usage" >&2
               exit 1
               ;;
     esac
done

checkFilename()
{
	if [[ $fileName =~ $regex ]]; then
		appId="${BASH_REMATCH[1]}"
		newVersion="${BASH_REMATCH[2]}"
		echo "-- $appId :: $asRegex --"
		if [[ $appId =~ $asRegex ]]; then
			asProject=true
		fi
	else
		printf "\nInput file doesn't match format\nShowing help functionality\n\n"
		echo "$usage" >&2
		exit 1
	fi
}

determineWebserver()
{
	webserverCmd="sh $wasadmin -lang jacl -f $getWebserverScript"
	webserverFilter=`$webserverCmd | grep "=webserver_"`
	webserver=`echo $webserverFilter | sed 's/^server=//'`
}

printDeploymentInformation()
{
	printf "\n"
	printf "\n**************************************************************"
	printf "\n** $1"
	printf "\n** environment = $environment"
	printf "\n** cellId      = $cellId"
	printf "\n** appId       = $appId"
	printf "\n** street      = $street"
	printf "\n** fileName    = $fileName"
	printf "\n** newVersion  = $newVersion"
	printf "\n** cluster     = $clusterId"
	printf "\n** webserver   = $webserver"
	printf "\n** AS-package  = $asProject"
	printf "\n**************************************************************"
	printf "\n"
}

determineCurrentlyInstalledApplicationVersion()
{
	versionCmd="cad liststreets --csv $cellId"
	versionFilter=`$versionCmd | egrep "$street;[^;]*;[\"]?$appId[\"]?"`
	versionOld=`echo $versionFilter | sed $versionRegex`

	printf "\n"
	printf "\n** Current installed version: $versionOld"
	printf "\n"
}

deinstallingCurrentlyInstalledApplication()
{
     if [ "$asProject" == "true" ] && [ "$versionOld" == "$newVersion" ] ; then
	 printf "\n"
	 printf "\n**************************************************************"
	 printf "\n** Not replacing MQ-AS project with the same version."
	 printf "\n**************************************************************"
	 printf "\n"
	 # Removing the package file from the wasUpload directory
	 # rm ${wasUpload}/${fileName}
	 exit 0
     else
	 printf "\n"
	 printf "\n**************************************************************"
	 printf "\n** Uninstall $appId $versionOld on $cellId with $street"
	 printf "\n**************************************************************"
	 printf "\n"
	 cad deactivate $appId $versionOld $cellId $street
	 cad deinstall $appId $versionOld $cellId $street
     fi
}

#addNewPackageToDsl()
#{
#    listDslCmd="cad listdsl --csv"
#    filterDslCmd=`$listDslCmd | egrep "[\"]?$appId[\"]?;\"$newVersion\""`
#
#    if [ "$filterDslCmd" == "" ] ; then
#	printf "\n"
#	printf "\n**************************************************************"
#	printf "\n** $appId-$newVersion not in DSL. Going to add it anyway"
#	printf "\n**************************************************************"
#	printf "\n"
#    else
#	printf "\n"
#	printf "\n**************************************************************"
#	printf "\n** $appId-$newVersion already in DSL. Going to remove and then add it"
#	printf "\n**************************************************************"
#	printf "\n"
#	cad remove $appId $newVersion
#    fi
#    cad add $appId $newVersion
#}

checkStatusCode() {
    httpStatusCode=`curl -s -o /dev/null -I -w "%{http_code}" $url --insecure `
    echo $httpStatusCode
}

checkApplicationResponse()
{
    printf "\n** Autodeployment was succesful. We are now going to check if application is active on url \n"

    protocol="https"
    url="$protocol://$appId.$street.$environment.belastingdienst.nl/$appId/"

    printf "\n** Url: $url \n"

    stCode=0
    maxCount=0
    acceptCount=0
    until [[ $acceptCount -gt 4 || $maxCount -gt 49  ]]
    do
	maxCount=$((maxCount+1))
	stCode=$(checkStatusCode)
	if [ "$stCode" == "200" ]
	then
	    acceptCount=$((acceptCount+1))
	    printf "\n**Attempt $maxCount :  getting correct http status code:  $stCode ($acceptCount / 5)"
	else
	    printf "\n**Attempt $maxCount :  getting http status code:  $stCode"
	fi
	sleep 3
    done
}

main()
{
	checkFilename
	determineWebserver
	printDeploymentInformation "ad_v2.sh: input data:"
	determineCurrentlyInstalledApplicationVersion

	if [ "$versionOld" != "" ] ; then
	    deinstallingCurrentlyInstalledApplication
	fi

#	addNewPackageToDsl

#	printDeploymentInformation "ad.sh: installation of new file:"

	cad install --cluster $clusterId --webservers $webserver $appId $newVersion $cellId $street
	cad activate $appId $newVersion $cellId $street

	if [ "$asProject" != "true" ] ; then
	    # If the is only a package with an Activation Specification then we don't check the URL.
	    # Normally the actual package is deployed immediatelly after this package has been deployed

	    checkApplicationResponse
	else
	    printf "!!!! Project with ActivationSpecification installed. Server has to be restarted !!!!\n"
	fi

	printf "\n\n** Application is deployed and running"
	printf "\n\n** You should be able to access the application by: $url"
	printf "\n\n** Thank you, Have a nice day!\n\n"
}

main
