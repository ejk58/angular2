#!/bin/sh
# Cronjob to check on new files in the wasUpload directory and lock the ad process if needed

#Props
wasUpload="/prj/wasUpload"
buildInfoProp="adBuildInfo.properties"
adLockFile="$HOME/ad.lock"
regex="^package-([a-zA-Z-]*)-([0-9a-zA-Z.-]*).zip$"
regexAS="^package-([a-zA-Z-]*)-as-([0-9a-zA-Z.-]*).zip$"
adScriptLocation="/home/virtuser/script/ad.sh"
asProject=false
joinProject=X

echo(){
	printf "`date`: $1\n"
}

if [ -e "$adLockFile" ]; then
	lockCmd="cat $adLockFile"
	lock=`$lockCmd`
fi

if [ "$lock" == "true" ]; then
    printf "AD proces is locked\n"
	exit;
fi
 
printf "true" > $adLockFile

if test "$(ls -A "$wasUpload")"; then
	for entry in "$wasUpload"/*
	do
		fileName=`basename $entry`
		if [[ $fileName =~ $regex ]]; then
			if [[ $fileName =~ $regexAS ]]; then
				asProject=true
			fi
			echo "Match on file $entry, Try to get all information from included $buildInfoProp"
			adBuildInfoCmd="unzip -p $entry $buildInfoProp"
			for line in `$adBuildInfoCmd`  
 			do   
			    lineExt="printf $line"
				lineN=`$lineExt | tr -d '\n' | tr -d '\r'`
				eval $lineN
			done
			
			sh $adScriptLocation -c $cell -s $street -f $fileName -t $cluster -b $buildnumber -a $asProject	-j $joinProject
		else
			echo "no match ignore file $entry"
		fi
	done
fi

rm $adLockFile
