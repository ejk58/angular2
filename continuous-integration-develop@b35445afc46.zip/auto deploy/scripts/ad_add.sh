#!/bin/sh
# Do auto deploy based on input

#Path
source $HOME/.bash_profile
PATH=$PATH:/usr/local/bin:/usr/local/sbin:/usr/sbin:/sbin

buildInfoProp="adBuildInfo.properties"
wasUpload="/prj/wasUpload"

# Regex props
packageNameVersionRegex="^package-([a-zA-Z-]*)-([0-9a-zA-Z.-]*).zip$"
regexBuildnumber="^buildnumber"

printf "\n**************************************************************"
printf "\n** Auto deployment script ** `basename $0` ***********************"
printf "\n** CoE Maatwerk **********************************************"
printf "\n** 2017 ******************************************************"
printf "\n**************************************************************"
printf "\n\n"


usage="$(basename "$0") [-h] -f value

where:
    -h  show this help text
    -f  File to deploy. Example : package-application-name-1.0.0-SNAPSHOT.zip"

while getopts ":h:f:" opt; do
     case $opt in
          h)   echo "$usage"
               exit
               ;;
          f)   fileName="$OPTARG"
	       fileName=`basename ${fileName}`
               ;;
          :)   printf "\nMissing arguments for -%s\n" "$OPTARG" >&2
               echo "$usage" >&2
               exit 1
               ;;
          \?)  printf "\nInvalid option: -%s -$OPTARG\n" >&2
               echo "$usage" >&2
               exit 1
               ;;
     esac
done

checkFilename()
{
	if [[ $fileName =~ $packageNameVersionRegex ]]; then
		appId="${BASH_REMATCH[1]}"
		newVersion="${BASH_REMATCH[2]}"
	else
		printf "\nInput file doesn't match format\nShowing help functionality\n\n"
		echo "$usage" >&2
		exit 1
	fi
}

processingBuildInfoFile() {
	echo "processingBuildInfoFile: Try to get all information from included $buildInfoProp from $wasUpload/$fileName"
	adBuildInfoCmd="unzip -p $wasUpload/$fileName $buildInfoProp"
	for line in `$adBuildInfoCmd`  
	do   
		lineExt="printf $line"
		lineN=`$lineExt | tr -d '\n' | tr -d '\r'`
		if [[ $lineN =~ $regexBuildnumber ]]; then
			eval $lineN
		fi
	done
}

printDeploymentInformation()
{
	printf "\n"
	printf "\n**************************************************************"
	printf "\n** $1"
	printf "\n** appId = $appId"
	printf "\n** fileName = $fileName"
	printf "\n** newVersion = $newVersion"
	printf "\n** buildnummer = $buildnumber"
	printf "\n**************************************************************"
	printf "\n"
}

addNewPackageToDsl()
{
    listDslCmd="cad listdsl --csv"
    filterDslCmd=`$listDslCmd | egrep "[\"]?$appId[\"]?;\"$newVersion\""`

    if [ "$filterDslCmd" == "" ] ; then
	printf "\n"
	printf "\n**************************************************************"
	printf "\n** $appId-$newVersion not in DSL. Going to add it anyway"
	printf "\n**************************************************************"
	printf "\n"
    else
	printf "\n"
	printf "\n**************************************************************"
	printf "\n** $appId-$newVersion already in DSL. Going to remove and then add it"
	printf "\n**************************************************************"
	printf "\n"
	cad remove $appId $newVersion
    fi
    cad add $appId $newVersion
}

main()
{
	checkFilename
	processingBuildInfoFile

	printDeploymentInformation "ad_add.sh: input data:"

	addNewPackageToDsl

	printf "\n\n** Package added to DSL."
}

main

