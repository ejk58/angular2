#!/bin/sh
# Do auto deploy based on input

#Path
source $HOME/.bash_profile
PATH=$PATH:/usr/local/bin:/usr/local/sbin:/usr/sbin:/sbin

#Props
regex="^package-([a-zA-Z-]*)-([0-9a-zA-Z.-]*).zip$"
asRegex="^(.+)-as$"
wasadmin="/opt/IBM/WebSphere/AppServer/bin/wsadmin.sh"
getClusterScript="/home/virtuser/script/getCluster.jacl"
getWebserverScript="/home/virtuser/script/getWebserver.jacl"

wasUpload="/prj/wasUpload"
asProject=false

shopt -s nocasematch

printf "\n**************************************************************"
printf "\n** Auto deployment script ************************************"
printf "\n** CoE Maatwerk **********************************************"
printf "\n** 2017 ******************************************************"
printf "\n**************************************************************"
printf "\n\n"


usage="$(basename "$0") [-h] -c value -s value -f value [-t value] [-b value]

where:
    -h  show this help text
    -c  Id of cell of environment, for example ontJHoP01 or tstJHoP01
    -s  Street for deployement, for example str11 or str14
    -f  File to deploy. Example : package-application-name-1.0.0-SNAPSHOT.zip
    -t  Which type of cluster. This field is optional. Default is OLTP
    -b  Unique buildnummer of deployed artifact, this is used for a validation check
    -a  value should be true when processing an MQ Activication Specification project otherwise it should be false
    -j  project name used to select the cluster to be deployed on."

while getopts ":h:c:s:f:t:b:a:j:" opt; do
     case $opt in
          h)     echo "$usage"
               exit
               ;;
          c)     cellId="$OPTARG"
               ;;
          s)     street="$OPTARG"
               ;;
          f)     fileName="$OPTARG"
               ;;
          t)     clusterInput="$OPTARG"
               ;;
          b)     buildNumber="$OPTARG"
               ;;
          a)     asProject="$OPTARG"
               ;;
          j)     joinProject="$OPTARG"
		  printf "\njoinProject argument found: ${joinProject}\n"
               ;;
          :)     printf "\nMissing arguments for -%s\n" "$OPTARG" >&2
               echo "$usage" >&2
               exit 1
               ;;
          \?)     printf "\nInvalid option: -%s -$OPTARG\n" >&2
               echo "$usage" >&2
               exit 1
               ;;
     esac
done

if [[ $fileName =~ $regex ]]; then
        appId="${BASH_REMATCH[1]}"
        newVersion="${BASH_REMATCH[2]}"
else
        printf "\nInput file doesn't match format\nShowing help functionality\n\n"
     echo "$usage" >&2
        exit 1
fi

tempAppId=$appId
if [ "${asProject}" == "true" ] ; then
	if [[ $appId =~ $asRegex ]] ; then
		tempAppId=${BASH_REMATCH[1]}
        fi
fi
if [ "${joinProject}" != "X" ] ; then
	tempAppId=${joinProject}
fi

printf "\n+++ Determine cluster using applicationId $tempAppId -- joinProject = ${joinPropject}"
if [ "$clusterInput" == "webservice" ]
then
    regexCluster="cluster=([a-zA-Z_-]*${tempAppId}_W)"
elif [ "$clusterInput" == "webservice_secure" ]
then
    regexCluster="cluster=([a-zA-Z_-]*${tempAppId}_WS)"
else
    regexCluster="^cluster=([a-zA-Z_-]*${tempAppId}_O)"
fi

printf "\n+++ regexCluster is $regexCluster"
clusterCmd="sh $wasadmin -lang jacl -f $getClusterScript"
clusterFilter=`$clusterCmd | grep "cluster="`

while read line
do
        if [[ $line =~ $regexCluster ]]
        then
        cluster="${BASH_REMATCH[1]}"
        fi
done <<< "$(echo -e "$clusterFilter")"

webserverCmd="sh $wasadmin -lang jacl -f $getWebserverScript"
webserverFilter=`$webserverCmd | grep "=webserver_"`
webserver=`echo $webserverFilter | sed 's/^server=//'`

printf "\n"
printf "\n**************************************************************"
printf "\n** Input:"
printf "\n** cellId = $cellId"
printf "\n** appId = $appId"
printf "\n** street = $street"
printf "\n** fileName = $fileName"
printf "\n** newVersion = $newVersion"
printf "\n** cluster = $cluster"
printf "\n** webserver = $webserver"
printf "\n** buildNumber= $buildNumber"
printf "\n**************************************************************"
printf "\n"

versionCmd="cad liststreets --csv $cellId"
versionFilter=`$versionCmd | egrep "$street;[^;]*;[\"]?$appId[\"]?"`
versionRegex='s/\([^;]*;\)\{4\}"\([^"]*\)";.*$/\2/'
versionOld=`echo $versionFilter | sed $versionRegex`

printf "\n"
printf  "\n** Current installed version: $versionOld"
printf "\n"

if [ "$versionOld" != "" ] ; then
     if [ "$asProject" == "true" ] && [ "$versionOld" == "$newVersion" ] ; then
         printf "\n"
         printf "\n**************************************************************"
         printf "\n** Not replacing MQ-AS project with the same version."
         printf "\n**************************************************************"
         printf "\n"
	 # Removing the package file from the wasUpload directory
	 rm ${wasUpload}/${fileName}
	 exit 0
     else
         printf "\n"
         printf "\n**************************************************************"
         printf "\n** Uninstall $appId $versionOld on $cellId with $street"
         printf "\n**************************************************************"
         printf "\n"
         cad deactivate $appId $versionOld $cellId $street
         cad deinstall $appId $versionOld $cellId $street
     fi
fi

listDslCmd="cad listdsl --csv"
filterDslCmd=`$listDslCmd | egrep "[\"]?$appId[\"]?;\"$newVersion\""`

if [ "$filterDslCmd" == "" ] ; then
     printf "\n"
     printf "\n**************************************************************"
     printf "\n** $appId-$newVersion not in DSL. Going to add it anyway"
     printf "\n**************************************************************"
     printf "\n"
     cad add $appId $newVersion
else
     printf "\n"
     printf "\n**************************************************************"
     printf "\n** $appId-$newVersion already in DSL. Going to remove and then add it"
     printf "\n**************************************************************"
     printf "\n"
     cad remove $appId $newVersion
    cad add $appId $newVersion
fi

printf "\n"
printf "\n**************************************************************"
printf "\n** Installation of new file"
printf "\n** Cluster: $cluster"
printf "\n** Webserver: $webserver"
printf "\n** Application Id: $appId"
printf "\n** New Version: $newVersion"
printf "\n** Cell Id: $cellId"
printf "\n** Street: $street"
printf "\n**************************************************************"
printf "\n"

cad install --cluster $cluster --webservers $webserver $appId $newVersion $cellId $street

cad activate $appId $newVersion $cellId $street

if [ "$asProject" != "true" ] ; then
	# if the is only a package with an Activation Specification then we don't check the URL.
	# Normally the actual pacakge is deployed immediatelly after this package has been deployed

	printf "\n** Autodeployement was succesful. We are now going to check if application is active on url \n"

	protocol="https"
	if [ "$clusterInput" == "webservice" ]; then
		protocol="http"
	fi

	environment="ont"
	if [ "$cellId" == "tstJHoP01" ] || [ "$cellId" == "tst85" ]; then
		environment="tst"
	fi

	url="$protocol://$appId.$street.$environment.belastingdienst.nl/$appId/"

	printf "\n** Url: $url \n"

	checkStatusCode() {
	   httpStatusCode=`curl -s -o /dev/null -I -w "%{http_code}" $url --insecure `
	   echo $httpStatusCode
	}

	stCode=0
	maxCount=0
	acceptCount=0
	until [[ $acceptCount -gt 4 || $maxCount -gt 49  ]]
	do
		maxCount=$((maxCount+1))
		stCode=$(checkStatusCode)
		if [ "$stCode" == "200" ]
		then
			acceptCount=$((acceptCount+1))
			printf "\n**Attempt $maxCount :  getting correct http status code:  $stCode ($acceptCount / 5)"
		else
			printf "\n**Attempt $maxCount :  getting http status code:  $stCode"
		fi
	    sleep 3
	done
fi

printf "\n\n** Application is deployed and running"
printf "\n\n** You should be able to access the application by: $url"

printf "\n\n** Thank you, Have a nice day!\n\n"
