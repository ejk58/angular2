#!/usr/bin/bash
job=$1
env=$2
str=$3
user=$4
pwtoken=$5
token=$6

curl -k -X POST https://coewd-jenkins.belastingdienst.nl/jenkins/job/${job}/build?token=${token} \
  --user ${user}:${pwtoken} \
  --data-urlencode json="{'parameter': [{'name':'environment', 'value':'${env}'}, {'name':'street', 'value':'${str}'}]}"