#!/usr/bin/python3
import requests
import argparse

parser = argparse.ArgumentParser(description='delete silence from alertmanager')
parser.add_argument("silenceID",  help="silence ID")

args = parser.parse_args()
silenceID = args.silenceID

print(silenceID)

url = "http://coewd-grafana.belastingdienst.nl:9093/api/v2/silence/" + silenceID

try:
  res = requests.delete(url)
  if res.status_code == 200:
    print("Silence ID " + silenceID + " is verwijderd ")
  else:
    print("Het verwijderen van de silence is fout gegaan met http code=" + str(res.status_code) + " " +  res.text)
except requests.exceptions.RequestException as e:
  print(e)
  print("alertmanager is niet beschikbaar")


