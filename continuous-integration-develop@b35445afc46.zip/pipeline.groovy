@Library("GENERIC") _
    pipelineCiUitrol {
    }
