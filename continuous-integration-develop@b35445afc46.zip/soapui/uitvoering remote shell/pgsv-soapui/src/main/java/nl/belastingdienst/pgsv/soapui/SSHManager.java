package nl.belastingdienst.pgsv.soapui;

import static java.nio.charset.StandardCharsets.ISO_8859_1;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class SSHManager {
	private static final Logger LOGGER = Logger.getLogger(SSHManager.class.getName());
	private JSch jschSSHChannel;
	private String strUserName;
	private String strConnectionIP;
	private String strConnectionHost;
	private int intConnectionPort;
	private String strPassword;
	private Session sesConnection;
	private int intTimeOut;

	private void doCommonConstructorActions(String userName, String password, String connectionHost) {
		jschSSHChannel = new JSch();
		strUserName = userName;
		strPassword = password;
		strConnectionHost = connectionHost;
	}

	public SSHManager(String userName, String password, String connectionHost) {
		doCommonConstructorActions(userName, password, connectionHost);
		intConnectionPort = 22;
		intTimeOut = 60000;
	}

	public SSHManager(String userName, String password, String connectionHost, int connectionPort) {
		doCommonConstructorActions(userName, password, connectionHost);
		intConnectionPort = connectionPort;
		intTimeOut = 60000;
	}

	public SSHManager(String userName, String password, String connectionHost, int connectionPort,
			int timeOutMilliseconds) {
		doCommonConstructorActions(userName, password, connectionHost);
		intConnectionPort = connectionPort;
		intTimeOut = timeOutMilliseconds;
	}

	private String connect() {
		String errorMessage = null;

		try {
			sesConnection = jschSSHChannel.getSession(strUserName, strConnectionHost, intConnectionPort);
			sesConnection.setPassword(strPassword);

			Properties props = new Properties();
			// Noodzakelijk voor acceptatie van elke willekeurige key
			props.setProperty("StrictHostKeyChecking", "no");
			// Kerberos/GSSAPI authentication set as the preferred
			// authentication
			// Gevolg: windows userid wordt gebruikt bij maken van de connectie
			// i.p.v. opgegeven userid
			// Solution: remove the Kerberos/GSSAPI (gssapi-with-mic) from the
			// list of preferred authentication methods
			props.setProperty("PreferredAuthentications", "publickey,keyboard-interactive,password");

			sesConnection.setConfig(props);
			sesConnection.setTimeout(intTimeOut);
			sesConnection.connect();
		} catch (JSchException jschX) {
			// logError(jschX.getMessage());
			errorMessage = jschX.getMessage();
		}
		return errorMessage;
	}

	private String logError(String errorMessage) {
		if (errorMessage != null) {
			LOGGER.log(Level.SEVERE, "{0}:{1} - {2}",
					new Object[] { strConnectionIP, intConnectionPort, errorMessage });
		}

		return errorMessage;
	}

	private String logWarning(String warnMessage) {
		if (warnMessage != null) {
			LOGGER.log(Level.WARNING, "{0}:{1} - {2}",
					new Object[] { strConnectionIP, intConnectionPort, warnMessage });
		}

		return warnMessage;
	}

	private String sendCommand(String command) {
		StringBuilder outputBuffer = new StringBuilder();

		try {
			Channel channel = sesConnection.openChannel("exec");
			((ChannelExec) channel).setCommand(command);
			InputStream commandOutput = channel.getInputStream();
			channel.connect();
			int readByte = commandOutput.read();

			while (readByte != 0xffffffff) {
				outputBuffer.append((char) readByte);
				readByte = commandOutput.read();
			}
			// exitStatus check moet net voor disconnect worden aangeroepen
			if (channel.getExitStatus() == -1) {
				outputBuffer.append("Er is wat fout gegaan (exitStatus = -1)\n");
			}
			channel.disconnect();
		} catch (IOException ioX) {
			// logWarning(ioX.getMessage());
			return ioX.getMessage();
		} catch (JSchException jschX) {
			// logWarning(jschX.getMessage());
			return jschX.getMessage();
		}
		return outputBuffer.toString();
	}

	private void close() {
		sesConnection.disconnect();
	}

	public String executeCommand(String command) {
		String result = null;
		try {
			result = connect();
			if (result == null) {
				result = sendCommand(command);
			}
		} finally {
			close();
		}
		return result;
	}
		
}
