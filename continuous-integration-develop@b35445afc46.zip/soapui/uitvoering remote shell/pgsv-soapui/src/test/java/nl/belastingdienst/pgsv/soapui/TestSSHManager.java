package nl.belastingdienst.pgsv.soapui;

import org.junit.Test;

/**
 * Unittest voor testen SSHManager.
 * 
 * @author corna00
 */
public class TestSSHManager {
	 	 
	 @Test
	  public void testExecuteCommandIPAS()
	  {
		 String command = "ls -al;/home/virtuser/hello_world_script";
		 String userName = "## user ##";
	     String password = "## password ##";
	     String connectionHost = "on01p549.ont.belastingdienst.nl";
	     SSHManager instance = new SSHManager(userName, password, connectionHost);
	     System.out.println(instance.executeCommand(command));
	     // automatically closed 
	  }

	 @Test
	  public void testExecuteCommandAWS()
	  {
	     String userName = "## user ##";
	     String password = "## password ##";
	     String connectionHost = "olandu99.ont.belastingdienst.nl";
	     SSHManager instance = new SSHManager(userName, password, connectionHost);
	     System.out.println(instance.executeCommand("locale charmap"));
	     // automatically closed 
	  }

}
