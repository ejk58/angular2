import groovy.io.FileType

def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrlPrefix = ApplicationConfiguration.getNexusUrlPrefix()
	def quayUrlPrefix = ApplicationConfiguration.getQuayUrlPrefix()
	def jdkImage = ApplicationConfiguration.getJdkImage()

    def sonarUrl = ApplicationConfiguration.getSonarUrl()
    def sonarToken = ApplicationConfiguration.getSonarToken()
    
    def dryRun = false
    def baseDir = '.'
    if (config.baseDirectory != null) {
		baseDir = config.baseDirectory
    }
    def useOnlySettingsfileInProject = false
    if (config.useOnlySettingsfileInProject != null) {
		useOnlySettingsfileInProject = config.useOnlySettingsfileInProject
    }

    def gitUrl = scm.userRemoteConfigs[0].url
    def gitBranch = scm.branches[0].name
    if (gitBranch.startsWith("*/")) {
		gitBranch = gitBranch.substring(2)
    }
    echo "gitUrl: ${gitUrl}; gitBranch: ${gitBranch}"
    def currentBranch = gitBranch
    def isNormalRelease = "NO"
    if (gitBranch ==~ /(develop)/) {
		isNormalRelease = "YES"
    }

	// Deze variabelen zijn project specifiek
    def projectBase = ApplicationConfiguration.getOSprojectBase(config.deploymentId, params.environment)
	def project = ApplicationConfiguration.getOSprojectName(config.deploymentId, params.environment)

	def bitbProject = ApplicationConfiguration.getBitbucketProject(config.deploymentId)
	def	bitbTestRepo = ApplicationConfiguration.getBitbucketTestRepo(config.deploymentId)
	def tmpRepoDir = "/tmp/testrepo"
	def gitServerUrl = ApplicationConfiguration.getGitServerUrl()

    // Deze variabelen alleen als je niet de standaard volgt.
    def backendName = "${projectBase}-backend"
	if(projectBase == "zaakadministratie") {
        backendName = "zaakadministratie"
    }
    def frontendName = "${projectBase}-frontend"
    def openshiftDeployment = params.environment

    // Deze variabelen in principe niet veranderen
    def mvnCmd = 'mvn -B -s openshift/maven-settings.xml'
	def mavenFile="openshift/maven-settings.xml"

	def node_name = "maven35-openjdk11"
    if (config.mvnVersion != null) {
        node_name = config.mvnVersion
    }


    node(node_name) {
		deleteDir()

		try {
			stage ('Clone') {
				// http://javadoc.jenkins.io/plugin/git/hudson/plugins/git/GitSCM.html
				checkout([$class: 'GitSCM', branches: [[name: gitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CloneOption', depth: 1, noTags: false, reference: '', shallow: false ], [$class: 'MessageExclusion', excludedMessage: '.*\\[maven-release-plugin\\].*'], [$class: 'LocalBranch', localBranch: gitBranch]], submoduleCfg: [], userRemoteConfigs: [[url: gitUrl]]])
				//checkout scm

				stash(name: 'ws', includes: '**', excludes: '**/node_modules/**')
				// stash(name: 'ws', useDefaultExcludes: false)

				properties([
					parameters([
						choice(name: 'build_application', choices: 'NO\nYES', description: 'Build application before making a new release?'),
						choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
						choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
						choice(name: 'run_it_test', choices: 'YES\nNO', description: 'Run the integration tests?')
					]),
					disableConcurrentBuilds()
				])
			}
			stage('Release prepare') {
				// node(node_name){
					dir(baseDir) {
						unstash 'ws'
						projectInfo = getInfoFromPom(readFile("pom.xml"))
						releaseVersion = projectInfo.versionWithoutSnapshot()
						echo "**************************************************************\n" +
							"** release parameters:\n" +
							"** deploymentId     = ${config.deploymentId}\n" +
							"** GroupId          = ${projectInfo.groupId}\n" +
							"** ArtifactId       = ${projectInfo.artifactId}\n" +
							"** version          = ${projectInfo.version}\n" +
							"** releaseVersion   = ${releaseVersion}\n" +
							"**  \n" +
							"** Run IT test      = ${params.run_it_test}\n" +
							"** Normal release   = ${isNormalRelease}\n" +
							"** useOnlySettingsfileInProject   = ${useOnlySettingsfileInProject}\n" +
							"**************************************************************"
						if (dryRun) {
							echo "DRYRUN: Running maven release:prepare\n"
						}
						else {
							// node(node_name){
							sh "git config --global user.email 'jenkins@belastingdienst.nl'"
							sh "git config --global user.name 'jenkins'"
							if (isNormalRelease ==~ /(YES)/) {
								sh "mvn -B -V -U -gs ${mavenFile} build-helper:parse-version release:prepare \
									-DdevelopmentVersion=\\\${parsedVersion.majorVersion}.\\\${parsedVersion.nextMinorVersion}.0-SNAPSHOT -DskipTests"
							}
							else {
								sh "mvn -B -V -U -gs ${mavenFile} release:prepare -DskipTests"
							}
							// stash(name: 'ws', useDefaultExcludes: false)
							// }
						}
					}
				// }
			}
			stage('Release perform') {
				// node(node_name){
					dir(baseDir) {
						if (dryRun) {
							echo "DRYRUN: Running maven release:perform\n"
						}
						else {
							// node(node_name){
							// unstash 'ws'
							sh "git config --global user.email 'jenkins@belastingdienst.nl'"
							sh "git config --global user.name 'jenkins'"
							wrap([$class: 'ConfigFileBuildWrapper', managedFiles: [[fileId: ApplicationConfiguration.getJenkinsMavenSettingsId(), variable: 'PROJECT_MAVEN_SETTINGS' ]]]) {
								if (useOnlySettingsfileInProject) {
									echo "Using only settings.xml from the project"
									sh "mvn -B -V -U -gs ${mavenFile}  release:perform -DskipTests"
								} else {
									sh "mvn -B -V -U -gs ${mavenFile}  -s ${env.PROJECT_MAVEN_SETTINGS} release:perform -DskipTests"
									//sh "mvn -B -V -U -gs ${mavenFile}  release:perform -DskipTests"
								}
							}
							// stash(name: 'ws-release-perform', useDefaultExcludes: false)
							// }
						}
					}
				// }
			}
			stage('build image in quay') {
				if (dryRun) {
					echo "DRYRUN: Build image in Quay \n"
				}
				else {
					// node(node_name){
						openshift.withCluster() {
                            openshift.withProject( project ) {
						        bcExists = openshift.selector("bc", "quay").exists()
                            }
						if(bcExists) {
							sh "oc delete bc/quay -n ${project}"
							}
						}
						script {
						openshift.withCluster() {
                            openshift.withProject( project ) {
                                openshift.newBuild("--name=quay"
                                        , "-i=${jdkImage}"
                                        , "--binary=true"
                                        , "--to=${quayUrlPrefix}/${project}:${releaseVersion}"
                                        , "--push-secret=webdevelopment-robot-pull-secret"
                                        , "--to-docker=true"
                                )
                            }
						}
						}
						script {
                        echo "Build Image in Quay"
                        //unstash 'ws-release-perform'
                        openshift.withCluster() {
                            openshift.withProject( project ) {
                                if(projectBase == "zaakadministratie") {
                                    openshift.selector("bc", "quay").startBuild("--from-file=target/${backendName}-${releaseVersion}.jar", "--wait=true")
                                }
                                else {
                                    openshift.selector("bc", "quay").startBuild("--from-file=${backendName}/target/${backendName}-${releaseVersion}.jar", "--wait=true")
                                }
                            }
                        }
                    	}	
					// }
				}
			}
			stage('Git push') {
				if (dryRun) {
					echo "DRYRUN: Pushing git changes to server\n"
				}
				else {
					// node(node_name){
					//unstash 'ws-release-perform'
					sh "git config --global user.email 'jenkins@belastingdienst.nl'"
					sh "git config --global user.name 'jenkins'"
					sh "git status"
					sh "git checkout $currentBranch"
					sh "git pull --rebase origin $currentBranch"
					sh "git status"
					if (isNormalRelease ==~ /(NO)/) {
						echo "We are now on ${gitBranch}, checking out develop branch."
						sh "git push origin ${gitBranch}"
						sh "git checkout develop"
						currentBranch = "develop"
					}

					stdOut = sh script: "pwd", returnStdout: true
					currentDir = new File(stdOut.trim())
					stdOut = sh script: "pwd", returnStdout: true
					currentDir = new File(stdOut.trim())
					stdOut1 = sh script: "hostname", returnStdout:true
					echo "hostname : ${stdOut1}"
					def yourScriptAsaString = libraryResource '../resources/updateVersion.py' 
    				writeFile file: 'updateVersion.py', text: yourScriptAsaString
					sh "python -u updateVersion.py ${releaseVersion}"
					//updateVersionsInDeployReleaseScript(releaseVersion)
					sh "git commit -m \"Added new version to pipeline script.\""
					sh "git status"
					sh "git pull --rebase origin $currentBranch"
					sh "git push --tags origin $currentBranch"
					// Only creating a release branch when building an normal release.
					if (isNormalRelease ==~ /(YES)/) {
						releaseBranch = "release/${releaseVersion}"
						sh "git branch ${releaseBranch} ${projectInfo.artifactId}-${releaseVersion}"
						sh "git checkout ${releaseBranch}"
						dir(baseDir) {
							sh "mvn -B -V -U -gs ${mavenFile} build-helper:parse-version versions:set -DgenerateBackupPoms=false \
								-DnewVersion=\\\${parsedVersion.majorVersion}.\\\${parsedVersion.minorVersion}.\\\${parsedVersion.nextIncrementalVersion}-SNAPSHOT -DskipTests"
							sh "git add --all"
							sh "git commit -m \"Preparing version for hotfixes.\""
							sh "git push origin ${releaseBranch}"
							// Preparing develop for merges from the release branch
							sh "git checkout develop"
							sh "git pull origin develop"
							sh "git merge -s ours ${releaseBranch}"
							sh "git push origin develop"
						}
						// Only creating a release branch for Test repo when building an normal release.
						echo "**************************************************************\n" +
						"**      Create tag in test repo en merge naar master\n" +
						"**  \n" +
						"** release parameters:\n" +
						"** deploymentId     = ${config.deploymentId}\n" +
						"** GroupId          = ${projectInfo.groupId}\n" +
						"** ArtifactId       = ${projectInfo.artifactId}\n" +
						"** version          = ${projectInfo.version}\n" +
						"** releaseVersion   = ${releaseVersion}\n" +
						"**  \n" +
						"** Test Repo        = ${gitServerUrl}/${bitbProject}/${bitbTestRepo}\n" +
						"** Working Dir      = ${tmpRepoDir}\n" +
						"** Normal release   = ${isNormalRelease}\n" +
						"**************************************************************"
						applicatie = projectInfo.artifactId
												
						if (bitbProject != null) {
							
                            echo "pull request test repo afhandelen"
                            // plaats een tag, zodat je de test versie in
                            // sync loppt met de code versie
							sh "rm -r ${tmpRepoDir} || true"
							sh "mkdir -p ${tmpRepoDir}"
							println "git clone ${gitServerUrl}/${bitbProject}/${bitbTestRepo} ${tmpRepoDir}"
							sh "git clone ${gitServerUrl}/${bitbProject}/${bitbTestRepo} ${tmpRepoDir}"
							dir(tmpRepoDir) {
                                gitTag = applicatie + '-' + releaseVersion
                                setTagTestRepo(gitTag)
							}
							sh "rm -r ${tmpRepoDir} || true"
						}
						else {
							println "No creating release branch in test repo configured for ${config.deploymentId}"
						}
					}
					// }
				}
			}
			stage('Deploying') {
				if (dryRun) {
					echo "DRYRUN: Deploying release\n"
				}
				else {
					// node(node_name){
						echo "Deploying new release to ${params.environment}-${params.street}\n"
						build job: config.deployPipeline, parameters: [string(name: 'UpdateParametersOnly', value: "YES"), string(name: 'environment', value: params.environment), string(name: 'street', value: params.street)], propagate: false, wait: true
						build job: config.deployPipeline, parameters: [
							string(name: 'environment', value: params.environment), 
							string(name: 'street', value: params.street),
							string(name: 'run_it_test', value: 'NO')
							], propagate: false, wait: false
						if (params.run_it_test ==~ /(YES)/) {
							build job: config.integrationPipeline, parameters: [
							string(name: 'environment', value: params.environment), 
							string(name: 'street', value: params.street)
							], propagate: false, wait: false
						}
					// }
				}
			}
			currentBuild.result = 'SUCCESS'

		} catch (any) {
			currentBuild.result = 'FAILURE'
			throw any
		} finally {
            deleteDir()
            // node(node_name) {
                echo "delete workspace ${WORKSPACE} on ${node_name} "
                deleteDir()
            // }
			emailNotification()
		}
    }
}

@NonCPS
def updateVersionsInDeployReleaseScript(String versionToAdd) {
	def found = []
	def filenames = []
	currentDir.eachFileMatch(FileType.ANY, ~/deployRelease.*groovy/) {
		found << it
		filenames << it.name
	}
	echo "Number of files to process: ${found.size()}"
	found.each{
		echo "Processing: ${it}"
		File orgFile = new File("${it}")
		File outputFile = new File("${it}.tmp")
		File tempFile = new File("/tmp/${it.name}.old")
		if (tempFile.exists()) {
			tempFile.delete()
		}
		it.withReader { reader ->
			while ((line = reader.readLine())!=null) {
				tempFile << "${line}\n"
				if (line.contains('applicationVersionChoices')) {
					choicesTxt = line.substring(line.indexOf('"') + 1, line.lastIndexOf('"'))
					choices = choicesTxt.split("\\\\n")
					outputFile << line.substring(0, line.indexOf("\"") + 1)
					outputFile << versionToAdd
					for (i = 0; i < Math.min(4, choices.length); i++) {
						outputFile << "\\n${choices[i]}"
					}
					outputFile << "\"\n"
				}
				else {
					outputFile << "${line}\n"
				}
			}
		}
		outputFile.renameTo(orgFile)
	}
	sh "git add ${filenames.join(' ')}"
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
	def gav = new GAV()
	def project = new XmlSlurper().parseText( pomContent )
	gav.groupId = project.groupId.toString()
	gav.artifactId = project.artifactId.toString()
	gav.version = project.version.toString()
	gav
}

class GAV {
	String groupId
	String artifactId
	String version

	def String groupIdPath() {
		groupId.replaceAll("\\.", "/")
	}
	def String versionWithoutSnapshot() {
		if (version.endsWith("-SNAPSHOT")) {
			version.substring(0, version.length() - 9)
		}
		else {
			version
		}
	}
	def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
