def call(body) {

        def config = [:]
        body.resolveStrategy = Closure.DELEGATE_FIRST
        body.delegate = config
        body()
	def lockLabel = 'XXXX'

        node {
            deleteDir()

            try {
                stage ('Clone') {
					
					checkout scm
					
                    properties([
                        parameters([
                            choice(name: 'environment', choices: 'ont\ntst', description: 'Environment to run this script'),
                            choice(name: 'defaultSchemaName', choices: config.dbSchema, description: 'DefaultSchemaName used for liquibase'),
                            choice(name: 'dropDatabase', choices: 'YES\nNO', description: 'Drop the database before updating?'),
                            choice(name: 'buildApps', choices: 'YES\nNO', description: 'Want to trigger pipelines of related applications?'),
                            string(name: 'gitBranchDb', defaultValue: 'develop', description: 'Git branch of the database repository to run Liquibase from')
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTriggers([pollSCM('')])
                    ])
                }

                if (params.environment ==~ /(?i)(ont)/) {
                    dbConnectString = config.dbUrlOnt
                    context = 'ONT'
                }
                if (params.environment ==~ /(?i)(tst)/) {
                    dbConnectString = config.dbUrlTst
                    context = 'TST'
                }

                if (params.defaultSchemaName.length() > 7 && params.defaultSchemaName.substring(0,7) == "IVANOTE") {
                    streetNumber = params.defaultSchemaName[-1..-1].toInteger() + 10    
                } else {
                 if (params.defaultSchemaName.substring(0,5) == "IVAT_") {
                     streetNumber = params.defaultSchemaName[-2..-1].toInteger()
                 } else {
                        streetNumber = params.defaultSchemaName[-2..-1].toInteger() + 10
                   }
                }

                street = 'str' + streetNumber.toString()

                if (params.defaultSchemaName.substring(0,4) == "IVAI") {
                    context = context.toLowerCase() + "-" + street
                }
		lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + street

                stage('Update Database') {
                    lock(lockLabel) {
                        if (dbConnectString.substring(5,13) == "teradata") {
                            if (params.environment ==~ /(?i)(ont|tst)/ && params.dropDatabase ==~ /(YES)/) {
                                liquibaseDropUpdateMasterTD(config.gitUrl, params.gitBranchDb, config.dbUser, dbConnectString + "DATABASE=" + params.defaultSchemaName, params.defaultSchemaName, config.changelogFile, context)
                            }
                            liquibaseUpdateDevelop(config.gitUrl, params.gitBranchDb, config.dbUser, dbConnectString + "DATABASE=" + params.defaultSchemaName, params.defaultSchemaName, config.changelogFile, context)
                        } else {
                            if (params.environment ==~ /(?i)(ont|tst)/ && params.dropDatabase ==~ /(YES)/) {
                                liquibaseDropUpdateMaster(config.gitUrl, params.gitBranchDb, config.dbUser, dbConnectString, params.defaultSchemaName, config.changelogFile, context)
                            }
                            liquibaseUpdateDevelop(config.gitUrl, params.gitBranchDb, config.dbUser, dbConnectString, params.defaultSchemaName, config.changelogFile, context)
                        }
                    }
                }   
		
                stage('Execute Code Pipelines') {
                    if (params.buildApps ==~ /(YES)/ && config.codePipeline.size() > 0) {
                        def stepsForParallel = config.codePipeline.collectEntries {
                            ["${it}": {build job: it, parameters: [string(name: 'environment', value: params.environment), string(name: 'street', value: street)], propagate: false, wait: false }]
                        }
                        parallel stepsForParallel
                    }
                    else {
                        echo "Skipped execution of code pipeline."
                    }

                }       
                currentBuild.result = 'SUCCESS'

            } catch (any) {
                currentBuild.result = 'FAILURE'
                throw any
	        } finally {
		        emailNotification()
	        }
        }
}
