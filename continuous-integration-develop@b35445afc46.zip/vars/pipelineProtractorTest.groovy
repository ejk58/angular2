def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    if (config.projectDir == null) {
        config.projectDir = './ivai-war'
    }
    if (config.protractorConfDir == null) {
        config.protractorConfDir = '.'
    }
    if (config.reportDir == null) {
        config.reportDir = './ivai-war/src/test/e2e/reports'
    }

    
    node {

        try {
            stage ('Clone') {
                
                checkout scm
                
                pipelineTrigger = pipelineTriggers(config.pipelineTrigger)

                properties([
                    parameters([
                        choice(name: 'npmInstall', choices: 'NO\nYES', description: 'Npm install?'),
                        choice(name: 'reRunFailed', choices: 'YES\nNO', description: 'Rerun failed tests?'),
                        string(name: 'projectDir', defaultValue: config.projectDir, description: 'Where is the project located?'),
                        string(name: 'protractorConfDir', defaultValue: config.protractorConfDir, description: 'Where is protractor.conf.js located?'),
                        string(name: 'reportDir', defaultValue: config.reportDir, description: 'Where are the E2E result reports located in the project after testing?')
                    ]),
                    disableConcurrentBuilds(),
                    pipelineTrigger
                ])
            }

            stage ("Protractor"){
                    try{
                        protractor(params.npmInstall, params.reRunFailed, params.projectDir, params.protractorConfDir)
                        currentBuild.result = 'SUCCESS'
                    }catch(e){
                        currentBuild.result = 'FAILURE'
                    }
                }

        } catch (e) {
            currentBuild.result = 'FAILURE'
            throw e
        } finally {
            echo "Protractor report dir: " + params.reportDir
            publishHTML([
                allowMissing: false,
                alwaysLinkToLastBuild: false,
                keepAll: true,
                reportDir: params.reportDir,
                reportFiles: './e2e-tests/report.html',
                reportName: 'Protractor Report',
                reportTitles: ''
            ])

            emailNotification()
        }
    }
}