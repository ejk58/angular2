def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def sonarUrl = ApplicationConfiguration.getSonarUrl()
    def sonarToken = ApplicationConfiguration.getSonarToken()

    // Deze variabelen zijn project specifiek
    def projectBase = ApplicationConfiguration.getOSprojectBase(config.deploymentId, params.environment)
    def project = ApplicationConfiguration.getOSprojectName(config.deploymentId, params.environment)

    // Deze variabelen alleen als je niet de standaard volgt.
    def backendName = "${projectBase}-backend"
    def frontendName = "${projectBase}-frontend"
    if(projectBase == "zaakadministratie") {
        backendName = "zaakadministratie"
        frontendName = ""
    }
    if(params.environment ==~ /(ont)/ && params.street ==~ /(1)/) {
        openshiftDeployment = params.environment
    }
    else {
        openshiftDeployment = params.environment + params.street
    }

    def vervangenOpenjdk11Image = false
    if (config.vervangenOpenjdk11Image != null ) {
        vervangenOpenjdk11Image = config.vervangenOpenjdk11Image
    }
    def vervangenOpenshiftObjects = false
    if (config.vervangenOpenshiftObjects != null ) {
        vervangenOpenshiftObjects = config.vervangenOpenshiftObjects
    }

    def mvnVersion = "maven35-openjdk11"
    if (config.mvnVersion != null) {
        mvnVersion = config.mvnVersion
    }

    def nodeVersion = "nodejs10"
    if (config.nodeVersion != null) {
        nodeVersion = config.nodeVersion
    }

    // Deze variabelen in principe niet veranderen
    def mvnCmd = 'mvn -B -s openshift/maven-settings.xml'

    def dryRun = false

    def tmpSonarDir = "/tmp/testSonar"

    def mvnNodeName = ''

    node {
        skipDefaultCheckout()
        try {
            stage('Checkout') {
            //    node {
            //        label "maven35-openjdk11"
            //    }
                if (dryRun) {
                    echo "DRYRUN: Running scm checkout\n"
                    IMAGE = readMavenPom().getArtifactId()
                    VERSION = readMavenPom().getVersion()
                    GROUPID = readMavenPom().getGroupId()
                    ART = config.artifactId
                    echo "IMAGE: ${IMAGE}"
                    echo "VERSION: ${VERSION}"
                    echo "GROUPID: ${GROUPID}"
                    echo ART
                    properties([
                        parameters([
                        choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
                        choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                        choice(name: 'run_it_test', choices: 'YES\nNO', description: 'Run the integration tests?')
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTriggers([pollSCM('')])
                        ])
                }
                else {
                    properties([
                        parameters([
                        choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
                        choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                        choice(name: 'run_it_test', choices: 'YES\nNO', description: 'Run the integration tests?')
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTriggers([pollSCM('')])
                        ])
                    checkout scm
                    // ITT Jeroen's versie, .git niet excluden omdat die voor de git-commit plugin nodig is
                    stash(name: 'ws', includes: '**', excludes: '**/node_modules/**', useDefaultExcludes: false)
                
                    projectInfo = getInfoFromPom(readFile("pom.xml"))
                    lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
                   }
            }
            if (frontendName?.trim()) {
                stage('NPM') {
                    if (config.artifactId != null) {
                        projectInfo.artifactId = config.artifactId
                    }
                node(nodeVersion) {
                    nodeNodeName = env.NODE_NAME
                    if (dryRun) {
                        echo "DRYRUN: Running npm i; npm run build\n"
                        echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** version          = ${projectInfo.version}\n" +
                        "**  \n" +
                        "** projectBase      = ${projectBase}\n" +
                        "** ocdProject       = ${project}\n" +
                        "** environment      = ${params.environment}\n" +
                        "** street           = ${params.street}\n" +
                        "** lockLabel        = ${lockLabel}\n" +
                        "** vervangenOpenjdk11Image        = ${vervangenOpenjdk11Image}\n" +
                        "** vervangenOpenshiftObjects      = ${vervangenOpenshiftObjects}\n" +
                        "**************************************************************\n"
                    }
                    else {
                        echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** version          = ${projectInfo.version}\n" +
                        "**  \n" +
                        "** projectBase      = ${projectBase}\n" +
                        "** ocdProject       = ${project}\n" +
                        "** environment      = ${params.environment}\n" +
                        "** street           = ${params.street}\n" +
                        "** lockLabel        = ${lockLabel}\n" +
                        "** vervangenOpenjdk11Image        = ${vervangenOpenjdk11Image}\n" +
                        "** vervangenOpenshiftObjects      = ${vervangenOpenshiftObjects}\n" +
                        "**************************************************************\n"
                        unstash 'ws'
                        dir(frontendName) {
                            sh (script: "npm i" ) // Dit moet later nog npm ci worden
                            sh (script: "npm run build" )
                            // Onderstaand is afhankelijk van de "name": "frontend" in package.json
                            stash(name: 'frontend', includes: 'dist/frontend/**')
                        }
                    }
                }
                }
            }
            else {
                echo "Er is geen frontend, dus geen npm nodig"
            }
            stage('Maven package') {
                node(mvnVersion){
                mvnNodeName = env.NODE_NAME
                if (dryRun) {
                    echo "DRYRUN: Running maven package\n"
                }
                else {
                    // als er frontendName gevuld is
                    if (frontendName?.trim()) {
                        unstash 'ws'
                        dir(frontendName) {
                            unstash 'frontend'
                        }
                    }
                    else {
                        unstash 'ws'
                    }
                    if(projectBase == "zaakadministratie") {
                        sh(script: "${mvnCmd} package -Ps2i" )
                    }
                    else {
                        sh(script: "${mvnCmd}  -pl ${backendName} package -Ps2i" )
                    }
                    stash name: 'jar', includes: '**/target/**/*'
                }

    //            Deze applicatie heeft (nog) geen unittests
    //            post {
    //                success {
    //                    junit '**/surefire-reports/**/*.xml'
    //                }
    //            }
            }
            }
            stage('Sonar en OWASP dependency analysis') {
                node(mvnNodeName) {
                    echo "temp dir maken, repo clonen en mvn sonar:sonar uitvoeren"
                    sh "rm -r ${tmpSonarDir} || true"
                    sh "mkdir -p ${tmpSonarDir}"
                    dir(tmpSonarDir) {
                        checkout scm
                        echo "OWASP dependency check"
                        //analyzeDependencies() // werkt niet in een ocd jenkins agent
                        try {
                            sh "${mvnCmd} -f pom.xml org.owasp:dependency-check-maven:aggregate \
                                -DcveUrlBase=https://nvd.belastingdienst.nl/nvd/nvdcve-1.1-%d.json.gz \
                                -DcveUrlModified=https://nvd.belastingdienst.nl/nvd/nvdcve-1.1-modified.json.gz \
                                -DretireJsAnalyzerEnabled=false \
                                -DossindexAnalyzerEnabled=false \
                                -Dformats=HTML,JSON \
                                -DfailBuildOnAnyVulnerability=false "
                        } catch (any) {
                            echo "Er gaat iets fout, maar het report wordt wel aangemaakt"
                        } finally {
                            publishHTML(target: [
                                    allowMissing         : true,
                                    alwaysLinkToLastBuild: true,
                                    keepAll              : true,
                                    reportDir            : 'target',
                                    reportFiles          : 'dependency-check-report.html',
                                    reportName           : 'OWASP dependency analysis'
                            ])
                        }
                        echo "Sonar"
                        sh "${mvnCmd} clean verify sonar:sonar -P sonarqube -Dsonar.host.url=${sonarUrl} -Dsonar.login=${sonarToken} "
                    }
                }
            }
            stage('Create Image Builder') {
                echo "Create Image Builder"
                if (dryRun) {
                    echo "DRYRUN: Running openshift.newbuild\n"
                }
                else {
                    openshift.withCluster() {
                        openshift.withProject( project ) {
                          bcExists = openshift.selector("bc", "${openshiftDeployment}").exists()
                        }
                        if(!bcExists) {
                            openshift.withCluster() {
                               openshift.withProject( project ) {
                                  openshift.newBuild("--name=${openshiftDeployment}", "-i=openjdk-11-rhel7", "--binary=true")
                               }
                            }
                        } else {
                            echo "Stage Create Image Builder niet uitgevoerd, want buildconfig ${openshiftDeployment} bestaat al."
                        }
                    }
                }
            }
            stage('Build Image') {
                        echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** version          = ${projectInfo.version}\n" +
                        "**  \n" +
                        "** projectBase      = ${projectBase}\n" +
                        "** ocdProject       = ${project}\n" +
                        "** environment      = ${params.environment}\n" +
                        "** street           = ${params.street}\n" +
                        "** lockLabel        = ${lockLabel}\n" +
                        "** vervangenOpenjdk11Image        = ${vervangenOpenjdk11Image}\n" +
                        "** vervangenOpenshiftObjects      = ${vervangenOpenshiftObjects}\n" +
                        "**************************************************************\n"
                
                node(mvnNodeName) {
                if (dryRun) {
                    echo "DRYRUN: Running openshift.startbuild\n"
                }
                else {
                    if (vervangenOpenjdk11Image) {
                        sh (script: "oc delete is/openjdk-11-rhel7 -n ${project}" )
                        sh (script: "oc import-image registry.chp.belastingdienst.nl/redhatio/openjdk-11-rhel7:latest --confirm -n ${project}" )
                        echo "openJdk 11 image is vervangen\n"
                    }
                    script {
                        echo "Build Image"
                        unstash 'jar'
                        openshift.withCluster() {
                            openshift.withProject( project ) {
                            if(projectBase == "zaakadministratie") {
                                openshift.selector("bc", openshiftDeployment).startBuild("--from-file=target/${backendName}.jar", "--wait=true")
                            }
                            else {
                                openshift.selector("bc", openshiftDeployment).startBuild("--from-file=${backendName}/target/${backendName}.jar", "--wait=true")
                            }
                            }
                        }
                        sh "oc tag ${openshiftDeployment}:latest ${openshiftDeployment}:${projectInfo.version} -n ${project}"
                    }
                }
            }
            }
            stage('Create deployment in O') {
             echo "Create deployment in ${openshiftDeployment}"
                if (dryRun) {
                    echo "DRYRUN: Running openshift create environment if not exists\n"
                }
                else {
                    script {
                        openshift.withCluster() {
                            openshift.withProject( project ) {
                                if (!openshift.selector('dc', openshiftDeployment).exists() || vervangenOpenshiftObjects) {
                                    echo "Create deployment in ${openshiftDeployment}"
                                    // ruim eerst de objecten als die zijn blijven staan
                                    if (openshift.selector('dc', openshiftDeployment).exists()) {
                                        openshift.selector('dc', openshiftDeployment).delete()
                                    }
                                    if (openshift.selector('svc', openshiftDeployment).exists()) {
                                        openshift.selector('svc', openshiftDeployment).delete()
                                    }
                                    if (openshift.selector('route', openshiftDeployment).exists()) {
                                        openshift.selector('route', openshiftDeployment).delete()
                                    }

                                    result = openshift.raw("apply", "-f openshift/${openshiftDeployment}-template.yaml")
                                    // dit template moet een deployment hebben van het image met tag 'latest'
                                    // er zit geen trigger in om te deployen bij image change

                                    // stel dat het trigger er toch is, deze op manual zetten, Jenkins is in control
                                    openshift.set("triggers", "dc/${openshiftDeployment}", "--manual")
                                } else {
                                    echo "Stage Create deployment in O niet uitgevoerd, DC bestaat al"
                                }
                            }
                        }
                    }
                }
            }
            stage('Deploy in O') { 
                echo "Deploy in ${openshiftDeployment}"
                if (dryRun) {
                    echo "DRYRUN: Running openshift deploy or rollout\n"
                }
                else {
                    script {
                        openshift.withCluster() {
                            openshift.withProject( project ) {
    //                        openshift.tag("ont:latest", "ont:${gitVersion}")
                            def dc = openshift.selector("dc", openshiftDeployment)
                            dc.rollout().latest()
                            // wachten tot alle replicas beschikbaar zijn.
                            try {
                                  sh  "oc rollout status dc/${openshiftDeployment} -n ${project} --watch"
                                } catch(any) {
                                  echo "rollout is fout gegaan"
                                  throw any
                                }
                            }
                        }
                    }
                }
                if (params.run_it_test ==~ /(YES)/ && config.integrationPipeline != "") {
                    if (dryRun) {
                        echo "DRYRUN: Not running integration tests\n"
                    }
                    else {
                        echo "Running integration tests\n"
                        build job: config.integrationPipeline, parameters: [string(name: 'environment', value: params.environment), string(name: 'street', value: params.street)], propagate: false, wait: false
                    }
                } else {
                    echo "'run_it_test' set to false >> Robot tests skipped."
                }
            }
            currentBuild.result = 'SUCCESS'

        } catch (any) {
            currentBuild.result = 'FAILURE'
            throw any
        } finally {
            deleteDir()
            if (mvnNodeName?.trim()) {
                node(mvnNodeName) {
                    echo "delete workspace ${WORKSPACE} on ${mvnNodeName} "
                    deleteDir()
                }
            }
            if (frontendName?.trim()) {
            node(nodeNodeName) {
                echo "delete workspace ${WORKSPACE} on ${nodeNodeName} "
                deleteDir()
            }
            }
            emailNotification()
        }
    }
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
        def gav = new GAV()
        def project = new XmlSlurper().parseText( pomContent )
        gav.groupId = project.groupId.toString()
        gav.artifactId = project.artifactId.toString()
        gav.version = project.version.toString()
        gav
}

class GAV {
        String groupId
        String artifactId
        String version

        def String groupIdPath() {
                groupId.replaceAll("\\.", "/")
        }
        def String versionWithoutSnapshot() {
                if (version.endsWith("-SNAPSHOT")) {
                        version.substring(0, version.length() - 9)
                }
                else {
                        version
                }
        }
        def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
