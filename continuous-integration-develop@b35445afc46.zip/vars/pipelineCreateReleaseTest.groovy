def call(body) {

    def config = [:]
    def approver = ""

    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrl = ApplicationConfiguration.getNexusUrl()
    def dinqUrl = ApplicationConfiguration.getDinqUrl()
    def dinq_credential_id = ApplicationConfiguration.getDinqCredentials()
    def annaUrl = ApplicationConfiguration.getAnnaUrl()
    def anna_credential_id = ApplicationConfiguration.getAnnaCredentials()

    def mvnDinqPlugin = ApplicationConfiguration.getMavenDinqPlugin()
    def gitServerUrl = ApplicationConfiguration.getGitServerUrl()

    def clusterSyncDelaySeconds = 5

    def stageDeployMavenArgs = ''

    def dryRun = false
    def baseDir = '.'
    def lockLabel = 'XXXX'
    
    if (config.baseDirectory != null) {
        baseDir = config.baseDirectory
    }

    def channel=ApplicationConfiguration.getMMChannel(config.deploymentId, params.environment)

    // Start deep copy van params omdat params unmodifyable is
    def paramsCopy = [UpdateParametersOnly: params.UpdateParametersOnly
                    , environment: params.environment
                    , street: params.street
                    , run_it_test: params.run_it_test
                    , package: params.package
                    , application_version: params.application_version
                    , version: params.version
                    ]

    // End deep copy van params omdat params unmodifyable is

    node {
    deleteDir()

    try {
        
        stage('Create release branch in test repo') {
            //projectInfo = getInfoFromPom(readFile("pom.xml"))
            //applicatie = projectInfo.artifactId
            applicatie = "zaakadministratie"
            versieNummer = "0.20.0"
            bitbProject = ApplicationConfiguration.getBitbucketProject(config.deploymentId)
            bitbTestRepo = ApplicationConfiguration.getBitbucketTestRepo(config.deploymentId)
            if (bitbProject != null) {
                tmpRepoDir = "/tmp/testrepo"
                sh "rm -r ${tmpRepoDir} || true"
                sh "mkdir -p ${tmpRepoDir}"
                println "git clone ${gitServerUrl}/${bitbProject}/${bitbTestRepo} ${tmpRepoDir}"
                sh "git clone ${gitServerUrl}/${bitbProject}/${bitbTestRepo} ${tmpRepoDir}"
                dir(tmpRepoDir) {
                    sh "git branch release/${versieNummer}"
                    sh "git checkout release/${versieNummer}"
                    sh "git branch --set-upstream-to=origin/develop release/${versieNummer}"
                    sh "git push origin release/${versieNummer}"
                    sh "git tag ${applicatie}-${versieNummer}"
                    sh "git push origin ${applicatie}-${versieNummer}"
                    sh "git branch -r"
                }
                sh "rm -r ${tmpRepoDir} || true"
            }
            else {
                println "No creating release branch in test repo configured for ${config.deploymentId}"
            }
        }
        currentBuild.result = 'SUCCESS'
	
    } catch (any) {
        currentBuild.result = 'FAILURE'
        throw any
    } finally {
        emailNotification()
    }
    }
}
@NonCPS
def GAV getInfoFromPom(String pomContent) {
    def gav = new GAV()
    def project = new XmlSlurper().parseText( pomContent )
    gav.groupId = project.groupId.toString()
    gav.artifactId = project.artifactId.toString()
    gav.version = project.version.toString()
    gav
}

class GAV {
    String groupId
    String artifactId
    String version

    def String groupIdPath() {
        groupId.replaceAll("\\.", "/")
    }
    def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}

