import groovy.io.FileType

def call(String versionToAdd, File currentDir) {
	println "nieuwe versie toevoegen aan ${currentDir}"
	stdOut2 = Jenkins.getInstance().getComputer(env['NODE_NAME']).getHostName()
	echo "hostname in de functie : ${stdOut2}"
	def found = []
	def filenames = []
	currentDir.eachFileMatch(FileType.ANY, ~/deployRelease.*groovy/) {
		found << it
		filenames << it.name
	}
	echo "Number of files to process: ${found.size()}"
	found.each{
		echo "Processing: ${it}"
		File orgFile = new File("${it}")
		File outputFile = new File("${it}.tmp")
		File tempFile = new File("/tmp/${it.name}.old")
		if (tempFile.exists()) {
			tempFile.delete()
		}
		it.withReader { reader ->
			while ((line = reader.readLine())!=null) {
				tempFile << "${line}\n"
				if (line.contains('applicationVersionChoices')) {
					choicesTxt = line.substring(line.indexOf('"') + 1, line.lastIndexOf('"'))
					choices = choicesTxt.split("\\\\n")
					outputFile << line.substring(0, line.indexOf("\"") + 1)
					outputFile << versionToAdd
					for (i = 0; i < Math.min(4, choices.length); i++) {
						outputFile << "\\n${choices[i]}"
					}
					outputFile << "\"\n"
				}
				else {
					outputFile << "${line}\n"
				}
			}
		}
		outputFile.renameTo(orgFile)
	}
	sh "git add ${filenames.join(' ')}"
}
