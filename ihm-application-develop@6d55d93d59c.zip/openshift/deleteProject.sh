#!/bin/bash
oc delete project wd-ihm
sleep 10
