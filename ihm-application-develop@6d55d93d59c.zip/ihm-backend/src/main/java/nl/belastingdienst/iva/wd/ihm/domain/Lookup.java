package nl.belastingdienst.iva.wd.ihm.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Lookup {

    private String code;
    private String omschrijving;

}

