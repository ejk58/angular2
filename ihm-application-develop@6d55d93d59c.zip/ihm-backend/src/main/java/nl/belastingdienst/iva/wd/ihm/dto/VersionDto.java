package nl.belastingdienst.iva.wd.ihm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@ApiModel(value = "Version", description = "Versie van deIHM- applicatie.")
public class VersionDto {

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Versienummer.", required = false, position = 1)
    private String version;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Datum van de commit in de Bitbucket-repository.", required = false, position = 2)
    private String commitDate;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Id van de commit in de Bitbucket-repository.", required = false, position = 3)
    private String commitId;
}
