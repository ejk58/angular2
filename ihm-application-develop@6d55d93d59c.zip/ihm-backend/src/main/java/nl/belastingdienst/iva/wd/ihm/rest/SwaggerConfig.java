package nl.belastingdienst.iva.wd.ihm.rest;

import com.fasterxml.classmate.TypeResolver;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.exceptions.ApiError;
import nl.belastingdienst.iva.common.springboot.exceptions.ApiValidationError;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Configuration
@EnableSwagger2
@Log4j2
public class SwaggerConfig {

    private static final Set<String> DEFAULT_PRODUCES_AND_CONSUMES = new HashSet<>(Arrays.asList("application/json"));

    @Bean
    public Docket productApi() {
        return new Docket(DocumentationType.SWAGGER_2)
		        .apiInfo(apiInfo())
                .produces(DEFAULT_PRODUCES_AND_CONSUMES)
                .consumes(DEFAULT_PRODUCES_AND_CONSUMES)
                .select()
                .apis(RequestHandlerSelectors.any())
				.paths(PathSelectors.any())
                .build();
    }

//                .apis(RequestHandlerSelectors.basePackage("nl.belastingdienst.iva.wd.ihm.controller"))
//    @Bean
//    public Docket productApi(TypeResolver typeResolver) {
//        final List<ResponseMessage> globalResponses = Arrays.asList(new ResponseMessageBuilder().code(400)
//                .message("User error")
//                .responseModel(
//                    new ModelRef("ApiError"))
//                .build(),
//            new ResponseMessageBuilder().code(500)
//                .message("Server Error")
//                .responseModel(new ModelRef("ApiError"))
//                .build(), new ResponseMessageBuilder().code(401)
//                .message("Not Authenticated!")
//                .build(), new ResponseMessageBuilder().code(403)
//                .message(
//                    "Not Authorized!")
//                .build());
//        return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo())
//            .produces(DEFAULT_PRODUCES_AND_CONSUMES)
//            .consumes(DEFAULT_PRODUCES_AND_CONSUMES)
//            .useDefaultResponseMessages(false)
//            .globalResponseMessage(RequestMethod.GET, globalResponses)
//            .globalResponseMessage(RequestMethod.POST, globalResponses)
//            .globalResponseMessage(RequestMethod.DELETE, globalResponses)
//            .globalResponseMessage(RequestMethod.PUT, globalResponses)
//            .additionalModels(typeResolver.resolve(ApiError.class),
//                typeResolver.resolve(ApiValidationError.class))
//            .select()
//            .apis(requestHandler -> !Arrays.asList("operation-handler",
//                "basic-error-controller", "web-mvc-links-handler")
//                .contains(requestHandler.groupName()))
//            .paths(PathSelectors.any())
//            .build();
//    }

    private ApiInfo apiInfo() {
        Contact c = new Contact("CoE Webdevelopment", "https://devtools.belastingdienst.nl/confluence/display/CM/CoE+Webdevelopment+Home", "");
        return new ApiInfoBuilder().title("Inhuur Management")
            .contact(c)
            .description("Services voor IHM")
            .version("1")
            .build();
    }

//    @Bean
//    UiConfiguration uiConfig() {
//        return UiConfigurationBuilder.builder()
//            .deepLinking(true)
//            .displayOperationId(false)
//            .defaultModelsExpandDepth(1)
//            .defaultModelExpandDepth(1)
//            .defaultModelRendering(ModelRendering.EXAMPLE)
//            .displayRequestDuration(true)
//            .docExpansion(DocExpansion.LIST)
//            .filter(false)
//            .maxDisplayedTags(null)
//            .operationsSorter(OperationsSorter.METHOD)
//            .showExtensions(false)
//            .tagsSorter(TagsSorter.ALPHA)
//            .supportedSubmitMethods(UiConfiguration.Constants.DEFAULT_SUBMIT_METHODS)
//            .validatorUrl(null)
//            .build();
//    }
//
}
