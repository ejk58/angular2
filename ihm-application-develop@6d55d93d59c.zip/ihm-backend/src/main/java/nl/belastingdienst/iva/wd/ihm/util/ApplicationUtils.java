package nl.belastingdienst.iva.wd.ihm.util;

import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.security.LdapPersonAttributesMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ApplicationUtils {

    private static final String SOURCE_DB = "datasource_db2";

    @Autowired
    private Environment env;

    @Autowired
    private LdapTemplate ldapTemplate;

    @Autowired
    private ApplicationContext context;

    @Value("${ihm.groups}")
    private List<String> ihmGroups;

    public String getUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth.getPrincipal().toString();
    }

    public NamedParameterJdbcTemplate getTemplate(String environment) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        String datasource = env.getProperty(environment);

        dataSource.setDriverClassName(env.getProperty(datasource + ".driverClassName"));
        dataSource.setUrl(env.getProperty(datasource + ".jdbc-url"));
        dataSource.setUsername(env.getProperty(datasource + ".username"));
        dataSource.setPassword(env.getProperty(datasource + ".password"));

        return new NamedParameterJdbcTemplate(dataSource);
    }

    public Connection getConnectionForEnvironment(String environment) throws SQLException {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        String datasource = env.getProperty(environment);

        dataSource.setDriverClassName(env.getProperty(datasource + ".driverClassName"));
        dataSource.setUrl(env.getProperty(datasource + ".jdbc-url"));
        dataSource.setUsername(env.getProperty(datasource + ".username"));
        dataSource.setPassword(env.getProperty(datasource + ".password"));

        return dataSource.getConnection();
    }

    public String getDatabaseSchema(String key) {
        return env.getProperty(key);
    }

    public Connection getSourceDBConnection() throws SQLException {
        DataSource ds = (DataSource) this.context.getBean(SOURCE_DB);
        return ds.getConnection();
    }

    private List<LdapPerson> getPerson(String userid) {
        LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(1)
            .base(env.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
            .is(userid.trim());
        return ldapTemplate.search(query, new LdapPersonAttributesMapper(null));
    }
}
