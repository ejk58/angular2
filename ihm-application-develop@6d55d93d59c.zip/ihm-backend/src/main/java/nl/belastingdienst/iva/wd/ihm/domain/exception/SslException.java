package nl.belastingdienst.iva.wd.ihm.domain.exception;

public class SslException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public SslException(String message) {
        super(message);
    }
}
