package nl.belastingdienst.iva.wd.ihm.controller;

import nl.belastingdienst.iva.wd.ihm.domain.AllLookupsDTO;
import nl.belastingdienst.iva.wd.ihm.domain.Lookup;
import nl.belastingdienst.iva.wd.ihm.service.LookupService;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lookup")
public class LookupController extends IhmController {

    private final LookupService lookupService;

    public LookupController(LookupService lookupService, Environment env) {
        super(env);
        this.lookupService = lookupService;
    }

    @GetMapping
    @CrossOrigin
    public List<Lookup> lookupTabel(@RequestParam LookupService.LookupType tabel) {
        return lookupService.getList(tabel);
    }

    @GetMapping("/all")
    @CrossOrigin
    public AllLookupsDTO lookupTabellen() {
        AllLookupsDTO allLookupsDTO = new AllLookupsDTO();
        allLookupsDTO.setSoortAanvraag(lookupService.getList(LookupService.LookupType.SOORTAANVRAAG));
        allLookupsDTO.setSoortMiniCompetitie(lookupService.getList(LookupService.LookupType.SOORTMINICOMPETITIE));
        return allLookupsDTO;
    }

}
