package nl.belastingdienst.iva.wd.ihm.domain;

public enum SoortMiniCompetitie {

    DETACHERING("Detachering"),
    OVEREENKOMST_VAN_OPDRACHT("Overeenkomst van opdracht");

    private final String description;

    SoortMiniCompetitie(String description) {
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

}
