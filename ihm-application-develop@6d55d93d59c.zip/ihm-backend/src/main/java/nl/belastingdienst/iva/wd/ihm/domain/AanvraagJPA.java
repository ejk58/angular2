package nl.belastingdienst.iva.wd.ihm.domain;

import java.util.Date;
import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "AANVRAAG")
public class AanvraagJPA {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "INDIENINGSDATUM")
	private Date indieningsDatum;

	@Column(name = "VORIGREFERENTIENR")
	private String vorigReferentieNr;

	@Column(name = "SOORTMINICOMPETITIE")
	private String soortMiniCompetitie;

	@Column(name = "SOORTAANVRAAG")
	private String soortAanvraag;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "SOORTTOELICHTING_ID")
	private ToelichtingJPA soortToelichting;

	@Column(name = "MAXIMUMUURTARIEF")
	private String maximumUurtarief;

	@Column(name = "SPOED")
	private Boolean spoed;

//			<!-- kostenplaats / eenheid / formatieplaats? -->

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "AANVRAGER_ID")
	private AanvragerJPA aanvrager;

//			<!-- opdracht -->
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "OPDRACHT_BESCHRIJVING_ID")
	private ToelichtingJPA opdrachtBeschrijving;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "OPDRACHT_ACHTERGROND_ID")
	private ToelichtingJPA opdrachtAchtergrond;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "OPDRACHT_CONTEXTCULTUUR_ID")
	private ToelichtingJPA opdrachtContextCultuur;

//			<!-- planning? -->
//    @Column(name = "PLANNING_OFFERTEDATUM")
//    @Column(name = "PLANNING_EINDDATUMVRAGEN")
//    @Column(name = "PLANNING_EINDDATUMANTWOORDEN")
//    @Column(name = "PLANNING_EINDDATUMOFFERTES")
//    @Column(name = "PLANNING_DATUMSINTERVIEWS")
//    @Column(name = "PLANNING_INTERVIEWERS")
//    @Column(name = "PLANNING_STREEFDATUMGUNNING")

//			<!-- kwaliteitenprofiel -->
//	@Column(name = "KWALITEITENPROFIEL_ID")

//	@Column(name = "FUNCTIEFAMILIE_ID")

	@Column(name = "FUNCTIESCHAAL")
	private Integer functieschaal;

	@Column(name = "FUNCTIENAAM")
	private String functienaam;

//			<!-- eisen -->

//			<!-- wensen -->
//	@Column(name = "WENS_COMPETENTIES_ID")
//	@Column(name = "WENS_AANVULLENDEKENNIS_ID")
//	@Column(name = "WENS_OVERIGEFUNCTIEWENSEN_ID")

//			<!-- gunning -->
	@Column(name = "GUNNING_TARIEF")
	private Integer gunningTarief;

	@Column(name = "GUNNING_DUURZAAMHEIDSOCIALRETURN")
	private Integer gunningDuurzaamheidSocialReturn;

	@Column(name = "GUNNING_RELEVANTEWERKERVARING")
	private Integer gunningRelevanteWerkervaring;

	@Column(name = "GUNNING_KENNISVAARDIGHEDENKANDIDAAT")
	private Integer gunningKennisVaardighedenKandidaat;

	@Column(name = "GUNNING_BESCHIKBAARHEIDKANDIDAAT")
	private Integer gunningBeschikbaarheidKandidaat;

	@Column(name = "GUNNING_KANDIDAATBEGRIJPTOPDRACHT")
	private Integer gunningKandidaatBegrijptOpdracht;

	@Column(name = "GUNNING_KANDIDAATPASTBIJORGANISATIE")
	private Integer gunningKandidaatPastBijOrganisatie;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "GUNNING_TOELICHTINGDUURZAAMHEIDSOCIALRETURN_ID")
	private ToelichtingJPA gunningToelichtingDuuraamheidSocialReturn;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "GUNNING_TOELICHTINGBESCHIKBAARHEID_ID")
	private ToelichtingJPA gunningToelichtingBeschikbaarheid;

	@Column(name = "INZET_STARTDATUM")
	private Date inzetStartdatum;

	@Column(name = "INZET_INITIELEEINDDATUM")
	private Date inzetInitieleEinddatum;

	@Column(name = "INZET_AANTALMAANDEN")
	private Integer inzetAantalMaanden;

	@Column(name = "INZET_OPTIEVERLENGING")
	private Boolean inzetOptieVerlenging;

	@Column(name = "INZET_PROJECTEINDDATUM")
	private Date inzetProjectEinddatum;

	@Column(name = "INZET_MAXIMAALAANTALVERLENGINGEN")
	private Integer inzetMaximaalAantalVerlengingen;

	@Column(name = "INZET_TERMIJNVERLENGINGINMAANDEN")
	private Integer inzetTermijnVerlengingInMaanden;

	@Column(name = "INZET_URENPERWEEK")
	private Integer inzetUrenPerWeek;

	@Column(name = "INZET_MAXURENINITIELETERMIJN")
	private Integer inzetMaxUrenInitieleTermijn;

	@Column(name = "INZET_VERGOEDINGDIENSTREIZENINBEGREPEN")
	private Boolean inzetVergoedingDienstreizenInbegrepen;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "INZET_VERGOEDINGDIENSTREIZENTOELICHTING_ID")
	private ToelichtingJPA inzetVergoedingDienstreizenToelichting;

	@Column(name = "INZET_HOOFDSTANDPLAATS")
	private String inzetHoofdstandplaats;

	@Column(name = "INZET_ALTERNATIEVESTANDPLAATS")
	private String inzetAlternatieveStandplaats;

	@Column(name = "INZET_EXTRASTANDPLAATSEN")
	private String inzetExtraStandplaatsen;

	@Column(name = "INZET_VEILIGHEIDSONDERZOEKVEREIST")
	private Boolean inzetVeiligheidsonderzoekVereist;

	@Column(name = "INZET_VOGBIJSTARTINZET")
	private Boolean inzetVogBijStartInzet;

	@Column(name = "INZET_VRIJEVERVANGINGBESPREEKBAAR")
	private Boolean inzetVrijeVervangingBespreekbaar;

	@Column(name = "INZET_PARTTIMERSTOEGESTAAN")
	private Boolean inzetParttimersToegestaan;

	@Column(name = "INZET_OFFSITEWERKENBESPREEKBAAR")
	private Boolean inzetOffsiteWerkenBespreekbaar;

	@Column(name = "INZET_CONSIGNATIEDIENSTEN")
	private Boolean inzetConsignatiediensten;

	@Column(name = "INZET_BETROKKENHEIDAANBESTEDINGEN")
	private Boolean inzetBetrokkenheidAanbestedingen;

	@Column(name = "INZET_MAXAANTALCVS")
	private Integer inzetMaxAantalCvs;
}
