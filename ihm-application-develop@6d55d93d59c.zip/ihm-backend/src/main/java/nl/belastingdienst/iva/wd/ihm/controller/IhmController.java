package nl.belastingdienst.iva.wd.ihm.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.env.Environment;

@RequiredArgsConstructor
@Log4j2
public abstract class IhmController {
    protected final Environment env;

}
