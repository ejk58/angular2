package nl.belastingdienst.iva.wd.ihm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import nl.belastingdienst.iva.wd.ihm.domain.AanvragerJPA;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class AanvragerDTO {

	@JsonProperty(required = false)
	private Integer id;

	@JsonProperty(required = false)
	@ApiModelProperty(notes = "Userid van de aanvrager.", example = "", required = false, position = 1)
	private String userid;

	@JsonProperty(required = false)
	@ApiModelProperty(notes = "Departement van de aanvrager.", example = "", required = false, position = 2)
	private String departement;

	@JsonProperty(required = false)
	@ApiModelProperty(notes = "Dienst van de aanvrager.", example = "", required = false, position = 3)
	private String dienst;

	@JsonProperty(required = false)
	@ApiModelProperty(notes = "Afdeling van de aanvrager.", example = "", required = false, position = 4)
	private String afdeling;

	@JsonProperty(required = false)
	@ApiModelProperty(notes = "Inhurend manager.", example = "", required = false, position = 5)
	private String inhurendManager;
}
