package nl.belastingdienst.iva.wd.ihm.domain;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "AANVRAGER")
public class AanvragerJPA {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "USERID")
	private String userid;

	@Column(name = "DEPARTEMENT")
	private String departement;

	@Column(name = "DIENST")
	private String dienst;

	@Column(name = "AFDELING")
	private String afdeling;

	@Column(name = "INHURENDMANAGER")
	private String inhurendManager;
}
