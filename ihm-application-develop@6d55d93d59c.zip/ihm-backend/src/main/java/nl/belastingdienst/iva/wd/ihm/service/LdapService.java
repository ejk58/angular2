package nl.belastingdienst.iva.wd.ihm.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.common.springboot.security.LdapGroup;
import nl.belastingdienst.iva.common.springboot.security.LdapGroupAttributesMapper;
import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.security.LdapPersonAttributesMapper;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class LdapService {

    private final Environment environment;
    private final LdapTemplate ldapTemplate;

    public List<LdapPerson> getPersons(String userid) {
        LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
            .base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
            .like(userid.trim() + "*");
        return ldapTemplate.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));
    }

    public LdapPerson getPerson(String userid) {
        LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
            .base(this.environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
            .is(userid.trim());
        List<LdapPerson> ldapPersonList = this.ldapTemplate
            .search(query, new LdapPersonAttributesMapper(this.environment.getProperty("ldap.emailKey")));
        if (ldapPersonList == null || ldapPersonList.size() != 1) {
            throw new NotFoundException("Ophalen van persoon uit ldap", "userid", userid, String.format("Userid %s bestaat niet", userid));
        }
        return ldapPersonList.get(0);
    }

    public boolean isAdGroep(String werkgroep) {
        LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE)
            .base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("group").and("cn").is(werkgroep);
        List<LdapGroup> adGroepen = ldapTemplate.search(query, new LdapGroupAttributesMapper());
        return adGroepen.size() == 1;
    }
}
