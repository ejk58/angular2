package nl.belastingdienst.iva.wd.ihm;

import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.wd.ihm.security.JwtUtils;
import nl.belastingdienst.iva.wd.ihm.util.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.util.TimeZone;

@Log4j2
@SpringBootApplication
@EnableScheduling
public class Application {

    @Autowired
    private Environment env;

    @Autowired
    private ClientHttpRequestFactory clientHttpRequestFactory;

    @Bean
    public LdapContextSource contextSource() {
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(env.getRequiredProperty("ldap.url"));
        contextSource.setUserDn(env.getRequiredProperty("ldap.user"));
        contextSource.setPassword(env.getRequiredProperty("ldap.password"));
        return contextSource;
    }

    @Bean
    public LdapTemplate ldapTemplate() {
        return new LdapTemplate(contextSource());
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate(clientHttpRequestFactory);
    }

    @Bean(name = "datasource_db2")
    @ConfigurationProperties("spring.datasource")
    @Primary
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    NamedParameterJdbcTemplate namedJdbcTemplateIhm() {
        return new NamedParameterJdbcTemplate(dataSource());
    }

    @Bean
    public ApplicationUtils applicationUtils() {
        return new ApplicationUtils();
    }

    @Bean
    public JwtUtils jwtUtils() {
        return new JwtUtils(env);
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @PostConstruct
    public void init() {
        TimeZone.setDefault(TimeZone.getTimeZone("Europe/Amsterdam"));
        log.info("LocalDateTime in {}: {}", TimeZone.getDefault().getDisplayName(), LocalDateTime.now());
    }
}
