package nl.belastingdienst.iva.wd.ihm.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AllLookupsDTO {
    @JsonProperty(required = true)
    private List<Lookup> soortAanvraag;
    @JsonProperty(required = true)
    private List<Lookup> soortMiniCompetitie;
}
