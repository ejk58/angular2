package nl.belastingdienst.iva.wd.ihm.exception;

import nl.belastingdienst.iva.wd.ihm.domain.exception.JWTInvalidException;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected String handle(Exception ex) {
        logger.error(ex);
        return ResponseMessages.SERVER_ERROR;
    }

    @ExceptionHandler({AccessDeniedException.class})
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    protected String handleAccessDenied(RuntimeException ex) {
        logger.error(ex);
        return ResponseMessages.UNAUTHORIZED + " " + handleMessage(ex.getMessage());
    }

    @ExceptionHandler(JWTInvalidException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public String handleJWTInvalid(JWTInvalidException ex) {
        logger.error(ex);
        return ResponseMessages.JWT_INVALID;
    }

    private String handleMessage(String message) {
        return message != null ? message : "";
    }
}
