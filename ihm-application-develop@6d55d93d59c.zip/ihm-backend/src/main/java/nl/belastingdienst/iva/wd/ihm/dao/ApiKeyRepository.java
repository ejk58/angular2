package nl.belastingdienst.iva.wd.ihm.dao;

import nl.belastingdienst.iva.wd.ihm.domain.ApiKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ApiKeyRepository extends JpaRepository<ApiKey, Integer> {
    Optional<ApiKey> getByKeyEquals(String apiKey);
}
