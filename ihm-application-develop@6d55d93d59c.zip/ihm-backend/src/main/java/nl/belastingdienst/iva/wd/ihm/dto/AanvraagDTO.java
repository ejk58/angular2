package nl.belastingdienst.iva.wd.ihm.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import nl.belastingdienst.iva.wd.ihm.domain.AanvraagJPA;
import nl.belastingdienst.iva.wd.ihm.domain.ToelichtingJPA;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@ApiModel(value = "Aanvraag", description = "Aanvraag voor inhuur.")
public class AanvraagDTO {

    @JsonProperty(required = false)
    private Integer id;
    
    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Indieningsdatum van dit formulier.", example = "2021-11-11", required = false, position = 1)
    private Date indieningsDatum;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Referentienummer van voorgaande aanvraag bij herhalingsaanvraag.", example = "", required = false, position = 2)
    private String vorigReferentieNr;
    
    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Indiecatie of het om een mini-competitie gaat.", example = "true", required = false, position = 3)
    private String soortMiniCompetitie;
    
    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Soort aanvraag.", example = "normaal", required = false, position = 4)
    private String soortAanvraag;
    
    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Toelichting bij soort aanvraag.", example = "Dit is de toelichting bij de soort aanvraag", required = false, position = 5)
    private ToelichtingDTO soortToelichting;
    
    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Maximale uurtarief.", example = "80", required = false, position = 6)
    private String maximumUurtarief;
    
    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Indicatie of het een spoedaanvraag is.", example = "false", required = false, position = 7)
    private Boolean spoed;








    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Weging van tarief.", example = "20", required = false, position = 801)
    private Integer gunningTarief;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Weging van duurzaamheid en social return.", example = "10", required = false, position = 802)
    private Integer gunningDuurzaamheidSocialReturn;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Weging van relevante werkervaring.", example = "10", required = false, position = 803)
    private Integer gunningRelevanteWerkervaring;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Weging van kennis en vaardigheden van de kandidaat.", example = "10", required = false, position = 804)
    private Integer gunningKennisVaardighedenKandidaat;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Weging van beschikbaarheid van de kandidaat.", example = "10", required = false, position = 805)
    private Integer gunningBeschikbaarheidKandidaat;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Weging van mate waarin de kandidaat de opdracht begrijpt.", example = "10", required = false, position = 806)
    private Integer gunningKandidaatBegrijptOpdracht;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Weging van mate waarin kandidaat bij de organisatie past.", example = "10", required = false, position = 807)
    private Integer gunningKandidaatPastBijOrganisatie;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Toelichting bij duurzaamheid en social return.", example = "Toelichting", required = false, position = 808)
    private ToelichtingDTO gunningToelichtingDuuraamheidSocialReturn;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Toelichting bij beschikbaarheidscriterium.", example = "Toelichting", required = false, position = 809)
    private ToelichtingDTO gunningToelichtingBeschikbaarheid;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Gunning: Toelichting bij duurzaamheid en social return.", example = "Toelichting", required = false, position = 810)
    private Date inzetStartdatum;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Initiële eiddatum.", example = "2022-11-11", required = false, position = 901)
    private Date inzetInitieleEinddatum;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Aantal maanden.", example = "12", required = false, position = 902)
    private Integer inzetAantalMaanden;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Optie op verlenging.", example = "true", required = false, position = 903)
    private Boolean inzetOptieVerlenging;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Einddatum van project.", example = "2023-11-11", required = false, position = 904)
    private Date inzetProjectEinddatum;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Maximaal aantal verlengingen.", example = "3", required = false, position = 905)
    private Integer inzetMaximaalAantalVerlengingen;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Termijn verlenging in maanden.", example = "6", required = false, position = 906)
    private Integer inzetTermijnVerlengingInMaanden;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Uren per week.", example = "32", required = false, position = 907)
    private Integer inzetUrenPerWeek;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Maximaal aantal uren in de initiële termijn.", example = "1440", required = false, position = 908)
    private Integer inzetMaxUrenInitieleTermijn;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Indicatie of vergoeding dienstreizen is inbegrepen.", example = "false", required = false, position = 909)
    private Boolean inzetVergoedingDienstreizenInbegrepen;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Toelichting bij vergoeding van dienstreizen.", example = "Toelichting", required = false, position = 910)
    private ToelichtingDTO inzetVergoedingDienstreizenToelichting;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Hoofdstandplaats.", example = "Apeldoorn", required = false, position = 911)
    private String inzetHoofdstandplaats;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Alternatieve standplaats.", example = "Arnhem", required = false, position = 912)
    private String inzetAlternatieveStandplaats;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Extra standplaatsen.", example = "Den Bosch, Amsterdam, Zutphen", required = false, position = 913)
    private String inzetExtraStandplaatsen;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Indicatie of veiligheidsonderzoek vereist is.", example = "false", required = false, position = 914)
    private Boolean inzetVeiligheidsonderzoekVereist;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Indicatie of VOG voor aanvang van inzet vereist is.", example = "true", required = false, position = 915)
    private Boolean inzetVogBijStartInzet;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Indicatie of vrije vervanging bespreekbaar is.", example = "false", required = false, position = 916)
    private Boolean inzetVrijeVervangingBespreekbaar;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Indicatie of parttime toegestaan is.", example = "true", required = false, position = 917)
    private Boolean inzetParttimersToegestaan;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Indicatie of offsite werken bespreekbaar is.", example = "true", required = false, position = 918)
    private Boolean inzetOffsiteWerkenBespreekbaar;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Indicatie of er sprake is van consignatiediensten.", example = "false", required = false, position = 919)
    private Boolean inzetConsignatiediensten;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Indicatie van betrokkenheid bij aanbestedingen.", example = "false", required = false, position = 920)
    private Boolean inzetBetrokkenheidAanbestedingen;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Inzet: Maximaal aantal CV's.", example = "1", required = false, position = 921)
    private Integer inzetMaxAantalCvs;
}
