package nl.belastingdienst.iva.wd.ihm.controller;

import nl.belastingdienst.iva.wd.ihm.dao.AanvraagRepository;
import nl.belastingdienst.iva.wd.ihm.domain.AanvraagJPA;
import nl.belastingdienst.iva.wd.ihm.domain.AanvraagMapper;
import nl.belastingdienst.iva.wd.ihm.dto.AanvraagDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;

@CrossOrigin
@RestController
@RequestMapping(value = "/api/aanvraag")
public class AanvraagFormController {

    @Autowired
    private AanvraagRepository aanvraagRepository;

    @Autowired
    private AanvraagMapper aanvraagMapper;

    @Transactional
    @PutMapping
    public ResponseEntity<Void> saveAanvraag(@RequestBody AanvraagDTO aanvraagDTO) {
        AanvraagJPA aanvraagJPA = this.aanvraagMapper.map(aanvraagDTO);
        this.aanvraagRepository.save(aanvraagJPA);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
