package nl.belastingdienst.iva.wd.ihm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@ApiModel(value = "Toelichting", description = "Toelichting bij aanvraag.")
public class ToelichtingDTO {

    @JsonProperty(required = false)
    private Integer id;

    @JsonProperty(required = false)
    @ApiModelProperty(notes = "Toelichting bij de rubriek.", example = "Toelichting", required = false, position = 1)
    private String tekst;
}
