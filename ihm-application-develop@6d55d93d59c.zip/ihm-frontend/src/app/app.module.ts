import {HttpClientModule} from '@angular/common/http';
import {ErrorHandler, NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ButtonModule} from 'primeng/button';
import {DropdownModule} from 'primeng/dropdown';
import {InputNumberModule} from 'primeng/inputnumber';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {InputTextModule} from 'primeng/inputtext';
import {RadioButtonModule} from 'primeng/radiobutton';
import {CheckboxModule} from 'primeng/checkbox';
import {MenuModule} from 'primeng/menu';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {HeaderComponent} from './components/header/header.component';
import {FooterComponent} from './components/footer/footer.component';
import {PageMenuComponent} from './components/page-menu/page-menu.component';
import {LoggedInGuard} from './guards/logged-in.guard';
import {LoginComponent} from './components/login/login.component';
import {LoginService} from './services/login.service';
import {PageMenuService} from './services/page-menu.service';
import {SystemService} from './services/system.service';
import * as httpInterceptorProviders from './interceptors';
import * as pipes from './pipes/index';
import {DatePipe} from '@angular/common';
import {SpinnerComponent} from './components/spinner/spinner.component';
import {SpinnerService} from './services/spinner.service';
import {ErrorComponent} from './components/error/error.component';
import {GlobalErrorHandler} from './error-handling/global-error-handler';
import {ErrorService} from './services/error.service';
import {DialogModule} from 'primeng/dialog';
import {DialogService, DynamicDialogConfig, DynamicDialogRef} from 'primeng/dynamicdialog';
import {InhuurformulierComponent} from './inhuur/inhuurformulier/inhuurformulier.component';
import {AanvraagFormComponent} from './inhuur/aanvraag-form/aanvraag-form.component';
import {AanvragerFormComponent} from './inhuur/aanvrager-form/aanvrager-form.component';
import {LookupService} from './services/lookup.service';
import {InhuurFormulierService} from './inhuur/services/inhuur-formulier.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    PageMenuComponent,
    SpinnerComponent,
    ErrorComponent,
    pipes.list,
    InhuurformulierComponent,
    AanvraagFormComponent,
    AanvragerFormComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    DropdownModule,
    InputNumberModule,
    MenuModule,
    RadioButtonModule,
    InputTextareaModule,
    InputTextModule,
    CheckboxModule,
    ProgressSpinnerModule,
    DialogModule
  ],
  providers: [
    httpInterceptorProviders.list,
    LoggedInGuard,
    LoginService,
    LookupService,
    PageMenuService,
    SystemService,
    SpinnerService,
    ErrorService,
    InhuurFormulierService,
    DialogService,
    DynamicDialogConfig,
    DynamicDialogRef,
    DatePipe,
    pipes.list,
    {provide: ErrorHandler, useClass: GlobalErrorHandler},
  ],
  bootstrap: [AppComponent]
})

export class AppModule {

}
