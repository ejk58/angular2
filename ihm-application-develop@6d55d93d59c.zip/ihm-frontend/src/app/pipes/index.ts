import {IhmDateTimePipe} from './date-time.pipe';

export const list = [
  IhmDateTimePipe
];
