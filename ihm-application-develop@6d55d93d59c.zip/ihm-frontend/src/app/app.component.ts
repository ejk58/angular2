import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {ErrorService} from './services/error.service';
import {ErrorComponent} from './components/error/error.component';
import {DialogService} from 'primeng/dynamicdialog';
import {Unsubscriber} from './common/unsubscriber';

@Component({
  selector: 'ihm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [Unsubscriber]
})

export class AppComponent implements OnInit, OnDestroy {

  // Necessary to show modal ErrorComponent automatically
  @ViewChild('hiddenModalBtn', {read: ElementRef}) myHiddenModalBtn: ElementRef;

  private errorDialogOpen: boolean = false;

  constructor(private readonly errorService: ErrorService,
              private readonly dialogService: DialogService,
              private readonly unsubscriber: Unsubscriber) {
    this.myHiddenModalBtn = new ElementRef<unknown>(undefined);
  }

  ngOnInit(): void {
    this.initializeModalForErrorMessage();
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  // Only necessary to show modal ErrorComponent automatically.
  openModalForErrorMessage(): void {
    // Intentionally left empty.
  }

  private initializeModalForErrorMessage(): void {
    this.errorService
      .getErrorMessage()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(errorMessage => {
        if (!this.errorDialogOpen) {
          const ref = this.dialogService.open(ErrorComponent, {data: {errorMessage}, header: 'Foutmelding', width: '50%'});
          this.errorDialogOpen = true;
          this.myHiddenModalBtn.nativeElement.click(); // Show modal ErrorComponent automatically
          ref.onClose.subscribe(() => this.errorDialogOpen = false);
        }
      });
  }

}
