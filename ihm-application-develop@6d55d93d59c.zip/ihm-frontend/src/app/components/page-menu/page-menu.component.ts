import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Router} from '@angular/router';

import {PageMenuService} from '../../services/page-menu.service';

import {PageMenuInterface} from '../../domain/application/page-menu.interface';

@Component({
  selector: 'ihm-page-menu',
  templateUrl: './page-menu.component.html',
  styleUrls: ['./page-menu.component.scss']
})

export class PageMenuComponent implements OnInit {
  @Output() pageMenuOpen: EventEmitter<boolean> = new EventEmitter();

  pageMenu: Array<PageMenuInterface>;
  currentPageKey: string;

  constructor(private pageMenuService: PageMenuService, private router: Router) {
  }

  ngOnInit(): void {
    this.pageMenu = this.pageMenuService.getPageMenuItems();
    this.currentPageKey = this.router.url.substring(1);
  }

  changePage(pageMenuTitleIndex: number, pageMenuOptionIndex: number): void {
    const menuOption = this.pageMenu[pageMenuTitleIndex].options[pageMenuOptionIndex];
    this.router.navigate([menuOption.key]);
    this.currentPageKey = menuOption.key;
    this.pageMenuOpen.emit(false);
  }

}
