import {Component, OnInit} from '@angular/core';
import {SpinnerService} from '../../services/spinner.service';
import {Observable} from 'rxjs';

@Component({
  selector: 'ihm-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})

export class SpinnerComponent implements OnInit {

  isSpinning$!: Observable<boolean>;

  constructor(private readonly spinnerService: SpinnerService) {
  }

  ngOnInit(): void {
    this.isSpinning$ = this.spinnerService.isSpinning$;
  }

}
