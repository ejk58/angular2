import {Component, OnDestroy, OnInit} from '@angular/core';
import {LoginService} from '../../services/login.service';
import {Router} from '@angular/router';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ApplicationUser} from '../../domain/application/application-user';
import {Unsubscriber} from '../../common/unsubscriber';

@Component({
  selector: 'ihm-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [Unsubscriber]
})
export class LoginComponent implements OnDestroy, OnInit {

  form: FormGroup;
  submitted = false;

  errorMessage: string;
  loading = false;

  constructor(private readonly router: Router,
              private readonly formBuilder: FormBuilder,
              private readonly loginService: LoginService,
              private readonly unsubscriber: Unsubscriber) {
    this.form = this.formBuilder.group({
      userId: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.form.valueChanges
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(() => this.errorMessage = undefined);
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  login() {
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    this.loginService.login(<ApplicationUser>this.form.value).subscribe({
      next: () => {
        this.router.navigate(['/'], {queryParamsHandling: 'preserve'});
      },
      error: (error: unknown) => {
        console.warn(error);
        this.errorMessage = 'Gebruikersnaam en/of wachtwoord fout';
        this.loading = false;
      }
    });
  }

  // Convenience getter for easy access to form fields
  get formControl(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
}
