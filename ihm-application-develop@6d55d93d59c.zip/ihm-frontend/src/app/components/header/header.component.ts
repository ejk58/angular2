import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {LoginService} from '../../services/login.service';

@Component({
  selector: 'ihm-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent implements OnInit {
  isLoggedIn$!: Observable<boolean>;
  loggedInUser: string;
  accountMenuOpen: boolean = false;
  pageMenuOpen: boolean = false;

  constructor(private loginService: LoginService) { }

  ngOnInit(): void {
    this.isLoggedIn$ = this.loginService.isLoggedIn();
    this.loginService.loggedInUser().subscribe(user => {
      this.loggedInUser = user;
    });
  }

  logout(): void {
    this.accountMenuOpen = false;
    this.pageMenuOpen = false;
    this.loginService.logout();
  }

  toggleAccountMenu(): boolean {
    return this.accountMenuOpen = !this.accountMenuOpen;
  }

  togglePageMenu(): boolean {
    return this.pageMenuOpen = !this.pageMenuOpen;
  }

  handlePageMenuOpen(event: boolean): void {
    this.pageMenuOpen = event;
  }

}
