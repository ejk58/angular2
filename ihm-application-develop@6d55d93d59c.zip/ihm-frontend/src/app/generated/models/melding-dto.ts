/* tslint:disable */
import {PersoonDTO} from './persoon-dto';
import {PrioriteitDTO} from './prioriteit-dto';
import {StatusLogDTO} from './status-log-dto';

export interface MeldingDTO {
  behandelaarId?: number;
  belastingMiddellen?: string;
  id?: number;
  implementatieDatum?: string;
  indienDatum?: string;
  meldingsNummer?: string;
  personen?: Array<PersoonDTO>;
  prioriteiten?: Array<PrioriteitDTO>;
  samenvatting?: string;
  statusLogs?: Array<StatusLogDTO>;
}
