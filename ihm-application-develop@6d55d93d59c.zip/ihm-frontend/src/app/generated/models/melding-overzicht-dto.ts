/* tslint:disable */
import {PrioriteitOverzichtDTO} from './prioriteit-overzicht-dto';

export interface MeldingOverzichtDTO {
  belastingMiddellen?: string;
  id?: number;
  implementatieDatum?: string;
  indienDatum?: string;
  meldingsNummer?: string;
  prioriteiten?: Array<PrioriteitOverzichtDTO>;
  status?: string;
}
