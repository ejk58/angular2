import {Lookup} from './lookup';

export interface AllLookupsDTO {
  soortAanvraag: Array<Lookup>;
  soortMiniCompetitie: Array<Lookup>;
}
