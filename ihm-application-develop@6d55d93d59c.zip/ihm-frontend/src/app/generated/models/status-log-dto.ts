/* tslint:disable */
export interface StatusLogDTO {
  behandelaarId?: number;
  status?: 'NEW' | 'PRIORITIZED' | 'ANALYZING' | 'IN_REVIEW' | 'DONE_NO_REVIEW' | 'DONE_REVIEW';
  wijzigingsMoment?: string;
}
