/* tslint:disable */
export interface Stroom {
  adGroep?: string;
  id?: number;
  naam?: string;
}
