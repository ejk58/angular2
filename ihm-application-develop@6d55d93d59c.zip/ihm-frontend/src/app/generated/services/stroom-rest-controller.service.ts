/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';

import {Stroom} from '../models/stroom';

/**
 * Stroom Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class StroomRestControllerService extends __BaseService {
  static readonly getStromenUsingGETPath = '/api/stroom';
  static readonly getCurrentStroomUsingGETPath = '/api/stroom/current';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * getStromen
   * @return OK
   */
  getStromenUsingGETResponse(): __Observable<__StrictHttpResponse<Array<Stroom>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/stroom`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<Stroom>>;
      })
    );
  }

  /**
   * getStromen
   * @return OK
   */
  getStromenUsingGET(): __Observable<Array<Stroom>> {
    return this.getStromenUsingGETResponse().pipe(
      __map(_r => _r.body as Array<Stroom>)
    );
  }

  /**
   * getCurrentStroom
   * @param Authorization Authorization
   * @return OK
   */
  getCurrentStroomUsingGETResponse(Authorization: string): __Observable<__StrictHttpResponse<string>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    if (Authorization != null) __headers = __headers.set('Authorization', Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/stroom/current`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<string>;
      })
    );
  }

  /**
   * getCurrentStroom
   * @param Authorization Authorization
   * @return OK
   */
  getCurrentStroomUsingGET(Authorization: string): __Observable<string> {
    return this.getCurrentStroomUsingGETResponse(Authorization).pipe(
      __map(_r => _r.body as string)
    );
  }
}

module StroomRestControllerService {
}

export {StroomRestControllerService};
