/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';

import {MeldingDTO} from '../models/melding-dto';
import {PagingMeldingOverzichtDTO} from '../models/paging-melding-overzicht-dto';
import {LazyLoadData} from '../models/lazy-load-data';
import {MeldingOverzichtDTO} from '../models/melding-overzicht-dto';

/**
 * Melding Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class MeldingRestControllerService extends __BaseService {
  static readonly createMeldingUsingPOSTPath = '/api/melding';
  static readonly getMeldingenUsingPOSTPath = '/api/melding/overzicht';
  static readonly addTestdataUsingGETPath = '/api/melding/testdata/{stroom}/{aantal}';
  static readonly getMeldingUsingGETPath = '/api/melding/{meldingsNummer}';
  static readonly getMeldingenWithStatusUsingGETPath = '/api/melding/{status}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * createMelding
   * @param params The `MeldingRestControllerService.CreateMeldingUsingPOSTParams` containing the following parameters:
   *
   * - `body`: body
   *
   * - `Authorization`: Authorization
   */
  createMeldingUsingPOSTResponse(params: MeldingRestControllerService.CreateMeldingUsingPOSTParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = params.body;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/melding`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }

  /**
   * createMelding
   * @param params The `MeldingRestControllerService.CreateMeldingUsingPOSTParams` containing the following parameters:
   *
   * - `body`: body
   *
   * - `Authorization`: Authorization
   */
  createMeldingUsingPOST(params: MeldingRestControllerService.CreateMeldingUsingPOSTParams): __Observable<null> {
    return this.createMeldingUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }

  /**
   * getMeldingen
   * @param params The `MeldingRestControllerService.GetMeldingenUsingPOSTParams` containing the following parameters:
   *
   * - `lazyLoadData`: lazyLoadData
   *
   * - `Authorization`: Authorization
   *
   * @return OK
   */
  getMeldingenUsingPOSTResponse(params: MeldingRestControllerService.GetMeldingenUsingPOSTParams): __Observable<__StrictHttpResponse<PagingMeldingOverzichtDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = params.lazyLoadData;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/melding/overzicht`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<PagingMeldingOverzichtDTO>;
      })
    );
  }

  /**
   * getMeldingen
   * @param params The `MeldingRestControllerService.GetMeldingenUsingPOSTParams` containing the following parameters:
   *
   * - `lazyLoadData`: lazyLoadData
   *
   * - `Authorization`: Authorization
   *
   * @return OK
   */
  getMeldingenUsingPOST(params: MeldingRestControllerService.GetMeldingenUsingPOSTParams): __Observable<PagingMeldingOverzichtDTO> {
    return this.getMeldingenUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as PagingMeldingOverzichtDTO)
    );
  }

  /**
   * addTestdata
   * @param params The `MeldingRestControllerService.AddTestdataUsingGETParams` containing the following parameters:
   *
   * - `stroom`: stroom
   *
   * - `aantal`: aantal
   */
  addTestdataUsingGETResponse(params: MeldingRestControllerService.AddTestdataUsingGETParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/melding/testdata/${encodeURIComponent(String(params.stroom))}/${encodeURIComponent(String(params.aantal))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }

  /**
   * addTestdata
   * @param params The `MeldingRestControllerService.AddTestdataUsingGETParams` containing the following parameters:
   *
   * - `stroom`: stroom
   *
   * - `aantal`: aantal
   */
  addTestdataUsingGET(params: MeldingRestControllerService.AddTestdataUsingGETParams): __Observable<null> {
    return this.addTestdataUsingGETResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }

  /**
   * getMelding
   * @param meldingsNummer meldingsNummer
   * @return OK
   */
  getMeldingUsingGETResponse(meldingsNummer: string): __Observable<__StrictHttpResponse<MeldingDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/melding/${encodeURIComponent(String(meldingsNummer))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<MeldingDTO>;
      })
    );
  }

  /**
   * getMelding
   * @param meldingsNummer meldingsNummer
   * @return OK
   */
  getMeldingUsingGET(meldingsNummer: string): __Observable<MeldingDTO> {
    return this.getMeldingUsingGETResponse(meldingsNummer).pipe(
      __map(_r => _r.body as MeldingDTO)
    );
  }

  /**
   * getMeldingenWithStatus
   * @param status status
   * @return OK
   */
  getMeldingenWithStatusUsingGETResponse(status: string): __Observable<__StrictHttpResponse<Array<MeldingOverzichtDTO>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/melding/${encodeURIComponent(String(status))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<MeldingOverzichtDTO>>;
      })
    );
  }

  /**
   * getMeldingenWithStatus
   * @param status status
   * @return OK
   */
  getMeldingenWithStatusUsingGET(status: string): __Observable<Array<MeldingOverzichtDTO>> {
    return this.getMeldingenWithStatusUsingGETResponse(status).pipe(
      __map(_r => _r.body as Array<MeldingOverzichtDTO>)
    );
  }
}

module MeldingRestControllerService {

  /**
   * Parameters for createMeldingUsingPOST
   */
  export interface CreateMeldingUsingPOSTParams {

    /**
     * body
     */
    body: MeldingDTO;

    /**
     * Authorization
     */
    Authorization: string;
  }

  /**
   * Parameters for getMeldingenUsingPOST
   */
  export interface GetMeldingenUsingPOSTParams {

    /**
     * lazyLoadData
     */
    lazyLoadData: LazyLoadData;

    /**
     * Authorization
     */
    Authorization: string;
  }

  /**
   * Parameters for addTestdataUsingGET
   */
  export interface AddTestdataUsingGETParams {

    /**
     * stroom
     */
    stroom: string;

    /**
     * aantal
     */
    aantal: number;
  }
}

export {MeldingRestControllerService};
