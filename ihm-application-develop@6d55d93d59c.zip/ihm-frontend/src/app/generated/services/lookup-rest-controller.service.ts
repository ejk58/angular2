/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';

import {Lookup} from '../models/lookup';
import {AllLookupsDTO} from '../models/all-lookups-dto';

/**
 * Lookup Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class LookupRestControllerService extends __BaseService {
  static readonly lookupTabelUsingGETPath = '/api/lookup';
  static readonly lookupTabellenUsingGETPath = '/api/lookup/all';
  static readonly lookupNextStatusUsingGETPath = '/api/lookup/next';

  constructor(
      config: __Configuration,
      http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * lookupTabel
   * @param tabel tabel
   * @return OK
   */
  lookupTabelUsingGETResponse(tabel: 'BELASTINGMIDDEL' | 'ROL' | 'STATUS' | 'WEZENKENMERK'): __Observable<__StrictHttpResponse<Array<Lookup>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    if (tabel != null) __params = __params.set('tabel', tabel.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/lookup`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<Lookup>>;
      })
    );
  }

  /**
   * lookupTabel
   * @param tabel tabel
   * @return OK
   */
  lookupTabelUsingGET(tabel: 'BELASTINGMIDDEL' | 'ROL' | 'STATUS' | 'WEZENKENMERK'): __Observable<Array<Lookup>> {
    return this.lookupTabelUsingGETResponse(tabel).pipe(
        __map(_r => _r.body as Array<Lookup>)
    );
  }

  /**
   * lookupTabellen
   * @return OK
   */
  lookupTabellenUsingGETResponse(): __Observable<__StrictHttpResponse<AllLookupsDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
        'GET',
        this.rootUrl + `/api/lookup/all`,
        __body,
        {
          headers: __headers,
          params: __params,
          responseType: 'json'
        });

    return this.http.request<any>(req).pipe(
        __filter(_r => _r instanceof HttpResponse),
        __map((_r) => {
          return _r as __StrictHttpResponse<AllLookupsDTO>;
        })
    );
  }

  /**
   * lookupTabellen
   * @return OK
   */
  lookupTabellenUsingGET(): __Observable<AllLookupsDTO> {
    return this.lookupTabellenUsingGETResponse().pipe(
        __map(_r => _r.body as AllLookupsDTO)
    );
  }

  /**
   * lookupNextStatus
   * @return OK
   */
  lookupNextStatusUsingGETResponse(): __Observable<__StrictHttpResponse<{ [key: string]: Array<string> }>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
        'GET',
        this.rootUrl + `/api/lookup/next`,
        __body,
        {
          headers: __headers,
          params: __params,
          responseType: 'json'
        });

    return this.http.request<any>(req).pipe(
        __filter(_r => _r instanceof HttpResponse),
        __map((_r) => {
          return _r as __StrictHttpResponse<{ [key: string]: Array<string> }>;
        })
    );
  }

  /**
   * lookupNextStatus
   * @return OK
   */
  lookupNextStatusUsingGET(): __Observable<{ [key: string]: Array<string> }> {
    return this.lookupNextStatusUsingGETResponse().pipe(
        __map(_r => _r.body as { [key: string]: Array<string> })
    );
  }
}

module LookupRestControllerService {
}

export { LookupRestControllerService }
