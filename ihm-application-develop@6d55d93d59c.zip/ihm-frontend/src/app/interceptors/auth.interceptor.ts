/* eslint-disable @typescript-eslint/no-explicit-any */
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {tap} from 'rxjs/operators';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    const idToken = localStorage.getItem('id_token');
    if (idToken && req.url !== '/api/login') {
      const cloned = req.clone({setHeaders: {Authorization: 'Bearer ' + idToken}});
      return next.handle(cloned);
    } else {
      return next.handle(req).pipe(

        tap((event: HttpEvent<any>) => {
          if (event instanceof HttpResponse) {
            const tkn = event.headers.get('authorization');
            if (tkn) {
              localStorage.setItem('id_token', tkn.substr(7));
            }
          }
        })
      );
    }
  }
}
