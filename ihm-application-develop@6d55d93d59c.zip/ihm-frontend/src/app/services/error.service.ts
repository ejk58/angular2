import {Injectable} from '@angular/core';
import {Observable, Subject} from 'rxjs';

@Injectable()
export class ErrorService {

  private readonly errorMessage$ = new Subject<string>();

  addErrorMessage(errorMessage: string): void {
    this.errorMessage$.next(errorMessage);
  }

  getErrorMessage(): Observable<string> {
    return this.errorMessage$.asObservable();
  }

}
