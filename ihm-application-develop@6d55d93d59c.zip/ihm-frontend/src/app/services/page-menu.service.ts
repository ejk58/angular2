import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {PageMenuInterface} from '../domain/application/page-menu.interface';

@Injectable()
export class PageMenuService {

  pageMenu: Array<PageMenuInterface> = [
    {title: 'Aanvraag inhuur', options: [{label: 'Inhuurformulier', key: ''}]}
  ];

  constructor(private readonly router: Router) {
  }

  getPageMenuItems(): Array<PageMenuInterface> {
    return this.pageMenu;
  }

  getCurrentMenuLabel(): string {
    const key = this.router.url.substring(1);
    let menuItem: string;
    this.pageMenu.forEach(mainMenu => {
      const result = (mainMenu.options.filter((item: { key: string; }) => item.key === key));
      if (result.length > 0) {
        menuItem = result[0]['label'];
      }
    });
    return menuItem;
  }

}
