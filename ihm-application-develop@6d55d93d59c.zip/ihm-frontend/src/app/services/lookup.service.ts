import {Injectable} from '@angular/core';
import {AllLookupsDTO} from '../generated/models/all-lookups-dto';
import {Lookup} from '../generated/models/lookup';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {BehaviorSubject, Observable} from 'rxjs';
import {SOORTAANVRAAG, SOORTMINICOMPETITIE} from '../inhuur/domain/constants';

@Injectable()
export class LookupService {

  private isFetchingLookupTablesReadyLocal$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private tabellen: AllLookupsDTO = {soortAanvraag: [], soortMiniCompetitie: []};

  constructor(private lookupRestControllerService: LookupRestControllerService) {
    this.lookupRestControllerService.lookupTabellenUsingGET()
      .subscribe({
        next: (tabellen: AllLookupsDTO) => {
          this.tabellen = tabellen;
          this.isFetchingLookupTablesReadyLocal$.next(true);
        },
        error: (error: unknown) => {
          this.isFetchingLookupTablesReadyLocal$.next(true);
          throw <Error>error;
        }
      });
  }

  get(soort: typeof SOORTAANVRAAG | typeof SOORTMINICOMPETITIE): Lookup[] {
    switch (soort) {
      case SOORTAANVRAAG:
        return this.tabellen.soortAanvraag;
      case SOORTMINICOMPETITIE:
        return this.tabellen.soortMiniCompetitie;
    }
  }

  get isFetchingLookupTablesReady$(): Observable<boolean> {
    return this.isFetchingLookupTablesReadyLocal$.asObservable();
  }

}
