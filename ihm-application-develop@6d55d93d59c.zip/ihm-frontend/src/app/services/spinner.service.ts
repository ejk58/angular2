import {BehaviorSubject, Observable} from 'rxjs';

export class SpinnerService {

  private isSpinningLocal$: BehaviorSubject<boolean> = new BehaviorSubject(false);

  show(): void {
    this.isSpinningLocal$.next(true);
  }

  hide(): void {
    this.isSpinningLocal$.next(false);
  }

  get isSpinning$(): Observable<boolean> {
    return this.isSpinningLocal$.asObservable();
  }
}
