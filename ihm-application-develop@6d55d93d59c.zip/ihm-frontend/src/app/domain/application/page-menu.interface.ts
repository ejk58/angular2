interface Options {
    label: string,
    key: string
}

export interface PageMenuInterface {
    title: string,
    options: Array<Options>
}
