import {ToelichtingDto} from './toelichting-dto';

export interface InhuurformulierDto {

  // Aanvraag
  ongewijzigdeHerhalingsaanvraag: boolean;
  vorigReferentieNr: string;
  soortMiniCompetitie: string;
  soortAanvraag: string;
  maximumUurtarief: string;
  spoed: boolean;
  soortToelichting: ToelichtingDto;

  // Aanvrager
  departement: string;
  deelnemer: string;
  afdelingBedrijfsonderdeel: string;
  inhurendManager: string;
}
