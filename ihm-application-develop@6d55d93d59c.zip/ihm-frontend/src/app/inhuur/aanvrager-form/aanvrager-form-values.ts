export class AanvragerFormValues {
  departement: string;
  deelnemer: string;
  afdelingBedrijfsonderdeel: string;
  inhurendManager: string;
}
