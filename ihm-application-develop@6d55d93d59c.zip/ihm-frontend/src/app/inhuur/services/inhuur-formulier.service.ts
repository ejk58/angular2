import {Injectable} from '@angular/core';
import {InhuurformulierDto} from '../../domain/dto/inhuurformulier-dto';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable()
export class InhuurFormulierService {

  // TODO: 'api/aanvraag' moet iets worden als 'api/inhuur' (want 'aanvraag' is ook 1e sectie op formulier)
  private readonly aanvraagUrl = 'api/aanvraag';

  constructor(private readonly http: HttpClient) {}

  save(inhuurformulierDto: InhuurformulierDto): Observable<string> {
    return this.http.put(`${this.aanvraagUrl}`, inhuurformulierDto, {responseType: 'text'});
  }

}
