import {AfterViewInit, Component, EventEmitter, forwardRef, OnDestroy, OnInit, Output} from '@angular/core';
import {FormBuilder, NG_VALUE_ACCESSOR, Validators} from '@angular/forms';
import {AanvraagFormValues} from './aanvraag-form-values';
import {AbstractFormSection} from '../form-section/abstract-form-section';
import {FormSectionStatus} from '../domain/form-section-status';
import {SectionStatus} from '../domain/section-status';
import {AANVRAAG, SOORTAANVRAAG, SOORTMINICOMPETITIE} from '../domain/constants';
import {pairwise, startWith} from 'rxjs/operators';
import {LookupService} from '../../services/lookup.service';
import {Lookup} from '../../generated/models/lookup';
import {Unsubscriber} from '../../common/unsubscriber';

@Component({
  selector: 'ihm-aanvraag-form',
  templateUrl: './aanvraag-form.component.html',
  styleUrls: ['./aanvraag-form.component.scss'],
  providers: [{provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => AanvraagFormComponent), multi: true}, Unsubscriber]
})
export class AanvraagFormComponent extends AbstractFormSection<AanvraagFormValues> implements AfterViewInit, OnDestroy, OnInit {

  soortenAanvraag: string[] = [];
  soortenMiniCompetitie: string[] = [];

  @Output() statusChanged: EventEmitter<FormSectionStatus> = new EventEmitter<FormSectionStatus>();

  constructor(private readonly formBuilder: FormBuilder,
              private readonly lookupService: LookupService,
              private readonly unsubscriber: Unsubscriber) {
    super();
    this.formSection = this.formBuilder.group({
      ongewijzigdeHerhalingsaanvraag: ['', [Validators.required]],
      vorigReferentieNr: [''],
      soortMiniCompetitie: [''],
      soortAanvraag: ['', [Validators.required]],
      maximumUurtarief: [''],
      spoed: ['', [Validators.required]],
      soortToelichting: ['']
    });
    super.activateSubscriptionsToValueChanges();

    // TODO: dit moet alleen gebeuren bij invullen nieuw formulier
    this.setDefaultValuesForAanvraag();
  }

  ngOnInit(): void {
    // Emit inital status
    this.formSection.updateValueAndValidity({onlySelf: true, emitEvent: false});
    this.statusChanged.emit({sectionName: AANVRAAG, status: SectionStatus[this.formSection.status]});

    this.lookupService.isFetchingLookupTablesReady$
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(() => {
        this.soortenAanvraag = this.lookupService.get(SOORTAANVRAAG).map((lookup: Lookup) => lookup.omschrijving);
        this.soortenMiniCompetitie = this.lookupService.get(SOORTMINICOMPETITIE).map((lookup: Lookup) => lookup.omschrijving);
      });
  }

  ngOnDestroy() {
    super.ngOnDestroy();
    this.unsubscriber.unsubscribe();
  }

  ngAfterViewInit() {
    // TODO: onderzoeken of het beter is om hier 'combineLatest' met 'distinctUntilChanged' te gebruiken (zie review commentaar Rick)
    // Emit status change
    this.formSection.statusChanges
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe((status: string) => {
        this.statusChanged.emit({sectionName: AANVRAAG, status: SectionStatus[status]});
      });
    // Add or remove validator for field 'vorigReferentieNr' which is optionally shown
    this.formSection.valueChanges
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .pipe(startWith(new AanvraagFormValues()), pairwise())
      .subscribe(([prev, next]: [AanvraagFormValues, AanvraagFormValues]) => {
        if (next.ongewijzigdeHerhalingsaanvraag !== prev.ongewijzigdeHerhalingsaanvraag) {
          if (next.ongewijzigdeHerhalingsaanvraag) {
            this.formSection.get('vorigReferentieNr').addValidators(Validators.required);
            this.formSection.get('vorigReferentieNr').updateValueAndValidity({onlySelf: false, emitEvent: false});
          } else {
            this.formSection.get('vorigReferentieNr').removeValidators(Validators.required);
            this.formSection.get('vorigReferentieNr').updateValueAndValidity({onlySelf: false, emitEvent: false});
          }
        }
      });
  }

  private setDefaultValuesForAanvraag(): void {
    this.formSection.patchValue({ongewijzigdeHerhalingsaanvraag: false});
    this.formSection.patchValue({soortMiniCompetitie: null});
    this.formSection.patchValue({soortAanvraag: 'Regulier'});
    this.formSection.patchValue({spoed: false});
  }
}
