import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {InhuurformulierDto} from '../../domain/dto/inhuurformulier-dto';
import {AanvraagFormValues} from '../aanvraag-form/aanvraag-form-values';
import {AanvragerFormValues} from '../aanvrager-form/aanvrager-form-values';
import {FormSectionStatus} from '../domain/form-section-status';
import {SectionStatus} from '../domain/section-status';
import {AANVRAAG, AANVRAGER} from '../domain/constants';
import {InhuurFormulierService} from '../services/inhuur-formulier.service';
import {ToelichtingDto} from '../../domain/dto/toelichting-dto';

@Component({
  selector: 'ihm-inhuurformulier',
  templateUrl: './inhuurformulier.component.html',
  styleUrls: ['./inhuurformulier.component.scss']
})
export class InhuurformulierComponent implements OnInit {

  inhuurForm: FormGroup;
  aanvraagFormValues: AanvraagFormValues = new AanvraagFormValues();
  aanvragerFormValues: AanvragerFormValues = new AanvragerFormValues();

  // TODO: misschien een map maken met alle <string, boolean> waarbij de key de 'sectienaam' is en de boolean de 'status'
  isInhuurFormValid: boolean = false;
  isAanvraagFormValid: boolean = false;
  isAanvragerFormValid: boolean = false;

  constructor(private readonly formBuilder: FormBuilder, private readonly inhuurFormulierService: InhuurFormulierService) {
    this.inhuurForm = this.formBuilder.group({
      aanvraagForm: [],
      aanvragerForm: []
    });
  }

  ngOnInit(): void {
    // TODO: backend call om gegevens inhuurformulier op te halen. Alleen nodig als het geen nieuw formulier betreft.
    // TODO: vul de verschillende onderdelen in het formulier (nodig als formulier uit backend wordt opgehaald)
    // Object.keys(this.aanvraagFormValues).forEach(key => this.aanvraagFormValues[key] = this.inhuurformulierDto[key]);
    // Object.keys(this.aanvragerFormValues).forEach(key => this.aanvragerFormValues[key] = this.inhuurformulierDto[key]);

    this.inhuurForm.patchValue({aanvraagForm: this.aanvraagFormValues});
    this.inhuurForm.patchValue({aanvragerForm: this.aanvragerFormValues});
  }

  onStatusChanged(formSectionStatus: FormSectionStatus): void {
    console.log('zit in InhuurfomrulierComponent onStatusChanges... ' + formSectionStatus.sectionName + ' ' + formSectionStatus.status);
    switch (formSectionStatus.sectionName) {
      case AANVRAAG:
        this.isAanvraagFormValid = formSectionStatus.status === SectionStatus.VALID;
        break;
      case AANVRAGER:
        this.isAanvragerFormValid = formSectionStatus.status === SectionStatus.VALID;
        break;
    }
    this.isInhuurFormValid = this.isAanvraagFormValid && this.isAanvragerFormValid;
    this.inhuurForm.setErrors(this.isInhuurFormValid ? null : {inhuurForm: {valid: false}});
  }

  save(): void {
    console.log('zit in InhuurformulierComponent save...');
    console.log('Formulier: ' + JSON.stringify(this.inhuurForm.value));
    const inhuurformulierDto = this.mapFormToDto();
    this.inhuurFormulierService.save(inhuurformulierDto).subscribe((tekst) => console.log(tekst));
  }

  private mapFormToDto(): InhuurformulierDto {
    // TODO: het mappen van het de velden in het FORM naar de DTO is nog niet heel fraai, moet beter kunnen :-)
    const toelichtingDto: ToelichtingDto = {tekst: undefined};
    const inhuurformulierDto: InhuurformulierDto = {
      ongewijzigdeHerhalingsaanvraag: undefined,
      vorigReferentieNr: undefined,
      soortMiniCompetitie: undefined,
      soortAanvraag: undefined,
      maximumUurtarief: undefined,
      spoed: undefined,
      soortToelichting: toelichtingDto,
      departement: undefined,
      deelnemer: undefined,
      afdelingBedrijfsonderdeel: undefined,
      inhurendManager: undefined
    };
    Object.keys(this.inhuurForm.value['aanvraagForm'])
      .forEach(key => inhuurformulierDto[key] = this.inhuurForm.value['aanvraagForm'][key]);
    Object.keys(this.inhuurForm.value['aanvragerForm'])
      .forEach(key => inhuurformulierDto[key] = this.inhuurForm.value['aanvragerForm'][key]);
    const soortToelichtingTekst: string = this.inhuurForm.value['aanvraagForm']['soortToelichting'];
    inhuurformulierDto.soortToelichting = soortToelichtingTekst.trim().length > 0 ? {tekst: soortToelichtingTekst} : null;
    return inhuurformulierDto;
  }
}
