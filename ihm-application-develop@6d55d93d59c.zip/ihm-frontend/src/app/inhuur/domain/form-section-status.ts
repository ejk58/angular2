import {SectionStatus} from './section-status';
import {AANVRAAG, AANVRAGER} from './constants';

export interface FormSectionStatus {
  sectionName: typeof AANVRAAG | typeof AANVRAGER;
  status: SectionStatus;
}
