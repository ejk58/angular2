/* eslint-disable @typescript-eslint/naming-convention */
// FormSection names
export const AANVRAAG = 'aanvraag';
export const AANVRAGER = 'aanvrager';
// Lookup-table names
export const SOORTAANVRAAG = 'SOORTAANVRAAG';
export const SOORTMINICOMPETITIE = 'SOORTMINICOMPETITIE';
