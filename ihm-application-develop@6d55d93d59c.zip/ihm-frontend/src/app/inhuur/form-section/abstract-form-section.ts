import {Directive, OnDestroy} from '@angular/core';
import {ControlValueAccessor, FormGroup} from '@angular/forms';
import {Subscription} from 'rxjs';

@Directive()
export abstract class AbstractFormSection<T> implements ControlValueAccessor, OnDestroy {

  private formSectionLocal: FormGroup;
  private subscriptionsLocal: Subscription[] = [];

  ngOnDestroy(): void {
    this.subscriptions.forEach((s => s.unsubscribe()));
  }

  get formSection(): FormGroup {
    return this.formSectionLocal;
  }

  set formSection(formSection: FormGroup) {
    this.formSectionLocal = formSection;
  }

  get subscriptions(): Subscription[] {
    return this.subscriptionsLocal;
  }

  get value(): T {
    return this.formSection.value;
  }

  set value(value: T) {
    this.formSection.patchValue(value);
    this.onChange(value);
    this.onTouched();
  }

  activateSubscriptionsToValueChanges(): void {
    this.subscriptions.push(
      // Any time the inner form changes update the parent of any change
      this.formSection.valueChanges.subscribe((value: T) => {
        this.onChange(value);
        this.onTouched();
      })
    );
  }

  onChange: (value: T) => void = () => {
    // Intentionally left empty
  };

  onTouched: () => void = () => {
    // Intentionally left empty
  };

  registerOnChange(fn: (value: T) => void) {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void) {
    this.onTouched = fn;
  }

  writeValue(value: T): void {
    if (value) {
      this.value = value;
    }
    if (value === null) {
      this.formSection.reset();
    }
  }

}
