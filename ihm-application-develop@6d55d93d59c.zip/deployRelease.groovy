@Library("GENERIC") _
pipelineDeployArtifactFromQuay {
    deploymentId = "iva-ihm"
    integrationPipeline = ""
    packageChoices = "iva-ihm"
    applicationVersionChoices = "0.18.0\n0.17.0\n0.15.0\n0.14.0\n0.13.0"
    asVersionChoices = ""
    environmentChoices = "tst\nacc\nprd"
    streetChoices = "1\n2\n3\n4\n5\n6\n"
}
