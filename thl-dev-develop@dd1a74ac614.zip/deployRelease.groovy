@Library("GENERIC") _
pipelineDeployArtifactFromNexus_v1 {
    deploymentId = "iva-thl"
    integrationPipeline = "IVA-THL_test-Robot"
    packageChoices = "iva-thl\nas-iva-thl"
    applicationVersionChoices = "0.4.0\n0.3.0\n0.2.4\n0.2.3\n0.2.2"
    asVersionChoices = "n.v.t"
    environmentChoices = "tst\nacc\nprd"
    streetChoices = "str11\nstr12"
}
