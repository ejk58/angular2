import { Component } from '@angular/core';
import {initialMenuItems} from './app.menu';
import {ConfigurationService, FrameworkConfigSettings, MenuService} from 'iv-framework-lib';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {

  constructor(private readonly menuService: MenuService,
              private readonly configService: ConfigurationService) {
    const config: FrameworkConfigSettings = {
      applicationName: 'Toezicht Heffen Levering',
      useFeedback: true
    }
    configService.configure(config);

    menuService.items = initialMenuItems;
  }
}
