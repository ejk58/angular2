import {Feedback, FeedbackApi, VersionInformation} from 'iv-framework-lib';
import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {map} from 'rxjs/operators';
import {VerwerkingenService} from "./verwerkingen.service";

@Injectable()
export class FeedbackService implements FeedbackApi {

  constructor(private readonly httpClient: HttpClient,
              private readonly verwerkingenService: VerwerkingenService) {
  }

  addFeedback(feedback: Feedback): Observable<Feedback> {
    return of({naam: '', email: '', melding: '', pagina: ''});
  }
  getVersionInformation(): Observable<VersionInformation> {
    return this.verwerkingenService.getIsAliveInformation().pipe(
      map( i => {
        return {application: 'thl', version: i.version, buildNumber: i.buildNumber, buildTime: ''} as VersionInformation;
      })
    );
  }
}
