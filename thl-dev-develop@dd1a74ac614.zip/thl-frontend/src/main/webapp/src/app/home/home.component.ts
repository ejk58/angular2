import {Component, OnInit} from '@angular/core';
import {VerwerkingenService} from "../services/verwerkingen.service";
import {Verwerking} from "../interfaces/verwerking";
import {CountService} from "../services/count.service";

export interface CountVerwerkingenResponse {
  thlCount: string
}

export interface VerwerkingResponse {
  verwerkingen: Verwerking[]
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  title = 'Toezicht Heffen Levering';
  countVerwerkingenTotaal: CountVerwerkingenResponse | undefined;
  countVerwerkingenLastWeek: CountVerwerkingenResponse | undefined;
  countErrorMessages: number | undefined;
  countEventMessages: number | undefined ;
  countResponseMessages: number | undefined;

  constructor(private readonly verwerkingenService: VerwerkingenService,
              private readonly counts: CountService) {
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.getVerwerkingenFromBackend();
    this.getErrorMessageCount();
    this.getResponseMessageCount();
    this.getEventMessageCount();
  }

  private getErrorMessageCount() {
    this.counts.countErrorMessages()
      .subscribe(
        (data: any) => {
          this.countErrorMessages = +data.messageCount;
        },
        error => {
          console.log('error bij getErrorMessageCount', error);
        }, () => {
          console.log('done countErrorMessages');
        })
  }

  private getEventMessageCount() {
    this.counts.countEventMessages()
      .subscribe(
        (data: any) => {
          this.countEventMessages = +data.messageCount;
        },
        error => {
          console.log('error bij getEventMessageCount', error);
        }, () => {
          console.log('done getEventMessageCount');
        })
  }

  private getResponseMessageCount() {
    this.counts.countResponseMessages()
      .subscribe(
        (data: any) => {
          this.countResponseMessages = +data.messageCount;
        },
        error => {
          console.log('error bij getResponseMessageCount', error);
        }, () => {
          console.log('done getResponseMessageCount');
        })
  }

  private getVerwerkingenFromBackend() {
    this.verwerkingenService.count()
      .subscribe((data: CountVerwerkingenResponse) => {
          this.countVerwerkingenTotaal = data
        },
        error => {
          console.log('error bij getVerwerkingenFromBackend ', error);
        }, () => {
          console.log('done');
        });

    this.verwerkingenService.countLastWeek()
      .subscribe((data: CountVerwerkingenResponse) => {
          this.countVerwerkingenLastWeek = data
        },
        error => {
          console.log('error bij countLastWeek ', error);
        }, () => {
          console.log('done last week');
        });
  }


  countVerwerkingen(): string | undefined {
    return this.countVerwerkingenTotaal ? this.countVerwerkingenTotaal.thlCount : "loading.."
  }

  getNumberOfOperationsPerWeek(): string | undefined {
    return this.countVerwerkingenLastWeek ? this.countVerwerkingenLastWeek.thlCount : "loading.."
  }

  openVerwerkingen() {
    this.getVerwerkingenFromBackend();
  }
}
