package nl.belastingdienst.iva.wd.thl.webservice;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import nl.belastingdienst.iva.common.errorhandling.UserError;
import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.dao.OperationsDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.domain.Verwerking;
import nl.belastingdienst.iva.wd.thl.dto.VerwerkingDto;
import nl.belastingdienst.iva.wd.thl.mappings.VerwerkingMapper;
import nl.belastingdienst.iva.wd.thl.utls.HttpResponseHelper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Contact;
import io.swagger.annotations.Info;
import io.swagger.annotations.SwaggerDefinition;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Api()
@Path("/operations")
@SwaggerDefinition(
        info = @Info(
                title = "RestOperations",
                version = "V1",
                description = "REST OPS Service",
                contact = @Contact(
                        name = "Webdevelopment Team",
                        url = "https://devtools.belastingdienst.nl/confluence/display/CM/CoE+Webdevelopment+Home")
        ),
        consumes = MediaType.APPLICATION_JSON,
        produces = MediaType.APPLICATION_JSON,
        schemes = {
                SwaggerDefinition.Scheme.HTTPS,
                SwaggerDefinition.Scheme.HTTP
        }
)
public class OperationsService {

    @Inject
    private OperationsDao operationsDao;

    @Inject
    private VerwerkingMapper verwerkingMapper;

    @Inject
    private ThlDao thlDao;

    @Inject
    private BatDao batDao;

    @GET()
    @Path("/verwerkingen/count")
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Count number of Verwerkingen", response = OperationsResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
            @ApiResponse(code = 415, message = "Unsupported Media Type")
    })
    public Response getCountVerwerkingen() {
        try {
            OperationsResponse response = new OperationsResponse();
            response.setThlCount(this.thlDao.count());
            return Response.ok(response).build();
        } catch (Exception e) {
            return HttpResponseHelper.handleException(e);
        }
    }

    @GET()
    @Path("/verwerkingen/countLastWeek")
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Count number of Verwerkingen in last week", response = OperationsResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
            @ApiResponse(code = 415, message = "Unsupported Media Type")
    })
    public Response getCountLastWeekVerwerkingen() {
        try {
            OperationsResponse response = new OperationsResponse();
            response.setThlCount(this.thlDao.countLastWeek());
            return Response.ok(response).build();
        } catch (Exception e) {
            return HttpResponseHelper.handleException(e);
        }
    }

    @GET()
    @Path("/verwerkingen/")
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Find all Verwerkingen", response = VerwerkingenResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
            @ApiResponse(code = 415, message = "Unsupported Media Type")
    })
    public Response findAllVerwerkingen() {
        try {
            VerwerkingenResponse response = new VerwerkingenResponse();
            Date oneWeekAgo = java.sql.Date.valueOf(LocalDate.now().minusDays(7));
            List<Verwerking> verwerkingen = this.thlDao.findAll(oneWeekAgo);
            List<VerwerkingDto> verwerkingDtos = verwerkingMapper.map(verwerkingen);
            response.setVerwerkingen(verwerkingDtos);
            return Response.ok(response).build();
        } catch (Exception e) {
            return HttpResponseHelper.handleException(e);
        }
    }
}

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
class OperationsResponse {
    private String thlCount = "-1";
}

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
class VerwerkingenResponse {
    List<VerwerkingDto> verwerkingen;
}