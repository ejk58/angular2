package nl.belastingdienst.iva.wd.thl.dao;

import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lombok.extern.slf4j.Slf4j;

@Singleton
@Slf4j
public class OperationsDao {

    @PersistenceContext(unitName = "iva-thl-pu")
    private EntityManager em;

    public Integer countsVerwerkingen() {
        Integer aantal = 0;
        try {
            Query query = em.createNativeQuery("SELECT count(*) FROM VERWERKING;" );
            aantal = (Integer) query.getSingleResult();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return aantal;
    }

    public Integer countsVerwerkingenLastWeek() {
        Integer aantal = 0;
        try {
            Query query = em.createNativeQuery(
                    "SELECT count(*) FROM VERWERKING\n" +
                            "WHERE START  >= current_date - 7 DAY;");
            aantal = (Integer) query.getSingleResult();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return aantal;
    }

    public long executeIsAlive() {
        long now = System.currentTimeMillis();
        long dateOfStart = LocalDate.of(2021, Month.MARCH, 1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        return now - dateOfStart;
    }
}
