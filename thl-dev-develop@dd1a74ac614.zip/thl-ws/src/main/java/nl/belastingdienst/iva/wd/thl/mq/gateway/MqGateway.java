package nl.belastingdienst.iva.wd.thl.mq.gateway;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jms.Destination;

import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.thl.mq.MessageResponse;

@Stateless
@Slf4j
public class MqGateway {

	@Resource(name = "jms/iva-thl/opvoerenEventsRef")
	private Destination writeEventsQueue;

	@Resource(name = "jms/iva-thl/inlezenEventsRef")
	private Destination readEventsQueue;

	@Resource(name = "jms/iva-thl/inlezenErrorMessagesRef")
	private Destination readErrorQueue;

	@Resource(name = "jms/iva-thl/opvoerenErrorMessageRef")
	private Destination errorDestination;

	@Resource(name = "jms/iva-thl/opvoerenEventResponseRef")
	private Destination writeResponseEventsQueue;

	@Resource(name = "jms/iva-thl/inlezenEventResponseRef")
	private Destination readResponseEventsQueue;

	@Inject
	private GenericMessageGateway gateway;

	// TglEvents (MDB Input) Queue
	public MessageResponse getTglEventCount() {
		return gateway.getMessageCount(readEventsQueue);
	}

	public MessageResponse getTglEvent(String messageId) {
		return gateway.getMessage(messageId, readEventsQueue);
	}

	public MessageResponse clearTglEventQueue() {
		return gateway.clearQueue(readEventsQueue);
	}

	public void sendEvent(String correlationId, String event) {
		gateway.send(correlationId, event, writeEventsQueue);
	}

	// Error Queue
	public MessageResponse getErrorMessageCount() {
		return gateway.getMessageCount(readErrorQueue);
	}

	public MessageResponse getErrorMessage(String messageId) {
		return gateway.getMessage(messageId, readErrorQueue);
	}

	public void placeErrorMessageOnQueue(String event) { gateway.send( event, errorDestination); }

	public MessageResponse removeErrorMessage(String messageId) { return gateway.removeMessage(messageId, readErrorQueue); }

	public MessageResponse clearErrorQueue() {
		return gateway.clearQueue(readErrorQueue);
	}

	// Response (MDB Output) Queue
	public MessageResponse getResponseEventsCount() {
		return gateway.getMessageCount(readResponseEventsQueue);
	}

	public MessageResponse getResponseEvent(String messageId) {
		return gateway.getMessage(messageId, readResponseEventsQueue);
	}

	public MessageResponse removeResponseEvent(String messageId) {
		return gateway.removeMessage(messageId, readResponseEventsQueue);
	}

	public MessageResponse clearResponseEventQueue() {
		return gateway.clearQueue(readResponseEventsQueue);
	}

	public void sendResponse(String message) {
		log.debug("Sending response.");
		gateway.send(message, writeResponseEventsQueue);
		log.debug("Response has been sent.");
	}
}
