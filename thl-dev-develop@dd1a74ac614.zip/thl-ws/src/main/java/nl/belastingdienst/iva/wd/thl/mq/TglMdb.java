package nl.belastingdienst.iva.wd.thl.mq;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.ejb.MessageDriven;
import javax.inject.Inject;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import nl.belastingdienst.iva.common.errorhandling.MyConstraintViolation;
import nl.belastingdienst.iva.common.errorhandling.ValidationException;
import nl.belastingdienst.iva.common.logging.MattermostAppender;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.mq.gateway.GenericMessageGateway;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

import lombok.extern.slf4j.Slf4j;

/**
 * Message-Driven Bean implementation class for: TglMdb
 */

@Slf4j
@MessageDriven
public class TglMdb implements MessageListener {

	@Inject
	private MessageHandler messageHandler;

	@Inject
	private GenericMessageGateway messageGateway;

	@Resource(name = "jms/iva-thl/opvoerenEventResponseRef")
	private Destination responseDestination;

	@Resource(name = "jms/iva-thl/opvoerenErrorMessageRef")
	private Destination errorDestination;

	@Inject
	private ThlDao thlDao;

	private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/**
	 * Default constructor.
	 */
	public TglMdb() {
		super();
		log.debug("TglMdb initializing.");
	}

	/**
	 * @see MessageListener#onMessage(Message)
	 */
	@Override
	public void onMessage(Message message) {
		log.debug("Message received..");
		log.debug("Message type: " + message.getClass().getSimpleName());
		ProgressReporter reporter = new ProgressReporter(thlDao);
		try {
			String correlationId = message.getJMSCorrelationID();
			reporter.reportStart(correlationId);
			List<String> response = messageHandler.processMessage(getTextFromMessage(message), reporter);
			response.forEach( resp -> messageGateway.send(correlationId, resp, responseDestination));
		} catch (Exception e) {
			handleException(e, message, reporter);
		} finally {
			log.debug("Finished processing message.");
			reporter.reportEinde();
		}
	}

	private String getTextFromMessage(Message message) {
		if (message instanceof TextMessage) {
			try {
				return ((TextMessage) message).getText();
			} catch (JMSException e) {
				log.error("Problem reading text from message.", e);
				throw new IllegalMessageType("Message received is not a TextMessage");
			}
		}
		return null;
	}

	private void handleException(Exception e, Message message, ProgressReporter reporter) {
		String text = getTextFromMessage(message);
		ErrorMessage errorMessage = new ErrorMessage();
		errorMessage.setTextMessageReceived(text);
		errorMessage.setExceptionInfo(new ExceptionInfo(e));
		errorMessage.setTimestamp(sdf.format(new Date()));
		errorMessage.setId(UUID.randomUUID().toString().replace("-", ""));

		messageGateway.send(errorMessage, errorDestination);
		log.error("Exception processing message. Message stored in error queue using id '" + errorMessage.getId() + "'.", e);
		String chMessage = String.format("IVA-THL: Message stored on errorQueue. id: %s; problem: %s", errorMessage.getId(), getProblem(e));
		reporter.error(chMessage);
		log.error(MattermostAppender.marker, chMessage);
	}

	String getProblem(Throwable exceptionInfo) {
		String issue = null;
		String exceptMessage = null;
		while (exceptionInfo != null && issue == null) {
			exceptMessage = exceptionInfo.getMessage();
			if (exceptionInfo instanceof ValidationException) {
				ValidationException validationEx = (ValidationException) exceptionInfo;
				if (validationEx.getViolations() != null) {
					issue = getViolationsAsString(validationEx.getViolations());
				}
			}
			exceptionInfo = exceptionInfo.getCause();
		}
		if (issue == null) {
			issue = exceptMessage;
		}
		return issue;
	}

	private String getViolationsAsString(List<MyConstraintViolation> violations) {
		StringBuilder violationsTxt = new StringBuilder();
		for (MyConstraintViolation v : violations) {
			if (violationsTxt.length() == 0) {
				violationsTxt.append(",");
			}
			violationsTxt.append("[Message=\"").append(v.getMessage()).append("\",Property=\"").append(v.getProperty())
					.append("\"]");
		}
		return violationsTxt.toString();
	}
}
