/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: MessageIdentifier.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 26-5-2021 10:38
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.thl.mq;

import java.util.Arrays;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

/**
 * Corresponds to the ID's in thl-database\Liquibase\changesets\feature-message-handlers-*.sql
 */
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public enum MessageIdentifier {

	TGL_ABS01("TGL-ABS01"),
	TGL_VPB02("TGL-VPB02"),
	TGL_RSA03("TGL-RSA03"),
	TGL_ATK04("TGL-ATK04"),
	TGL_ATK05("TGL-ATK05"),
	TGL_VTC06("TGL-VTC06"),
	TGL_KWO07("TGL-KWO07"),
	UNKNOWN("Unknown");

	private final String id;

	public static MessageIdentifier fromId(String id) {
		return Arrays.stream(MessageIdentifier.values())
				.filter(e -> e.id.equals(id))
				.findFirst()
				.orElse(UNKNOWN);
	}

	@Override
	public String toString() {
		return id;
	}
}
