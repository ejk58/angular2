package nl.belastingdienst.iva.wd.thl.reporting;

import java.util.Date;
import java.util.List;

import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.domain.Problem;
import nl.belastingdienst.iva.wd.thl.domain.Verwerking;

public class ProgressReporter {

    private final ThlDao thlDao;

    private Verwerking verwerking;

    public ProgressReporter(ThlDao thlDao) {
        this.thlDao = thlDao;
    }

    public void reportStart(String correlationId) {
        verwerking = new Verwerking();
        verwerking.setStart(new Date());
        verwerking.setCorrelationId(correlationId);
    }

    public void error(String message) {
        Problem problem = new Problem();
        problem.setMoment(new Date());
        problem.setVerwerkingId(verwerking.getId());
        problem.setError(message);
        verwerking.addProblem(problem);
    }

    public void reportBadRecordLength(int recNumber) {
        verwerking.addBadRecordLengthError(recNumber);
    }

    public void reportBatchStart(String rec) {
        verwerking.setType(rec);
    }

    public void numberOfRequestRecords(int aantal) {
        verwerking.setAantalRequestRecords(aantal);
    }

    public void numberOfResponseRecords(int aantal) {
        verwerking.setAantalResponseRecords(aantal);
    }

    public void reportEinde() {
        verwerking.setEinde(new Date());
        thlDao.save(verwerking);
    }

    public List<Problem> getProblems() {
        return verwerking.getProblems();
    }
}

