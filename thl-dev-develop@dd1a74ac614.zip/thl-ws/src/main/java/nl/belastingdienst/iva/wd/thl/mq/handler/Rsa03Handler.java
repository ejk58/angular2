package nl.belastingdienst.iva.wd.thl.mq.handler;

import java.time.LocalDate;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

public class Rsa03Handler  extends AbstractHandler {

	static final int REQUEST_RECORD_LENGTH = 9;
	static final int ANSWER_RECORD_LENGTH = 270;
	static final int MAX_NUMBER_OF_RECORDS_PER_MESSAGE = 10_000;

	@Inject
	private BatDao batdao;

	@Override
	public List<String> getData(List<String> records, ProgressReporter reporter, String lineEnding) {
		List<StringBuilder> result = new LinkedList<>();
		StringBuilder sb = new StringBuilder();
		addVoorloopRecord(sb, records.get(0), reporter, 1);
		sb.append(lineEnding);

		Date mutatieDatum = java.sql.Date.valueOf(LocalDate.of(LocalDate.now().getYear() - 10,1,1));
		List<String> batChanges = batdao.getVpbChangesForRsaSince(mutatieDatum);
		processData(batChanges, result, sb, reporter, records.get(0), lineEnding);
		return resultWithMaxVolgnummers(result);
	}

	@Override
	void setErrorCodeToZero(StringBuilder sb) {
		setErrorCodeToZero(sb, 15, 16);
	}

	@Override
	public int getAnswerRecordLength() {
		return ANSWER_RECORD_LENGTH;
	}

	@Override
	int getRequestRecordLength() {
		return REQUEST_RECORD_LENGTH;
	}

	@Override
	public int getMaxNumberOfRecordPerMessage(){
		return Math.min(super.getMaxNumberOfRecordPerMessage(), MAX_NUMBER_OF_RECORDS_PER_MESSAGE);
	}
}
