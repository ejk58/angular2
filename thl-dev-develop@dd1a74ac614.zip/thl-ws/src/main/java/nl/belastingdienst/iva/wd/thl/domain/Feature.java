package nl.belastingdienst.iva.wd.thl.domain;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Entity
@Table(name = "FEATURE")
@Slf4j
@RequiredArgsConstructor
@Getter
@Setter
@ToString
public class Feature {

	@Id
	@Column(name = "NAME")
	private String name;

	@Column(name = "ENABLED_SINCE_TS")
	private Date enabledSince;

	@Column(name = "DESCRIPTION", nullable = false)
	private String description;

	public void toggle() {
		setEnabledSince(getEnabledSince() == null ? new Date() : null);
	}

	public boolean isEnabled() {
		return getEnabledSince() != null && !getEnabledSince().after(new Date());
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		Feature feature = (Feature) o;

		if (!name.equals(feature.name))
			return false;
		if (!Objects.equals(enabledSince, feature.enabledSince))
			return false;
		return description.equals(feature.description);
	}

	@Override
	public int hashCode() {
		int result = name.hashCode();
		result = 31 * result + (enabledSince != null ? enabledSince.hashCode() : 0);
		result = 31 * result + description.hashCode();
		return result;
	}
}
