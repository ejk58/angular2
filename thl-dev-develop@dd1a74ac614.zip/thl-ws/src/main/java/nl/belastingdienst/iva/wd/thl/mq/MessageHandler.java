package nl.belastingdienst.iva.wd.thl.mq;

import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.inject.Inject;

import nl.belastingdienst.iva.wd.thl.mq.handler.Abs01Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.AbstractHandler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Atk04Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Atk05Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Kwo07Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Rsa03Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Vpb02Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Vtc06Handler;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;
import nl.belastingdienst.iva.wd.thl.webservice.FeatureService;

@Singleton
public class MessageHandler {

    public static final String ERROR_CODE_BAD_VOORLOOPRECORD = "99";
    /**
     * Corresponds to the prefix in thl-database\Liquibase\changesets\feature-message-handlers-*.sql
     */
    public static final String FEATURE_PREFIX = "MESSAGE-HANDLER_";

    @Inject
    private FeatureService featureService;
    @Inject
    private Abs01Handler abs01Handler;
    @Inject
    private Vpb02Handler vpb02Handler;
    @Inject
    private Rsa03Handler rsa03Handler;
    @Inject
    private Atk04Handler atk04Handler;
    @Inject
    private Atk05Handler atk05Handler;
    @Inject
    private Vtc06Handler vtc06Handler;
    @Inject
    private Kwo07Handler kwo07Handler;

    final Map<MessageIdentifier, AbstractHandler> messageHandlers = new EnumMap<>(MessageIdentifier.class);

    @PostConstruct
    public void initialize() {
        messageHandlers.put(MessageIdentifier.TGL_ABS01, abs01Handler);
        messageHandlers.put(MessageIdentifier.TGL_VPB02, vpb02Handler);
        messageHandlers.put(MessageIdentifier.TGL_RSA03, rsa03Handler);
        messageHandlers.put(MessageIdentifier.TGL_ATK04, atk04Handler);
        messageHandlers.put(MessageIdentifier.TGL_ATK05, atk05Handler);
        messageHandlers.put(MessageIdentifier.TGL_VTC06, vtc06Handler);
        messageHandlers.put(MessageIdentifier.TGL_KWO07, kwo07Handler);
    }

    public List<String> processMessage(String textFromMessage, ProgressReporter reporter) {
        if (textFromMessage == null || textFromMessage.isEmpty()) {
            reporter.error("Empty message received!! Abort");
            return Collections.singletonList("");
        }
        String lineEnding = "\n";
        if (textFromMessage.contains("\r\n")) {
            lineEnding = "\r\n";
        }
        List<String> records = Arrays.stream(textFromMessage.split(lineEnding)).collect(Collectors.toList());
        reporter.numberOfRequestRecords(records.size());
        if (records.get(0).length() < 9) {
            reporter.error("BatchId received is too small: " + records.get(0).trim());
            return Collections.singletonList(createBadHeaderResponse(records, lineEnding));
        }
        String identifierPart = records.get(0).substring(0, 9);
        reporter.reportBatchStart(identifierPart);

        MessageIdentifier msgId = MessageIdentifier.fromId(identifierPart);
        AbstractHandler msgHandler = messageHandlers.get(msgId);
        if (msgHandler == null || !featureService.isFeatureEnabled(FEATURE_PREFIX + msgId)) {
            reporter.error("Bad batchId received: " + identifierPart);
            return Collections.singletonList(createBadHeaderResponse(records, lineEnding));
        }

        return msgHandler.getData(records, reporter, lineEnding);
    }

    String createBadHeaderResponse(List<String> records, String lineEnding) {
        String batchId = String.format("%-9.9s", records.get(0));
        StringBuilder returnMessage = new StringBuilder(batchId + ERROR_CODE_BAD_VOORLOOPRECORD);
        if (records.get(0).length() > 11) {
            returnMessage.append(records.get(0).substring(11));
        }
        returnMessage.append(lineEnding);
        for(int teller = 1; teller < records.size(); teller++) {
            returnMessage.append(records.get(teller));
            returnMessage.append(lineEnding);
        }
        return returnMessage.toString();
    }
}
