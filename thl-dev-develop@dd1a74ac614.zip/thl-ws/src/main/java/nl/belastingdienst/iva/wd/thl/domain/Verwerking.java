package nl.belastingdienst.iva.wd.thl.domain;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@ToString
@Entity(name = "VERWERKING")
public class Verwerking {

    private static final int CORRELATION_ID_MAX_LENGTH = 100;
    private static final int REQUEST_TYPE_MAX_LENGTH = 15;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Version
    @Column(name = "VERSION")
    @Getter(value=AccessLevel.PRIVATE)
    @Setter(value= AccessLevel.PRIVATE)
    private Integer version;

    @Column(name = "CORRELATION_ID")
    private String correlationId;

    @Column(name = "START")
    @Temporal(TemporalType.TIMESTAMP)
    private Date start;

    @Column(name = "EIND")
    @Temporal(TemporalType.TIMESTAMP)
    private Date einde;

    @Column(name = "REQUEST_TYPE")
    private String type;

    @Column(name = "AANTAL_REC_REQ")
    private Integer aantalRequestRecords;

    @Column(name = "AANTAL_REC_RESP")
    private Integer aantalResponseRecords;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name="VERWERKING_ID")
    @OrderBy("moment DESC")
    List<Problem> problems;

    @Transient
    private Problem recordToLong = null;

    public void addProblem(Problem problem) {
        if (problems == null) {
            problems = new LinkedList<>();
        }
        problems.add(problem);
    }
    public void setCorrelationId(String correlationId) {
        String tempCorrelationId = correlationId;
        if (tempCorrelationId != null && tempCorrelationId.length() > CORRELATION_ID_MAX_LENGTH) {
            log.error("correlationId in verwerking is te lang (" + tempCorrelationId + "). Max Lengte is " + CORRELATION_ID_MAX_LENGTH);
            tempCorrelationId = tempCorrelationId.substring(0, CORRELATION_ID_MAX_LENGTH);
        }
        this.correlationId = tempCorrelationId;
    }

    public void setType(String type) {
        String tempType = type;
        if (tempType != null && tempType.length() > REQUEST_TYPE_MAX_LENGTH) {
            log.error("type in verwerking is te lang (" + tempType + "). Max Lengte is " + REQUEST_TYPE_MAX_LENGTH);
            tempType = tempType.substring(0, REQUEST_TYPE_MAX_LENGTH);
        }
        this.type = tempType;
    }

    public void addBadRecordLengthError(int recNumber) {
        if (recordToLong == null) {
            recordToLong = new Problem();
            recordToLong.setMoment(new Date());
            recordToLong.setVerwerkingId(this.getId());
            recordToLong.setError("Recordlength not correct: ");
            this.addProblem(recordToLong);
        }
        if (recordToLong.getError().length() < 100) {
            recordToLong.setError(recordToLong.getError() + recNumber + ", ");
        }
    }
}
