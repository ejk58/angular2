package nl.belastingdienst.iva.wd.thl.mappings;

import java.util.List;

import org.mapstruct.Mapper;

import nl.belastingdienst.iva.wd.thl.domain.Verwerking;
import nl.belastingdienst.iva.wd.thl.dto.VerwerkingDto;

@Mapper(componentModel = "cdi")
public interface VerwerkingMapper {

	VerwerkingDto map(Verwerking dto);

	List<VerwerkingDto> map(List<Verwerking> dtoList);
}
