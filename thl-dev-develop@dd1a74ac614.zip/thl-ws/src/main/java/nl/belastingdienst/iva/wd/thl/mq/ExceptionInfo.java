package nl.belastingdienst.iva.wd.thl.mq;

import lombok.Data;
import nl.belastingdienst.iva.common.errorhandling.MyConstraintViolation;
import nl.belastingdienst.iva.common.errorhandling.ValidationException;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * This class is used to get meaning full information from an exception that can be put into an MQ-ErrorMessage.
 * 
 * @author weera09
 */
@Data
public class ExceptionInfo {

	private String message;
	private String exceptionType;
	private String[] stackTrace;
	private ExceptionInfo cause;
	private List<MyConstraintViolation> violations;
	private Map<Integer, List<MyConstraintViolation>> violationsMap;

	public ExceptionInfo(Throwable e) {
		this.setMessage(e.getMessage());
		this.setExceptionType(e.getClass().getName());
		this.setStackTrace(getShortStacktrace(e.getStackTrace()));
		if (e.getCause() != null) {
			this.setCause(new ExceptionInfo(e.getCause()));
		}
		if (e instanceof ValidationException) {
			switch (((ValidationException) e).getType()) {
			case VIOLATIONS:
				this.setViolations(((ValidationException) e).getViolations());
				break;
			case PERTYPE:
				this.setViolationsMap(((ValidationException) e).getViolationMap());
				break;
			default:
				break;
			}
		}
	}

	private String[] getShortStacktrace(StackTraceElement[] stackTrace) {
		List<String> trace = new LinkedList<>();
		int nlBelastingdienstLinecount = 0;
		for (StackTraceElement element : stackTrace) {
			if (element.getClassName().startsWith("nl.belastingdienst")) {
				trace.add(element.toString());
				if (++nlBelastingdienstLinecount > 3) {
					break;
				}
			}
		}
		return trace.toArray(new String[0]);
	}
}
