package nl.belastingdienst.iva.wd.thl.dao;

import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.spaces;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lombok.extern.slf4j.Slf4j;

@Singleton
@Slf4j
public class BatDao {

    private String currentSchema;

    @PersistenceContext(unitName = "iva-bat-pu")
    EntityManager em;
    private static final String DATE_FORMAT = "yyyy-MM-dd";
    private static final String DATE_FOR_RECORD = "yyyyMMdd";
    private final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT);
    private final SimpleDateFormat dateForRecordDateFormat = new SimpleDateFormat(DATE_FOR_RECORD);

    private static final String NULL_RESULT = "00000000";

    public boolean existsBehandelvoorstel(Integer bsn, Integer belastingjaar, String middel) {
        Integer aantal = 0;
        if ("IB".equalsIgnoreCase(middel)) {
            // IVATHL-77 BAT database using middel IH there where ABS using IB
            middel = "IH";
        }
        try {
            Query query = em.createNativeQuery(
                    "SELECT count(id) " +
                            "FROM BEHANDELVOORNEMEN_ACTIEF " +
                            "WHERE BSN_RSIN = ?1 " +
                            "AND JAAR = ?2 " +
                            "AND MIDDEL = ?3 ");
            query.setParameter(1, bsn);
            query.setParameter(2, belastingjaar);
            query.setParameter(3, middel);
            aantal = (Integer) query.getSingleResult();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        if (aantal > 1) {
            log.warn("Meer dan 1 behandelvoornemen gevonden voor {}, jaar: {}, middel: {}", bsn, belastingjaar, middel);
        }
        return aantal > 0;
    }

    public long executeIsAliveCheck() {
        long start = System.currentTimeMillis();
        try {
            Query query = em.createNativeQuery("select * from BEHANDELVOORNEMEN_ACTIEF fetch first 2 rows only");
            query.getResultList();
        } catch (Exception e) {
            return -1;
        }
        return System.currentTimeMillis() - start;
    }

    public List<String> getVpbChangesSince(Date vanafDatum) {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        List<String> result = Collections.emptyList();
        try {
            Query query = em.createNativeQuery(
                    "select BSN_RSIN, JAAR, '03', DT_AANGEMAAKT, DT_GEWIJZIGD, cast(null as TIMESTAMP) \n" +
                            "from BEHANDELVOORNEMEN_ACTIEF \n" +
                            "where middel='VPB' and (DT_AANGEMAAKT > ?1 OR DT_GEWIJZIGD > ?1) AND JAAR <= ?2 \n" +
                            "union \n" +
                            "select BSN_RSIN, JAAR, '03', DT_AANGEMAAKT, DT_GEWIJZIGD, DT_INGETROKKEN \n" +
                            "from BEHANDELVOORNEMEN_INGETROKKEN \n" +
                            "where middel='VPB' and (DT_INGETROKKEN > ?1 ) AND JAAR <= ?2 \n" +
                            "order by BSN_RSIN, jaar");
            query.setParameter(1, simpleDateFormat.format(vanafDatum));
            query.setParameter(2, currentYear);
            List<Object[]> changes = query.getResultList();
            List<String> processedChanges = new LinkedList<>();
            for (Object[] change : changes) {
                processedChanges.add(processVpb02Change(change));
            }
            result = processedChanges;

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    private String processVpb02Change(Object[] change) {
        // TIMESTAMP_DATE_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss")
        return String.format("%09d%4d%s%s"
                , change[0]
                , change[1]
                , change[2]
//                , TIMESTAMP_DATE_FORMAT.format(change[4] == null ? change[3] : change[4])   // IVATHL-67
                , change[5] == null ? NULL_RESULT : dateForRecordDateFormat.format(change[5]));
    }

    public List<String> getVpbChangesForRsaSince(Date vanafDatum) {
        List<String> result = Collections.emptyList();
        try {
            Query query = em.createNativeQuery(
                    "select BSN_RSIN, JAAR, '03', TOELICHTING \n" +
                            "from BEHANDELVOORNEMEN_ACTIEF \n" +
                            "where middel='VPB' and DT_AANGEMAAKT >= ?1 \n" +
                            "order by BSN_RSIN, jaar");
            query.setParameter(1, simpleDateFormat.format(vanafDatum));
            List<Object[]> changes = query.getResultList();
            List<String> processedChanges = new LinkedList<>();
            for (Object[] change : changes) {
                processedChanges.add(processVpbRsa03Change(change));
            }
            result = processedChanges;

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    private String processVpbRsa03Change(Object[] objs) {
        truncateToelichtingTo255Chars(objs, 3);
        return String.format("%09d%4d%2s%-255s"
                , objs[0]
                , objs[1]
                , objs[2]
                , objs[3] == null ? " " : objs[3]);
    }

    public List<String> getChangesForAtk04(Date since) {
        List<String> result = Collections.emptyList();
        String queryString = "select BSN_RSIN, 0, JAAR, MIDDEL ,'03', cast(null as TIMESTAMP), TOELICHTING " +
                "from BEHANDELVOORNEMEN_ACTIEF " +
                "where middel in ('VPB','IH') and ( DT_AANGEMAAKT > ?1 or DT_GEWIJZIGD > ?1 ) " +
                "union " +
                "select BSN_RSIN, 0, JAAR, MIDDEL, '03', DT_INGETROKKEN, REDEN_INGETROKKEN " +
                "from BEHANDELVOORNEMEN_INGETROKKEN " +
                "where middel in ('VPB','IH') and ( DT_INGETROKKEN > ?1 )  " +
                "order by BSN_RSIN, jaar ";
        try {
            Query query = em.createNativeQuery(queryString);
            query.setParameter(1, simpleDateFormat.format(since));
            List<Object[]> changes = query.getResultList();
            List<String> processedChanges = new LinkedList<>();
            for (Object[] change : changes) {
                processedChanges.add(processAtk04Change(change));
            }
            result = processedChanges;

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    private void replaceMiddelIhWithIb(Object[] objs) {
        if (objs[3] != null && ((String) objs[3]).equalsIgnoreCase("IH")) {
            objs[3] = "IB";
        }
    }

    private void truncateToelichtingTo255Chars(Object[] objs, int i) {
        if (objs[i] != null && ((String) objs[i]).length() > 255) {
            objs[i] = ((String) objs[i]).substring(0, 255);
        }
    }

    private String processAtk04Change(Object[] objs) {
        replaceMiddelIhWithIb(objs);
        truncateToelichtingTo255Chars(objs, 6);

        return String.format("%09d%02d%04d%s%s%s%s"
                , objs[0]                                                                   // bsnrsin n9
                , objs[1]                                                                   // subnummer n2
                , objs[2]                                                                   // bel jaar n4
                , objs[3] != null ? String.format("%-3s", objs[3]) : spaces(3)       // middel c3
                , objs[4] != null ? String.format("%-2s", objs[4]) : spaces(2)       // beh wijze c2
                , objs[5] != null ? String.format("%-8s", dateForRecordDateFormat.format(objs[5])) : spaces(8)       // ingetrokken c8
                , objs[6] != null ? String.format("%-255s", objs[6]) : spaces(255)); // toelichting c255
    }

    public List<String> getCorrectiesAndSpecificatiesOfLast6YearsForVtc06() {
        List<String> result = Collections.emptyList();
        try {
            List<Object[]> correcties = em.createNativeQuery("CALL "+getCurrentSchema()+".GET_CORRECTIES()").getResultList();
            List<Object[]> specificaties = em.createNativeQuery("CALL "+getCurrentSchema()+".GET_SPECIFICATIES()").getResultList();

            List<String> processedChanges = correcties.stream().map(this::processVtc06Correctie).collect(Collectors.toList());
            processedChanges.addAll(specificaties.stream().map(this::processVtc06Specificatie).collect(Collectors.toList()));
            result = processedChanges;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    private String processVtc06Correctie(Object[] correctie) {
        return String.format("%09d%4s%-32s%010d%017d%017d%15s",
                correctie[0], // BSNRSIN
                correctie[1], // JAAR
                correctie[2], // MIDDEL
                correctie[3], // VOLGNUMMER (actually CORRECTIE_ID)
                correctie[4], // AANGEGEVEN_BEDRAG
                correctie[5], // VASTGESTELD_BEDRAG
                ""            // Filler
        );
    }

    private String processVtc06Specificatie(Object[] specificatie) {
        return String.format("%09d%4s%-32s%010d%-32s%017d",
                specificatie[0], // BSNRSIN
                specificatie[1], // JAAR
                specificatie[2], // MIDDEL
                specificatie[3], // VOLGNUMMER (actually CORRECTIE_ID)
                specificatie[4], // (SPECIFICATIE_)CODE
                specificatie[5]  // (SPECIFICATIE_)BEDRAG
        );
    }

    public List<String> getKwaliteitsbeoordelingenLast6YearsForKwo07() {
        List<String> result = Collections.emptyList();

        try {
            Query query = em.createNativeQuery("CALL "+getCurrentSchema()+".GET_KWALITEITSOORDELEN()");
            List<Object[]> changes = query.getResultList();

            List<String> processedChanges = new LinkedList<>();
            for (Object[] change : changes) {
                processedChanges.add(processKwo07Change(change));
            }
            result = processedChanges;

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;

    }

    private String processKwo07Change(Object[] objs) {
        return String.format("%09d%s%2s",
                objs[0],                                                                        // rsin
                objs[1] == null ? NULL_RESULT : dateForRecordDateFormat.format(objs[1]),        // datum
                objs[2]                                                                         // kwaliteitsoordeelcode
        );
    }

    public String getCurrentSchema() {
        if (currentSchema == null) {
            Query query = em.createNativeQuery("values current schema");
            currentSchema = (String) query.getSingleResult();
            log.debug("Current schema is {}", currentSchema);
        }
        return currentSchema;
    }
}