package nl.belastingdienst.iva.wd.thl.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Entity(name = "PROBLEM")
public class Problem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Version
    @Column(name = "VERSION")
    @Getter(value= AccessLevel.PRIVATE)
    @Setter(value= AccessLevel.PRIVATE)
    private Integer version;

    @Column(name = "VERWERKING_ID")
    private Long verwerkingId;

    @Column(name = "MOMENT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date moment;

    @Column(name = "ERROR")
    private String error;
}

