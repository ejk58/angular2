package nl.belastingdienst.iva.wd.thl.webservice;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import nl.belastingdienst.iva.common.errorhandling.UserError;
import nl.belastingdienst.iva.wd.thl.domain.Feature;
import nl.belastingdienst.iva.wd.thl.utls.HttpResponseHelper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Contact;
import io.swagger.annotations.Info;
import io.swagger.annotations.SwaggerDefinition;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Api
@Path("/features")
// TODO IVATHL-58: @RolesAllowed({"ivad.operations"})
@SwaggerDefinition(
		info = @Info(
				title = "RestFeatures",
				version = "V1",
				description = "RESTful feature toggle service, indicates which feature toggles are enabled",
				contact = @Contact(
						name = "Webdevelopment Team",
						url = "https://devtools.belastingdienst.nl/confluence/display/CM/CoE+Webdevelopment+Home"
				)
		),
		consumes = MediaType.APPLICATION_JSON,
		produces = MediaType.APPLICATION_JSON,
		schemes = {
				SwaggerDefinition.Scheme.HTTP,
				SwaggerDefinition.Scheme.HTTPS
		}
)
public class RestFeatureService {

	@Inject
	private FeatureService service;

	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Retrieves a List of all Features", response = Feature.class, responseContainer = "List")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 415, message = "Unsupported Media Type")
	})
	public Response findAll() {
		try {
			List<Feature> features = this.service.findAll();
			return Response.ok(features).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@GET
	@Path("/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Checks if a Feature is enabled", response = Boolean.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"), @ApiResponse(code = 403, message = "No permission")
	})
	// TODO IVATHL-58: @PermitAll
	public Response isFeatureEnabled(
			@ApiParam(value = "The name of the Feature", example = "MESSAGE-HANDLER_TGL-RSA03") @PathParam("name") String name) {
		boolean isEnabled;
		try {
			isEnabled = this.service.isFeatureEnabled(name);
		} catch (Exception e) {
			log.warn("Unable to check if feature is enabled: " + name, e);
			isEnabled = false;
		}
		return Response.ok(isEnabled).build();
	}

	@GET
	@Path("/{name}/toggle")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Toggles a Feature on or off by its name and returns a List of all Features", response = Feature.class, responseContainer = "List")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"), @ApiResponse(code = 403, message = "No permission")
	})
	public Response toggleByName(
			@ApiParam(value = "The name of the Feature", example = "MESSAGE-HANDLER_TGL-RSA03") @PathParam("name") String name) {
		try {
			this.service.toggleByName(name);
			return findAll();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}
}