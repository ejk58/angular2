package nl.belastingdienst.iva.wd.thl.dao;

import java.util.Date;
import java.util.List;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import nl.belastingdienst.iva.wd.thl.domain.Verwerking;

import lombok.extern.slf4j.Slf4j;

@Singleton
@Slf4j
public class ThlDao {

    @PersistenceContext(unitName = "iva-thl-pu")
    private EntityManager em;

    public Verwerking save(Verwerking verwerking) {
        em.persist(verwerking);
        return verwerking;
    }

    public long executeIsAliveCheck() {
        long start = System.currentTimeMillis();
        em.find(Verwerking.class, 1L);
        return System.currentTimeMillis() - start;
    }

    public List<Verwerking> findAll(Date oneWeekAgo) {
        TypedQuery<Verwerking> query = em.createQuery("select v from VERWERKING v " +
                "where v.start >= ?1 ", Verwerking.class);
        return query.setParameter(1, oneWeekAgo).getResultList();
    }

    public String count() {
        return em.createNativeQuery("select count(*) from  Verwerking").getSingleResult().toString();
    }

    public String countLastWeek() {
        return em
                .createNativeQuery("select count(*) from  Verwerking WHERE START > current date - 7 days")
                .getSingleResult().toString();
    }
}
