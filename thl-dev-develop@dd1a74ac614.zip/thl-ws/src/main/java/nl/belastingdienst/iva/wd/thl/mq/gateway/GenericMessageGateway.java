package nl.belastingdienst.iva.wd.thl.mq.gateway;

import java.util.Enumeration;
import java.util.UUID;

import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.EJBException;
import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.common.errorhandling.CommonException;
import nl.belastingdienst.iva.wd.thl.mq.ErrorMessage;
import nl.belastingdienst.iva.wd.thl.mq.ExceptionInfo;
import nl.belastingdienst.iva.wd.thl.mq.MessageResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * Generieke gateway voor het verzenden en ontvangen van berichten.
 *
 * @author wittm06
 */
@Slf4j
@Singleton
public class GenericMessageGateway {

	private static final String PROBLEM_FETCHING_MESSAGE_IDS_FROM_QUEUE = "Problem fetching messageIds from queue.";

	@Resource(name = "jms/iva-thl/qcfRef")
	private ConnectionFactory connectionFactory;

	public GenericMessageGateway() {
		log.info("{}", "Constructor");
	}

	@PreDestroy
	public void teardown() {
		log.info("{}", "PreDestroy");
	}

	public void send(String messageTxt, Destination destination) {
			send(null, messageTxt, destination);
	}

	public void send(String correlationId, String messageTxt, Destination destination) {
		log.info("{}", "Start: send Text");
		Session session = null;
		Connection connection = null;
		try {
			connection = connectionFactory.createConnection();
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			Message message = session.createTextMessage(messageTxt);
			if (correlationId != null) {
				message.setJMSCorrelationID(correlationId);
			}
			sendTextMessage(session, message, destination);
		} catch (JMSException e) {
			log.error("GenericMessageGateway: send signaalWrapper: Exception: {}", e.getMessage());
			// Conform : JSR 318: Enterprise JavaBeans
			// 14.2.2 System Exceptions
			// If the bean method performs an operation that results in a checked exception[76]
			// that the bean method cannot recover,
			// the bean method should throw the javax.ejb.EJBException that wraps the original
			// exception.
			throw new EJBException(e);
		} finally {
			closeConnections(session, connection);
		}
		log.info("{}", "End: send Text");
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void send(ErrorMessage errorMessage, Destination errorDestination) {
		log.info("{}", "Start: send errorMessage");
		Session session = null;
		Connection connection = null;
		try {
			connection = connectionFactory.createConnection();
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			ObjectMapper mapper = new ObjectMapper();
			String jsonObjectString = mapper.writeValueAsString(errorMessage);
			Message message = session.createTextMessage(jsonObjectString);
			message.setJMSCorrelationID(UUID.randomUUID().toString());
			sendTextMessage(session, message, errorDestination);
		} catch (JMSException | CommonException | JsonProcessingException e) {
			log.error("GenericMessageGateway: send errorMessage: Exception: {}", e.getMessage());
			// Conform : JSR 318: Enterprise JavaBeans
			// 14.2.2 System Exceptions
			// If the bean method performs an operation that results in a checked exception[76]
			// that the bean method cannot recover,
			// the bean method should throw the javax.ejb.EJBException that wraps the original
			// exception.
			throw new EJBException(e);
		} finally {
			closeConnections(session, connection);
		}
		log.info("{}", "End: send errorMessage");
	}

	private void sendTextMessage(Session session, Message message, Destination destination) throws JMSException {
		MessageProducer producer = session.createProducer(destination);
		log.debug("send: start sending: {}", message);
		producer.send(message);
		log.debug("{}", "send: message is send");
		producer.close();
	}

	/**
	 * Maak een queue leeg door alle objecten synchroon te ontvangen (maar wacht er niet op).
	 *
	 * Het heeft niet de voorkeur om synchroon berichten te ontvangen, maar is wel toegestaan. Aanbevolen wordt om berichten
	 * asynchroon te ontvangen via een MessageDrivenBean om te voorkomen dat een SLSB eeuwig blijft wachten op een bericht.
	 */
	public void purge(Destination destination) {
		log.info("{}", "Start: purge");
		Connection connection = null;
		Session session = null;
		MessageConsumer consumer = null;
		try {
			connection = connectionFactory.createConnection();
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(destination);
			connection.start();
			log.debug("{}", "purge: start receiving");
			// receiveNoWait: wacht niet op een bericht omdat deze SLSB dan eeuwig zou kunnen
			// blijven wachten als er geen berichten binnen komen.
			//noinspection StatementWithEmptyBody
			while (consumer.receiveNoWait() != null) {
				// Geen actie: maak alleen de queue leeg.
			}
			log.debug("{}", "purge: end receiving");
		} catch (JMSException jmsException) {
			log.error("GenericMessageGateway: purge: jmsException: {}", jmsException.getMessage());
			// Conform : JSR 318: Enterprise JavaBeans
			// 14.2.2 System Exceptions
			// If the bean method performs an operation that results in a checked exception[76]
			// that the bean method cannot recover,
			// the bean method should throw the javax.ejb.EJBException that wraps the original
			// exception.
			throw new EJBException(jmsException);
		} finally {
			closeConnections(consumer, session, connection);
		}
		log.info("{}", "End: purge");
	}

	public MessageResponse getMessageCount(Destination destination) {
		log.info("{}", "Start: getMessageCount");
		Connection connection = null;
		Session session = null;
		QueueBrowser browser = null;
		MessageResponse messageIdsResponse = new MessageResponse("Get number of messages and their Id's from queue");
		messageIdsResponse.setMessageCount(-1);
		try {
			connection = connectionFactory.createConnection();
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			browser = session.createBrowser((Queue) destination);
			messageIdsResponse.setMessageCount(0);
			Enumeration<?> messageEnumeration = browser.getEnumeration();
			while (messageEnumeration.hasMoreElements()) {
				messageIdsResponse.setMessageCount(messageIdsResponse.getMessageCount() + 1);
				Message message = (Message) messageEnumeration.nextElement();
				messageIdsResponse.addMessageId(message.getJMSMessageID());
			}
		} catch (JMSException e) {
			messageIdsResponse.setErrorMessage("Problem counting number of messages on queue.");
			messageIdsResponse.setExceptionInformation(new ExceptionInfo(e));
			log.warn("Problem counting number of messages on queue.", e);
		} finally {
			closeConnections(browser, session, connection);
		}
		log.info("{}", "End: getMessageCount");
		return messageIdsResponse;
	}

	public MessageResponse clearQueue(Destination destination) {
		log.info("{}", "Start: clearQueue");
		MessageResponse messageResponse = new MessageResponse("Removing all messages from queue");
		Connection connection = null;
		Session session = null;
		MessageConsumer consumer = null;
		try {
			connection = connectionFactory.createConnection();
			messageResponse.setJmsDestination(getDestinationName(destination));
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(destination);
			connection.start();
			log.debug("{}", "purge: start receiving");
			messageResponse.setMessageCount(0);
			// receiveNoWait: wacht niet op een bericht omdat deze SLSB dan eeuwig zou kunnen
			// blijven wachten als er geen berichten binnen komen.
			while (consumer.receiveNoWait() != null) {
				messageResponse.setMessageCount(messageResponse.getMessageCount() + 1);
			}
		} catch (JMSException e) {
			messageResponse.setErrorMessage("Problem cleaning queue.");
			messageResponse.setExceptionInformation(new ExceptionInfo(e));
			log.warn("Problem cleaning queue.", e);
		} finally {
			closeConnections(consumer, session, connection);
		}
		log.info("{}", "End: clearQueue");
		return messageResponse;
	}

	public MessageResponse getMessage(String messageId, Destination destination) {
		log.info("{}", "Start: getMessage");
		Session session = null;
		QueueBrowser browser = null;
		Connection connection = null;
		MessageResponse messageResponse = new MessageResponse("Get message with Id '" + messageId + "' from queue.");

		messageResponse.setMessageCount(-1);
		try {
			connection = connectionFactory.createConnection();
			messageResponse.setJmsDestination(((Queue) destination).getQueueName());
			messageResponse.setMessageCount(0);
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			browser = session.createBrowser((Queue) destination);
			attemptToFindMessage(messageId, messageResponse, browser.getEnumeration());
			if (messageResponse.getMessageCount() < 1) {
				messageResponse.setErrorMessage("No message found with id '" + messageId + "'.");
			}
		} catch (JMSException e) {
			messageResponse.setErrorMessage(PROBLEM_FETCHING_MESSAGE_IDS_FROM_QUEUE);
			messageResponse.setExceptionInformation(new ExceptionInfo(e));
			log.warn(PROBLEM_FETCHING_MESSAGE_IDS_FROM_QUEUE, e);
		} finally {
			closeConnections(browser, session, connection);
		}

		log.info("{}", "End: getMessage");
		return messageResponse;
	}

	private void attemptToFindMessage(String messageId, MessageResponse messageResponse, Enumeration<?> messageEnumeration)
			throws JMSException {
		while (messageEnumeration.hasMoreElements()) {
			Message message = (Message) messageEnumeration.nextElement();
			if (message.getJMSMessageID().equals(messageId)) {
				messageResponse.setMessageCount(1);
				addMessageDataToResponse(messageResponse, message);
				log.error("{}", message);
				break;
			}
		}
	}

	public MessageResponse removeMessage(String messageId, Destination destination) {
		log.info("{}", "Start: removeMessage");
		QueueConnection queueConnection = null;
		QueueSession session = null;
		MessageResponse messageResponse = new MessageResponse("Removing message with Id '" + messageId + "' from queue.");

		String selector = "JMSMessageID = '" + messageId + "'";
		messageResponse.setMessageCount(-1);
		try {
			queueConnection = ((QueueConnectionFactory) connectionFactory).createQueueConnection();
			Queue destQueue = (Queue) destination;
			messageResponse.setJmsDestination(destQueue.getQueueName());
			queueConnection.start();
			session = queueConnection.createQueueSession(true, Session.AUTO_ACKNOWLEDGE);
			attemptToRemoveMessage(messageId, destQueue, session, messageResponse, selector);
		} catch (JMSException e) {
			messageResponse.setErrorMessage(PROBLEM_FETCHING_MESSAGE_IDS_FROM_QUEUE);
			messageResponse.setExceptionInformation(new ExceptionInfo(e));
			log.warn(PROBLEM_FETCHING_MESSAGE_IDS_FROM_QUEUE, e);
		} finally {
			closeConnections(session, queueConnection);
		}
		log.info("{}", "End: removeMessage");
		return messageResponse;
	}

	private void attemptToRemoveMessage(String messageId, Queue destination, QueueSession session, MessageResponse messageResponse,
			String selector) {
		QueueReceiver receiver = null;
		try {
			receiver = session.createReceiver(destination, selector);
			messageResponse.setMessageCount(0);
			Message message;
			while ((message = receiver.receiveNoWait()) != null) {
				messageResponse.setMessageCount(1);
				addMessageDataToResponse(messageResponse, message);
			}
			if (messageResponse.getMessageCount() < 1) {
				messageResponse.setErrorMessage("No message found with id '" + messageId + "' (" + selector + ").");
			}
		} catch (Exception e) {
			log.error("{}", "==============================================");
			log.error("{}", "Selector: " + selector);
			log.error(e.getMessage(), e);
			log.error("{}", "==============================================");
		} finally {
			closeReceiver(receiver);
		}
	}

	private void closeReceiver(QueueReceiver receiver) {
		try {
			if (receiver != null) {
				receiver.close();
			}
		} catch (JMSException e) {
			log.debug("Unable to close receiver!", e);
		}
	}

	private void addMessageDataToResponse(MessageResponse response, Message message) throws JMSException {
		if (message == null) {
			response.setErrorMessage("Problem reading message. message is null.");
			return;
		}
		response.setJmsCorrelationID(message.getJMSCorrelationID());
		response.setJmsMessageID(message.getJMSMessageID());
		response.setJmsReplyTo(getDestinationName(message.getJMSReplyTo()));
		response.setJmsDestination(getDestinationName(message.getJMSDestination()));
		response.setJmsPriority(message.getJMSPriority());
		response.setJmsRedelivered(message.getJMSRedelivered());
		response.setJmsTimestamp(message.getJMSTimestamp());
		response.setJmsType(message.getJMSType());
		if (message instanceof TextMessage) {
			response.setTextMessageText(((TextMessage) message).getText());
		}
		Enumeration<?> propertyNames = message.getPropertyNames();
		while (propertyNames.hasMoreElements()) {
			String key = (String) propertyNames.nextElement();
			response.addProperty(key, message.getObjectProperty(key));
		}
	}

	private String getDestinationName(Destination destination) throws JMSException {
		String name = null;
		if (destination instanceof Queue) {
			name = ((Queue) destination).getQueueName();
		}
		return name;
	}

	private void closeConnections(MessageConsumer consumer, Session session, Connection connection) {
		if (consumer != null) {
			try {
				consumer.close();
			} catch (JMSException e) {
				log.warn("Problem closing consumer.", e);
			}
		}
		closeConnections(session, connection);
	}

	private void closeConnections(QueueBrowser browser, Session session, Connection connection) {
		if (browser != null) {
			try {
				browser.close();
			} catch (JMSException e) {
				log.warn("Problem closing browser.", e);
			}
		}
		closeConnections(session, connection);
	}

	private void closeConnections(Session session, Connection connection) {
		if (session != null) {
			try {
				session.close();
			} catch (JMSException e) {
				log.warn("Problem closing session.", e);
			}
		}
		if (connection != null) {
			try {
				connection.close();
			} catch (JMSException e) {
				log.warn("Problem closing connection.", e);
			}
		}
	}
}