package nl.belastingdienst.iva.wd.thl.mq;

import java.text.SimpleDateFormat;
import java.util.*;

public class MessageResponse {

	private int messageCount;
	private List<String> messageIds;
	private String jmsCorrelationID;
	private String jmsDestination;
	private String jmsMessageID;
	private String jmsReplyTo;
	private Integer jmsPriority;
	private Boolean jmsRedelivered;
	private Date jmsTimestamp;
	private String  jmsTimestampAsDatetime;
	private String jmsType;
	private String textMessageText;
	private String errorMessage;
	private String action;
	private ExceptionInfo exceptionInformation;
	private Map<String, Object> properties;

	public Map<String, Object> getProperties() {
		return properties;
	}
	public void setProperties(Map<String, Object> properties) {
		this.properties = properties;
	}

	public MessageResponse(String action) {
		this.setAction(action);
	}
	public void setMessageCount(int cnt) {
		this.messageCount = cnt;
	}
	public int getMessageCount() {
		return this.messageCount;
	}

	public List<String> getMessageIds() {
		return this.messageIds;
	}
	public void addMessageId(String id) {
		if (messageIds == null) {
			messageIds = new LinkedList<>();
		}
		messageIds.add(id);
	}

	public void setJmsCorrelationID(String jmsCorrelationID) {
		this.jmsCorrelationID = jmsCorrelationID;
	}

	public void setJmsDestination(String jmsDestination) { this.jmsDestination = jmsDestination; }

	public void setJmsMessageID(String jmsMessageID) {
		this.jmsMessageID = jmsMessageID;
	}

	public void setJmsReplyTo(String destinationName) {
		this.jmsReplyTo = destinationName;
	}

	public void setJmsPriority(int jmsPriority) {
		this.jmsPriority = jmsPriority;
	}

	public void setJmsRedelivered(boolean jmsRedelivered) {
		this.jmsRedelivered = jmsRedelivered;
	}

	public void setJmsTimestamp(long jmsTimestamp) {
		this.jmsTimestamp = new Date(jmsTimestamp);
		this.jmsTimestampAsDatetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(this.jmsTimestamp);
	}

	public void setJmsType(String jmsType) {
		this.jmsType = jmsType;
	}

	public void setTextMessageText(String text) {
		this.textMessageText= text;
	}

	public void setErrorMessage(String message) {
		this.errorMessage = message;
	}

	public String getJmsCorrelationID() {
		return jmsCorrelationID;
	}

	public String getJmsDestination() { return jmsDestination; }

	public String getJmsMessageID() {
		return jmsMessageID;
	}

	public String getJmsReplyTo() {
		return jmsReplyTo;
	}

	public Integer getJmsPriority() {
		return jmsPriority;
	}

	public Boolean getJmsRedelivered() {
		return jmsRedelivered;
	}

	public Date getJmsTimestamp() {
		return jmsTimestamp;
	}

	public String getJmsTimestampAsDatetime() {
		return jmsTimestampAsDatetime;
	}

	public String getJmsType() {
		return jmsType;
	}

	public String getTextMessageText() {
		return textMessageText;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setExceptionInformation(ExceptionInfo exceptionInfo) {
		this.exceptionInformation = exceptionInfo;
	}

	public ExceptionInfo getExceptionInformation() {
		return this.exceptionInformation;
	}

	public void addProperty(String key, Object objectProperty) {
		if (properties == null) {
			properties = new HashMap<>();
		}
		properties.put(key, objectProperty);
	}
	public Object getProperty(String key) {
		return (properties == null? null:properties.get(key));
	}
	@Override
	public String toString() {
		return "MessageResponse [messageCount=" + messageCount + ", messageIds=" + messageIds + ", jmsCorrelationID="
				+ jmsCorrelationID + ", jmsDestination" + jmsDestination + ", jmsMessageID="
				+ jmsMessageID + ", jmsReplyTo=" + jmsReplyTo + ", jmsPriority=" + jmsPriority + ", jmsRedelivered="
				+ jmsRedelivered + ", jmsTimestamp=" + jmsTimestamp + ", jmsType=" + jmsType + ", textMessageText="
				+ textMessageText + ", errorMessage=" + errorMessage + ", action=" + action + ", exceptionInformation="
				+ exceptionInformation + ", properties=" + properties + "]";
	}

}