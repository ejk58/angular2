package nl.belastingdienst.iva.wd.thl.webservice;

import java.util.List;

import javax.inject.Inject;

import nl.belastingdienst.iva.wd.thl.dao.FeatureDao;
import nl.belastingdienst.iva.wd.thl.domain.Feature;


public class FeatureService {

	@Inject
	private FeatureDao dao;

	public List<Feature> findAll() {
		return this.dao.findAll();
	}

	public boolean isFeatureEnabled(String name) {
		Feature f = this.dao.findByName(name);
		return f.isEnabled();
	}

	public boolean toggleByName(String name) {
		Feature f = this.dao.findByName(name);
		f.toggle();
		f = this.dao.update(f);
		return f.isEnabled();
	}
}