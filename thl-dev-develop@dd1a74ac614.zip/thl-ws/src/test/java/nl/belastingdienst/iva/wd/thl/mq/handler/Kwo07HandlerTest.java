package nl.belastingdienst.iva.wd.thl.mq.handler;

import static nl.belastingdienst.iva.wd.thl.mq.handler.Kwo07Handler.REQUEST_RECORD_LENGTH;
import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.numbers;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doReturn;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

@ExtendWith(MockitoExtension.class)
class Kwo07HandlerTest {

	private static final String HERKOMST = "TGL-KWO";
	private static final String FUNCTIE = "07";
	private static final int LINEFEED_LENGTH = 1;

	private static final String VOORLOOP_RECORD = String.format("%s%s", HERKOMST, FUNCTIE);
	private static final String[] MESSAGE_INFO = new String[]{
			VOORLOOP_RECORD
	};

	final List<String> mockDataRecords = Arrays.asList(
			String.format("%s%s%s", numbers(9), "20210201", "02"),
			String.format("%s%s%s", numbers(9), "20210301", "03"),
			String.format("%s%s%s", numbers(9), "20210401", "04"),
			String.format("%s%s%s", numbers(9), "20210501", "05"),
			String.format("%s%s%s", numbers(9), "20210601", "06"),
			String.format("%s%s%s", numbers(9), "20210701", "07"),
			String.format("%s%s%s", numbers(9), "20210801", "08"),
			String.format("%s%s%s", numbers(9), "20210901", "09"),
			String.format("%s%s%s", numbers(9), "20211001", "10"),
			String.format("%s%s%s", numbers(9), "20211002", "10"),
			String.format("%s%s%s", numbers(9), "20211003", "10"),
			String.format("%s%s%s", numbers(9), "20211004", "10"),
			String.format("%s%s%s", numbers(9), "20211005", "10"),
			String.format("%s%s%s", numbers(9), "20211006", "10"),
			String.format("%s%s%s", numbers(9), "20211007", "10"),
			String.format("%s%s%s", numbers(9), "20211008", "10"),
			String.format("%s%s%s", numbers(9), "20211009", "10"),
			String.format("%s%s%s", numbers(9), "20211010", "10"),
			String.format("%s%s%s", numbers(9), "20211011", "10"),
			String.format("%s%s%s", numbers(9), "20211012", "10"),
			String.format("%s%s%s", numbers(9), "20211013", "10"),
			String.format("%s%s%s", numbers(9), "20211014", "10"),
			String.format("%s%s%s", numbers(9), "20211015", "10"),
			String.format("%s%s%s", numbers(9), "20211016", "10")

	);

	@Mock
	private BatDao batDao;

	@Spy
	@InjectMocks
	private final Kwo07Handler kwo07Handler = new Kwo07Handler();

	@Mock
	private ThlDao thlDao;

	@Test
	public void checkValidParameters() {
		assertEquals(REQUEST_RECORD_LENGTH, VOORLOOP_RECORD.length());
		String message = String.format("%s\n", VOORLOOP_RECORD);
		assertEquals(REQUEST_RECORD_LENGTH + LINEFEED_LENGTH, message.length());
	}

	@Test
	public void getSingleRecord() {
		String lineEnding = "\n";
		List<String> mockData = mockDataRecords.subList(0, 1);
		List<String> data = getKwaliteitsbeoordelingenLast6YearsForKwo07WithMockData(mockData, 100_000, lineEnding);

		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals("TGL-KWO0700100100  " + lineEnding +
				"1234567892021020102" + lineEnding, data.get(0));
	}

	@Test
	public void getSmallRecordSet() {
		String lineEnding = "\n";
		List<String> mockData = mockDataRecords.subList(0, 4);
		List<String> data = getKwaliteitsbeoordelingenLast6YearsForKwo07WithMockData(mockData, 100_000, lineEnding);

		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals("TGL-KWO0700100100  " + lineEnding +
				String.join(lineEnding, mockData) + lineEnding , data.get(0));
	}

	@Test
	public void LargeRecordSetThatWillBeBrokenUpInto4DifferentStrings() {
		LargeRecordSetThatWillBeBrokenUpInto4DifferentStringsWithLineEnding("\n");
	}

	@Test
	public void LargeRecordSetThatWillBeBrokenUpInto4DifferentStringsWithDifferentLineEnding() {
		LargeRecordSetThatWillBeBrokenUpInto4DifferentStringsWithLineEnding("\r\n");
	}

	private void LargeRecordSetThatWillBeBrokenUpInto4DifferentStringsWithLineEnding(String lineEnding) {
		List<String> mockData = mockDataRecords;
		List<String> data = getKwaliteitsbeoordelingenLast6YearsForKwo07WithMockData(mockData, 5, lineEnding);

		assertNotNull(data);
		assertEquals(5, data.size());
		assertEquals("TGL-KWO0700100500  " + lineEnding
						+ String.join(lineEnding, mockDataRecords.subList(0, 5)) + lineEnding
				, data.get(0));

		assertEquals("TGL-KWO0700200500  "  + lineEnding
						+ String.join(lineEnding, mockDataRecords.subList(5, 10)) + lineEnding
				, data.get(1));

		assertEquals("TGL-KWO0700300500  "  + lineEnding
						+ String.join(lineEnding, mockDataRecords.subList(10, 15)) + lineEnding
				, data.get(2));

		assertEquals("TGL-KWO0700400500  "  + lineEnding
						+ String.join(lineEnding, mockDataRecords.subList(15, 20)) + lineEnding
				, data.get(3));

		assertEquals("TGL-KWO0700500500  "  + lineEnding
						+ String.join(lineEnding, mockDataRecords.subList(20, mockDataRecords.size())) + lineEnding
				, data.get(4));
	}

	private List<String> getKwaliteitsbeoordelingenLast6YearsForKwo07WithMockData(List<String> mockData, int maxNumberOfRecordPerMessage, String lineEnding) {
		ProgressReporter progressReporter = new ProgressReporter(thlDao);
		progressReporter.reportStart("1");
		if (mockData.size() > 1) {
			doReturn(maxNumberOfRecordPerMessage).when(this.kwo07Handler).getMaxNumberOfRecordPerMessage();
		}
		doReturn(mockData).when(this.batDao).getKwaliteitsbeoordelingenLast6YearsForKwo07();
		return this.kwo07Handler.getData(Arrays.asList(MESSAGE_INFO), progressReporter, lineEnding);
	}

}