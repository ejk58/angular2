package nl.belastingdienst.iva.wd.thl.mq.handler;

import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.numbers;
import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.spaces;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

@ExtendWith(MockitoExtension.class)
public class Rsa03HandlerTest {

	private static final String HERKOMST = "TGL-RSA";
	private static final String FUNCTIE = "03";
	private static final String SPACES_253 = spaces(253);

	@Mock
	private BatDao batDao;

	@Spy
	@InjectMocks
	private final Rsa03Handler rsa03Handler = new Rsa03Handler();

	@Mock
	private ThlDao thlDao;

	private String herkomst, functie;

	final List<String> mockData = Arrays.asList(
			String.format("%s%s%s%-255s", numbers(9), "2017", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2017", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2017", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2017", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2017", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2018", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2018", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2018", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2018", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2018", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2019", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2019", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2019", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2019", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2019", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2020", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2020", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2020", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2020", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2020", "03", "Toelichting"),
			String.format("%s%s%s%-255s", numbers(9), "2021", "03", "Toelichting")
	);

	@BeforeEach
	public void setup() {
		herkomst = HERKOMST;
		functie = FUNCTIE;
	}

	@Test
	public void LargeRecordSetThatWillBeBrokenUpInto4DifferentStrings() {
		ProgressReporter progressReporter = new ProgressReporter(thlDao);
		progressReporter.reportStart("1");
		String voorloop = String.format("%s%s", herkomst, functie);
		String[] messageInfo = new String[]{
				voorloop
		};
		when(batDao.getVpbChangesForRsaSince(any(Date.class))).thenReturn(mockData);
		doReturn(5).when(rsa03Handler).getMaxNumberOfRecordPerMessage();
		List<String> data = rsa03Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");
		assertNotNull(data);
		assertEquals(5, data.size());

		assertEquals("TGL-RSA0300100500" + SPACES_253 + "\n"  +
				mockData.get(0) + "\n" + mockData.get(1) + "\n" + mockData.get(2) + "\n" + mockData.get(3) + "\n" + mockData.get(4) + "\n" , data.get(0));
		assertEquals("TGL-RSA0300200500" + SPACES_253 + "\n"  +
				mockData.get(5) + "\n" + mockData.get(6) + "\n" + mockData.get(7) + "\n" + mockData.get(8) + "\n" + mockData.get(9) + "\n" , data.get(1));
		assertEquals("TGL-RSA0300300500" + SPACES_253 + "\n"  +
				mockData.get(10) + "\n" + mockData.get(11) + "\n" + mockData.get(12) + "\n" + mockData.get(13) + "\n" + mockData.get(14) + "\n" , data.get(2));
		assertEquals("TGL-RSA0300400500" + SPACES_253 + "\n"  +
				mockData.get(15) + "\n" + mockData.get(16) + "\n" + mockData.get(17) + "\n" + mockData.get(18) + "\n" + mockData.get(19) + "\n" , data.get(3));
		assertEquals("TGL-RSA0300500500" + SPACES_253 + "\n"  +
				mockData.get(20) + "\n", data.get(4));
	}
	@Test
	public void LargeRecordSetThatWillBeBrokenUpInto4DifferentStringsWithDiffenrentLineEnding() {
		ProgressReporter progressReporter = new ProgressReporter(thlDao);
		progressReporter.reportStart("1");
		String voorloop = String.format("%s%s", herkomst, functie);
		String[] messageInfo = new String[]{
				voorloop
		};
		when(batDao.getVpbChangesForRsaSince(any(Date.class))).thenReturn(mockData);
		doReturn(5).when(rsa03Handler).getMaxNumberOfRecordPerMessage();
		List<String> data = rsa03Handler.getData(Arrays.asList(messageInfo), progressReporter, "\r\n");
		assertNotNull(data);
		assertEquals(5, data.size());

		assertEquals("TGL-RSA0300100500" + SPACES_253 + "\r\n"  +
				mockData.get(0) + "\r\n" + mockData.get(1) + "\r\n" + mockData.get(2) + "\r\n" + mockData.get(3) + "\r\n" + mockData.get(4) + "\r\n" , data.get(0));
		assertEquals("TGL-RSA0300200500" + SPACES_253 + "\r\n"  +
				mockData.get(5) + "\r\n" + mockData.get(6) + "\r\n" + mockData.get(7) + "\r\n" + mockData.get(8) + "\r\n" + mockData.get(9) + "\r\n" , data.get(1));
		assertEquals("TGL-RSA0300300500" + SPACES_253 + "\r\n"  +
				mockData.get(10) + "\r\n" + mockData.get(11) + "\r\n" + mockData.get(12) + "\r\n" + mockData.get(13) + "\r\n" + mockData.get(14) + "\r\n" , data.get(2));
		assertEquals("TGL-RSA0300400500" + SPACES_253 + "\r\n"  +
				mockData.get(15) + "\r\n" + mockData.get(16) + "\r\n" + mockData.get(17) + "\r\n" + mockData.get(18) + "\r\n" + mockData.get(19) + "\r\n" , data.get(3));
		assertEquals("TGL-RSA0300500500" + SPACES_253 + "\r\n"  +
				mockData.get(20) + "\r\n", data.get(4));
	}

}
