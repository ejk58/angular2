package nl.belastingdienst.iva.wd.thl.mq.handler;

import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.spaces;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

@ExtendWith(MockitoExtension.class)
class Atk04HandlerTest {
    // parts voorlooprecord
    private static final String HERKOMST = "TGL-ATK";
    private static final String FUNCTIE = "04";
    private static final String FILLER_VOORLOOP = spaces(5);
    public static final String LINEFEED = "\n";

    @Mock
    private ThlDao thlDao;

    @Mock
    private BatDao batDao;

    @Spy
    @InjectMocks
    private Atk04Handler atk04Handler = new Atk04Handler();

    @Test
    void getDataFromOneRecord() {
        ProgressReporter progressReporter = new ProgressReporter(thlDao);
        progressReporter.reportStart("1");
        // dit komt binnen
        String voorlooprecord = HERKOMST + FUNCTIE + FILLER_VOORLOOP ;
        String[] messageInfo = new String[]{voorlooprecord, "20210101000000"};
        //verwerken
        //maak nieuw voorloop record voor de verwerking
        String record = createMockRecord(123456789, 22, 2021, 333, 2,
                "20210102", "abc");
        List<String> mockData = Collections.singletonList(record);
        when(batDao.getChangesForAtk04(any(Date.class))).thenReturn(mockData);
        List<String> data = atk04Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");

        assertNotNull(data);
        assertEquals(atk04Handler.getAnswerRecordLength(), record.length());
        assertEquals(1, data.size());
        String responseVoorloopRecord = String.format("%s", HERKOMST+FUNCTIE+"001"+"001"+"00"
                        + spaces(266) + LINEFEED);
        String responseRecord = String.format("%s", "1234567892220213330220210102abc" +
                spaces(252) + LINEFEED);
        assertEquals(String.format("%s", responseVoorloopRecord + responseRecord) , data.get(0));
        assertTrue(data.get(0).contains("1234567892220213330220210102abc") );
    }

    @Test
    void getDataFromTwoRecords() {
        ProgressReporter progressReporter = new ProgressReporter(thlDao);
        progressReporter.reportStart("1");
        String voorlooprecord = HERKOMST + FUNCTIE + FILLER_VOORLOOP;
        String[] messageInfo = new String[]{voorlooprecord.replace(" ", "0"), "20210101000000"};

        String record1 = createMockRecord(123456789, 21, 2021, 333, 2, "20210101", "abc");
        String record2 = createMockRecord(123456788, 22, 2021, 333, 2, "20210101", "def");
        List<String> mockData = Arrays.asList(record1, record2);
        doReturn(100_000).when(atk04Handler).getMaxNumberOfRecordPerMessage();
        when(batDao.getChangesForAtk04(any(Date.class))).thenReturn(mockData);
        List<String> data = atk04Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");

        assertNotNull(data);
        assertEquals(1, data.size());
        assertTrue(data.get(0).contains(record1));
        assertTrue(data.get(0).contains(record2));
        String responseVoorloopRecord = String.format("%s", HERKOMST+FUNCTIE+"001"+"001"+"00" + spaces(266)
                + LINEFEED);
        String responseRecords = String.format("%s", record1 + LINEFEED + record2 + LINEFEED);
        assertEquals(String.format("%s", responseVoorloopRecord + responseRecords) , data.get(0));
    }

    @Test
    void getDataFromTwoRecordsUsingDifferentLineEnding() {
        ProgressReporter progressReporter = new ProgressReporter(thlDao);
        progressReporter.reportStart("1");
        String voorlooprecord = HERKOMST + FUNCTIE + FILLER_VOORLOOP;
        String[] messageInfo = new String[]{voorlooprecord.replace(" ", "0"), "20210101000000"};

        String record1 = createMockRecord(123456789, 21, 2021, 333, 2, "20210101", "abc");
        String record2 = createMockRecord(123456788, 22, 2021, 333, 2, "20210101", "def");
        List<String> mockData = Arrays.asList(record1, record2);
        doReturn(100_000).when(atk04Handler).getMaxNumberOfRecordPerMessage();
        when(batDao.getChangesForAtk04(any(Date.class))).thenReturn(mockData);
        List<String> data = atk04Handler.getData(Arrays.asList(messageInfo), progressReporter, "\r\n");

        assertNotNull(data);
        assertEquals(1, data.size());
        assertTrue(data.get(0).contains(record1));
        assertTrue(data.get(0).contains(record2));
        String responseVoorloopRecord = String.format("%s%s00100100%s\r\n", HERKOMST, FUNCTIE, spaces(266));
        String responseRecords = String.format("%s\r\n%s\r\n", record1, record2);
        assertEquals(String.format("%s%s", responseVoorloopRecord, responseRecords) , data.get(0));
    }

    @Test
    void largeSetThatWillBeDividedOverStrings() {
        ProgressReporter progressReporter = new ProgressReporter(thlDao);
        progressReporter.reportStart("1");
        String voorlooprecord = HERKOMST + FUNCTIE + FILLER_VOORLOOP;
        String[] messageInfo = new String[]{voorlooprecord, "20210101000000"};

        String record1 = createMockRecord(123456701, 21, 2021, 333, 2, "20210101", "abc");
        String record2 = createMockRecord(123456702, 22, 2021, 333, 2, "20210101", "def");
        String record3 = createMockRecord(123456703, 22, 2021, 333, 2, "20210101", "qwe");
        String record4 = createMockRecord(123456704, 22, 2021, 333, 2, "20210101", "wer");
        String record5 = createMockRecord(123456705, 22, 2021, 333, 2, "20210101", "ert");
        String record6 = createMockRecord(123456706, 22, 2021, 333, 2, "20210101", "rty");
        String record7 = createMockRecord(123456707, 22, 2021, 333, 2, "20210101", "tyu");
        String record8 = createMockRecord(123456708, 22, 2021, 333, 2, "20210101", "yui");
        String record9 = createMockRecord(123456709, 22, 2021, 333, 2, "20210101", "uio");
        String record10 = createMockRecord(123456710, 22, 2021, 333, 2, "20210101", "iop");
        String record11 = createMockRecord(123456711, 22, 2021, 333, 2, "20210101", "asd");
        String record12 = createMockRecord(123456712, 22, 2021, 333, 2, "20210101", "sdf");
        String record13 = createMockRecord(123456713, 22, 2021, 333, 2, "20210101", "dfg");
        String record14 = createMockRecord(123456714, 22, 2021, 333, 2, "20210101", "fgh");
        String record15 = createMockRecord(123456715, 22, 2021, 333, 2, "20210101", "hjk");
        String record16 = createMockRecord(123456716, 22, 2021, 333, 2, "20210101", "jkl");
        String record17 = createMockRecord(123456717, 22, 2021, 333, 2, "20210101", "zxc");
        String record18 = createMockRecord(123456718, 22, 2021, 333, 2, "20210101", "xcv");
        String record19 = createMockRecord(123456719, 22, 2021, 333, 2, "20210101", "cvb");
        String record20 = createMockRecord(123456720, 22, 2021, 333, 2, "20210101", "vbn");
        List<String> mockData = Arrays.asList(record1, record2, record3, record4, record5, record6,record7, record8, record9,
                record10, record11, record12, record13, record14, record15, record16,record17, record18, record19, record20);
        doReturn(5).when(atk04Handler).getMaxNumberOfRecordPerMessage();
        when(batDao.getChangesForAtk04(any(Date.class))).thenReturn(mockData);
        List<String> data = atk04Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");

        assertNotNull(data);
        assertEquals(4, data.size());
        //First part
        assertEquals("TGL-ATK0400100400" + spaces(266) + LINEFEED
                        + mockData.get(0) + LINEFEED + mockData.get(1) + LINEFEED + mockData.get(2)
                        + LINEFEED + mockData.get(3) + LINEFEED + mockData.get(4) + LINEFEED,
                data.get(0));
        //Last part
        assertEquals("TGL-ATK0400400400" + spaces(266) + LINEFEED
                        + mockData.get(15)+ LINEFEED + mockData.get(16) + LINEFEED + mockData.get(17)
                        + LINEFEED + mockData.get(18) + LINEFEED + mockData.get(19) + LINEFEED,
                data.get(3));
    }


    private String createMockRecord(int bsn, int subNr, int bJaar, int middel, int bWijze, String ingetrokken, String toelichting) {
        String bsnRsin = String.format("%09d", bsn);
        String subNummer = String.format("%02d", subNr);
        String belastingJaar = String.format("%04d", bJaar);
        String middelStr = String.format("%03d", middel);
        String behWijze = String.format("%02d", bWijze);
        String ingetrokkenStr = String.format("%-8s",ingetrokken);
        String toelichtingStr = String.format("%-255s", toelichting);
        return bsnRsin + subNummer + belastingJaar + middelStr + behWijze + ingetrokkenStr + toelichtingStr;
    }


}