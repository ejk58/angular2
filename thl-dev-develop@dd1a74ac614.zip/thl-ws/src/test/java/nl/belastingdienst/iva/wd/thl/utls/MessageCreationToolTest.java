package nl.belastingdienst.iva.wd.thl.utls;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class MessageCreationToolTest {

    @Test
    void spaces() {
        String zerospaces = "";
        String oneSpace = " ";
        String twoSpaces = "  ";
        String sixSpaces = twoSpaces + twoSpaces + twoSpaces;
        assertEquals(MessageCreationTool.spaces(0), zerospaces);
        assertEquals(MessageCreationTool.spaces(1), oneSpace);
        assertEquals(MessageCreationTool.spaces(2), twoSpaces);
        assertEquals(MessageCreationTool.spaces(6), sixSpaces);
    }

    @Test
    void numbers() {
        String numbersTill9 = "123456789";
        assertEquals(MessageCreationTool.numbers(9), numbersTill9);
        assertNotEquals("012345678", MessageCreationTool.numbers(9));
        assertNotEquals("012345678", MessageCreationTool.numbers(9));

    }

    @Test
    void zeroFiller() {
        String oneZero = "0";
        String twoZeros = "00";
        String threeZeros = "000";
        assertEquals(MessageCreationTool.zeroFiller(1), oneZero);
        assertEquals(MessageCreationTool.zeroFiller(2), twoZeros);
        assertEquals(MessageCreationTool.zeroFiller(3), threeZeros);

    }

    @Test
    void stringFiller() {
        String testAbc = "abc";
        String result = "   " + testAbc;

        assertEquals(MessageCreationTool.stringFiller(testAbc, 6), result);
    }

    @Test
    void testStringFiller() {
        String testAbc = "abc";
        String result = testAbc + "   ";

        assertEquals(MessageCreationTool.stringFiller(testAbc, 6, false), result);
    }
}