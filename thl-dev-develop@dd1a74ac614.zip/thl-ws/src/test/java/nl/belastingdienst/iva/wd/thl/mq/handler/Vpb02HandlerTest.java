package nl.belastingdienst.iva.wd.thl.mq.handler;

import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

@ExtendWith(MockitoExtension.class)
public class Vpb02HandlerTest {

    private static final String HERKOMST = "TGL-VPB";
    private static final String FUNCTIE = "02";
    private static final String SPACES_5 = spaces(5);
    @Mock
    private BatDao batDao;

    @Spy
    @InjectMocks
    private final Vpb02Handler vpb02Handler = new Vpb02Handler();

    @Mock
    private ThlDao thlDao;

    @Test
    public void checkValidParameters() {
        String mutatieDatum = "20210102030405";
        String voorloop = String.format("%s%s%s", HERKOMST, FUNCTIE, SPACES_5);
        assertEquals(Vpb02Handler.REQUEST_RECORD_LENGTH, voorloop.length());
        String message = String.format("%s\n%s\n", voorloop, mutatieDatum);
        System.out.println(message.length());
        assertEquals(Vpb02Handler.REQUEST_RECORD_LENGTH + Vpb02Handler.REQUEST_RECORD_LENGTH + 2, message.length());
    }

    @Test
    public void getSingleRecord() {
        ProgressReporter progressReporter = new ProgressReporter(thlDao);
        progressReporter.reportStart("1");
        String mutatieDatum = "20210102030405";
        String voorloop = String.format("%s%s%s", HERKOMST, FUNCTIE, SPACES_5);
        String[] messageInfo = new String[]{
                voorloop, mutatieDatum
        };
        String singleRecord = String.format("%s%s%s%s", numbers(9), "2021", spaces(2), "20210102");
        List<String> mockData = Collections.singletonList(singleRecord);
        when(batDao.getVpbChangesSince(any(Date.class))).thenReturn(mockData);
        List<String> data = vpb02Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");
        assertNotNull(data);
        assertEquals(1, data.size());
        assertEquals("TGL-VPB0200100100      \n" +
                "1234567892021  20210102\n", data.get(0));
    }

    @Test
    public void getSmallRecordSet() {
        ProgressReporter progressReporter = new ProgressReporter(thlDao);
        progressReporter.reportStart("1");
        String mutatieDatum = "20210102030405";
        String voorloop = String.format("%s%s%s", HERKOMST, FUNCTIE, SPACES_5);
        String[] messageInfo = new String[]{
                voorloop
                , mutatieDatum
        };
        String singleRecord = String.format("%s%s%s%s", numbers(9), "2021", spaces(2), "20210102");
        String singleRecord2 = String.format("%s%s%s%s", numbers(9), "2021", spaces(2), "20210103");
        String singleRecord3 = String.format("%s%s%s%s", numbers(9), "2021", spaces(2), "20210104");
        List<String> mockData = Arrays.asList(singleRecord, singleRecord2, singleRecord3);
        doReturn(100_000).when(vpb02Handler).getMaxNumberOfRecordPerMessage();
        when(batDao.getVpbChangesSince(any(Date.class))).thenReturn(mockData);
        List<String> data = vpb02Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");
        assertNotNull(data);
        assertEquals(1, data.size());
        assertEquals("TGL-VPB0200100100      \n"  +
                "1234567892021  20210102\n" +
                "1234567892021  20210103\n" +
                "1234567892021  20210104\n", data.get(0));
    }

    @Test
    public void getSmallRecordSetWithDifferentLineEnding() {
        ProgressReporter progressReporter = new ProgressReporter(thlDao);
        progressReporter.reportStart("1");
        String mutatieDatum = "20210102030405";
        String voorloop = String.format("%s%s%s", HERKOMST, FUNCTIE, SPACES_5);
        String[] messageInfo = new String[]{
                voorloop
                , mutatieDatum
        };
        String singleRecord = String.format("%s%s%s%s", numbers(9), "2021", spaces(2), "20210102");
        String singleRecord2 = String.format("%s%s%s%s", numbers(9), "2021", spaces(2), "20210103");
        String singleRecord3 = String.format("%s%s%s%s", numbers(9), "2021", spaces(2), "20210104");
        List<String> mockData = Arrays.asList(singleRecord, singleRecord2, singleRecord3);
        doReturn(100_000).when(vpb02Handler).getMaxNumberOfRecordPerMessage();
        when(batDao.getVpbChangesSince(any(Date.class))).thenReturn(mockData);
        List<String> data = vpb02Handler.getData(Arrays.asList(messageInfo), progressReporter, "\r\n");
        assertNotNull(data);
        assertEquals(1, data.size());
        assertEquals("TGL-VPB0200100100      \r\n"  +
                "1234567892021  20210102\r\n" +
                "1234567892021  20210103\r\n" +
                "1234567892021  20210104\r\n", data.get(0));
    }

    @Test
    public void LargeRecordSetThatWillBeBrokenUpInto4DifferentStrings() {
        ProgressReporter progressReporter = new ProgressReporter(thlDao);
        progressReporter.reportStart("1");
        String mutatieDatum = "20210102030405";
        String voorloop = String.format("%s%s%s", HERKOMST, FUNCTIE, SPACES_5);
        String[] messageInfo = new String[]{
                voorloop
                , mutatieDatum
        };
        List<String> mockData = Arrays.asList(
                String.format("%s%s%s%s", numbers(9), "2017", spaces(2), "20210101"),
                String.format("%s%s%s%s", numbers(9), "2017", spaces(2), "20210102"),
                String.format("%s%s%s%s", numbers(9), "2017", spaces(2), "20210103"),
                String.format("%s%s%s%s", numbers(9), "2017", spaces(2), "20210104"),
                String.format("%s%s%s%s", numbers(9), "2017", spaces(2), "20210105"),
                String.format("%s%s%s%s", numbers(9), "2018", spaces(2), "20210101"),
                String.format("%s%s%s%s", numbers(9), "2018", spaces(2), "20210102"),
                String.format("%s%s%s%s", numbers(9), "2018", spaces(2), "20210103"),
                String.format("%s%s%s%s", numbers(9), "2018", spaces(2), "20210104"),
                String.format("%s%s%s%s", numbers(9), "2018", spaces(2), "20210105"),
                String.format("%s%s%s%s", numbers(9), "2019", spaces(2), "20210101"),
                String.format("%s%s%s%s", numbers(9), "2019", spaces(2), "20210102"),
                String.format("%s%s%s%s", numbers(9), "2019", spaces(2), "20210103"),
                String.format("%s%s%s%s", numbers(9), "2019", spaces(2), "20210104"),
                String.format("%s%s%s%s", numbers(9), "2019", spaces(2), "20210105"),
                String.format("%s%s%s%s", numbers(9), "2020", spaces(2), "20210101"),
                String.format("%s%s%s%s", numbers(9), "2020", spaces(2), "20210102"),
                String.format("%s%s%s%s", numbers(9), "2020", spaces(2), "20210103"),
                String.format("%s%s%s%s", numbers(9), "2020", spaces(2), "20210104"),
                String.format("%s%s%s%s", numbers(9), "2020", spaces(2), "20210105"),
                String.format("%s%s%s%s", numbers(9), "2021", spaces(2), "20210101")
        );
        when(batDao.getVpbChangesSince(any(Date.class))).thenReturn(mockData);
        doReturn(5).when(vpb02Handler).getMaxNumberOfRecordPerMessage();
        List<String> data = vpb02Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");
        assertNotNull(data);
        assertEquals(5, data.size());
        assertEquals("TGL-VPB0200100500      \n"  +
                mockData.get(0) + "\n" + mockData.get(1) + "\n" + mockData.get(2) + "\n" + mockData.get(3) + "\n" + mockData.get(4) + "\n" , data.get(0));
        assertEquals("TGL-VPB0200200500      \n"  +
                mockData.get(5) + "\n" + mockData.get(6) + "\n" + mockData.get(7) + "\n" + mockData.get(8) + "\n" + mockData.get(9) + "\n" , data.get(1));
        assertEquals("TGL-VPB0200300500      \n"  +
                mockData.get(10) + "\n" + mockData.get(11) + "\n" + mockData.get(12) + "\n" + mockData.get(13) + "\n" + mockData.get(14) + "\n" , data.get(2));
        assertEquals("TGL-VPB0200400500      \n"  +
                mockData.get(15) + "\n" + mockData.get(16) + "\n" + mockData.get(17) + "\n" + mockData.get(18) + "\n" + mockData.get(19) + "\n" , data.get(3));
        assertEquals("TGL-VPB0200500500      \n"  +
                mockData.get(20) + "\n", data.get(4));
    }
}