package nl.belastingdienst.iva.wd.thl.mq.handler;

import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.spaces;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

@ExtendWith(MockitoExtension.class)
class Vtc06HandlerTest {
	// parts voorlooprecord
	private static final String HERKOMST = "TGL-VTC";
	private static final String FUNCTIE = "06";
	public static final String LINEFEED = "\n";

	@Mock
	private Query correctieQuery;

	@Mock
	private Query specificatieQuery;

	@Mock
	private ThlDao thlDao;

	@Mock
	EntityManager em;

	@InjectMocks
	private BatDao batDao;

	@InjectMocks
	private Vtc06Handler vtc06Handler = new Vtc06Handler();

	@BeforeEach
	void setUp() {
		batDao = Mockito.spy(new BatDao());
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void getDataFromOneRecordCorrectie() {
		ProgressReporter progressReporter = new ProgressReporter(thlDao);
		progressReporter.reportStart("1");
		// dit komt binnen
		String voorlooprecord = HERKOMST + FUNCTIE ;
		String[] messageInfo = new String[]{voorlooprecord};

		Object[] objs = new Object[] {123456789, "2021", "VPB", 1, 1234, 123};
		List<Object[]> mockObjects = Collections.singletonList(objs);

		when(correctieQuery.getResultList()).thenReturn(mockObjects);
		when(specificatieQuery.getResultList()).thenReturn(Collections.emptyList());
		doReturn("SCHEMA").when(batDao).getCurrentSchema();
		when(em.createNativeQuery(eq("CALL SCHEMA.GET_CORRECTIES()"))).thenReturn(correctieQuery);
		when(em.createNativeQuery(eq("CALL SCHEMA.GET_SPECIFICATIES()"))).thenReturn(specificatieQuery);

		List<String> data = vtc06Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");

		assertNotNull(data);
		String corRecord = "1234567892021VPB                             00000000010000000000000123400000000000000123               ";
		assertEquals(vtc06Handler.getAnswerRecordLength(), corRecord.length());
		assertEquals(1, data.size());
		String responseVoorloopRecord = String.format("%s", HERKOMST+FUNCTIE+"001"+"001"+"00" + spaces(87) + LINEFEED);
		String responseRecord = corRecord + LINEFEED;
		assertEquals(responseVoorloopRecord + responseRecord , data.get(0));
	}

	@Test
	void getDataFromOneRecordCorrectieWithNegativeAmount() {
		ProgressReporter progressReporter = new ProgressReporter(thlDao);
		progressReporter.reportStart("1");
		// dit komt binnen
		String voorlooprecord = HERKOMST + FUNCTIE ;
		String[] messageInfo = new String[]{voorlooprecord};

		Object[] objs = new Object[] {123456789, "2021", "VPB", 1, 1234, -123};
		List<Object[]> mockObjects = Collections.singletonList(objs);

		when(correctieQuery.getResultList()).thenReturn(mockObjects);
		when(specificatieQuery.getResultList()).thenReturn(Collections.emptyList());
		doReturn("SCHEMA").when(batDao).getCurrentSchema();
		when(em.createNativeQuery(eq("CALL SCHEMA.GET_CORRECTIES()"))).thenReturn(correctieQuery);
		when(em.createNativeQuery(eq("CALL SCHEMA.GET_SPECIFICATIES()"))).thenReturn(specificatieQuery);

		List<String> data = vtc06Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");

		assertNotNull(data);
		String corRecord = "1234567892021VPB                             000000000100000000000001234-0000000000000123               ";
		assertEquals(vtc06Handler.getAnswerRecordLength(), corRecord.length());
		assertEquals(1, data.size());
		String responseVoorloopRecord = String.format("%s", HERKOMST+FUNCTIE+"001"+"001"+"00" + spaces(87) + LINEFEED);
		assertEquals(responseVoorloopRecord + corRecord + LINEFEED , data.get(0));
	}
	@Test
	void getDataFromOneSpecificatieRecord() {
		ProgressReporter progressReporter = new ProgressReporter(thlDao);
		progressReporter.reportStart("1");
		// dit komt binnen
		String voorlooprecord = HERKOMST + FUNCTIE ;
		String[] messageInfo = new String[]{voorlooprecord};

		Object[] objs = new Object[] {123456789, "2021", "VPB", 1, "SpecCode", -123};
		List<Object[]> mockObjects = Collections.singletonList(objs);

		when(correctieQuery.getResultList()).thenReturn(Collections.emptyList());
		when(specificatieQuery.getResultList()).thenReturn(mockObjects);
		doReturn("SCHEMA").when(batDao).getCurrentSchema();
		when(em.createNativeQuery(eq("CALL SCHEMA.GET_CORRECTIES()"))).thenReturn(correctieQuery);
		when(em.createNativeQuery(eq("CALL SCHEMA.GET_SPECIFICATIES()"))).thenReturn(specificatieQuery);

		List<String> data = vtc06Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");

		assertNotNull(data);
		String corRecord = "1234567892021VPB                             0000000001SpecCode                        -0000000000000123";
		assertEquals(vtc06Handler.getAnswerRecordLength(), corRecord.length());
		assertEquals(1, data.size());
		String responseVoorloopRecord = String.format("%s", HERKOMST+FUNCTIE+"001"+"001"+"00" + spaces(87) + LINEFEED);
		String responseRecord = corRecord + LINEFEED;
		assertEquals(responseVoorloopRecord + responseRecord , data.get(0));
	}

	@Test
	void aUnitTestThatChecksIfActualSizeOfAnMqMessageIsMaxFourMegabytesOrSomeExceptionIsProperlyHandledWhenWeExceedThisLimit() {
		// TODO IVATHL-85 IVATHL-97 do this some day
	}
}