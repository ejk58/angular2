package nl.belastingdienst.iva.wd.thl.mq.handler;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.dao.OrgDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

@ExtendWith(MockitoExtension.class)
class Atk05HandlerTest {

	@Mock
	private ThlDao thlDao;

	@Mock
	private OrgDao orgDao;

	@InjectMocks
	private final Atk05Handler atk05Handler = new Atk05Handler();

	@Test
	void getSmallDataSetTest() {
		ProgressReporter progressReporter = new ProgressReporter(thlDao);
		progressReporter.reportStart("1");
		String[] messageInfo = new String[] {
				"TGL-ATK05     "
				, "20210101000000"
		};
		List<String> mockData = Arrays.asList(
				String.format("%09d%05d%05d", 111, 11, 1),
				String.format("%09d%05d%05d", 222, 22, 2),
				String.format("%09d%05d%05d", 333, 33, 3),
				String.format("%09d%05d%05d", 444, 44, 4)
		);
		when(orgDao.getOrgChangesSince(any(Date.class))).thenReturn(mockData);
		List<String> data = atk05Handler.getData(Arrays.asList(messageInfo), progressReporter, "\n");
		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals("TGL-ATK0500        \n0000001110001100001\n0000002220002200002\n0000003330003300003\n0000004440004400004\n", data.get(0));
	}

	@Test
	void getSmallDataSetTestWithDifferentLineEnding() {
		ProgressReporter progressReporter = new ProgressReporter(thlDao);
		progressReporter.reportStart("1");
		String[] messageInfo = new String[] {
				"TGL-ATK05     "
				, "20210101000000"
		};
		List<String> mockData = Arrays.asList(
				String.format("%09d%05d%05d", 111, 11, 1),
				String.format("%09d%05d%05d", 222, 22, 2),
				String.format("%09d%05d%05d", 333, 33, 3),
				String.format("%09d%05d%05d", 444, 44, 4)
		);
		when(orgDao.getOrgChangesSince(any(Date.class))).thenReturn(mockData);
		List<String> data = atk05Handler.getData(Arrays.asList(messageInfo), progressReporter, "\r\n");
		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals("TGL-ATK0500        \r\n0000001110001100001\r\n0000002220002200002\r\n0000003330003300003\r\n0000004440004400004\r\n", data.get(0));
	}

	@Test
	@SuppressWarnings("java:S3415")
	void checkAnswerRecordLengthTest() {
		assertEquals(19, Atk05Handler.ANSWER_RECORD_LENGTH);
	}

	@Test
	@SuppressWarnings("java:S3415")
	void getRequestRecordLength() {
		assertEquals(14, Atk05Handler.REQUEST_RECORD_LENGTH);
	}
}