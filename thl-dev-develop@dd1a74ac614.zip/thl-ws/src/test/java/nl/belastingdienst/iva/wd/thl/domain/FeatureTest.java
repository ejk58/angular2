package nl.belastingdienst.iva.wd.thl.domain;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FeatureTest {

	private Feature sut;

	@BeforeEach
	void setUp() {
		sut = new Feature();
	}

	@Test
	void toggle_ShouldSetEnabledSinceToNull_WhenDisablingFeature() {
		sut.setEnabledSince(new Date());

		sut.toggle();

		assertNull(sut.getEnabledSince());
	}

	@Test
	void toggle_ShouldSetEnabledSinceToCurrentTime_WhenEnablingFeature() {
		sut.setEnabledSince(null);

		Date startTime = new Date();
		sut.toggle();
		Date endTime = new Date();

		assertNotNull(sut.getEnabledSince());
		assertFalse(startTime.after(sut.getEnabledSince()));
		assertFalse(endTime.before(sut.getEnabledSince()));
	}

	@Test
	void isEnabled_ShouldReturnFalse_WhenEnabledSinceIsNull() {
		sut.setEnabledSince(null);

		assertFalse(sut.isEnabled());
	}

	@Test
	void isEnabled_ShouldReturnFalse_WhenEnabledSinceIsInTheFuture() {
		Date oneSecondFromNow = new Date(new Date().getTime() + 1_000);
		sut.setEnabledSince(oneSecondFromNow);

		assertFalse(sut.isEnabled());
	}

	@Test
	void isEnabled_ShouldReturnTrue_WhenEnabledSinceIsNow() {
		Date now = new Date();
		sut.setEnabledSince(now);

		assertTrue(sut.isEnabled());
	}

	@Test
	void isEnabled_ShouldReturnTrue_WhenEnabledSinceIsInThePast() {
		Date oneSecondAgo = new Date(new Date().getTime() - 1_000);
		sut.setEnabledSince(oneSecondAgo);

		assertTrue(sut.isEnabled());
	}
}