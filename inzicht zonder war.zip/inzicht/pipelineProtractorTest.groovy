@Library("GENERIC") _
    pipelineProtractorTest {
			project = "inzicht"
			pipelineTrigger = [cron('H 12,21 * * 1-5')]
    }