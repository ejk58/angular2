  @Library("GENERIC") _
    pipelineCode_v3 {
	deploymentId = "inzicht"
	integrationPipeline = "inzicht-test"
	environmentChoices = "ont\ntst\nacc"
	streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
    }
    
    
 
