# Inzicht 
Make sure the following is not set in your Windows environment:

* Node or NPM should not be on the path
* SASS-BINARY should not be set as env var
* Maven should be version 3.3.9 or higher

To build:

`mvn clean install`

Starting front-end development with (back-end should be deployed on localhost:4200/inzicht):

`npm start`


