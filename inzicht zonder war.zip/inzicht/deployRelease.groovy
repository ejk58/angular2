@Library("GENERIC") _
    pipelineDeployArtifactFromNexus {
	deploymentId = "inzicht"
	integrationPipeline = "inzicht-test"
	packageChoices = "inzicht"
	applicationVersionChoices = "3.22.0\n3.21.0\n3.20.0\n3.19.0\n3.18.1"
	asVersionChoices = "n.v.t"
	environmentChoices = "tst\nont\nacc\nprd"
	streetChoices = "str11/productie\nstr12/opleiding\nstr13\nstr14"
}
