#!/bin/bash -x
basenamespace=$1
jenkinsNamespace=$2

# Check env.sh for the namespace and the branch
namespace=${basenamespace}

if [ "${basenamespace}" == "" ]; then
	echo "Je moet basenamespace (ofwel project naam) meegeven"
  exit
fi

if [ "${jenkinsNamespace}" == "" ]; then
	echo "Je moet je jenkins openshift projectnaam ( iets van wd-build-..) meegeven"
  exit
else
	if [ "$(oc get projects -o name | cut -d'/' -f2 | grep -w ${jenkinsNamespace})" == "" ]; then
		echo "De opgegeven jenkins openshift projectnaam bestaat niet, we kennen wel deze "; echo "$(oc get projects -o name | cut -d'/' -f2 | grep  'wd-build-')"
		exit
	fi
fi

echo stage 'Check or Create Namespace'
if [  "$( oc get project/${basenamespace} ; echo $? )" == "1"  ]; then 
  oc new-project "${namespace}" "--description= ${basenamespace}" "--display-name=${basenamespace} "
else 
  echo "Het project ${namespace} bestaat reeds"
fi
oc label namespace ${namespace} dcs.itsmoplosgroep=IVA01000 --overwrite
oc -n ${namespace} apply -f base/wd-rolebinding-alle-teamleden.yaml
oc policy add-role-to-user edit system:serviceaccount:${jenkinsNamespace}:jenkins -n ${namespace}
oc import-image registry.chp.belastingdienst.nl/redhatio/openjdk-11-rhel7:latest --confirm -n ${namespace}

##oc get secret webdevelopment-robot-pull-secret -n wd-pastebin -o yaml | sed 's/namespace: wd-pastebin/namespace: wd-build-team3/g' | oc create -f -
oc -n ${namespace} apply -f base/wd-robot-pull-secret.yaml
oc secrets link default webdevelopment-robot-pull-secret --for=pull -n ${namespace}
oc secrets link builder webdevelopment-robot-pull-secret -n ${namespace}


