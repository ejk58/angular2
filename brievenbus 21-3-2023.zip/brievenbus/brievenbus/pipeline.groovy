pipelineCode_openshift_v4c {
    deploymentId = "iva-brievenbus"
    integrationPipeline = ""
    environmentChoices = "ont\ntst\nacc"
    streetChoices = "1\n2\n3\n4\n5\n6\n"
    vervangenOpenjdk11Image = true
    mvnVersion = "maven36-openjdk11"
    nodeVersion = "nodejs16"
    gitopsRepo = "ivab/brievenbus-deploy.git"
    skipSonar = true
    vervangenOpenshiftObjects = true
}