package nl.belastingdienst.iva.wd.brievenbus.domain;

import java.time.LocalDateTime;
import java.util.UUID;

public class DeliveryBuilder {

    public static Delivery buildBasicDelivery(UUID uuid) {
        Delivery delivery = new Delivery();
        delivery.setUuid(uuid);
        delivery.setSender("sende01");
        LocalDateTime created = LocalDateTime.now();
        delivery.setCreated(created);
        delivery.setExpiration(created.plusWeeks(2));
        return delivery;
    }

    public static Delivery buildCompleteDelivery(UUID uuid) {
        Delivery delivery = DeliveryBuilder.buildBasicDelivery(uuid);
        delivery.setReceivers(ReceiverBuilder.buildReceiverList("recei01", "recei02"));

        File file = new File();
        delivery.setFile(file);
        return delivery;
    }

    public static Delivery buildCompleteDelivery(String uuid, String filename) {
        Delivery delivery = DeliveryBuilder.buildBasicDelivery(UUID.fromString(uuid));
        delivery.setReceivers(ReceiverBuilder.buildReceiverList("recei01", "recei02"));

        File file = new File();
        file.setName(filename);
        delivery.setFile(file);
        return delivery;
    }

    public static Delivery buildCompleteDeliveryAlsoWithMailboxReceivers(String uuid, String filename) {
        Delivery delivery = DeliveryBuilder.buildBasicDelivery(UUID.fromString(uuid));
        delivery.setReceivers(ReceiverBuilder.buildReceiverList("recei01", "recei02", "mailbox1", "mailbox2"));

        File file = new File();
        file.setName(filename);
        delivery.setFile(file);
        return delivery;
    }

    public static Delivery buildExpiredDelivery(UUID uuid) {
        Delivery delivery = DeliveryBuilder.buildCompleteDelivery(uuid);
        delivery.setExpiration(delivery.getExpiration().minusWeeks(3));
        return delivery;
    }

}
