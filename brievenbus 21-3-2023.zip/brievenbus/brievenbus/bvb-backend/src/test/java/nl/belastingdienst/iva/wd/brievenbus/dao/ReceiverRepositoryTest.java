package nl.belastingdienst.iva.wd.brievenbus.dao;

import java.util.Optional;
import java.util.stream.StreamSupport;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapAdpClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityUtils;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

@RunWith(SpringRunner.class)
@DataJpaTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ReceiverRepositoryTest {

    @MockBean
    LdapAdpClient ldapAdpClient;

    @MockBean
    LdapDwbClient ldapDwbClient;

    @MockBean
    LdapContextSource ldapContextSource;

    @MockBean
    AuditService auditService;

    @MockBean
    SecurityUtils securityUtils;

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private ReceiverRepository receiverRepository;

    @Before
    public void setup() {
        Receiver receiver1 = new Receiver();
        receiver1.setUserid("user1");
        receiver1.setId(1L);
        entityManager.persist(receiver1);

        Receiver receiver2 = new Receiver();
        receiver2.setUserid("user2");
        receiver2.setId(2L);
        entityManager.persist(receiver2);

        entityManager.flush();
    }

    @Test
    public void testFindExistingReceivers() {
        // when
        Optional<Receiver> found1 = receiverRepository.findById(1L);
        Receiver receiver1Found = found1.get();
        Optional<Receiver> found2 = receiverRepository.findById(2L);
        Receiver receiver2Found = found2.get();

        // then
        Assert.assertTrue(receiver1Found.getUserid().equals("user1"));
        Assert.assertTrue(receiver2Found.getUserid().equals("user2"));
    }

    @Test
    public void testCheckNumberOfReceivers() {
        // when
        Iterable<Receiver> receivers = receiverRepository.findAll();

        // then
        Assert.assertEquals(2, StreamSupport.stream(receivers.spliterator(), false).count());
    }

    @Test
    public void testUnknownReceiverShouldNotBeFound() {
        Optional<Receiver> found3 = receiverRepository.findById(3L);

        // then
        Assert.assertFalse(found3.isPresent());
    }

    @Test
    public void testReceiverDataCanBeChanged() {
        // when
        Optional<Receiver> found1 = receiverRepository.findById(1L);
        Receiver receiver1Found = found1.get();
        receiver1Found.setUserid("changedUser1");
        receiverRepository.save(receiver1Found);

        // then
       Assert.assertTrue(receiver1Found.getUserid().equals("changedUser1"));
    }

    @Test
    public void testReceiverDataCanBeDeleted() {

        // precondition
        Iterable<Receiver> receivers = receiverRepository.findAll();
        Assert.assertEquals(2, StreamSupport.stream(receivers.spliterator(), false).count());

        // when
        Optional<Receiver> found1 = receiverRepository.findById(1L);
        Receiver receiver1Found = found1.get();
        receiverRepository.delete(receiver1Found);

        // then
        Iterable<Receiver> receiversAfterDelete = receiverRepository.findAll();
        Assert.assertEquals(1, StreamSupport.stream(receiversAfterDelete.spliterator(), false).count());
    }

}
