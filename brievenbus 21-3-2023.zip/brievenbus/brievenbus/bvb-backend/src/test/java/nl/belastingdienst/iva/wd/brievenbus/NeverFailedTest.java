package nl.belastingdienst.iva.wd.brievenbus;

import org.junit.Assert;
import org.junit.Test;

public class NeverFailedTest {

    @Test
    public void neverFailedTest() {
        Assert.assertTrue(true);
    }
}