package nl.belastingdienst.iva.wd.brievenbus.dao;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapAdpClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.DeliveryBuilder;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityUtils;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.UUID;
import java.util.stream.StreamSupport;

@RunWith(SpringRunner.class)
@DataJpaTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class DeliveryRepositoryTest {

    @MockBean
    LdapAdpClient ldapAdpClient;

    @MockBean
    LdapDwbClient ldapDwbClient;

    @MockBean
    LdapContextSource ldapContextSource;

    @MockBean
    AuditService auditService;

    @MockBean
    SecurityUtils securityUtils;

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private DeliveryRepository deliveryRepository;

    @Before
    public void setup() {
        Delivery delivery = DeliveryBuilder.buildBasicDelivery(UUID.fromString("db5582d9-444a-4451-957b-33a22168a094"));
        entityManager.persist(delivery);
        Delivery delivery2 = DeliveryBuilder.buildBasicDelivery(UUID.fromString("db5582d9-444a-4451-957b-33a22168a022"));
        entityManager.persist(delivery2);

        entityManager.flush();
    }

    @Test
    public void findExistingDelivery() {
        // when
        Delivery delivery = deliveryRepository.findFirstByUuid(UUID.fromString("db5582d9-444a-4451-957b-33a22168a094"));

        // then
        Delivery deliveryNew = DeliveryBuilder.buildBasicDelivery(UUID.fromString("db5582d9-444a-4451-957b-33a22168a094"));
        Assert.assertTrue(delivery.getUuid().toString().equals("db5582d9-444a-4451-957b-33a22168a094"));
        Assert.assertTrue(delivery.getCreated().getDayOfYear() == deliveryNew.getCreated().getDayOfYear());
        Assert.assertTrue(delivery.getExpiration().getDayOfYear() == deliveryNew.getExpiration().getDayOfYear());
    }

    @Test
    public void testCheckNumberOfDeliveries() {
        // when
        Iterable<Delivery> deliveries = deliveryRepository.findAll();

        // then
        Assert.assertEquals(2, StreamSupport.stream(deliveries.spliterator(), false).count());
    }

    @Test
    public void testUnknownDeliveryShouldNotBeFound() {
        Delivery delivery = deliveryRepository.findFirstByUuid(UUID.fromString("db5582d9-444a-4451-957b-33a22168a999"));

        // then
        Assert.assertNull(delivery);
    }

    @Test
    public void testDeliveryDataCanBeChanged() {
        // when
        Delivery delivery = deliveryRepository.findFirstByUuid(UUID.fromString("db5582d9-444a-4451-957b-33a22168a094"));
        delivery.setUuid(UUID.fromString("db5582d9-444a-4451-957b-33a22168a888"));
        deliveryRepository.save(delivery);

        // then
        delivery = deliveryRepository.findFirstByUuid(UUID.fromString("db5582d9-444a-4451-957b-33a22168a094"));
        Assert.assertNull(delivery);
        delivery = deliveryRepository.findFirstByUuid(UUID.fromString("db5582d9-444a-4451-957b-33a22168a888"));
        Assert.assertTrue(delivery.getUuid().toString().equals("db5582d9-444a-4451-957b-33a22168a888"));
    }

    @Test
    public void testDeliveryDataCanBeDeleted() {

        // precondition
        Iterable<Delivery> deliveries = deliveryRepository.findAll();
        Assert.assertEquals(2, StreamSupport.stream(deliveries.spliterator(), false).count());

        // when
        Delivery delivery = deliveryRepository.findFirstByUuid(UUID.fromString("db5582d9-444a-4451-957b-33a22168a094"));
        deliveryRepository.delete(delivery);

        // then
        Iterable<Delivery> deliveriesAfterDelete = deliveryRepository.findAll();
        Assert.assertEquals(1, StreamSupport.stream(deliveriesAfterDelete.spliterator(), false).count());
    }

}
