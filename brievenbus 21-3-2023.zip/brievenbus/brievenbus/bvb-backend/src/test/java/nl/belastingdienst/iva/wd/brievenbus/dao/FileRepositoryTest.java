package nl.belastingdienst.iva.wd.brievenbus.dao;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapAdpClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import nl.belastingdienst.iva.wd.brievenbus.domain.FileBuilder;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityUtils;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;
import java.util.stream.StreamSupport;

@RunWith(SpringRunner.class)
@DataJpaTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class FileRepositoryTest {

    @MockBean
    LdapAdpClient ldapAdpClient;

    @MockBean
    LdapDwbClient ldapDwbClient;

    @MockBean
    LdapContextSource ldapContextSource;

    @MockBean
    AuditService auditService;

    @MockBean
    SecurityUtils securityUtils;

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private FileRepository fileRepository;

    @Before
    public void setup() {
        File file1 = FileBuilder.buildFile(1);
        entityManager.persist(file1);

        File file2 = FileBuilder.buildFile(2);
        entityManager.persist(file2);

        entityManager.flush();
    }

    @Test
    public void testFindExistingFiles() {
        // when
        Optional<File> found1 = fileRepository.findById(1L);
        File file1Found = found1.get();
        Optional<File> found2 = fileRepository.findById(2L);
        File file2Found = found2.get();

        // then
        Assert.assertTrue(FileBuilder.buildFile(1).toString().equals(file1Found.toString()));
        Assert.assertTrue(FileBuilder.buildFile(2).toString().equals(file2Found.toString()));
    }

    @Test
    public void testCheckNumberOfFiles() {
        // when
        Iterable<File> files = fileRepository.findAll();

        // then
        Assert.assertEquals(2, StreamSupport.stream(files.spliterator(), false).count());
    }

    @Test
    public void testUnknownFileShouldNotBeFound() {
        Optional<File> found3 = fileRepository.findById(3L);

        // then
        Assert.assertFalse(found3.isPresent());
    }

    @Test
    public void testFileDataCanBeChanged() {
        // when
        Optional<File> found1 = fileRepository.findById(1L);
        File file1Found = found1.get();
        file1Found.setName("changedFilename1");
        fileRepository.save(file1Found);

        // then
        Assert.assertTrue(file1Found.getName().equals("changedFilename1"));
    }

    @Test
    public void testFileDataCanBeDeleted() {

        // precondition
        Iterable<File> files = fileRepository.findAll();
        Assert.assertEquals(2, StreamSupport.stream(files.spliterator(), false).count());

        // when
        Optional<File> found1 = fileRepository.findById(1L);
        File file1Found = found1.get();
        fileRepository.delete(file1Found);

        // then
        Iterable<File> filesAfterDelete = fileRepository.findAll();
        Assert.assertEquals(1, StreamSupport.stream(filesAfterDelete.spliterator(), false).count());
    }

}
