package nl.belastingdienst.iva.wd.brievenbus.domain;

import java.util.ArrayList;
import java.util.List;

import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;

public class ReceiverBuilder {

    public static List<Receiver> buildReceiverList(String... receiverIds) {
        List<Receiver> receiverList = new ArrayList<>();
        for (String receiverId: receiverIds) {
            Receiver receiver = new Receiver();
            receiver.setUserid(receiverId);
            receiverList.add(receiver);
        }
        return receiverList;
    }

    public static List<ReceiverJson> buildReceiverJsonList(String... receiverIds) {
        List<ReceiverJson> receiverJsonList = new ArrayList<>();
        for (String receiverId : receiverIds) {
            ReceiverJson receiverJson = new ReceiverJson();
            receiverJson.setId((receiverId));
            receiverJson.setName(receiverId + "Name");
            receiverJson.setEmail(receiverId + "@test.com");
            receiverJson.setType("PERSON");
            receiverJsonList.add(receiverJson);
        }
        return receiverJsonList;
    }

    public static String buildIvaTestReceiverJson(int i) {
        return createReceiverJson("ivatest" + i, "ivatest" + i + "@test.com", "ivatest" + i + "Name");
    }

    private static String createReceiverJson(String id, String email, String name) {
        return "{" +
                "\"id\": \"" + id + "\"," +
                "\"email\": \"" + email + "\"," +
                "\"name\": \"" + name + "\"," +
                "\"type\": \"PERSON\"" +
                "}";
    }

}
