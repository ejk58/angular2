package nl.belastingdienst.iva.wd.brievenbus.controller;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.FileRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.ReceiverRepository;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;
import nl.belastingdienst.iva.wd.brievenbus.domain.ReceiverBuilder;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import nl.belastingdienst.iva.wd.brievenbus.service.FileService;
import nl.belastingdienst.iva.wd.brievenbus.service.MailService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.PersistenceException;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(UploadController.class)
public class UploadControllerTest {
    private static final String API_UPLOAD = "/api/upload/offer";

    @MockBean
    LdapContextSource ldapContextSource;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private DeliveryRepository deliveryRepository;

    @MockBean
    MailService mailService;

    @MockBean
    private FileRepository fileRepository;

    @MockBean
    private ReceiverRepository receiverRepository;

    @MockBean
    private FileService fileService;

    private MockMultipartFile uploadFile;

    @Before
    public void setup() {
        uploadFile = new MockMultipartFile("file", "README.txt", "text/plain", "README.txt".getBytes());
    }

    @Test
    @WithMockUser
    public void testUploadWithMissingParameter() throws Exception {
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile))
                .andExpect(content().string("{\"message\":\"Required request parameter 'receivers' for method parameter type List is not present\"}"))
                .andExpect(status().is(HttpStatus.INTERNAL_SERVER_ERROR.value()));

        verify(deliveryRepository, times(0)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(String.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class));

    }

    @Test
    @WithMockUser
    public void testUploadWithTooManyReceivers() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1),
                        ReceiverBuilder.buildIvaTestReceiverJson(2),
                        ReceiverBuilder.buildIvaTestReceiverJson(3),
                        ReceiverBuilder.buildIvaTestReceiverJson(4),
                        ReceiverBuilder.buildIvaTestReceiverJson(5),
                        ReceiverBuilder.buildIvaTestReceiverJson(6)))
                .andExpect(content().string("{\"error\": \"max 5 receivers\"}"))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value())).andReturn();

        verify(deliveryRepository, times(0)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(String.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class));
    }

    @Test
    @WithMockUser
    public void testWritingOfFileToFileSystemGoesWrong() throws Exception {
        Mockito.doThrow(new UnprocessableException("Er is iets misgegaan bij het schrijven van de file")).when(fileService).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(String.class));
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", "{}"))
                .andExpect(content().string("{\"message\":\"Er is iets misgegaan bij het schrijven van de file\"}"))
                .andExpect(status().is(HttpStatus.UNPROCESSABLE_ENTITY.value()));
        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(1)).save(any(File.class));
        verify(receiverRepository, times(1)).save(any(Receiver.class));
        verify(fileService, times(1)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(String.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithErrorOnSavingDelivery() throws Exception {
        when(deliveryRepository.save(any(Delivery.class))).thenThrow(new PersistenceException());
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", "{}"))
                .andExpect(content().string("{\"message\":\"Opslaan van delivery is niet gelukt\"}"))
                .andExpect(status().is(HttpStatus.UNPROCESSABLE_ENTITY.value()));
        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(String.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithErrorOnSavingReceiver() throws Exception {
        when(receiverRepository.save(any(Receiver.class))).thenThrow(new PersistenceException());
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", "{}"))
                .andExpect(content().string("{\"message\":\"Opslaan van receiver is niet gelukt\"}"))
                .andExpect(status().is(HttpStatus.UNPROCESSABLE_ENTITY.value()));
        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(1)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(String.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithErrorOnSavingFileMetadata() throws Exception {
        when(fileRepository.save(any(File.class))).thenThrow(new PersistenceException());
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", "{}"))
                .andExpect(content().string("{\"message\":\"Opslaan van file is niet gelukt\"}"))
                .andExpect(status().is(HttpStatus.UNPROCESSABLE_ENTITY.value()));
        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(1)).save(any(File.class));
        verify(receiverRepository, times(1)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(String.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class));
    }

    @Test
    @WithMockUser
    public void testValidUploadWith2Receivers() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1),
                        ReceiverBuilder.buildIvaTestReceiverJson(2)))
                .andExpect(status().isOk()).andReturn();

        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(1)).save(any(File.class));
        verify(receiverRepository, times(2)).save(any(Receiver.class));
        verify(fileService, times(1)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(String.class));
        verify(mailService, times(1)).createAndSendMail(any(Delivery.class), any(List.class));

        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Bestand goed verwerkt!"));
    }

}
