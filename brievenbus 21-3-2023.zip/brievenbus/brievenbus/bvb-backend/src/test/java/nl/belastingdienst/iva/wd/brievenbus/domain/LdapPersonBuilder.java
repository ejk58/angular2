package nl.belastingdienst.iva.wd.brievenbus.domain;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;

public class LdapPersonBuilder {

	public static LdapPerson buildLdapPersonFromReceiverJson(ReceiverJson receiverJson) {
		LdapPerson ldapPerson = new LdapPerson();
		ldapPerson.setUserId(receiverJson.getId());
		ldapPerson.setEmail(receiverJson.getEmail());
		return ldapPerson;
	}

}
