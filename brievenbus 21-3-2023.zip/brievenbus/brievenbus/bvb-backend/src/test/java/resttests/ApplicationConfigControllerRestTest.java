package resttests;

import org.springframework.http.HttpStatus;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class ApplicationConfigControllerRestTest {

    private static final String BASE_PATH = "/api/application/configuration";

    private static final String APPLICATION_PLATFORM = "ADP";

    @BeforeMethod
    public void setup() {
        RestUtils.setBaseURI(RestConstants.BASE_ADP_URI);
        RestUtils.setBasePort(RestConstants.PORT);
        RestUtils.setBasePath(BASE_PATH);
        RestUtils.setContentType(RestConstants.HEADER);
        RestUtils.setRelaxedHTTPSValidation();
    }

    @AfterMethod
    public void afterTest() {
        RestUtils.resetBaseURI();
        RestUtils.resetBasePort();
        RestUtils.resetBasePath();
    }

    @Test
    @Ignore
    public void get_application_platform_config() {
        String response = given()
                .when()
                .get()
                .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
                .extract()
                .asString();

        assert response.equals("{\"applicationPlatform\": \"" + APPLICATION_PLATFORM + "\"}");
    }

}
