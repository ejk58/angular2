package resttests;

public class RestHelperMethods {
}