package nl.belastingdienst.iva.wd.brievenbus.security;

public class SecurityConstants {

    private SecurityConstants() {
    }

    public static final String SECRET = "SecretKeyToGenJWTs";
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_AUTHORIZATION = "Authorization";
    public static final String APPLICATION_PLATFORM = "applicationPlatform";
}
