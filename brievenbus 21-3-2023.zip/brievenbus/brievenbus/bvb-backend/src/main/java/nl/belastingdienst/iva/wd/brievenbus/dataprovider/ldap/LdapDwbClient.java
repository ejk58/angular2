package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;

@Component
public class LdapDwbClient extends LdapClient {

	private static final String USERID4CHARS = "^[A-Za-z]{5}\\d{2}$";
	private static final String USERID3CHARS = "^[A-Za-z]{3}0[A-Za-z]\\d{2}$";
	private static final String USERID2CHARS = "^[A-Za-z]{2}00[A-Za-z]\\d{2}$";
	private static final String USERID1CHARS = "^[A-Za-z]000[A-Za-z]\\d{2}$";
	private static final String OR = "|";

	private final Pattern userIdPattern = Pattern.compile(USERID4CHARS + OR + USERID3CHARS + OR + USERID2CHARS + OR + USERID1CHARS);

	@Value("${ldap.dwb.partitionSuffix}")
	private String ldapDwbPartitionSuffix;

    @Override
	public LdapPerson getPerson(String userId) {
		return super.getPersonByUserId(userId, ldapDwbPartitionSuffix);
	}

	@Override
	public void authenticateInLdap(ApplicationUser user) {
		super.authenticate(user, ldapDwbPartitionSuffix);
	}

	public List<LdapPerson> getPersonsWithMail(String userIdOrName) {
		boolean isUserId = this.userIdPattern.matcher(userIdOrName).matches();
		if (isUserId) {
			LdapPerson person = getPersonWithMailByUserId(userIdOrName);
			return person != null ? Collections.singletonList(person) : new ArrayList<>();
		}
		return filterAndSortPersons(getPersonsWithMailByLastName(userIdOrName));
	}

	private LdapPerson getPersonWithMailByUserId(String userId) {
		LdapQuery query = query()
				.searchScope(SearchScope.SUBTREE)
				.timeLimit(3000)
				.base(ldapDwbPartitionSuffix)
				.where("objectclass").is("person")
				.and("cn").is(userId)
				.and("mail").isPresent();
		List<LdapPerson> persons = this.ldapTemplate.search(query, new LdapPersonAttributesMapper());
		return (persons == null || persons.isEmpty()) ? null : persons.get(0);
	}

	private List<LdapPerson> getPersonsWithMailByLastName(String lastName) {
		LdapQuery query = query()
				.searchScope(SearchScope.SUBTREE)
				.timeLimit(3000)
				.base(ldapDwbPartitionSuffix)
				.where("objectclass").is("person")
				.and(query().where("sn").like(lastName + "*").or("sn").like("* " + lastName + "*"))
				.and("mail").isPresent();
		return this.ldapTemplate.search(query, new LdapPersonAttributesMapper());
	}

	private List<LdapPerson> filterAndSortPersons(List<LdapPerson> ldapPersons) {
		return ldapPersons.stream()
				.filter(person -> this.userIdPattern.matcher(person.getUserId()).matches())
				.sorted(Comparator
						.comparing(LdapPerson::getLastName, String::compareToIgnoreCase)
						.thenComparing(LdapPerson::getFirstName, Comparator.nullsFirst(String::compareToIgnoreCase)))
				.collect(Collectors.toList());
	}

}
