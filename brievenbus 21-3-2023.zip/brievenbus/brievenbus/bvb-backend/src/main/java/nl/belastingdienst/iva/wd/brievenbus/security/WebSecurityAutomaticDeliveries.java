package nl.belastingdienst.iva.wd.brievenbus.security;

import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

import nl.belastingdienst.iva.wd.brievenbus.filter.AuthorizationFilter;
import nl.belastingdienst.iva.wd.brievenbus.filter.FilterExceptionHandlerFilter;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

/**
 * The @Order must be LOWER than the one for {@link WebSecurity} because
 * checking the security for automatic deliveries must be done first.
 */
@EnableWebSecurity
@Order(1)
public class WebSecurityAutomaticDeliveries extends WebSecurityConfigurerAdapter {

	private final Environment env;
	private final JwtUtils jwtUtils;
	private final SecurityUtils securityUtils;
	private final HandlerExceptionResolver handlerExceptionResolver;
	private final AuditService auditService;

	public WebSecurityAutomaticDeliveries(Environment env, JwtUtils jwtUtils, SecurityUtils securityUtils,
			HandlerExceptionResolver handlerExceptionResolver, AuditService auditService) {
		this.env = env;
		this.jwtUtils = jwtUtils;
		this.securityUtils = securityUtils;
		this.handlerExceptionResolver = handlerExceptionResolver;
		this.auditService = auditService;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.antMatcher("/api/upload/offer/automatic")
			.cors().and().csrf().disable()
			.authorizeRequests()
			.anyRequest().authenticated()
			.and()
			.addFilterBefore(new FilterExceptionHandlerFilter(handlerExceptionResolver), LogoutFilter.class)
			.addFilter(new BasicAuthenticationFilter(authenticationManager()))
			.addFilterAfter(new AuthorizationFilter(env, jwtUtils, auditService), BasicAuthenticationFilter.class)
			// this disables session creation on Spring Security
			.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

		// This option is needed to enable the h2 console
		http.headers().frameOptions().sameOrigin();
	}

	@Override
	public void configure(AuthenticationManagerBuilder authManBuilder) throws Exception {
		authManBuilder.authenticationProvider(new LdapAuthenticationProvider(securityUtils));
	}

}
