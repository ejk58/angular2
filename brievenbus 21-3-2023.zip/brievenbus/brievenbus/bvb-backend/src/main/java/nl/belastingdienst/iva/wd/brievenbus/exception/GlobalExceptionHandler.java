package nl.belastingdienst.iva.wd.brievenbus.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import nl.belastingdienst.iva.wd.brievenbus.domain.exception.ErrorResponse;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.JWTInvalidException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.NotFoundException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnauthorizedException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.ValidationException;
import nl.belastingdienst.iva.wd.brievenbus.filter.FilterExceptionHandlerFilter;

/**
 * Class that handles errors that occur in a controller or in a filter.
 * It handles errors in controllers because it is annotated with '@ControllerAdvice'.
 * It handles errors in filters because of the filter {@link FilterExceptionHandlerFilter}.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LogManager.getLogger(GlobalExceptionHandler.class);

    // General exception handling
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(Exception exception) {
        return createErrorResponse(exception, HttpStatus.INTERNAL_SERVER_ERROR, true);
    }

    // Validation exception handling
    @ExceptionHandler(ValidationException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(ValidationException exception) {
        return createErrorResponse(exception, HttpStatus.PRECONDITION_FAILED, false);
    }

    // NotFound exception handling
    @ExceptionHandler(NotFoundException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(NotFoundException exception) {
        return createErrorResponse(exception, HttpStatus.NOT_FOUND, false);
    }

    // Unprocessable exception handling
    @ExceptionHandler(UnprocessableException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(UnprocessableException exception) {
        return createErrorResponse(exception, HttpStatus.UNPROCESSABLE_ENTITY, true);
    }

    // JWTInvalid exception handling
    @ExceptionHandler(JWTInvalidException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(JWTInvalidException exception) {
        return createErrorResponse(exception, HttpStatus.UNAUTHORIZED, true);
    }

    // Unauthorized exception handling
    @ExceptionHandler(UnauthorizedException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(UnauthorizedException exception) {
        return createErrorResponse(exception, HttpStatus.UNAUTHORIZED, false);
    }

    // AccessDenied exception handling
    @ExceptionHandler(AccessDeniedException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(AccessDeniedException exception) {
        return createErrorResponse(exception, HttpStatus.UNAUTHORIZED, false);
    }

    // MaxUploadSizeExceeded exception handling
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleErrors(MaxUploadSizeExceededException exception) {
        return createErrorResponse(exception, HttpStatus.PAYLOAD_TOO_LARGE, false);
    }

    private ResponseEntity<ErrorResponse> createErrorResponse(Exception exception, HttpStatus httpStatus, boolean logError) {
        if (logError) {
            LOGGER.error(exception.getMessage(), exception);
        }
        return new ResponseEntity<>(new ErrorResponse(exception.getMessage()), httpStatus);
    }
}
