package nl.belastingdienst.iva.wd.brievenbus.validator;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.domain.Mailbox;
import nl.belastingdienst.iva.wd.brievenbus.domain.RecipientType;
import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;
import nl.belastingdienst.iva.wd.brievenbus.utils.MailboxUtils;

@Component
public class UploadValidator {

	private static final int PRODUCT_NUMBER_MAX_LENGTH = 32;

	private static final String NOT_ALLOWED_SENDING_FILE_TO_YOURSELF = "U mag geen bestand naar uzelf sturen";

	private static final String NO_RECEIVERS_ENTERED = "Er zijn geen receivers opgegeven";
	private static final String NOT_ALL_REQUIRED_FIELDS_ENTERED = "Niet alle verplichte velden bij een receiver (id, name, email, type) zijn gevuld";
	private static final String MAX_NUMBER_OF_RECEIVERS_1 = "Er mogen maximaal ";
	private static final String MAX_NUMBER_OF_RECEIVERS_2 = " receivers worden opgegeven";
	private static final String WRONG_TYPE_OF_RECEIVER = "Er is een verkeerd type receiver opgegeven (alleen PERSON en MAILBOX zijn toegestaan)";
	private static final String RECEIVER_NOT_REGISTERED = "Een opgegeven receiver is niet geregistreerd";
	private static final String EMAIL_ADDRESS_RECEIVER_NOT_REGISTERED = "Een opgegeven emailadres van een receiver klopt niet met het geregistreerde emailadres";

	private static final String PRODUCT_NUMBER_NOT_ENTERED = "Het productnummer is niet ingevuld";
	private static final String PRODUCT_NUMBER_TOO_LONG_1 = "Het productnummer is langer dan ";
	private static final String PRODUCT_NUMBER_TOO_LONG_2 = " posities";

	private static final String NO_PERMISSION_PRIVACY_OFFICER = "Er is geen toestemming privacy officer opgegeven bij het versturen naar postbussen";

	@Value("${max.receivers}")
	private int maxReceivers;

	@Value("${application.feature.sendingFileToYourselfIsNotAllowed}")
	private boolean sendingFileToYourselfIsNotAllowed;

	@Value("${application.feature.enterProductNumber}")
	private boolean enterProductNumber;

	@Autowired
	private LdapDwbClient ldapDwbClient;

	@Autowired
	private MailboxUtils mailboxUtils;

	public ResponseEntity<String> validateSender(Principal sender, List<ReceiverJson> receivers) {
		if (sendingFileToYourselfIsNotAllowed && isUserSendingFileToHimself(receivers, sender)) {
			return ResponseEntity.badRequest().body(createError(NOT_ALLOWED_SENDING_FILE_TO_YOURSELF));
		}
		return null;
	}

	public ResponseEntity<String> validateReceivers(List<ReceiverJson> receivers) {
		if (isReceiversNotPresent(receivers)) {
			return ResponseEntity.badRequest().body(createError(NO_RECEIVERS_ENTERED));
		}
		if (isNotEveryRequiredFieldEntered(receivers)) {
			return ResponseEntity.badRequest().body(createError(NOT_ALL_REQUIRED_FIELDS_ENTERED));
		}
		if (isNumberOfReceiversTooMany(receivers)) {
			return ResponseEntity.badRequest().body(createError(MAX_NUMBER_OF_RECEIVERS_1, maxReceivers, MAX_NUMBER_OF_RECEIVERS_2));
		}
		if (isReceiverTypeNotCorrect(receivers)) {
			return ResponseEntity.badRequest().body(createError(WRONG_TYPE_OF_RECEIVER));
		}

		Map<String, String> registeredReceiversWithEmailAddress = getRegisteredReceiversWithEmailAddress(receivers);

		if (isReceiverNotRegistered(receivers, registeredReceiversWithEmailAddress)) {
			return ResponseEntity.badRequest().body(createError(RECEIVER_NOT_REGISTERED));
		}
		if (isReceiverEmailAddressNotRegistered(receivers, registeredReceiversWithEmailAddress)) {
			return ResponseEntity.badRequest().body(createError(EMAIL_ADDRESS_RECEIVER_NOT_REGISTERED));
		}
		return null;
	}

	public ResponseEntity<String> validateProductNumber(String productNumber) {
		if (enterProductNumber && isProductNumberNotEntered(productNumber)) {
			return ResponseEntity.badRequest().body(createError(PRODUCT_NUMBER_NOT_ENTERED));
		}
		if (enterProductNumber && isProductNumberTooLong(productNumber)) {
			return ResponseEntity.badRequest().body(createError(PRODUCT_NUMBER_TOO_LONG_1, PRODUCT_NUMBER_MAX_LENGTH, PRODUCT_NUMBER_TOO_LONG_2));
		}
		return null;
	}

	public ResponseEntity<String> validateIsVerifyMailboxChecked(Boolean isVerifyMailboxChecked, List<ReceiverJson> receivers) {
		if (isVerifyMailboxNotTrueWhenMailboxInReceivers(receivers, isVerifyMailboxChecked)) {
			return ResponseEntity.badRequest().body(createError(NO_PERMISSION_PRIVACY_OFFICER));
		}
		return null;
	}

	private Map<String, String> getRegisteredReceiversWithEmailAddress(List<ReceiverJson> receivers) {
		Map<String, String> registeredReceiversWithEmailAddress = new HashMap<>();
		for (ReceiverJson receiverJson : receivers) {
			if (receiverJson.getType().equals(RecipientType.PERSON.name())) {
				LdapPerson ldapPerson = ldapDwbClient.getPerson(receiverJson.getId());
				if (ldapPerson != null) {
					registeredReceiversWithEmailAddress.put(receiverJson.getId(), ldapPerson.getEmail());
				}
			} else if (receiverJson.getType().equals(RecipientType.MAILBOX.name())) {
				Mailbox mailbox = mailboxUtils.getMailbox(receiverJson.getId());
				if (mailbox != null) {
					registeredReceiversWithEmailAddress.put(receiverJson.getId(), mailbox.getEmail());
				}
			}
		}
		return registeredReceiversWithEmailAddress;
	}

	private boolean isUserSendingFileToHimself(List<ReceiverJson> receivers, Principal sender) {
		return receivers.stream().anyMatch(receiver -> sender.getName().equalsIgnoreCase(receiver.getId()));
	}

	private boolean isReceiversNotPresent(List<ReceiverJson> receivers) {
		return receivers == null || receivers.isEmpty();
	}

	private boolean isNotEveryRequiredFieldEntered(List<ReceiverJson> receivers) {
		Predicate<ReceiverJson> isRequiredFieldNotEntered = receiverJson -> {
			boolean isIdNotEntered = receiverJson.getId() == null || receiverJson.getId().trim().isEmpty();
			boolean isNameNotEntered = receiverJson.getName() == null || receiverJson.getName().trim().isEmpty();
			boolean isEmailNotEntered = receiverJson.getEmail() == null || receiverJson.getEmail().trim().isEmpty();
			boolean isTypeNotEntered = receiverJson.getType() == null || receiverJson.getType().trim().isEmpty();
			return isIdNotEntered || isNameNotEntered || isEmailNotEntered || isTypeNotEntered;
		};
		return receivers.stream().anyMatch(isRequiredFieldNotEntered);
	}

	private boolean isNumberOfReceiversTooMany(List<ReceiverJson> receivers) {
		return receivers.size() > maxReceivers;
	}

	private boolean isReceiverTypeNotCorrect(List<ReceiverJson> receivers) {
		Predicate<ReceiverJson> isPersonOrMailbox = receiverJson -> receiverJson.getType().equals(RecipientType.PERSON.name())
				|| receiverJson.getType().equals(RecipientType.MAILBOX.name());
		return receivers.stream().filter(isPersonOrMailbox).count() != receivers.size();
	}

	private boolean isReceiverNotRegistered(List<ReceiverJson> receivers, Map<String, String> registeredReceiversWithEmailAddress) {
		return !receivers.stream().allMatch(receiverJson -> registeredReceiversWithEmailAddress.containsKey(receiverJson.getId()));
	}

	private boolean isReceiverEmailAddressNotRegistered(List<ReceiverJson> receivers, Map<String, String> registeredReceiversWithEmailAddress) {
		return !receivers.stream().allMatch(receiverJson -> receiverJson.getEmail().equalsIgnoreCase(registeredReceiversWithEmailAddress.get(receiverJson.getId())));
	}

	private boolean isProductNumberNotEntered(String productNumber) {
		return productNumber == null || productNumber.trim().length() == 0 || productNumber.equalsIgnoreCase("null");
	}

	private boolean isProductNumberTooLong(String productNumber) {
		return productNumber != null && productNumber.trim().length() > PRODUCT_NUMBER_MAX_LENGTH;
	}

	private boolean isVerifyMailboxNotTrueWhenMailboxInReceivers(List<ReceiverJson> receivers, Boolean isVerifyMailboxChecked) {
		boolean isMailboxInReceivers = receivers.stream().anyMatch(receiverJson -> mailboxUtils.isMailbox(receiverJson.getId()));
		return isMailboxInReceivers && !Boolean.TRUE.equals(isVerifyMailboxChecked);
	}

	private String createError(String message) {
		return "{\"error\": \"" + message + "\"}";
	}

	private String createError(String messagePart1, int number, String messagePart2) {
		return "{\"error\": \"" + messagePart1 + number + messagePart2 + "\"}";
	}
}
