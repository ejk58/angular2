package nl.belastingdienst.iva.wd.brievenbus.security;

import nl.belastingdienst.iva.wd.brievenbus.filter.AuthorizationFilter;
import nl.belastingdienst.iva.wd.brievenbus.filter.FilterExceptionHandlerFilter;
import nl.belastingdienst.iva.wd.brievenbus.filter.JWTAuthenticationFilter;
import nl.belastingdienst.iva.wd.brievenbus.filter.LoginAuthenticationFilter;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

@EnableWebSecurity
public class WebSecurity extends WebSecurityConfigurerAdapter {

    private final Environment env;
    private final LdapTemplate ldapTemplate;
    private final JwtUtils jwtUtils;
    private final HandlerExceptionResolver handlerExceptionResolver;

    public WebSecurity(Environment env, LdapTemplate ldapTemplate, JwtUtils jwtUtils, HandlerExceptionResolver handlerExceptionResolver) {
        this.env = env;
        this.ldapTemplate = ldapTemplate;
        this.jwtUtils = jwtUtils;
        this.handlerExceptionResolver = handlerExceptionResolver;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .cors().and().csrf().disable()
            .authorizeRequests()
            // "/actuator/health" is necessary for OpenShift checks (see template.yaml files)
            .antMatchers("/actuator/health", "/", "/api/login", "/api/appconfig/applicationplatform",
                "/assets/**", "/index.html", "/*.js", "/*.css", "/*.png", "/*.svg", "/*.ttf", "/*.eot", "/*.woff", "/favicon.ico").permitAll()
            .anyRequest().authenticated()
            .and()
            .addFilterBefore(new FilterExceptionHandlerFilter(handlerExceptionResolver), LogoutFilter.class)
            .addFilter(new LoginAuthenticationFilter(env, ldapTemplate, jwtUtils))
            .addFilter(new JWTAuthenticationFilter(jwtUtils, authenticationManager()))
            .addFilterAfter(new AuthorizationFilter(env, jwtUtils), BasicAuthenticationFilter.class)
            // this disables session creation on Spring Security
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        // This option is needed to enable the h2 console
        http.headers().frameOptions().sameOrigin();
    }
}
