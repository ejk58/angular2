package nl.belastingdienst.iva.wd.brievenbus.domain;

public enum RecipientType {
	PERSON, MAILBOX;
}
