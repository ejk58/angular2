package nl.belastingdienst.iva.wd.brievenbus.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Mailbox extends Recipient {

	public Mailbox() {
		setType(RecipientType.MAILBOX);
	}

	private String adGroup;
}
