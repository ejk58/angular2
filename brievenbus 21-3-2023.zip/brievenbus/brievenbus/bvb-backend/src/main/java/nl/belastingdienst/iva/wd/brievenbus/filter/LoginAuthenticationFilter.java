package nl.belastingdienst.iva.wd.brievenbus.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;
import nl.belastingdienst.iva.wd.brievenbus.security.JwtUtils;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityConstants;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Slf4j
public class LoginAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private final LdapTemplate ldapTemplate;
    private final Environment env;
    private final JwtUtils jwtUtils;

    public LoginAuthenticationFilter(Environment env, LdapTemplate ldapTemplate, JwtUtils jwtUtils) {
        this.env = env;
        this.ldapTemplate = ldapTemplate;
        this.jwtUtils = jwtUtils;
        setFilterProcessesUrl("/api/login");
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request,
                                                HttpServletResponse response) {
        try {
            ApplicationUser user = new ObjectMapper().readValue(request.getInputStream(), ApplicationUser.class);

            // ldap authentication accepts empty passwords!
            if (user.getPassword().isEmpty()) {
                user.setPassword(null);
            }

            String applicationPlatform = env.getRequiredProperty("application.platform", String.class).toLowerCase();
            String partitionSuffix = env.getRequiredProperty("ldap." + applicationPlatform + ".partitionSuffix");

            if (!ldapTemplate.authenticate(partitionSuffix, "(cn=" + user.getUsername() + ")", user.getPassword())) {
                AuditService.logUserAction("Er is geprobeerd in te loggen met een verkeerd userid of password", user.getUsername());
                throw new BadCredentialsException("Verkeerd userid of password");
            }
            return new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword(), null);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request,
                                            HttpServletResponse response,
                                            FilterChain chain,
                                            Authentication authentication) {
        String token = jwtUtils.generateJwtToken(authentication);
        response.addHeader(SecurityConstants.HEADER_AUTHORIZATION, SecurityConstants.TOKEN_PREFIX + token);
    }
}