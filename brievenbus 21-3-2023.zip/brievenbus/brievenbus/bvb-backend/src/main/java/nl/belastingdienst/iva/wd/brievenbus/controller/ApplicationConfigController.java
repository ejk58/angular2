package nl.belastingdienst.iva.wd.brievenbus.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationConfig;

@RestController
@RequestMapping("/api/application")
public class ApplicationConfigController {

	@Value("${application.platform}")
	private String applicationPlatform;

	@Value("${application.feature.sendingFileToYourselfIsNotAllowed}")
	private boolean sendingFileToYourselfIsNotAllowed;

	@Value("${application.feature.enterProductNumber}")
	private boolean enterProductNumber;

	@GetMapping("/configuration")
	public ApplicationConfig getApplicationConfiguration() {
		ApplicationConfig applicationConfig = new ApplicationConfig();
		applicationConfig.setApplicationPlatform(this.applicationPlatform);
		applicationConfig.setSendingFileToYourselfIsNotAllowed(this.sendingFileToYourselfIsNotAllowed);
		applicationConfig.setEnterProductNumber(this.enterProductNumber);
		return applicationConfig;
	}
}
