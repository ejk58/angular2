package nl.belastingdienst.iva.wd.brievenbus.controller;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import javax.annotation.security.RolesAllowed;
import javax.persistence.PersistenceException;
import javax.xml.bind.DatatypeConverter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.FileRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.ReceiverRepository;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapAdpClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityConstants;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;
import nl.belastingdienst.iva.wd.brievenbus.service.FileService;
import nl.belastingdienst.iva.wd.brievenbus.service.MailService;
import nl.belastingdienst.iva.wd.brievenbus.validator.UploadValidator;

@RestController
@RequestMapping("/api/upload")
@Transactional
public class UploadController {

    private static final String START_OFFER = "Starten opslaan delivery en verzenden email";
    private static final String END_OFFER = "Einde opslaan delivery en verzenden email";

    private static final String START_SAVING_DELIVERY = "Starten met opslaan van delivery";
    private static final String START_SAVING_RECEIVER = "Starten met opslaan van receiver";
    private static final String START_SAVING_FILE = "Starten met opslaan van file";
    private static final String DELIVERY_SAVED = "Opslaan van delivery is gelukt";
    private static final String RECEIVER_SAVED = "Opslaan van receiver is gelukt";
    private static final String FILE_SAVED = "Opslaan van file is gelukt";

    private static final String DELIVERY_SAVE_ERROR = "Opslaan van delivery is niet gelukt";
    private static final String RECEIVER_SAVE_ERROR = "Opslaan van receiver is niet gelukt";
    private static final String FILE_SAVE_ERROR = "Opslaan van file is niet gelukt";

    private static final Logger LOGGER = LogManager.getLogger(UploadController.class);

    @Value("${link.expiration.period.in.weeks}")
    private int linkExpirationPeriodInWeeks;

    @Autowired
    private DeliveryRepository deliveryRepository;

    @Autowired
    private FileRepository fileRepository;

    @Autowired
    private ReceiverRepository receiverRepository;

    @Autowired
    private MailService mailService;

    @Autowired
    private FileService fileService;

    @Autowired
    private AuditService auditService;

    @Autowired
    private LdapAdpClient ldapAdpClient;

    @Autowired
    private UploadValidator uploadValidator;

    @RolesAllowed(SecurityConstants.ROLE_UPLOADER_ADP)
    @PostMapping(value = "/offer", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> offer(
            @RequestParam("file") MultipartFile file,
            @RequestParam(name = "productNumber", required = false) String productNumber,
            @RequestParam(name = "isVerifyMailboxChecked", required = false) Boolean isVerifyMailboxChecked,
            @RequestParam("receivers") List<ReceiverJson> receivers,
            Principal sender) {

        ResponseEntity<String> errorResponse = validateParameters(sender, receivers, productNumber, isVerifyMailboxChecked);
        if (errorResponse != null)
            return errorResponse;

        this.auditService.logUserAction(START_OFFER, sender.getName(), file.getOriginalFilename());
        String senderUserId = sender.getName();
        LdapPerson senderUser = this.ldapAdpClient.getPerson(senderUserId);
        Delivery deliveryEntity = new Delivery();
        deliveryEntity.setUuid(UUID.randomUUID());

        updateDatabase(deliveryEntity, sender, receivers, file);
        this.fileService.writeFileToDirectoryOnSystem(deliveryEntity, file, sender.getName());
        this.mailService.createAndSendMail(deliveryEntity, receivers);
        this.auditService.logUserAction(END_OFFER, senderUser, file.getOriginalFilename(), deliveryEntity.getUuid());

        String productNumberForAuditing = productNumber != null ? productNumber.trim() : "";
        this.auditService.logSendAction(senderUser, deliveryEntity, productNumberForAuditing, isVerifyMailboxChecked);
        return ResponseEntity.ok("{\"message\": \"Bestand goed verwerkt!\", \"deliveryUUID\": \"" + deliveryEntity.getUuid() + "\"}");
    }

    @RolesAllowed(SecurityConstants.ROLE_UPLOADER_AUTOMATIC)
    @PostMapping(value = "/offer/automatic", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> offerAutomatic(
            @RequestParam("file") MultipartFile file,
            @RequestParam(name = "productNumber", required = false) String productNumber,
            @RequestParam(name = "isVerifyMailboxChecked", required = false) Boolean isVerifyMailboxChecked,
            @RequestParam("receivers") List<ReceiverJson> receivers,
            Principal sender) {
        return this.offer(file, productNumber, isVerifyMailboxChecked, receivers, sender);
    }

    private ResponseEntity<String> validateParameters(Principal sender, List<ReceiverJson> receivers, String productNumber, Boolean isVerifyMailboxChecked) {
        ResponseEntity<String> errorResponse = uploadValidator.validateSender(sender, receivers);
        errorResponse = errorResponse == null ? uploadValidator.validateReceivers(receivers) : errorResponse;
        errorResponse = errorResponse == null ? uploadValidator.validateProductNumber(productNumber) : errorResponse;
        errorResponse = errorResponse == null ? uploadValidator.validateIsVerifyMailboxChecked(isVerifyMailboxChecked, receivers) : errorResponse;
        return errorResponse;
    }

    private void updateDatabase(Delivery deliveryEntity, Principal sender, List<ReceiverJson> receivers, MultipartFile file) {
        persistNewDeliveryEntity(deliveryEntity, sender);
        for(ReceiverJson receiver : receivers) {
            persistNewReceiverEntity(deliveryEntity, receiver);
        }
        persistNewFileEntity(deliveryEntity, file);
    }

    private void persistNewDeliveryEntity(Delivery deliveryEntity, Principal sender) {
        LocalDateTime created = LocalDateTime.now();
        LocalDateTime expiration = created.plusWeeks(linkExpirationPeriodInWeeks);

        deliveryEntity.setSender(sender.getName());
        deliveryEntity.setCreated(created);
        deliveryEntity.setExpiration(expiration);

        this.auditService.logUserAction(START_SAVING_DELIVERY, deliveryEntity.getUuid());
        try {
            this.deliveryRepository.save(deliveryEntity);
            this.auditService.logUserAction(DELIVERY_SAVED, deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            this.auditService.logUserAction(DELIVERY_SAVE_ERROR, deliveryEntity.getUuid());
            throw new UnprocessableException(DELIVERY_SAVE_ERROR, e);
        }
    }

    private void persistNewReceiverEntity(Delivery deliveryEntity, ReceiverJson receiver) {
        Receiver receiverEntity = new Receiver();
        receiverEntity.setDelivery(deliveryEntity);
        receiverEntity.setUserid(receiver.getId());

        deliveryEntity.addReceiver(receiverEntity);

        this.auditService.logUserAction(START_SAVING_RECEIVER, deliveryEntity.getUuid());
        try {
            this.receiverRepository.save(receiverEntity);
            this.auditService.logUserAction(RECEIVER_SAVED, deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            this.auditService.logUserAction(RECEIVER_SAVE_ERROR, deliveryEntity.getUuid());
            throw new UnprocessableException(RECEIVER_SAVE_ERROR, e);
        }
    }

    private void persistNewFileEntity(Delivery deliveryEntity, MultipartFile file) {
        File fileEntity = new File();
        fileEntity.setHash(getFileHash(file));
        fileEntity.setName(file.getOriginalFilename());
        fileEntity.setBytes(file.getSize());
        fileEntity.setDelivery(deliveryEntity);

        deliveryEntity.setFile(fileEntity);

        this.auditService.logUserAction(START_SAVING_FILE, deliveryEntity.getUuid());
        try {
            this.fileRepository.save(fileEntity);
            this.auditService.logUserAction(FILE_SAVED, deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            this.auditService.logUserAction(FILE_SAVE_ERROR, deliveryEntity.getUuid());
            throw new UnprocessableException(FILE_SAVE_ERROR, e);
        }
    }

    private String getFileHash(MultipartFile file) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(file.getBytes());
            byte[] digested = md.digest();
            return DatatypeConverter.printHexBinary(digested).toUpperCase();
        } catch (NoSuchAlgorithmException | IOException e) {
            LOGGER.error(e);
        }

        return "no-hash-generated-due-to-error";
    }
}
