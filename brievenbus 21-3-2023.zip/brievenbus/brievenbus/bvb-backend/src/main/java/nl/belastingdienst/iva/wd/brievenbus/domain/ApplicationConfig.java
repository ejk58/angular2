package nl.belastingdienst.iva.wd.brievenbus.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationConfig {
	private String applicationPlatform;
	private boolean sendingFileToYourselfIsNotAllowed;
	private boolean enterProductNumber;
}
