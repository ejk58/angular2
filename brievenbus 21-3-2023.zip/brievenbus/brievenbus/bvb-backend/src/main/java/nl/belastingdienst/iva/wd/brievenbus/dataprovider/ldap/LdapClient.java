package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnauthorizedException;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

public abstract class LdapClient {

	private static final String LOGIN_CREDENTIALS_ERROR = "Gebruikersnaam en/of wachtwoord fout";
	private static final String LOGIN_WITH_WRONG_CREDENTIALS = "Er is geprobeerd in te loggen met een verkeerd userid of password";

	@Autowired
	protected AuditService auditService;

	@Autowired
	protected LdapTemplate ldapTemplate;

	public abstract LdapPerson getPerson(String userId);

	public abstract void authenticateInLdap(ApplicationUser user);

	protected LdapPerson getPersonByUserId(String userId, String partitionSuffix) {
		LdapQuery query = LdapQueryBuilder.query()
				.searchScope(SearchScope.SUBTREE)
				.timeLimit(3000)
				.base(partitionSuffix)
				.where("objectclass").is("person")
				.and("cn").is(userId);
		List<LdapPerson> persons = this.ldapTemplate.search(query, new LdapPersonAttributesMapper());
		return (persons == null || persons.isEmpty()) ? null : persons.get(0);
	}

	protected void authenticate(ApplicationUser user, String partitionSuffix) {
		if (!this.ldapTemplate.authenticate(partitionSuffix, "(cn=" + user.getUsername() + ")", user.getPassword())) {
			this.auditService.logUserAction(LOGIN_WITH_WRONG_CREDENTIALS, user.getUsername());
			throw new UnauthorizedException(LOGIN_CREDENTIALS_ERROR);
		}
	}

}
