package nl.belastingdienst.iva.wd.brievenbus.filter;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationPlatform;
import nl.belastingdienst.iva.wd.brievenbus.security.JwtUtils;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityConstants;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;
import org.springframework.core.env.Environment;
import org.springframework.security.access.AuthorizationServiceException;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class AuthorizationFilter extends OncePerRequestFilter {

    private static final List<String> ADP_ALLOWED_POST_REST_CALLS = Arrays.asList("/api/upload/offer");

    private final Environment env;
    private final JwtUtils jwtUtils;

    public AuthorizationFilter(Environment env, JwtUtils jwtUtils) {
        this.env = env;
        this.jwtUtils = jwtUtils;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws IOException, ServletException {
        if (request.getMethod().equals("POST") && !isPostAllowed(request)) {
            AuditService.logUserAction("Er is geprobeerd een ongeautoriseerde POST uit te voeren", getUserFromToken(request));
            throw new AuthorizationServiceException("Restcall niet toegestaan");
        }
        chain.doFilter(request, response);
    }

    private boolean isPostAllowed(HttpServletRequest request) {
        String applicationPlatform = env.getRequiredProperty("application.platform", String.class);
        String url = request.getRequestURL().toString();
        String postRestCall = url.substring(url.indexOf("/api"));
        return request.getMethod().equals("POST")
            && ADP_ALLOWED_POST_REST_CALLS.contains(postRestCall)
            && ApplicationPlatform.ADP.getPlatform().equals(applicationPlatform);
    }

    private String getUserFromToken(HttpServletRequest request) {
        String headerAuthorization = request.getHeader(SecurityConstants.HEADER_AUTHORIZATION);
        if (headerAuthorization != null && headerAuthorization.startsWith(SecurityConstants.TOKEN_PREFIX)) {
            String token = headerAuthorization.replace(SecurityConstants.TOKEN_PREFIX, "");
            return jwtUtils.validateJwtToken(token).getSubject();
        }
        return null;
    }

}
