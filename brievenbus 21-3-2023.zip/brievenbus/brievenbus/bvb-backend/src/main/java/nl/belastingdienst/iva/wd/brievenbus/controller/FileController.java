package nl.belastingdienst.iva.wd.brievenbus.controller;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.NotFoundException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnauthorizedException;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.ValidationException;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;
import nl.belastingdienst.iva.wd.brievenbus.service.FileService;
import nl.belastingdienst.iva.wd.brievenbus.utils.MailboxUtils;

@RestController
@RequestMapping("/api/download")
public class FileController {

	public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

	private static final String USER_NOT_FOUND_IN_AD = "Deze gebruiker komt niet voor in de Active Directory: ";
	private static final String DELIVERY_NOT_FOUND_WITH_UUID = "Levering met dit uuid niet gevonden: ";
	private static final String REQUIRED_VALUE_NULL = "Eén of meer verplichte waarden zijn niet gevuld";
	private static final String DOWNLOAD_PERIOD_EXPIRED = "De download periode is verstreken. Deze eindigde op: ";
	private static final String NOT_ALLOWED_TO_DOWNLOAD_FILE_YOU_SENT_YOURSELF = "U mag geen bestand ophalen dat u zelf hebt verzonden";
	private static final String AUTHORISATION_ERROR = "U bent niet geautoriseerd om dit bestand op te halen";

	private static final String FILENAME_HTTPHEADER = "filename";

	@Value("${application.feature.sendingFileToYourselfIsNotAllowed}")
	private boolean sendingFileToYourselfIsNotAllowed;

	@Autowired
	private FileService fileService;

	@Autowired
	private DeliveryRepository deliveryRepository;

	@Autowired
	private AuditService auditService;

	@Autowired
	private LdapDwbClient ldapDwbClient;

	@Autowired
	private MailboxUtils mailboxUtils;

	@GetMapping(value = "/{deliveryUUID}")
	public ResponseEntity<Resource> getFileFromFileSystem(
            @PathVariable("deliveryUUID") UUID deliveryUUID,
            Principal principal) throws IOException {

		String userId = principal.getName();
		LdapPerson user = this.ldapDwbClient.getPerson(userId);
		Delivery delivery = getDeliveryIfAllowed(user, deliveryUUID, userId);
		String uuid = delivery.getUuid().toString();
		String filename = delivery.getFile().getName();

		this.auditService.logUserAction("Start opzoeken file " + uuid + "/" + filename, user, filename);
		Resource fileResource = fileService.getFileResource(uuid, filename);
		if (!fileResource.exists()) {
			this.auditService.logUserAction("File " + uuid + "/" + filename + " niet gevonden", user, filename);
			throw new NotFoundException("File " + uuid + "/" + filename + " niet gevonden");
		}
		this.auditService.logUserAction("Einde opzoeken file " + uuid + "/" + filename, user, filename);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentDisposition(ContentDisposition.attachment().filename(filename).build());
		headers.setContentLength(fileResource.contentLength());
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		headers.set(FILENAME_HTTPHEADER, filename); // Self-made header; used in the frontend to give the file the correct name

		this.auditService.logReceiveAction(user, delivery);
		return ResponseEntity.ok().headers(headers).body(fileResource);
	}

	private Delivery getDeliveryIfAllowed(LdapPerson user, UUID deliveryUUID, String userId) {
		Delivery delivery = this.deliveryRepository.findFirstByUuid(deliveryUUID);

		// Validations should be in this order
		validateUserExists(userId, user);
		validateDeliveryExists(deliveryUUID, delivery, user);
		validateRequiredValuesNotNull(delivery, user);
		validateNotDownloadingFileYouSentYourself(delivery, user);
		validateDownloadPeriodNotExpired(delivery, user);
		validateUserAllowedToDownloadFile(delivery, user);

		return delivery;
	}

	private void validateUserExists(String userId, LdapPerson user) {
		if (user == null) {
			this.auditService.logUserAction(USER_NOT_FOUND_IN_AD + userId, userId);
			throw new NotFoundException(USER_NOT_FOUND_IN_AD + userId);
		}
	}

	private void validateDeliveryExists(UUID deliveryUUID, Delivery delivery, LdapPerson user) {
		if (delivery == null) {
			this.auditService.logUserAction(DELIVERY_NOT_FOUND_WITH_UUID + deliveryUUID, user);
			throw new NotFoundException(DELIVERY_NOT_FOUND_WITH_UUID + deliveryUUID);
		}
	}

	private void validateRequiredValuesNotNull(Delivery delivery, LdapPerson user) {
		if (delivery.getSender() == null || user.getUserId() == null || delivery.getReceivers() == null) {
			this.auditService.logUserAction(REQUIRED_VALUE_NULL, user);
			throw new ValidationException(REQUIRED_VALUE_NULL);
		}
	}

	private void validateNotDownloadingFileYouSentYourself(Delivery delivery, LdapPerson user) {
		if (sendingFileToYourselfIsNotAllowed && delivery.getSender().equalsIgnoreCase(user.getUserId())) {
			this.auditService.logUserAction(NOT_ALLOWED_TO_DOWNLOAD_FILE_YOU_SENT_YOURSELF, user);
			throw new ValidationException(NOT_ALLOWED_TO_DOWNLOAD_FILE_YOU_SENT_YOURSELF);
		}
	}

	private void validateDownloadPeriodNotExpired(Delivery delivery, LdapPerson user) {
		if (LocalDateTime.now().isAfter(delivery.getExpiration())) {
			String dateAsString = delivery.getExpiration().format(DATE_TIME_FORMATTER);
			this.auditService.logUserAction(DOWNLOAD_PERIOD_EXPIRED + dateAsString, user);
			throw new ValidationException(DOWNLOAD_PERIOD_EXPIRED + dateAsString);
		}
	}

	private void validateUserAllowedToDownloadFile(Delivery delivery, LdapPerson user) {
		// Determine the id's of the mailboxes listed as receivers
		List<String> mailboxIds = delivery.getReceivers().stream().map(Receiver::getUserid)
				.filter(userid -> mailboxUtils.isMailbox(userid)).collect(Collectors.toList());

		boolean isUserInListWithReceivers = false;
		boolean isUserInGroupThatBelongsToMailbox = false;

		if (mailboxIds.size() < delivery.getReceivers().size()) {
			isUserInListWithReceivers = isUserInListWithReceivers(delivery, user);
		}
		if (!mailboxIds.isEmpty()) {
			isUserInGroupThatBelongsToMailbox = isUserInGroupThatBelongsToMailbox(mailboxIds, user);
		}

		if (!isUserInListWithReceivers && !isUserInGroupThatBelongsToMailbox) {
			this.auditService.logUserAction(AUTHORISATION_ERROR, user);
			throw new UnauthorizedException(AUTHORISATION_ERROR);
		}
	}

	private boolean isUserInListWithReceivers(Delivery delivery, LdapPerson user) {
		return delivery.getReceivers().stream().anyMatch(receiver -> receiver.getUserid().equalsIgnoreCase(user.getUserId()));
	}

	private boolean isUserInGroupThatBelongsToMailbox(List<String> mailboxIds, LdapPerson user) {
		// Determine the groups that belong to the mailboxes listed as receivers
		List<String> groups = mailboxIds.stream().map(mailboxId -> mailboxUtils.getMailbox(mailboxId).getAdGroup()).collect(Collectors.toList());
		// Add the groups that the logged-in user has access to
		groups.addAll(user.getGroups());
		// Determine whether a group appears more than once in the list
		// If so, the user is in a group that belongs to a mailbox listed as a receiver
		Set<String> set = groups.stream().filter(group -> Collections.frequency(groups, group) > 1).collect(Collectors.toSet());
		return !set.isEmpty();
	}

}
