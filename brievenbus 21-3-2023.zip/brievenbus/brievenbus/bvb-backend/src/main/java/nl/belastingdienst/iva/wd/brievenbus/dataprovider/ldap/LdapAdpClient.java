package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;

@Component
public class LdapAdpClient extends LdapClient {

	@Value("${ldap.adp.partitionSuffix}")
	private String ldapAdpPartitionSuffix;

	@Override
	public LdapPerson getPerson(String userId) {
		return super.getPersonByUserId(userId, ldapAdpPartitionSuffix);
	}

	@Override
	public void authenticateInLdap(ApplicationUser user) {
		super.authenticate(user, ldapAdpPartitionSuffix);
	}

}
