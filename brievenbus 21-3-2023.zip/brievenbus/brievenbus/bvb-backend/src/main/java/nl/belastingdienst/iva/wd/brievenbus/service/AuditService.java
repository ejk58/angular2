package nl.belastingdienst.iva.wd.brievenbus.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapAdpClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationPlatform;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;

@Component
public class AuditService implements InitializingBean {

    private static final String ACTION_LABEL = " ACTION: ";
    private static final String USERID_LABEL = "USERNAME: ";
    private static final String TENANT_LABEL = "TENANT: ";
    private static final String FILE_LABEL = "FILE: ";
    private static final String DELIVERY_UUID_LABEL = "DELIVERY UUID: ";
    private static final String SENDER_LABEL = "SENDER: ";
    private static final String RECIPIENTS_LABEL = "RECIPIENTS: ";
    private static final String PRODUCT_NUMBER_LABEL = "PRODUCT NUMBER: ";
    private static final String VERIFY_MAILBOX_CHECKED = "VERIFY MAILBOX CHECKED: ";
    private static final String SEND_FILE_ACTION = "Verzenden bestand";
    private static final String DOWNLOAD_FILE_ACTION = "Downloaden bestand";

    private static final String CUSTOM_LEVEL = "AUDIT";
    private static final int CUSTOM_INT_VALUE = 250;
    private static final String EMPTY = "";
    private static final String SEPARATOR = "\t ";

    private static final Logger logger = LogManager.getLogger(AuditService.class);

    private LdapClient ldapClient;

    @Value("${application.platform}")
    private String applicationPlatform;

    @Autowired
    private LdapAdpClient ldapAdpClient;

    @Autowired
    private LdapDwbClient ldapDwbClient;

    @Override
    public void afterPropertiesSet() {
        this.ldapClient = ApplicationPlatform.ADP.getPlatform().equalsIgnoreCase(applicationPlatform) ? ldapAdpClient : ldapDwbClient;
    }

    public void logSendAction(LdapPerson user, Delivery delivery, String productNumber, Boolean isVerifyMailboxChecked) {
        String userId = user == null ? EMPTY : user.getUserId();
        String tenant = user == null ? EMPTY : user.getTenant();
        String uuid = delivery.getUuid().toString();
        File file = delivery.getFile();
        String filename = file.getName();
        long filesize = file.getBytes();
        List<Receiver> receivers = delivery.getReceivers();
        String recipients = receivers.stream().map(Receiver::getUserid).collect(Collectors.joining(", "));
        String verifyMailboxChecked = isVerifyMailboxChecked != null ? String.valueOf(isVerifyMailboxChecked) : EMPTY;

        logger.log(Level.forName(CUSTOM_LEVEL, CUSTOM_INT_VALUE),
                ACTION_LABEL + SEND_FILE_ACTION + SEPARATOR +
                USERID_LABEL + userId + SEPARATOR +
                TENANT_LABEL + tenant + SEPARATOR +
                DELIVERY_UUID_LABEL + uuid + SEPARATOR +
                FILE_LABEL + filename + " (" + Long.toString(filesize) + ")" + SEPARATOR +
                RECIPIENTS_LABEL + recipients + SEPARATOR +
                PRODUCT_NUMBER_LABEL + productNumber + SEPARATOR +
                VERIFY_MAILBOX_CHECKED + verifyMailboxChecked);
    }

    public void logReceiveAction(LdapPerson user, Delivery delivery) {
        String userId = user == null ? EMPTY : user.getUserId();
        String tenant = user == null ? EMPTY : user.getTenant();
        String uuid = delivery.getUuid().toString();
        File file = delivery.getFile();
        String filename = file.getName();
        long filesize = file.getBytes();
        String sender = delivery.getSender();

        logger.log(Level.forName(CUSTOM_LEVEL, CUSTOM_INT_VALUE),
                ACTION_LABEL + DOWNLOAD_FILE_ACTION + SEPARATOR +
                USERID_LABEL + userId + SEPARATOR +
                TENANT_LABEL + tenant + SEPARATOR +
                DELIVERY_UUID_LABEL + uuid + SEPARATOR +
                FILE_LABEL + filename + " (" + Long.toString(filesize) + ")" + SEPARATOR +
                SENDER_LABEL + sender);
    }

    public void logUserAction(String action, LdapPerson user, String fileName, UUID deliveryUUID) {
        String userId = user == null ? EMPTY : user.getUserId();
        String tenant = user == null ? EMPTY : user.getTenant();

        logger.log(Level.forName(CUSTOM_LEVEL, CUSTOM_INT_VALUE),
                ACTION_LABEL + action + SEPARATOR +
                USERID_LABEL + userId + SEPARATOR +
                TENANT_LABEL + tenant + SEPARATOR +
                DELIVERY_UUID_LABEL + (deliveryUUID == null ? EMPTY : deliveryUUID.toString()) + SEPARATOR +
                FILE_LABEL + fileName);
    }

    public void logUserAction(String action, LdapPerson user, String fileName) {
        this.logUserAction(action, user, fileName, null);
    }

    public void logUserAction(String action, LdapPerson user) {
        this.logUserAction(action, user, EMPTY, null);
    }

    public void logUserAction(String action, String userId, String fileName, UUID deliveryUUID) {
        LdapPerson user = userId == null || EMPTY.equals(userId) ? null : this.ldapClient.getPerson(userId);
        this.logUserAction(action, user, fileName, deliveryUUID);
    }

    public void logUserAction(String action, String userId, String fileName) {
        this.logUserAction(action, userId, fileName, null);
    }

    public void logUserAction(String action, String userId, UUID deliveryUUID) {
        this.logUserAction(action, userId, EMPTY, deliveryUUID);
    }

    public void logUserAction(String action, String userId) {
        this.logUserAction(action, userId, EMPTY, null);
    }

    public void logUserAction(String action, UUID deliveryUUID) {
        this.logUserAction(action, EMPTY, EMPTY, deliveryUUID);
    }
}
