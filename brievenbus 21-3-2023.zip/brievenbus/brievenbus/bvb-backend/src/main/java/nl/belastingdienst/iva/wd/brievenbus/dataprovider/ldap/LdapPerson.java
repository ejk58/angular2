package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import java.util.List;

public class LdapPerson {

	private String userId;
	private String firstName;
	private String lastName;
	private String name;
	private String email;
	private List<String> groups;
	private String tenant;

	public String getUserId() {
		return userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public List<String> getGroups() {
		return groups;
	}

	public String getTenant() {
		return tenant;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}
}
