package nl.belastingdienst.iva.wd.brievenbus.controller;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.domain.Mailbox;
import nl.belastingdienst.iva.wd.brievenbus.domain.Person;
import nl.belastingdienst.iva.wd.brievenbus.domain.Recipient;
import nl.belastingdienst.iva.wd.brievenbus.utils.MailboxUtils;

@RestController
@RequestMapping("/api/recipient")
public class RecipientController {

	@Value("${application.feature.sendingFileToYourselfIsNotAllowed}")
	private boolean sendingFileToYourselfIsNotAllowed;

	@Autowired
	private LdapDwbClient ldapDwbClient;

	@Autowired
	private MailboxUtils mailboxUtils;

	@GetMapping("/find")
	public ResponseEntity<List<Recipient>> getRecipients(@RequestParam("userIdOrName") String userIdOrName, Principal principal) {
		List<Recipient> recipients = getRecipients(userIdOrName);
		if (sendingFileToYourselfIsNotAllowed) {
			removeLoggedInUserFromRecipients(principal, recipients);
		}
		List<Mailbox> mailboxes = getMailboxes(userIdOrName);
		recipients.addAll(0, mailboxes);
		return new ResponseEntity<>(recipients.isEmpty() ? null : recipients, HttpStatus.OK);
	}

	private List<Recipient> getRecipients(String userIdOrName) {
		List<LdapPerson> ldapPersons = ldapDwbClient.getPersonsWithMail(userIdOrName);
		return ldapPersons.stream().map(this::createPerson).collect(Collectors.toList());
	}

	private void removeLoggedInUserFromRecipients(Principal principal, List<Recipient> recipients) {
		recipients.removeIf(recipient -> principal.getName().equalsIgnoreCase(recipient.getId()));
	}

	private List<Mailbox> getMailboxes(String userIdOrName) {
		return mailboxUtils.getMailboxes(userIdOrName);
	}

	private Person createPerson(LdapPerson ldapPerson) {
		Person person = new Person();
		person.setId(ldapPerson.getUserId());
		person.setEmail(ldapPerson.getEmail());
		person.setName(ldapPerson.getName());
		return person;
	}

}
