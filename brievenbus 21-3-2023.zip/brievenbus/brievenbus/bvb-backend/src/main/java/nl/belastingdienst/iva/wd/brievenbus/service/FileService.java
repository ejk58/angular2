package nl.belastingdienst.iva.wd.brievenbus.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;

@Component
public class FileService {

    private static final String FILE_DIRECTORY = "/data/";
    private static final String FILE_WRITE_ERROR = "Er is iets misgegaan bij het schrijven van de file";
    private static final String FILE_SAVED = "File is opgeslagen op systeem ";

    @Autowired
    private AuditService auditService;

    public Resource getFileResource(String uuid, String filename) {
        return new FileSystemResource(FILE_DIRECTORY + uuid + "/" + filename);
    }

    public void writeFileToDirectoryOnSystem(Delivery delivery, MultipartFile file, String senderName) {
        try {
            String directory = FILE_DIRECTORY + delivery.getUuid() + "/";
            Path directoryPath = Paths.get(directory);
            Files.createDirectories(directoryPath);

            Path filePath = Paths.get(directory + file.getOriginalFilename());
            file.transferTo(filePath);
            this.auditService.logUserAction(FILE_SAVED + filePath, delivery.getSender(), delivery.getUuid());
        } catch (IOException ioe) {
            this.auditService.logUserAction(FILE_WRITE_ERROR, senderName, file.getOriginalFilename(), delivery.getUuid());
            throw new UnprocessableException(FILE_WRITE_ERROR, ioe);
        }
    }
}
