package nl.belastingdienst.iva.wd.brievenbus.service;

import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class FileService {

    private static final String FILE_DIRECTORY = "/data/";
    private static final String FILE_WRITE_ERROR = "Er is iets misgegaan bij het schrijven van de file";

    /**
     * @param uuid directory with uuid as nanme
     * @param filename filename
     * @param response Http response.
     * @return file from system.
     */
    public Resource getFileSystem(String uuid, String filename, HttpServletResponse response) {
        return getResource(uuid + "/" + filename, response);
    }

    public void writeFileToDirectoryOnSystem(Delivery delivery, MultipartFile file, String senderName) {
        try {
            AuditService.logUserAction("Tijdelijk: eerste stap writeFileToDirectoryOnSystem", senderName, delivery.getUuid());
            String directory = FILE_DIRECTORY + delivery.getUuid() + "/";
            AuditService.logUserAction("Tijdelijk: tweede stap writeFileToDirectoryOnSystem. Directory: " + directory, senderName, delivery.getUuid());
            Path directoryPath = Paths.get(directory);
            AuditService.logUserAction("Tijdelijk: derde stap writeFileToDirectoryOnSystem. DirectoryPath: " + directoryPath.toString(), senderName, delivery.getUuid());
            Files.createDirectories(directoryPath);

            AuditService.logUserAction("Tijdelijk: vierde stap writeFileToDirectoryOnSystem", senderName, delivery.getUuid());
            Path filePath = Paths.get(directory + file.getOriginalFilename());
            AuditService.logUserAction("Tijdelijk: vijfde stap writeFileToDirectoryOnSystem. FilePath: " + filePath.toString(), senderName, delivery.getUuid());
            file.transferTo(filePath);
            AuditService.logUserAction("File is opgeslagen op systeem " + filePath.toString(), delivery.getSender(), delivery.getUuid());
        } catch (IOException ioe) {
            AuditService.logUserAction(FILE_WRITE_ERROR, senderName, file.getOriginalFilename(), delivery.getUuid());
            throw new UnprocessableException(FILE_WRITE_ERROR, ioe);
        }
    }


    private Resource getResource(String filename, HttpServletResponse response) {
        response.setContentType(MediaType.ALL_VALUE);
        response.setHeader("Content-Disposition", "attachment; filename=" + filename);
        response.setHeader("filename", filename);
        return new FileSystemResource(FILE_DIRECTORY + filename);
    }
}
