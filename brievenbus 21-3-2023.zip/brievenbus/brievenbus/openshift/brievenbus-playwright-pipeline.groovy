#!groovy

// Deze variabelen zijn project specifiek
def projectBase = "bvb"

// Deze variabelen alleen als je niet de standaard volgt
def frontendName = "bvb-frontend"

// Deze variabelen in principe niet veranderen
def playwrightCmd = """
               SELENIUM_REMOTE_URL=http://selenium-hub-wd-selenium-grid-4.apps.cn01.chp.belastingdienst.nl/wd/hub SELENIUM_REMOTE_CAPABILITIES='{"browserName": "chrome", "goog:chromeOptions":{"w3c":"false","args":["--disable-gpu","--disable-infobars","--disable-extensions","--ignore-certificate-errors","--disable-dev-shm-usage"]}}' npx playwright test --config=playwright.config.ts --retries=3 --workers=1
               """

node('master') {
    stage('Checkout and set agent') {
        checkout scm
        // ITT Jeroen's versie, .git niet excluden omdat die voor de git-commit plugin nodig is
        stash(name: 'ws', includes: '**', excludes: '**/node_modules/**')
    }
}

pipeline {
    agent {
        label "nodejs16"
    }
    options {
        skipDefaultCheckout()
    }
    stages {
        stage('NPM') {
            steps {
                unstash 'ws'
                dir(frontendName) {
                    script {
                        if (npmInstall == 'YES') {
                            sh """
                            npm ci --registry=https://nexus.belastingdienst.nl/nexus/repository/npm/;
                            """
                        } else if (npmInstall == 'NO') {
                            echo "Skip npm install."
                        }
                    }
                }
            }
        }
        stage('Playwright') {
            steps {
                unstash 'ws'
                dir(frontendName) {
                    sh(script: "cd ${projectDir}; export PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1; cd src/tests/; ${playwrightCmd}")
                }
                echo "Playwright report dir: " + params.reportDir
                publishHTML([
                        allowMissing: false,
                        alwaysLinkToLastBuild: false,
                        keepAll: true,
                        reportDir: params.reportDir,
                        reportFiles: 'index.html',
                        reportName: 'Playwright Report',
                        reportTitles: ''
                ])
            }
        }
    }
}
