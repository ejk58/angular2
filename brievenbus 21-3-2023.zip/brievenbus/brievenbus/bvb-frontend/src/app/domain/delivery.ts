import {Receiver} from './receiver';

export interface Delivery {
  uuid: string;
  receivers: Receiver[];
  productNumber: string;
  file: File;
  sender: string;
  created: string;
  expiration: string;
  isVerifyMailboxChecked: boolean;
}
