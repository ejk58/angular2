export interface ApplicationConfig {
  applicationPlatform: string;
  sendingFileToYourselfIsNotAllowed: boolean;
  enterProductNumber: boolean;
}
