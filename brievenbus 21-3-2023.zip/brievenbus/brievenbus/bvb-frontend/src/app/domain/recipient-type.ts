export type RecipientType = 'PERSON' | 'MAILBOX';
