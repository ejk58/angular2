import {Component, EventEmitter, Input, Output, ViewChild} from '@angular/core';
import {FileUpload} from 'primeng/fileupload';
import {ConfirmationService, MessageService} from 'primeng/api';

@Component({
  selector: 'b-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  providers: [ConfirmationService, MessageService]
})
export class FileUploadComponent {

  @ViewChild('pFileUpload') fileUpload: FileUpload;

  @Input() file: File;
  @Output() changeFile: EventEmitter<File> = new EventEmitter<File>();

  constructor(
    private readonly confirmationService: ConfirmationService,
    private readonly messageService: MessageService) {
  }

  onUpload(event) {
    if (event.files[0] != null) {
      this.messageService.add({
        closable: false,
        severity: 'success',
        summary: `Bestand is toegevoegd`,
        detail: `${(event.files[0].name) ? event.files[0].name : ''}`
      });
      this.changeFile.emit(event.files[0] as File);
    } else {
      this.messageService.add({
        closable: true,
        sticky: true,
        severity: 'error',
        summary: `Bestand niet gevonden`,
        detail: `${(event.files[0].name) ? event.files[0].name : ''}`
      });
    }
  }

  onRemove() {
    this.messageService.add({
      closable: false,
      severity: 'success',
      summary: `Bestand is verwijderd`
    });
    this.changeFile.emit(null);
  }
}
