import {Injectable} from '@angular/core';
import {CanActivate, Router} from '@angular/router';
import {AppConfigService} from '../services/app-config.service';
import {ApplicationPlatform} from '../domain/application-platform';

@Injectable()
export class ReceiveGuard implements CanActivate {

  constructor(private appConfigService: AppConfigService, private router: Router) {
  }

  canActivate() {
    if (this.appConfigService.getApplicationPlatform() !== ApplicationPlatform.DWB) {
      this.router.navigate(['']);
    }
    return true;
  }
}
