import {Component, OnInit} from '@angular/core';
import {Delivery} from '../domain/delivery';
import {ConfirmationService, MenuItem, MessageService} from 'primeng/api';
import {Receiver} from '../domain/receiver';
import {HttpClient} from '@angular/common/http';
import {VerificationValues} from '../domain/verification-values';
import {ApplicationConfigService} from '../services/application-config.service';

@Component({
  selector: 'app-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.scss'],
  providers: [ConfirmationService, MessageService]
})

export class WizardComponent implements OnInit {

  public items: MenuItem[];
  public step = 0;
  public isChecked = false;
  public isSending = false;
  public enterProductNumber: boolean;

  public delivery: Delivery = {
    uuid: null,
    receivers: [],
    productNumber: null,
    file: null,
    sender: null,
    created: null,
    expiration: null,
    isVerifyMailboxChecked: null
  };

  constructor(private readonly applicationConfigService: ApplicationConfigService,
              private readonly confirmationService: ConfirmationService,
              private readonly messageService: MessageService,
              private readonly httpClient: HttpClient) {
  }

  ngOnInit() {
    this.enterProductNumber = this.applicationConfigService.getEnterProductNumber();
    this.items = [{
      label: 'Selecteren',
      command: () => {
        this.step = 0;
        // this.messageService.add({severity:'info', summary:'Select receivers and a file', detail: event.item.label});
      }
    },
    {
      label: 'Bevestigen',
      command: () => {
        this.step = 1;
        // this.messageService.add({severity:'info', summary:'Control', detail: event.item.label});
      }
    },
    {
      label: 'Verstuurd',
      command: () => {
        this.step = 2;
        // this.messageService.add({severity:'info', summary:'Succes', detail: event.item.label});
      }
    }
    ];
  }

  public disabledSteps(step): void {
    if (step === 0) {
      this.items[0].disabled = false;
      this.items[1].disabled = true;
      this.items[2].disabled = true;
    }
    if (step === 1) {
      this.items[0].disabled = false;
      this.items[1].disabled = false;
      this.items[2].disabled = true;
    }
    if (step === 2) {
      this.items[0].disabled = true;
      this.items[1].disabled = true;
      this.items[2].disabled = false;
    }
  }

  public onChangeChecked(verificationValues: VerificationValues): void {
    this.delivery.isVerifyMailboxChecked = verificationValues.isCheckedMailbox;
    if (verificationValues.isCheckedPerson === null) {
      this.isChecked = verificationValues.isCheckedMailbox;
    } else if (verificationValues.isCheckedMailbox === null) {
      this.isChecked = verificationValues.isCheckedPerson;
    } else {
      this.isChecked = verificationValues.isCheckedPerson && verificationValues.isCheckedMailbox;
    }
  }

  public onChangeFile(file: File): void {
    this.delivery.file = file;
  }

  public onChangeReceivers(receivers: Receiver[]): void {
    this.delivery.receivers = receivers;
  }

  public onChangeProductNumber(productNumber: string): void {
    this.delivery.productNumber = productNumber;
  }

  public promptEraseAll(): void {
    this.confirmationService.confirm({
      message: 'Weet u zeker dat u alle gegevens binnen het formulier wilt wissen?',
      accept: () => {
        this.delivery = {
          uuid: null,
          receivers: [],
          productNumber: null,
          file: null,
          sender: null,
          created: null,
          expiration: null,
          isVerifyMailboxChecked: null
        };
      }
    });
  }

  public send(): void {
    if (this.delivery) {
      const formData: FormData = this.createFormData();
      this.isSending = true;

      this.httpClient.post('/api/upload/offer', formData).subscribe({
        next: () => {
          this.isSending = false;
          this.step++;
        },
        error: err => {
          const unauthorizedError = 'U bent niet geautoriseerd om bestanden te versturen';
          const deliveryError = `Fout bij aanleveren (${err.status})`;
          this.isSending = false;
          this.messageService.add({
            closable: true,
            sticky: true,
            severity: 'error',
            summary: (err.status === 401 || err.status === 403) ? unauthorizedError : deliveryError,
            detail: `${(err.error.error) ? err.error.error : ''}`
          });
        }
      });
    }
  }

  private createFormData(): FormData {
    const formData = new FormData();
    formData.append('file', this.delivery.file);
    if (this.enterProductNumber) {
      formData.append('productNumber', this.delivery.productNumber);
    }
    if (this.delivery.isVerifyMailboxChecked !== null) {
      formData.append('isVerifyMailboxChecked', this.delivery.isVerifyMailboxChecked.toString());
    }
    this.delivery.receivers.forEach(receiver => formData.append('receivers', JSON.stringify(receiver)));
    return formData;
  }

  public allFieldsFilled(): boolean {
    const productNumberNotRequired = !this.enterProductNumber;
    const productNumberRequiredAndEntered = this.enterProductNumber && this.delivery.productNumber != null && this.delivery.productNumber.trim() !== '';
    return this.delivery.receivers.length > 0 && (productNumberNotRequired || productNumberRequiredAndEntered) && this.delivery.file != null;
  }

  public readyToSend(): boolean {
    return !this.isSending && this.isChecked;
  }

  public goBackToFirstStep(): void {
    this.step = 0;
    this.disabledSteps(this.step);
    this.isChecked = false;
  }

  public goToVerify(): void {
    if (this.allFieldsFilled()) {
      this.step++;
    }
  }

  public onStartOver(): void {
    this.delivery = {
      uuid: null,
      receivers: [],
      productNumber: null,
      file: null,
      sender: null,
      created: null,
      expiration: null,
      isVerifyMailboxChecked: null
    };
    this.step = 0;
    this.disabledSteps(this.step);
    this.isChecked = false;
  }

}
