import {Component, OnInit} from '@angular/core';
import {LoginService} from '../services/login.service';
import {Router} from '@angular/router';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ApplicationUser} from '../domain/application-user';
import {ApplicationConfigService} from '../services/application-config.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public form: FormGroup;
  public submitted = false;

  public errorMessage: string;
  public loading = false;

  constructor(private readonly router: Router,
              private readonly formBuilder: FormBuilder,
              private readonly applicationConfigService: ApplicationConfigService,
              private readonly loginService: LoginService) {
    this.form = this.formBuilder.group({
      userId: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.form.valueChanges.subscribe({
      next: () => {
        this.errorMessage = null;
      },
      error: err => {
        console.log(err);
      }
    });
  }

  public login() {
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }

    if (this.isApplicationPlatformEmpty()) {
      this.applicationConfigService.loadApplicationConfig();
    }

    const user: ApplicationUser = {userId: this.form.value.userId, password: this.form.value.password};
    this.loginService.login(user).subscribe({
      next: () => {
        this.router.navigate(['/'], {queryParamsHandling: 'preserve'});
      },
      error: error => {
        console.warn(error);
        this.errorMessage = error.error?.message;
        this.loading = false;
      }
    });
  }

  // Convenience getter for easy access to form fields
  get formControl(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  private isApplicationPlatformEmpty(): boolean {
    return this.applicationConfigService.getApplicationConfig() === undefined ||
      this.applicationConfigService.getApplicationConfig() === null ||
      this.applicationConfigService.getApplicationPlatform() === undefined ||
      this.applicationConfigService.getApplicationPlatform() === '' ||
      this.applicationConfigService.getApplicationPlatform() === null;
  }

}
