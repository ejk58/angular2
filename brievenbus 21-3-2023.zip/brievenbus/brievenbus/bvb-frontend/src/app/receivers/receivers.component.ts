import {Component, ElementRef, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild} from '@angular/core';
import {ReceiverService} from '../services/receiver.service';
import {MessageService} from 'primeng/api';
import {Receiver} from '../domain/receiver';
import {Recipient} from '../domain/recipient';
import {LoginService} from '../services/login.service';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {ApplicationConfigService} from '../services/application-config.service';

@Component({
  selector: 'b-receivers',
  templateUrl: './receivers.component.html',
  styleUrls: ['./receivers.component.scss'],
  providers: [MessageService]
})
export class ReceiversComponent implements OnChanges, OnDestroy, OnInit {

  @Input() receivers: Receiver[];
  @Input() readOnly: boolean;
  @Output() changeReceivers: EventEmitter<Receiver[]> = new EventEmitter<Receiver[]>();

  @ViewChild('userIdOrNameInput') userIdOrNameInput: ElementRef;

  public loading = false;
  public recipients;
  public loggedInUser: string;

  private readonly ngUnsubscribe$ = new Subject<void>();

  constructor(
    private readonly applicationConfigService: ApplicationConfigService,
    private readonly messageService: MessageService,
    private readonly receiverService: ReceiverService,
    private readonly loginService: LoginService) {
  }

  ngOnInit(): void {
    this.loginService.loggedInUser().pipe(takeUntil(this.ngUnsubscribe$)).subscribe({
      next: userId => {
        this.loggedInUser = userId;
      },
      error: err => {
        throw err;
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Necessary for not displaying listbox with recipients after 'wissen'
    if (!Array.isArray(changes.receivers.currentValue) || changes.receivers.currentValue.length === 0) {
      this.recipients = undefined;
    }
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe$.next();
    this.ngUnsubscribe$.complete();
  }

  public addReceivers(): void {
    this.loading = true;
    const userIdOrName: string = this.userIdOrNameInput.nativeElement.value.trim();
    this.userIdOrNameInput.nativeElement.value = userIdOrName;
    const sendingFileToYourselfIsNotAllowed = this.applicationConfigService.getSendingFileToYourselfIsNotAllowed();

    if (userIdOrName === null || userIdOrName.match(/^ *$/) !== null) {
      this.displayMessageForEmptyInputField();
      this.loading = false;
    } else if (sendingFileToYourselfIsNotAllowed && userIdOrName.toLowerCase() === this.loggedInUser.toLowerCase()) {
      this.displayMessageForReceiverIsEqualToUser();
      this.loading = false;
    } else {
      this.receiverService.getRecipients(userIdOrName).subscribe({
        next: (recipients: Recipient[]) => {
          if (recipients != null) {
            if (recipients.length === 1) {
              this.addReceiver(recipients[0]);
            } else {
              this.userIdOrNameInput.nativeElement.value = '';
              this.loading = false;
              this.recipients = recipients;
            }
          } else {
            this.displayMessageForNoRecipientsFound(userIdOrName);
            this.loading = false;
            this.recipients = undefined;
          }
        },
        error: err => {
          this.loading = false;
          throw err;
        }
      });
    }
  }

  public addReceiver(recipient: Recipient): void {
    const receiver: Receiver = {id: recipient.id, name: recipient.name, email: recipient.email, type: recipient.type};
    this.displayMessageForAddingReceiver(receiver);
    this.receivers.push(receiver);
    this.userIdOrNameInput.nativeElement.value = '';
    this.changeReceivers.emit(this.receivers);
    this.loading = false;
    this.recipients = undefined;
  }

  public removeReceiver(index: number): void {
    this.displayMessageForDeletingReceiver(index);
    this.receivers.splice(index, 1);
    this.changeReceivers.emit(this.receivers);
  }

  private displayMessageForEmptyInputField(): void {
    this.messageService.add({
      closable: true,
      sticky: true,
      severity: 'error',
      summary: `Ontvanger mag niet leeg zijn`
    });
  }

  private displayMessageForReceiverIsEqualToUser(): void {
    this.messageService.add({
      closable: true,
      sticky: true,
      severity: 'error',
      summary: `U mag uzelf niet als ontvanger opgeven`
    });
  }

  private displayMessageForNoRecipientsFound(userIdOrName: string): void {
    this.messageService.add({
      closable: true,
      sticky: true,
      severity: 'error',
      summary: `Geen ontvanger(s) gevonden`,
      detail: `${userIdOrName} is onbekend`
    });
  }

  private displayMessageForAddingReceiver(receiver: Receiver): void {
    this.messageService.add({
      closable: false,
      severity: 'success',
      summary: `Ontvanger is toegevoegd`,
      detail: `${receiver.name}`
    });
  }

  private displayMessageForDeletingReceiver(index: number): void {
    this.messageService.add({
      closable: false,
      severity: 'success',
      summary: `Ontvanger verwijderd`,
      detail: `${this.receivers[index].name} is verwijderd`
    });
  }

}
