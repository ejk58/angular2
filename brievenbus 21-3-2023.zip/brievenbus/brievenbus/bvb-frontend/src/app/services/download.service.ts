import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DownloadService {

  constructor(private http: HttpClient) {
  }

  download(deliveryUUID: string): Observable<HttpResponse<any>> {
    let headers = new HttpHeaders();
    headers = headers.append('Accept', '*/*');

    return this.http.get('/api/download/' + deliveryUUID, {
      headers: headers, observe: 'response', responseType: 'blob'
    });
  }

}
