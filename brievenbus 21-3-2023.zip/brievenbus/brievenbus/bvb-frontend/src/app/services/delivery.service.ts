import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';

@Injectable()
export class DeliveryService {

  constructor(protected http: HttpClient) {
  }

  public getDelivery(uuid: string): Observable<any> {
    return this.http.get('api/delivery/get/' + uuid);
  }

}
