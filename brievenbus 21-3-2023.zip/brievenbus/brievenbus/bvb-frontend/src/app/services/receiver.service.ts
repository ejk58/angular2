import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';

@Injectable()
export class ReceiverService {

  constructor(protected http: HttpClient) {
  }

  public getRecipients(userIdOrName: string): Observable<any> {
    let params: HttpParams = new HttpParams();
    params = params.set('userIdOrName', userIdOrName);
    return this.http.get('api/recipient/find', {params: params});
  }

}
