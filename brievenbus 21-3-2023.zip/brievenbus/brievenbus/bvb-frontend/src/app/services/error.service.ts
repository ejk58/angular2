import {Injectable} from '@angular/core';
import {Observable, Subject} from 'rxjs';

@Injectable()
export class ErrorService {

  private readonly errorMessage$ = new Subject<string>();

  public addErrorMessage(errorMessage: string): void {
    this.errorMessage$.next(errorMessage);
  }

  public getErrorMessage(): Observable<string> {
    return this.errorMessage$.asObservable();
  }

}
