import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {lastValueFrom} from 'rxjs';
import {ApplicationConfig} from '../domain/application-config';

@Injectable()
export class ApplicationConfigService {

  private applicationConfig: ApplicationConfig;

  constructor(private readonly http: HttpClient, private readonly router: Router) {
  }

  async loadApplicationConfig(): Promise<void> {
    const configuration$ = this.http.get('/api/application/configuration');
    await lastValueFrom(configuration$)
      .then((config: ApplicationConfig) => this.applicationConfig = config)
      .catch((error: HttpErrorResponse) => {
        console.error('Error while initializing the configuration', error);
        if (error.status === 401 || error.status === 403) {
          localStorage.removeItem('id_token');
        }
        this.router.navigateByUrl('');
      });
  }

  getApplicationConfig(): ApplicationConfig {
    return this.applicationConfig;
  }

  getApplicationPlatform(): string {
    return this.applicationConfig.applicationPlatform;
  }

  getSendingFileToYourselfIsNotAllowed(): boolean {
    return this.applicationConfig.sendingFileToYourselfIsNotAllowed;
  }

  getEnterProductNumber(): boolean {
    return this.applicationConfig.enterProductNumber;
  }
}
