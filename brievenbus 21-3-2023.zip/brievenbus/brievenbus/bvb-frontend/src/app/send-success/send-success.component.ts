import {Component, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'b-send-success',
  templateUrl: './send-success.component.html',
  styleUrls: ['./send-success.component.scss']
})
export class SendSuccessComponent {

  @Output() startOver: EventEmitter<void> = new EventEmitter<void>();

}
