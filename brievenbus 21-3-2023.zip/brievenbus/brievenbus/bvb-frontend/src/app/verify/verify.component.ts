import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Delivery} from '../domain/delivery';
import {DisclaimerType} from '../domain/disclaimer-type';
import {VerificationValues} from '../domain/verification-values';
import {ApplicationConfigService} from '../services/application-config.service';

@Component({
  selector: 'b-verify',
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.scss']
})

export class VerifyComponent implements OnInit {

  @Input() readonly delivery: Delivery;
  @Output() changeChecked: EventEmitter<VerificationValues> = new EventEmitter<VerificationValues>();

  public readonly disclaimerTypePerson: DisclaimerType = 'verify-person';
  public readonly disclaimerTypeMailbox: DisclaimerType = 'verify-mailbox';

  public enterProductNumber: boolean;
  public hasPerson = false;
  public hasMailbox = false;
  public isCheckedPerson = false;
  public isCheckedMailbox = false;

  constructor(private readonly applicationConfigService: ApplicationConfigService) {}

  ngOnInit(): void {
    this.enterProductNumber = this.applicationConfigService.getEnterProductNumber();
    this.hasPerson = this.delivery.receivers.some(receiver => receiver.type === 'PERSON');
    this.hasMailbox = this.delivery.receivers.some(receiver => receiver.type === 'MAILBOX');
  }

  public onChangeCheckedPerson(isChecked: boolean): void {
    this.isCheckedPerson = isChecked;
    const bothPersonAndMailbox: VerificationValues = {isCheckedPerson: this.isCheckedPerson, isCheckedMailbox: this.isCheckedMailbox};
    const onlyPerson: VerificationValues = {isCheckedPerson: this.isCheckedPerson, isCheckedMailbox: null};
    this.changeChecked.emit(this.hasMailbox ? bothPersonAndMailbox : onlyPerson);
  }

  public onChangeCheckedMailbox(isChecked: boolean): void {
    this.isCheckedMailbox = isChecked;
    const bothPersonAndMailbox: VerificationValues = {isCheckedPerson: this.isCheckedPerson, isCheckedMailbox: this.isCheckedMailbox};
    const onlyMailbox: VerificationValues = {isCheckedPerson: null, isCheckedMailbox: this.isCheckedMailbox};
    this.changeChecked.emit(this.hasPerson ? bothPersonAndMailbox : onlyMailbox);
  }

}
