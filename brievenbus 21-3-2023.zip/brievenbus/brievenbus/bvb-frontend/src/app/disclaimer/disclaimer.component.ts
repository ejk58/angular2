import {Component, EventEmitter, Input, Output} from '@angular/core';
import {DisclaimerType} from '../domain/disclaimer-type';

@Component({
  selector: 'b-disclaimer',
  templateUrl: './disclaimer.component.html',
  styleUrls: ['./disclaimer.component.scss']
})

export class DisclaimerComponent {

  @Input() disclaimerType: DisclaimerType;
  @Output() changeCheckedPerson: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() changeCheckedMailbox: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() changeCheckedReceive: EventEmitter<boolean> = new EventEmitter<boolean>();

  public isCheckedPerson = false;
  public isCheckedMailbox = false;
  public isCheckedReceive = false;

  onChangeCheckedPerson(): void {
    this.isCheckedPerson = !this.isCheckedPerson;
    this.changeCheckedPerson.emit(this.isCheckedPerson);
  }

  onChangeCheckedMailbox(): void {
    this.isCheckedMailbox = !this.isCheckedMailbox;
    this.changeCheckedMailbox.emit(this.isCheckedMailbox);
  }

  onChangeCheckedReceive(): void {
    this.isCheckedReceive = !this.isCheckedReceive;
    this.changeCheckedReceive.emit(this.isCheckedReceive);
  }

  public send(): void {
    window.alert('TODO');
  }

}
