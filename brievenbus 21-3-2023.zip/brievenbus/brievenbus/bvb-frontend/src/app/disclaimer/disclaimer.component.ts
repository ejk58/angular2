import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Delivery} from '../domain/delivery';
import {DisclaimerType} from '../domain/disclaimer-type';

@Component({
  selector: 'b-disclaimer',
  templateUrl: './disclaimer.component.html',
  styleUrls: ['./disclaimer.component.scss']
})

export class DisclaimerComponent {

  @Input() offer: Delivery;
  @Input() disclaimerType: DisclaimerType;
  @Output() changeChecked: EventEmitter<boolean> = new EventEmitter<boolean>();

  public checked = false;

  isChecked(): void {
    this.checked = !this.checked;
    this.changeChecked.emit(this.checked);
  }

  public send(): void {
    window.alert('TODO');
  }

}
