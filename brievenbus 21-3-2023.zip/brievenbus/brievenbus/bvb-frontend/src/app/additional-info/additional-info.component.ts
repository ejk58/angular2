import {Component, EventEmitter, Input, Output} from '@angular/core';
import {MessageService} from 'primeng/api';

@Component({
  selector: 'b-additional-info',
  templateUrl: './additional-info.component.html',
  styleUrls: ['./additional-info.component.scss'],
  providers: [MessageService]
})
export class AdditionalInfoComponent {

  public PRODUCT_NUMBER_MAX_LENGTH = 32;

  @Input() productNumber: string;
  @Input() readOnly: boolean;
  @Output() changeProductNumber: EventEmitter<string> = new EventEmitter<string>();

  onProductNumberChange(): void {
    this.changeProductNumber.emit(this.productNumber);
  }

}
