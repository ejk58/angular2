import {Locator, Page} from '@playwright/test';

export default class ReceivePo {
  readonly checkCheckBox: Locator;
  readonly downloadButton: Locator;
  readonly toast: Locator;
  readonly appMessage: Locator;

  constructor(page: Page) {
    this.checkCheckBox = page.locator('.p-checkbox-box');
    this.downloadButton = page.locator('button.continue');
    this.toast = page.locator('p-toastitem');
    this.appMessage = page.locator('app-receive');
  }
}
