import {expect, Page, test} from '@playwright/test';
import {General} from '../shared/general';
import {Login} from '../shared/login';
import {APPURL, BRIEVENBUS_USER} from '../shared/shared.constants';
import ReceivePo from './ReceivePo';
import config from '../playwright.config';

test.describe('Receive (dwb): Download', () => {

  let page: Page, general: General, login: Login, receivePo: ReceivePo;

  test.beforeAll(async ({browser}) => {
    page = await browser.newPage({viewport: null});
    await page.setViewportSize({width: config.use.viewport.width, height: config.use.viewport.height});
    general = new General(page);
    login = new Login(page);
    receivePo = new ReceivePo(page);

    await page.goto(`${APPURL.baseUrl.dwb}/login`);
    await login.loginToApp('dwb', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
  });

  test.beforeEach(async ({}, testInfo) => {
    testInfo.snapshotSuffix = '';
  });

  test.afterAll(async () => {
    await page.close();
  });

  test('Should show initial recieve page when logged in without uuid', async () => {
    await general.checkWindow('receiveLoggedInInitialWithoutUUID.png')
  });

  test('Should show recieve page with invalid uuid', async () => {
    await page.goto(`${APPURL.baseUrl.dwb}/receive?8fba387d-5954-424b-9999-6d2306215a12`);
    await expect(receivePo.appMessage).toHaveText('ProbleemKlik op de link in de mail om een levering op te halen.');
  });

  test('Should show initial recieve page with valid uuid', async () => {
    await page.goto(`${APPURL.baseUrl.dwb}/receive?uuid=a60b683b-cd31-41f5-8c50-1ad4a6d5cdac`);
    await expect(page.locator('.receive-container')).toBeVisible();
    await general.checkWindow('receiveWithValidUUID.png');
  });

  test('Should show disabled downloaded button', async () => {
    await expect(receivePo.downloadButton).toBeDisabled();
  });

  test('Should show file downloaded toast', async () => {
    await receivePo.checkCheckBox.click();
    await expect(receivePo.downloadButton).toBeEnabled();
    await receivePo.downloadButton.click();
    await general.checkRegion(receivePo.toast.nth(0), 'receiveFileDownloaded.png');
  });
});
