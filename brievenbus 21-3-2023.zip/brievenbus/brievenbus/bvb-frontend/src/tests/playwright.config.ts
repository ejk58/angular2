import {PlaywrightTestConfig} from '@playwright/test';

const config: PlaywrightTestConfig = {
  // forbidOnly: !!process.env.CI,
  // video: 'on-first-retry',
  // screenshot: 'only-on-failure',
  retries: process.env.CI ? 2 : 0,
  reporter: [['html', {open: 'never'}]],
  use: {
    // trace: 'retain-on-failure',
    ignoreHTTPSErrors: true,
    viewport: {width: 1280, height: 720},
    browserName: 'chromium',
    channel: 'chrome',
    launchOptions: {
      // slowMo: 2000,
      headless: false,
      args: ['--browser-test', '--incognito' , '--disable-gpu', '--disable-infobars', '--disable-extensions', '--ignore-certificate-errors', '--no-sandbox', '--disable-dev-shm-usage'],
    },
  },
  expect: {
    toMatchSnapshot: {
      maxDiffPixelRatio: 0.02
    }
  },
  // testMatch: ["test.spec.ts"],
};
export default config;
