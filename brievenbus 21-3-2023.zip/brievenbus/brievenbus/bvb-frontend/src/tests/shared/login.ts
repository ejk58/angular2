import {expect, Page} from '@playwright/test'
import {APPURL} from './shared.constants';
import {General} from './general';

export class Login {
  readonly page: Page;
  readonly general: General;

  constructor(page: Page) {
    this.page = page;
    this.general = new General(this.page);
  }

  async openApp(environment: string) {
    let baseUrl: string;
    switch (environment) {
      case 'adp':
        baseUrl = APPURL.baseUrl.adp;
        break;
      case 'dwb':
        baseUrl = APPURL.baseUrl.dwb;
        break;
      case 'adpRtvip':
        baseUrl = APPURL.baseUrl.adpRtvip;
        break;
      case 'dwbRtvip':
        baseUrl = APPURL.baseUrl.dwbRtvip;
        break;
      default:
        baseUrl = null;
        break;
    }

    await this.clearBrowserData();
    await this.page.goto(baseUrl);
    await this.page.waitForNavigation({url: /login/gm})
  }

  async setUsername(name: string) {
    await this.page.locator('form > span > input').nth(0).fill(name);
  }

  async setPassword(password: string) {
    await this.page.locator('form > span > input').nth(1).fill(password);
  }

  async clickOnLoginButton() {
    await this.page.locator('.login-button-position').click()
  }

  async loginToApp(environment: string, username: string, password: string, loginTest?: boolean) {
    await this.openApp(environment);
    await this.general.waitForAngular();
    await this.setUsername(username);
    await this.setPassword(password);
    await this.clickOnLoginButton();
    if (loginTest === true) {
      await expect(this.page).toHaveURL(/login/gm);
    }
  }

  async logoutFromApp() {
    await this.page.locator('button.p-button.logout').click();
    await expect(this.page).toHaveURL(/login/gm);
  }

  /**
   * Clears browsers localstorage, session storage and deletes all cookies.
   * */
  async clearBrowserData() {
    await this.page.evaluate(() => window.localStorage.clear());
    await this.page.evaluate(() => window.sessionStorage.clear());
    await this.page.context().clearCookies();
  }

}
