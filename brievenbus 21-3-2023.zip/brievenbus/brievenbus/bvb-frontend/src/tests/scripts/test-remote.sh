clear
echo "<Optional> Path to test? For example: src/tests/login/login.spec.ts"
read filePath

if [ -z "${filePath}" ]; then
  echo "Path is empty.. Do you want to test all? (Y/n)"
  read answer
  if [ $answer == "y" ] || [ $answer == "Y" ]; then
    filePath="./tests"
  else
    echo "Tests will not be executed."
    exit 1
  fi
fi

SELENIUM_REMOTE_URL=http://selenium-hub-wd-selenium-grid-4.apps.cn01.chp.belastingdienst.nl/wd/hub SELENIUM_REMOTE_CAPABILITIES='{"browserName": "chrome", "goog:chromeOptions":{"w3c":"false","args":["--incognito","--disable-infobars","--disable-extensions","--ignore-certificate-errors","--disable-dev-shm-usage"]}}' npx playwright test  --config=./src/tests/playwright.config.ts $filePath
