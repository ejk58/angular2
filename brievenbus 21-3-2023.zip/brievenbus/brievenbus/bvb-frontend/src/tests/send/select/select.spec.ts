import {expect, Page, test} from '@playwright/test';
import {General} from '../../shared/general';
import {Login} from '../../shared/login';
import SelectPo from '../select/SelectPo';
import config from '../../playwright.config';
import {APPURL, BRIEVENBUS_USER} from '../../shared/shared.constants';

test.describe('Send: Select', () => {

  let page: Page, general: General, login: Login, selectPo: SelectPo;

  const path = require('path'),
    resourceDir = `${process.cwd()}/resources`; // comment for local use
  // resourceDir = `${process.cwd()}/src/tests/resources`;  //uncomment for local use

  test.beforeAll(async ({browser}) => {
    page = await browser.newPage({viewport: null});
    await page.setViewportSize({width: config.use.viewport.width, height: config.use.viewport.height});
    general = new General(page);
    login = new Login(page);
    selectPo = new SelectPo(page);
  });

  test.beforeEach(async ({}, testInfo) => {
    testInfo.snapshotSuffix = '';
  });

  test.afterAll(async () => {
    await page.close();
  });

  test.describe('ADP', () => {
    test.beforeAll(async () => {
      await page.goto(`${APPURL.baseUrl.adp}/login`);
      await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
    });

    test('Should show initial send page when logged in', async () => {
      await expect(page.locator('.logged-in-header-content > span')).toBeVisible();
      await general.checkWindow('sendSelectLoggedInInitial.png');
    });

    test.describe('Select receivers', () => {
      test('Should show message that user is not found', async () => {
        await selectPo.receiversUserid.fill('[${wrong}#@]');
        await selectPo.receiversButtonPlus.click();
        await general.checkRegion(selectPo.toast.nth(1), 'sendSelectReceiversUserNotFound.png');
        await selectPo.toastClose.nth(0).click();
      });

      test('Should show message that mailbox is not found', async () => {
        await selectPo.receiversUserid.fill('IV Accent CoE Maatwerk');
        await selectPo.receiversButtonPlus.click();
        await expect(selectPo.toastSummary.nth(0)).toHaveText('Geen ontvanger(s) gevonden');
        await expect(selectPo.toastDetail.nth(0)).toBeVisible();
        await selectPo.toastClose.nth(0).click();
      });

      test('Should variety of last names', async () => {
        await selectPo.receiversUserid.fill('beek');
        await selectPo.receiversButtonPlus.click();
        await expect(selectPo.receiversListboxListElement.nth(0)).toContainText('. Beek (');
        await expect(selectPo.receiversListboxListElement.nth(3)).toContainText('. BEEKHUIJZEN (');
        await expect(selectPo.receiversListboxListElement.nth(5)).toContainText('. Beekman (');
        await expect(selectPo.receiversListboxListElement.nth(8)).toContainText('. ter Beek (');
        await expect(selectPo.receiversListboxListElement.nth(18)).toContainText('. van de Beek - Hoksbergen (');
        await general.checkRegion(selectPo.receiversListbox, 'sendSelectReceiversVarietyOfNames.png');
      });

      test('Should show disable add button when maximum receivers is reached', async () => {
        await selectPo.receiversUserid.fill('bihas07');
        await selectPo.receiversButtonPlus.click();
        await expect(selectPo.receiversTableUsername.nth(0)).toHaveText('Sanjay S.S. Bihari');
        await selectPo.receiversUserid.fill('kerke02');
        await selectPo.receiversButtonPlus.click();
        await expect(selectPo.receiversTableUsername.nth(1)).toHaveText('Ed E.J. KERKHOVEN');
        await selectPo.receiversUserid.fill('benti00');
        await selectPo.receiversButtonPlus.click();
        await expect(selectPo.receiversTableUsername.nth(2)).toHaveText('Inge I.E. van Benthem');
        await selectPo.receiversUserid.fill('hubem00');
        await selectPo.receiversButtonPlus.click();
        await expect(selectPo.receiversTableUsername.nth(3)).toHaveText('Marijn M.C. HUBERT');
        await selectPo.receiversUserid.fill('vermr09');
        await selectPo.receiversButtonPlus.click();
        await expect(selectPo.toastSummary.nth(0)).toHaveText('Ontvanger is toegevoegd');
        await expect(selectPo.toastDetail.nth(0)).toBeVisible();
        await expect(selectPo.receiversTableUsername.nth(4)).toHaveText('Ron R.A.M. VERMAAS');
        await general.delay(1000);
        await general.checkRegion(selectPo.receiversContainer, 'sendSelectReceiversMaximumReceivers.png');
      });

      test('Should remove users when button is clicked', async () => {
        await selectPo.receiversButtonMinus.nth(0).click();
        await selectPo.receiversButtonMinus.nth(0).click();
        await selectPo.receiversButtonMinus.nth(0).click();
        await selectPo.receiversButtonMinus.nth(0).click();
        await expect(selectPo.toastSummary.nth(0)).toHaveText('Ontvanger verwijderd');
        await expect(selectPo.toastDetail.nth(0)).toContainText(' is verwijderd');
        await general.delay(1000);
        await general.checkRegion(selectPo.receiversContainer, 'sendSelectReceiversRemovedReceivers.png');
      });

      test('Should show user is unkown toast (Can search logged in user)', async () => {
        await selectPo.receiversUserid.fill('ivatest1');
        await selectPo.receiversButtonPlus.click();
        await expect(selectPo.toastDetail.nth(0)).toBeVisible();
        await expect(selectPo.toastDetail.nth(1)).toHaveText('ivatest1 is onbekend');
        await expect(selectPo.toastSummary.nth(0)).toHaveText('Geen ontvanger(s) gevonden');
        await selectPo.toastClose.click();
      });
    });

    test.describe('File(s)', () => {
      test('Should add file', async () => {
        await page.waitForSelector('p-toastitem', {state: 'detached'});
        await selectPo.fileUploadInput.setInputFiles(path.resolve(resourceDir, 'upload.txt'));
        await expect(selectPo.toastSummary.nth(0)).toHaveText('Bestand is toegevoegd');
        await expect(selectPo.toastDetail.nth(0)).toHaveText('upload.txt');
        await general.checkRegion(selectPo.fileUploadContainer, 'sendSelectFileAdded.png');
      });

      test('Should remove file', async () => {
        await general.delay(1000);
        await selectPo.fileUploadRemove.click();
        await expect(selectPo.toastSummary.nth(0)).toHaveText('Bestand is verwijderd');
        await general.checkRegion(selectPo.fileUploadContainer, 'sendSelectFileRemoved.png');
      });
    });
  });

  test.describe('ADP RTVIP', () => {
    test.beforeAll(async () => {
      await page.goto(`${APPURL.baseUrl.adp}/login`);
      await login.loginToApp('adpRtvip', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
    });

    test('Should show message that mailbox is added', async () => {
      await selectPo.receiversUserid.fill('IV Accent CoE Maatwerk');
      await selectPo.receiversButtonPlus.click();
      await expect(selectPo.toastSummary.nth(0)).toHaveText('Ontvanger is toegevoegd');
      await expect(selectPo.toastDetail.nth(0)).toBeVisible();
      await expect(selectPo.receiversTableUsername.nth(0)).toHaveText('IV Accent CoE Maatwerk');
    });

    test('Should show message that you can not search as yourself', async () => {
      await selectPo.receiversUserid.fill('ivatest1');
      await selectPo.receiversButtonPlus.click();
      await expect(selectPo.toastSummary.nth(0)).toHaveText('U mag uzelf niet als ontvanger opgeven');
    });

    test('Should not be possible to insert more than 32 characters in productnumber field', async () => {
      await selectPo.additionalInfoProductnumber.fill('prodnr:01234567890123456789012345');
      await expect(selectPo.additionalInfoProductnumber).toHaveValue('prodnr:0123456789012345678901234');
    });

    test.describe('Should clear form', () => {
      test('Should not clear form', async () => {
        await selectPo.fileUploadInput.setInputFiles(path.resolve(resourceDir, 'upload.txt'));
        await selectPo.buttonContainerClear.click();
        await selectPo.buttonContainerDialogButtons.nth(0).click();
        await expect(selectPo.fileUploadRemove).toBeVisible();
        await expect(selectPo.toastDetail.nth(0)).not.toBeVisible();
      });

      test('Should clear form', async () => {
        await selectPo.buttonContainerClear.click();
        await selectPo.buttonContainerDialogButtons.nth(1).click();
        await general.checkWindow('sendSelectAllFieldsCleared.png');
      });
    });
  });
});
