import {Locator, Page} from '@playwright/test';

export default class SelectPo {
  readonly receiversContainer: Locator;
  readonly receiversUserid: Locator;
  readonly receiversButtonPlus: Locator;
  readonly receiversButtonMinus: Locator;
  readonly receiversTableUsername: Locator;
  readonly receiversListbox: Locator;
  readonly receiversListboxListElement: Locator;

  readonly additionalInfoProductnumber: Locator;

  readonly fileUploadContainer: Locator;
  readonly fileUploadInput: Locator;
  readonly fileUploadRemove: Locator;

  readonly buttonContainerClear: Locator;
  readonly buttonContainerConfirm: Locator;
  readonly buttonContainerDialogButtons: Locator;

  readonly toast: Locator;
  readonly toastMessage: Locator;
  readonly toastClose: Locator;
  readonly toastSummary: Locator;
  readonly toastDetail: Locator;

  constructor(page: Page) {
    // receivers
    this.receiversContainer = page.locator('.receivers-container');
    this.receiversUserid = page.locator('.recipients-input-field > input');
    this.receiversButtonPlus = page.locator('.recipients-input-field .plus');
    this.receiversButtonMinus = page.locator('.receivers-table .minus');
    this.receiversTableUsername = page.locator('.receivers-table .user-name');
    this.receiversListbox = page.locator('div.recipients-listbox');
    this.receiversListboxListElement = page.locator('div.recipients-listbox li div');

    // additional info container
    this.additionalInfoProductnumber = page.locator('[placeholder="Verplicht invullen\, maximaal 32 posities"]');

    // file-upload
    this.fileUploadContainer = page.locator('.file-upload-container');
    this.fileUploadRemove = page.locator('.p-fileupload-row .pi-times');
    this.fileUploadInput = page.locator('.p-fileupload-buttonbar input[type=file]');

    // button-container
    this.buttonContainerClear = page.locator('.button-container .clear');
    this.buttonContainerConfirm = page.locator('.button-container .continue');
    this.buttonContainerDialogButtons = page.locator('.p-dialog-footer .continue');

    // toast
    this.toast = page.locator('.p-toast-top-right');
    this.toastMessage = page.locator('p-toastitem');
    this.toastClose = page.locator('.p-toast-icon-close');
    this.toastSummary = page.locator('.p-toast-summary');
    this.toastDetail = page.locator('.p-toast-detail');
  }
}
