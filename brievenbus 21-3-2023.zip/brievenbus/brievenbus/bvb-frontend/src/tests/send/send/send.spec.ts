import {expect, Page, test} from '@playwright/test';
import {General} from '../../shared/general';
import {Login} from '../../shared/login';
import {APPURL, BRIEVENBUS_USER} from '../../shared/shared.constants';
import CheckPo from '../check/CheckPo';
import SelectPo from '../select/SelectPo';
import SendPo from './SendPo';
import config from '../../playwright.config';

test.describe('Send (ADP RTVIP): Check', () => {

  let page: Page, general: General, login: Login, checkPo: CheckPo, selectPo: SelectPo, sendPo: SendPo;

  const path = require('path'),
    resourceDir = `${process.cwd()}/resources`; // comment for local use
    // resourceDir = `${process.cwd()}/src/tests/resources`;  //uncomment for local use

  test.beforeAll(async ({browser}) => {
    page = await browser.newPage({viewport: null});
    await page.setViewportSize({width: config.use.viewport.width, height: config.use.viewport.height});
    general = new General(page);
    login = new Login(page);
    checkPo = new CheckPo(page);
    selectPo = new SelectPo(page);
    sendPo = new SendPo(page);
  });

  test.beforeEach(async ({}, testInfo) => {
    testInfo.snapshotSuffix = '';

    await page.goto(`${APPURL.baseUrl.adpRtvip}/login`);
    await login.loginToApp('adpRtvip', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
  });

  test.afterAll(async () => {
    await page.close();
  });

  test('Should show initial send page with mailbox as receiver', async () => {
    await selectPo.receiversUserid.fill('IV Accent CoE Maatwerk');
    await selectPo.receiversButtonPlus.click();
    await selectPo.additionalInfoProductnumber.fill('prodnr:1234');
    await selectPo.fileUploadInput.setInputFiles(path.resolve(resourceDir, 'upload.txt'));
    await selectPo.buttonContainerConfirm.click();
    await sendPo.wizardSelectbox.click();
    await general.checkFullPage('sendMailboxReceiver.png');
  });

  test('Should show send page with mailbox and user as receiver', async () => {
    // await sendPo.wizardBack.click();
    await selectPo.receiversUserid.fill('bihas07', {timeout: 1000});
    await selectPo.receiversButtonPlus.click();
    await expect(selectPo.receiversTableUsername.nth(0)).toHaveText('Sanjay S.S. Bihari');
    await selectPo.receiversUserid.fill('IV Accent CoE Maatwerk');
    await selectPo.receiversButtonPlus.click();
    await expect(selectPo.receiversTableUsername.nth(1)).toHaveText('IV Accent CoE Maatwerk');
    await selectPo.additionalInfoProductnumber.fill('prodnr:1234');
    await selectPo.fileUploadInput.setInputFiles(path.resolve(resourceDir, 'upload.txt'));
    await selectPo.buttonContainerConfirm.click();
    await sendPo.wizardSelectbox.nth(1).click();
    await general.checkFullPage('sendMailboxReceiverAndPerson.png');
    await sendPo.wizardBack.click();
  });

  test('Should show a new delivery page', async () => {
    await selectPo.receiversUserid.fill('IV Accent CoE Maatwerk');
    await selectPo.receiversButtonPlus.click();
    await selectPo.fileUploadInput.setInputFiles(path.resolve(resourceDir, 'upload.txt'));
    await selectPo.additionalInfoProductnumber.fill('prodnr:1234');
    await selectPo.buttonContainerConfirm.click();
    await sendPo.wizardSelectbox.click();
    await expect(sendPo.wizardContinue).toBeVisible({timeout: 15000});
    await sendPo.wizardContinue.click();
    await expect(sendPo.wizardSendSuccessContainer).toBeVisible();
    await general.checkFullPage('sendSendNewDelivery.png')
  });

});
