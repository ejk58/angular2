'use strict'

import {by, element} from 'protractor';

export default class SendPo {
  // wizard container
  wizardContainer = element(by.css('.wizard-container'));
  wizardContinue = element(by.css('.button-container .continue'));
}
