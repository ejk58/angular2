'use strict'

import {by, element} from 'protractor';

export default class CheckPo {
  // wizard container
  wizardContainer = element(by.css('.wizard-container'));

  // button-container
  buttonContainerBack = element(by.css('.button-container .back'));
}
