import {checkRegion, checkWindow} from '../../../../shared/imageCompare';
import {Login} from '../../../../shared/login';
import {BRIEVENBUS_USER} from '../../../../shared/shared.constants';
import SelectPo from './select.po';
import {browser} from 'protractor';
import {waitForElementVisible} from '../../../../shared/general';

describe('Send (adp): Select', () => {

  let remote = require('selenium-webdriver/remote');
  let login, selectPo;

  beforeAll(async () => {
    login = new Login();
    selectPo = new SelectPo();

    await browser.setFileDetector(new remote.FileDetector());
    await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
  });

  afterAll(async () => {
    await login.logoutFromApp();
  });

  describe('Select', () => {

    it('should show initial send page when logged in', async () => {
      await checkWindow('sendSelectLoggedInInitial');
    });

  });

  describe('Send: Select receivers', () => {

    it('should show message that user is not found', async () => {
      await selectPo.receiversUserid.sendKeys('wrong');
      await selectPo.receiversButtonPlus.click();
      await checkRegion(selectPo.toast.get(1),'sendSelectReceiversUserNotFound',false,false);
      await selectPo.toastClose.get(0).click();
    });

    it('should show disable add button when maximum receivers is reached', async () => {
      await selectPo.receiversUserid.clear();
      await selectPo.receiversUserid.sendKeys('ivatest1');
      await selectPo.receiversButtonPlus.click();
      await waitForElementVisible(selectPo.receiversTableUsername.get(0));
      await expect(selectPo.receiversTableUsername.get(0).getText()).toContain('Test1');
      await selectPo.receiversUserid.sendKeys('ivatest2');
      await selectPo.receiversButtonPlus.click();
      await waitForElementVisible(selectPo.receiversTableUsername.get(1));
      await expect(selectPo.receiversTableUsername.get(1).getText()).toContain('Test2');
      await selectPo.receiversUserid.sendKeys('ivatest3');
      await selectPo.receiversButtonPlus.click();
      await waitForElementVisible(selectPo.receiversTableUsername.get(2));
      await expect(selectPo.receiversTableUsername.get(2).getText()).toContain('Test');
      await selectPo.receiversUserid.sendKeys('ivatest4');
      await selectPo.receiversButtonPlus.click();
      await waitForElementVisible(selectPo.receiversTableUsername.get(3));
      await expect(selectPo.receiversTableUsername.get(3).getText()).toContain('ivatest4');
      await selectPo.receiversUserid.sendKeys('ivatest5');
      await selectPo.receiversButtonPlus.click();
      await expect(selectPo.toastSummary.get(0).getText()).toEqual('Ontvanger is toegevoegd');
      await expect(selectPo.toastDetail.get(0).getText()).toEqual('Iva I. Test1');
      await waitForElementVisible(selectPo.receiversTableUsername.get(4));
      await expect(selectPo.receiversTableUsername.get(4).getText()).toContain('ivatest5');
      await browser.sleep(1000);
      await checkRegion(selectPo.receiversContainer,'sendSelectReceiversMaximumReceivers');
    });

    it('should remove users when button is clicked', async () => {
      await selectPo.receiversButtonMinus.get(0).click();
      await selectPo.receiversButtonMinus.get(0).click();
      await selectPo.receiversButtonMinus.get(0).click();
      await selectPo.receiversButtonMinus.get(0).click();
      await expect(selectPo.toastSummary.get(0).getText()).toEqual('Ontvanger verwijderd');
      await expect(selectPo.toastDetail.get(0).getText()).toEqual('Iva I. Test1 is verwijderd');
      await browser.sleep(1000);
      await checkRegion(selectPo.receiversContainer,'sendSelectReceiversRemovedReceivers');
    });

  });

  describe('Send: Add file', () => {

    it('should add file', async () => {
      await selectPo.fileUploadInput.sendKeys(`${process.cwd()}/src/test/e2e/resources/upload.txt`);
      await expect(selectPo.toastSummary.get(0).getText()).toEqual('Bestand is toegevoegd');
      await expect(selectPo.toastDetail.get(0).getText()).toEqual('upload.txt');
      await checkRegion(selectPo.fileUploadContainer,'sendSelectFileAdded');
    });


    it('should remove file', async () => {
      await browser.sleep(1000);
      await selectPo.fileUploadRemove.click();
      await expect(selectPo.toastSummary.get(0).getText()).toEqual('Bestand is verwijderd');
      await checkRegion(selectPo.fileUploadContainer,'sendSelectFileRemoved');
    });

  });

  describe('Send: Clear form', () => {

    it('should not clear form', async () => {
      await selectPo.fileUploadInput.sendKeys(`${process.cwd()}/src/test/e2e/resources/upload.txt`);
      await selectPo.buttonContainerClear.click();
      await selectPo.buttonContainerDialogButtons.get(0).click();
      await expect(selectPo.fileUploadRemove.isDisplayed()).toBeTruthy();
    });

    it('should clear form', async () => {
      await selectPo.buttonContainerClear.click();
      await selectPo.buttonContainerDialogButtons.get(1).click();
      await expect(selectPo.fileUploadRemove.isPresent()).toBeFalsy();
    });

  });

});
