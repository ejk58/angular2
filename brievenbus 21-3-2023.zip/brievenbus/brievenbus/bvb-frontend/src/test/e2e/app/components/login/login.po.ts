'use strict'

import {by, element} from 'protractor';

export default class LoginPo {
  authenticationContainer = element(by.css('.login-form'));

  // input fields
  userIdInput = element.all(by.css('form > span > input')).get(0);
  userPasswordInput = element.all(by.css('form > span > input')).get(1);

  // error locator
  loginError = element(by.css('.login-error'));

  // expected values
  errorMessageRetry = 'Gebruikersnaam en/of wachtwoord fout';
}
