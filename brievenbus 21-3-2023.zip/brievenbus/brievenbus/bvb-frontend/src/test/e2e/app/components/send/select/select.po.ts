'use strict'

import {by, element} from 'protractor';

export default class SelectPo {
  // receivers
  receiversContainer = element(by.css('.receivers-container'));
  receiversUserid = element(by.css('.receivers-input-field > input'));
  receiversButtonPlus = element(by.css('.receivers-input-field .plus'));
  receiversButtonMinus = element.all(by.css('.receivers-table .minus'));
  receiversTableUsername = element.all(by.css('.receivers-table .user-name'));

  // file-upload
  fileUploadContainer = element(by.css('.file-upload-container'));
  fileUploadInput = element(by.css('.p-fileupload-choose > input'));
  fileUploadRemove = element(by.css('.p-fileupload-row .pi-times'));

  // button-container
  buttonContainerClear = element(by.css('.button-container .clear'));
  buttonContainerConfirm = element(by.css('.button-container .continue'));
  buttonContainerDialogButtons = element.all(by.css('.p-dialog-footer .continue'));

  // toast
  toast = element.all(by.css('.p-toast-top-right'));
  toastMessage = element.all(by.css('p-toastitem'));
  toastClose = element.all(by.css('.p-toast-icon-close'));
  toastSummary = element.all(by.css('.p-toast-summary'));
  toastDetail = element.all(by.css('.p-toast-detail'));
}
