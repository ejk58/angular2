'use strict'

import {browser, by, element, protractor} from 'protractor';
import {APPURL} from './shared.constants';

export class Login {

  async openApp(environment: string) {
    let baseUrl = environment === 'adp' ? APPURL.baseUrl.adp : environment === 'dwb' ? APPURL.baseUrl.dwb : null;
    await browser.get(baseUrl);
    await this.clearBrowserData();
    await browser.manage().timeouts().setScriptTimeout(60000);
    await browser.manage().timeouts().implicitlyWait(10000);
    await browser.get(baseUrl);
    await browser.wait(protractor.ExpectedConditions.urlContains('/login'), 5000, 'Login failed');
    // await browser.waitForAngularEnabled(true);
  }

  async setUsername(name: string) {
    await element.all(by.css('form > span > input')).get(0).sendKeys(name);
  }

  async setPassword(password: string) {
    await element.all(by.css('form > span > input')).get(1).sendKeys(password);
  }

  async clickOnLoginButton() {
    let loginButton = element.all(by.css('.login-button-position'));

    await loginButton.get(0).click();
    // await loginButton.count().then(function(count) {
    //   if (count === 1) {
    //     loginButton.click();
    //   }
    // });
  }

  async loginToApp(environment: string, username: string, password: string, loginTest?: boolean) {
    await this.openApp(environment);
    await browser.waitForAngularEnabled(false);
    await this.setUsername(username);
    await this.setPassword(password);
    await this.clickOnLoginButton();
    if (loginTest === true) {
      await browser.wait(protractor.ExpectedConditions.urlContains('/login'), 5000, 'Login failed');
    }
  }

  async logoutFromApp() {
    await browser.executeScript('document.getElementsByClassName(\'logout\')[0].click()');
  }

  /**
   * Disables CSS animation.
   * Turning off Angular animations must be investigated.
   * */
  async disableAnimation() {
    await browser.executeScript('document.querySelector(\'head\').innerHTML += \'<style>.notransition * {' +
      '-webkit-transition: none !important;' +
      '-moz-transition: none !important;' +
      '-o-transition: none !important;' +
      '-ms-transition: none !important;' +
      'transition: none !important;}</style>\';');
    await browser.executeScript('document.body.classList.add("notransition");');
  }

  /**
   * Clears browsers localstorage, session storage and deletes all cookies.
   * */
  async clearBrowserData() {
    await browser.executeScript('window.localStorage.clear();');
    await browser.executeScript('window.sessionStorage.clear();');
    await browser.driver.manage().deleteAllCookies();
  }

}
