/**
 * Configuration to run protractor on 1 browser instance.
 *
 * One configuration setting has been changed compared to protractor.conf.js:
 * - multiCapabilities (no 'shardTestFiles' and no 'maxInstances');
 */
protractor = require('./protractor.conf.js');
let config = protractor.config;

// Capabilities for the webdriver instance
config.multiCapabilities = [
    {
      browserName: 'chrome',
      logName: 'chrome-latest',
      'goog:chromeOptions': {
            // Disable warnings and disable infobars when starting chrome
            'w3c': false,
            args: ["--headless", "--disable-gpu", "--disable-infobars", "--disable-extensions", "--ignore-certificate-errors", "--no-sandbox", "--disable-dev-shm-usage"],
        }
    }
];

exports.config = config;
