# Project beschrijving

## Bestanden

- ~~auto deploy/scripts - Shell scripts en jacl-scripts die gebruikt worden op de WAS-deployment manager~~ Deprecated
- get links - Bestanden t.b.v. de Jenkins job 'Generate links'
- isAlive - Bestanden t.b.v. de Jenkins job 'isAlive'
- ~~soapui~~ - Deprecated
- vars - Groovy script die gebruikt worden door het build proces op de Jenkins server.

## procedures

Beschrijving van de verschillende procedures / acties die mbv. deze library uit te voeren zijn.

- Project bouwen en testen zodra iets gepushed wordt naar de git repository.
- Release van een project.
- Release deployen.

Zie voor de inrichting van een project de confluence pagina [Jenkins jobs](https://devtools.belastingdienst.nl/confluence/display/CM/Jenkins+jobs)

### Bouwen en testen van een project

Zodra wijzigingen gemaakt worden in de git repository kan Jenkins het projecten bouwen, het gebouwde product deployen en op het draaiende product de nodige testen uitvoeren.

Het project moet in de root van de git repository een groovy script hebben staan met de naam "pipeline.groovy" die verwijst naar het pipelineCode_v3 groovy script.

Voor de inrichting van projecten zie de [Jenkins jobs](https://devtools.belastingdienst.nl/confluence/display/CM/Jenkins+jobs) pagina op Confluence

### Releasen van een project naar Nexus

Het is mogelijk om een project (mbv. een Jenkins job) te releasen, waarbij het resultaat van de build (het artifact) geupload wordt naar de standaard BD maven repository ( [Nexus](http://rms.belastingdienst.nl:8080/nexus) ).

Om een project te kunnen releasen mbv. Jenkins moet een pipeline job aangemaakt worden met de naam "buildRelease.groovy" die verwijst naar het pipelineRelease script.

De benodigde credentials zijn in een standaard maven settingsfile gedefinieerd die in Jenkins is opgenomen onder 'Managed files' (Manage Jenkins -> Managed files)

Wanneer de job is gestart vanuit de develop branch van het project zal na het runnen in de repository van het betreffende project een release branch en een tag aangemaakt, deze release branch is gebruikt om het artifact te bouwen wat na de build op de Nexus server geplaatst is.

Wanneer de job is gestart vanuit een release branch van het project zal na het runnen in de repository van het betreffende project een tag zijn aangemaakt. De genoemde release branch is gebruikt om het artifact te bouwen wat na de build op de Nexus server geplaatst is.

### Deployen van een applicatie vanaf Nexus

Het is mogelijk om een project waarvan een release op Nexus staat (bijv. gebouwd mbv. bovenstaande procedure) te deployen mbv. een Jenkins job.

Om een project te kunnen deployen mbv. Jenkins moet een pipeline script aangemaakt worden met de naam "deployRelease.groovy" die verwijst naar het pipelineDeployArtifactFromNexus script.

Om een project te kunnen deployen vanaf Nexus mbv. Jenkins moet een pipeline job aangemaakt worden met een verwijzing naar de juiste git repository en met als script path de naam van de script file zoals hierboven aan het project is toegevoegd (deployArtifactFromNexusPipeline.groovy).

Na het runnen van de job is de juiste versie van de applicatie uit nexus gedownload en gedeployed op de aangegeven omgeving/straat, evt. zijn na deployment de integratie testen gedraaid.

### groovy scripts

Hierbij een beschrijving van een aantal groovy script files zodat aanpassingen aan het systeem eenvoudig uitgevoerd kunnen worden.

![Schema van de scripts](CI_Scripts.png "Schema van de scripts en hun samenhang")

##Basis scripts##

**pipelineDatabase.groovy**

Dit script wordt gebruikt door het pipeline.groovy script van een database project. Als eerste worden de aangebrachte wijzigingen uitgerold op de betreffende omgeving. Wanneer gekozen is om ook een dropAll te doen, dan wordt de betreffende database leeggemaakt, de master branch van het project wordt uitgecheckt en uitgerold en daarna wordt de develop branch van het project uitgecheckt en wordt deze nogmaals uitgerold op de omgeving.

Deze manier van werken zorgt er voor dat de updates correct werken wanneer ze uitgerold worden in productie.

**pipelineCode_v3.groovy**

Dit script wordt gebruikt vanuit het pipeline.groovy script van een java project. Zodra wijzigingen gepushed worden naar de git repository zal een job dit script gebruiken om het project te bouwen, uit te rollen en er de integratie testen op uit te voeren (mbv. het pipelineTest script).

**pipelineTest.groovy**

Dit script wordt gebruikt om alle robot testen uit te voeren op een applicatie.

**pipelineProtractorTest.groovy**

Dit script wordt gebruikt om alle protractor testen uit te voeren op een applicatie.

**pipelineRelease.groovy**

Dit script wordt gebruikt bij het maken van een release van een project.

**pipelineDeployArtifactFromNexus.groovy**

Dit script wordt gebruikt bij het uitroolen van een release.

**pipelineSIG.groovy**

Dit script wordt gebruikt bij het maken van een oplevering aan de SIG van het zaakadministratie project. Dit project bestaat uit meerdere modules (zaakadministratie, beheermodule, etc. en heeft daarom extra bewerkingen nodig.

**ApplicationConfiguration.groovy**

Dit script wordt gebruikt door andere groovy scripts en bevat een groot deel van de benodigde configuratie gegevens. Het is de bedoeling dat dit script op termijn alle configuratie gegevens gaat bevatten.

De configuratie gegevens bevat oa. de destinations voor alle omgevingen per project en andere standaard gegevens.

Mbv. het deploymentId en de omgeving waarop gedeployd moet worden kunnen de systeem gegevens als destination opgehaald worden. Bijv

De overige scripts zijn ondersteunend en worden gebruikt door de basis scripts. Ze worden niet nader beschreven.