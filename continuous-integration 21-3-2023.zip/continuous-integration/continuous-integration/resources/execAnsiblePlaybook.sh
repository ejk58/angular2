#!/usr/bin/bash
hostName=$1
playbook=$2
ansibleDir=$3
ansibleCmd="ansible-playbook -i ${ansibleDir}/hosts -l ${hostName} ${ansibleDir}/playbooks/${playbook} "

echo "ansibleCmd=> ${ansibleCmd}"

ssh ansible@oqsoel15410.ont.belastingdienst.nl "${ansibleCmd}"
