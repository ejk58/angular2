#!/usr/bin/bash
hostName=$1
version=$2
assemblyId=$3
ansibleDir="/srv/data/git/pgsv/ansible"
ansibleCmd="ansible-playbook -i ${ansibleDir}/hosts -l ${hostName} ${ansibleDir}/playbooks/script.yml -e \"scripts_version=${version} assembly_id=${assemblyId} \""

echo "ansibleCmd=> ${ansibleCmd}"

ssh ansible@oqsoel15410.ont.belastingdienst.nl "${ansibleCmd}"
