#!/usr/bin/bash
job=$1
env=$2
str=$3
user=$4
pwtoken=$5
token=$6
deploymentId=$7
robotTestPath=$8

curl -k -X POST https://jenkins16.belastingdienst.nl/jenkins/job/${job}/build?token=${token} \
  --user ${user}:${pwtoken} \
  --data-urlencode json="{'parameter': [{'name':'deploymentId', 'value':'${deploymentId}'}, {'name':'robotTestPath', 'value':'${robotTestPath}'}, {'name':'environment', 'value':'${env}'}, {'name':'street', 'value':'${str}'},]}"