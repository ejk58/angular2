#!/usr/bin/python3

import requests
from requests.packages import urllib3
from jira import JIRA, JIRAError
import argparse


# Initialize Jira connection and project settings

parser = argparse.ArgumentParser(description='create a new Jira project release')
parser.add_argument("projectName",  help="jira project name")
parser.add_argument("version",  help="new version of application for project")
parser.add_argument("personalAccessToken",  help="jira Personal Access Token")
parser.add_argument("jiraUrl", nargs="?", default="https://jira.belastingdienst.nl", help="url jiraServer")

args = parser.parse_args()
projectName = args.projectName.upper()
version = args.version
pat = args.personalAccessToken
jira_url = args.jiraUrl

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Create Jira connection
headers = JIRA.DEFAULT_OPTIONS["headers"].copy()
headers["Authorization"] = f"Bearer {pat}"
#jira=JIRA(server=host, options={"headers": headers})
try:
    jira = JIRA(server=jira_url, options={"headers": headers,"verify": False},  get_server_info = False, max_retries=0)
except JIRAError as e:
   print( e.status_code )
   exit(1)



def createReleaseMap(jira, project):
    try: 
        versions = jira.project_versions(project)
    except JIRAError as e:
        print("Jira project " + project +  " doesn't exist")
        exit(1)
    prjList = {}

    # Make a map from version name -> version release date
    for version in versions:
        try:
            prjList[version.name] = version

        # if no release date is set for this version,
        # do something else, e.g., use the name as value instead of the date
        except AttributeError:
            prjList[version.name] = version.name

    return prjList

if createReleaseMap(jira, projectName).get(version) is None:
  jira.create_version(version, projectName , description=None, releaseDate=None, startDate=None, archived=False, released=False)
  print(version + " Added")
else:
  print("versie " + version + " bestaat reeds")


