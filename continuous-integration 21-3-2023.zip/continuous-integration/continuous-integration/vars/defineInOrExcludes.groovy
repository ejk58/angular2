def call(String cludes, String clude) {
    def split = cludes.split("\\r\\n|\\n|\\r")
    def robotCludesBuilder = new StringBuilder();
    for (int i = 0; i < split.length; i++) {
        robotCludesBuilder.append(" --").append(clude).append(" ").append(split[i]);
    }
    return robotCludesBuilder.toString()
}