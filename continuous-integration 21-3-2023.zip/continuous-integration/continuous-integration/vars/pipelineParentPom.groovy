def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    mvnExtraBuildArguments = ''
    if (config.mvnExtraBuildArguments != null) {
        mvnExtraBuildArguments = config.mvnExtraBuildArguments
    }

    dryRun = false
    baseDir = '.'

    if (config.baseDirectory != null) {
        baseDir = config.baseDirectory
    }

    node {
        deleteDir()

        try {
            stage ('Clone') {

                checkout scm

                properties([
                    disableConcurrentBuilds(),
                    pipelineTriggers([pollSCM('')])
                ])

            }

            stage('Build') {
                dir(baseDir) {
                    projectInfo = getInfoFromPom(readFile('pom.xml'))
                    if (config.artifactId != null) {
                        projectInfo.artifactId = config.artifactId
                    }
                    echo '**************************************************************\n' +
                        '** Deployment parameters:\n' +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** version          = ${projectInfo.version}\n" +
                        '**  \n' +
                        "** extraArguments   = ${mvnExtraBuildArguments}\n" +
                        '**************************************************************\n'

                    if (dryRun) {
                        echo 'DRYRUN: Running maven clean deploy\n'
                    }
                    else {
                        wrap([$class: 'ConfigFileBuildWrapper', managedFiles: [[fileId: ApplicationConfiguration.getJenkinsMavenNexus3SettingsId(), variable: 'PROJECT_MAVEN_SETTINGS' ]]]) {
                            sh 'mvn -V clean deploy'                        }
                    }
                }
            }

            currentBuild.result = 'SUCCESS'

        } catch (any) {
            currentBuild.result = 'FAILURE'
            throw any
        } finally {
            emailNotification()
        }
    }
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
    def gav = new GAV()
    def project = new XmlSlurper().parseText( pomContent )
    gav.groupId = project.groupId.toString()
    gav.artifactId = project.artifactId.toString()
    gav.version = project.version.toString()
    gav
}

class GAV {
    String groupId
    String artifactId
    String version

    def String groupIdPath() {
        groupId.replaceAll('\\.', '/')
    }
    def String versionWithoutSnapshot() {
        if (version.endsWith('-SNAPSHOT')) {
            version.substring(0, version.length() - 9)
        }
        else {
            version
        }
    }
    def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
