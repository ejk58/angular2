def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
	def lockLabel = 'XXXX'

    def robotDir = ''
    if (config.robotDir != null) {
        robotDir = config.robotDir
    }

    def robotNode = "robot4"
    if (config.robotNode != null) {
        robotNode = config.robotNode
    }

    node(robotNode) {

        try {
            stage ('Clone') {
                
                checkout scm

                if (config.pipelineTrigger != null){
                        pipelineTrigger = pipelineTriggers(config.pipelineTrigger)
                } else {
                        pipelineTrigger = pipelineTriggers([pollSCM('')])
                }

                properties([
                    parameters([
                        choice(name: 'environment', choices: "ont\ntst\nacc", description: 'Environment to run this script'),
                        choice(name: 'street', choices: "1\n2\n3\n4\n5\n6", description: 'Which street?'),
                        choice(name: 'reRunFailed', choices: 'NO\nYES', description: 'Rerun failed test suites only?'),
                        choice(name: 'robotRunner', choices:'pabot\nrobot', description: 'Use which robot script?'),
                        choice(name: 'splitlevel', choices: 'SUITE\nTEST', description: 'If parallel, at which level?'),
                        string(name: 'robotArguments', defaultValue:'', description: 'Do you want to add extra robot options e.g. -i TAG or --logname LOGNAME'),
                        string(name: 'pabotProcesses', defaultValue:'8', description: 'How may parallel threads do you want running'),
                        string(name: 'pabotArguments', defaultValue:'', description: 'Do you want to add extra pabot options e.g. --argumentfile1 path_to_file1 --argumentfile2 path_to_file2'),
                        string(name: 'previousOutput', defaultValue:'', description: 'Add a previous output xml name to your repository and name it here (e.g. "previous_output.xml") if you want pabot to optimize results based on the xml')
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTrigger
                    ])
                }

            stage ("Integration"){
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
                lock(lockLabel) {
                def reRun = false
                def environment = params.street + "." + params.environment
                def robotRunner=""
                def pabotArguments=""
                def pabotProcesses=""
                def previousOutput=""
                // Select Robot script to run
                if (config.robotRunner != null) {
                    robotRunner=config.robotRunner
                }
                else {            
                    robotRunner=params.robotRunner
                }
                // Set Robot Arguments
                def robotArguments=""
                if (params.robotArguments != "") {
                    robotArguments = params.robotArguments
                }
                else {            
                    robotArguments=config.robotArguments
                }
                // Set Pabot number of processes
                if (params.pabotProcesses != "") {
                    pabotProcesses=params.pabotProcesses
                }
                else {            
                    pabotProcesses=config.pabotProcesses
                }
                // Set Pabot Arguments, base config is with 8 arguments
                if (params.pabotArguments != "") {
                    pabotArguments = params.pabotArguments
                }
                else if (params.robotRunner == "pabot" && params.splitlevel == "TEST") {
                    pabotArguments = "--processes ${pabotProcesses} --testlevelsplit --pabotlib --artifactsinsubfolders"
                }
                else if (params.robotRunner == "pabot" && params.splitlevel == "SUITE") {
                    pabotArguments = "--processes ${pabotProcesses} --pabotlib --artifactsinsubfolders"
                }
                else if (config.pabotArguments != null){
                    pabotArguments = config.pabotArguments
                }
                else {
                    pabotArguments = ""
                }
                if (config.previousOutput != null) {
                    previousOutput=" --suitesfrom ${config.previousOutput}"
                }
                else if (params.previousOutput != "") {
                    previousOutput = " --suitesfrom ${params.previousOutput}"
                }
                else {
                    previousOutput = ""
                }
                // Start run
                echo "Going to try running robot tests with command: ${params.robotRunner} ${pabotArguments}${previousOutput} ${config.robotNonCriticals} ${robotArguments} -v ENVIRONMENT:${environment} -l original_log.html  ${config.robotTestPath}"
                try{
                    if (config.robotTestPath != null && params.reRunFailed == 'NO') {
                        echo "Going to run robot tests for ${JOB_NAME}"
                        sh "${params.robotRunner} ${pabotArguments}${previousOutput} ${config.robotNonCriticals} ${robotArguments} -v ENVIRONMENT:${environment} -l original_log.html  ${config.robotTestPath}"
                        
                    }
                    else {
                    echo "Robot tests skipped."
                    }
                }catch(e){
                    reRun = true
                }  

                if (reRun || params.reRunFailed == 'YES' ) {
                    echo "Rerun started"
//                    rbtReRun(params.street + "." + params.environment, config.robotExcludes, config.robotIncludes, config.robotNonCriticals, config.robotTestPath)
                    def env = (params.environment == "acc") ? "ACC" : "DEV" 

                    echo "Going to run robot tests for ${JOB_NAME}"
                    echo "Going to try running robot tests with command: ${params.robotRunner} ${pabotArguments} ${config.robotNonCriticals} ${robotArguments} --rerunfailed output.xml --runemptysuite --output rerun_output.xml -v ENVIRONMENT:${environment} -v ENV:${env} ${config.robotTestPath}"
                    sh """
                        set +e \\
                        ;${params.robotRunner} ${pabotArguments} ${config.robotNonCriticals} ${robotArguments} --rerunfailed output.xml --runemptysuite --output rerun_output.xml -v ENVIRONMENT:${environment} -v ENV:${env} ${config.robotTestPath} \\
                        ;rebot --processemptysuite --output output.xml --merge output.xml rerun_output.xml 
                        """
                    }
                }
            }

            currentBuild.result = 'SUCCESS'

        } catch (e) {
            currentBuild.result = 'FAILURE'
            throw e
        } finally {
            if (config.robotTestPath != null){ 
                step([$class              : 'RobotPublisher',
                    disableArchiveOutput: false,
                    logFileName         : '*log.html',
                    otherFiles          : 'browser/screenshot/*.png,*selenium-screenshot-*.png,visualReport.html,visual_images/**/*.png,pabot_results',
                    outputFileName      : 'output.xml',
                    outputPath          : '.',
                    passThreshold       : 100,
                    reportFileName      : '*report.html',
                    unstableThreshold   : 0]);
            }
            emailNotification()
        }
    }
}
