def call(String clientWebFolder, String appName) {
    echo "(npm update and) ng build ${clientWebFolder} ${appName}"
    dir("${WORKSPACE}/${clientWebFolder}") {
        // TODO fix nmp update
        // sh "npm update"
        def baseRef = ""
        if (appName) {
            baseRef = "--base-href ${appName}"
        }
        sh "node_modules/@angular/cli/bin/ng build --prod ${baseRef}"
    }
}