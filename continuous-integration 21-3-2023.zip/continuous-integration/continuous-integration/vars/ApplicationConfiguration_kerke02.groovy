class ApplicationConfiguration_kerke02 {
//    static def nexus_url = 'http://rms.belastingdienst.nl:8080'
    static def nexus_url = 'https://nexus.belastingdienst.nl'
//    static def nexus_repository_prefix = '/nexus/service/local/repositories/bld.iva.release/content/'
    static def nexus_repository_prefix = 'nexus/repository/release-candidates'
    static def nexus_repository_prefix_nexus2 = 'nexus/repository/nexus2-releases'

    static def quay_url = 'registry.chp.belastingdienst.nl'
    static def quay_repository_prefix = '/webdevelopment'
    static def harbor_url = 'cir-cn.chp.belastingdienst.nl'
    static def harbor_repository_prefix = '/webdevelopment'
    
    //static def jdk_image = 'openjdk-11-rhel7'
    static def jdk_image = 'ubi8-openjdk-17'

    static def sonar_url = 'https://qmp.belastingdienst.nl/sonar/'
    static def sonar_token_name = 'jenkins-IV-Accent'
    static def sonar_token = 'a8f8f1d68dd89feace48f99ee6146dd502aee92e'

    static def bitbucket_url = 'ssh://git@git.belastingdienst.nl:7999'
    static def dinq_host = "iva-dinqserver.belastingdienst.nl"
    static def dinq_url = "https://${dinq_host}/api/v1/"

    static def jira_server_url = "https://jira.belastingdienst.nl"

    static def jenkins_maven_settings_id = '2c4720f1-29d7-48ae-b91e-86522508266b'
    static def jenkins_maven_nexus3_settings_id = '417aa8c8-9921-4f5e-8b84-96ccdcd6e88a'

    static def dinq_credential_id = 'DINQ_USER_JJ'

    static def jira_credential_id = 'JIRA_USER'

    static def mavenDinqPlugin = 'nl.belastingdienst.jacob:jacob-dinq-maven-plugin:5.5.0'

    static def anna_host = "anna.belastingdienst.nl"
    static def anna_url = "https://${anna_host}/api/v1/anoc/manage_virtual_ip/"
    static def anna_credential_id = 'ANNA_USER'
    static def exclude_commit_users = ['jenkins','noreply-jenkins', 'iv.accent.coe.maatwerk']

    static def npm_repository_url = 'https://nexus.belastingdienst.nl/nexus/repository/npm/'

    static def stages = [
        'ONT' : 'Ontwikkel',
        'TST' : 'Test',    
        'ACC' : 'Acceptatie',
        'PRD' : 'Productie'
    ]
    static def lockPrefixes = [
        'ivabat'                : 'GSV',
        'ivaregie'              : 'GSV',
        'iva-gsv'               : 'GSV',
        'gsv-beheermodule'      : 'GSV',    
        'gsv-database'          : 'GSV',
        'iva-kvkEventConsumer'  : 'GSV',
        'thl-database'          : 'iva-thl',
        'iva-datadashboard-database'           : 'iva-datadashboard'
        // 'iva-datadashboard-teradata-database'  : 'iva-datadashboard'
    ]

    static def config = [ 
    // Configuration for deployment of iva-note
        'note' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF TRAWERNO KANTOOR ON2P0062']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF TRAWERNO KANTOOR TS1P1010']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 NOTE KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 NOTE KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 NOTE KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 NOTE KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of iva-kvkEventConsumer
        'iva-kvkEventConsumer' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF GSV KANTOOR ON2P0056']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF GSV KANTOOR TS1P1014']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAK KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAK KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAK KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAK KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of the activation-specification of iva-kvkEventConsumer
        'iva-kvkEventConsumer-as' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF GSV KANTOOR ON2P0056']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF GSV KANTOOR TS1P1014']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAK KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAK KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAK KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAK KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of iva-gsv
        'iva-gsv' : [
        //'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF GSV KANTOOR ON2P0056']],
        //'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF GSV KANTOOR TS1P1014']],
        //'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 GSV KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 GSV KANTOOR AC2P0040']],
        //'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 GSV KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 GSV KANTOOR PR2P0016']]
        'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 GSVJPA20 KANTOOR ON2P0077 IVA WD ONT WAS9 1']],
        'TST':['DESTINATIONS':['IPAS IVACCENT 9.0.5 GSVJPA20 KANTOOR TS1P0999 IVA WD TST WAS9 1']],
        'ACC':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSV KANTOOR AC1P1011','IVACCENT WAS 9.0.5 WHP C2 GSV KANTOOR AC2P0037']],
        'PRD':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSV KANTOOR PR1P1011','IVACCENT WAS 9.0.5 WHP C2 GSV KANTOOR PR2P0036']]
		],
    // Configuration for deployment of the activation-specification of the iva-gsv
        'iva-gsv-as' : [
        //'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF GSV KANTOOR ON2P0056']],
        //'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF GSV KANTOOR TS1P1014']],
        //'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 GSV KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 GSV KANTOOR AC2P0040']],
        //'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 GSV KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 GSV KANTOOR PR2P0016']]
        'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 GSVJPA20 KANTOOR ON2P0077 IVA WD ONT WAS9 1']],
        'TST':['DESTINATIONS':['IPAS IVACCENT 9.0.5 GSVJPA20 KANTOOR TS1P0999 IVA WD TST WAS9 1']],
        'ACC':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSV KANTOOR AC1P1011','IVACCENT WAS 9.0.5 WHP C2 GSV KANTOOR AC2P0037']],
        'PRD':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSV KANTOOR PR1P1011','IVACCENT WAS 9.0.5 WHP C2 GSV KANTOOR PR2P0036']]
        ],
    // Configuration for deployment of iva-gsv-tsl specially for Toeslagen
        'iva-gsv-tsl' : [
        //'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 GSVTSL KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 GSVTSL KANTOOR AC2P0040']],
        //'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 GSVTSL KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 GSVTSL KANTOOR PR2P0016']]
        'ACC':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSVTSL KANTOOR AC1P1011','IVACCENT WAS 9.0.5 WHP C2 GSVTSL KANTOOR AC2P0037']],
        'PRD':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSVTSL KANTOOR PR1P1011','IVACCENT WAS 9.0.5 WHP C2 GSVTSL KANTOOR PR2P0036']]
        ],
    // Configuration for deployment of the activation-specification of the iva-gsv-tsl specially for Toeslagen
        'iva-gsv-tsl-as' : [
        //'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 GSVTSL KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 GSVTSL KANTOOR AC2P0040']],
        //'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 GSVTSL KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 GSVTSL KANTOOR PR2P0016']]
		'ACC':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSVTSL KANTOOR AC1P1011','IVACCENT WAS 9.0.5 WHP C2 GSVTSL KANTOOR AC2P0037']],
        'PRD':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSVTSL KANTOOR PR1P1011','IVACCENT WAS 9.0.5 WHP C2 GSVTSL KANTOOR PR2P0036']]
        ],
    // Configuration for deployment of iva-mihproxyservice
        'iva-mihproxyservice' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE ON2P0056']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE TS1P1014']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE PR2P0016']]
        ],
    // Configuration for deployment of iva-kkmproxyservice
        'kkmproxyservice' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE ON2P0056']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE TS1P1014']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE PR2P0016']]
        ],
    // Configuration for deployment of the gsv-beheermodule
        'gsv-beheermodule' : [  
        'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 GSVJPA20 KANTOOR ON2P0077 IVA WD ONT WAS9 1']],
        'TST':['DESTINATIONS':['IPAS IVACCENT 9.0.5 GSVJPA20 KANTOOR TS1P0999 IVA WD TST WAS9 1']],
        'ACC':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSV KANTOOR AC1P1011','IVACCENT WAS 9.0.5 WHP C2 GSV KANTOOR AC2P0037']],
        'PRD':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSV KANTOOR PR1P1011','IVACCENT WAS 9.0.5 WHP C2 GSV KANTOOR PR2P0036']]
        ],
    // Configuration for deployment of the gsv-beheermodule-tsl
        'gsv-beheermodule-tsl' : [
        'ACC':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSVTSL KANTOOR AC1P1011','IVACCENT WAS 9.0.5 WHP C2 GSVTSL KANTOOR AC2P0037']],
        'PRD':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 GSVTSL KANTOOR PR1P1011','IVACCENT WAS 9.0.5 WHP C2 GSVTSL KANTOOR PR2P0036']]
        ],
    // Configuration for deployment of iva-settlement-service
        'settlement-service' : [
        'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS_JPA20 KANTOOR ON2P0083 IVA WD ONT WAS9 2']],
        'TST':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS_JPA20 KANTOOR TS1P0995 IVA WD TST WAS9 2']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAS KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAS KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAS KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAS KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of iva-settlement
        'settlement' : [
        'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS_JPA20 KANTOOR ON2P0083 IVA WD ONT WAS9 2']],
        'TST':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS_JPA20 KANTOOR TS1P0995 IVA WD TST WAS9 2']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAS KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAS KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAS KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAS KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of iva-transfer
        'transfer' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF TRAWERNO KANTOOR ON2P0062']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF TRAWERNO KANTOOR TS1P1010']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAT KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAT KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAT KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAT KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of iva-werkgroep
        'iva-werkgroep' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF TRAWERNO KANTOOR ON2P0062']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF TRAWERNO KANTOOR TS1P1010']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAW KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAW KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAW KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAW KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of iva-tbm
        'tbm' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE ON2P0056']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE TS1P1014']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE PR2P0016']]
        ],
    // Configuration for deployment of iva-tbm testing
        'TEST_tbm' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE leeg']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE leeg']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE leeg','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE leeg','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE PR2P0016']]
        ],
    // Configuration for deployment of iva-stivers
        'stivers' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF DASTIVAS KANTOOR ON2P0062']],
        // 'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS_JPA20 KANTOOR ON2P0083 IVA WD ONT WAS9 2']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF DASTIVAS KANTOOR TS1P1010']],
        // 'TST':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS_JPA20 KANTOOR TS1P0995 IVA WD TST WAS9 2']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 STIVERS KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 STIVERS KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 STIVERS KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 STIVERS KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of datadashboard
        'iva-datadashboard' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF DASTIVAS KANTOOR ON2P0062']],
        // 'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS_JPA20 KANTOOR ON2P0083 IVA WD ONT WAS9 2']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF DASTIVAS KANTOOR TS1P1010']],
        // 'TST':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS_JPA20 KANTOOR TS1P0995 IVA WD TST WAS9 2']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAD KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAD KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAD KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAD KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of datadashboard
        'iva-datadashboard-cfm' : [
        'ONT':['DESTINATIONS':[]],
        'TST':['DESTINATIONS':[]],
        'ACC':['DESTINATIONS':[]],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAD KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAD KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of datamonitor
        'iva-datamonitor' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF DASTIVAS KANTOOR ON2P0062']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF DASTIVAS KANTOOR TS1P1010']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAD KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAD KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAD KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAD KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of iva-thl
        'iva-thl' : [
//        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF DASTIVAS KANTOOR ON2P0062']],
        'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS KANTOOR ON2P0083 IVA WD ONT WAS9 2']],
        'TST':['DESTINATIONS':['IVACCENT WAS 9.0.5 DASTIVAS KANTOOR TS1P0995 IVA WD TST WAS9 2']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAD KANTOOR AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAD KANTOOR AC2P0040']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAT KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAT KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of inzicht
        'inzicht' : [
        'ONT':['DESTINATIONS':['IVACCENT WAS 9.0.5 INZICHT KANTOOR ON2P0083 IVA WD ONT WAS9 2']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF INZICHT KANTOOR TS1P1010']],
        'ACC':['DESTINATIONS':['IVACCENT WAS 9.0.5 WHP C1 IVAI KANTOOR AC1P1011','IVACCENT WAS 9.0.5 WHP C2 IVAI KANTOOR AC2P0037']],
        'PRD':['DESTINATIONS':['IVA_PRODUCTIE WAS 8.5.5 WHP C1 IVAI KANTOOR PR1P1014','IVA_PRODUCTIE WAS 8.5.5 WHP C2 IVAI KANTOOR PR2P0016']]
        ],
    // Configuration for deployment of bat-rest-dataservice in cluster van MIH voor OTA
        'batRestDataService' : [
        'ONT':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE ON2P0056']],
        'TST':['DESTINATIONS':['IVA WAS 8.5.5 SELF IVAMIH WEBSERVICE_SECURE TS1P1014']],
        'ACC':['DESTINATIONS':['IVA_ACCEPTATIE WAS 8.5.5 WHP C1 IVAMIH WEBSERVICE_SECURE AC1P1007','IVA_ACCEPTATIE WAS 8.5.5 WHP C2 IVAMIH WEBSERVICE_SECURE AC2P0040']],
        'PRD':['DESTINATIONS':['moet nog worden aangemaakt']]
        ],
    // Configuration dummy for deployment of dummy
        'dummy' : [
        'ONT':['DESTINATIONS':['']],
        'TST':['DESTINATIONS':['']],
        'ACC':['DESTINATIONS':['','']],
        'PRD':['DESTINATIONS':['','']]
        ]
    ]

    static def LBconfig = [ 
    // Configuration for deployment of iva-note
        'note' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-kvkEventConsumer
        'iva-kvkEventConsumer' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of the activation-specification of iva-kvkEventConsumer
        'iva-kvkEventConsumer-as' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-gsv
        'iva-gsv' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        '//ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
		//'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
		'ACC':['LB_SELECTOR':'70b1a087fccd446280bacbf2317a4c4c', 'MEMBER_SELECTOR':['6677098298bad803dc96522a67ecad88','ae3f81e58658bce0078295d9c2de4b52'], 'MEMBER_HOSTNAME':['ac1p1004.acc.belastingdienst.nl','ac2p0044.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'3bfd22ad00fd46ea9e8ee3226f848b5d', 'MEMBER_SELECTOR':['023170f5e933f334abbd3c122a998186','44912c8d07ecf67617796f401a639c4a'], 'MEMBER_HOSTNAME':['pr1p0989.prod.belastingdienst.nl','pr2p0037.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of the activation-specification of the iva-gsv
        'iva-gsv-as' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        '//ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
		//'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
		'ACC':['LB_SELECTOR':'70b1a087fccd446280bacbf2317a4c4c', 'MEMBER_SELECTOR':['6677098298bad803dc96522a67ecad88','ae3f81e58658bce0078295d9c2de4b52'], 'MEMBER_HOSTNAME':['ac1p1004.acc.belastingdienst.nl','ac2p0044.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'3bfd22ad00fd46ea9e8ee3226f848b5d', 'MEMBER_SELECTOR':['023170f5e933f334abbd3c122a998186','44912c8d07ecf67617796f401a639c4a'], 'MEMBER_HOSTNAME':['pr1p0989.prod.belastingdienst.nl','pr2p0037.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-gsv-tsl specially for Toeslagen
        'iva-gsv-tsl' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        '//ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
		//'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
		'ACC':['LB_SELECTOR':'70b1a087fccd446280bacbf2317a4c4c', 'MEMBER_SELECTOR':['6677098298bad803dc96522a67ecad88','ae3f81e58658bce0078295d9c2de4b52'], 'MEMBER_HOSTNAME':['ac1p1004.acc.belastingdienst.nl','ac2p0044.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'3bfd22ad00fd46ea9e8ee3226f848b5d', 'MEMBER_SELECTOR':['023170f5e933f334abbd3c122a998186','44912c8d07ecf67617796f401a639c4a'], 'MEMBER_HOSTNAME':['pr1p0989.prod.belastingdienst.nl','pr2p0037.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of the activation-specification of the iva-gsv-tsl specially for Toeslagen
        'iva-gsv-tsl-as' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        '//ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
		//'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
		'ACC':['LB_SELECTOR':'70b1a087fccd446280bacbf2317a4c4c', 'MEMBER_SELECTOR':['6677098298bad803dc96522a67ecad88','ae3f81e58658bce0078295d9c2de4b52'], 'MEMBER_HOSTNAME':['ac1p1004.acc.belastingdienst.nl','ac2p0044.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'3bfd22ad00fd46ea9e8ee3226f848b5d', 'MEMBER_SELECTOR':['023170f5e933f334abbd3c122a998186','44912c8d07ecf67617796f401a639c4a'], 'MEMBER_HOSTNAME':['pr1p0989.prod.belastingdienst.nl','pr2p0037.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-mihproxyservice
        'iva-mihproxyservice' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-kkmproxyservice
        'kkmproxyservice' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of the gsv-beheermodule
        'gsv-beheermodule' : [  
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
		//'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        //'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]  
		'ACC':['LB_SELECTOR':'9e51761159fa4263ba1c665b328264f1', 'MEMBER_SELECTOR':['6677098298bad803dc96522a67ecad88','ae3f81e58658bce0078295d9c2de4b52'], 'MEMBER_HOSTNAME':['ac1p1004.acc.belastingdienst.nl','ac2p0044.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'ba53c1df1aa748cfafe75272efbdf887', 'MEMBER_SELECTOR':['023170f5e933f334abbd3c122a998186','44912c8d07ecf67617796f401a639c4a'], 'MEMBER_HOSTNAME':['pr1p0989.prod.belastingdienst.nl','pr2p0037.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of the gsv-beheermodule-tsl
        'gsv-beheermodule-tsl' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        //'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        //'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]  
		'ACC':['LB_SELECTOR':'9e51761159fa4263ba1c665b328264f1', 'MEMBER_SELECTOR':['6677098298bad803dc96522a67ecad88','ae3f81e58658bce0078295d9c2de4b52'], 'MEMBER_HOSTNAME':['ac1p1004.acc.belastingdienst.nl','ac2p0044.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'ba53c1df1aa748cfafe75272efbdf887', 'MEMBER_SELECTOR':['023170f5e933f334abbd3c122a998186','44912c8d07ecf67617796f401a639c4a'], 'MEMBER_HOSTNAME':['pr1p0989.prod.belastingdienst.nl','pr2p0037.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-settlement-service
        'settlement-service' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-settlement
        'settlement' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-transfer
        'transfer' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-werkgroep
        'iva-werkgroep' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-tbm
        'tbm' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-stivers
        'stivers' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of datadashboard
        'iva-datadashboard' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of datadashboard
        'iva-datadashboard-cfm' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of datamonitor
        'iva-datamonitor' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of iva-thl
        'iva-thl' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'05229cb984b745d383977075f33dc8f4', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'63ae321e41f4456596e92c9be39b1a90', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration for deployment of inzicht
        'inzicht' : [
        'ONT':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'TST':['LB_SELECTOR':'', 'MEMBER_SELECTOR':['',''], 'MEMBER_HOSTNAME':['','']],
        'ACC':['LB_SELECTOR':'277e0605c3594d93ac87955123674b1a', 'MEMBER_SELECTOR':['2ee59e806f4826776244f764acc35188','cdea8376bdb4869acc772fc12691fd58'], 'MEMBER_HOSTNAME':['ac1p1009.acc.belastingdienst.nl','ac2p0039.acc.belastingdienst.nl']],
        'PRD':['LB_SELECTOR':'88ebcadfa93c43f691347b2c02ecb9ac', 'MEMBER_SELECTOR':['8a4d102b41beca8905e20c6ca5739a8f','f0d05cf8eafa87869332391ad9dc4f59'], 'MEMBER_HOSTNAME':['pr1p1016.prod.belastingdienst.nl','pr2p0015.prod.belastingdienst.nl']]
        ],
    // Configuration dummy for deployment of dummy
        'dummy' : [
        'ONT':['lbSelector':'', 'memberSelector':['',''], 'memberHostname':['','']],
        'TST':['lbSelector':'', 'memberSelector':['',''], 'memberHostname':['','']],
        'ACC':['lbSelector':'', 'memberSelector':['',''], 'memberHostname':['','']],
        'PRD':['lbSelector':'', 'memberSelector':['',''], 'memberHostname':['','']]
        ],
    ]

    static def dbConfig = [
    // Database configuration for deployment of iva-note
    'iva-note-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'    ,'SCHEMA_PREFIX':'IVANOTE', 'dbCredentials':'27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'    ,'SCHEMA_PREFIX':'IVANOTE', 'dbCredentials':'27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://ivan-db.acc.belastingdienst.nl:50000/IVANOTE1','SCHEMA_PREFIX':'IVANOTE', 'dbCredentials':'DB_admin_IVAN_Acc'],
        'PRD':['URL':'jdbc:db2://ivan-db.belastingdienst.nl:50000/IVANOTE1'    ,'SCHEMA_PREFIX':'IVANOTE', 'dbCredentials':'DB_admin_IVAN_Prod']
        ],
    'gsv-database' : [  // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://gsv-db.acc.belastingdienst.nl:50000/gsvdb01' ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_Acc'],
        'PRD':['URL':'jdbc:db2://gsv-db.belastingdienst.nl:50000/gsvdb01'     ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_Prod']
        ],
    'TEST-gsv-database' : [  // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'TEST_GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'TEST_GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://gsv-db.acc.belastingdienst.nl:50000/gsvdb01' ,'SCHEMA_PREFIX':'TEST_GSV0', 'dbCredentials': 'DB_admin_IVAZ_Acc'],
        'PRD':['URL':'jdbc:db2://gsv-db.acc.belastingdienst.nl:50000/gsvdb01' ,'SCHEMA_PREFIX':'TEST_PRD_GSV0', 'dbCredentials': 'DB_admin_IVAZ_Acc']
        ],
    'gsv-database-config' : [  // * duplicated because we need this for correct deploymentId
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://gsv-db.acc.belastingdienst.nl:50000/gsvdb01' ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_Acc'],
        'PRD':['URL':'jdbc:db2://gsv-db.belastingdienst.nl:50000/gsvdb01'     ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_Prod']
        ],
    'TEST-gsv-database-config' : [  // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'TEST_GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'TEST_GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://gsv-db.acc.belastingdienst.nl:50000/gsvdb01' ,'SCHEMA_PREFIX':'TEST_GSV0', 'dbCredentials': 'DB_admin_IVAZ_Acc']
        ],
    'gsv-database-tsl' : [  // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'      ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'      ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://gsv-tsl-db.acc.belastingdienst.nl:50000/gsvdb02','SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_TSL_ACC'],
        'PRD':['URL':'jdbc:db2://gsv-tsl-db.belastingdienst.nl:50000/gsvdb01'    ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_TSL_Prod']
        ],
    'gsv-database-config-tsl' : [  // * duplicated because we need this for correct deploymentId
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'      ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'      ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://gsv-tsl-db.acc.belastingdienst.nl:50000/gsvdb02','SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_TSL_ACC'],
        'PRD':['URL':'jdbc:db2://gsv-tsl-db.belastingdienst.nl:50000/gsvdb01'    ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_TSL_Prod']
        ],
    'iva-settlement-database' : [  // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAS0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAS0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://ivas-db.acc.belastingdienst.nl:50000/ivas01','SCHEMA_PREFIX':'IVAS0', 'dbCredentials': 'DB_admin_IVAS_ACC'],
        'PRD':['URL':'jdbc:db2://ivas-db.belastingdienst.nl:50000/ivas01'    ,'SCHEMA_PREFIX':'IVAS0', 'dbCredentials': 'DB_admin_IVAS_Prod']
        ],
    'transfer-database' : [    // --
        'ONT':['URL':'jdbc:teradata://o802vtdavapp.ont.belastingdienst.nl/DATABASE=${schemaName},CHARSET=UTF8'  ,'SCHEMA_PREFIX':'IVAT_DEV_STR1', 'dbCredentials': 'OIVA01_teradata'],
        //'ONT':['URL':'TERADATA','SCHEMA_PREFIX':'', 'dbCredentials': ''],
        'TST':['URL':'TERADATA','SCHEMA_PREFIX':'', 'dbCredentials': ''],
        'ACC':['URL':'TERADATA','SCHEMA_PREFIX':'', 'dbCredentials': ''],
        'PRD':['URL':'TERADATA','SCHEMA_PREFIX':'', 'dbCredentials': '']
        ],
    'iva-werkgroep-database' : [    // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAW0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAW0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        // Om resources te sparen wordt het ivaorg schema in de IVAW database aangemaakt
        'ACC':['URL':'jdbc:db2://ivaw-db.acc.belastingdienst.nl:50000/ivaw01','SCHEMA_PREFIX':'IVAW0', 'dbCredentials': 'DB_admin_IVAW_Acc'],
        'PRD':['URL':'jdbc:db2://ivaw-db.belastingdienst.nl:50000/ivaw01'    ,'SCHEMA_PREFIX':'IVAW0', 'dbCredentials': 'DB_admin_IVAW_Prod']
        ],
    'iva-datadashboard-database' : [    // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAD0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAD0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://ivad-db.acc.belastingdienst.nl:50000/IVAD01','SCHEMA_PREFIX':'IVAD0', 'dbCredentials': 'DB_admin_IVAD_Acc'],
        'PRD':['URL':'jdbc:db2://ivad-db.belastingdienst.nl:50000/IVAD01'    ,'SCHEMA_PREFIX':'IVAD0', 'dbCredentials': 'DB_admin_IVAD_Prod']
        ],
    'iva-datamonitor-database' : [    // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVADM0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVADM0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://ivad-db.acc.belastingdienst.nl:50000/IVAD01','SCHEMA_PREFIX':'IVADM0', 'dbCredentials': 'DB_admin_IVAD_Acc'],
        'PRD':['URL':'jdbc:db2://ivadm-db.belastingdienst.nl:50000/IVADM01'    ,'SCHEMA_PREFIX':'IVADM0', 'dbCredentials': 'DB_admin_IVADM_Prod']
        ],
    'stivers-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'      ,'SCHEMA_PREFIX':'IVASTIVERS0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'      ,'SCHEMA_PREFIX':'IVASTIVERS0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://stivers-db.acc.belastingdienst.nl:50000/STIDB01','SCHEMA_PREFIX':'IVASTIVERS0', 'dbCredentials': 'DB_admin_IVASTIVERS_Acc'],
        'PRD':['URL':'jdbc:db2://stivers-db.belastingdienst.nl:50000/STIDB01'    ,'SCHEMA_PREFIX':'IVASTIVERS0', 'dbCredentials': 'DB_admin_IVASTIVERS_Prod']
        ],
    'inzicht-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAI0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAI0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://ivai-db.acc.belastingdienst.nl:50000/ivai01','SCHEMA_PREFIX':'IVAI0', 'dbCredentials': 'DB_admin_IVAI_Acc'],
        'PRD':['URL':'jdbc:db2://ivai-db.prd.belastingdienst.nl:50000/ivai01','SCHEMA_PREFIX':'IVAI0', 'dbCredentials': 'DB_admin_IVAI_Prod']
        ],
    'iva-kvkEventConsumer-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAKEC0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAKEC0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://ivak-db.acc.belastingdienst.nl:50000/IVA01','SCHEMA_PREFIX':'IVAKEC0', 'dbCredentials': 'DB_admin_IVAKEC_Acc'],
        'PRD':['URL':'jdbc:db2://ivak-db.belastingdienst.nl:50000/IVA01','SCHEMA_PREFIX':'IVAKEC0', 'dbCredentials': 'DB_admin_IVAKEC_Prod']
        ],
    'zaakadministratie-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAZAAK', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-ont'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAZAAK', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-tst'],
        'ACC':['URL':'jdbc:db2://ivazaak-db.acc.belastingdienst.nl:50000/ZAAKDB01','SCHEMA_PREFIX':'IVAZAAK', 'dbCredentials': 'wd-build-pb-db-admin-ivazaak-acc'],
        'PRD':['URL':'jdbc:db2://ivazaak-db.belastingdienst.nl:50000/ZAAKDB01','SCHEMA_PREFIX':'ZAAK', 'dbCredentials': 'wd-build-pb-db-admin-ivazaak-prod']
        ],
    'ivabat-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVABAT', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-ont'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVABAT', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-tst'],
        'ACC':['URL':'jdbc:db2://ivabat-db.acc.belastingdienst.nl:50000/BATDB01','SCHEMA_PREFIX':'IVABAT', 'dbCredentials': 'wd-build-pb-db-admin-ivabat-acc'],
        'PRD':['URL':'jdbc:db2://ivabat-db.belastingdienst.nl:50000/BATDB01','SCHEMA_PREFIX':'IVABAT', 'dbCredentials': 'wd-build-pb-db-admin-ivabat-prod']
        ],
    'TEST-ivabat-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'TEST_IVABAT', 'dbCredentials': 'wd-japie-db-admin-ivadb-ont'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'TEST_IVABAT', 'dbCredentials': 'wd-japie-db-admin-ivadb-tst'],
        'ACC':['URL':'jdbc:db2://ivabat-db.acc.belastingdienst.nl:50000/BATDB01','SCHEMA_PREFIX':'TEST_IVABAT', 'dbCredentials': 'wd-japie-db-admin-ivabat-acc'],
        'PRD':['URL':'jdbc:db2://ivabat-db.acc.belastingdienst.nl:50000/BATDB01','SCHEMA_PREFIX':'TEST_PRD_IVABAT', 'dbCredentials': 'wd-japie-db-admin-ivabat-acc']
        ],
    'ivaorg-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAORG', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-ont'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVAORG', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-tst'],
        'ACC':['URL':'jdbc:db2://ivaw-db.acc.belastingdienst.nl:50000/IVAW01','SCHEMA_PREFIX':'IVAORG', 'dbCredentials': 'wd-build-pb-db-admin-ivaw-acc'],
        'PRD':['URL':'jdbc:db2://ivaw-db.belastingdienst.nl:50000/IVAW01','SCHEMA_PREFIX':'IVAORG', 'dbCredentials': 'wd-build-pb-db-admin-ivaw-prod']
        ],
    'ivatce-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVATCE', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-ont'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'  ,'SCHEMA_PREFIX':'IVATCE', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-tst']
        //'ACC':['URL':'jdbc:db2://ivabat-db.acc.belastingdienst.nl:50000/BATDB01','SCHEMA_PREFIX':'IVABAT', 'dbCredentials': 'wd-build-pb-db-admin-ivabat-acc'],
        //#'PRD':['URL':'jdbc:db2://ivabat-db.belastingdienst.nl:50000/BATDB01','SCHEMA_PREFIX':'IVABAT', 'dbCredentials': 'wd-build-pb-db-admin-ivabat-prod']
        ],
    'thl-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVATHL0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVATHL0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://thl-db.acc.belastingdienst.nl:50000/thl01'   ,'SCHEMA_PREFIX':'THL0'   , 'dbCredentials': 'DB_admin_IVATHL_Acc'],
        'PRD':['URL':'jdbc:db2://tima-db.belastingdienst.nl:50000/ivatt01'    ,'SCHEMA_PREFIX':'THL0'   , 'dbCredentials': 'DB_admin_IVATIMA_Prod']
        ],
    'kbs-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVAKBS0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVAKBS0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://tima-db.acc.belastingdienst.nl:50000/KBS01' ,'SCHEMA_PREFIX':'IVAKBS0', 'dbCredentials': 'DB_admin_IVAKBS_Acc']
//        'PRD':['URL':'jdbc:db2://gsv-db.belastingdienst.nl:50000/gsvdb01'     ,'SCHEMA_PREFIX':'GSV0', 'dbCredentials': 'DB_admin_IVAZ_Prod']
        ],
    'ivagmv-database' : [  // *
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVAGMV', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-ont'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVAGMV', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-tst'],
        'ACC':['URL':'jdbc:db2://ivagmv-db.acc.belastingdienst.nl:50000/gmvdb01' ,'SCHEMA_PREFIX':'IVAGMV', 'dbCredentials': 'wd-build-pb-db-admin-ivagmv-acc'],
        'PRD':['URL':'jdbc:db2://ivagmv-db.belastingdienst.nl:50000/gmvdb01'     ,'SCHEMA_PREFIX':'IVAGMV', 'dbCredentials': 'wd-build-pb-db-admin-ivagmv-prod']
        ],
    'ivafsvimp-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVA_FSV_IMP', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-ont'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVA_FSV_IMP', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-tst'],
        'ACC':['URL':'jdbc:db2://gsv-db.acc.belastingdienst.nl:50000/gsvdb01'   ,'SCHEMA_PREFIX':'IVA_FSV_IMP'   , 'dbCredentials': 'wd-build-pb-DB_admin_IVAZ_Acc'],
        'PRD':['URL':'jdbc:db2://gsv-db.belastingdienst.nl:50000/gsvdb01'    ,'SCHEMA_PREFIX':'IVA_FSV_IMP'   , 'dbCredentials': 'wd-build-pb-DB_admin_IVAZ_Prod']
        ],
    'iva-spring-batch-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVA_SPRING_BATCH', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-ont'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVA_SPRING_BATCH', 'dbCredentials': 'wd-build-pb-db-admin-ivadb-tst'],
     //   'ACC':['URL':'jdbc:db2://gsv-db.acc.belastingdienst.nl:50000/gsvdb01'   ,'SCHEMA_PREFIX':'IVA_SPRING_BATCH'   , 'dbCredentials': 'wd-build-pb-DB_admin_IVAZ_Acc'],
     //   'PRD':['URL':'jdbc:db2://gsv-db.belastingdienst.nl:50000/gsvdb01'    ,'SCHEMA_PREFIX':'IVA_SPRING_BATCH'   , 'dbCredentials': 'wd-build-pb-DB_admin_IVAZ_Prod']
        ],
    'tima-database' : [
        'ONT':['URL':'jdbc:db2://iva-db.ont.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVATIMA0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'TST':['URL':'jdbc:db2://iva-db.tst.belastingdienst.nl:50000/ivadb'   ,'SCHEMA_PREFIX':'IVATIMA0', 'dbCredentials': '27a2a787-f5b2-4d17-b13c-44c7c2598504'],
        'ACC':['URL':'jdbc:db2://tima-db.acc.belastingdienst.nl:50000/tima01' ,'SCHEMA_PREFIX':'TIMA0', 'dbCredentials': 'DB_admin_IVATIMA_Acc'],
        'PRD':['URL':'jdbc:db2://tima-db.belastingdienst.nl:50000/ivatt01'     ,'SCHEMA_PREFIX':'TIMA0', 'dbCredentials': 'DB_admin_IVATIMA_Prod']
        ],
    'iva-datadashboard-teradata-database' : [    // *
        'ONT':['URL':'jdbc:teradata://rtdaoudll01.data.rsi.bdp.belastingdienst.nl/DATABASE=${schemaName},CHARSET=UTF8'  ,'SCHEMA_PREFIX':'DG_S_P_50PRO_KDD', 'dbCredentials': '88f72bfb-4478-4fd6-8ed5-8ca747959b9a'],
        'TST':['URL':'jdbc:teradata://rtdatudll01.data.rsi.bdp.belastingdienst.nl/DATABASE=${schemaName},CHARSET=UTF8'  ,'SCHEMA_PREFIX':'DG_S_P_50PRO_KDD', 'dbCredentials': 'fbbcf0a8-2ec9-46c5-b350-709a789f37cb']
        ]
    ]

    // Configuration for openshift groovy scripts
    static def OSConfig = [
    'ivaorg' : [
        'ONT':['projectBase':'org'  ,'projectName':'wd-org'],
        'TST':['projectBase':'org'  ,'projectName':'wd-org'],
        'ACC':['projectBase':'org'  ,'projectName':'wd-org-acceptatie'],
        'PRD':['projectBase':'org'  ,'projectName':'wd-org-productie'],
        ],
    'ivabat' : [
        'ONT':['projectBase':'bat'  ,'projectName':'wd-bat'],
        'TST':['projectBase':'bat'  ,'projectName':'wd-bat'],
        'ACC':['projectBase':'bat'  ,'projectName':'wd-bat-acceptatie'],
        'PRD':['projectBase':'bat'  ,'projectName':'wd-bat-productie'],
        ],
    'ivabat_ikb_migratie' : [
        'ONT':['projectBase':'bat'  ,'projectName':'wd-ikb-migratie'],
        'TST':['projectBase':'bat'  ,'projectName':'wd-ikb-migratie'],
        'ACC':['projectBase':'bat'  ,'projectName':'wd-ikb-migratie'],
        'PRD':['projectBase':'bat'  ,'projectName':'wd-ikb-migratie'],
        ],
    'ivafsvimp' : [
        'ONT':['projectBase':'iva-fsv-imp'  ,'projectName':'wd-fsvimp'],
        'TST':['projectBase':'iva-fsv-imp'  ,'projectName':'wd-fsvimp'],
        'ACC':['projectBase':'iva-fsv-imp'  ,'projectName':'wd-fsvimp'],
        'PRD':['projectBase':'iva-fsv-imp'  ,'projectName':'wd-fsvimp'],
        ],
    'ivagmv' : [
        'ONT':['projectBase':'gmv'  ,'projectName':'wd-gmv'],
        'TST':['projectBase':'gmv'  ,'projectName':'wd-gmv'],
        'ACC':['projectBase':'gmv'  ,'projectName':'wd-gmv-acceptatie'],
        'PRD':['projectBase':'gmv'  ,'projectName':'wd-gmv-productie'],
        ],
    'ivakbs' : [
	    'ONT':['projectBase':'kbs'  ,'projectName':'wd-kbs'],
	    'TST':['projectBase':'kbs'  ,'projectName':'wd-kbs'],
	    'ACC':['projectBase':'kbs'  ,'projectName':'wd-kbs'],
	    'PRD':['projectBase':'kbs'  ,'projectName':'wd-kbs'],
	    ],
    'iva-ihm' : [
	    'ONT':['projectBase':'ihm'  ,'projectName':'wd-ihm'],
	    'TST':['projectBase':'ihm'  ,'projectName':'wd-ihm'],
	    'ACC':['projectBase':'ihm'  ,'projectName':'wd-ihm-acceptatie'],
	    'PRD':['projectBase':'ihm'  ,'projectName':'wd-ihm-productie'],
	    ],
     'tbm' : [
        'ONT':['projectBase':'tbm'  ,'projectName':'wd-tbm'],
        'TST':['projectBase':'tbm'  ,'projectName':'wd-tbm'],
        'ACC':['projectBase':'tbm'  ,'projectName':'wd-tbm-acceptatie'],
        'PRD':['projectBase':'tbm'  ,'projectName':'wd-tbm-productie'],
        ],
    'ivatima' : [
        'ONT':['projectBase':'tima'  ,'projectName':'wd-tima'],
        'TST':['projectBase':'tima'  ,'projectName':'wd-tima'],
        'ACC':['projectBase':'tima'  ,'projectName':'wd-tima-acceptatie'],
        'PRD':['projectBase':'tima'  ,'projectName':'wd-tima-productie'],
        ],
    'ivatimadev' : [
        'ONT':['projectBase':'tima'  ,'projectName':'wd-tima-dev'],
        'TST':['projectBase':'tima'  ,'projectName':'wd-tima-test'],
        'ACC':['projectBase':'tima'  ,'projectName':'wd-tima-acceptatie'],
        'PRD':['projectBase':'tima'  ,'projectName':'wd-tima-productie'],
        ],
    'ivabvn' : [
        'ONT':['projectBase':'bvn'  ,'projectName':'wd-bvn'],
        'TST':['projectBase':'bvn'  ,'projectName':'wd-bvn'],
        'ACC':['projectBase':'bvn'  ,'projectName':'wd-bvn-acceptatie'],
        'PRD':['projectBase':'bvn'  ,'projectName':'wd-bvn-productie'],
        ],
    'ivaflat' : [
        'ONT':['projectBase':'flat'  ,'projectName':'wd-flat'],
        'TST':['projectBase':'flat'  ,'projectName':'wd-flat'],
        'ACC':['projectBase':'flat'  ,'projectName':'wd-flat-acceptatie'],
        'PRD':['projectBase':'flat'  ,'projectName':'wd-flat-productie'],
        ],
    'iva-brievenbus' : [
        'ONT':['projectBase':'bvb'  ,'projectName':'wd-brievenbus'],
       // 'TST':['projectBase':'flat'  ,'projectName':'wd-flat'],
       // 'ACC':['projectBase':'flat'  ,'projectName':'wd-flat-acceptatie'],
       // 'PRD':['projectBase':'flat'  ,'projectName':'wd-flat'],
        ],
    'ivai-configurator' : [
        'ONT':['projectBase':'cfg'  ,'projectName':'wd-inzicht-configurator'],
       // 'TST':['projectBase':'flat'  ,'projectName':'wd-flat'],
       // 'ACC':['projectBase':'flat'  ,'projectName':'wd-flat-acceptatie'],
       // 'PRD':['projectBase':'flat'  ,'projectName':'wd-flat'],
        ],
    'ivapastebin' : [
        'ONT':['projectBase':'pastebin'  ,'projectName':'wd-pastebin'],
        'TST':['projectBase':'pastebin'  ,'projectName':'wd-pastebin'],
        'ACC':['projectBase':'pastebin'  ,'projectName':'wd-pastebin'],
        'PRD':['projectBase':'pastebin'  ,'projectName':'wd-pastebin'],
        ],
    'TEST-ivabat' : [
        'ONT':['projectBase':'bat'  ,'projectName':'wd-japie'],
        'TST':['projectBase':'bat'  ,'projectName':'wd-japie'],
        'ACC':['projectBase':'bat'  ,'projectName':'wd-japie'],
        'PRD':['projectBase':'bat'  ,'projectName':'wd-japie'],
        ],
    'ivaregie' : [
        'ONT':['projectBase':'regie'  ,'projectName':'wd-regie'],
        'TST':['projectBase':'regie'  ,'projectName':'wd-regie'],
        'ACC':['projectBase':'regie'  ,'projectName':'wd-regie-acceptatie'],
        'PRD':['projectBase':'regie'  ,'projectName':'wd-regie-productie'],
        ],
    'ivatce' : [
        'ONT':['projectBase':'tce'  ,'projectName':'wd-tce'],
        'TST':['projectBase':'tce'  ,'projectName':'wd-tce'],
        'ACC':['projectBase':'tce'  ,'projectName':'wd-tce-acceptatie'],
        'PRD':['projectBase':'tce'  ,'projectName':'wd-tce-productie'],
        ],
    'zaakadministratie' : [
        'ONT':['projectBase':'zaakadministratie'  ,'projectName':'wd-zadm'],
        'TST':['projectBase':'zaakadministratie'  ,'projectName':'wd-zadm'],
        'ACC':['projectBase':'zaakadministratie'  ,'projectName':'wd-zadm-acceptatie'],
        'PRD':['projectBase':'zaakadministratie'  ,'projectName':'wd-zadm-productie'],
        ],
    'iva-lrh' : [
            'ONT':['projectBase':'lrh'  ,'projectName':'wd-lrh'],
            'TST':['projectBase':'lrh'  ,'projectName':'wd-lrh'],
            'ACC':['projectBase':'lrh'  ,'projectName':'wd-lrh-acceptatie'],
            'PRD':['projectBase':'lrh'  ,'projectName':'wd-lrh-productie'],
        ],
    'iva-spring-batch' : [
            'ONT':['projectBase':'iva-spring-batch'  ,'projectName':'wd-iva-spring-batch'],
            'TST':['projectBase':'iva-spring-batch'  ,'projectName':'wd-iva-spring-batch'],
            'ACC':['projectBase':'iva-spring-batch'  ,'projectName':'wd-iva-spring-batch-acceptatie'],
            'PRD':['projectBase':'iva-spring-batch'  ,'projectName':'wd-iva-spring-batch-productie'],
        ],
    'moodboard' : [
	    'ONT':['projectBase':'moodboard'  ,'projectName':'wd-moodboard']
	    ]
    ]

    static def repoConfig = [
    // Configuration for creating release branch test repo, create new jira project release
    
    'tbm' : [  
        'BITB_PROJECT':'ivatbm',
        'BITB_TST_REPO':'iva-tbm-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'tbm '
        ],
    'gsv-database' : [  
        'BITB_PROJECT':'pgsv',
        'BITB_TST_REPO':'gsv-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'gsv-database '
        ],
    'gsv-database-config' : [  
        'BITB_PROJECT':'pgsv',
        'BITB_TST_REPO':'gsv-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'gsv-database-config '
        ],
    'iva-gsv' : [  
        'BITB_PROJECT':'pgsv',
        'BITB_TST_REPO':'gsv-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'gsv '
        ],
    'iva-gsv' : [  
        'BITB_PROJECT':'pgsv',
        'BITB_TST_REPO':'gsv-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'gsv '
        ],
    'gsv-beheermodule' : [  
        'BITB_PROJECT':'pgsv',
        'BITB_TST_REPO':'beheermodule-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'gsv-beheermodule '
        ],
    'iva-kvkEventConsumer' : [  
        'BITB_PROJECT':'pgsv',
        'BITB_TST_REPO':'iva-KvkEventConsumer-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'kvkEventConsumer '
        ],
    'iva-kvkEventConsumer-database' : [  
        'BITB_PROJECT':'pgsv',
        'BITB_TST_REPO':'iva-KvkEventConsumer-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'kvkEventConsumer-database '
        ],
    'iva-werkgroep' : [  
        'BITB_PROJECT':'ivaw',
        'BITB_TST_REPO':'werkgroep-test',
        'JIRA_PROJECT':'IVAW',
        'JIRA_RLSE_PREFIX':'werkgroep '
        ],
    'iva-werkgroep-database' : [  
        'BITB_PROJECT':'ivaw',
        'BITB_TST_REPO':'werkgroep-test',
        'JIRA_PROJECT':'IVAW',
        'JIRA_RLSE_PREFIX':'werkgroep-database '
        ],
    'ivabat' : [  
        'BITB_PROJECT':'ivabat',
        'BITB_TST_REPO':'bat-test',
        'JIRA_PROJECT':'IVABAT',
        'JIRA_RLSE_PREFIX':'iva-bat '
        ],
    'ivabat-database' : [  
        'BITB_PROJECT':'ivabat',
        'BITB_TST_REPO':'bat-test',
        'JIRA_PROJECT':'IVABAT',
        'JIRA_RLSE_PREFIX':'iva-bat-database '
        ],
    'ivabvn' : [  
        'BITB_PROJECT':'ivabat',
        'BITB_TST_REPO':'bvn-test',
        'JIRA_PROJECT':'IVABAT',
        'JIRA_RLSE_PREFIX':'iva-bvn '
        ],
    'ivaflat' : [  
        'BITB_PROJECT':'ivaflat',
        'BITB_TST_REPO':'flat-test',
        'JIRA_PROJECT':'IVAFLAT',
        'JIRA_RLSE_PREFIX':'iva-flat '
        ],
    'ivaorg' : [  
        'BITB_PROJECT':'ivaorg',
        'BITB_TST_REPO':'org-test',
        'JIRA_PROJECT':'IVAORG',
        'JIRA_RLSE_PREFIX':'iva-org '
        ],
    'ivaorg-database' : [  
        'BITB_PROJECT':'ivaorg',
        'BITB_TST_REPO':'org-test',
        'JIRA_PROJECT':'IVAORG',
        'JIRA_RLSE_PREFIX':'iva-org-database '
        ],
    'ivagmv' : [  
        'BITB_PROJECT':'gmv',
        'BITB_TST_REPO':'gmv-test',
        'JIRA_PROJECT':'GMV',
        'JIRA_RLSE_PREFIX':'iva-gmv '
        ],
    'ivatce' : [  
        'BITB_PROJECT':'tce',
        'BITB_TST_REPO':'tce-test',
        'JIRA_PROJECT':'TCE',
        'JIRA_RLSE_PREFIX':'iva-tce '
        ],
    'ivagmv-database' : [  
        'BITB_PROJECT':'ivagmv',
        'BITB_TST_REPO':'gmv-test',
        'JIRA_PROJECT':'GMV',
        'JIRA_RLSE_PREFIX':'iva-gmv-database '
        ],
    'ivaregie' : [  
        'BITB_PROJECT':'pgsv',
        'BITB_TST_REPO':'iva-regie-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'iva-regie '
        ],
    'zaakadministratie' : [  
        'BITB_PROJECT':'zaak',
        'BITB_TST_REPO':'robot',
        'JIRA_PROJECT':'ZAAK',
        'JIRA_RLSE_PREFIX':'zaak '
        ],
    'zaakadministratie-database' : [  
        'BITB_PROJECT':'zaak',
        'BITB_TST_REPO':'robot',
        'JIRA_PROJECT':'ZAAK',
        'JIRA_RLSE_PREFIX':'zaak-database '
        ],
    'TEST-ivabat' : [  
        'BITB_PROJECT':'~langj08',
        'BITB_TST_REPO':'bat-test',
        'JIRA_PROJECT':'VABAT',
        'JIRA_RLSE_PREFIX':'TEST-bat '
        ],
    'TEST-ivabat-database' : [  
        'BITB_PROJECT':'~langj08',
        'BITB_TST_REPO':'bat-test',
        'JIRA_PROJECT':'IVABAT',
        'JIRA_RLSE_PREFIX':'TEST-ivabat-database '
        ],
    'TEST-gsv-database' : [  
        'BITB_PROJECT':'~langj08',
        'BITB_TST_REPO':'zaakadministratie-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'TEST-gsv-database '
        ],
    'TEST-zaakadministratie' : [  
        'BITB_PROJECT':'~langj08',
        'BITB_TST_REPO':'robot',
        'JIRA_PROJECT':'ZAAK',
        'JIRA_RLSE_PREFIX':'zaakadministratie '
        ],
    'TEST_tbm' : [  
        'BITB_PROJECT':'~langj08',
        'BITB_TST_REPO':'iva-tbm-test',
        'JIRA_PROJECT':'PGSV',
        'JIRA_RLSE_PREFIX':'TEST_tbm '
        ],
    'inzicht' : [ 
        'BITB_PROJECT':'IVAI',
        'BITB_TST_REPO':'robot',
        'JIRA_PROJECT':'IVAI',
        'JIRA_RLSE_PREFIX':'Inzicht '
        ],
    'inzicht-database' : [ 
        'BITB_PROJECT':'IVAI',
        'BITB_TST_REPO':'robot',
        'JIRA_PROJECT':'IVAI',
        'JIRA_RLSE_PREFIX':'Inzicht-database'
        ],
    'inzicht-robot' : [ 
        'BITB_PROJECT':'IVAI',
        'BITB_TST_REPO':'robot',
        'JIRA_PROJECT':'IVAI',
        'JIRA_RLSE_PREFIX':'Inzicht-robot'
        ],
    'iva-spring-batch' : [ 
        'BITB_PROJECT':'IVACOMMON',
        'BITB_TST_REPO':'iva-spring-batch-test',
        'JIRA_PROJECT':'IVAM',
        'JIRA_RLSE_PREFIX':'iva-spring-batch'
        ],
    'ivakbs' : [ 
        'BITB_PROJECT':'IVAKBS',
        'BITB_TST_REPO':'kbs-robot',
        'JIRA_PROJECT':'IVAKBS',
        'JIRA_RLSE_PREFIX':'KlantBehandelSysteem'
        ]
    ]

    static def MMNotificationChannel = [
    // Configuration for send message to MM channel
    'gsv-database-config' : [  
        'TST':['MMCHANNEL':'#wd-omgevingen'],
        'ACC':['MMCHANNEL':'#wd-omgevingen']
        ],
    'TEST-gsv-database-config' : [
        'TST':['MMCHANNEL':'#maatwerk-test'],
        'ACC':['MMCHANNEL':'#maatwerk-test']
        ],
    'iva-gsv' : [  
        'TST':['MMCHANNEL':'#wd-omgevingen'],
        'ACC':['MMCHANNEL':'#wd-omgevingen']
        ],
    'gsv-database' : [  
        'TST':['MMCHANNEL':'#wd-omgevingen'],
        'ACC':['MMCHANNEL':'#wd-omgevingen']
        ],
    'TEST-gsv-database' : [
        'TST':['MMCHANNEL':'#maatwerk-test'],
        'ACC':['MMCHANNEL':'#maatwerk-test']
        ],
    'iva-werkgroep' : [  
        'TST':['MMCHANNEL':'#wd-omgevingen'],
        'ACC':['MMCHANNEL':'#wd-omgevingen']
        ],
    'tbm' : [
        'TST':['MMCHANNEL':'#wd-omgevingen'],
        'ACC':['MMCHANNEL':'#wd-omgevingen']
        ],
    'ivabat' : [
        'TST':['MMCHANNEL':'#wd-bat-wf-pat-collaboration'],
        'ACC':['MMCHANNEL':'#wd-bat-wf-pat-collaboration']
        ],
    'ivabvn' : [
        'TST':['MMCHANNEL':'#maatwerk-test'],
        'ACC':['MMCHANNEL':'#maatwerk-test']
        ],
    'TEST-ivabat' : [
        'TST':['MMCHANNEL':'#maatwerk-test'],
        'ACC':['MMCHANNEL':'#maatwerk-test']
        ],
    'ivabat-database' : [
        'TST':['MMCHANNEL':'#wd-bat-wf-pat-collaboration'],
        'ACC':['MMCHANNEL':'#wd-bat-wf-pat-collaboration']
        ],
    'TEST-ivabat-database' : [
        'TST':['MMCHANNEL':'#maatwerk-test'],
        'ACC':['MMCHANNEL':'#maatwerk-test']
        ],   
    'zaakadministratie' : [
        'TST':['MMCHANNEL':'##wd-omgevingen'],
        'ACC':['MMCHANNEL':'##wd-omgevingen']
        ],   
    'zaakadministratie-database' : [
        'TST':['MMCHANNEL':'##wd-omgevingen'],
        'ACC':['MMCHANNEL':'##wd-omgevingen']
        ],
    'stivers' : [
        'TST':['MMCHANNEL':'#maatwerk-test'],
        'ACC':['MMCHANNEL':'#maatwerk-test']
        ]
    ]

    static def thirdPartyJobs = [ 
    // Configuration for running third party job on iva-gsv
    'iva-gsv' : [
        'ACC':['PARTIES':
            [
                ['DESCRIPTION':'Acc testen van Document Management', 
                 'JOBURL':'http://oivacmrl05.ont.belastingdienst.nl:8080/jenkins/view/DMGE/job/dmge.test/job/dmge.test.smoke/buildWithParameters?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9&ENVIRONMENT=TST_HA',
                 'TOKEN':'weera09:118cc81b385e27730ba8d2ee50c1efa5c3']
            ]
        ]
    ],
    'dummy application' : [
        'ONT':['PARTIES':
            [
                ['DESCRIPTION':'Ont testen van Third Party', 'JOBURL':'Productie URL 1', 'TOKEN':'UserToken ONT']
            ]
        ],
        'TST':['PARTIES':
            [
                ['DESCRIPTION':'Test testen van Third Party 1', 'JOBURL':'Productie URL 1', 'TOKEN':'UserToken TST01'],
                ['DESCRIPTION':'Test testen van Third Party 2', 'JOBURL':'Productie URL 2', 'TOKEN':'UserToken TST02']
            ]
        ],
        'ACC':['PARTIES':
            [
                ['DESCRIPTION':'Acc testen van Third Party 1', 'JOBURL':'Productie URL 1', 'TOKEN':'UserToken ACC_A'],
                ['DESCRIPTION':'Acc testen van Third Party 2', 'JOBURL':'Productie URL 2', 'TOKEN':'UserToken ACC_B'],
                ['DESCRIPTION':'Acc testen van Third Party 3', 'JOBURL':'Productie URL 3', 'TOKEN':'UserToken ACC_C']
            ]
        ],
        'PRD':['PARTIES':
            [
                ['DESCRIPTION':'Prod testen van Third Party', 'JOBURL':'Productie URL 1', 'TOKEN':'UserToken PRD_ABC']
            ]
        ]
    ]
    ]

    static def getConfiguration(String applicatie, String omgeving) {
        // applicatie = mvn ArtifactId
        def result = config[applicatie]
        if ( result != null) {
            result = result[omgeving.toUpperCase()]
        }
        result
    }

    static def getThirdPartyJobs(String applicatie, String omgeving) {
        // applicatie = mvn ArtifactId
        def result = thirdPartyJobs[applicatie]
        if ( result != null) {
            result = result[omgeving.toUpperCase()]
        }
        result
    }


    static def getNexusUrlPrefix() {
        nexus_repository_prefix
    }

    static def getNexusUrl() {
        nexus_url
    }

    static def getQuayUrlPrefix() {
        "${quay_url}${quay_repository_prefix}"
    }

// Is dit wel goed??
    static def getQuayUrl() {
        nexus_url
    }

    static def getHarborWdRepository() {
        "${harbor_url}${harbor_repository_prefix}"
    }

    static def getHarborServername() {
        harbor_url
    }

    static def getJdkImage() {
        jdk_image
    }

    static def getJiraServerUrl() {
        jira_server_url
    }

    static def getNpmRepositoryUrl() {
        npm_repository_url
    }

    static def determinePackageDirectory(String deploymentDirectory, String packageDirectory) {
        "${deploymentDirectory}/${packageDirectory}/target/"
    }
    
    static def getSonarUrl() {
        sonar_url
    }
    
    static def getGitServerUrl() {
        bitbucket_url
    }
    
    static def getDinqHostname() {
        dinq_host
    }
    static def getDinqUrl() {
        dinq_url
    }
    
    static def getDinqCredentials() {
        dinq_credential_id
    }

    static def getJiraUserCredentialId() {
        jira_credential_id
    }
    
    static def getSonarToken() {
        sonar_token
    }

    static def getStageId(String environment) {
        stages[environment.toUpperCase()]
    }


    static def getJenkinsDbCredentials(String environment) {
        dbConfig['gsv-database'][environment.toUpperCase()]['dbCredentials']
    }

    static def getJenkinsDbCredentials(String deploymentId, String environment) {
        dbConfig[deploymentId][environment.toUpperCase()]['dbCredentials']
    }

    static def getDbUrl(String deploymentId, String environment) {
        dbConfig[deploymentId][environment.toUpperCase()]['URL']
    }

    static def getSchemaName(String deploymentId, String environment, String street) {
        if (street.toUpperCase() == 'PRODUCTIE') {
            "${dbConfig[deploymentId][environment.toUpperCase()]['SCHEMA_PREFIX']}1"
        }
        else if (street.toUpperCase() == 'OPLEIDING') {
            "${dbConfig[deploymentId][environment.toUpperCase()]['SCHEMA_PREFIX']}2"
        }
        else if (street.toUpperCase() == 'CONFORMANCE') {
            "${dbConfig[deploymentId][environment.toUpperCase()]['SCHEMA_PREFIX']}2"
        }
        else {
            if (street.toUpperCase().contains("STR1")) {
                "${dbConfig[deploymentId][environment.toUpperCase()]['SCHEMA_PREFIX']}${street.substring(street.length() - 1)}"
            }
            else {
                "${dbConfig[deploymentId][environment.toUpperCase()]['SCHEMA_PREFIX']}${street.toUpperCase()}"
            }
        }
    }

    static def getDestinations(String deploymentId, String environment) {
        config[deploymentId][environment.toUpperCase()]['DESTINATIONS']
    }

    static def getJenkinsMavenSettingsId() {
        jenkins_maven_settings_id
    }

    static def getJenkinsMavenNexus3SettingsId() {
        jenkins_maven_nexus3_settings_id
    }

    static def getJenkinsLockPrefix(String deploymentId) {
        def tempPrefix = lockPrefixes[deploymentId]
        if (tempPrefix == null) {
            tempPrefix = deploymentId
        }
        tempPrefix
    }

    static def getMavenDinqPlugin() {
        mavenDinqPlugin
    }

    static def getLbSelector(String deploymentId, String environment) {
        LBconfig[deploymentId][environment.toUpperCase()]['LB_SELECTOR']
    }

    static def getMemberSelectors(String deploymentId, String environment) {
        LBconfig[deploymentId][environment.toUpperCase()]['MEMBER_SELECTOR']
    }

    static def getMemberHostnames(String deploymentId, String environment) {
        LBconfig[deploymentId][environment.toUpperCase()]['MEMBER_HOSTNAME']
    }

    static def getAnnaUrl() {
        anna_url
    }

    static def getAnnaCredentials() {
        anna_credential_id
    }

    static def getExcludeCommitterUsers() {
        exclude_commit_users
    }

    static def getOSprojectBase(String deploymentId, String environment) {
        def result = OSConfig[deploymentId]
        if ( result != null && environment != null ) {
            result = result[environment.toUpperCase()]
        }
        if ( result != null && environment != null ) {
           OSConfig[deploymentId][environment.toUpperCase()]['projectBase']
        }
    }

    static def getOSprojectName(String deploymentId, String environment) {
        def result = OSConfig[deploymentId]
        if ( result != null && environment != null ) {
            result = result[environment.toUpperCase()]
        }
        if ( result != null && environment != null ) {
               OSConfig[deploymentId][environment.toUpperCase()]['projectName']
        }
    }

    static def getMMChannel(String deploymentId, String environment) {
        def result = MMNotificationChannel[deploymentId]
        if ( result != null && environment != null ) {
            result = result[environment.toUpperCase()]
        }
        if ( result != null && environment != null ) {
           MMNotificationChannel[deploymentId][environment.toUpperCase()]['MMCHANNEL']
        }
    }

    static def getBitbucketProject(String deploymentId) {
        def result = repoConfig[deploymentId]
        if ( result != null) {
            repoConfig[deploymentId]['BITB_PROJECT']
        }
    }

    static def getBitbucketTestRepo(String deploymentId) {
        def result = repoConfig[deploymentId]
        if ( result != null) {
            repoConfig[deploymentId]['BITB_TST_REPO']
        }
    }

    static def getJiraProject(String deploymentId) {
        def result = repoConfig[deploymentId]
        if ( result != null) {
            repoConfig[deploymentId]['JIRA_PROJECT']
        }
    }

    static def getJiraProjectRlsePref(String deploymentId) {
        def result = repoConfig[deploymentId]
        if ( result != null) {
            repoConfig[deploymentId]['JIRA_RLSE_PREFIX']
        }
    }
}
