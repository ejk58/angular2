def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def npmRepoUrl = ApplicationConfiguration.getNpmRepositoryUrl()
    def frontendDir = 'kbs-frontend'
    def distDir = 'kbs-frontend/storybook-static'
    def osProject = 'wd-kbs'

    node("nodejs16") {
        stage('Clone') {
            checkout scm
        }
        stage('npm build') {
            sh """
                export npm_config_registry=${npmRepoUrl}
                cd ${frontendDir}
                # building storybook
                node --version
                npm --version
                rm package-lock.json
                npm i --force
                echo Running storybook build
                npm run build-storybook
            """
        }
        stage('image build') {
            sh """
                cd ${distDir}
                ls -la
                # Possibly updating openshift resources
                oc project ${osProject}
                if [ `oc get all | grep -E "(service/storybook|buildconfig.build.openshift.io/storybook|deployment.apps/storybook)" | wc -l` -ne 3 ] ; then
                    oc delete bc storybook --ignore-not-found=true --wait=true
                    oc delete deployment storybook --ignore-not-found=true --wait=true
                    oc delete service storybook --ignore-not-found=true --wait=true
                    oc delete is storybook --ignore-not-found=true --wait=true
        
                    # Building image
                    oc new-app httpd~. --name=storybook
                fi

                if [ `oc get all | grep -E "(route.route.openshift.io/storybook)" | wc -l` -ne 1 ] ; then
                    oc apply -f ../openshift/route.yaml
                fi

                oc start-build storybook --from-dir .
            """
        }
    }
}
