def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    if (config.projectDir == null) {
        config.projectDir = './ivai-war'
    }
    if (config.protractorConfDir == null) {
        config.protractorConfDir = '.'
    }
    if (config.reportDir == null) {
        config.reportDir = './ivai-war/src/test/e2e/reports'
    }

    
    node {

        try {
            stage ('Clone') {
                
                checkout scm
                
                pipelineTrigger = pipelineTriggers(config.pipelineTrigger)

                properties([
                    parameters([
                        choice(name: 'npmInstall', choices: 'NO\nYES', description: 'Npm install?'),
                        choice(name: 'reRunFailed', choices: 'YES\nNO', description: 'Rerun failed tests?'),
                        string(name: 'projectDir', defaultValue: config.projectDir, description: 'Where is the project located?'),
                        string(name: 'protractorConfDir', defaultValue: config.protractorConfDir, description: 'Where is protractor.conf.js located?'),
                        string(name: 'reportDir', defaultValue: config.reportDir, description: 'Where are the E2E result reports located in the project after testing?')
                    ]),
                    disableConcurrentBuilds(),
                    pipelineTrigger
                ])
            }

            stage ("Protractor"){
                echo "Scaling up pods."
                sh """
                    curl -X PATCH https://api.cn01.chp.belastingdienst.nl:6443/apis/apps.openshift.io/v1/namespaces/wd-selenium-grid/deploymentconfigs/selenium-node-chrome \\
                    --header "Authorization: Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6Im1LM25fSmg3X2NMV3dUcFljYlQ5V09MZElUaGhVbTRjd09QQ2FPOTBfTjQifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJ3ZC1zZWxlbml1bS1ncmlkIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZWNyZXQubmFtZSI6ImF1dG8tc2NhbGUtcm9ib3Qtc2EtdG9rZW4tNnE1d20iLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoiYXV0by1zY2FsZS1yb2JvdC1zYSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6IjUzNmU4ZTgzLWUyMjItNDEwOS05YmE4LThjNGViNTZjZWMyMyIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDp3ZC1zZWxlbml1bS1ncmlkOmF1dG8tc2NhbGUtcm9ib3Qtc2EifQ.I0VG3822IWHmJhaJBJkWwu6VQG2c55Rb0htpgQgPBDGqze1bLsCIDK7KExwAByRlz0nHCv6gjAtfYqh8CPKEE-5owgTA_j75y8ULzYXmZoEUzpzfN6WYoQiWEpNCUg3JCVeUzi9dnaSY3DUWA1Jpf6_l2LNbm0o2wOBv49-seA4jynQIZrAQWsZ4EhES7lzHZLU9d1t0TaITfN08PPkn4N4F_H_S41x9KNqq4jbCgPJBvdSimsaMR2_qID5hGODJX5Dhvj6hFNFqWrljLxLbGSvV1XDbLnN23RukznysZC7EvBzAPnAAdK_g6tdtODobRpgw3wTQMubbwMtYBz3uuw" \\
                    --header 'Accept: application/json' \\
                    --header 'Content-Type: application/strategic-merge-patch+json' \\
                    --insecure \\
                    --data '{"spec": {"replicas":  9}}'
                    """
                try{
                    protractor(params.npmInstall, params.reRunFailed, params.projectDir, params.protractorConfDir)
                    currentBuild.result = 'SUCCESS'
                }catch(e){
                    currentBuild.result = 'FAILURE'
                }
            }

        } catch (e) {
            currentBuild.result = 'FAILURE'
            throw e
        } finally {
            echo "Scaling down pods."
            sh """
                curl -X PATCH https://api.cn01.chp.belastingdienst.nl:6443/apis/apps.openshift.io/v1/namespaces/wd-selenium-grid/deploymentconfigs/selenium-node-chrome \\
                --header "Authorization: Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6Im1LM25fSmg3X2NMV3dUcFljYlQ5V09MZElUaGhVbTRjd09QQ2FPOTBfTjQifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJ3ZC1zZWxlbml1bS1ncmlkIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZWNyZXQubmFtZSI6ImF1dG8tc2NhbGUtcm9ib3Qtc2EtdG9rZW4tNnE1d20iLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoiYXV0by1zY2FsZS1yb2JvdC1zYSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6IjUzNmU4ZTgzLWUyMjItNDEwOS05YmE4LThjNGViNTZjZWMyMyIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDp3ZC1zZWxlbml1bS1ncmlkOmF1dG8tc2NhbGUtcm9ib3Qtc2EifQ.I0VG3822IWHmJhaJBJkWwu6VQG2c55Rb0htpgQgPBDGqze1bLsCIDK7KExwAByRlz0nHCv6gjAtfYqh8CPKEE-5owgTA_j75y8ULzYXmZoEUzpzfN6WYoQiWEpNCUg3JCVeUzi9dnaSY3DUWA1Jpf6_l2LNbm0o2wOBv49-seA4jynQIZrAQWsZ4EhES7lzHZLU9d1t0TaITfN08PPkn4N4F_H_S41x9KNqq4jbCgPJBvdSimsaMR2_qID5hGODJX5Dhvj6hFNFqWrljLxLbGSvV1XDbLnN23RukznysZC7EvBzAPnAAdK_g6tdtODobRpgw3wTQMubbwMtYBz3uuw" \\
                --header 'Accept: application/json' \\
                --header 'Content-Type: application/strategic-merge-patch+json' \\
                --insecure \\
                --data '{"spec": {"replicas":  2}}'
                """
            echo "Protractor report dir: " + params.reportDir
            publishHTML([
                allowMissing: false,
                alwaysLinkToLastBuild: false,
                keepAll: true,
                reportDir: params.reportDir,
                reportFiles: './e2e-tests/report.html',
                reportName: 'Protractor Report',
                reportTitles: ''
            ])

            emailNotification()
        }
    }
}