def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrlPrefix = ApplicationConfiguration.getNexusUrlPrefix()

    def sonarUrl = 'https://owsoel19954.ont.belastingdienst.nl/sonar/'  //ApplicationConfiguration.getSonarUrl()
    def sonarToken = '7dea5b2361e99b37f808bec8f14d9571bfbcc45e'  //ApplicationConfiguration.getSonarToken()
    
    def nexusUrl = ApplicationConfiguration.getNexusUrl()
    def dinqUrl = ApplicationConfiguration.getDinqUrl()
    def dinq_credential_id = ApplicationConfiguration.getDinqCredentials()

    def mvnDinqPlugin = ApplicationConfiguration.getMavenDinqPlugin()
    
    def mvnExtraBuildArguments = ""
    if (config.mvnExtraBuildArguments != null) {
        mvnExtraBuildArguments = config.mvnExtraBuildArguments
    }
    def skipOwaspDependencyCheck = false
    if (config.skipOwaspDependencyCheck != null) {
        skipOwaspDependencyCheck = config.skipOwaspDependencyCheck
    }
    
    def clusterSyncDelaySeconds = 5

    def dryRun = false
    def baseDir = '.'
    def lockLabel = 'XXXX'

    def exclude_committer_users = ApplicationConfiguration.getExcludeCommitterUsers()

    def channel=ApplicationConfiguration.getMMChannel(config.deploymentId, params.environment)

    if (config.baseDirectory != null) {
        baseDir = config.baseDirectory
    }

    // Environment setting for the OWASP check
    env.MAVEN_SETTINGS_FILE_ID = ApplicationConfiguration.getJenkinsMavenNexus3SettingsId();
    
    def silenceId = ""

    node {
        deleteDir()

        try {
            stage ('Clone') {

                checkout scm

                properties([
                    parameters([
                        choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
                        choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                        choice(name: 'run_it_test', choices: 'YES\nNO', description: 'Run the integration tests?')
                    ]),
                    disableConcurrentBuilds(),
                    pipelineTriggers([pollSCM('')])  
                ])

                committerName = sh (
                      script: 'git --no-pager show -s --format=\'%cn\'',
                      returnStdout: true
                ).trim()

            }
            
            if (! exclude_committer_users.contains(committerName)) {
                stage('Build') {
                    lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
                    dir(baseDir) {
                        projectInfo = getInfoFromPom(readFile("pom.xml"))
                        if (config.artifactId != null) {
                            projectInfo.artifactId = config.artifactId
                        }
                        echo "**************************************************************\n" +
                            "** Deployment parameters:\n" +
                            "** deploymentId     = ${config.deploymentId}\n" +
                            "** GroupId          = ${projectInfo.groupId}\n" +
                            "** ArtifactId       = ${projectInfo.artifactId}\n" +
                            "** version          = ${projectInfo.version}\n" +
                            "**  \n" +
                            "** environment      = ${params.environment}\n" +
                            "** street           = ${params.street}\n" +
                            "** lockLabel        = ${lockLabel}\n" +
                            "** extraArguments   = ${mvnExtraBuildArguments}\n" +
                            "**************************************************************\n"

                        snapshotFilename = "DummySnapshotFilename"
                        buildnumber = "DummyBuildNumber"
                        if (dryRun) {
                            echo "DRYRUN: Running maven clean deploy\n"
                        }
                        else {
                            sh "mvn -V clean deploy -DExtraVersionInformation=-${params.environment}-${params.street} ${mvnExtraBuildArguments}  | tee mvn.log "
                            snapshotFilenameGrepTxt = "Uploading.*package-${projectInfo.artifactId}-${projectInfo.versionWithoutSnapshot()}-[0123456789]*.[0123456789-]*.zip"

                            stdOut = sh script: "grep \"${snapshotFilenameGrepTxt}\" mvn.log", returnStdout: true
                            stdOut = stdOut.trim()
                            snapshotFilename = stdOut.substring(stdOut.lastIndexOf('/') + 1)
                        }
                        echo "Project information: ${projectInfo}\nSnapshotFilename: ${snapshotFilename}\n"
                    }
                }
                stage('OWASP dependency analysis') {
                    if (skipOwaspDependencyCheck) {
                        echo "Skipping the OWASP Dependency Check"
                    } else {
                        analyzeDependencies()
                    }
                }
                stage ("Sonar"){
                    if (dryRun) {
                        echo "DRYRUN: Running sonar check\n"
                    }
                    else {
                        checkout(changelog: false, scm: scm)
                        dir(baseDir) {
                            sh "mvn clean verify -P sonarqube ${mvnExtraBuildArguments}"
                            sh "mvn org.pitest:pitest-maven:mutationCoverage -P sonarqube ${mvnExtraBuildArguments}"
                            sh "mvn org.pitest:pitest-maven:report-aggregate-module --non-recursive -P sonarqube ${mvnExtraBuildArguments}"
                            sh "mvn sonar:sonar -P sonarqube -Dsonar.host.url=${sonarUrl} -Dsonar.login=${sonarToken} ${mvnExtraBuildArguments}"
                        }
                    }
                }
                stage('Publish Reports') {
                    if (dryRun) {
                        echo "DRYRUN: Not publishing reports\n"
                    }
                    else {
                        junit allowEmptyResults: true, testResults: '**/surefire-reports/*.xml'
                    }
                }
                stage('Deploy') {
                    lock(lockLabel) {
                        dir(baseDir) {
                            //  https://nexus.belastingdienst.nl/nexus/repository/snapshots/nl/belastingdienst/iva/wd/ivad/package-iva-datadashboard/1.26.0-SNAPSHOT/package-iva-datadashboard-1.26.0-20210504.071315-2.zip
                            artifactUrl = "${nexusUrl}/nexus/repository/snapshots/${projectInfo.groupIdPath()}/package-${projectInfo.artifactId}/${projectInfo.version}/${snapshotFilename}"

                            stage = ApplicationConfiguration.getStageId(params.environment)
                            destinations = ApplicationConfiguration.getDestinations(config.deploymentId, params.environment)

                            echo "**************************************************************\n" +
                                "** Deployment parameters:\n" +
                                "** deploymentId     = ${config.deploymentId}\n" +
                                "** GroupId          = ${projectInfo.groupId}\n" +
                                "** ArtifactId       = ${projectInfo.artifactId}\n" +
                                "** version          = ${projectInfo.version}\n" +
                                "**  \n" +
                                "** environment      = ${params.environment}\n" +
                                "** street           = ${params.street}\n" +
                                "**  \n" +
                                "** dinqUrl          = ${dinqUrl}\n" +
                                "** stage            = ${stage}\n" +
                                "** destinations     = ${destinations}\n" +
                                "** artifactUrl      = ${artifactUrl}\n" +
                                "** snapshotFilename = ${snapshotFilename}\n" +
                                "**  \n" +
                                "** Run IT test      = ${params.run_it_test}\n" +
                                "**************************************************************"

                            if (dryRun) {
                                echo "DRYRUN: Deploying artifact using parameters:\n" +
                                "- deploymentId     : ${config.deploymentId}\n"
                            }
                            else {
                                def syncDelay = clusterSyncDelaySeconds * 1000
                                if ( params.environment.toUpperCase() == "TST" ||  params.environment.toUpperCase() == "ACC" ) {
                                    message = "Start uitrol van ${config.deploymentId} versie ${projectInfo.version} op ${params.environment} - ${params.street}"
                                    // if the channel is defined in ApplicationConfiguration
                                    if (channel?.trim()) {
                                    mattermostSend channel: "${channel}", message: "${message}"
                                    }
                                }
                                if ( params.environment.toUpperCase() == "PRD" ) {
                                omgeving = ""
                            }
                            else {
                                omgeving = ".${params.street}.${params.environment}"
                            }
                            instance = "${projectInfo.artifactId}${omgeving}.belastingdienst.nl"
                            script="add_silence.py"
                            def yourScriptAsaString = libraryResource "../resources/${script}" 
                            writeFile file: "${script}", text: yourScriptAsaString
                            silenceId = sh( script: "python3 -u ${script} ${instance}",
                                          returnStdout: true
                                          ).trim();
                            echo "${instance} is ge-silenced in alertmanager met id ${silenceId}"
                                withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: dinq_credential_id, passwordVariable: 'DINQ_APIKEY', usernameVariable: 'DINQ_ACCOUNT']]) {
                                    for (destination in destinations) {
                                        mvnArguments = "-DartifactUrl=$artifactUrl -DdinqEndpoint=$dinqUrl -Dstage=$stage \"-Ddestination=$destination\" -Dparams=\"street=${params.street}\" -DdinqAccount=${env.DINQ_ACCOUNT} -DapiKey=${env.DINQ_APIKEY} -Ddinq.maven.plugin.was.cluster.sync.time=${syncDelay}"
                                        echo "mvnArguments: ${mvnArguments}"
                                        try {
                                            sh "mvn ${mvnDinqPlugin}:undeploy ${mvnArguments}  ${mvnExtraBuildArguments}"
                                        } catch (any) {
                                            // Doing nothing here. Exception probably because the package was not active
                                        }
                                        try {
                                            sh "mvn ${mvnDinqPlugin}:deleteOrphans ${mvnArguments}  ${mvnExtraBuildArguments}"
                                        } catch (any) {
                                            // Doing nothing here. Exception probably because the package was not active
                                        }
                                        sh "mvn ${mvnDinqPlugin}:deploy ${mvnArguments}  ${mvnExtraBuildArguments}"
                                    }
                                }
                            if ( params.environment.toUpperCase() == "TST" ||  params.environment.toUpperCase() == "ACC" ) {
                            // if the channel is defined in ApplicationConfiguration
                                if (channel?.trim()) {
                                    message = "Einde uitrol van ${config.deploymentId} versie ${projectInfo.version} op ${params.environment} - ${params.street}"
                                    mattermostSend channel: "${channel}", message: "${message}"
                                }
                            }
                            }
                        }
                    }
                }
                if (params.run_it_test ==~ /(YES)/ && config.integrationPipeline != "") {
                    if (dryRun) {
                        echo "DRYRUN: Not running integration tests\n"
                    }
                    else {
                        echo "Running integration tests\n"
                        build job: config.integrationPipeline, parameters: [string(name: 'environment', value: params.environment), string(name: 'street', value: params.street)], propagate: false, wait: false
                    }
                } else {
                    echo "'run_it_test' set to false >> Robot tests skipped."
                }
            } 
            else {
                echo "build, Sonar, Publish Reports, Deploy and Test not executed, because committer is jenkins"
            }

            currentBuild.result = 'SUCCESS'

        } catch (any) {
            currentBuild.result = 'FAILURE'
            throw any
        } finally {
            if (silenceId?.trim()) { 
                script="del_silence.py"
                def yourScriptAsaString = libraryResource "../resources/${script}" 
                writeFile file: "${script}", text: yourScriptAsaString
                result = sh( script: "python3 -u ${script} ${silenceId}",
                            returnStdout: true
                            ).trim();
                echo "${instance} wordt weer gemonitord"
            }
            emailNotification()
            
        }
    }
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
    def gav = new GAV()
    def project = new XmlSlurper().parseText( pomContent )
    gav.groupId = project.groupId.toString()
    gav.artifactId = project.artifactId.toString()
    gav.version = project.version.toString()
    gav
}

class GAV {
    String groupId
    String artifactId
    String version

    def String groupIdPath() {
        groupId.replaceAll("\\.", "/")
    }
    def String versionWithoutSnapshot() {
        if (version.endsWith("-SNAPSHOT")) {
            version.substring(0, version.length() - 9)
        }
        else {
            version
        }
    }
    def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
