def call(String projectDir, String dirToLint, String eslintConfDir) {
    echo "Start ESLint run."

    echo "Project dir: " + projectDir
    echo "Dir to lint: " + dirToLint
    echo "Eslint config dir: " + eslintConfDir

    sh """
    cd $projectDir;
    npm install;
    node ./node_modules/.bin/eslint $dirToLint --config $eslintConfDir/.eslintrc.json --no-eslintrc --ext js,ts,json
    """

}