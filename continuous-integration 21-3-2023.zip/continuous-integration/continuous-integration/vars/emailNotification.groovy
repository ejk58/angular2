def call() {
    if (currentBuild.result == "FAILURE" || (currentBuild.previousBuild != null && currentBuild.result != currentBuild.previousBuild.result)){
        def recipients = emailextrecipients([[$class: 'CulpritsRecipientProvider'], [$class: 'DevelopersRecipientProvider'], [$class: 'RequesterRecipientProvider']])
        def color = (currentBuild.result == "FAILURE") ? 'red' : 'green'
        def message = """<div style=\"font-family: verdana;\">
            <p>${env.JOB_NAME} [${env.BUILD_DISPLAY_NAME}]: <span style=\"font-weight: bold; color: ${color}\">${currentBuild.result}</span><br>
            You can check the console output in Jenkins at <a href='${env.BUILD_URL}'>${env.JOB_NAME} [${env.BUILD_DISPLAY_NAME}]</a>.</p>
            <p><ul>
            <li>Status: ${currentBuild.result}</li>
            <li>Job: ${env.JOB_NAME}</li>
            <li>Build: ${env.BUILD_DISPLAY_NAME}</li>
            </ul></p></div>"""

        if (recipients != null) {
            emailext subject: "${env.JOB_NAME} [${env.BUILD_DISPLAY_NAME}]: ${currentBuild.result}",
                    to: recipients,
                    cc: 'iv.accent.coe.maatwerk@belastingdienst.nl',
                    body: message,
                    mimeType: 'text/html',
                    charset: 'utf-8'
        }
    }
}