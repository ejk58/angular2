def call(channel, message) {
    mattermostSend channel: "${channel}", message: "${message}"
}