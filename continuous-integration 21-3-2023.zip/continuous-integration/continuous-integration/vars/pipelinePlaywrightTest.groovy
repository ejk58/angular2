def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    if (config.projectDir == null) {
        config.projectDir = './ivai-war'
    }
    if (config.reportDir == null) {
        config.reportDir = './ivai-war/playwright-report'
    }


    node {

        try {
            stage ('Clone') {

                checkout scm

                pipelineTrigger = pipelineTriggers(config.pipelineTrigger)

                properties([
                        parameters([
                                choice(name: 'npmInstall', choices: 'NO\nYES', description: 'Npm install?'),
                                string(name: 'projectDir', defaultValue: config.projectDir, description: 'Where is the project located?'),
                                string(name: 'reportDir', defaultValue: config.reportDir, description: 'Where are the E2E result reports located in the project after testing?')
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTrigger
                ])
            }

            stage ("Playwright"){
                echo "Scaling up pods."
                sh """
                   curl --write-out '%{http_code}' --silent --output /dev/null -X PATCH https://api.cn01.chp.belastingdienst.nl:6443/apis/apps.openshift.io/v1/namespaces/wd-selenium-grid-4/deploymentconfigs/selenium-node-chrome \\
                    --header "Authorization: Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6Im1LM25fSmg3X2NMV3dUcFljYlQ5V09MZElUaGhVbTRjd09QQ2FPOTBfTjQifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJ3ZC1zZWxlbml1bS1ncmlkLTQiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlY3JldC5uYW1lIjoiYXV0by1zY2FsZS1yb2JvdC1zYS10b2tlbi14dnpxNyIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJhdXRvLXNjYWxlLXJvYm90LXNhIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiYjNlNzI3YzgtNGUyNy00MjI3LWFhYTMtMGM4YTU5ZTc0ZDY1Iiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50OndkLXNlbGVuaXVtLWdyaWQtNDphdXRvLXNjYWxlLXJvYm90LXNhIn0.A70o91lYJW-X8W7OObscxxmF_3PW1PFe2dejDXAjBG8v8VFYVSPkmDOmN46HDvmitGqWTjPSlNJuQgAoVhp_Av8IQdCWYClQlvfH8cIAaEan6pdvRodBlP-Fm6GfhIDguAsKn6al-c7MT-krz3RPa23BWotpSXejvd_mFwQ-N0rjlXnOjXjYYfGlhS8bc2uXnmSRyiTcd4zGQZNQf4VJDJJsasYmzNInvyOOMP_ORNNSnU4-QpofBCIEwKEb_WYChpwBecIuW5oYHfWZV1W7-XXf4TqodwZUmCrL7PdByiN49SOvmv0dYnYvejxIPiRK-dWVHSCGcqQi5rMTjEDw9A" \\
                    --header 'Accept: application/json' \\
                    --header 'Content-Type: application/strategic-merge-patch+json' \\
                    --insecure \\
                    --data '{"spec": {"replicas":  9}}' \\
                   """
//                echo "Waiting for all replicas to be ready"
//                waitUntil(initialRecurrencePeriod: 15000, quiet: true) {
//                    def output = sh(returnStdout: true, script: 'oc get dc/selenium-node-chrome -n wd-selenium-grid-4 -o template --template \'{{.status.readyReplicas}}\'').trim()
//                    echo "Current ready replica's: " + output
//                    output == "9"
//                }
                echo "Running tests."
                try{
                    playwright(params.npmInstall, params.projectDir)
                    currentBuild.result = 'SUCCESS'
                }catch(e){
                    currentBuild.result = 'FAILURE'
                }
                echo "Scaling down pods."
                sh """
                   curl --write-out '%{http_code}' --silent --output /dev/null -X PATCH https://api.cn01.chp.belastingdienst.nl:6443/apis/apps.openshift.io/v1/namespaces/wd-selenium-grid-4/deploymentconfigs/selenium-node-chrome \\
                    --header "Authorization: Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6Im1LM25fSmg3X2NMV3dUcFljYlQ5V09MZElUaGhVbTRjd09QQ2FPOTBfTjQifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJ3ZC1zZWxlbml1bS1ncmlkLTQiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlY3JldC5uYW1lIjoiYXV0by1zY2FsZS1yb2JvdC1zYS10b2tlbi14dnpxNyIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJhdXRvLXNjYWxlLXJvYm90LXNhIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiYjNlNzI3YzgtNGUyNy00MjI3LWFhYTMtMGM4YTU5ZTc0ZDY1Iiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50OndkLXNlbGVuaXVtLWdyaWQtNDphdXRvLXNjYWxlLXJvYm90LXNhIn0.A70o91lYJW-X8W7OObscxxmF_3PW1PFe2dejDXAjBG8v8VFYVSPkmDOmN46HDvmitGqWTjPSlNJuQgAoVhp_Av8IQdCWYClQlvfH8cIAaEan6pdvRodBlP-Fm6GfhIDguAsKn6al-c7MT-krz3RPa23BWotpSXejvd_mFwQ-N0rjlXnOjXjYYfGlhS8bc2uXnmSRyiTcd4zGQZNQf4VJDJJsasYmzNInvyOOMP_ORNNSnU4-QpofBCIEwKEb_WYChpwBecIuW5oYHfWZV1W7-XXf4TqodwZUmCrL7PdByiN49SOvmv0dYnYvejxIPiRK-dWVHSCGcqQi5rMTjEDw9A" \\
                    --header 'Accept: application/json' \\
                    --header 'Content-Type: application/strategic-merge-patch+json' \\
                    --insecure \\
                    --data '{"spec": {"replicas":  2}}' \\
                   """
            }

        } catch (e) {
            currentBuild.result = 'FAILURE'
            throw e
        } finally {
            echo "Playwright report dir: " + params.reportDir
            publishHTML([
                    allowMissing: false,
                    alwaysLinkToLastBuild: false,
                    keepAll: true,
                    reportDir: params.reportDir,
                    reportFiles: 'index.html',
                    reportName: 'Playwright Report',
                    reportTitles: ''
            ])

            emailNotification()
        }
    }
}