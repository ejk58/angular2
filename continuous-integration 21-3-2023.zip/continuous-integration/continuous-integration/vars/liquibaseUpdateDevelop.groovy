def call(String gitUrlDb, String gitBranchDb, String dbUser, String dbUrl, String defaultSchemaName, String changelogFile, String contexts) {
	
			checkout(
				scm: [$class: 'GitSCM',
				branches: [[name: "*/${gitBranchDb}"]], 
				doGenerateSubmoduleConfigurations: false, 
				extensions: [[$class: 'CleanCheckout'], [$class: 'RelativeTargetDirectory', relativeTargetDir: "${gitBranchDb}"]], 
				submoduleCfg: [], 
				userRemoteConfigs: [[credentialsId: 'Jenkins ssh', url: "${gitUrlDb}" ]]])
			
			withCredentials([[$class: 'UsernamePasswordMultiBinding',
				credentialsId: "${dbUser}",
                usernameVariable: 'USERNAME',
				passwordVariable: 'PASSWORD']]) {
					sh "/mnt/data/liquibase/liquibase --url=${dbUrl} --defaultSchemaName=${defaultSchemaName} --username=${env.USERNAME} --password=${env.PASSWORD} --logLevel=info --classpath=${WORKSPACE}/${gitBranchDb}/Liquibase --changeLogFile=${changelogFile} --contexts=${contexts} update"
				}
}