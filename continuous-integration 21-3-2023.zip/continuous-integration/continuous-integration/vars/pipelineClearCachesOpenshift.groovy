def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    
    node("maven35-openjdk11") {
        stage('clear maven cache') {
            sh """
                rm -rf /home/jenkins/.buildcache/m2repo/
            """
        }
    }
    node("nodejs14") {
        stage('Clear npm cache') {
            sh """
                npm cache clean --force
            """
        }
    }
}