def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def sonarUrl = ApplicationConfiguration.getSonarUrl()
    def sonarToken = ApplicationConfiguration.getSonarToken()

    // Deze variabelen zijn project specifiek
    def projectBase = ApplicationConfiguration.getOSprojectBase(config.deploymentId, params.environment)
    def project = ApplicationConfiguration.getOSprojectName(config.deploymentId, params.environment)

    // Deze variabelen alleen als je niet de standaard volgt.
    def backendName = "${projectBase}-backend"
    def frontendName = "${projectBase}-frontend"
    if(projectBase == "zaakadministratie") {
        backendName = "zaakadministratie-backend"
        frontendName = ""
    }
    if(projectBase == "lrh") {
        backendName = "lrh-backend"
        frontendName = ""
    }
    if(params.street ==~ /(1)/) {
        openshiftDeployment = params.environment
    }
    else {
        openshiftDeployment = params.environment + params.street
    }

    def vervangenOpenjdk11Image = false
    if (config.vervangenOpenjdk11Image != null ) {
        vervangenOpenjdk11Image = config.vervangenOpenjdk11Image
    }
    def vervangenOpenshiftObjects = false
    if (config.vervangenOpenshiftObjects != null ) {
        vervangenOpenshiftObjects = config.vervangenOpenshiftObjects
    }

    def mvnVersion = "maven35-openjdk11"
    if (config.mvnVersion != null) {
        mvnVersion = config.mvnVersion
    }

    def nodeVersion = "nodejs10"
    if (config.nodeVersion != null) {
        nodeVersion = config.nodeVersion
    }

    def sonarVersion = "sonar"
    if (config.sonarVersion != null) {
        sonarVersion = config.sonarVersion
    }

    def skipSonar = false
    if (config.skipSonar != null) {
        skipSonar = config.skipSonar
    }

    def skipOWASP = false
    if (config.skipOWASP != null) {
        skipOWASP = config.skipOWASP
    }

    def updateImageTo = [];
    if (config.updateImageTo) {
        updateImageTo = config.updateImageTo
    }

    // Deze variabelen in principe niet veranderen
    def mvnCmd = 'mvn -B -s openshift/maven-settings.xml'

    def dryRun = false

    def tmpSonarDir = "/tmp/testSonar"

    def nodeNodeName = ""
    def mvnNodeName = ""

    node {
        skipDefaultCheckout()
        try {
            stage('Checkout') {
            //    node {
            //        label "maven35-openjdk11"
            //    }
                if (dryRun) {
                    echo "DRYRUN: Running scm checkout\n"
                    checkout scm

                    projectInfo = getInfoFromPom(readFile("pom.xml"))
                    ART = config.artifactId
                    echo "GROUP: ${projectInfo.groupId}"
                    echo "ARTIFACT: ${projectInfo.artifactId}"
                    echo "VERSION: ${projectInfo.version}"
                    echo "Artifact from config: ${ART}"
                    properties([
                        parameters([
                        choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
                        choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                        choice(name: 'run_it_test', choices: 'YES\nNO', description: 'Run the integration tests?')
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTriggers([pollSCM('')])
                        ])
                }
                else {
                    properties([
                        parameters([
                        choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
                        choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                        choice(name: 'run_it_test', choices: 'YES\nNO', description: 'Run the integration tests?')
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTriggers([pollSCM('')])
                        ])
                    checkout scm
                    // ITT Jeroen's versie, .git niet excluden omdat die voor de git-commit plugin nodig is
                    stash(name: 'ws', includes: '**', excludes: '**/node_modules/**', useDefaultExcludes: false)
                
                    projectInfo = getInfoFromPom(readFile("pom.xml"))
                }
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
            }
            if (frontendName?.trim()) {
                stage('NPM') {
                    if (config.artifactId != null) {
                        projectInfo.artifactId = config.artifactId
                    }
                    if (dryRun) {
                        echo "DRYRUN: Running npm i; npm run build\n"
                        echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** version          = ${projectInfo.version}\n" +
                        "**  \n" +
                        "** projectBase      = ${projectBase}\n" +
                        "** ocdProject       = ${project}\n" +
                        "** environment      = ${params.environment}\n" +
                        "** street           = ${params.street}\n" +
                        "** lockLabel        = ${lockLabel}\n" +
                        "** vervangenOpenjdk11Image        = ${vervangenOpenjdk11Image}\n" +
                        "** vervangenOpenshiftObjects      = ${vervangenOpenshiftObjects}\n" +
                        "**************************************************************\n"
                    }
                    else {
                        node(nodeVersion) {
                            nodeNodeName = env.NODE_NAME
                            echo "**************************************************************\n" +
                            "** Deployment parameters:\n" +
                            "** deploymentId     = ${config.deploymentId}\n" +
                            "** GroupId          = ${projectInfo.groupId}\n" +
                            "** ArtifactId       = ${projectInfo.artifactId}\n" +
                            "** version          = ${projectInfo.version}\n" +
                            "**  \n" +
                            "** projectBase      = ${projectBase}\n" +
                            "** ocdProject       = ${project}\n" +
                            "** environment      = ${params.environment}\n" +
                            "** street           = ${params.street}\n" +
                            "** lockLabel        = ${lockLabel}\n" +
                            "** vervangenOpenjdk11Image        = ${vervangenOpenjdk11Image}\n" +
                            "** vervangenOpenshiftObjects      = ${vervangenOpenshiftObjects}\n" +
                            "**************************************************************\n"
                            unstash 'ws'
                            dir(frontendName) {
                                sh '''
                                    npm config set registry https://nexus.belastingdienst.nl/nexus/repository/npm/

                                    npm config list
                                    npm ci
                                    npm run build
                                '''
                                // Onderstaand is afhankelijk van de "name": "frontend" in package.json
                                stash(name: 'frontend', includes: 'dist/frontend/**')
                            }
                        }
                    }
                }
            }
            else {
                echo "Er is geen frontend, dus geen npm nodig"
            }
            stage('Maven package') {
                if (dryRun) {
                    echo "DRYRUN: Running maven package\n"
                }
                else {
                    node(mvnVersion){
                    mvnNodeName = env.NODE_NAME
                        // als er frontendName gevuld is
                        if (frontendName?.trim()) {
                            unstash 'ws'
                            dir(frontendName) {
                                unstash 'frontend'
                            }
                        }
                        else {
                            unstash 'ws'
                        }
                        if(projectBase == "zaakadministratie1") {
                            sh(script: "${mvnCmd} package -Ps2i,sonarqube" )
                        }
                        else {
                            sh(script: "${mvnCmd}  -pl ${backendName} package -Ps2i,sonarqube" )
                        }
                        sh "rm -r ${backendName}/target/lib || true"
                        sh "mkdir -p ${backendName}/target/lib"
                        dir("${backendName}/target/lib") {
                            sh "jar xf ../${backendName}.jar"
                            sh "rm -R META-INF"
                            sh "rm -R org"
                        }
                        // het komt soms voor dat ${backendName}/target/generated-sources leeg is, terwijl sonar
                        // de directory toch nodig heeft. Omdat stash empty directoreis niet mee neemt, even een
                        // dummy file opgenomen, zodat de directory wel wordt gestashed
                        sh "touch ${backendName}/target/generated-sources/.keep"
                        if (frontendName?.trim()) {
                            stash name: 'jar', includes: "**/target/**/*,${frontendName}/src/**/*"
                        } else {
                            stash name: 'jar', includes: '**/target/**/*'
                        }
                    }
                }
            }
            stage('OWASP dependency analysis') {
                if (dryRun) {
                    echo "DRYRUN: OWASP dependency analysis\n"
                }
                else {
                    node(mvnNodeName) {
                        echo "temp dir maken, repo clonen en owasp dependency check uitvoeren"
                        sh "rm -r ${tmpSonarDir} || true"
                        sh "mkdir -p ${tmpSonarDir}"
                        dir(tmpSonarDir) {
                            checkout scm
                                //analyzeDependencies() // werkt niet in een ocd jenkins agent
                            try {
                                if (skipOWASP) {
                                    echo "Skipping OWASP dependency analysis\n"
                                    sh "mkdir -p target ; echo Skipping this file > target/SkipFile.txt"
                                } else {
                                    echo "OWASP dependency check"
                                    sh "${mvnCmd} -f pom.xml org.owasp:dependency-check-maven:aggregate \
                                        -DcveUrlBase=https://nvd.belastingdienst.nl/nvd/nvdcve-1.1-%d.json.gz \
                                        -DcveUrlModified=https://nvd.belastingdienst.nl/nvd/nvdcve-1.1-modified.json.gz \
                                        -DretireJsAnalyzerEnabled=false \
                                        -DossindexAnalyzerEnabled=false \
                                        -Dformats=HTML,JSON \
                                        -DfailBuildOnAnyVulnerability=false "
                                }
                            } catch (any) {
                                echo "Er gaat iets fout, maar het report wordt wel aangemaakt"
                            } finally {
                                publishHTML(target: [
                                        allowMissing         : true,
                                        alwaysLinkToLastBuild: true,
                                        keepAll              : true,
                                        reportDir            : 'target',
                                        reportFiles          : 'dependency-check-report.html',
                                        reportName           : 'OWASP dependency analysis'
                                ])
                            }
                            stash name: 'owasp', includes: "**/target/*"
                        }
                    }
                }
            }
            stage('Sonar scanner') {
                if (dryRun) {
                    echo "DRYRUN: Sonar analysis\n"
                }
                else {
                    if (skipSonar) {
                        echo "INFO: Skipping Sonar analysis\n"
                    } else {
                        node(sonarVersion) {
                            echo "temp dir maken, repo clonen en mvn sonar:sonar uitvoeren"
                            sh "rm -r ${tmpSonarDir} || true"
                            sh "mkdir -p ${tmpSonarDir}"
                            dir(tmpSonarDir) {
                                checkout scm
                                unstash 'jar'
                                unstash 'owasp'
                                sh "export BROWSERSLIST_IGNORE_OLD_DATA=true ; sonar-scanner  -Dproject.settings=sonar-scanner.properties -Dsonar.login=${sonarToken} -Dsonar.projectVersion=${projectInfo.version}"
                            }
                        }
                    }
                }
            }
            stage('Create Image Builder') {
                echo "Create Image Builder"
                if (dryRun) {
                    echo "DRYRUN: Running openshift.newbuild\n"
                }
                else {
                    openshift.withCluster() {
                        openshift.withProject( project ) {
                          bcExists = openshift.selector("bc", "${openshiftDeployment}").exists()
                        }
                        if(!bcExists) {
                            openshift.withCluster() {
                               openshift.withProject( project ) {
                                  openshift.newBuild("--name=${openshiftDeployment}", "-i=openjdk-11-rhel7", "--binary=true")
                               }
                            }
                        } else {
                            echo "Stage Create Image Builder niet uitgevoerd, want buildconfig ${openshiftDeployment} bestaat al."
                        }
                    }
                }
            }
            stage('Build Image') {
                        echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** version          = ${projectInfo.version}\n" +
                        "**  \n" +
                        "** projectBase      = ${projectBase}\n" +
                        "** ocdProject       = ${project}\n" +
                        "** environment      = ${params.environment}\n" +
                        "** street           = ${params.street}\n" +
                        "** lockLabel        = ${lockLabel}\n" +
                        "** vervangenOpenjdk11Image        = ${vervangenOpenjdk11Image}\n" +
                        "** vervangenOpenshiftObjects      = ${vervangenOpenshiftObjects}\n" +
                        "**************************************************************\n"
                
                if (dryRun) {
                    echo "DRYRUN: Running openshift.startbuild\n"
                }
                else {
                    node(mvnNodeName) {
                        if (vervangenOpenjdk11Image) {
                            sh (script: "oc delete is/openjdk-11-rhel7 -n ${project}" )
                            sh (script: "oc import-image openjdk-11-rhel7 --from=cir.chp.belastingdienst.nl/redhatio/openjdk/openjdk-11-rhel7:latest --confirm -n ${project}" )
                            echo "openJdk 11 image is vervangen\n"
                        }
                        script {
                            echo "Build Image"
                            unstash 'jar'
                            openshift.withCluster() {
                                openshift.withProject( project ) {
                                if(projectBase == "zaakadministratie1") {
                                    openshift.selector("bc", openshiftDeployment).startBuild("--from-file=target/${backendName}.jar", "--wait=true")
                                }
                                else {
                                    openshift.selector("bc", openshiftDeployment).startBuild("--from-file=${backendName}/target/${backendName}.jar", "--wait=true")
                                }
                                }
                            }
                            sh "oc tag ${openshiftDeployment}:latest ${openshiftDeployment}:${projectInfo.version} -n ${project}"
                        }
                    }
                }
            }
            stage('Create deployment in O') {
             echo "Create deployment in ${openshiftDeployment}"
                if (dryRun) {
                    echo "DRYRUN: Running openshift create environment if not exists\n"
                }
                else {
                    script {
                    if ( config.deploymentId == 'iva-brievenbus' ) {
                        if ( params.street == "1" ) {
                            dcs = ['adp','dwb']
                        } else {
                            dcs = ['adp' + params.street,'dwb' + params.street]
                        }
                    } else {
                        dcs = [ openshiftDeployment ]
                    }
                    for (dc in dcs) {
                        openshift.withCluster() {
                            openshift.withProject( project ) {
                                if (!openshift.selector('dc',dc).exists() || vervangenOpenshiftObjects) {
                                    echo "Create deployment in ${dc}"
                                    // ruim eerst de objecten als die zijn blijven staan
                                    if (openshift.selector('dc', dc).exists()) {
                                        openshift.selector('dc', dc).delete()
                                    }
                                    if (openshift.selector('svc', dc).exists()) {
                                        openshift.selector('svc', dc).delete()
                                    }
                                    if (openshift.selector('route', dc).exists()) {
                                        openshift.selector('route', dc).delete()
                                    }

                                    result = openshift.raw("apply", "-f openshift/${dc}-template.yaml")
                                    // dit template moet een deployment hebben van het image met tag 'latest'
                                    // er zit geen trigger in om te deployen bij image change

                                    // stel dat het trigger er toch is, deze op manual zetten, Jenkins is in control
                                    openshift.set("triggers", "dc/${dc}", "--manual")
                                } else {
                                    echo "Stage Create deployment in O niet uitgevoerd, DC bestaat al"
                                }
                            }
                        }
                    }
                    }
                }
            }
            stage('Deploy in O') { 
                echo "Deploy in ${openshiftDeployment}"
                if (dryRun) {
                    echo "DRYRUN: Running openshift deploy or rollout\n"
                }
                else {
                    if ( config.deploymentId == 'iva-brievenbus' ) {
                        if ( params.street == "1" ) {
                            dcs = ['adp','dwb']
                        } else {
                            dcs = ['adp' + params.street,'dwb' + params.street]
                        }
                    } else {
                        dcs = [ openshiftDeployment ]
                    }
                    for (dc in dcs) {
                        sh "oc rollout latest dc/${dc} -n ${project} "
                        // wachten tot alle replicas beschikbaar zijn.
                        try {
                            sh  "oc rollout status dc/${dc} -n ${project} --watch"
                        } catch(any) {
                            echo "rollout van ${dc} is fout gegaan"
                            throw any
                        }
                    }


                    // Only update other project if this build is from ont str 1
                    if (updateImageTo.size() > 0 && ( params.environment == "ont" && params.street == "1" )) {
                        echo "Updating other pods"
                        def imageId = sh (script: " oc get dc ont -o yaml -n ${project} | grep image: | grep image-registry | sed 's/^[ \t]*//' | cut -d ' ' -f 2", returnStdout: true)
                        echo "ImageId: ${imageId}"
                        def curProject = sh (script: " oc project | sed 's/^[ \t]*//' |  cut -d ' ' -f 3 | sed 's/\"//g' ", returnStdout: true)
                        echo "curProject: ${curProject}"

                        for (destination in updateImageTo) {
                            echo "Updating image of dc ${destination["deploymentConfig"]}, container ${destination["container"]} in project ${destination["project"]} -- ${destination}}"
                            sh "oc project ${destination["project"]}"
                            sh "oc set image dc ${destination["deploymentConfig"]} ${destination["container"]}=${imageId}"
                        }
                        sh "oc project ${curProject}"
                    }
                }

                if (params.run_it_test ==~ /(YES)/ && config.integrationPipeline != "") {
                    if (dryRun) {
                        echo "DRYRUN: Not running integration tests\n"
                    }
                    else {
                        echo "Running integration tests\n"
                        build job: config.integrationPipeline, parameters: [string(name: 'environment', value: params.environment), string(name: 'street', value: params.street)], propagate: false, wait: false
                    }
                } else {
                    echo "'run_it_test' set to false >> Robot tests skipped."
                }
            }
            currentBuild.result = 'SUCCESS'

        } catch (any) {
            echo "Exception: ${any}"
            currentBuild.result = 'FAILURE'
            throw any
        } finally {
            deleteDir()
            if (! dryRun) {
                try {
                    // controleer dat de agent online is
                    if (hudson.model.Hudson.instance.getNode(mvnNodeName).toComputer().isOnline()) {
                        node(mvnNodeName) {
                            echo "delete workspace ${WORKSPACE} on ${mvnNodeName} "
                            deleteDir()
                        }
                    }
                } catch (any) {
                    echo "node ${nodeNodeName} is offline en de workspace kan dus niet worden verwijderd"
                }
                if (frontendName?.trim()) {
                    try {
                        // controleer dat de agent online is
                        if (hudson.model.Hudson.instance.getNode(nodeNodeName).toComputer().isOnline()) {
                            node(nodeNodeName) {
                                echo "delete workspace ${WORKSPACE} on ${nodeNodeName} "
                                deleteDir()
                            }
                        }
                    } catch (any) {
                        echo "node ${nodeNodeName} is offline  en de workspace kan dus niet worden verwijderd"
                    }

                }
            }
            emailNotification()
        }
    }
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
        def gav = new GAV()
        def project = new XmlSlurper().parseText( pomContent )
        gav.groupId = project.groupId.toString()
        gav.artifactId = project.artifactId.toString()
        gav.version = project.version.toString()
        gav
}

class GAV {
        String groupId
        String artifactId
        String version

        def String groupIdPath() {
                groupId.replaceAll("\\.", "/")
        }
        def String versionWithoutSnapshot() {
                if (version.endsWith("-SNAPSHOT")) {
                        version.substring(0, version.length() - 9)
                }
                else {
                        version
                }
        }
        def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
