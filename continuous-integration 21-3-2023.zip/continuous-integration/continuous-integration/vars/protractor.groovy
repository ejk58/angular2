def call(String npmInstall, String reRunFailed, String projectDir, String protractorConfDir) {
    echo "Start Protractor tests run."

    echo "Npm install: " +  npmInstall
    echo "Rerun failed tests: " +  reRunFailed
    echo "Project dir: " +  projectDir
    echo "Protractor config dir: " +  protractorConfDir

    if (npmInstall == 'YES' && reRunFailed == 'YES') {
        wrap([$class: "Xvfb", autoDisplayName: true, screen: '1366x768x24']) {
            sh """
            cd $projectDir;
            npm install;
            node ./node_modules/protractor-flake/bin/protractor-flake --parser=./my-custom-parser.js --max-attempts=3 --color=yellow -- $protractorConfDir/protractor.conf.js
            """
        }
    } else if (npmInstall == 'NO' && reRunFailed == 'YES') {
        wrap([$class: "Xvfb", autoDisplayName: true, screen: '1366x768x24']) {
            sh """
            cd $projectDir;
            node ./node_modules/protractor-flake/bin/protractor-flake --parser=./my-custom-parser.js --max-attempts=3 --color=yellow -- $protractorConfDir/protractor.conf.js
            """
        }
    } else if (npmInstall == 'YES' && reRunFailed == 'NO') {
        wrap([$class: "Xvfb", autoDisplayName: true, screen: '1366x768x24']) {
            sh """
            cd $projectDir;
            npm install;
            node ./node_modules/protractor/bin/protractor $protractorConfDir/protractor.conf.js
            """
        }
    } else if (npmInstall == 'NO' && reRunFailed == 'NO') {
        wrap([$class: "Xvfb", autoDisplayName: true, screen: '1366x768x24']) {
            sh """
            cd $projectDir;
            node ./node_modules/protractor/bin/protractor $protractorConfDir/protractor.conf.js
            """
        }
    }

}