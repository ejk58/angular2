def call(body) {

        def config = [:]
        body.resolveStrategy = Closure.DELEGATE_FIRST
        body.delegate = config
        body()
	def lockLabel = 'XXXX'

        node {
	    	deleteDir()

            try {
                stage ('Clone') {
					
		    checkout scm
					
                    if (config.pipelineTrigger != null){
                            pipelineTrigger = pipelineTriggers(config.pipelineTrigger)
                    } else {
                            pipelineTrigger = pipelineTriggers([pollSCM('')])
                    }

                    properties([
                        parameters([
                            choice(name: 'environment', choices: 'ont\ntst\nacc', description: 'Environment to run this script'),
                            choice(name: 'street', choices: 'str11\nstr12\nstr13\nstr14', description: 'Which street of cell?'),
                            choice(name: 'reRunFailed', choices: 'NO\nYES', description: 'Rerun failed test suites only?')
                            
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTrigger
		            ])
                }

                stage ("Integration"){
		    lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
		    lock(lockLabel) {
			def reRun = false
			try{
			    if (config.robotTestPath != null && params.reRunFailed == 'NO') {
				robotLocal(params.street + "." + params.environment, config.robotExcludes, config.robotIncludes, config.robotNonCriticals, config.robotTestPath, config.pabotProcesses, config.pabotIncludes)
			    }
			    else {
				echo "Robot tests skipped."
			    }
			}catch(e){
			    reRun = true
			}  

			if (reRun || params.reRunFailed == 'YES' ) {
			    echo "Rerun started"
			    robotReRun(params.street + "." + params.environment, config.robotExcludes, config.robotIncludes, config.robotNonCriticals, config.robotTestPath)
			}
		    }
                }

                currentBuild.result = 'SUCCESS'

            } catch (e) {
                currentBuild.result = 'FAILURE'
                throw e
	        } finally {
                if (config.robotTestPath != null){ 
		            robotLogPublication()
                }
		        emailNotification()
	        }
        }
}
