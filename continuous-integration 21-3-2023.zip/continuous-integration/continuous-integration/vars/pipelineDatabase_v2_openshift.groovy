def call(body) {

	def config = [:]
	body.resolveStrategy = Closure.DELEGATE_FIRST
	body.delegate = config
	body()

	def lockLabel = 'XXXX'

	def dryRun = false
    def contextIsEnvPlusStreet = false
    if (config.contextIsEnvPlusStreet != null) {
		contextIsEnvPlusStreet = config.contextIsEnvPlusStreet
    }
	def dropDatabaseChoices = "YES\nNO"
	if (config.dropDatabaseChoices != null) {
		dropDatabaseChoices = config.dropDatabaseChoices
	}

	node("maven35-openjdk11") {
		deleteDir()

		try {
			stage ('Clone') {
				checkout scm
				
				properties([
					parameters([
						choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
						choice(name: 'street', description: 'Which street?', choices: config.streetChoices),
						choice(name: 'dropDatabase', choices: dropDatabaseChoices, description: 'Drop the database before updating?'),
						choice(name: 'buildApps', choices: 'YES\nNO', description: 'Want to trigger pipelines of related applications?')
					]),
					disableConcurrentBuilds(),
					pipelineTriggers([pollSCM('')])
				])
			}

			projectInfo = getInfoFromPom(readFile("pom.xml"))
			context = params.environment.toUpperCase()
			if (contextIsEnvPlusStreet) {
				context = paramsCopy.environment.toLowerCase() + "-" + paramsCopy.street.toLowerCase()
			}
			schemaName = ApplicationConfiguration.getSchemaName(config.deploymentId, context, params.street)
			stage = ApplicationConfiguration.getStageId(params.environment)
			dbUrl = ApplicationConfiguration.getDbUrl(config.deploymentId, context)
			dbUserCredentials = ApplicationConfiguration.getJenkinsDbCredentials(config.deploymentId, context)
			lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street

			echo "**************************************************************\n" +
				"** Deployment parameters:\n" +
				"** deploymentId     = ${config.deploymentId}\n" +
				"** GroupId          = ${projectInfo.groupId}\n" +
				"** ArtifactId       = ${projectInfo.artifactId}\n" +
				"** Version          = ${projectInfo.version}\n" +
				"**  \n" +
				"** environment      = ${params.environment}\n" +
				"** street           = ${params.street}\n" +
				"** stage            = ${stage}\n" +
				"**  \n" +
				"** dbUrl            = ${dbUrl}\n" +
				"** context          = ${context}\n" +
				"** dbSchema         = ${schemaName}\n" +
				"** credentials      = ${dbUserCredentials}\n" +
				"** drop database    = ${params.dropDatabase}\n" +
				"**************************************************************"

			stage('Update Database') {
				lock(lockLabel) {
					if (dbUrl.substring(5,13) == "teradata") {
						if (params.environment ==~ /(?i)(ont|tst)/ && params.dropDatabase ==~ /(YES)/) {
							liquibaseDropUpdateMasterTD(config.gitUrl, params.gitBranchDb, config.dbUser, dbUrl + "DATABASE=" + params.defaultSchemaName, params.defaultSchemaName, config.changelogFile, context)
						}
						liquibaseUpdateDevelop(config.gitUrl, params.gitBranchDb, config.dbUser, dbUrl + "DATABASE=" + params.defaultSchemaName, params.defaultSchemaName, config.changelogFile, context)
					} else {
						withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: dbUserCredentials, passwordVariable: 'DB_WW', usernameVariable: 'DB_USER']]) {
							mvnArguments = "-PdeployDB -DversionToDeploy=${projectInfo.version} -Dliquibase.url=${dbUrl} -Dliquibase.username=${env.DB_USER} -Dliquibase.contexts=${context} -Dliquibase.defaultSchemaName=${schemaName} "
							if (params.environment ==~ /(?i)(ont|tst)/ && params.dropDatabase ==~ /(YES)/) {
								if (dryRun) {
									echo "DRYRUN: Executing dropAll on database and updating DB from master branch using maven with arguments:\n" +
										"- mvnArguments: ${mvnArguments}\n"
									echo "**************************************************************"
								}
								else {
									mvnArguments = " ${mvnArguments}"
									sh "mvn install liquibase:dropAll ${mvnArguments} -Dliquibase.password=${env.DB_WW}"
									// Copy pom.xml in case this is not present in the master branch
									sh "cp pom.xml /tmp/pom.xml.${projectInfo.artifactId}.develop"
									sh "cp assembly.xml /tmp/assembly.xml.${projectInfo.artifactId}.develop"
									sh "git checkout master"
									def workDir = sh(script: 'pwd', returnStdout: true).trim()
									def workDirectoryFile = new File(workDir)
									def liquibaseDir = new File(workDirectoryFile, 'Liquibase')
									if ( ! liquibaseDir.exists() || liquibaseDir.listFiles().length == 0) {
										// Switching back to develop when master doesn't contain any data.
										echo "Master branch seems to be empty, switching back to develop"
										sh "git checkout develop"
									} else {
										// Master contains data. Using it.
										echo "Master branch contains data. Using it."
									}
									if (! new File(workDirectoryFile, 'pom.xml').exists()) {
										// Copy develop pom.xml to working directory in case this was not present in the master branch
										sh "cp /tmp/pom.xml.${projectInfo.artifactId}.develop ./pom.xml"
										sh "cp /tmp/assembly.xml.${projectInfo.artifactId}.develop ./assembly.xml"
									}
									sh "mvn install liquibase:update liquibase:tag ${mvnArguments} -Dliquibase.password=${env.DB_WW}"
									sh "git reset --hard"
									sh "git clean -fd"
									sh "git checkout develop"
								}
							}
							if (dryRun) {
								echo "DRYRUN: Deploying database from develop branch using maven with arguments:\n" +
									"- mvnArguments: ${mvnArguments}\n"
								echo "**************************************************************"
							}
							else {
								sh "mvn install liquibase:update liquibase:tag ${mvnArguments} -Dliquibase.password=${env.DB_WW}"
							}
						}	
					}
				}
			}
			stage('Execute Code Pipelines') {
				if (params.buildApps ==~ /(YES)/ && config.codePipeline.size() > 0) {
					def stepsForParallel = config.codePipeline.collectEntries {
						["${it}": {build job: it, parameters: [string(name: 'environment', value: params.environment), string(name: 'street', value: params.street)], propagate: false, wait: false }]
					}
					parallel stepsForParallel
				}
				else {
					echo "Skipped execution of code pipeline."
				}

			}       
			currentBuild.result = 'SUCCESS'
		} catch (any) {
			currentBuild.result = 'FAILURE'
			throw any
		} finally {
            deleteDir()
            node("maven35-openjdk11") {
                echo "delete workspace ${WORKSPACE} on maven35-openjdk11 "
                deleteDir()
            }
			emailNotification()
		}
	}
}

@NonCPS
def int cntFilesInDirectory(String dir) {
	def fileCnt=0
	new File(dir).eachFile(FileType.FILES) {
		file -> fileCnt++;
	}
	return fileCnt
}
@NonCPS
def GAV getInfoFromPom(String pomContent) {
	def gav = new GAV()
	def project = new XmlSlurper().parseText( pomContent )
	gav.groupId = project.groupId.toString()
	gav.artifactId = project.artifactId.toString()
	gav.version = project.version.toString()
	gav
}

class GAV {
	String groupId
	String artifactId
	String version

	def String groupIdPath() {
		groupId.replaceAll("\\.", "/")
	}
	def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
