def call(String jiraProjectName, String jiraRelease, String jiraServerUrl ) {
    echo "project ${jiraProjectName} "
    withCredentials([string(credentialsId: 'JIRA_Personal_Access_Token', variable: 'JIRA_PERSONAL_ACCESS_TOKEN')]) {
      script="releaseJira.py"
      def yourScriptAsaString = libraryResource "../resources/${script}"
      writeFile file: "${script}", text: yourScriptAsaString
      sh "python3 -u ${script} ${jiraProjectName} '${jiraRelease}' ${JIRA_PERSONAL_ACCESS_TOKEN} ${jiraServerUrl}"
    }
}
