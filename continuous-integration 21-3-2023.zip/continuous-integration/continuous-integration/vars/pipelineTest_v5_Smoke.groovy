def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
	def lockLabel = 'XXXX'

    def robotExtraVariables = ''
    if (config.robotExtraVariables != null) {
        robotExtraVariables = config.robotExtraVariables
    }
    
    def robotDir = ''
    if (config.robotDir != null) {
        robotDir = config.robotDir
    }
	
    
    node {
	
        try {
            stage ('Clone') {
                cleanWs()
                checkout scm
                
                if (config.pipelineTrigger != null){
                        pipelineTrigger = config.pipelineTrigger
                } else {
                        pipelineTrigger = [pollSCM('')]
                }

                properties([
                    parameters([
                        choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
						choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                        choice(name: 'reRunFailed', choices: 'NO\nYES', description: 'Rerun failed test suites only?'),
						choice(name: 'runSmoke', choices: 'YES\nNO', description: 'Run Smoke test?')
                        
                    ]),
                    disableConcurrentBuilds(),
                    pipelineTriggers(pipelineTrigger)
					
                ])
				currentBuild.displayName = "#" + BUILD_NUMBER + " str:" + street.toUpperCase() + " env:" + environment.toUpperCase()
				
            }
			
		 stage ("Smoke Test"){
            if ( params.street == "1" ) {
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_str1" + params.street
            } 
            else {
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
            }
            
            lock(lockLabel) {
                def runSmoke = true
                def reRun = false
                def environment = params.street + "." + params.environment
                def robotLock = "Lock Robot ${JOB_NAME} ${environment}"
                
                    if (config.robotTestPath != null && params.runSmoke == 'YES') {
                        // rbtLocal(params.street + "." + params.environment, config.robotArguments, config.robotTestPath)
                        lock(robotLock) {
                            echo "Going to run robot tests for ${JOB_NAME}"
                            wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                                sh "${robotDir}robot -o outputSmoke.xml ${config.robotNonCriticals} -v BROWSER:headlesschrome -v GRID_URL:selenium-hub-wd-selenium-grid-4.apps.cn01.chp.belastingdienst.nl --include SMOKE -v ENVIRONMENT:${environment} ${config.robotTestPath}"
                             }
                        }
                    }
                else {
                        echo "Robot Smoke tests skipped."
                    }
                }
            }
			
			currentBuild.result = 'SUCCESS'
		} catch (e) {
		
			if (config.robotTestPath != null && params.runSmoke == 'YES'){ 
                step([$class              : 'RobotPublisher',
                    disableArchiveOutput: false,
                    logFileName         : 'logSmoke.html',
                    otherFiles          : '',
                    outputFileName      : '*outputSmoke.xml',
                    outputPath          : '.',
                    passThreshold       : 100,
                    reportFileName      : '*reportSmoke.html',
                    unstableThreshold   : 0]);
            }
            currentBuild.result = 'FAILURE'
            emailNotification()
			currentBuild.displayName = "${currentBuild.displayName} Smoke Fail"	
			throw e
			
		} 
		try {
		stage ("Backend Test"){
            if ( params.street == "1" ) {
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_str1" + params.street
            } 
            else {
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
            }
            
            lock(lockLabel) {
                def reRun = false
                def environment = params.street + "." + params.environment
                def robotLock = "Lock Robot ${JOB_NAME} ${environment}"
                try{
                    if (config.robotTestPath != null && params.reRunFailed == 'NO') {
                        // rbtLocal(params.street + "." + params.environment, config.robotArguments, config.robotTestPath)
                        lock(robotLock) {
                            echo "Going to run robot tests for ${JOB_NAME}"
                            wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                                sh "${robotDir}robot --output outputBackend.xml ${config.robotNonCriticals} -v BROWSER:headlesschrome -v GRID_URL:selenium-hub-wd-selenium-grid-4.apps.cn01.chp.belastingdienst.nl --include BACKEND -v ENVIRONMENT:${environment} ${config.robotTestPath}"
                            }
                        }
                    }
                    else {
                        echo "Backend tests skipped."
                    }
                }catch(e){
                    reRun = true
                }  
				
                if (reRun || params.reRunFailed == 'YES' ) {
                    echo "Rerun started"
//                    rbtReRun(params.street + "." + params.environment, config.robotExcludes, config.robotIncludes, config.robotNonCriticals, config.robotTestPath)
                    def env = (params.environment == "acc") ? "ACC" : "DEV" 

                    lock(robotLock) {
                        echo "Going to run robot tests for ${JOB_NAME}"
                        wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                            sh """
                            set +e \\
                            ;${robotDir}robot ${config.robotNonCriticals} ${config.robotArguments} --rerunfailed outputBackend.xml --runemptysuite --output rerun.xml -v ENVIRONMENT:${environment} -v ENV:${env} ${config.robotTestPath} \\
                            ;${robotDir}rebot --processemptysuite ${config.robotNonCriticals} --output outputBackend.xml --merge outputBackend.xml rerun.xml 
                            """
                        }
                    }

                }
            }
        }
			currentBuild.result = 'SUCCESS'

        }  finally {
			 step([$class              : 'RobotPublisher',
                    disableArchiveOutput: false,
                    logFileName         : 'log.html',
                    otherFiles          : 'selenium-screenshot-*.png,visualReport.html,visual_images/**/*.png',
                    outputFileName      : '*outputBackend.xml',
                    outputPath          : '.',
                    passThreshold       : 20,
                    reportFileName      : '*report.html',
                    unstableThreshold   : 95]);
        }
		catch (e) {
                   
			currentBuild.result = 'FAILURE'
			currentBuild.displayName = "${currentBuild.displayName} Backend Fail"
			emailNotification()
			throw e
        }
	    
		
		try {
		stage ("Frontend Test"){
            if ( params.street == "1" ) {
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_str1" + params.street
            } 
            else {
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
            }
            
            lock(lockLabel) {
                def reRun = false
                def environment = params.street + "." + params.environment
                def robotLock = "Lock Robot ${JOB_NAME} ${environment}"
                try{
                    if (config.robotTestPath != null && params.reRunFailed == 'NO') {
                        // rbtLocal(params.street + "." + params.environment, config.robotArguments, config.robotTestPath)
                        lock(robotLock) {
                            echo "Going to run robot tests for ${JOB_NAME}"
                            wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                                 sh "${robotDir}robot --output outputFrontend.xml ${config.robotNonCriticals} -v BROWSER:headlesschrome -v GRID_URL:selenium-hub-wd-selenium-grid-4.apps.cn01.chp.belastingdienst.nl --include FRONTEND -v ENVIRONMENT:${environment} ${config.robotTestPath}"
                            }
                        }
                    }
                    else {
                        echo "Frontend tests skipped."
                    }
                }catch(e){
                    reRun = true
                }  
				
                if (reRun || params.reRunFailed == 'YES' ) {
                    echo "Rerun started"
//                    rbtReRun(params.street + "." + params.environment, config.robotExcludes, config.robotIncludes, config.robotNonCriticals, config.robotTestPath)
                    def env = (params.environment == "acc") ? "ACC" : "DEV" 

                    lock(robotLock) {
                        echo "Going to run robot tests for ${JOB_NAME}"
                        wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                            sh """
                            set +e \\
                            ;${robotDir}robot ${config.robotNonCriticals} ${config.robotArguments} --rerunfailed outputFrontend.xml --runemptysuite --output rerun.xml -v ENVIRONMENT:${environment} -v ENV:${env} ${config.robotTestPath} \\
                            ;${robotDir}rebot --processemptysuite ${config.robotNonCriticals} --output outputFrontend.xml --merge outputFrontend.xml rerun.xml 
                            """
                        }
                    }

                }
            }
        }
			currentBuild.result = 'SUCCESS'

        } catch (e) {
            currentBuild.result = 'FAILURE'
			currentBuild.displayName = "${currentBuild.displayName} Frontend Fail"	
            throw e
        } finally {
		wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
						  sh "${robotDir}rebot --output output.xml --merge output*.xml"
						  	
						}
			if (config.robotTestPath != null){ 
                step([$class              : 'RobotPublisher',
                    disableArchiveOutput: false,
                    logFileName         : 'log.html',
                    otherFiles          : 'selenium-screenshot-*.png,visualReport.html,visual_images/**/*.png',
                    outputFileName      : '*output.xml',
                    outputPath          : '.',
                    passThreshold       : 100,
                    reportFileName      : '*report.html',
                    unstableThreshold   : 0]);
            }
            emailNotification()
			
        }
    }
}