def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
	def lockLabel = 'XXXX'
    
    def robotDir = ''
    if (config.robotDir != null) {
        robotDir = config.robotDir
    }
    environment {
        ENVIRONMENT =    ''
        RERUN =          'false'
        ROBOTARGUMENTS = ''
        ROBOTLOCK =      ''
        ROBOTRUNNER =    ''
        PABOTARGUMENTS = ''
        PABOTPROCESSES = ''
        PREVIOUSOUTPUT = 'false'
        PREVIOUSXML = ''
    }
    node {
        try {
            stage ('Clone') {
                cleanWs()
                checkout scm
                
                if (config.pipelineTrigger != null){
                        pipelineTrigger = config.pipelineTrigger
                } else {
                        pipelineTrigger = [pollSCM('')]
                }

                properties([
                    parameters([
                        choice(name: 'environment', choices: "ont\ntst\nacc", description: 'Environment to run this script'),
                        choice(name: 'street', choices: "str11\nstr12\nstr13", description: 'Which street?'),
                        choice(name: 'reRunFailed', choices: 'NO\nYES', description: 'Rerun failed test suites only?'),
                        choice(name: 'robotRunner', choices:'pabot\nrobot', description: 'Use which robot script?'),
                        choice(name: 'splitlevel', choices: 'SUITE\nTEST', description: 'If parallel, at which level?'),
                        string(name: 'robotArguments', defaultValue:'', description: 'Do you want to add extra robot options e.g. -i TAG or --logname LOGNAME'),
                        string(name: 'pabotProcesses', defaultValue:'8', description: 'How may parallel threads do you want running'),
                        string(name: 'pabotArguments', defaultValue:'', description: 'Do you want to add extra pabot options e.g. --argumentfile1 path_to_file1 --argumentfile2 path_to_file2'),
                        string(name: 'previousOutput', defaultValue:'', description: 'Add a previous output xml name to your repository and name it here (e.g. "previous_output.xml") if you want pabot to optimize results based on the xml')
                        ]),
                        disableConcurrentBuilds(),
                        pipelineTriggers(pipelineTrigger)
                    ])
                }
                stage("Previous build artifacts") {
                    if (currentBuild.previousBuild) {
                        try {
                            def username='mobem00'
                            def api_token='1123b6dc461051215211d0b46c617c7b6f'
                            echo "${env.JENKINS_URL}job/${env.JOB_NAME}/$currentBuild.previousBuild.number/robot/report/output.xml"
                            echo "$WORKSPACE/previousOutput.xml"
                            sh "curl -u $username:$api_token -k ${env.JENKINS_URL}job/${env.JOB_NAME}/$currentBuild.previousBuild.number/robot/report/output.xml -o $WORKSPACE/previousOutput.xml"
                            env.PREVIOUSOUTPUT = 'true'
                        } catch(err) {
                            env.PREVIOUSOUTPUT = 'false'
                        }
                    }
                }
            stage ("Test"){
                if ( params.street == "1" ) {
                    lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_str1" + params.street
                } 
                else {
                    lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
                }
            
            lock(lockLabel) {
                env.ROBOTLOCK = "Lock Robot ${JOB_NAME} ${env.ENVIRONMENT}"
                env.ENVIRONMENT = params.street + "." + params.environment
                // Select Robot script to run
                if (config.robotRunner != null) {
                    env.ROBOTRUNNER=config.robotRunner
                }
                else {            
                    env.ROBOTRUNNER=params.robotRunner
                }
                // Set Robot Arguments
                if (params.robotArguments != "") {
                    env.ROBOTARGUMENTS = params.robotArguments
                }
                else {            
                    env.ROBOTARGUMENTS=config.robotArguments
                }
                // Set Pabot number of processes
                if (params.pabotProcesses != "") {
                    env.PABOTPROCESSES=params.pabotProcesses
                }
                else {            
                    env.PABOTPROCESSES=config.pabotProcesses
                }
                // Set Pabot Arguments, base config is with 8 arguments
                if (params.pabotArguments != "") {
                    env.PABOTARGUMENTS = params.pabotArguments
                }
                else if (params.robotRunner == "pabot" && params.splitlevel == "TEST") {
                    env.PABOTARGUMENTS = "--processes ${env.PABOTPROCESSES} --testlevelsplit --pabotlib --artifactsinsubfolders --command ${robotDir}robot --end-command"
                }
                else if (params.robotRunner == "pabot" && params.splitlevel == "SUITE") {
                    env.PABOTARGUMENTS = "--processes ${env.PABOTPROCESSES} --pabotlib --artifactsinsubfolders --command ${robotDir}robot --end-command"
                }
                else if (config.pabotArguments != null){
                    env.PABOTARGUMENTS = config.pabotArguments
                }
                else {
                    env.PABOTARGUMENTS = ""
                }
                if (params.robotRunner == "pabot" && config.previousOutput != null) {
                    env.PREVIOUSXML=" --suitesfrom ${config.previousOutput}"
                }
                else if (params.robotRunner == "pabot" && params.previousOutput != "") {
                    env.PREVIOUSXML = " --suitesfrom ${params.previousOutput}"
                }
                else if (params.robotRunner == "pabot" && params.previousOutput == ""){
                    if (env.PREVIOUSOUTPUT) {
                        env.PREVIOUSXML = " --suitesfrom previousOutput.xml"
                    }
                }
                else {
                    env.PREVIOUSXML = ""
                }
                // Start run
                try{
                    if (config.robotTestPath != null && params.reRunFailed == 'NO') {
                        // rbtLocal(params.street + "." + params.environment, config.robotArguments, config.robotTestPath)
                        lock(env.ROBOTLOCK) {
                            echo "Going to run robot tests for ${JOB_NAME}"
                            echo "Going to try running robot tests with command: ${robotDir}${env.ROBOTRUNNER} ${env.PABOTARGUMENTS}${env.PREVIOUSXML} ${config.robotNonCriticals} ${env.ROBOTARGUMENTS} -v ENVIRONMENT:${env.ENVIRONMENT} -l original_log.html  ${config.robotTestPath}"
                            wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                                sh "${robotDir}${env.ROBOTRUNNER} ${env.PABOTARGUMENTS}${env.PREVIOUSXML} ${config.robotNonCriticals} ${env.ROBOTARGUMENTS} -v ENVIRONMENT:${env.ENVIRONMENT} -l original_log.html  ${config.robotTestPath}"
                            }
                        }
                    }
                    else {
                        echo "Robot tests skipped."
                    }
                }catch(e){
                    env.RERUN = true
                }  
            }
        }
        stage ("Rerun"){
            lock(lockLabel) {
                if (env.RERUN || params.reRunFailed == 'YES' ) {
                    echo "Rerun started"
//                    rbtReRun(params.street + "." + params.environment, config.robotExcludes, config.robotIncludes, config.robotNonCriticals, config.robotTestPath)
                    def robot_environment = (params.environment == "acc") ? "ACC" : "DEV" 

                    lock(env.ROBOTLOCK) {
                        echo "Going to run robot tests for ${JOB_NAME}"
                        echo "Going to try running robot tests with command: ${robotDir}${env.ROBOTRUNNER} ${env.PABOTARGUMENTS} ${config.robotNonCriticals} ${env.ROBOTARGUMENTS} --rerunfailed output.xml --runemptysuite --output rerun_output.xml -v ENVIRONMENT:${env.ENVIRONMENT} -v ENV:${environment} ${config.robotTestPath}"
                        wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
                            sh """
                            set +e \\
                            ;${robotDir}${env.ROBOTRUNNER} ${env.PABOTARGUMENTS} ${config.robotNonCriticals} ${env.ROBOTARGUMENTS} --rerunfailed output.xml --runemptysuite --output rerun_output.xml -v ENVIRONMENT:${env.ENVIRONMENT} -v ENV:${robot_environment} ${config.robotTestPath} \\
                            ;${robotDir}rebot --processemptysuite --output output.xml --merge output.xml rerun_output.xml 
                            """
                        }
                    }

                }
            }
        }
        // stage ("Metrics"){
        //     lock(lockLabel) {
        //         lock(env.ROBOTLOCK) {
        //             echo "Going to collect robot metrics for ${JOB_NAME}"
        //             wrap([$class: "Xvfb", autoDisplayName: true, screen: '1920x1080x24']) {
        //                     sh """
        //                     set +e \\
        //                     ;${robotDir}robotmetrics -M metrics-report.html
        //                     """
        //             }
        //         }

        //         }
        // }
        currentBuild.result = 'SUCCESS'

        } catch (e) {
            currentBuild.result = 'FAILURE'
            throw e
        } finally {
            if ("cookies" != null){ 
                step([$class            : 'RobotPublisher',
                    disableArchiveOutput: false,
                    logFileName         : '*log.html',
                    otherFiles          : 'browser/screenshot/*.png,*selenium-screenshot-*.png,visualReport.html,visual_images/**/*.png,pabot_results, metrics-report.html',
                    outputFileName      : 'output.xml',
                    outputPath          : '.',
                    passThreshold       : 100,
                    reportFileName      : '*report.html',
                    unstableThreshold   : 0]);
            }
            emailNotification()
        }
    }
}
