def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
	def lockLabel = 'XXXX'

    def robotDir = ''
    if (config.robotDir != null) {
        robotDir = config.robotDir
    }

    def robotNode = "robot4"
    if (config.robotNode != null) {
        robotNode = config.robotNode
    }

    node(robotNode) {

        try {
            stage ('Clone') {
                
                checkout scm
                    
                if (config.pipelineTrigger != null){
                        pipelineTrigger = pipelineTriggers(config.pipelineTrigger)
                } else {
                        pipelineTrigger = pipelineTriggers([pollSCM('')])
                }

                properties([
                    parameters([
                        choice(name: 'environment', choices: 'ont\ntst\nacc', description: 'Environment to run this script'),
                        choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                        choice(name: 'useGrid', choices: 'YES\nNO', description: 'Use selenium grid?'),
                        choice(name: 'reRunFailed', choices: 'NO\nYES', description: 'Rerun failed test suites only?')
                        
                    ]),
                    disableConcurrentBuilds(),
                    pipelineTrigger
                ])
            }

            stage ("Integration"){
                lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
                lock(lockLabel) {
                def reRun = false
                def useGridCommand = ""
                if (params.useGrid == 'YES') {
                    useGridCommand="-v BROWSER:headlesschrome -v GRID_URL:selenium-hub-wd-selenium-grid-4.apps.cn01.chp.belastingdienst.nl"
                }
                try{
                    if (config.robotTestPath != null && params.reRunFailed == 'NO') {
                        sh  "${robotDir}robot ${config.robotNonCriticals} ${config.robotArguments} ${useGridCommand} -v ENVIRONMENT:${street}.${environment}  ${config.robotTestPath} "
                    }
                    else {
                    echo "Robot tests skipped."
                    }
                }catch(e){
                    reRun = true
                }  

                if (reRun || params.reRunFailed == 'YES' ) {
                    echo "Rerun started"
                    sh """
                            set +e \\
                            ;${robotDir}robot ${config.robotNonCriticals} ${config.robotArguments} ${useGridCommand} --rerunfailed output.xml --runemptysuite --output rerun.xml -v ENVIRONMENT:${street}.${environment} -v ENV:${env} ${config.robotTestPath} \\
                            ;${robotDir}rebot --processemptysuite --output output.xml --merge output.xml rerun.xml 
                            """
                    }
                }
            }

            currentBuild.result = 'SUCCESS'

        } catch (e) {
            currentBuild.result = 'FAILURE'
            throw e
        } finally {
            if (config.robotTestPath != null){ 
                step([$class              : 'RobotPublisher',
                    disableArchiveOutput: false,
                    logFileName         : 'log.html',
                    otherFiles          : 'selenium-screenshot-*.png,visualReport.html,visual_images/**/*.png',
                    outputFileName      : '*output.xml',
                    outputPath          : '.',
                    passThreshold       : 100,
                    reportFileName      : '*report.html',
                    unstableThreshold   : 0]);
                // robotLogPublication()
            }
            emailNotification()
        }
    }
}
