def call(String environment, String excludes, String includes, String nonCriticals, String testPath) {
    def robotLock = "Lock Robot ${JOB_NAME} ${environment}"

    def robotExcludes = defineInOrExcludes(excludes, "exclude")
    def robotIncludes = defineInOrExcludes(includes, "include")
	def robotNonCriticals = defineInOrExcludes(nonCriticals, "noncritical")
	def env = (environment[-3..-1] == "acc") ? "ACC" : "DEV" 

    lock(robotLock) {
        echo "Going to run robot tests for ${JOB_NAME}"

        wrap([$class: "Xvfb", autoDisplayName: true]) {
            sh """
            set +e \\
            ;robot ${robotIncludes} ${robotExcludes} ${robotNonCriticals} --rerunfailedsuites output.xml --runemptysuite --output rerun.xml -v ENVIRONMENT:${environment} -v ENV:${env} ${testPath} \\
            ;rebot --processemptysuite ${robotNonCriticals} --output output.xml --merge output.xml rerun.xml 
            """
        }
    }
}