def call(body) {

    def config = [:]
    def approver = ""

    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def nexusUrlPrefix = ApplicationConfiguration.getNexusUrlPrefix()
    def nexusUrl = ApplicationConfiguration.getNexusUrl()
    def clusterSyncDelay = 0
    def stageDeployMavenArgs = ''

    def dryRun = false
    if (config.dryRun != null) {
		dryRun = config.dryRun
    }
    
	def baseDir = '.'
    if (config.baseDirectory != null) {
		baseDir = config.baseDirectory
    }

	def channel=ApplicationConfiguration.getMMChannel(config.deploymentId, params.environment)

	// Start deep copy van params omdat params unmodifyable is
    def paramsCopy = [UpdateParametersOnly: params.UpdateParametersOnly
					, environment: params.environment
	//				, street: params.street
	//				, run_it_test: params.run_it_test
					, package: params.package
					, application_version: params.application_version
					, version: params.version
					]

	// End deep copy van params omdat params unmodifyable is

    node {
	deleteDir()

	try {
	    stage ('Clone') {
			checkout scm

			properties([
				parameters([
					choice(name: 'package', description: 'The package to be deployed', choices: config.packageChoices),
					choice(name: 'application_version', description: 'The version of the application to be deployed', choices: config.applicationVersionChoices),
					choice(name: 'environment', description: 'Environment to run this script', choices: config.environmentChoices),
	//				choice(name: 'street', description: 'Which street?', choices: config.streetChoices),
	//				choice(name: 'run_it_test', description: 'Run the integration tests?', choices: 'NO\nYES'),
                    choice(name: 'UpdateParametersOnly', description: 'Run script only to update the parameters?', choices: 'NO\nYES'),
				]),
				disableConcurrentBuilds()
			])
            onlyParamsUpdate = paramsCopy.UpdateParametersOnly == "YES"
            if (onlyParamsUpdate) {
                    echo "Only updating the parameters."
                }
            else {
                if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                    paramsCopy.run_it_test = 'NO'
                    approver = input(id: 'EnterApprover', message: 'Enter user name approver and proceed or abort?', parameters: [
                        [$class: 'StringParameterDefinition', description: 'Approver', name: 'name'],
                    ])
                    if (approver.isEmpty() ) {
                        throw new Exception("Deployment to PRD aborted (Invalid approver).")
                    }
                }
            }
		}

	    stage('Deploy') {
			dir(baseDir) {
                if (! onlyParamsUpdate) {
                    projectInfo = getInfoFromPom(readFile("pom.xml"))
                    if (paramsCopy.package != null && ! paramsCopy.package.isEmpty()) {
                        projectInfo.artifactId = paramsCopy.package
                    }
                    if (paramsCopy.application_version != null && ! paramsCopy.application_version.isEmpty()) {
                        projectInfo.version = paramsCopy.application_version
                    }
                    context = paramsCopy.environment.toUpperCase()

                    echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** Version          = ${projectInfo.version}\n" +
                        "**  \n" +
                        "** environment      = ${paramsCopy.environment}\n" +
                     //   "** street           = ${paramsCopy.street}\n" +
                        "**  \n" +
                        "**  \n" +
                        "**************************************************************"
                    if ( paramsCopy.environment.toUpperCase() == "PRD" ) {
                        echo "**************************************************************\n" +
                        "** Approver	 = ${approver}\n" +
                        "**************************************************************"
                    }
                    
                    if ( paramsCopy.environment.toUpperCase() == "TST" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                        message = "Start uitrol van ${config.deploymentId} versie ${projectInfo.version} op ${paramsCopy.environment} - ${paramsCopy.street}"
                        if (channel?.trim()) {
                        mattermostSend channel: "${channel}", message: "${message}"
                        }
                    }
                    
                    if (dryRun) {
                        echo "DRYRUN: Deploying database using maven with arguments:\n" +
                            "- mvnArguments            : ${mvnArguments}\n"
                        echo "**************************************************************"
                    }
                    else {
                        echo "./execAnsible.sh ${paramsCopy.environment} ${projectInfo.version} ${config.assemblyId}"    
                        def scriptContent = libraryResource "../resources/execAnsible.sh"
                        writeFile file: "execAnsible.sh", text: scriptContent
                        sh "chmod +x execAnsible.sh && ./execAnsible.sh ${paramsCopy.environment} ${projectInfo.version} ${config.assemblyId}"
                    }
                }
			}
		}
		/* stage('Publish') {
			if (dryRun) {
				echo "Publishing deployed version to MatterMost."
			} else {
                if (! onlyParamsUpdate) {
                    if ( paramsCopy.environment.toUpperCase() == "TST" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                        // if the channel is defined in ApplicationConfiguration
                        if (channel?.trim()) {
                        message = "Einde uitrol van ${config.deploymentId} versie ${projectInfo.version} op ${paramsCopy.environment} - ${paramsCopy.street}"
                        mattermostSend channel: "${channel}", message: "${message}"
                        }
                    }
                    if ( paramsCopy.environment.toUpperCase() == "PRD" ||  paramsCopy.environment.toUpperCase() == "ACC" ) {
                        message = "${config.deploymentId} versie ${projectInfo.version} uitgerold op ${paramsCopy.environment} - ${paramsCopy.street}"
                        mattermostSend channel: '#maatwerk-deployment', message: "${message}"
                    }
                }
			}
		}
		stage('Start test') {
                if (! onlyParamsUpdate) {
                    if (paramsCopy.run_it_test ==~ /(YES)/) {
                        if (dryRun) {
                            echo "DRYRUN: Running integration tests using parameters:\n" +
                            "- environment      : ${paramsCopy.environment}\n" +
                            "- street           : ${paramsCopy.street}"
                        }
                        else {
                            if (paramsCopy.environment.toUpperCase() == 'PRD') {
                                throw new GroovyRuntimeException("Running tests in production environment is not allowed.")
                            }
                            build job: config.integrationPipeline, parameters: [string(name: 'environment', value: paramsCopy.environment.toLowerCase()), string(name: 'street', value: paramsCopy.street)], propagate: false, wait: false
                        }
                    } else {
                    echo "'run_it_test' set to false >> Robot tests skipped."
                    }
                }
			} */
	    currentBuild.result = 'SUCCESS'

	} catch (any) {
	    currentBuild.result = 'FAILURE'
	    throw any
	} finally {
	    emailNotification()
	}
    }
}
@NonCPS
def GAV getInfoFromPom(String pomContent) {
	def gav = new GAV()
	def project = new XmlSlurper().parseText( pomContent )
	gav.groupId = project.groupId.toString()
	gav.artifactId = project.artifactId.toString()
	gav.version = project.version.toString()
	gav
}

class GAV {
	String groupId
	String artifactId
	String version

	def String groupIdPath() {
		groupId.replaceAll("\\.", "/")
	}
	def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}

