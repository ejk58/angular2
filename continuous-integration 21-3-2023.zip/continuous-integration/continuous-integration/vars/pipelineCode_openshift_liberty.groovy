def call(body) {
    /*
     * Dit script is bedoeld voor het uitrollen van standard BD projecten (opgebouwd mbv. mvn BD archetype) op OpenShift.
     * Het script gaat er van uit dat er een aparte repo is voor het uitrollen van het image.
     *
     * Verplichte configuratie parameters:
     * - deploymentId : Een uniek applicatie id waarmee gegevens uit de ApplicationConfiguration gehaald worden. Bijv: "iva-datadashboard"
     * - environmentChoices : omgeving waarop de applicatie moet worden uitgerold. Bijv: "ont\ntst"
     * - streetChoices : de straat binnen de omgeving waarop de applicatie moet worden uitgerold. Bijv: "1\n2\n3"
     * - gitopsRepo : de naam van de git-repository in hetzelfde project, hiermee wordt de applicatie uitgerold. Bijv: "ivadatadashboard/datadashboard-deploy.git"
     *
     * Optionele  configuratie parameters:
     * - integrationPipeline : de naam van de jenkins job die aan het eind van de succesvolle uitrol uitgevoerd moet worden. Bijv: "IVA-DataDashboard_test-Robot"
     * - nodeVersion : De naam van de jenkins agent die gebruikt wordt voor het bouwen van de Angular module(s) (Default: "nodejs10").
     * - mvnVersion : De naam van de jenkins agent die gebruikt wordt voor het bouwen van de Java module(s) (Default: "maven35-openjdk11").
     * - sonarVersion : De naam van de jenkins agent die gebruikt wordt voor het uitvoeren van de sonar check (Default: sonar).
     * - vervangenOpenjdk11Image : Boolean die aangeeft of het Jdk11 base-image vervangen moet worden (Default: false).
     * - skipSonar : Boolean die aangeeft of de Sonar stap en de OWASP stap in het build-proces overgeslagen moet worden (Default: false).
     * - mvnExtraBuildArguments : Een string met evt. extra maven argumenten (Default: ""). Bijv: "-X"
     * - environmentType = "openliberty"
     * - baseDirectory : de directory wat de basis is van de applicatie (Default: ""). Bijv. "iva-datadashboard/" (Let op: denk hierbij aan de slash op het eind)
     */
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def sonarUrl = ApplicationConfiguration.getSonarUrl()
    def sonarToken = ApplicationConfiguration.getSonarToken()

    // Deze variabelen zijn project specifiek
    def projectBase = ApplicationConfiguration.getOSprojectBase(config.deploymentId, params.environment)
    def project = ApplicationConfiguration.getOSprojectName(config.deploymentId, params.environment)

    // Deze variabelen alleen als je niet de standaard volgt.
    openshiftDeployment = params.environment + params.street

    def vervangenOpenjdk11Image = false
    if (config.vervangenOpenjdk11Image != null ) {
        vervangenOpenjdk11Image = config.vervangenOpenjdk11Image
    }
    def vervangenOpenshiftObjects = false
    if (config.vervangenOpenshiftObjects != null ) {
        vervangenOpenshiftObjects = config.vervangenOpenshiftObjects
    }

    def mvnVersion = "maven35-openjdk11"
    if (config.mvnVersion != null) {
        mvnVersion = config.mvnVersion
    }

    def nodeVersion = "nodejs10"
    if (config.nodeVersion != null) {
        nodeVersion = config.nodeVersion
    }

    def sonarVersion = "sonar"
    if (config.sonarVersion != null) {
        sonarVersion = config.sonarVersion
    }

    def skipSonar = false
    if (config.skipSonar != null) {
        skipSonar = params.skipSonar 
    }

    def gitopsRepo = null
    if (config.gitopsRepo != null) {
        gitopsRepo = config.gitopsRepo
    }

    def baseDir = ""
    if (config.baseDirectory != null) {
    baseDir = config.baseDirectory
    }

    def environmentType = 'liberty'                        
    // if (config.environmentType != null) {                     
    //     environmentType = config.environmentType              
    // } 

    def sonarQualitygateWait = false
    if (config.sonarQualitygateWait != null) {
        sonarQualitygateWait = config.sonarQualitygateWait
    }

    def tmpGitopsRepo = "/tmp/testrepoGitOps"
    def gitServerUrl = ApplicationConfiguration.getGitServerUrl()

    // Deze variabelen in principe niet veranderen
    def dryRun = false
    def baseImage = "ubi8-openjdk-17"
    def artifactName = "ws-server.jar"

    def tmpSonarDir = "/tmp/testSonar"

    def nodeNodeName = ""
    def mvnNodeName = ""

    node {
        skipDefaultCheckout()
        try {
            stage('Checkout') {
            //    node {
            //        label "maven35-openjdk11"
            //    }
                echo "DRYRUN: Running scm checkout\n"
                checkout scm
                projectInfo = getInfoFromPom(readFile("${baseDir}pom.xml"))

                if (dryRun) {
                    ART = config.artifactId
                    echo "GROUP: ${projectInfo.groupId}"
                    echo "ARTIFACT: ${projectInfo.artifactId}"
                    echo "VERSION: ${projectInfo.version}"
                    echo "Artifact from config: ${ART}"
                }
                properties([
                    parameters([
                    choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
                    choice(name: 'street', choices: config.streetChoices, description: 'Which street?'),
                    choice(name: 'run_it_test', choices: 'YES\nNO', description: 'Run the integration tests?'),
                    choice(name: 'skipSonar', choices: 'false\ntrue', description: 'skip OWASP & Sonar?')
                    ]),
                    disableConcurrentBuilds(),
                    pipelineTriggers([pollSCM('')])
                    ])

                // ITT Jeroen's versie, .git niet excluden omdat die voor de git-commit plugin nodig is
                stash(name: 'ws', includes: '**', excludes: '**/node_modules/**', useDefaultExcludes: false)
            }
            stage('Maven package') {
                echo "**************************************************************\n" +
                "** Deployment parameters:\n" +
                "** deploymentId     = ${config.deploymentId}\n" +
                "** GroupId          = ${projectInfo.groupId}\n" +
                "** ArtifactId       = ${projectInfo.artifactId}\n" +
                "** version          = ${projectInfo.version}\n" +
                "**  \n" +
                "** projectBase      = ${projectBase}\n" +
                "** ocdProject       = ${project}\n" +
                "** environment      = ${params.environment}\n" +
                "** street           = ${params.street}\n" +
                "** vervangenOpenjdk11Image        = ${vervangenOpenjdk11Image}\n" +
                "** vervangenOpenshiftObjects      = ${vervangenOpenshiftObjects}\n" +
                "**************************************************************\n"
                if (dryRun) {
                    echo "DRYRUN: Running maven package\n"
                }
                else {
                    node(mvnVersion) {
                        mvnNodeName = env.NODE_NAME
                        unstash 'ws'
                        dir(baseDir) {
                            npm_config_phantomjs_cdnurl=
                            wrap([$class: 'ConfigFileBuildWrapper', managedFiles: [[fileId: ApplicationConfiguration.getJenkinsMavenSettingsId(), variable: 'PROJECT_MAVEN_SETTINGS' ]]]) {
                                sh(script: "mvn -B -s ${PROJECT_MAVEN_SETTINGS}  install" )
                            }
                            stash name: 'jar', includes: '**/target/**/*'
                        }
                    }
                }
            }
            stage('OWASP dependency analysis') {
                if (dryRun) {
                    echo "DRYRUN: OWASP dependency analysis\n"
                }
                else {
                    node(mvnNodeName) {
                        if (skipSonar) {
                            echo "INFO: Skipping OWASP analysis\n"
                        } else {
                            echo "temp dir maken, repo clonen en owasp dependency check uitvoeren"
                            sh "rm -r ${tmpSonarDir} || true"
                            sh "mkdir -p ${tmpSonarDir}"
                            dir(tmpSonarDir) {
                                checkout scm
                                echo "OWASP dependency check"
                                //analyzeDependencies() // werkt niet in een ocd jenkins agent
                                try {
                                    wrap([$class: 'ConfigFileBuildWrapper', managedFiles: [[fileId: ApplicationConfiguration.getJenkinsMavenSettingsId(), variable: 'PROJECT_MAVEN_SETTINGS' ]]]) {
                                        sh "mvn -B -s ${PROJECT_MAVEN_SETTINGS} -f ${baseDir}pom.xml org.owasp:dependency-check-maven:aggregate \
                                            -DcveUrlBase=https://nvd.belastingdienst.nl/nvd/nvdcve-1.1-%d.json.gz \
                                            -DcveUrlModified=https://nvd.belastingdienst.nl/nvd/nvdcve-1.1-modified.json.gz \
                                            -DretireJsAnalyzerEnabled=false \
                                            -DossindexAnalyzerEnabled=false \
                                            -Dformats=HTML,JSON \
                                            -DfailBuildOnAnyVulnerability=false "
                                    }
                                } catch (any) {
                                    echo "Er gaat iets fout, maar het report wordt wel aangemaakt"
                                } finally {
                                    publishHTML(target: [
                                            allowMissing         : true,
                                            alwaysLinkToLastBuild: true,
                                            keepAll              : true,
                                            reportDir            : 'target',
                                            reportFiles          : 'dependency-check-report.html',
                                            reportName           : 'OWASP dependency analysis'
                                    ])
                                }
                                stash name: 'owasp', includes: "**/target/*"
                            }
                        }
                    }
                }
            }
            stage('Sonar scanner') {
                if (dryRun) {
                    echo "DRYRUN: Sonar analysis\n"
                }
                else {
                    if (skipSonar) {
                        echo "INFO: Skipping Sonar analysis\n"
                    } else {
                        node(sonarVersion) {
                            echo "temp dir maken, repo clonen en mvn sonar:sonar uitvoeren"
                            sh "rm -r ${tmpSonarDir} || true"
                            sh "mkdir -p ${tmpSonarDir}"
                            dir(tmpSonarDir) {
                                checkout scm
                                unstash 'jar'
                                unstash 'owasp'
                            sh "sonar-scanner  -Dproject.settings=sonar-scanner.properties -Dsonar.login=${sonarToken} -Dsonar.projectVersion=${projectInfo.version} -Dsonar.qualitygate.wait=${sonarQualitygateWait}"
                            }
                        }
                    }
                }
            }
            stage('Create Image Builder') {
                echo "Create Image Builder"
                if (dryRun) {
                    echo "DRYRUN: Running openshift.newbuild\n"
                }
                else {
                    openshift.withCluster() {
                        openshift.withProject( project ) {
                          bcExists = openshift.selector("bc", "${openshiftDeployment}").exists()
                        }
                        if(!bcExists) {
                            openshift.withCluster() {
                               openshift.withProject( project ) {
                                  openshift.newBuild("--name=${openshiftDeployment}", "-i=${baseImage}", "--binary=true")
                               }
                            }
                        } else {
                            echo "Stage Create Image Builder niet uitgevoerd, want buildconfig ${openshiftDeployment} bestaat al."
                        }
                    }
                }
            }
            stage('Build Image') {
                        echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** deploymentId     = ${config.deploymentId}\n" +
                        "** GroupId          = ${projectInfo.groupId}\n" +
                        "** ArtifactId       = ${projectInfo.artifactId}\n" +
                        "** version          = ${projectInfo.version}\n" +
                        "**  \n" +
                        "** projectBase      = ${projectBase}\n" +
                        "** ocdProject       = ${project}\n" +
                        "** environment      = ${params.environment}\n" +
                        "** street           = ${params.street}\n" +
                        "** vervangenOpenjdk11Image        = ${vervangenOpenjdk11Image}\n" +
                        "** vervangenOpenshiftObjects      = ${vervangenOpenshiftObjects}\n" +
                        "**************************************************************\n"
                
                if (dryRun) {
                    echo "DRYRUN: Running openshift.startbuild\n"
                }
                else {
                    node(mvnNodeName) {
                        if (vervangenOpenjdk11Image) {
                            sh (script: "oc delete is/${baseImage} -n ${project}" )
                            sh (script: "oc import-image cir-cn.chp.belastingdienst.nl/cpet/${baseImage}:latest --confirm -n ${project}" )
                            echo "openJdk image ${baseImage} is vervangen\n"
                        }
                        script {
                            echo "Build Image"
                            unstash 'jar'
                            openshift.withCluster() {
                                openshift.withProject( project ) {
                                    openshift.selector("bc", openshiftDeployment).startBuild("--from-file=${baseDir}/${projectBase}-ear/target/${artifactName}", "--wait=true")
                                }
                            }
                            if (gitopsRepo != null) {
                                sh "oc set image dc ${openshiftDeployment}  ${openshiftDeployment}=image-registry.openshift-image-registry.svc:5000/${project}/${openshiftDeployment}:latest -n ${project}"
                            }
                            else {
                                sh "oc tag ${openshiftDeployment}:latest ${openshiftDeployment}:${projectInfo.version} -n ${project}"
                            }
                        }
                    }
                }
            }
            stage('Create deployment in O') {
                echo "Create deployment in ${openshiftDeployment}"
                if (dryRun) {
                    echo "DRYRUN: Running openshift create environment if not exists\n"
                }
                else {
                    if (gitopsRepo != null) {
                        node("ocptools") {
                            sh "rm -r ${tmpGitopsRepo} || true"
                            sh "mkdir -p ${tmpGitopsRepo}"
                            println "repo is ${gitopsRepo}"
                            gitUrl = "${gitServerUrl}/${gitopsRepo}"
                            println "git clone ${gitUrl} ${tmpGitopsRepo}"
                            overlayDir = "overlays/${params.environment}/${openshiftDeployment}"
                            sh "git clone ${gitUrl} ${tmpGitopsRepo}"
                            sh "cd ${tmpGitopsRepo};kustomize build ${overlayDir} | oc apply -f - "
                            sh "rm -r ${tmpGitopsRepo} || true"
                            // na kustomize even image in DC setten 
                            sh "oc set image dc ${openshiftDeployment}  ${openshiftDeployment}=image-registry.openshift-image-registry.svc:5000/${project}/${openshiftDeployment}:latest -n ${project}"
                        }
                    }
                    else {
                    script {
                    if ( config.deploymentId == 'iva-brievenbus' ) {
                        if ( params.street == "1" ) {
                            dcs = ['adp','dwb']
                        } else {
                            dcs = ['adp' + params.street,'dwb' + params.street]
                        }
                    } else {
                        dcs = [ openshiftDeployment ]
                    }
                    for (dc in dcs) {
                        openshift.withCluster() {
                            openshift.withProject( project ) {
                                if (!openshift.selector('dc',dc).exists() || vervangenOpenshiftObjects) {
                                    echo "Create deployment in ${dc}"
                                    // ruim eerst de objecten als die zijn blijven staan
                                    if (openshift.selector('dc', dc).exists()) {
                                        openshift.selector('dc', dc).delete()
                                    }
                                    if (openshift.selector('svc', dc).exists()) {
                                        openshift.selector('svc', dc).delete()
                                    }
                                    if (openshift.selector('route', dc).exists()) {
                                        openshift.selector('route', dc).delete()
                                    }

                                    result = openshift.raw("apply", "-f openshift/${dc}-template.yaml")
                                    // dit template moet een deployment hebben van het image met tag 'latest'
                                    // er zit geen trigger in om te deployen bij image change

                                    // stel dat het trigger er toch is, deze op manual zetten, Jenkins is in control
                                    openshift.set("triggers", "dc/${dc}", "--manual")
                                } else {
                                    echo "Stage Create deployment in O niet uitgevoerd, DC bestaat al"
                                }
                            }
                        }
                    }
                    }
                    }
                }
            }
            stage('Deploy in O') { 
                echo "Deploy in ${openshiftDeployment}"
                if (dryRun) {
                    echo "DRYRUN: Running openshift deploy or rollout\n"
                }
                else {
                    dcs = [ openshiftDeployment ]
                    for (dc in dcs) {
                        sh "oc rollout latest dc/${dc} -n ${project} "
                        // wachten tot alle replicas beschikbaar zijn.
                        try {
                            sh  "oc rollout status dc/${dc} -n ${project} --watch"
                        } catch(any) {
                            echo "rollout van ${dc} is fout gegaan"
                            throw any
                        }
                    }


                    // Only update other project if this build is from ont str 1
                    if (updateImageTo.size() > 0 && ( params.environment == "ont" && params.street == "1" )) {
                        echo "Updating other pods"
                        def imageId = sh (script: " oc get dc ont -o yaml -n ${project} | grep image: | grep image-registry | sed 's/^[ \t]*//' | cut -d ' ' -f 2", returnStdout: true)
                        echo "ImageId: ${imageId}"
                        def curProject = sh (script: " oc project | sed 's/^[ \t]*//' |  cut -d ' ' -f 3 | sed 's/\"//g' ", returnStdout: true)
                        echo "curProject: ${curProject}"

                        for (destination in updateImageTo) {
                            echo "Updating image of dc ${destination["deploymentConfig"]}, container ${destination["container"]} in project ${destination["project"]} -- ${destination}}"
                            sh "oc project ${destination["project"]}"
                            sh "oc set image dc ${destination["deploymentConfig"]} ${destination["container"]}=${imageId}"
                        }
                        sh "oc project ${curProject}"
                    }
                }

                if (params.run_it_test ==~ /(YES)/ && config.integrationPipeline != "") {
                    if (dryRun) {
                        echo "DRYRUN: Not running integration tests\n"
                    }
                    else {
                        echo "Running integration tests\n"
                        build job: config.integrationPipeline, parameters: [string(name: 'environment', value: params.environment), string(name: 'street', value: params.street)], propagate: false, wait: false
                    }
                } else {
                    echo "'run_it_test' set to false >> Robot tests skipped."
                }
            }
            currentBuild.result = 'SUCCESS'

        } catch (any) {
            echo "Exception: ${any}"
            currentBuild.result = 'FAILURE'
            throw any
        } finally {
            deleteDir()
            if (! dryRun) {
                try {
                    // controleer dat de agent online is
                    if (hudson.model.Hudson.instance.getNode(mvnNodeName).toComputer().isOnline()) {
                        node(mvnNodeName) {
                            echo "delete workspace ${WORKSPACE} on ${mvnNodeName} "
                            deleteDir()
                        }
                    }
                } catch (any) {
                    echo "node ${nodeNodeName} is offline en de workspace kan dus niet worden verwijderd"
                }
            }
            emailNotification()
        }
    }
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
        def gav = new GAV()
        def project = new XmlSlurper().parseText( pomContent )
        gav.groupId = project.groupId.toString()
        gav.artifactId = project.artifactId.toString()
        gav.version = project.version.toString()
        gav
}

class GAV {
        String groupId
        String artifactId
        String version

        def String groupIdPath() {
                groupId.replaceAll("\\.", "/")
        }
        def String versionWithoutSnapshot() {
                if (version.endsWith("-SNAPSHOT")) {
                        version.substring(0, version.length() - 9)
                }
                else {
                        version
                }
        }
        def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
