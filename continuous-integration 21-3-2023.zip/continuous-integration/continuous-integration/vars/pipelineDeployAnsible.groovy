def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    node {
		deleteDir()

		try {
			stage ('Clone') {

				checkout scm

				properties([
				parameters([
					choice(name: 'playbook', description: 'The playbook to run', choices: 'prometheus\ngrafana'),
				]),
				disableConcurrentBuilds()
				])		
			}
			 stage ('Deploy') {
                        echo "**************************************************************\n" +
                        "** Deployment parameters:\n" +
                        "** playbook     = ${params.playbook}\n" +
                        "**************************************************************\n"
                        switch(params.playbook) {
						case "prometheus":
							hostname = "prometheus"
							playbook_name = 'create_prometheus.yml'
							break
						case "grafana":
							hostname = "grafana"
							playbook_name = 'create_grafana.yml'
							break
						default:
							
							break
						}
                        
						scriptname = 'execAnsiblePlaybook.sh'
                        def scriptContent = libraryResource "../resources/${scriptname}"
                        writeFile file: "${scriptname}" , text: scriptContent
                        sh "chmod +x ${scriptname} && ./${scriptname}  ${hostname} ${playbook_name} ${env.workspace}"
                        }

							
			currentBuild.result = 'SUCCESS'

		} catch (any) {
			currentBuild.result = 'FAILURE'
			throw any
		} finally {
			emailNotification()
		}
    }
}

@NonCPS
def GAV getInfoFromPom(String pomContent) {
	def gav = new GAV()
	def project = new XmlSlurper().parseText( pomContent )
	gav.groupId = project.groupId.toString()
	gav.artifactId = project.artifactId.toString()
	gav.version = project.version.toString()
	gav
}

class GAV {
	String groupId
	String artifactId
	String version

	def String groupIdPath() {
		groupId.replaceAll("\\.", "/")
	}
	def String versionWithoutSnapshot() {
		if (version.endsWith("-SNAPSHOT")) {
			version.substring(0, version.length() - 9)
		}
		else {
			version
		}
	}
	def String toString() {
        "GAV {groupId: ${groupId}, artifactId: ${artifactId}, version: ${version}}"
    }
}
