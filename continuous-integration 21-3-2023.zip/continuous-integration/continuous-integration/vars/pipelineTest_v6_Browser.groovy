def call(body) {
    // dit is een tijdelijk script. Omdat er nog niet een goed werkende 
    // robotframework slave op openshift is. Daarom starten we hier een job
    // in de "oude" jenkins omgeving
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    //def project = ApplicationConfiguration.getOSprojectName(config.deploymentId, params.environment)

   

    def convertNumericStreetChoicesToStrxx = false
    if (config.convertNumericStreetChoicesToStrxx != null) {
        convertNumericStreetChoicesToStrxx = config.convertNumericStreetChoicesToStrxx
    }

	def lockLabel = 'XXXX'

        node {

            try {
                stage ('Clone') {
					
		    checkout scm
					
                    if (config.pipelineTrigger != null){
                            pipelineTrigger = pipelineTriggers(config.pipelineTrigger)
                    } else {
                            pipelineTrigger = pipelineTriggers([pollSCM('')])
                    }

                    properties([
                        parameters([
                            choice(name: 'environment', choices: config.environmentChoices, description: 'Environment to run this script'),
                            choice(name: 'street', choices: config.streetChoices, description: 'Which street of cell?'),
                        ]),
                        disableConcurrentBuilds(),
                        // omdat dit een soort dummy job is voor het starten van de test op 
                        // coewd-jenkins gaan we job niet draaien na een push
                        //pipelineTrigger
		            ])
                }

                stage ("Integration"){
		    lockLabel = ApplicationConfiguration.getJenkinsLockPrefix(config.deploymentId) + "_" + params.environment + "_" + params.street
		    lock(lockLabel) {
			def reRun = false
			try{
                jobName = env.JOB_BASE_NAME
                streetId = params.street
                if (convertNumericStreetChoicesToStrxx) {
                    streetId = "str1${params.street}"
                }
                echo "Street: ${streetId}"
                echo ("Jobname:  ${jobName}")
			    withCredentials([
                    usernamePassword(credentialsId: "${jenkins_project}-jenkins-api-jobtoken", usernameVariable: 'user_niet_van_belang', passwordVariable: 'jenkins_job_token'),
                    usernamePassword(credentialsId: "JenkinsGTvDesktop", usernameVariable: 'jenkins_user', passwordVariable: 'jenkins_token')
                    ]) {
                    echo "./execJenkinsJobGTvDesktop.sh ${jobName} ${params.environment} ${params.street} ${jenkins_user} ${jenkins_token} ${jenkins_job_token}"    
                    def scriptContent = libraryResource "../resources/execJenkinsJobGTvDesktop.sh"
                    writeFile file: "execJenkinsJobGTvDesktop.sh", text: scriptContent
                    sh "chmod +x execJenkinsJobGTvDesktop.sh && ./execJenkinsJobGTvDesktop.sh ${jobName} ${params.environment} ${streetId} ${jenkins_user} ${jenkins_token} ${jenkins_job_token}"
                    }
			}catch(e){
			    reRun = true
			}  

			//if (reRun || params.reRunFailed == 'YES' ) {
			//    echo "Rerun started"
			//    robotReRun(params.street + "." + params.environment, config.robotExcludes, config.robotIncludes, config.robotNonCriticals, config.robotTestPath)
			//}
		    }
                }

                currentBuild.result = 'SUCCESS'

            } catch (e) {
                currentBuild.result = 'FAILURE'
                throw e
	        } finally {
                //if (config.robotTestPath != null){ 
		        //    robotLogPublication()
                //}
		        //emailNotification()
	        }
        }
}