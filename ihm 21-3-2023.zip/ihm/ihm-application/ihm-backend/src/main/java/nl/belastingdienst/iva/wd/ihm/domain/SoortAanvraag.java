package nl.belastingdienst.iva.wd.ihm.domain;

public enum SoortAanvraag {

    REGULIER("Regulier"),
    PROACTIEF("Proactief"),
    STRIPPENKAART("Strippenkaart"),
    CLUSTER("Cluster"),
    VRIJBLIJVEND("Vrijblijvend"),
    VERANBTELIJKING("Verambtelijking");

    private final String description;

    SoortAanvraag(String description) {
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

}
