package nl.belastingdienst.iva.wd.ihm.domain;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
public class ApiKey {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String key;
    private String client;
    private String signalTypes;
    private String authorizedMethods;

    public boolean isMethodAuthorized(String method) {
        Set<String> methods = new HashSet<>(Arrays.asList(authorizedMethods.split(",")));
        return methods.contains(method);
    }

    public boolean isSignalTypeAuthorized(String signalType) {
        Set<String> types = new HashSet<>(Arrays.asList(signalTypes.split(",")));
        return types.contains(signalType);
    }
}
