package nl.belastingdienst.iva.wd.ihm.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import nl.belastingdienst.iva.wd.ihm.domain.exception.JWTInvalidException;
import org.springframework.core.env.Environment;
import org.springframework.security.core.Authentication;

import java.util.Date;

public class JwtUtils {

    private final Environment env;

    public JwtUtils(Environment env) {
        this.env = env;
    }

    public String generateJwtToken(Authentication authentication) {
        long validityPeriod = Long.parseLong(env.getRequiredProperty("jwt.validity.period.in.days")) * 24 * 60 * 60 * 1000;
        return JWT.create()
            .withSubject(authentication.getPrincipal().toString())
            .withExpiresAt(new Date(System.currentTimeMillis() + validityPeriod))
            .sign(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes()));
    }

    public DecodedJWT validateJwtToken(String token) {
        try {
            return JWT.require(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes())).build().verify(token);
        } catch (JWTVerificationException e) {
            throw new JWTInvalidException(e.getMessage(), e);
        }
    }

}
