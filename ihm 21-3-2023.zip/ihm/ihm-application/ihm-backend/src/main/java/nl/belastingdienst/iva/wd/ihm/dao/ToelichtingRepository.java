package nl.belastingdienst.iva.wd.ihm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.ihm.domain.ToelichtingJPA;

@Repository
public interface ToelichtingRepository extends JpaRepository<ToelichtingJPA, Integer> {

}
