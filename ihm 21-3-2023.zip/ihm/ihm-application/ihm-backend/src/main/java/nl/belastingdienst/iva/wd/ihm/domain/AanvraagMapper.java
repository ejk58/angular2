package nl.belastingdienst.iva.wd.ihm.domain;

import nl.belastingdienst.iva.wd.ihm.dto.AanvraagDTO;
import nl.belastingdienst.iva.wd.ihm.dto.ToelichtingDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AanvraagMapper {

    @Autowired
    private ToelichtingMapper toelichtingMapper;

    public AanvraagJPA map(AanvraagDTO aanvraagDTO) {
        AanvraagJPA aanvraagJPA = new AanvraagJPA();

        aanvraagJPA.setId(aanvraagDTO.getId());
        aanvraagJPA.setIndieningsDatum(aanvraagDTO.getIndieningsDatum());
        aanvraagJPA.setVorigReferentieNr(aanvraagDTO.getVorigReferentieNr());
        aanvraagJPA.setSoortMiniCompetitie(aanvraagDTO.getSoortMiniCompetitie());
        aanvraagJPA.setSoortAanvraag(aanvraagDTO.getSoortAanvraag());
        aanvraagJPA.setSoortToelichting(mapToelichting(aanvraagDTO.getSoortToelichting()));
        aanvraagJPA.setMaximumUurtarief(aanvraagDTO.getMaximumUurtarief());
        aanvraagJPA.setSpoed(aanvraagDTO.getSpoed());

        // TODO Map meer zut

        return aanvraagJPA;
    }

    private ToelichtingJPA mapToelichting(ToelichtingDTO toelichtingDTO) {
        return this.toelichtingMapper.map(toelichtingDTO);
    }
}
