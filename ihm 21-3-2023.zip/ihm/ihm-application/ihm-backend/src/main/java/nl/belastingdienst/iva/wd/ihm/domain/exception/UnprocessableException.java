package nl.belastingdienst.iva.wd.ihm.domain.exception;

public class UnprocessableException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public UnprocessableException(String message) {
        super(message);
    }

    public UnprocessableException(String message, Throwable cause) {
        super(message, cause);
    }
}
