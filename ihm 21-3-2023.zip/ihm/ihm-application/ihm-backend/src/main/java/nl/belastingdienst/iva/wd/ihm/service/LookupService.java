package nl.belastingdienst.iva.wd.ihm.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.wd.ihm.domain.Lookup;
import nl.belastingdienst.iva.wd.ihm.domain.SoortAanvraag;
import nl.belastingdienst.iva.wd.ihm.domain.SoortMiniCompetitie;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class LookupService {

    public enum LookupType {
        SOORTAANVRAAG, SOORTMINICOMPETITIE;
    }

    public Map<String, Lookup> getMap(LookupType type) {
        switch (type) {
            case SOORTAANVRAAG:
                return Arrays.stream(SoortAanvraag.values()).collect(Collectors.toMap(Enum::name, e -> new Lookup(e.name(), e.getDescription())));
            case SOORTMINICOMPETITIE:
                return Arrays.stream(SoortMiniCompetitie.values()).collect(Collectors.toMap(Enum::name, e -> new Lookup(e.name(), e.getDescription())));
            default:
                return null;
        }
    }

    public List<Lookup> getList(LookupType type) {
        return getMap(type).values().stream().sorted(Comparator.comparing(Lookup::getOmschrijving)).collect(Collectors.toList());
    }

}
