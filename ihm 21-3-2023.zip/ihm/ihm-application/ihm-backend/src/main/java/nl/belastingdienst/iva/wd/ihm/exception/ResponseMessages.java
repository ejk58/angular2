package nl.belastingdienst.iva.wd.ihm.exception;

public class ResponseMessages {

    private ResponseMessages() {
    }

    public static final String SERVER_ERROR = "Er is een fout opgetreden op de server.";
    public static final String UNAUTHORIZED = "Let op! Het opslaan is niet gelukt. Je hebt geen toegang tot klantbeeld ";
    public static final String JWT_INVALID = "Uw autorisatie is verlopen. U moet uitloggen en opnieuw inloggen.";
}
