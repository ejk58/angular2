import {MonoTypeOperatorFunction, Subject as RxSubject, Unsubscribable as RxUnsubscribable} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable()
export class Unsubscriber implements RxUnsubscribable {

  private unsubscribeSubject$: RxSubject<void> = new RxSubject<void>();
  readonly takeUntilForUnsubscribe: MonoTypeOperatorFunction<never> = takeUntil(this.unsubscribeSubject$);

  unsubscribe(): void {
    this.unsubscribeSubject$.next();
    this.unsubscribeSubject$.complete();
  }
}
