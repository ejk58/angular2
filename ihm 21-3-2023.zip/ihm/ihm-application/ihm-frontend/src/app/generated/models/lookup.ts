/* tslint:disable */
export interface Lookup {
  code?: string;
  omschrijving?: string;
}
