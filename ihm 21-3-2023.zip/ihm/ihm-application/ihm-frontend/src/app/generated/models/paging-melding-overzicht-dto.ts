/* tslint:disable */
import {MeldingOverzichtDTO} from './melding-overzicht-dto';

export interface PagingMeldingOverzichtDTO {
  count?: number;
  list?: Array<MeldingOverzichtDTO>;
}
