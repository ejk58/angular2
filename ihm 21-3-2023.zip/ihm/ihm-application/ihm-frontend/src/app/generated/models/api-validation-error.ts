/* tslint:disable */
export interface ApiValidationError {
  field?: string;
  message?: string;
  rejectedValue?: string;
}
