/* tslint:disable */
import {ModuleWithProviders, NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {ApiConfiguration, ApiConfigurationInterface} from './api-configuration';

import {LookupRestControllerService} from './services/lookup-rest-controller.service';
import {MeldingRestControllerService} from './services/melding-rest-controller.service';
import {StroomRestControllerService} from './services/stroom-rest-controller.service';

/**
 * Provider for all Api services, plus ApiConfiguration
 */
@NgModule({
  imports: [
    HttpClientModule
  ],
  exports: [
    HttpClientModule
  ],
  declarations: [],
  providers: [
    ApiConfiguration,
    LookupRestControllerService,
    MeldingRestControllerService,
    StroomRestControllerService
  ],
})
export class ApiModule {
  static forRoot(customParams: ApiConfigurationInterface): ModuleWithProviders<ApiModule> {
    return {
      ngModule: ApiModule,
      providers: [
        {
          provide: ApiConfiguration,
          useValue: {rootUrl: customParams.rootUrl}
        }
      ]
    };
  }
}
