import {Component, OnInit} from '@angular/core';

import {DynamicDialogConfig} from 'primeng/dynamicdialog';

@Component({
  selector: 'ihm-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss']
})
export class ErrorComponent implements OnInit {

  errorMessage: string;

  constructor(public readonly config: DynamicDialogConfig) { }

  ngOnInit(): void {
    this.errorMessage = this.config.data ? this.config.data.errorMessage : '';
  }

}
