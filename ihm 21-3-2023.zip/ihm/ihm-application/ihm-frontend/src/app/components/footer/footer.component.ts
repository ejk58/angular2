import {Component, OnInit} from '@angular/core';

import {SystemService} from '../../services/system.service';
import {Version} from '../../domain/system/version';

@Component({
  selector: 'ihm-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})

export class FooterComponent implements OnInit {

  version: Version;

  constructor(private readonly systemService: SystemService) { }

  ngOnInit(): void {
    this.systemService.getVersion().subscribe(version => this.version = version);
  }
}
