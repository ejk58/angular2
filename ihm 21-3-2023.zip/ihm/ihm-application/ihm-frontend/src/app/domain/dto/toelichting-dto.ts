export interface ToelichtingDto {
  tekst: string;
}
