export interface Version {
    version: string;
    commitDate: string;
    commitId: string;
}
