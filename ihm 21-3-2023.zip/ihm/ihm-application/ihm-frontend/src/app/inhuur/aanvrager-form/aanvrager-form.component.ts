import {AfterViewInit, Component, EventEmitter, forwardRef, OnDestroy, OnInit, Output} from '@angular/core';
import {FormBuilder, NG_VALUE_ACCESSOR, Validators} from '@angular/forms';
import {AanvragerFormValues} from './aanvrager-form-values';
import {AbstractFormSection} from '../form-section/abstract-form-section';
import {FormSectionStatus} from '../domain/form-section-status';
import {SectionStatus} from '../domain/section-status';
import {AANVRAGER} from '../domain/constants';
import {Unsubscriber} from '../../common/unsubscriber';

@Component({
  selector: 'ihm-aanvrager-form',
  templateUrl: './aanvrager-form.component.html',
  styleUrls: ['./aanvrager-form.component.scss'],
  providers: [{provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => AanvragerFormComponent), multi: true}, Unsubscriber]
})
export class AanvragerFormComponent extends AbstractFormSection<AanvragerFormValues> implements AfterViewInit, OnDestroy, OnInit {

  @Output() statusChanged: EventEmitter<FormSectionStatus> = new EventEmitter<FormSectionStatus>();

  constructor(private readonly formBuilder: FormBuilder,
              private readonly unsubscriber: Unsubscriber) {
    super();
    this.formSection = this.formBuilder.group({
      departement: ['', [Validators.required]],
      deelnemer: ['', [Validators.required]],
      afdelingBedrijfsonderdeel: ['', [Validators.required]],
      inhurendManager: ['', [Validators.required]]
    });
    super.activateSubscriptionsToValueChanges();

    // TODO: dit moet alleen gebeuren bij invullen nieuw formulier
    this.setDefaultValuesForAanvrager();
  }

  ngOnInit(): void {
    // Emit inital status
    this.formSection.updateValueAndValidity({onlySelf: true, emitEvent: false});
    this.statusChanged.emit({sectionName: AANVRAGER, status: SectionStatus[this.formSection.status]});
  }

  ngOnDestroy() {
    super.ngOnDestroy();
    this.unsubscriber.unsubscribe();
  }

  ngAfterViewInit() {
    // Emit status change
    this.formSection.statusChanges
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe((status: string) => {
        this.statusChanged.emit({sectionName: AANVRAGER, status: SectionStatus[status]});
      });
  }

  private setDefaultValuesForAanvrager(): void {
    this.formSection.patchValue({departement: 'Ministerie van Financiën'});
    this.formSection.patchValue({deelnemer: 'Belastingdienst'});
  }
}
