export class AanvraagFormValues {
  ongewijzigdeHerhalingsaanvraag: boolean;
  vorigReferentieNr: string;
  soortMiniCompetitie: string;
  soortAanvraag: string;
  maximumUurtarief: string;
  spoed: boolean;
  soortToelichting: string;
}
