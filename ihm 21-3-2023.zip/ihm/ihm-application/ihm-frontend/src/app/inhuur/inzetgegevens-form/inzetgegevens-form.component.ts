import {AfterViewInit, Component, EventEmitter, forwardRef, OnDestroy, OnInit, Output} from '@angular/core';
import {FormBuilder, NG_VALUE_ACCESSOR, Validators} from '@angular/forms';
import {Unsubscriber} from '../../common/unsubscriber';
import {AbstractFormSection} from '../form-section/abstract-form-section';
import {AanvragerFormValues} from '../aanvrager-form/aanvrager-form-values';
import {FormSectionStatus} from '../domain/form-section-status';
import {INZETGEGEVENS} from '../domain/constants';
import {SectionStatus} from '../domain/section-status';
import {LookupService} from '../../services/lookup.service';


@Component({
  selector: 'ihm-inzetgegevens-form',
  templateUrl: './inzetgegevens-form.component.html',
  styleUrls: ['./inzetgegevens-form.component.scss'],
  providers: [{provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => InzetgegevensFormComponent), multi: true}, Unsubscriber]
})
export class InzetgegevensFormComponent extends AbstractFormSection<AanvragerFormValues> implements AfterViewInit, OnDestroy, OnInit {
  @Output() statusChanged: EventEmitter<FormSectionStatus> = new EventEmitter<FormSectionStatus>();

  constructor(private readonly formBuilder: FormBuilder,
              private readonly lookupService: LookupService,
              private readonly unsubscriber: Unsubscriber) {
    super();
    this.formSection = this.formBuilder.group({
      gewensteStartdatum: ['', [Validators.required]],
      initieleStartdatum: ['', [Validators.required]],
      aantalMaandenInitieleInhuurtermijn: ['', [Validators.required]],
      optieOpVerlenging: ['', [Validators.required]],
      maximaalAantalVerlenginen: ['', [Validators.required]],
      termijnPerVerlengingInMaanden: ['', [Validators.required]],
      geplandeEinddatumProject: ['', [Validators.required]],
      urenPerWeek: ['', [Validators.required]],
      maxAantalUrenInitieleInhuurtermijn: ['', [Validators.required]],
      vergoedingDienstreizenInbegrepenInTarief: ['', [Validators.required]],
      toelichting: ['', [Validators.required]],
      hoofdStandplaats: ['', [Validators.required]],
      alternatieveHoofdStandplaats: ['', [Validators.required]],
      extraStandplaats_en: ['', [Validators.required]],
      veiligheidsonderzoekVereist: ['', [Validators.required]],
      vogAanwezigVoorStartInzet: ['', [Validators.required]],
      vrijeVervangingBespreekbaar: ['', [Validators.required]],
      mogenZzpersWordenAangeboden: ['', [Validators.required]],
      parttimersToegestaan: ['', [Validators.required]],
      offsiteWerkenBespreekbaar: ['', [Validators.required]],
      socialReturnKandidaatGewenst: ['', [Validators.required]],
      cosignatiediensten: ['', [Validators.required]],
      betrokkenheidBijAanbestedingen: ['', [Validators.required]],
      maxAantalCVsPerOpdrachtnemer: ['', [Validators.required]]
    });
    super.activateSubscriptionsToValueChanges();

    this.setDefaultValuesForInzetgegevens();
  }

  ngOnInit(): void {
    // Emit inital status
    this.formSection.updateValueAndValidity({onlySelf: true, emitEvent: false});
    this.statusChanged.emit({sectionName: INZETGEGEVENS, status: SectionStatus[this.formSection.status]});

    this.lookupService.isFetchingLookupTablesReady$
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(() => {
        //this.soortenAanvraag = this.lookupService.get(SOORTAANVRAAG).map((lookup: Lookup) => lookup.omschrijving);
        //this.soortenMiniCompetitie = this.lookupService.get(SOORTMINICOMPETITIE).map((lookup: Lookup) => lookup.omschrijving);
      });
  }

  ngOnDestroy() {
    super.ngOnDestroy();
    this.unsubscriber.unsubscribe();
  }

  ngAfterViewInit() {
    this.formSection.statusChanges
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe((status: string) => {
        this.statusChanged.emit({sectionName: INZETGEGEVENS, status: SectionStatus[status]});
      });
  }

  private setDefaultValuesForInzetgegevens(): void {
    this.formSection.patchValue({gewensteStartdatum: null});
    this.formSection.patchValue({initieleStartdatum: null});
    this.formSection.patchValue({aantalMaandenInitieleInhuurtermijn: null});
    this.formSection.patchValue({optieOpVerlenging: false});
    this.formSection.patchValue({maximaalAantalVerlenginen: null});
    this.formSection.patchValue({termijnPerVerlengingInMaanden: null});
    this.formSection.patchValue({geplandeEinddatumProject: null});
    this.formSection.patchValue({urenPerWeek: null});
    this.formSection.patchValue({maxAantalUrenInitieleInhuurtermijn: null});
    this.formSection.patchValue({vergoedingDienstreizenInbegrepenInTarief: false});
    this.formSection.patchValue({toelichting: null});
    this.formSection.patchValue({hoofdStandplaats: null});
    this.formSection.patchValue({alternatieveHoofdStandplaats: null});
    this.formSection.patchValue({extraStandplaats_en: null});
    this.formSection.patchValue({veiligheidsonderzoekVereist: false});
    this.formSection.patchValue({vogAanwezigVoorStartInzet: false});
    this.formSection.patchValue({vrijeVervangingBespreekbaar: false});
    this.formSection.patchValue({mogenZzpersWordenAangeboden: false});
    this.formSection.patchValue({parttimersToegestaan: false});
    this.formSection.patchValue({offsiteWerkenBespreekbaar: false});
    this.formSection.patchValue({socialReturnKandidaatGewenst: false});
    this.formSection.patchValue({cosignatiediensten: false});
    this.formSection.patchValue({betrokkenheidBijAanbestedingen: false});
    this.formSection.patchValue({maxAantalCVsPerOpdrachtnemer: null});

  }
}