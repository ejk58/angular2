export class InzetgegevensFormValues {
  gewensteStartdatum: any;
  initieleStartdatum: any;
  aantalMaandenInitieleInhuurtermijn: string;
  optieOpVerlenging: boolean;
  maximaalAantalVerlenginen: string;
  termijnPerVerlengingInMaanden: string;
  geplandeEinddatumProject: any;
  urenPerWeek: string;
  maxAantalUrenInitieleInhuurtermijn: string;
  vergoedingDienstreizenInbegrepenInTarief: boolean;
  toelichting: string;
  hoofdStandplaats: string;
  alternatieveHoofdStandplaats: string;
  extraStandplaats_en: string;
  veiligheidsonderzoekVereist: boolean;
  vogAanwezigVoorStartInzet: boolean;
  vrijeVervangingBespreekbaar: boolean;
  mogenZzpersWordenAangeboden: boolean;
  parttimersToegestaan: boolean;
  offsiteWerkenBespreekbaar: boolean;
  socialReturnKandidaatGewenst: boolean;
  cosignatiediensten: boolean;
  betrokkenheidBijAanbestedingen: boolean;
  maxAantalCVsPerOpdrachtnemer: string;
}