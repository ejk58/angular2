import {SectionStatus} from './section-status';
import {AANVRAAG, AANVRAGER, INZETGEGEVENS} from './constants';

export interface FormSectionStatus {
  sectionName: typeof AANVRAAG | typeof AANVRAGER | typeof INZETGEGEVENS;
  status: SectionStatus;
}
