export enum SectionStatus {
  VALID = 'VALID',
  INVALID = 'INVALID'
}
