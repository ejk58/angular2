@Library("GENERIC") _
pipelineRelease_openshift {
    deploymentId = "iva-ihm"
    deployPipeline = "iva-ihm_deploy_release"
    integrationPipeline = ""
    environmentChoices = "tst\nacc"
    streetChoices = "1\n2\n3\n4\n5\n6\n"
}
