# pip install --index-url http://externerepos.belastingdienst.nl/pypi/web/simple --trusted-host externerepos.belastingdienst.nl pandas

import calendar
import pandas


vogCodeColumn = 'A'
vogNaamColumn = 'B'
sqlFilename = '915-verklaringomtrentgedrag.sql'

data = pandas.read_excel('Inhuurformulier ICT Belastingdienst 4.17 (onbeveiligde versie).xlsm', sheet_name = 'Info VOG Items', usecols = f'{vogCodeColumn}:{vogNaamColumn}')
vogItemList = []
sql = []


print('Reading information about "verklaring omtrent gedrag items"...')    
for index, datarow in data.iterrows():
    code = datarow[0]

    if code is not None and code > 0:
        naam = str(datarow[1]).strip()
#        sql.append(f'INSERT INTO VERKLARINGOMTRENTGEDRAG(INDEX, CODE, NAAM) VALUES ({str(index)}, \'{code:02.0f}\', \'{naam}\');\n')
        sql.append(f'MERGE INTO VERKLARINGOMTRENTGEDRAG AS V USING (VALUES ({str(index)}, \'{code:02.0f}\', \'{naam}\')) AS X(INDEX, CODE, NAAM) ON V.CODE = X.CODE WHEN MATCHED THEN UPDATE SET INDEX = X.INDEX, CODE = X.CODE, NAAM = X.NAAM WHEN NOT MATCHED THEN INSERT (INDEX, CODE, NAAM) VALUES (X.INDEX, X.CODE, X.NAAM);\n')


print('Writing SQL file...')    
sqlFile = open(sqlFilename, 'w', encoding = 'utf-8')
sqlFile.writelines(sql)
sqlFile.close()

print('Done.')
