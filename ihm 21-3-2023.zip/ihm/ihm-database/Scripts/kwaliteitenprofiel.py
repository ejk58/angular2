# pip install --index-url http://externerepos.belastingdienst.nl/pypi/web/simple --trusted-host externerepos.belastingdienst.nl pandas

import calendar
import pandas

# months = {v: k for k,v in enumerate(calendar.month_abbr)}
# data = pandas.read_csv('Data_3DC.csv', sep = ';')

hoofdgroepList = ['Plannen', 'Bouwen', 'Uitvoeren', 'Mogelijk maken', 'Sturen']
kwaliteitenprofielColumn = 'Kwaliteitenprofielen'
toelichtingColumn = 'Toelichting' 
opleidingsvoorbeeldColumn = 'Voorbeelden van opleidingen'
sqlFilename = '911-kwaliteitenprofiel.sql'

data = pandas.read_excel('Inhuurformulier ICT Belastingdienst 4.17 (onbeveiligde versie).xlsm', sheet_name = 'Kwaliteitsraamwerk I(v)')
kwaliteitenprofielList = []
sql = []


print('Reading basic information about "kwaliteitenprofiel"...')    
index = 1
for hoofdgroep in hoofdgroepList:
    for rowindex, datarow in data.iterrows():
        naam = str(datarow[hoofdgroep]).strip().replace('  ', ' ')
        
        if naam is not None and len(naam) > 3:
            code = naam.split(' ', 1)[0]
            kwaliteitenprofielList.append({'hoofdgroep': hoofdgroep, 'naam': naam, 'code': code, 'index': index})
            index = index + 1


print('Reading more information for each "kwaliteitenprofiel"...')
for rowindex, datarow in data.iterrows():
    naam = str(datarow[kwaliteitenprofielColumn]).strip().replace('  ', ' ')

    if naam is not None and len(naam) > 3:
        kwaliteitenprofiel = next((profiel for profiel in kwaliteitenprofielList if profiel['naam'] == naam), None)
        if kwaliteitenprofiel:
            kwaliteitenprofiel['toelichting'] = str(datarow[toelichtingColumn])
            kwaliteitenprofiel['opleidingsvoorbeeld'] = str(datarow[opleidingsvoorbeeldColumn])


print('Creating SQL insert statements...')
for kwaliteitenprofiel in kwaliteitenprofielList:
    index = kwaliteitenprofiel['index']
    hoofdgroep = kwaliteitenprofiel['hoofdgroep']
    code = kwaliteitenprofiel['code']
    naam = kwaliteitenprofiel['naam']
    toelichting = kwaliteitenprofiel['toelichting'].replace("'", "''").replace(";\n", "\n").strip()
    opleidingsvoorbeeld = kwaliteitenprofiel['opleidingsvoorbeeld'].replace("'", "''").replace(";\n", "\n").strip()
    sql.append(f'MERGE INTO KWALITEITENPROFIEL AS K USING (VALUES ({str(index)}, \'{hoofdgroep}\', \'{code}\', \'{naam}\', \'{toelichting}\', \'{opleidingsvoorbeeld}\')) AS X(INDEX, HOOFDGROEP, CODE, NAAM, TOELICHTING, OPLEIDINGSVOORBEELD) ON K.CODE = X.CODE WHEN MATCHED THEN UPDATE SET INDEX = X.INDEX, HOOFDGROEP = X.HOOFDGROEP, CODE = X.CODE, NAAM = X.NAAM, TOELICHTING = X.TOELICHTING, OPLEIDINGSVOORBEELD = X.OPLEIDINGSVOORBEELD WHEN NOT MATCHED THEN INSERT (INDEX, HOOFDGROEP, CODE, NAAM, TOELICHTING, OPLEIDINGSVOORBEELD) VALUES (X.INDEX, X.HOOFDGROEP, X.CODE, X.NAAM, X.TOELICHTING, X.OPLEIDINGSVOORBEELD);\n')


print('Writing SQL file...')    
sqlFile = open(sqlFilename, 'w', encoding = 'utf-8')
sqlFile.writelines(sql)
sqlFile.close()

print('Done.')
