# pip install --index-url http://externerepos.belastingdienst.nl/pypi/web/simple --trusted-host externerepos.belastingdienst.nl pandas

import calendar
import pandas


kwaliteitenprofielColumn = 'Kwaliteitenprofielen'
naamColumnPrefix = 'Functiegroep '
schaalColumnPrefix = 'Schaal '
competentiesColumnPrefix = 'Competenties '
sqlFilename = '912-functiegroep.sql'

data = pandas.read_excel('Inhuurformulier ICT Belastingdienst 4.17 (onbeveiligde versie).xlsm', sheet_name = 'Kwaliteitsraamwerk I(v)')
functiegroepList = []
sql = []


print('Reading information about "functiegroep"...')    
for rowindex, datarow in data.iterrows():
    kwaliteitenprofiel = str(datarow[kwaliteitenprofielColumn]).strip().replace('  ', ' ')

    if kwaliteitenprofiel is not None and len(kwaliteitenprofiel) > 3:
        for columnindex in range(1, 3):
            naam = str(datarow[naamColumnPrefix + str(columnindex)]).strip()
            schaal = str(datarow[schaalColumnPrefix + str(columnindex)]).strip()
            competenties = str(datarow[competentiesColumnPrefix + str(columnindex)]).strip()
            
            if naam is not None and len(naam) > 3:
                duplicate = False
                for functiegroep in functiegroepList:
                    duplicate = duplicate or functiegroep['naam'] == naam

                if not duplicate:
                    functiegroepList.append({'naam': naam, 'schaal': schaal, 'competenties': competenties})


print('Converting information to SQL...')
for index, functiegroep in enumerate(functiegroepList):
    naam = functiegroep['naam']
    schaal = functiegroep['schaal']
    competenties = functiegroep['competenties']
    sql.append(f'MERGE INTO FUNCTIEGROEP AS F USING (VALUES ({str(index + 1)}, \'{naam}\', \'{schaal}\', \'{competenties}\')) AS X(INDEX, NAAM, SCHAAL, COMPETENTIES) ON F.NAAM = X.NAAM WHEN MATCHED THEN UPDATE SET INDEX = X.INDEX, NAAM = X.NAAM, SCHAAL = X.SCHAAL, COMPETENTIES = X.COMPETENTIES WHEN NOT MATCHED THEN INSERT (INDEX, NAAM, SCHAAL, COMPETENTIES) VALUES (X.INDEX, X.NAAM, X.SCHAAL, X.COMPETENTIES);\n')


print('Writing SQL file...')    
sqlFile = open(sqlFilename, 'w', encoding = 'utf-8')
sqlFile.writelines(sql)
sqlFile.close()

print('Done.')
