package nl.ticket.domain;

public enum Scrumlane {

	TODO("todo"), DOING("doing"), DONE("done");

	private String description;

	private Scrumlane(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	/**
	 * Geeft de scrumlane die bij een omschrijving hoort.
	 * 
	 * @param scrumlaneDescription
	 *            omschrijving van een scrumlane
	 * @return scrumlane (null indien geen scrumlane voor deze omschrijving aanwezig is)
	 */
	public static final Scrumlane getScrumlane(String scrumlaneDescription) {
		if (scrumlaneDescription != null) {
			for (Scrumlane scrumlane : Scrumlane.values()) {
				if (scrumlaneDescription.equalsIgnoreCase(scrumlane.description)) {
					return scrumlane;
				}
			}
		}
		return null;
	}

}
