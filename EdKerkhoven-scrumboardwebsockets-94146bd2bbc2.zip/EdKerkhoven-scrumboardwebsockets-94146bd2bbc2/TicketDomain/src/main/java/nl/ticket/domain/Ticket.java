package nl.ticket.domain;

//@Named("ticketXX")
//@RequestScoped
public class Ticket {

	private String id;
	private String owner;
	private int numberOfHours;
	private String description;
	private String team;
	private Scrumlane scrumlane;

	/**
	 * Constructor ZONDER argumenten is verplicht als je een bean wilt injecteren met @Inject (anders krijg je bij het deployen
	 * fouten dat de bean niet gevonden kan worden). Zie link http://docs.oracle.com/javaee/6/tutorial/doc/gjfzi.html.
	 */
	public Ticket() {
		super();
	}

	public Ticket(String id, String owner, int numberOfHours, String description, String team, Scrumlane scrumlane) {
		super();
		this.id = id;
		this.owner = owner;
		this.numberOfHours = numberOfHours;
		this.description = description;
		this.team = team;
		this.scrumlane = scrumlane;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public int getNumberOfHours() {
		return numberOfHours;
	}

	public void setNumberOfHours(int numberOfHours) {
		this.numberOfHours = numberOfHours;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public Scrumlane getScrumlane() {
		return scrumlane;
	}

	public void setScrumlane(Scrumlane scrumlane) {
		this.scrumlane = scrumlane;
	}

}
