/*!
 * websocket JavaScript Library v1.0
 *
 * Author: Ed Kerkhoven
 */

var websockets = {};
var ws = null;

websockets.connect = function () {
    var target = 'ws://localhost:8080/scrumboardWebsockets';

    if (ws != null) {
    	return;
    }
    
    if ('WebSocket' in window) {
    	ws = new WebSocket(target);
    } else if ('MozWebSocket' in window) {
    	ws = new MozWebSocket(target);
    } else {
        alert('WebSocket is not supported by this browser.');
        return;
    }
    
    ws.onopen = function () {
        alert('Info: WebSocket connection opened.');
    };
    
    ws.onmessage = function (event) {
        var received = event.data;
    	// event.data is een string in json-formaat (geen JSONObject). Omzetten naar een javascript object met parseJSON.
        var obj = jQuery.parseJSON(received);
        if (obj.action == 'Archivate') {
        	var ticketId = obj.ticketId;
        	$("#" + ticketId).remove();
        	alert('Ticket ' + ticketId + ' is gearchiveerd');
        } else if (obj.action == 'Move') {
        	var ticketId = obj.ticketId;
        	var newScrumlane = obj.newScrumlane;
        	$("#" + newScrumlane).append($("#" + ticketId));
        } else if (obj.action == 'Add') {
        	var scrumlane = obj.ticketScrumlane;
        	var newTicket = scrumboardtemplates.ticket(obj);
        	$("#" + scrumlane).append(newTicket);
        } else if (obj.action == 'Remove') {
        	var ticketId = obj.ticketId;
        	$("#" + ticketId).remove();
        } else {
        	alert('Error: onbekende actie in ws.onmessage');
        }
    };
    
    ws.onclose = function () {
        alert('Info: WebSocket connection closed.');
    };
    
};

websockets.disconnect = function () {
    if (ws != null) {
    	ws.close();
    	ws = null;
    }
};

websockets.send = function (tekst) {
    if (ws != null) {
    	ws.send(tekst);
    } else {
        alert('WebSocket connection not established, please connect.');
    }
};
 