/*!
 * scrumboard JavaScript Library v1.0
 * 
 * Opmerkingen:
 * ------------
 * De gebruikte jQuery.get is geen gewone get-submit, maar is een ajax-call waarbij het resultaat wordt terugverwacht.
 * Het resultaat kun je dan met behulp van een callback functie verwerken --> zie jQuery website.
 *
 * Author: Ed Kerkhoven
 */

function allowDrop(ev)
{
	ev.preventDefault();
}

function drag(ev)
{
	ev.dataTransfer.setData("Text", ev.target.id);
}

//************************************************
//********** VERPLAATSEN VAN EEN TICKET **********
//************************************************

/**
 * Verplaatst een ticket naar een andere scrumlane.
 */
function move(ev)
{
	ev.preventDefault();
	var transferredTicketId = ev.dataTransfer.getData("Text");
	var newScrumlane = ev.target.id;
	jQuery.get("moveTicket", {scrumlane: newScrumlane, ticketId: transferredTicketId}, function() {} )
	      .success(function(data) {
	    	  // De ontvangen 'data' is een JSONObject en bevat het ticketId en de nieuwe scrumlane (gemaakt in de servlet die de get afhandeld).
	    	  var ticketId = data.ticketId;
	    	  var newScrumlane = data.newScrumlane;
	    	  moveSuccessfull(ticketId, newScrumlane);} )
	      .error(function() {
	    	  moveNotSuccessfull(transferredTicketId);} );
}

/**
 * Verplaatsen ticket is succesvol afgehandeld. Verplaats het ticket op het scherm door een websocket message te versturen.
 * 
 * @param ticketId
 *            id van het te verplaatsen ticket
 * @param scrumlane
 *            nieuwe scrumlane van het te verplaatsen ticket
 */
function moveSuccessfull(ticketId, scrumlane)
{
	// Maak en verzend een websocket message
	var actionToPerform = new Object();
	actionToPerform.action = "Move";
	actionToPerform.ticketId = ticketId;
	actionToPerform.newScrumlane = scrumlane;
	var actionToPerformAsJsonString = JSON.stringify(actionToPerform);
	websockets.send(actionToPerformAsJsonString);
}

/**
 * Verplaatsen ticket is NIET succesvol afgehandeld. Geef een melding dat het ticket NIET is verplaatst.
 * 
 * @param ticketId
 *            id van te verplaatsen ticket
 */
function moveNotSuccessfull(ticketId)
{
	alert("Error!! Ticket " + ticketId + " is NIET verplaatst");
}

//************************************************
//********** ARCHIVEREN VAN EEN TICKET ***********
//************************************************

/**
 * Archiveert een ticket.
 */
function archivate(ev)
{
	ev.preventDefault();
	var transferredTicketId = ev.dataTransfer.getData("Text");
	jQuery.get("archivateTicket", {ticketId: transferredTicketId}, function() {} )
	 	  .success(function(data) {
	 		  // De ontvangen 'data' is een JSONObject en bevat het ticketId (gemaakt in de servlet die de get afhandeld).
	 		  var ticketId = data.ticketId;
	 		  archivateSuccessfull(ticketId);} )
		  .error(function() {
			  archivateNotSuccessfull(transferredTicketId);} );
}

/**
 * Archiveren ticket is succesvol afgehandeld. Verwijder het ticket van het scherm en
 * geef een melding dat het ticket is gearchiveerd door een websocket message te versturen.
 * 
 * @param ticketId
 *            id van het gearchiveerde ticket
 */
function archivateSuccessfull(ticketId)
{
	// Maak en verzend een websocket message
	var actionToPerform = new Object();
	actionToPerform.action = "Archivate";
	actionToPerform.ticketId = ticketId;
	var actionToPerformAsJsonString = JSON.stringify(actionToPerform);
	websockets.send(actionToPerformAsJsonString);
}

/**
 * Archiveren ticket is NIET succesvol afgehandeld. Geef een melding dat het ticket NIET is gearchiveerd.
 * 
 * @param ticketId
 *            id van te archiveren ticket
 */
function archivateNotSuccessfull(ticketId)
{
	alert("Error!! Ticket " + ticketId + " is NIET gearchiveerd");
}

//***********************************************
//********** TOEVOEGEN VAN EEN TICKET ***********
//***********************************************

/**
 * Voegt een ticket toe.
 */
function add()
{
	var ticket = new Object();
	ticket.numberOfHours = $("input[name|='numberOfHours']").val();
	ticket.owner = $("input[name|='owner']").val();
	ticket.description = $("input[name|='description']").val();
	ticket.team = $("input[name|='team']").val();
	var ticketAsJsonString = JSON.stringify(ticket);
	jQuery.post("addTicket", {ticket: ticketAsJsonString}, function() {} )
	      .success(function(data) {
	    	  // De ontvangen 'data' is een JSONObject en bevat de gegevens van het nieuwe ticket (gemaakt in de servlet die de post afhandeld).
	    	  addSuccessfull(data);} )
	      .error(function() {
	    	  addNotSuccessfull();} );
}

/**
 * Toevoegen ticket is succesvol afgehandeld. Voeg het ticket toe op het scherm door een websocket message te versturen.
 * 
 * @param ticket
 *            ticket
 */
function addSuccessfull(ticket)
{
	// Leegmaken rubrieken op het toevoegscherm
	$("input[name|='numberOfHours']").val("");
	$("input[name|='owner']").val("");
	$("input[name|='description']").val("");
	$("input[name|='team']").val("");
	// Maak en verzend een websocket message
	var actionToPerform = new Object();
	actionToPerform.action = "Add";
	actionToPerform.ticketId = ticket.id;
	actionToPerform.ticketOwner = ticket.owner;
	actionToPerform.ticketNumberOfHours = ticket.numberOfHours;
	actionToPerform.ticketDescription = ticket.description;
	actionToPerform.ticketTeam = ticket.team;
	actionToPerform.ticketScrumlane = ticket.scrumlane;
	var actionToPerformAsString = JSON.stringify(actionToPerform);
	websockets.send(actionToPerformAsString);
	// Toon scrumboard
	showScrumboard();
}

/**
 * Toevoegen ticket is NIET succesvol afgehandeld. Geef een melding dat het ticket NIET is toegevoegd.
 */
function addNotSuccessfull()
{
	alert("Error!! Ticket is NIET toegevoegd");
}

//*************************************************
//********** VERWIJDEREN VAN EEN TICKET ***********
//*************************************************

/**
* Verwijdert een ticket.
*/
function removeTicket(toBeRemovedTicketId)
{
	jQuery.get("removeTicket", {ticketId: toBeRemovedTicketId}, function() {} )
	 	  .success(function(data) {
	 		  // De ontvangen 'data' is een JSONObject en bevat het ticketId (gemaakt in de servlet die de get afhandeld).
	 		  var ticketId = data.ticketId;
	 		  removeSuccessfull(ticketId);} )
		  .error(function() {
			  removeNotSuccessfull(toBeRemovedTicketId);} );
}

/**
* Verwijderen ticket is succesvol afgehandeld. Verwijder het ticket van het scherm door een websocket message te versturen.
* 
* @param ticketId
*            id van het verwijderde ticket
*/
function removeSuccessfull(ticketId)
{
	// Maak en verzend een websocket message
	var actionToPerform = new Object();
	actionToPerform.action = "Remove";
	actionToPerform.ticketId = ticketId;
	var actionToPerformAsJsonString = JSON.stringify(actionToPerform);
	websockets.send(actionToPerformAsJsonString);
}

/**
* Verwijderen ticket is NIET succesvol afgehandeld. Geef een melding dat het ticket NIET is verwijderd.
* 
* @param ticketId
*            id van te verwijderen ticket
*/
function removeNotSuccessfull(ticketId)
{
	alert("Error!! Ticket " + ticketId + " is NIET verwijderd");
}

//******************************
//********** DISPLAY ***********
//******************************

function showAddTicket()
{
	// In plaats van dialog kun je ook met hide en show (zie showScrumboard) werken (dan heb je geen jquery-ui nodig).
	// $("#scrumboard").hide();
	$("#addTicket").removeClass("hidden");
	$("#addTicket").dialog({
		draggable : false,
		modal : true,
		resizable : false,
		show : {effect: "fade", duration: 1000},
		width : 500
	});
	// Verberg titel van de jquery dialog
	$(".ui-dialog-titlebar").hide();
}

function showScrumboard()
{
	$("#addTicket").dialog("close");
	$("#addTicket").addClass("hidden");
	// In plaats van dialog kun je ook met hide (zie showAddTicket) en show werken (dan heb je geen jquery-ui nodig).
	// $("#scrumboard").show();
}

//******************************
//********** SUBMITS ***********
//******************************

/**
 * Submit een formulier voor een ticket waarvoor een actie moet worden uitgevoerd.
 * 
 * @param action
 *            uit te voeren actie
 * @param id
 *            id van het ticket waarvoor de actie moet worden uitgevoerd
 */
function doSubmit(action, id)
{
	// alert("action = " + action);
	// alert("ticketid = " + id);
	var actionAndParameters = action + "Ticket?ticketid=" + id;
	// alert("action = " + actionAndParameters);
	$("form#ticketActionsFormId").submit(function() {
		  // gebruik van jquery voor bepalen formid maakt je onafhankelijk van de browser ....
		  // alert("jquery location href " + $(location).attr('href'));
		  // alert("window location href " + window.location.href);
		  // alert("window location pathname = " + window.location.pathname);
		  var shortPathname = '/ScrumboardWebsockets/';
		  // alert("shortPathname = " + shortPathname);
		  window.location.href = (shortPathname + actionAndParameters);
		  return false;
		});
}

//***************************************
//********** OVERIGE FUNCTIES ***********
//***************************************

function geefTijdstip()
{
	var today = new Date();
	alert("tijdstip: " + today);
}