/*!
 * scrumboardtemplates JavaScript Library v1.0
 *
 * Author: Ed Kerkhoven
 */

var scrumboardtemplates = {};

// Settings zetten zodat je in de template met {{veldnaam in JSONObject}} kunt verwijzen naar de datavelden.
_.templateSettings = {interpolate : /\{\{(.+?)\}\}/g};

// De template is een kopie van ticket.jspf. Quotes escapen met een backslash. 
// Het moet 1 string zijn (gerealiseerd door " + aan het einde van een regel te gebruiken).
// Na het </form> een &nbsp; toegevoegd, omdat de images anders tegen elkaar aan komen te staan (oorzaak: onbekend).
scrumboardtemplates.ticket = _.template("<table id=\"{{ticketId}}\" draggable=\"true\" ondragstart=\"drag(event)\">" + 
"<tr>" +
	"<td class=\"bgyellow\" height=\"10\" colspan=\"3\" align=\"right\">" +
		"<form id=\"ticketActionsFormId\" method=\"get\" class=\"inline\">" +
			"<input type=\"image\" title=\"Edit\" src=\"images/EditIcon.png\" width=\"12\" height=\"12\" onclick=\"doSubmit('edit', {{ticketId}})\">" +
		"</form>" +
		"&nbsp;" +
		"<input type=\"image\" title=\"Remove\" src=\"images/DeleteIcon.png\" width=\"12\" height=\"12\" onclick=\"removeTicket({{ticketId}})\">" +
	"</td>" +
"</tr>" +
"<tr>" +
	"<td class=\"bgyellow\">{{ticketNumberOfHours}} uur</td>" +
	"<td class=\"bgyellow\">{{ticketOwner}}</td>" +
	"<td class=\"bgyellow\">#{{ticketId}}</td>" +
"</tr>" +
"<tr>" +
	"<td class=\"bgyellow\" height=\"50px\" colspan=\"3\">{{ticketDescription}}</td>" +
"</tr>" +
"<tr>" +
	"<td class=\"bgaqua\" height=\"10px\" colspan=\"3\">{{ticketTeam}}</td>" +
"</tr>" +
"</table>");
