package nl.scrumboard.servlets;

import nl.scrumboard.util.HTMLFilter;
import nl.ticket.domain.Scrumlane;
import nl.ticket.domain.Ticket;
import nl.ticket.service.TicketService;
import org.apache.commons.lang.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddTicketServlet extends HttpServlet {

	private static final long serialVersionUID = 1374877920955582956L;

	private static final String JSON_VAR_ID = "id";
	private static final String JSON_VAR_OWNER = "owner";
	private static final String JSON_VAR_NUMBEROFHOURS = "numberOfHours";
	private static final String JSON_VAR_DESCRIPTION = "description";
	private static final String JSON_VAR_TEAM = "team";
	private static final String JSON_VAR_SCRUMLANE = "scrumlane";

	@Inject
	private TicketService ticketService;

	@SuppressWarnings("unchecked")
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String ticketAsJsonString = request.getParameter("ticket");
		// Never trust the client
		String filteredMessage = HTMLFilter.filter(ticketAsJsonString);

		// Omdat de message een json-string is, moeten de quotes worden teruggezet
		String jsonStringMessage = StringUtils.replace(filteredMessage, "&quot;", "\"");

		// Zet json-string met ticket-gegevens om naar JSONObject
		Object obj = JSONValue.parse(jsonStringMessage);
		JSONObject ticketAsJsonObject = (JSONObject) obj;

		// Voeg ticket toe
		Ticket ticket = convertJSONObjectToTicket(ticketAsJsonObject);
		String ticketId = ticketService.addTicket(ticket);

		// Voeg id en scrumlane toe aan ticketAsJsonObject
		ticketAsJsonObject.put(JSON_VAR_ID, ticketId);
		ticketAsJsonObject.put(JSON_VAR_SCRUMLANE, Scrumlane.TODO.toString());

		// Retourneer nieuwe ticket als JSONObject
		response.setContentType("application/json");
		response.getWriter().println(ticketAsJsonObject);
	}

	/**
	 * Converteert JSONObject met ticketgegevens naar een ticket.
	 * 
	 * @param ticketAsJsonObject
	 *            JSONObject met ticketgegevens
	 * @return ticket
	 */
	private Ticket convertJSONObjectToTicket(JSONObject ticketAsJsonObject) {
		String owner = (String) ticketAsJsonObject.get(JSON_VAR_OWNER);
		String numberOfHours = (String) ticketAsJsonObject.get(JSON_VAR_NUMBEROFHOURS);
		String description = (String) ticketAsJsonObject.get(JSON_VAR_DESCRIPTION);
		String team = (String) ticketAsJsonObject.get(JSON_VAR_TEAM);
		Ticket ticket = new Ticket(null, owner, Integer.parseInt(numberOfHours), description, team, Scrumlane.TODO);
		return ticket;
	}

}
