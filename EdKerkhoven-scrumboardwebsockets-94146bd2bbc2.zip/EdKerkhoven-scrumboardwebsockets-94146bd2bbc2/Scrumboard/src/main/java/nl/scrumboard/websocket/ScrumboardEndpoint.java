package nl.scrumboard.websocket;

import nl.scrumboard.util.HTMLFilter;
import org.apache.commons.lang.StringUtils;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.Set;

/**
 * Created by ejk on 08-11-14.
 */
@ServerEndpoint("/scrumboardWebsockets")
public class ScrumboardEndpoint {

    @OnOpen
    public void open(Session session, EndpointConfig config) {
        System.out.println("Connectie [" + session.toString() + "] geopend");
    }

    @OnMessage
    public void message(Session session, String msg) {
        // Never trust the client
        String filteredMessage = HTMLFilter.filter(msg.toString());
        // Omdat de message een json-string is, moeten de quotes worden teruggezet
        String jsonStringMessage = StringUtils.replace(filteredMessage, "&quot;", "\"");
        // Verstuur message naar alle connections
        Set<Session> sessions = session.getOpenSessions();
        for (Session sessie : sessions) {
            try {
                sessie.getBasicRemote().sendText(jsonStringMessage);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @OnClose
    public void close(Session session, CloseReason reason) {
        System.out.println("Connectie [" + session.toString() + "] gesloten omdat [" + reason + "]");
    }

    @OnError
    public void error(Session session, Throwable t) {
        t.printStackTrace();
    }

}
