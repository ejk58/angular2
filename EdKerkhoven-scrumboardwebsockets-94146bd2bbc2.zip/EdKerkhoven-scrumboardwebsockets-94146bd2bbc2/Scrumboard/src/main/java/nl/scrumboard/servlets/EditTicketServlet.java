package nl.scrumboard.servlets;

import nl.ticket.domain.Ticket;
import nl.ticket.service.TicketService;

import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class EditTicketServlet extends HttpServlet {

	private static final long serialVersionUID = 1374877920955582956L;

	@Inject
	private TicketService ticketService;

	@Inject
	private Ticket ticket;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Haal ticket op
		String ticketId = request.getParameter("ticketid");
		ticket = ticketService.readTicket(ticketId);
		// Zet ticket op request
		request.setAttribute("ticket", ticket);
		// Toon wijzigen ticket scherm
		RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/jsp/editTicket.jsp");
		requestDispatcher.forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Haal ticket nogmaals op
		String id = request.getParameter("id");
		Ticket ticket = ticketService.readTicket(id);
		// Indien nog aanwezig, muteer ticket
		if (ticket != null) {
			ticket.setOwner(request.getParameter("owner"));
			ticket.setNumberOfHours(Integer.parseInt(request.getParameter("numberOfHours")));
			ticket.setDescription(request.getParameter("description"));
			ticket.setTeam(request.getParameter("team"));
			ticketService.changeTicket(ticket);
		} else {
			throw new RuntimeException("Te wijzigen ticket " + id + " niet meer aanwezig");
		}
		// Toon scrumboard scherm
		RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/start");
		requestDispatcher.forward(request, response);
	}

}
