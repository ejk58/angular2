package nl.scrumboard.servlets;

import nl.ticket.domain.Scrumlane;
import nl.ticket.domain.Ticket;
import nl.ticket.service.TicketService;

import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class ScrumboardServlet extends HttpServlet {

	private static final long serialVersionUID = 716619031866685852L;

	@Inject
	private TicketService ticketService;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Haal scrumboard gegevens op
		Scrumlane[] scrumlanes = Scrumlane.values();
		List<Ticket> ticketsTodo = ticketService.readTicketsByScrumlane(Scrumlane.TODO);
		List<Ticket> ticketsDoing = ticketService.readTicketsByScrumlane(Scrumlane.DOING);
		List<Ticket> ticketsDone = ticketService.readTicketsByScrumlane(Scrumlane.DONE);
		// Zet scrumboard gegevens op request
		request.setAttribute("scrumlanes", scrumlanes);
		request.setAttribute("ticketsTodo", ticketsTodo);
		request.setAttribute("ticketsDoing", ticketsDoing);
		request.setAttribute("ticketsDone", ticketsDone);
		// Toon scherm
		RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/jsp/scrumboard.jsp");
		requestDispatcher.forward(request, response);
	}

}
