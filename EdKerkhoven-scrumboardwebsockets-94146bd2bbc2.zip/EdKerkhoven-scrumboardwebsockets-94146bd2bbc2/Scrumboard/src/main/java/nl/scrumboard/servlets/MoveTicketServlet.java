package nl.scrumboard.servlets;

import nl.ticket.domain.Scrumlane;
import nl.ticket.service.TicketService;
import org.json.simple.JSONObject;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class MoveTicketServlet extends HttpServlet {

	private static final long serialVersionUID = -3561961147112183328L;

	@Inject
	private TicketService ticketService;

	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Verplaats ticket (pas scrumlane aan)
		String ticketId = request.getParameter("ticketId");
		String scrumlaneDescription = request.getParameter("scrumlane");
		ticketService.moveTicket(ticketId, Scrumlane.getScrumlane(scrumlaneDescription));
		// Retourneer id en nieuwe scrumlane van het verplaatste ticket als JSONObject
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("ticketId", ticketId);
		jsonObject.put("newScrumlane", Scrumlane.getScrumlane(scrumlaneDescription).toString());
		response.setContentType("application/json");
		response.getWriter().println(jsonObject);
	}

}
