package nl.scrumboard.servlets;

import nl.ticket.service.TicketService;
import org.json.simple.JSONObject;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class RemoveTicketServlet extends HttpServlet {

	private static final long serialVersionUID = 1374877920955582956L;

	@Inject
	private TicketService ticketService;

	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Verwijder ticket
		String ticketId = request.getParameter("ticketId");
		ticketService.removeTicket(ticketId);
		// Retourneer id van verwijderde ticket als JSONObject
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("ticketId", ticketId);
		response.setContentType("application/json");
		response.getWriter().println(jsonObject);
	}

}
