package nl.ticket.service;

import java.util.Collections;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import nl.ticket.annotations.JsonFileImpl;
import nl.ticket.comparators.TicketIdComparator;
import nl.ticket.dao.TicketDao;
import nl.ticket.domain.Scrumlane;
import nl.ticket.domain.Ticket;

@Singleton
public class TicketServiceImpl implements TicketService {

	@Inject
	@JsonFileImpl
	TicketDao ticketDao;

	@Override
	public List<Ticket> readAllTickets() {
		List<Ticket> tickets = ticketDao.readAllTickets();
		Collections.sort(tickets, new TicketIdComparator());
		return tickets;
	}

	@Override
	public List<Ticket> readTicketsByScrumlane(Scrumlane scrumlane) {
		List<Ticket> tickets = ticketDao.readTicketsByScrumlane(scrumlane);
		Collections.sort(tickets, new TicketIdComparator());
		return tickets;
	}

	@Override
	public Ticket readTicket(String id) {
		return ticketDao.readTicket(id);
	}

	@Override
	public String addTicket(Ticket ticket) {
		return ticketDao.addTicket(ticket);
	}

	@Override
	public void changeTicket(Ticket ticket) {
		ticketDao.changeTicket(ticket);
	}

	@Override
	public void moveTicket(String id, Scrumlane scrumlane) {
		Ticket ticket = ticketDao.readTicket(id);
		ticket.setScrumlane(scrumlane);
		ticketDao.changeTicket(ticket);
	}

	@Override
	public void removeTicket(String id) {
		ticketDao.removeTicket(id);
	}

	@Override
	public void archivateTicket(String id) {
		ticketDao.archivateTicket(id);
	}

}
