package nl.ticket.comparators;

import java.util.Comparator;

import nl.ticket.domain.Ticket;

/**
 * Comparator om tickets oplopend op ticket-id te kunnen sorteren.
 */
public class TicketIdComparator implements Comparator<Ticket> {

	@Override
	public int compare(Ticket ticket1, Ticket ticket2) {
		int ticket1Id = 0;
		int ticket2Id = 0;
		if (ticket1 != null && ticket1.getId() != null) {
			ticket1Id = Integer.parseInt(ticket1.getId());
		}
		if (ticket2 != null && ticket2.getId() != null) {
			ticket2Id = Integer.parseInt(ticket2.getId());
		}
		if (ticket1Id < ticket2Id) {
			return -1;
		} else if (ticket1Id > ticket2Id) {
			return 1;
		}
		return 0;
	}

}
