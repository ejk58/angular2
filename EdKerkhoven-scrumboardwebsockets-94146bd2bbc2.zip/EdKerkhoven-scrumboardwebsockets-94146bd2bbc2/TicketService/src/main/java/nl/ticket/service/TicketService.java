package nl.ticket.service;

import java.util.List;

import nl.ticket.domain.Scrumlane;
import nl.ticket.domain.Ticket;

public interface TicketService {

	public List<Ticket> readAllTickets();

	public List<Ticket> readTicketsByScrumlane(Scrumlane scrumlane);

	public Ticket readTicket(String id);

	public String addTicket(Ticket ticket);

	public void changeTicket(Ticket ticket);

	public void moveTicket(String id, Scrumlane scrumlane);

	public void removeTicket(String id);

	public void archivateTicket(String id);

}
