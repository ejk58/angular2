package nl.ticket.dao;

import nl.ticket.annotations.JsonFileImpl;
import nl.ticket.domain.Scrumlane;
import nl.ticket.domain.Ticket;
import nl.ticket.predicates.ScrumlanePredicate;
import nl.ticket.util.TicketFileUtils;
import nl.ticket.util.TicketJsonConverter;
import org.apache.commons.collections.CollectionUtils;
import org.json.simple.JSONObject;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Singleton
@JsonFileImpl
public class TicketDaoJsonFileImpl implements TicketDao {

	/** Hoogst uitgegeven ticket-id */
	private int highestAssignedTicketId = 0;

	@Inject
	private TicketJsonConverter ticketJsonConverter;

	public TicketDaoJsonFileImpl() {
		super();
		highestAssignedTicketId = TicketFileUtils.getHighestAssignedTicketId();
	}

	@Override
	public List<Ticket> readAllTickets() {
		File directory = new File(TicketFileUtils.TICKETS_DIRECTORY_NAME);
		List<Ticket> tickets = new ArrayList<Ticket>();
		for (File file : directory.listFiles()) {
			JSONObject jsonObject = TicketFileUtils.readTicketFile(file);
			Ticket ticket = ticketJsonConverter.convertJSONObjectToTicket(jsonObject);
			tickets.add(ticket);
		}
		return tickets;
	}

	@Override
	public List<Ticket> readTicketsByScrumlane(Scrumlane scrumlane) {
		List<Ticket> tickets = readAllTickets();
		ScrumlanePredicate scrumlanePredicate = new ScrumlanePredicate(scrumlane);
		CollectionUtils.filter(tickets, scrumlanePredicate);
		return tickets;
	}

	@Override
	public Ticket readTicket(String id) {
		File file = TicketFileUtils.getTicketFile(id);
		JSONObject jsonObject = TicketFileUtils.readTicketFile(file);
		Ticket ticket = ticketJsonConverter.convertJSONObjectToTicket(jsonObject);
		return ticket;
	}

	@Override
	public String addTicket(Ticket ticket) {
		increaseHighestAssignedTicketId();
		ticket.setId("" + highestAssignedTicketId);
		JSONObject jsonObject = ticketJsonConverter.convertTicketToJSONObject(ticket);
		File file = TicketFileUtils.getTicketFile(ticket.getId());
		TicketFileUtils.writeNewTicketFile(file, jsonObject);
		return ticket.getId();
	}

	@Override
	public void changeTicket(Ticket ticket) {
		JSONObject jsonObject = ticketJsonConverter.convertTicketToJSONObject(ticket);
		File file = TicketFileUtils.getTicketFile(ticket.getId());
		TicketFileUtils.writeChangedTicketFile(file, jsonObject);
	}

	@Override
	public void removeTicket(String id) {
		File file = TicketFileUtils.getTicketFile(id);
		TicketFileUtils.deleteTicketFile(file);
	}

	@Override
	public void archivateTicket(String id) {
		TicketFileUtils.moveTicketFileToArchiveDirectory(id);
	}

	/**
	 * Verhoogt het hoogste uitgegeven ticket-id met 1.
	 */
	private synchronized void increaseHighestAssignedTicketId() {
		highestAssignedTicketId++;
	}

}
