package nl.ticket.predicates;

import nl.ticket.domain.Scrumlane;
import nl.ticket.domain.Ticket;

import org.apache.commons.collections.Predicate;

/**
 * Selecteert tickets op basis van een opgegeven scrumlane.
 */
public class ScrumlanePredicate implements Predicate {

	private final Scrumlane scrumlane;

	public ScrumlanePredicate(Scrumlane scrumlane) {
		super();
		this.scrumlane = scrumlane;
	}

	@Override
	public boolean evaluate(Object obj) {
		Ticket ticket = (Ticket) obj;
		if (ticket.getScrumlane().equals(scrumlane)) {
			return true;
		}
		return false;
	}

}
