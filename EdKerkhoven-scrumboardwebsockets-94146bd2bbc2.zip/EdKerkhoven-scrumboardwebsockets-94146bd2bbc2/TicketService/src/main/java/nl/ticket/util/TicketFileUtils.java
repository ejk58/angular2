package nl.ticket.util;

import org.apache.commons.lang.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;

public class TicketFileUtils {

	public static final String TICKETS_DIRECTORY_NAME = "/Users/ejk/Documents/ScrumboardTickets";
	public static final String TICKETS_ARCHIVE_DIRECTORY_NAME = "/Users/ejk/Documents/ScrumboardTicketsArchief";
	private static final String FILE_PREFIX_TICKET = "ticket";
	private static final String FILE_EXTENSION_JSON = ".json";
	private static final String FORWARD_SLASH = "/";

	private static final JSONParser JSONPARSER = new JSONParser();

	/**
	 * Geeft (de verwijzing naar) een file voor de ticketgegevens.
	 * 
	 * @param id
	 *            ticket-id
	 * @return (de verwijzing naar) een file voor de ticketgegevens
	 */
	public static final File getTicketFile(String id) {
		String fileName = FILE_PREFIX_TICKET + id + FILE_EXTENSION_JSON;
		return new File(TICKETS_DIRECTORY_NAME + FORWARD_SLASH + fileName);
	}

	/**
	 * Leest een file met ticketgegevens (in json-formaat).
	 * 
	 * @param file
	 *            verwijzing naar de file met ticketgegevens
	 * @return jsonObject met ticketgegevens
	 */
	public static final JSONObject readTicketFile(File file) {
		JSONObject jsonObject = null;
		try {
			FileReader fileReader = new FileReader(file);
			Object obj = JSONPARSER.parse(fileReader);
			jsonObject = (JSONObject) obj;
			fileReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return jsonObject;
	}

	/**
	 * Maakt een nieuwe file aan met ticketgegevens (in json-formaat).
	 * 
	 * @param file
	 *            verwijzing naar de file met ticketgegevens
	 * @param jsonObject
	 *            jsonObject met ticketgegevens
	 */
	public static final void writeNewTicketFile(File file, JSONObject jsonObject) {
		try {
			file.createNewFile();
			FileWriter newFile = new FileWriter(file);
			newFile.write(jsonObject.toJSONString());
			newFile.flush();
			newFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Wijzigt de file met ticketgegevens (in json-formaat).
	 * 
	 * @param file
	 *            verwijzing naar de file met ticketgegevens
	 * @param jsonObject
	 *            jsonObject met ticketgegevens
	 */
	public static final void writeChangedTicketFile(File file, JSONObject jsonObject) {
		try {
			FileWriter fileWriter = new FileWriter(file);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write(jsonObject.toJSONString());
			bufferedWriter.close();
			fileWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Verwijdert een file met ticketgegevens (in json-formaat).
	 * 
	 * @param file
	 *            verwijzing naar de file met ticketgegevens
	 */
	public static final void deleteTicketFile(File file) {
		// file.delete() werkt alleen goed als je OVERAL netjes je readers/writers hebt gesloten !!!!!!!!
		// anders blijft er iets open staan en lukt het verwijderen niet (zonder een hele duidelijke fout) !!!!!!!
		boolean fileDeleted = file.delete();
		if (!fileDeleted) {
			throw new RuntimeException("Verwijderen ticketfile " + file.getName() + " is niet gelukt");
		}
	}

	/**
	 * Verplaatst een file met ticketgegevens naar de archief directory.
	 * 
	 * @param ticketId
	 *            id van het ticket
	 */
	public static final void moveTicketFileToArchiveDirectory(String ticketId) {
		String fileName = FILE_PREFIX_TICKET + ticketId + FILE_EXTENSION_JSON;
		File oldFile = new File(TICKETS_DIRECTORY_NAME + FORWARD_SLASH + fileName);
		File newFile = new File(TICKETS_ARCHIVE_DIRECTORY_NAME + FORWARD_SLASH + fileName);
		oldFile.renameTo(newFile);
	}

	/**
	 * Geeft het hoogst uitgegeven ticket-id.
	 * 
	 * @return hoogst uitgegeven ticket-id (0 als er geen tickets aanwezig zijn)
	 */
	public static final int getHighestAssignedTicketId() {
		int highestTicketId = 0;
		// Actieve tickets
		File activeDirectory = new File(TICKETS_DIRECTORY_NAME);
		int highestActiveTicketId = getHighestTicketIdInDirectory(activeDirectory);
		highestTicketId = highestTicketId < highestActiveTicketId ? highestActiveTicketId : highestTicketId;
		// Gearchiveerde tickets
		File archiveDirectory = new File(TICKETS_ARCHIVE_DIRECTORY_NAME);
		int highestArchivatedTicketId = getHighestTicketIdInDirectory(archiveDirectory);
		highestTicketId = highestTicketId < highestArchivatedTicketId ? highestArchivatedTicketId : highestTicketId;
		// Retourneer hoogst uitgegeven ticket-id
		return highestTicketId;
	}

	/**
	 * Geeft het hoogste ticket-id van de tickets in een directory.
	 * 
	 * @param directory
	 *            directory waar tickets in staan
	 * @return hoogste ticket-id (0 als er geen tickets aanwezig zijn)
	 */
	private static final int getHighestTicketIdInDirectory(File directory) {
		int highestTicketId = 0;
		for (File file : directory.listFiles()) {
            if (StringUtils.startsWith(file.getName(), FILE_PREFIX_TICKET)) {
                // Alleen ticket-files verwerken
                String id = StringUtils.removeStart(file.getName(), FILE_PREFIX_TICKET);
                id = StringUtils.removeEnd(id, FILE_EXTENSION_JSON);
                int currentTicketId = Integer.parseInt(id);
                if (currentTicketId > highestTicketId) {
                    highestTicketId = currentTicketId;
                }
            }
		}
		return highestTicketId;
	}

}
