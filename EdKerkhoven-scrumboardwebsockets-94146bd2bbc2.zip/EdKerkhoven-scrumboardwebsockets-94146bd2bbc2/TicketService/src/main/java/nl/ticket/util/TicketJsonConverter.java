package nl.ticket.util;

import nl.ticket.domain.Scrumlane;
import nl.ticket.domain.Ticket;

import org.json.simple.JSONObject;

public class TicketJsonConverter {

	private static final String JSON_VAR_ID = "id";
	private static final String JSON_VAR_OWNER = "owner";
	private static final String JSON_VAR_NUMBEROFHOURS = "numberOfHours";
	private static final String JSON_VAR_DESCRIPTION = "description";
	private static final String JSON_VAR_TEAM = "team";
	private static final String JSON_VAR_SCRUMLANE = "scrumlane";

	/**
	 * Zet een jsonObject met ticketgegevens om naar een ticket-object.
	 * 
	 * @param jsonObject
	 *            jsonObject met ticketgegevens
	 * @return ticket
	 */
	public final Ticket convertJSONObjectToTicket(JSONObject jsonObject) {
		String id = (String) jsonObject.get(JSON_VAR_ID);
		String owner = (String) jsonObject.get(JSON_VAR_OWNER);
		Long numberOfHours = (Long) jsonObject.get(JSON_VAR_NUMBEROFHOURS);
		String description = (String) jsonObject.get(JSON_VAR_DESCRIPTION);
		String team = (String) jsonObject.get(JSON_VAR_TEAM);
		Scrumlane scrumlane = Scrumlane.getScrumlane((String) jsonObject.get(JSON_VAR_SCRUMLANE));
		Ticket ticket = new Ticket(id, owner, numberOfHours.intValue(), description, team, scrumlane);
		return ticket;
	}

	/**
	 * Zet een ticket-object om naar een jsonObject met ticketgegevens.
	 * 
	 * @param ticket
	 *            ticket
	 * @return jsonObject met ticketgegevens
	 */
	@SuppressWarnings("unchecked")
	public final JSONObject convertTicketToJSONObject(Ticket ticket) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(JSON_VAR_ID, ticket.getId());
		jsonObject.put(JSON_VAR_OWNER, ticket.getOwner());
		jsonObject.put(JSON_VAR_NUMBEROFHOURS, ticket.getNumberOfHours());
		jsonObject.put(JSON_VAR_DESCRIPTION, ticket.getDescription());
		jsonObject.put(JSON_VAR_TEAM, ticket.getTeam());
		jsonObject.put(JSON_VAR_SCRUMLANE, ticket.getScrumlane().getDescription());
		return jsonObject;
	}

}
