package nl.ticket.dao;

import java.util.List;

import nl.ticket.domain.Scrumlane;
import nl.ticket.domain.Ticket;

public interface TicketDao {

	public List<Ticket> readAllTickets();

	public List<Ticket> readTicketsByScrumlane(Scrumlane scrumlane);

	public Ticket readTicket(String id);

	public String addTicket(Ticket ticket);

	public void changeTicket(Ticket ticket);

	public void removeTicket(String id);

	public void archivateTicket(String id);

}
