import { Component, OnInit } from '@angular/core';
import {UserApi} from '../users/user-api';
import {Router} from '@angular/router';
import {ConfigurationService} from '../services/configuration.service';

@Component({
  selector: 'ivfw-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.scss']
})
export class TopBarComponent implements OnInit {

  constructor(
    private userApi: UserApi,
    private router: Router,
    private configService: ConfigurationService
  ) {
  }

  ngOnInit(): void {
  }

  getUser(): string {
    return this.userApi.getUsername();
  }

  signOut(): void {
    this.userApi.signOut().subscribe( () => {
      this.router.navigate([this.userApi.getSignInRoute()]);
    });
  }

  hideLinkToBelastingdient(): boolean {
    return this.configService.hideLinkToBelastingdienst;
  }
}
