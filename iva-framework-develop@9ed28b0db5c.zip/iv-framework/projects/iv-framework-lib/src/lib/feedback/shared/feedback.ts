import {VersionInformation} from './version-information';
export interface Feedback {
  naam: string;
  email: string;
  melding: string;
  pagina: string;
  versionInformation?: VersionInformation; 
}
