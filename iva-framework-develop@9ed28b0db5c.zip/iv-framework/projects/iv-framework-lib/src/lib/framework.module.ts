import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ContentComponent} from './content/content.component';
import {TitleBarComponent} from './title-bar/title-bar.component';
import {StatusBarComponent} from './status-bar/status-bar.component';
import {MenuComponent} from './menus/menu/menu.component';
import {MenuItemComponent} from './menus/menu-item/menu-item.component';
import {FrameworkBodyComponent} from './framework-body/framework-body.component';
import {RouterModule} from '@angular/router';
import {TopBarComponent} from './top-bar/top-bar.component';
import {SignInComponent} from './users/sign-in/sign-in.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MenuService} from './services/menu.service';
import {ConfigurationService} from './services/configuration.service';
import {ScreenService} from './services/screen.service';
import {DynamicFormComponent} from './dynamic-forms/dynamic-form/dynamic-form.component';
import {DynamicFieldComponent} from './dynamic-forms/dynamic-field/dynamic-field.component';
import {PopupMenuComponent} from './menus/popup-menu/popup-menu.component';
import {AutofocusDirective} from './directives/autofocus.directive';
import {PanelComponent} from './panels/panel/panel.component';
import {FeedbackComponent} from './feedback/feedback.component';
import {MenuHideVerticalComponent} from './menus/menu-hide-vertical/menu-hide-vertical.component';
import {ContentWithMenuComponent} from './content-with-menu/content-with-menu.component';
import {TabViewModule} from 'primeng/tabview';
import {AuthGuard} from './users/auth.guard';

@NgModule({
  declarations: [
    ContentComponent,
    TitleBarComponent,
    StatusBarComponent,
    MenuComponent,
    MenuItemComponent,
    MenuHideVerticalComponent,
    FrameworkBodyComponent,
    TopBarComponent,
    SignInComponent,
    DynamicFormComponent,
    DynamicFieldComponent,
    PopupMenuComponent,
    AutofocusDirective,
    PanelComponent,
    FeedbackComponent,
    ContentWithMenuComponent
  ],
    imports: [
        CommonModule,
        RouterModule,
        FormsModule,
        ReactiveFormsModule,
        TabViewModule
    ],
  exports: [
    FrameworkBodyComponent,
    DynamicFormComponent,
    DynamicFieldComponent,
    PanelComponent,
    ContentWithMenuComponent,
    AutofocusDirective
  ],
  providers: [
    AuthGuard,
    MenuService,
    ConfigurationService,
    ScreenService
  ]
})
export class FrameworkModule { }
