import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';

@Injectable()
export abstract class UserApi {

  abstract getSignInRoute(): string;

  abstract getAuthenticatedRoute(): string;

  abstract isSignedIn(): boolean;

  abstract getUsername(): string | null;

  abstract signIn(username: string, password: string): Observable<any>;

  abstract signOut(): Observable<any>;
}
