import {CanActivate, Router} from '@angular/router';
import {Injectable} from '@angular/core';
import {UserApi} from './user-api';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private userApi: UserApi, private router: Router) {
  }

  canActivate(): boolean {
    if (!this.userApi.isSignedIn()) {
      this.router.navigate([this.userApi.getSignInRoute()]);
    }
    return this.userApi.isSignedIn();
  }
}
