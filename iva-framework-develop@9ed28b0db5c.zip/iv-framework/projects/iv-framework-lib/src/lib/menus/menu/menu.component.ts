import { Component, OnInit } from '@angular/core';
import {MenuService} from '../../services/menu.service';
import {ConfigurationService} from "../../services/configuration.service";

@Component({
  selector: 'ivfw-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {

  constructor(
    public menuService: MenuService,
    private configService: ConfigurationService) { }

  ngOnInit(): void {
  }

  hideButton(): boolean {
    return this.configService.hideButtonToSwitchVerticalMenuToTopStyle;
  }
}
