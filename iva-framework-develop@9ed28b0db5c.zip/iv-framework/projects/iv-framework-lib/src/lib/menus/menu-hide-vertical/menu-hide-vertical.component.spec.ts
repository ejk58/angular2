import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuHideVerticalComponent } from './menu-hide-vertical.component';

describe('MenuHideVerticalComponent', () => {
  let component: MenuHideVerticalComponent;
  let fixture: ComponentFixture<MenuHideVerticalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenuHideVerticalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuHideVerticalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
