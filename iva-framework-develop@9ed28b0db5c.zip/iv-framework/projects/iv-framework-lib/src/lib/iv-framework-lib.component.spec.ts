import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvFrameworkLibComponent } from './iv-framework-lib.component';

describe('IvFrameworkLibComponent', () => {
  let component: IvFrameworkLibComponent;
  let fixture: ComponentFixture<IvFrameworkLibComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IvFrameworkLibComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IvFrameworkLibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
