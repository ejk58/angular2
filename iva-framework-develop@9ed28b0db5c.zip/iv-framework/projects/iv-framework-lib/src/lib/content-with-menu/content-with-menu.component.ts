import {Component, Input, OnInit} from '@angular/core';
import {IvMenuItem} from '../shared/iv-menu-item';


@Component({
  selector: 'ivfw-content-with-menu',
  templateUrl: './content-with-menu.component.html',
  styleUrls: ['./content-with-menu.component.css']
})
export class ContentWithMenuComponent implements OnInit {
  @Input()
  title: string;

  @Input()
  menuItems: IvMenuItem[];

  constructor() { }

  ngOnInit(): void {
  }

}
