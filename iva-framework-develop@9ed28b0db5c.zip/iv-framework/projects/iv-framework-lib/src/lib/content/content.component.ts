import {Component, OnInit} from '@angular/core';
import {MenuService} from '../services/menu.service';
import {ScreenService} from '../services/screen.service';
import {ConfigurationService} from '../services/configuration.service';

@Component({
  selector: 'ivfw-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.scss']
})
export class ContentComponent implements OnInit {

  showHideLeftSideMenuViaContentButton = true;

  constructor(
    public menuService: MenuService,
    public screenService: ScreenService,
    private configService: ConfigurationService
  ) {
  }

  ngOnInit(): void {
    this.showHideLeftSideMenuViaContentButton = this.configService.showMenuButtonShowHideMenuVertical;
  }

  showLeftMenu(): boolean {
    if (this.configService.showMenuButtonShowHideMenuVertical) {
      return this.showHideLeftSideMenuViaContentButton && this.menuService.showingLeftSideMenu;
    }
    return this.menuService.isVertical && this.screenService.isLarge()
      || this.menuService.showingLeftSideMenu && !this.screenService.isLarge();
  }

}
