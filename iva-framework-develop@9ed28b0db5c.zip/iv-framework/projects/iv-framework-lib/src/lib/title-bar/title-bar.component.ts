import {Component, OnInit} from '@angular/core';
import {ConfigurationService} from '../services/configuration.service';
import {ScreenService} from '../services/screen.service';
import {MenuService} from '../services/menu.service';

@Component({
  selector: 'ivfw-title-bar',
  templateUrl: './title-bar.component.html',
  styleUrls: ['./title-bar.component.scss']
})
export class TitleBarComponent implements OnInit {

  constructor(public configService: ConfigurationService,
              public screenService: ScreenService,
              public menuService: MenuService) { }

  ngOnInit(): void {
  }

}
