import {Injectable} from '@angular/core';

export interface  FrameworkConfigSettings {
  applicationName?: string;
  useFeedback?: boolean;
  hideLinkToBelastingdienst?: boolean;
  hideButtonToSwitchVerticalMenuToTopStyle?: boolean; // button in Left vertical menu to switch to top or horizontal menu
  showLeftIconForMenuItem?: boolean;
  showMenuButtonShowHideMenuVertical?: boolean;
}

@Injectable()
export class ConfigurationService {

  applicationName = 'ApplicationName';
  useFeedback = false;

  // Top Bar
  hideLinkToBelastingdienst = true;

  // Vertical Menu
  hideButtonToSwitchVerticalMenuToTopStyle = true;

  showLeftIconForMenuItem = false;
  showMenuButtonShowHideMenuVertical = true;

  allowedOnRightMenuIcons = ['fas fa-search'];

  configure(settings: FrameworkConfigSettings): void {
    Object.assign(this, settings);
  }

  allowedOnRightSide(icon: string): string {
    return this.allowedOnRightMenuIcons.includes(icon) ? icon + ' menu-item__show-right' : '';
  }
}
