import {Injectable} from '@angular/core';

export interface MenuItem {
  text: string,
  route: string,
  icon?: string,
  submenu?: Array<MenuItem>
}

@Injectable()
export class MenuService {

  items: Array<MenuItem> = new Array<MenuItem>();
  isVertical = true;
  showingLeftSideMenu = true;

  toggleLeftSideMenu(): void {
    this.isVertical = true;
    this.showingLeftSideMenu = !this.showingLeftSideMenu;
  }

  toggleMenuOrientation(): void {
    this.isVertical = !this.isVertical;
  }

}
