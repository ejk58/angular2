import {Component} from '@angular/core';
import {ConfigurationService, FrameworkConfigSettings, MenuService} from 'iv-framework-lib';
import {initialMenuItems} from './app.menu';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private menuService: MenuService,
              private configService: ConfigurationService) {

    const config: FrameworkConfigSettings = {
      applicationName: 'Showcase',
      useFeedback: true,
      hideLinkToBelastingdienst: true, /*todo: set back to default*/
      hideButtonToSwitchVerticalMenuToTopStyle: true, /*todo: set back to default*/
      showLeftIconForMenuItem: false,  /*todo: set back to default*/
      showMenuButtonShowHideMenuVertical: true /*todo: set back to default*/
    };

    configService.configure(config);

    menuService.items = initialMenuItems;

  }
}
