export const PATH_SIGN_IN = 'signIn';
export const PATH_AUTHENTICATED = 'authenticated';
