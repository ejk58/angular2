import {MenuItem} from 'iv-framework-lib';
import {PATH_AUTHENTICATED} from './app.paths';

export let initialMenuItems: Array<MenuItem> = [
  {
    text: 'Search',
    route: `${PATH_AUTHENTICATED}/dashboard`,
    icon: 'fas fa-search'
  },
  {
    text: 'Niveau 1',
    route: `${PATH_AUTHENTICATED}/datapage`,
    icon: 'fas fa-chart-line'
  },
  {
    text: 'Niveau 1',
    route: null,
    icon: 'fas fa-cog',
    submenu: [
      {
        text: 'Niveau 1',
        route: `${PATH_AUTHENTICATED}/datapage`,
        icon: 'fas fa-list',
      },
      {
        text: 'Settings',
        route: `${PATH_AUTHENTICATED}/settings`,
        icon: 'fas fa-cog',
      }
    ]
  },
  {
    text: 'Countries',
    route: null,
    icon: 'fas fa-flag',
    submenu: [
      {
        text: 'Select',
        route: null,
        submenu: [
          {
            text: 'Switzerland',
            icon: 'fas fa-flag',
            route: `${PATH_AUTHENTICATED}/country-detail/1/details`
          },
          {
            text: 'Luxembourg',
            icon: 'fas fa-flag',
            route: `${PATH_AUTHENTICATED}/country-detail/2/details`
          },
        ]
      },
      {
        text: 'Top 3',
        route: `${PATH_AUTHENTICATED}/country-list/3`,
        icon: 'fas fa-flag',
        submenu: null
      },
      {
        text: 'Top 10',
        route: `${PATH_AUTHENTICATED}/country-list/10`,
        icon: 'fas fa-flag',
        submenu: null
      },
      {
        text: 'All',
        route: `${PATH_AUTHENTICATED}/country-list/0`,
        icon: 'fas fa-flag',
        submenu: null
      }
    ]
  },
  {
    text: 'Maintenance',
    route: null,
    icon: 'fas fa-cog',
    submenu: [
      {
        text: 'Country Maint',
        route: `${PATH_AUTHENTICATED}/country-maint`,
        icon: 'fas fa-list',
      },
      {
        text: 'Settings',
        route: `${PATH_AUTHENTICATED}/settings`,
        icon: 'fas fa-cog',
      }
    ]
  },
]
