import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {AuthGuard, ConfigurationService, FeedbackApi, FrameworkModule, MenuService, UserApi} from 'iv-framework-lib';
import {UserService} from './services/user.service';
import {DashboardComponent} from './dashboard/dashboard.component';
import {AuthenticatedUserComponent} from './authenticated-user/authenticated-user.component';
import {SettingsComponent} from './settings/settings.component';
import { CountryMaintComponent } from './country-maint/country-maint.component';
import { CountryDetailComponent } from './country-detail/country-detail.component';
import { CountryListComponent } from './country-list/country-list.component';
import { CountryPanelComponent } from './panels/country-panel/country-panel.component';
import {FeedbackService} from './services/feedback.service';
import { DatapageComponent } from './datapage/datapage.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    AuthenticatedUserComponent,
    SettingsComponent,
    CountryMaintComponent,
    CountryDetailComponent,
    CountryListComponent,
    CountryPanelComponent,
    DatapageComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FrameworkModule
  ],
  // Dit moet alleen in de showcase, anders beschikbaar door public-api.ts
  providers: [
    MenuService,
    ConfigurationService,
    UserService,
    {
      provide: UserApi,
      useExisting: UserService
    },
    FeedbackService,
    {
      provide: FeedbackApi,
      useExisting: FeedbackService
    },
    AuthGuard,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
