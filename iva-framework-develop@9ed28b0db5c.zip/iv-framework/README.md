# Iv Framework Library

This project contains a responsive SPA framework for your Angular application.
It is based on the Pluralsight course: Building a Responsive SPA Framework With Angular. 

The project contains a library project, with the framework and showcase which uses the library.
It was initially generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.0.3.

##Setup
Run npm install to install the needed npm packages. Then Build the library. Then you can run the showcase.

## Build library
Run `ng build iv-framework-lib` to build the library. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Run showcase
Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The showcase app will automatically reload if you change any of the source files.

## Publish library
https://angular.io/guide/creating-libraries#publishing-your-library (increment version in the package.json)

1. `iv-framework-lib` project uitbreiden met gewenste functionaliteit/bugfix
2. In `iv-framework-showcase` een voorbeeld opnemen van gemaakte code uit stap 1.
3. Changelog uitbreiden
4. Versienummer ophogen  in `projects/iv-framework-lib/package.json`
5. In directory van root `package.json` uitvoeren: `ng build iv-framework-lib --prod`
6. `cd dist/iv-framework-lib && npm publish`

##Usage
Mailtje van Pascal op 15 april 2021:
```
Versie 0.0.13 van iv-framework-lib bevat een aanpassing die je moet meenemen in je applicatie (als je gebruik van deze versie van het framework maakt)

Je moet nu opgeven in je app.component.ts of je van de feedback functionaliteit gebruik wilt maken

const config: FrameworkConfigSettings = {
  applicationName: 'Mijn systeem',
  useFeedback: true
}

Als je feedback wil gebruiken, moet je ook een FeedbackService maken die FeedbackApi implementeert (gelijk aan UserService en UserApi), in KBS en de showcase zie je hier voorbeelden van.
```

This framework contains switchable configuration settings defined in configuration.service.ts you can turn on/off certain display settings/func.

## Further help
To get more help on the framework you can watch the Pluralsight course it is based on.
To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
