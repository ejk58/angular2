## 0.0.28 (2021-10-27)

### Features

Added extra method to the feedback-api to be able to supply application information
The application information is show on the feeback screen
The application information is inserted into the feedback

### Bug Fixes

## 0.0.27 (2021-08-02)


### Features

When a menuoption is selected that contains a route the the browser will navigate to that page. (Unchanged)

When a menuoption is selected that contains a submenu then the browser wil navigate to the page indicates by the first menuoption from that submenu. (Changed)

When a menuoption is selected that contains a submenu and the first element of that submenu also contains a submenu then the browser will nog change the page. (Unchanged)


### Bug Fixes

. . . 
