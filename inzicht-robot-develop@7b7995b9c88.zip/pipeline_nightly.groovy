@Library("GENERIC") _
    pipelineTest_v3 {
       deploymentId = "inzicht"
           robotTestPath = "testsuites"
                   robotArguments = "--include Final --exclude NONE"
                   robotNonCriticals = "--noncritical NONCRITICAL"
                   robotDir = "/srv/jenkins/home/robotframework_322/bin/"
                   environmentChoices = "ont\ntst\nacc"
                   streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
                   pipelineTrigger = [cron('H 21 * * *')]
    }