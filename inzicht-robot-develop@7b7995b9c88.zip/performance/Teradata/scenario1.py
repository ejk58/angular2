query1 = "select finr, naam, naamswijzigingen, rechtsvorm, geslacht, burgerlijke_staat, doelgroep, convenant_fd_tekst, convenant_fd_url, convenant_indiv_tekst, convenant_indiv_url, geboortedatum_d, overlijdensdatum_d, oprichtingsdatum_d, opheffingsdatum_d, faillissementsdatum_d, immigratiedatum_d, emigratiedatum_d, np_ind, convenant_fd_tekst, convenant_indiv_tekst from DG_I_O_50PRO_INZ.p_inz_finrs where finr = {subjectNr:fiscalnumber};"
query2 = "select ingang_d, ondernemers_codes, type_verplichtingen, verval_d, icoon_variant, icoon_subnrs_van_fe, icoon_aangifte_in_fe, icoon_aangifte_onder_zelfde_nr, icoon_zelfstandig_aangifte, icoon_omschrijving from DG_I_O_50PRO_INZ.p_inz_fisc_activ_overz where finr = {subjectNr:fiscalnumber} and middel = 'OB' ;"
query3 = "select handelsnaam, actief_sinds_d, branche_omschr, branche_cd, branche_cd_en_omschr, ingang_d, kvknr, actief_ind, aantal_activiteiten, laatst_actief_d from DG_I_O_50PRO_INZ.p_inz_econ_activiteit where finr = {subjectNr:fiscalnumber} AND laatste_stand_ind = 1 ORDER BY volgnr;"
query4 = "select finr, ingang_d, ondernemers_codes, type_verplichtingen, verval_d, icoon_variant, icoon_zelfstandig_aangifte from DG_I_O_50PRO_INZ.p_inz_fisc_activ_overz where finr = {subjectNr:fiscalnumber} AND middel = 'LH';"
query5 = "select kantoor, segment, entiteit_naam, entiteitNr, finr, entiteitnr, klantcoordinator from DG_I_O_50PRO_INZ.p_inz_finrs where finr = {subjectNr:fiscalnumber};"
query6 = "select voornamen, aanschrijfnaam, vestigingsadres, vestiging_sinds_d from DG_I_O_50PRO_INZ.p_inz_contact where finr = {subjectNr:fiscalnumber};"
query7 = "select finr, ob_becon, ob_doorkiesnr, ob_aangiftesoort, ob_aangiftetijdvak, ob_aangifte_d, vpb_becon, vpb_doorkiesnr, vpb_aangiftesoort, vpb_aangiftetijdvak, vpb_aangifte_d, lh_becon, lh_doorkiesnr, lh_aangiftesoort, lh_aangiftetijdvak, lh_aangifte_d, ih_becon, ih_doorkiesnr, ih_aangiftesoort, ih_aangiftetijdvak, ih_aangifte_d, cur_naam, cur_doorkiesnr, cur_sinds_d from DG_I_O_50PRO_INZ.p_inz_contact where finr = {subjectNr:fiscalnumber};"

a_file = open("finrs.txt", "r")
list_of_lists = [(line.strip()).split() for line in a_file]
a_file.close()

with open("scenario1.csv", "a") as myfile:
    for i in list_of_lists:
        query10 = query1.replace("{subjectNr:fiscalnumber}", i[0])
        query20 = query2.replace("{subjectNr:fiscalnumber}", i[0])
        query30 = query3.replace("{subjectNr:fiscalnumber}", i[0])
        query40 = query4.replace("{subjectNr:fiscalnumber}", i[0])
        query50 = query5.replace("{subjectNr:fiscalnumber}", i[0])
        query60 = query6.replace("{subjectNr:fiscalnumber}", i[0])
        query70 = query7.replace("{subjectNr:fiscalnumber}", i[0])
        myfile.write(str(i[0]) + "|" + query10 + "|" + query20 + "|" + query30 + "|" + query40 + "|" + query50 + "|" + query60 + "|" + query70 + "\n")