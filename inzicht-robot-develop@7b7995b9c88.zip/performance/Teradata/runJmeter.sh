echo -e "\e[33m################################################################"
echo -e "                   Starting Teradata stress test                     "
echo -e "################################################################\e[0m"
echo -e ""
echo -e "\e[93m----------------------------------------------------------------"
echo -e "Running 10 samples / second for 10 minutes"
echo -e "----------------------------------------------------------------\e[0m"
/srv/jmeter5/bin/jmeter -n -Jduration=900 -Jsamples=600 -Jusers=1 -JteradataCsv=scenario1.csv -t Teradata.jmx -l results1.jtl -e -o ./dashboard1

mv -f results*.jtl ./dashboard1
mv -f jmeter.log ./dashboard1


echo -e ""
echo -e "\e[93m----------------------------------------------------------------"
echo -e "Running 100 samples / second for 10 minutes"
echo -e "----------------------------------------------------------------\e[0m"
/srv/jmeter5/bin/jmeter -n -Jduration=900 -Jsamples=6000 -Jusers=1 -JteradataCsv=scenario1.csv -t Teradata.jmx -l results2.jtl -e -o ./dashboard2

mv -f results*.jtl ./dashboard2
mv -f jmeter.log ./dashboard2


echo -e ""
echo -e "\e[93m----------------------------------------------------------------"
echo -e "Running 1000 samples / second for 10 minutes"
echo -e "----------------------------------------------------------------\e[0m"
/srv/jmeter5/bin/jmeter -n -Jduration=900 -Jsamples=60000 -Jusers=1 -JteradataCsv=scenario1.csv -t Teradata.jmx -l results3.jtl -e -o ./dashboard3

mv -f results*.jtl ./dashboard3
mv -f jmeter.log ./dashboard3


echo -e ""
echo -e "\e[33m################################################################"
echo -e "                    Teradata stress test ended                       "
echo -e "################################################################\e[0m"
