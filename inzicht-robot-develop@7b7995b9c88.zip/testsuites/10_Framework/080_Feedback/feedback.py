import http.client
import mimetypes
import certifi
import urllib3
from jira.client import JIRA

def post_feedback(domainname, uri, cookie, feedback, attachment=None):
    # Use this for debugging arguments
    # print("Domain name             : ", domainname)
    # print("URI                     : ", uri)
    # print("Cookie                  : ", cookie)
    # print("Feedback                : ", feedback)
    # print("Attachment              : ", attachment)

    if "9080" in domainname:
    	service_root = domainname.split("//")
    	service_root = service_root[1].split("/")
    	service_root = service_root[0].split(":")
    	host = service_root[0]
    	port = service_root[1]
    	conn = http.client.HTTPConnection(host, port)
    else:
        service_root = domainname.split("//")
        service_root = service_root[1].split("/")
        host = service_root[0]
        conn = http.client.HTTPSConnection(host)
        
    dataList = []
    boundary = 'wL36Yn8afVp8Ag7AmP8qZ0SA4n1v9T'
    dataList.append('--' + boundary)
    dataList.append('Content-Disposition: form-data; name="feedback"')

    dataList.append('Content-Type: {}'.format('multipart/form-data'))
    dataList.append('')
    dataList.append(feedback)
    
    if not(attachment is None):
        dataList.append('--' + boundary)
        dataList.append('Content-Disposition: form-data; name="attachment"; filename={0}'.format(attachment))
	
        fileType = mimetypes.guess_type(attachment)[0] or 'application/octet-stream'
        dataList.append('Content-Type: {}'.format(fileType))
        dataList.append('')
	
        with open(attachment) as f:
                dataList.append(f.read())
                
    dataList.append('--' + boundary + '--')
    dataList.append('')
    print(dataList)
    body = '\r\n'.join(dataList)
    payload = body
    headers = {
        'Cookie': cookie,
        'Content-type': 'multipart/form-data; boundary={}'.format(boundary)
    }

    conn.request("POST", uri, payload, headers)
    res = conn.getresponse()
    data = res.read()
    print(res.status, res.reason)
    return res.status
    

def delete_feedback(jira_server, jira_user, jira_password, jira_query='project = INZREST AND issuetype = Story AND description ~ "robot test"'):
    # Disable SSL warnings because there's something wrong with the jira test server while useing a certificate.
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    jira_server = {'server': jira_server, 'verify': False}
    jira = JIRA(options=jira_server, basic_auth=(jira_user, jira_password))
    
    issues = jira.search_issues(jira_query, maxResults=100)

    for issue in issues:
        issue.delete()
    