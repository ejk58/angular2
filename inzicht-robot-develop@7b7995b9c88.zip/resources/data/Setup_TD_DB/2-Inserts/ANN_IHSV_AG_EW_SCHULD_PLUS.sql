/*Het lukte in squirrel NIET om deze data te laden (exception). Volgens mij wordt déze tabel ook niet gebruit maar 
alleen de _INZ tabel hiervan... Die heeft wél data*/