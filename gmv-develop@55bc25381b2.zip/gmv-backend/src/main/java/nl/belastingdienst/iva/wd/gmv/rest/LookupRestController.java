package nl.belastingdienst.iva.wd.gmv.rest;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.services.LdapService;
import nl.belastingdienst.iva.wd.gmv.domain.AllLookupsDTO;
import nl.belastingdienst.iva.wd.gmv.domain.Lookup;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6Status;
import nl.belastingdienst.iva.wd.gmv.domain.Status;
import nl.belastingdienst.iva.wd.gmv.service.LookupService;

@RestController
@RequestMapping("/api/lookup")
public class LookupRestController extends GMVRestController {

	private final LookupService lookupService;
	private final LdapService ldapService;

	public LookupRestController(LookupService lookupService, LdapService ldapService, Environment env) {
		super(env);
		this.lookupService = lookupService;
		this.ldapService = ldapService;
	}

	@GetMapping
	@CrossOrigin
	public List<Lookup> lookupTabel(@RequestParam LookupService.LookupType tabel) {
		return lookupService.getList(tabel);
	}

	@GetMapping("/all")
	@CrossOrigin
	public AllLookupsDTO lookupTabellen() {
		AllLookupsDTO ret = new AllLookupsDTO();
		ret.setRol(lookupService.getList(LookupService.LookupType.ROL));
		ret.setStatus(lookupService.getList(LookupService.LookupType.STATUS));
		ret.setBelastingMiddel(lookupService.getList(LookupService.LookupType.BELASTINGMIDDEL));
		ret.setHallmark(lookupService.getList(LookupService.LookupType.HALLMARK));
		ret.setBhStatus(lookupService.getList(LookupService.LookupType.BHSTATUS));
		ret.setToedeling(lookupService.getList(LookupService.LookupType.TOEDELING));
		ret.setSignaaldac6Status(lookupService.getList(LookupService.LookupType.SIGNAALDAC6STATUS));
		return ret;
	}

	@GetMapping("/next")
	@CrossOrigin
	public Map<String, List<String>> lookupNextStatus() {
		return Arrays.stream(Status.values())
					 .collect(Collectors.toMap(Status::name, (Status s) -> s.getNextStatus()
																			.stream()
																			.map(Status::name)
																			.collect(Collectors.toList())));
	}

	@GetMapping("/nextsignaaldac6")
	@CrossOrigin
	public Map<String, List<String>> lookupNextSignaalDAC6Status() {
		return Arrays.stream(SignaalDAC6Status.values())
					 .collect(Collectors.toMap(SignaalDAC6Status::name, (SignaalDAC6Status s) -> s.getNextStatus()
																								  .stream()
																								  .map(SignaalDAC6Status::name)
																								  .collect(Collectors.toList())));
	}

	@GetMapping("/user/{search}")
	public List<LdapPerson> getPersonsByUseridOrLastName(@PathVariable("search") String search) {
		List<LdapPerson> ret = ldapService.getPersonByLastNameOrUserId(search);
		for (LdapPerson p : ret) {
			p.setName(String.format("%s (%s)", p.getName(), p.getUserId()));
		}
		return ret;
	}
}
