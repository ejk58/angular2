package nl.belastingdienst.iva.wd.gmv.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum SignaalDAC6Status {

	NEW(1, "Nieuw"),
	INBEHANDELING(2, "In behandeling"),
	DONE(3, "Gereed");

	private final String description;
	private final int order;

	SignaalDAC6Status(int order, String description) {
		this.order = order;
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	public int getOrder() {
		return this.order;
	}

	public List<SignaalDAC6Status> getNextStatus() {
		switch (this) {
		case NEW:
			return Collections.singletonList(INBEHANDELING);
		case INBEHANDELING:
			return Arrays.asList(NEW, DONE);
		case DONE:
			return Collections.singletonList(INBEHANDELING);
		default:
			// Bij DONE_* geen next status
			return new ArrayList<>();
		}
	}
}
