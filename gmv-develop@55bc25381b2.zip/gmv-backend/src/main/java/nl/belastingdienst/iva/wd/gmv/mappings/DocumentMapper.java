package nl.belastingdienst.iva.wd.gmv.mappings;

import org.mapstruct.Mapper;

import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocument;
import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocumentDTO;

@Mapper(componentModel = "spring")
public abstract class DocumentMapper {

	public abstract GekoppeldDocument map(GekoppeldDocumentDTO src);

	public abstract GekoppeldDocumentDTO map(GekoppeldDocument src);

}
