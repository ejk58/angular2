package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.BEHEERDER;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.GEBRUIKER;

import java.io.IOException;
import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import nl.belastingdienst.iva.wd.gmv.domain.document.FilenetDocument;
import nl.belastingdienst.iva.wd.gmv.service.DocumentenService;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/api/documents")
@Configuration
@RequiredArgsConstructor
@RolesAllowed({ GEBRUIKER, BEHEERDER })
public class DocumentRestController {

	private final DocumentenService documentenService;

	@PostMapping("/upload")
	@CrossOrigin
	public void handleFileUpload(@RequestParam MultipartFile file, @RequestParam Integer meldingId,
			@RequestParam(required = false) String omschrijving) throws IOException {
		documentenService.saveUploadedDocument(file, meldingId, omschrijving);
	}

	@GetMapping("/{meldingId}")
	@CrossOrigin
	public List<FilenetDocument> getAllDocuments(@PathVariable Integer meldingId) {
		List<FilenetDocument> filenetDocuments = documentenService.getFilenetDocuments(meldingId);
		filenetDocuments.forEach(d -> d.setGekoppeld(true));
		return filenetDocuments;
	}

	@DeleteMapping("/documents/{meldingId}/document/{docId}")
	@CrossOrigin
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteDocument(@PathVariable Integer meldingId, @PathVariable String docId) {
		documentenService.deleteDocumentFromMelding(meldingId, docId);
	}
}
