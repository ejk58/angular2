package nl.belastingdienst.iva.wd.gmv.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocument;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
@Entity
public class Melding {

	@Id
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String arrangementId;
	private String disclosureId;
	private String belastingMiddellen;
	private String behandelaarId;
	private LocalDate indienDatum;
	private LocalDate implementatieDatum;
	private String samenvatting;
	@Enumerated(EnumType.STRING)
	private Status currentStatus;
	@OneToMany(mappedBy = "melding", orphanRemoval = true, cascade = CascadeType.ALL)
	private List<Persoon> personen;
	@OneToMany(mappedBy = "melding", orphanRemoval = true, cascade = CascadeType.ALL)
	private List<Prioriteit> prioriteiten;
	@OneToMany(mappedBy = "melding", orphanRemoval = true, cascade = CascadeType.ALL)
	private List<StatusLog> statusLogs;
	@OneToMany(mappedBy = "melding", orphanRemoval = true, cascade = CascadeType.ALL)
	private List<GekoppeldDocument> documenten;
	@OneToMany(mappedBy = "melding", orphanRemoval = true, cascade = CascadeType.ALL)
	@MapKey(name = "soort")
	private Map<TextSoort, Text> teksten;
	@ManyToOne()
	private Stroom stroom;

	public Melding() {
		personen = new ArrayList<>();
		prioriteiten = new ArrayList<>();
		statusLogs = new ArrayList<>();
	}
}
