package nl.belastingdienst.iva.wd.gmv.rest.security;

import nl.belastingdienst.iva.common.springboot.security.LoginCredentials;

import lombok.Data;

@Data
public class LoginStroomCredentials extends LoginCredentials {
	private String stroom;
}
