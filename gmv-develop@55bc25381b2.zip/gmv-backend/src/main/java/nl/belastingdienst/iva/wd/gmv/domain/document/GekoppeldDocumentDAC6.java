package nl.belastingdienst.iva.wd.gmv.domain.document;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6;

import lombok.Data;

@Data
@Entity(name = "GEKOPPELD_DOCUMENT_DAC6")
@Table()
public class GekoppeldDocumentDAC6 extends AbstractGekoppeldDocument {

	@ManyToOne
	@JoinColumn(name = "signaal_dac6_id", nullable = false)
	private SignaalDAC6 signaalDAC6;
}
