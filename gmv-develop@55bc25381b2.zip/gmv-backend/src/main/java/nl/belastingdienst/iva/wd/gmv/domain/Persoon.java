package nl.belastingdienst.iva.wd.gmv.domain;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Persoon {

	@Id
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private Integer tin; // BSN/RSIN
	private String naam; // Naam van BSN/RSIN
	@ManyToOne
	@JoinColumn(name = "melding_id", nullable = false)
	private Melding melding;
	@Enumerated(EnumType.STRING)
	private Rol rol;

}
