package nl.belastingdienst.iva.wd.gmv.domain.document;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class GekoppeldDocumentDTO {

	@ApiModelProperty(value = "The identification id of the document", required = true, example = "idd_70A36E6A-0000-C027-AF67-90C8688767F2")
	private String docId;

}
