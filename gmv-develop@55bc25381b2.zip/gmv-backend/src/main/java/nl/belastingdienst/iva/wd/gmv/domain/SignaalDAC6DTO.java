package nl.belastingdienst.iva.wd.gmv.domain;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocumentDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignaalDAC6DTO {

	private Integer id;
	private String behandelaarId;

	@JsonProperty(required = true)
	private String naam;
	@JsonProperty(required = true)
	private String kantoor;
	@JsonProperty(required = true)
	private String segment;
	@JsonProperty(required = true)
	private String belastingMiddellen;
	@JsonProperty(required = true)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private LocalDate datumOntvangen;
	@JsonProperty(required = true)
	private Integer jaar;
	@JsonProperty(required = true)
	@Enumerated(EnumType.STRING)
	private SignaalDAC6Status currentStatus;
	@JsonProperty(required = true)
	private String signaal;
	@JsonProperty(required = true)
	private List<PersoonDAC6DTO> personen;
	@JsonProperty(required = true)
	private String hallmarks;
	@JsonProperty(required = true)
	private List<GekoppeldDocumentDTO> documenten;
	@JsonProperty(required = true)
	private Map<TextSoort, String> teksten;
	@JsonProperty(required = true)
	private String persoonNaam;
	@JsonProperty(required = true)
	private Integer persoonTin;
	@JsonProperty(required = true)
	private String nummer;
}
