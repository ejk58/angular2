package nl.belastingdienst.iva.wd.gmv.service;

import java.io.IOException;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import nl.belastingdienst.iva.wd.gmv.dao.GekoppeldDocumentRepository;
import nl.belastingdienst.iva.wd.gmv.dao.MeldingRepository;
import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocument;

import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
public class DocumentenService extends AbstractDocumentenService {

	private final GekoppeldDocumentRepository gekoppeldDocumentRepository;
	private final MeldingRepository meldingRepository;
	private final MeldingService meldingService;

	public DocumentenService(FilenetClient filenetClient, DocumentViewerRestClient documentViewerRestClient,
			GekoppeldDocumentRepository gekoppeldDocumentRepository, MeldingRepository meldingRepository,
			MeldingService meldingService) {
		super(filenetClient, documentViewerRestClient);
		this.gekoppeldDocumentRepository = gekoppeldDocumentRepository;
		this.meldingRepository = meldingRepository;
		this.meldingService = meldingService;
	}

	public long saveUploadedDocument(MultipartFile file, Integer meldingId, String omschrijving) throws IOException {
		Melding melding = meldingService.getMelding(meldingId);

		String docId = saveInFilenet(file, omschrijving);

		GekoppeldDocument gekoppeldDocument = new GekoppeldDocument();
		gekoppeldDocument.setMelding(melding);
		gekoppeldDocument.setDocId(docId);
		this.gekoppeldDocumentRepository.save(gekoppeldDocument);

		return gekoppeldDocument.getId();
	}

	@Override
	public List<GekoppeldDocument> getGekoppeldeDocuments(Integer meldingId) {
		Melding melding = meldingService.getMelding(meldingId);
		return melding.getDocumenten();
	}

	public void deleteDocumentFromMelding(Integer meldingId, String docId) {
		Melding melding = meldingService.getMelding(meldingId);
		GekoppeldDocument doc = melding.getDocumenten()
									   .stream()
									   .filter(d -> d.getDocId()
													 .equalsIgnoreCase(docId))
									   .findFirst()
									   .orElseThrow(() -> notFound(docId, "Document niet gevonden"));
		melding.getDocumenten().remove(doc);
		meldingRepository.save(melding);
	}
}

