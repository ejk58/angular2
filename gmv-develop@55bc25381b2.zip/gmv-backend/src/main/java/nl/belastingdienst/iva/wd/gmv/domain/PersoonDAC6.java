package nl.belastingdienst.iva.wd.gmv.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity(name = "PERSOON_DAC6")
public class PersoonDAC6 {
	@Id
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private Integer tin; // BSN/RSIN
	private String naam; // Naam van BSN/RSIN
	@ManyToOne
	@JoinColumn(name = "signaal_dac6_id", nullable = false)
	private SignaalDAC6 signaalDAC6;
}
