package nl.belastingdienst.iva.wd.gmv.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PagingMeldingOverzichtDTO {
	Long count;
	List<MeldingDTO> list;
}
