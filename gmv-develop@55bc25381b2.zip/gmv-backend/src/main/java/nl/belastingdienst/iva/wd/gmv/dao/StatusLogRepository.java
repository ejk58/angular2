package nl.belastingdienst.iva.wd.gmv.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.gmv.domain.StatusLog;

@Repository
public interface StatusLogRepository extends JpaRepository<StatusLog, Integer> {
}
