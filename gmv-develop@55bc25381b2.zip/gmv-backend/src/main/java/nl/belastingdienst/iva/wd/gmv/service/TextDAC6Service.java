package nl.belastingdienst.iva.wd.gmv.service;

import java.util.Optional;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.gmv.dao.TextDAC6Repository;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.TextDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.TextSoort;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class TextDAC6Service extends AbstractService{

	private final SignaalDAC6Service signaalDAC6Service;
	private final TextDAC6Repository textDAC6Repository;

	public TextDAC6 updateText(Integer id, String soort, String text) {
		if (!EnumUtils.isValidEnum(TextSoort.class, soort)) {
			throw notFound(soort, "Deze textsoort bestaat niet");
		}
		SignaalDAC6 signaal = signaalDAC6Service.getSignaalDAC6(id);
		Optional<TextDAC6> dup = textDAC6Repository.findBySignaalDAC6_IdAndSoort(id, TextSoort.valueOf(soort));
		if (dup.isPresent()) {
			dup.get()
			   .setText(text);
			return textDAC6Repository.save(dup.get());
		}
		TextDAC6 newText = new TextDAC6();
		newText.setSignaalDAC6(signaal);
		newText.setText(text);
		newText.setSoort(TextSoort.valueOf(soort));
		return textDAC6Repository.save(newText);
	}
}
