package nl.belastingdienst.iva.wd.gmv.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocumentDAC6;

@Repository
public interface GekoppeldDocumentDAC6Repository extends JpaRepository<GekoppeldDocumentDAC6, Integer> {

	List<GekoppeldDocumentDAC6> getAllBySignaalDAC6(SignaalDAC6 signaalDAC6);

}
