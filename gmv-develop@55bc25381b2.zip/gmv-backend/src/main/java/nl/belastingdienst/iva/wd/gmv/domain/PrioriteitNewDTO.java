package nl.belastingdienst.iva.wd.gmv.domain;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrioriteitNewDTO {

	@Enumerated(EnumType.STRING)
	private Hallmark hallmark;
	private Integer prioriteit;

}
