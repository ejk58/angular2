package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.BEHEERDER;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.GEBRUIKER;

import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.gmv.domain.Stroom;
import nl.belastingdienst.iva.wd.gmv.service.StroomService;

@RestController
@RequestMapping("/api/stroom")
public class StroomRestController extends GMVRestController {

	private final StroomService stroomService;

	public StroomRestController(StroomService stroomService, Environment env) {
		super(env);
		this.stroomService = stroomService;
	}

	///////////////////////////////////////////////////////////////////////////
	// Deze functie is niet beveiligd. Wordt gebruikt vòòr de login
	///////////////////////////////////////////////////////////////////////////
	@GetMapping
	public List<Stroom> getStromen() {
		return stroomService.getStromen();
	}

	///////////////////////////////////////////////////////////////////////////
	// Test / demo methode om de current stroom op te halen
	///////////////////////////////////////////////////////////////////////////
	@RolesAllowed({ GEBRUIKER, BEHEERDER })
	@GetMapping("/current")
	public String getCurrentStroom(@RequestHeader(required = false, name = HEADER_STRING) String header) {
		return "\"" + getCurrentStroomFromHeader(header) + "\"";
	}
}
