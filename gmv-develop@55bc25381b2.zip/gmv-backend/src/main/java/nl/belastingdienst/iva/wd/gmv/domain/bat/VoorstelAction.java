package nl.belastingdienst.iva.wd.gmv.domain.bat;

public enum VoorstelAction {
    NEW, VIEW, UPD, DEL
}

