package nl.belastingdienst.iva.wd.gmv.domain.bat;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DecodedToken {
	private String userId;
	private String subject;
	private String naam;
	private String subjectType;
	private String voorstelType;
	private String voorstelAction;
	private String client;
	private String behandelVoorstelReference;
	private Map<String, Object> context = new HashMap<>();
}
