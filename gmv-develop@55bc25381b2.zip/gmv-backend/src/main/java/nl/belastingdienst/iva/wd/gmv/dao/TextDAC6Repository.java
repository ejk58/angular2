package nl.belastingdienst.iva.wd.gmv.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.gmv.domain.TextDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.TextSoort;

@Repository
public interface TextDAC6Repository extends JpaRepository<TextDAC6, Integer> {
	Optional<TextDAC6> findBySignaalDAC6_IdAndSoort(Integer signaalDAC6Id, TextSoort soort);
}
