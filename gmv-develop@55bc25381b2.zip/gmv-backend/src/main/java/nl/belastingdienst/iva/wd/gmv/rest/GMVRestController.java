package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.TOKEN_PREFIX;
import static nl.belastingdienst.iva.wd.gmv.rest.security.JWTLoginStroomFilter.CURRENT_STROOM;

import org.springframework.core.env.Environment;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Log4j2
public abstract class GMVRestController {
	protected final Environment env;

	protected String getCurrentStroomFromHeader(String header) {
		String stroom;
		DecodedJWT decodedJWT = null;

		String token = header.replace(TOKEN_PREFIX, "");
		try {
			decodedJWT = JWT.require(Algorithm.HMAC512(env.getRequiredProperty("jwt.secret")
														  .getBytes()))
							.build()
							.verify(token);

			stroom = decodedJWT.getClaim(CURRENT_STROOM)
							   .asString();
		} catch (Exception e) {
			throw new CommonException("Deze fout kan niet optreden omdat het token al gevalideerd is", e);
		}
		return stroom;
	}
}
