package nl.belastingdienst.iva.wd.gmv.domain;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocumentDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MeldingDTO {

	private Integer id;
	private String behandelaarId;

	@JsonProperty(required = true)
	private String arrangementId; // Reference ID
	@JsonProperty(required = true)
	private String disclosureId; // Reference ID
	@JsonProperty(required = true)
	private String belastingMiddellen;
	@JsonProperty(required = true)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private LocalDate indienDatum;
	@JsonProperty(required = true)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private LocalDate implementatieDatum;
	@JsonProperty(required = true)
	@Enumerated(EnumType.STRING)
	private Status currentStatus;
	@JsonProperty(required = true)
	private String samenvatting;
	@JsonProperty(required = true)
	private List<PersoonDTO> personen;
	@JsonProperty(required = true)
	private List<PrioriteitDTO> prioriteiten;
	@JsonProperty(required = true)
	private List<StatusLogDTO> statusLogs;
	@JsonProperty(required = true)
	private List<GekoppeldDocumentDTO> documenten;
	@JsonProperty(required = true)
	private Map<TextSoort, String> teksten;
}
