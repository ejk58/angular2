package nl.belastingdienst.iva.wd.gmv.domain;

public enum BhStatus {
	NEW("Nieuw"), WITHDRAWN("Ingetrokken"), UNSEEN("Afgewezen"), WAITING("Wachtend"), INPROGRESS("Onderhanden"), COMPLETED(
			"Afgehandeld"), CANCELED("Afgebroken"), @Deprecated DELETED("Niet meer in de GSV"); // Alleen voor testdoeleinden

	private final String description;

	BhStatus(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

}
