package nl.belastingdienst.iva.wd.gmv.domain;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersoonDTO {
	@JsonProperty(required = true)
	private Integer tin; // BSN/RSIN
	@JsonProperty(required = true)
	private String naam; // Naam van BSN/RSIN
	@JsonProperty(required = true)
	@Enumerated(EnumType.STRING)
	private Rol rol;
}
