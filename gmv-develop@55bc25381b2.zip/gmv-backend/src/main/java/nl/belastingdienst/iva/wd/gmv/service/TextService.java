package nl.belastingdienst.iva.wd.gmv.service;

import java.util.Optional;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.gmv.dao.TextRepository;
import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.Text;
import nl.belastingdienst.iva.wd.gmv.domain.TextSoort;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class TextService extends AbstractService{

	private final MeldingService meldingService;
	private final TextRepository textRepository;

	public Text updateText(Integer meldingId, String soort, String text) {
		if (!EnumUtils.isValidEnum(TextSoort.class, soort)) {
			throw notFound(soort, "Deze textsoort bestaat niet");
		}
		Melding melding = meldingService.getMelding(meldingId);
		Optional<Text> dup = textRepository.findByMelding_IdAndSoort(meldingId, TextSoort.valueOf(soort));
		if (dup.isPresent()) {
			dup.get()
			   .setText(text);
			return textRepository.save(dup.get());
		}
		Text newText = new Text();
		newText.setMelding(melding);
		newText.setText(text);
		newText.setSoort(TextSoort.valueOf(soort));
		return textRepository.save(newText);
	}
}
