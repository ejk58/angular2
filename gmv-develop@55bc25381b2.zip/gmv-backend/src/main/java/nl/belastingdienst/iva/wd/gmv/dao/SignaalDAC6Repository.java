package nl.belastingdienst.iva.wd.gmv.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6;

@Repository
public interface SignaalDAC6Repository extends JpaRepository<SignaalDAC6, Integer> {
	@Query("select max(opvoerVolgnr) from SIGNAAL_DAC6 where opvoerJaar = :jaar")
	Integer getMaxInJaar(Integer jaar);
}
