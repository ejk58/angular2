package nl.belastingdienst.iva.wd.gmv.rest.security;

public class SecurityConstants extends nl.belastingdienst.iva.common.springboot.security.SecurityConstants {
	// Een Role is een Role als er ROLE_ voor staat, anders is het een Authority
	// Hoewel ze allebei als authority opgeslagen worden
	public static final String GEBRUIKER = "ROLE_GEBRUIKER";
	public static final String BEHEERDER = "ROLE_BEHEERDER";
}
