package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.BEHEERDER;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.GEBRUIKER;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.security.RolesAllowed;

import org.apache.commons.lang3.NotImplementedException;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.gmv.domain.LazyLoadData;
import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.MeldingDTO;
import nl.belastingdienst.iva.wd.gmv.domain.MeldingNewDTO;
import nl.belastingdienst.iva.wd.gmv.domain.PagingMeldingOverzichtDTO;
import nl.belastingdienst.iva.wd.gmv.mappings.MeldingMapper;
import nl.belastingdienst.iva.wd.gmv.service.MeldingService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/api/melding")
@Configuration
@RolesAllowed({ GEBRUIKER, BEHEERDER })
public class MeldingRestController extends GMVRestController {

	private final MeldingMapper meldingMapper;
	private final MeldingService meldingService;

	public MeldingRestController(MeldingMapper meldingMapper, MeldingService meldingService, Environment env) {
		super(env);
		this.meldingService = meldingService;
		this.meldingMapper = meldingMapper;
	}

	@PostMapping
	@CrossOrigin
	public void createMelding(@RequestHeader(name = HEADER_STRING, required = false) String header,
			@RequestBody MeldingNewDTO body) {
		Melding melding = meldingMapper.map(body);
		meldingService.addMelding(melding, getCurrentStroomFromHeader(header));
	}

	@PostMapping("/overzicht")
	@CrossOrigin
	public PagingMeldingOverzichtDTO getMeldingen(@RequestHeader(name = HEADER_STRING, required = false) String header,
			@RequestBody LazyLoadData lazyLoadData) {
		Long count = meldingService.getMeldingenCount(getCurrentStroomFromHeader(header), lazyLoadData);
		List<Melding> meldingen = meldingService.getMeldingen(getCurrentStroomFromHeader(header), lazyLoadData);
		PagingMeldingOverzichtDTO ret = new PagingMeldingOverzichtDTO();
		ret.setList(meldingen.stream()
							 .map(meldingMapper::map)
							 .collect(Collectors.toList()));
		ret.setCount(count);
		return ret;
	}

	@GetMapping("/{status}")
	@CrossOrigin
	public List<MeldingDTO> getMeldingenWithStatus(@PathVariable("status") String status) {
		throw new NotImplementedException("Nog niet geimplementeerd");
	}

	@PutMapping("/{id}/status/{status}")
	@CrossOrigin
	public MeldingDTO updateMeldingStatus(@PathVariable("id") Integer id, @PathVariable("status") String status) {
		return meldingMapper.map(this.meldingService.setStatus(id, status));
	}

	@GetMapping("/{arrangementId}/{disclusureId}")
	@CrossOrigin
	public MeldingDTO getMelding(@PathVariable("arrangementId") String arrangementId, @PathVariable("disclusureId") String disclusureId) {
		return meldingMapper.map(meldingService.getMelding(arrangementId, disclusureId));
	}

	@GetMapping("/id/{id}")
	@CrossOrigin
	public MeldingDTO getMeldingById(@PathVariable("id") Integer id) {
		return meldingMapper.map(meldingService.getMelding(id));
	}

	@GetMapping("/testdata/{stroom}/{aantal}")
	@CrossOrigin
	public void addTestdata(@PathVariable("stroom") String stroom, @PathVariable("aantal") Integer aantal) {
		meldingService.addTestdata(aantal, stroom);
	}
}
