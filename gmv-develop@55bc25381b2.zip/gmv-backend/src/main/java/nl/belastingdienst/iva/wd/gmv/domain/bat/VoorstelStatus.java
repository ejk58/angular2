package nl.belastingdienst.iva.wd.gmv.domain.bat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VoorstelStatus {
	private String behandelvoorstelReference;
	private String status;
}
