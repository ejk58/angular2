package nl.belastingdienst.iva.wd.gmv.exception;

import static org.springframework.http.HttpStatus.Series.CLIENT_ERROR;
import static org.springframework.http.HttpStatus.Series.SERVER_ERROR;

import java.io.IOException;

import org.apache.cxf.helpers.IOUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import nl.belastingdienst.iva.common.springboot.exceptions.ConfigurationException;
import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
public class BatErrorHandler implements ResponseErrorHandler {
	private static final String ONBEKENDE_APIKEY = "BAT toegang is geweigerd vanwege onbekende apikey.";
	private static final String METHODE_NIET_TOEGESTAAN = "BAT methode niet toegestaan";
	private final String method; // Via ReqArgs

	@Override
	public boolean hasError(ClientHttpResponse httpResponse) throws IOException {
		return (httpResponse.getStatusCode()
							.series() == CLIENT_ERROR || httpResponse.getStatusCode()
																	 .series() == SERVER_ERROR);
	}

	@Override
	public void handleError(ClientHttpResponse httpResponse) throws IOException {
		HttpStatus status = httpResponse.getStatusCode();
		if (status.series() == CLIENT_ERROR) {
			switch (status) {
			case FORBIDDEN:
				throw new ConfigurationException(METHODE_NIET_TOEGESTAAN);
			case UNAUTHORIZED:
				throw new ConfigurationException(ONBEKENDE_APIKEY);
			case BAD_REQUEST:
				String body = IOUtils.toString(httpResponse.getBody());
				throw new NotFoundException(null, null, null, body);
			default:
				break;
			}
			throw new ConfigurationException(new StringBuilder().append("Niet succesvolle aanroep naar BAT.")
																.append(" Method: ")
																.append(method)
																.append(" Statuscode: ")
																.append(status)
																.toString());
		}
	}
}
