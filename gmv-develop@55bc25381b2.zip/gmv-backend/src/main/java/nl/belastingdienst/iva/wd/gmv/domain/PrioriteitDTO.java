package nl.belastingdienst.iva.wd.gmv.domain;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrioriteitDTO {

	@JsonProperty(required = true)
	@Enumerated(EnumType.STRING)
	private Hallmark hallmark;
	@JsonProperty(required = true)
	private Integer prioriteit;

}
