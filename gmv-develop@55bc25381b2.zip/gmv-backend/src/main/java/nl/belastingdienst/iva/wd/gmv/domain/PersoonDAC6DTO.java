package nl.belastingdienst.iva.wd.gmv.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersoonDAC6DTO {
	@JsonProperty(required = true)
	private Integer tin;
	@JsonProperty(required = true)
	private String naam;
}
