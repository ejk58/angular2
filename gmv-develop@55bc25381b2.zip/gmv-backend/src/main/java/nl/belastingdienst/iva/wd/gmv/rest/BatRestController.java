package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.BEHEERDER;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.GEBRUIKER;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.security.RolesAllowed;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.bat.BehandelvoorstelResponse;
import nl.belastingdienst.iva.wd.gmv.domain.bat.DecodedToken;
import nl.belastingdienst.iva.wd.gmv.domain.bat.EncodedToken;
import nl.belastingdienst.iva.wd.gmv.domain.bat.EncodedTokenDTO;
import nl.belastingdienst.iva.wd.gmv.domain.bat.StartDTO;
import nl.belastingdienst.iva.wd.gmv.domain.bat.SubjectType;
import nl.belastingdienst.iva.wd.gmv.domain.bat.Voorstel;
import nl.belastingdienst.iva.wd.gmv.domain.bat.VoorstelAction;
import nl.belastingdienst.iva.wd.gmv.service.BatService;
import nl.belastingdienst.iva.wd.gmv.service.MeldingService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/api/bat")
@Configuration
public class BatRestController extends GMVRestController {

	private final BatService batService;
	private final MeldingService meldingService;

	public BatRestController(Environment env, BatService batService, MeldingService meldingService) {
		super(env);
		this.batService = batService;
		this.meldingService = meldingService;
	}

	@PostMapping("/token")
	@CrossOrigin
	@RolesAllowed({ GEBRUIKER, BEHEERDER })
	public EncodedTokenDTO getToken(@RequestBody StartDTO dto) {
		Melding melding = meldingService.getMelding(dto.getMeldingId());
		DecodedToken token = new DecodedToken();
		token.setSubject(dto.getTin());
		token.setSubjectType(SubjectType.PER.name());
		token.setVoorstelAction(VoorstelAction.NEW.name());
		token.setVoorstelType("BOMD6");
		token.setUserId(batService.getBehandelaar());
		token.getContext()
			 .put("arrangementId", melding.getArrangementId());
		token.getContext()
			 .put("disclosureId", melding.getDisclosureId());
		token.getContext()
			 .put("implementatieDatum", melding.getImplementatieDatum()
											   .format(DateTimeFormatter.ISO_LOCAL_DATE));
		token.getContext()
			 .put("indienDatum", melding.getIndienDatum()
										.format(DateTimeFormatter.ISO_LOCAL_DATE));
		token.getContext()
			 .put("samenvatting", melding.getSamenvatting());
		token.getContext()
			 .put("meldingId", melding.getId());
		List<String> hallmarks = melding.getPrioriteiten()
										.stream()
										.map(prioriteit -> prioriteit.getHallmark()
																	 .name())
										.sorted(String::compareToIgnoreCase)
										.collect(Collectors.toList());
		token.getContext()
			 .put("hallmarks", hallmarks);
		EncodedToken ret = null;
		try {
			ret = batService.requestToken(token);
		} catch (NotFoundException e) {
			throw new NotFoundException(null, null, dto.getTin(), "Persoon niet gevonden");
		}
		String rightUrl = batService.getBaseUrl()
									.replace("/api", "#/token/");
		String localRightUrl = rightUrl.replace("8081", "4201");
		return new EncodedTokenDTO(ret.getToken(), localRightUrl);
	}

	@PostMapping("/voorstel")
	@CrossOrigin
	@RolesAllowed({ GEBRUIKER, BEHEERDER })
	public List<Voorstel> getVoorstel(@RequestBody StartDTO[] personen) {
		List<Voorstel> ret = new ArrayList<>();
		for (StartDTO startDTO : personen) {
			BehandelvoorstelResponse a = batService.getVoorstellen(startDTO.getTin());
			if (!a.getBehandelopdrachtenMDR()
				  .isEmpty()) {
				ret.addAll(a.getBehandelopdrachtenMDR()
							.stream()
							.filter(bo -> bo.getMeldingId()
											.intValue() == startDTO.getMeldingId()
																   .intValue())
							.map(voorstel -> new Voorstel(startDTO.getTin(), voorstel.getBehandelVoorstelReference(),
									voorstel.getMeldingId(), voorstel.getStatus(), voorstel.getToedeling()))
							.collect(Collectors.toList()));
			}
		}
		return ret;
	}

	@GetMapping("/status/{voorstelId}")
	@CrossOrigin
	@RolesAllowed({ GEBRUIKER, BEHEERDER })
	public Voorstel getStatus(@PathVariable String voorstelId) {
		return batService.getStatus(voorstelId);
	}
}
