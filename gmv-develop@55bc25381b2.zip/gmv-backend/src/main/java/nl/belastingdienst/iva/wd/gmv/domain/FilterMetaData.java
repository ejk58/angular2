package nl.belastingdienst.iva.wd.gmv.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FilterMetaData {
	String value;
	String matchMode;
	String operator;

	@Override
	public String toString() {
		return "{" + "val='" + value + '\'' + '}';
	}
}
