package nl.belastingdienst.iva.wd.gmv.service;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.common.springboot.exceptions.NotPossibleException;

public class AbstractService {
	protected NotPossibleException notPossible(String key, String message) {
		return new NotPossibleException(null, null, key, message);
	}

	protected NotFoundException notFound(String key, String message) {
		return new NotFoundException(null, null, key, message);
	}

	public String getBehandelaar() {
		Authentication authentication = SecurityContextHolder.getContext()
															 .getAuthentication();
		return (authentication == null || authentication.getName()
														.equalsIgnoreCase("anonymousUser")) ? "SWAGGER" : authentication.getName();
	}
}
