package nl.belastingdienst.iva.wd.gmv.mappings;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import nl.belastingdienst.iva.wd.gmv.domain.Hallmark;
import nl.belastingdienst.iva.wd.gmv.domain.PersoonDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.PersoonDAC6DTO;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6DTO;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6NewDTO;
import nl.belastingdienst.iva.wd.gmv.domain.TextDAC6;

@Mapper(componentModel = "spring")
public interface SignaalDAC6Mapper {

	@Mapping(target = "teksten", source = "teksten", ignore = true)
	SignaalDAC6 map(SignaalDAC6DTO src);

	SignaalDAC6 map(SignaalDAC6NewDTO src);

	@Mapping(target = "nummer", expression = "java(String.format(\"%d-%d\", src.getOpvoerJaar(), src.getOpvoerVolgnr()))")
	SignaalDAC6DTO map(SignaalDAC6 src);

	PersoonDAC6DTO map(PersoonDAC6 src);

	default String map(TextDAC6 src) {
		return src.getText();
	}

	default String map(List<Hallmark> value) {
		return value.stream()
					.map(Enum::name)
					.collect(Collectors.joining(","));
	}

	default List<Hallmark> map(String value) {
		if (value == null) return Collections.emptyList();
		return Arrays.stream(value.split(","))
					 .map(name -> Enum.valueOf(Hallmark.class, name))
					 .collect(Collectors.toList());
	}
}
