package nl.belastingdienst.iva.wd.gmv.service;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import nl.belastingdienst.iva.common.springboot.exceptions.NetworkException;
import nl.belastingdienst.iva.wd.gmv.domain.bat.BehandelvoorstelResponse;
import nl.belastingdienst.iva.wd.gmv.domain.bat.DecodedToken;
import nl.belastingdienst.iva.wd.gmv.domain.bat.EncodedToken;
import nl.belastingdienst.iva.wd.gmv.domain.bat.Voorstel;
import nl.belastingdienst.iva.wd.gmv.domain.bat.VoorstelStatus;
import nl.belastingdienst.iva.wd.gmv.exception.BatErrorHandler;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class BatRestClient {
	private static final String BAT_BASE = "bat.base";
	private static final String BAT_APIKEY = "bat.apikey";
	private final Environment env;
	private final ClientHttpRequestFactory httpRequestFactory;

	public EncodedToken requestToken(DecodedToken decodedToken) {
		ResponseEntity<EncodedToken> response = doRestCall(HttpMethod.POST, "/external/start", decodedToken, null,
				EncodedToken.class);
		return response.getBody();
	}

	public BehandelvoorstelResponse getVoorstellen(String subject) {
		String resource = String.format("/external/behandelvoorstel/subject/%s?subjectType=PER", subject);
		ResponseEntity<BehandelvoorstelResponse> response = doRestCall(HttpMethod.GET, resource, null, null,
				BehandelvoorstelResponse.class);
		return response.getBody();
	}

	public Voorstel getStatus(String voorstelId) {
		String resource = String.format("/external/behandelvoorstel/%s/status", voorstelId);
		ResponseEntity<VoorstelStatus> response = doRestCall(HttpMethod.GET, resource, null, null, VoorstelStatus.class);
		VoorstelStatus retBat = response.getBody();
		// Domme constructie is nodig omdat BAT twee schrijfwijzen voor behandelvoorstel hanteert
		return new Voorstel("", retBat.getBehandelvoorstelReference(), 0, retBat.getStatus(), "");
	}

	private <T, U> ResponseEntity<U> doRestCall(HttpMethod httpMethod, String resource, T body, Class<T> requestClazz,
			Class<U> responseClazz) {
		RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
		restTemplate.setErrorHandler(new BatErrorHandler(resource));
		String url = env.getProperty(BAT_BASE) + resource;
		final HttpHeaders headers = new HttpHeaders();
		headers.set("X-APIKEY", env.getProperty(BAT_APIKEY));
		headers.set("Accept", "application/json");
		headers.set("Content-type", "application/json");
		Authentication auth = SecurityContextHolder.getContext()
												   .getAuthentication();
		headers.set("X-USERID", auth.getPrincipal()
									.toString());
		HttpEntity<T> request = new HttpEntity<>(body, headers);
		ResponseEntity<U> response;
		try {
			response = restTemplate.exchange(url, httpMethod, request, responseClazz);
		} catch (RestClientException e) {
			throw new NetworkException(e.getLocalizedMessage());
		}
		if (response.getStatusCode() == BAD_REQUEST) {
			if (response.hasBody()) {
				// alleen loggen als niet voldaan wordt aan de class van de verwachte response
				if (!responseClazz.equals(response.getBody()
												  .getClass())) {
					// niet loggen als voorstel ondertussen is gewijzigd
					String message = ResponseBodyHelper.getMessage(response.getBody(), "detail");
					if (!"Voorstel is in tussentijd gewijzigd".equals(message)) {
						log.error(response.getBody()
										  .toString());
					}
				} else {
					log.error("Er is iets misgegaan met restCall naar bat url: {} body: {}", url, response.getBody());
				}
			} else {
				log.error("Er is iets misgegaan met restCall naar bat url: {}", url);
			}
		}
		return response;
	}

}
