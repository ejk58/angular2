package nl.belastingdienst.iva.wd.gmv.domain;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

@Data
@Entity(name = "TEXT_DAC6")
public class TextDAC6 {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@ManyToOne
	@JoinColumn(name = "signaal_dac6_id", nullable = false)
	private SignaalDAC6 signaalDAC6;
	@Enumerated(EnumType.STRING)
	private TextSoort soort;
	private String text;
}
