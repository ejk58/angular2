package nl.belastingdienst.iva.wd.gmv.domain.document;

import java.util.Arrays;

import org.springframework.util.MimeTypeUtils;

public enum AllowedFileExtension {

    DOC("application/msword"),
    DOCX("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    EML("message/rfc822"),
    JPEG("image/jpg"),
    JPG("image/jpg"),
    MP3("audio/mpeg"),
    MP4("video/mp4"),
    MPG("video/mpg"),
    MXF("application/mxf"),
    ODP("application/vnd.oasis.opendocument.presentation"),
    ODS("application/vnd.oasis.opendocument.spreadsheet"),
    ODT("application/vnd.oasis.opendocument.text"),
    PDF("application/pdf"),
    PNG("image/png"),
    PPT("application/vnd.ms-powerpoint"),
    PPTX("application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    TIF("image/tiff"),
    TIFF("image/tiff"),
    TXT("text/plain"),
    WAV("audio/wav"),
    XBRL("application/xml"),
    XLS("application/vnd.ms-excel"),
    XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    XML("application/xml");

    private final String mimeType;

    AllowedFileExtension(String mimeType) {
        this.mimeType = mimeType;
    }

    public static boolean containsExtension(String extension) {
        String extUpper = extension.toUpperCase();
        return Arrays.stream(AllowedFileExtension.values()).anyMatch(a -> a.name().equals(extUpper));
    }

    public static String findMimeType(String extension) {
        String extUpper = extension.toUpperCase();
        return Arrays.stream(AllowedFileExtension.values()).filter(a -> a.name().equals(extUpper)).findFirst().map(a -> a.mimeType)
                .orElse(MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE);
    }

}
