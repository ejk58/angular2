package nl.belastingdienst.iva.wd.gmv.domain;

public enum Rol {

	DISCLOSER("Discloser"),
	TAXPAYER("Relevant Taxpayer"),
	PERSON("Affected Person"),
	ENTERPRISE("Associated Enterprise"),
	INTERMEDIARY("Intermediary");

	private final String description;

	Rol(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

}
