package nl.belastingdienst.iva.wd.gmv.service;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.gmv.dao.StroomRepository;
import nl.belastingdienst.iva.wd.gmv.domain.Stroom;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class StroomService extends AbstractService {

	private final StroomRepository stroomRepository;

	public List<Stroom> getStromen() {
		return stroomRepository.findByOrderByNaam();
	}

	public Stroom getStroom(String stroomNaam) {
		Stroom stroom = stroomRepository.getByNaam(stroomNaam);
		if (stroom == null) {
			throw notFound(stroomNaam, "Stroom bestaat niet");
		}
		return stroom;
	}
}
