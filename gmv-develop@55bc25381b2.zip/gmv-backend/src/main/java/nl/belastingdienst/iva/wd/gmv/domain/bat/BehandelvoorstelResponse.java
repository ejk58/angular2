package nl.belastingdienst.iva.wd.gmv.domain.bat;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BehandelvoorstelResponse {
	List<Voorstel> behandelopdrachtenMDR;
}
