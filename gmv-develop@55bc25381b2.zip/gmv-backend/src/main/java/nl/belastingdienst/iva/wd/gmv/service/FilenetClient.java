package nl.belastingdienst.iva.wd.gmv.service;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.BindingType;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Scope;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.gmv.domain.document.FilenetDocumentProperties;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class FilenetClient {
	private final Environment env;
	private Session session;

	@Value("${http.client.ssl.trust-store-password}")
	String trustStorePassword;
	@Value("${http.client.ssl.trust-store}")
	Resource trustStore;

	@EventListener(ApplicationReadyEvent.class)
	public void initializeChemistryTruststore() {
		// This action is needed because otherwise the default Java truststore is used
		Path tempFile = null;
		try {
			String tmpDir = System.getProperty("java.io.tmpdir");
			tempFile = Paths.get(tmpDir, "trustStore");
			Files.copy(trustStore.getInputStream(), tempFile, REPLACE_EXISTING);
		} catch (IOException e) {
			log.error("TrustStore not found", e);
		}
		System.setProperty("javax.net.ssl.trustStore", tempFile.toString());
		System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
		log.info("Truststore initialized");
	}

	public Session getSession() {
		if (this.session != null)
			return session;
		SessionFactory factory = SessionFactoryImpl.newInstance();
		Map<String, String> parameters = new HashMap<>();
		parameters.put(SessionParameter.USER, env.getRequiredProperty("filenet.userid"));
		parameters.put(SessionParameter.PASSWORD, env.getRequiredProperty("filenet.password"));
		parameters.put(SessionParameter.ATOMPUB_URL, env.getRequiredProperty("filenet.atompub"));
		parameters.put(SessionParameter.BINDING_TYPE, BindingType.ATOMPUB.value());
		parameters.put(SessionParameter.REPOSITORY_ID, env.getRequiredProperty("filenet.repository"));

		this.session = factory.createSession(parameters);
		return this.session;
	}

	public String saveDocument(FilenetDocumentProperties props, byte[] file) {
		Folder docFolder = (Folder) this.getSession().getObjectByPath(env.getRequiredProperty("filenet.folder"));
		ContentStream contentStream = null;
		contentStream = session.getObjectFactory()
				.createContentStream(props.getFileName(), file.length, props.getMimetype(), new ByteArrayInputStream(file));

		Map<String, Object> properties = generateDocumentProperties(props);

		Document doc = null;
		try {
			doc = docFolder.createDocument(properties, contentStream, VersioningState.MAJOR);
			log.info("Document succesfully uploaded to filenet:" + props);
		} catch (Exception e) {
			log.error("Problem uploading document to filenet:" + props);
			throw e;
		}
		return doc.getId();
	}

	private Map<String, Object> generateDocumentProperties(FilenetDocumentProperties props) {
		Map<String, Object> properties = new HashMap<>();
		properties.put(PropertyIds.NAME, props.getFileName());
		properties.put(PropertyIds.OBJECT_TYPE_ID, "BD_Behandelvoornemen"); //TODO: change type
		properties.put("BD_Taal", "nl");
		properties.put("BD_Documentomschrijving", props.getOmschrijving());
		return properties;
	}
}
