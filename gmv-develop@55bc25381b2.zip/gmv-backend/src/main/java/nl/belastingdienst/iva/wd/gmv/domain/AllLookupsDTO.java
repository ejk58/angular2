package nl.belastingdienst.iva.wd.gmv.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllLookupsDTO {
	@JsonProperty(required = true)
	private List<Lookup> belastingMiddel;
	@JsonProperty(required = true)
	private List<Lookup> rol;
	@JsonProperty(required = true)
	private List<Lookup> status;
	@JsonProperty(required = true)
	private List<Lookup> hallmark;
	@JsonProperty(required = true)
	private List<Lookup> bhStatus;
	@JsonProperty(required = true)
	private List<Lookup> toedeling;
	@JsonProperty(required = true)
	private List<Lookup> signaaldac6Status;
}
