package nl.belastingdienst.iva.wd.gmv.service;

import java.util.LinkedHashMap;

public class ResponseBodyHelper {

	private ResponseBodyHelper() {
		// private constructor to prevent instantiation
	}

	public static String getMessage(Object body, String key) {
		String message = null;
		if (body instanceof LinkedHashMap) {
			LinkedHashMap map = (LinkedHashMap) body;
			Object value = map.get(key);
			if (value instanceof String) {
				message = (String) value;
			} else if (value instanceof Integer) {
				message = String.valueOf(value);
			}
		}
		return message;
	}

}
