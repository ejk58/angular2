package nl.belastingdienst.iva.wd.gmv;

import java.time.LocalDateTime;
import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import nl.belastingdienst.iva.common.springboot.services.LdapService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@SpringBootApplication
@EnableScheduling
public class Application {
    @Autowired
    private Environment env;
    @Autowired
    private CacheManager cacheManager;
    @Autowired
    private ClientHttpRequestFactory clientHttpRequestFactory;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
        PropertySourcesPlaceholderConfigurer propsConfig
                = new PropertySourcesPlaceholderConfigurer();
        propsConfig.setLocation(new ClassPathResource("git.properties"));
        propsConfig.setIgnoreResourceNotFound(true);
        propsConfig.setIgnoreUnresolvablePlaceholders(true);
        return propsConfig;
    }
   @Bean
    public LdapContextSource contextSource() {
        LdapContextSource contextSource = new LdapContextSource();
       contextSource.setUrl(env.getRequiredProperty("ldap.url"));
       contextSource.setUserDn(env.getRequiredProperty("ldap.user"));
       contextSource.setPassword(env.getRequiredProperty("ldap.password"));
       return contextSource;
   }

    @Bean
    public LdapTemplate ldapTemplate() {
        return new LdapTemplate(contextSource());
    }

    @Bean
    public LdapService ldapService() {
        return new LdapService(env, ldapTemplate(), cacheManager);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate(clientHttpRequestFactory);
    }

    @PostConstruct
    public void init() {
        TimeZone.setDefault(TimeZone.getTimeZone("Europe/Amsterdam"));
        log.info("LocalDateTime in {}: {}", TimeZone.getDefault().getDisplayName(), LocalDateTime.now());
    }
}
