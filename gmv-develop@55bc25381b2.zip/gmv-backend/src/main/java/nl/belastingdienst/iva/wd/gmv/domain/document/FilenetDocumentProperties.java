package nl.belastingdienst.iva.wd.gmv.domain.document;

import java.util.Optional;

import org.springframework.util.MimeTypeUtils;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FilenetDocumentProperties {
    private String fileName;
    private String documentSoort;
    private String omschrijving;

    public String getMimetype() {
        Optional<String> extension = getExtension(this.fileName);
        return extension.isPresent() ?
                AllowedFileExtension.findMimeType(extension.get()) :
                MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE;
    }

    private Optional<String> getExtension(String filename) {
        return Optional.ofNullable(filename)
                .filter(f -> f.contains("."))
                .map(f -> f.substring(filename.lastIndexOf(".") + 1));
    }
}
