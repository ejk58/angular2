package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.BEHEERDER;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.GEBRUIKER;

import javax.annotation.security.RolesAllowed;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.gmv.service.TextDAC6Service;
import nl.belastingdienst.iva.wd.gmv.service.TextService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/api/text")
@Configuration
public class TextRestController extends GMVRestController {

	private final TextService textService;
	private final TextDAC6Service textDAC6Service;

	public TextRestController(Environment env, TextService textService, TextDAC6Service textDAC6Service) {
		super(env);
		this.textService = textService;
		this.textDAC6Service = textDAC6Service;
	}

	@PostMapping("/melding/{parentId}/soort/{soort}")
	@CrossOrigin
	@ResponseStatus(HttpStatus.NO_CONTENT)
	@RolesAllowed({ GEBRUIKER, BEHEERDER })
	public void updateText(@PathVariable("parentId") Integer parentId,
			@PathVariable("soort") String soort, @RequestBody String body) {
		textService.updateText(parentId, soort, body);
	}

	@PostMapping("/signaaldac6/{parentId}/soort/{soort}")
	@CrossOrigin
	@ResponseStatus(HttpStatus.NO_CONTENT)
	@RolesAllowed({ GEBRUIKER, BEHEERDER })
	public void updateTextDAC6(@PathVariable("parentId") Integer parentId,
			@PathVariable("soort") String soort, @RequestBody String body) {
		textDAC6Service.updateText(parentId, soort, body);
	}
}
