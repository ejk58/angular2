package nl.belastingdienst.iva.wd.gmv.domain;

public enum Toedeling {
	P("Particulieren"), MKB("Midden- en Kleinbedrijf"), SUC("Successie"), GO("Grote Ondernemingen");

	private final String description;

	Toedeling(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

}
