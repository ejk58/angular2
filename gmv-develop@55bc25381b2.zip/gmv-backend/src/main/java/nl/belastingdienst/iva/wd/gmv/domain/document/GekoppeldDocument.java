package nl.belastingdienst.iva.wd.gmv.domain.document;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import nl.belastingdienst.iva.wd.gmv.domain.Melding;

import lombok.Data;

@Data
@Entity
@Table
public class GekoppeldDocument extends AbstractGekoppeldDocument {

	@ManyToOne
	@JoinColumn(name = "melding_id", nullable = false)
	private Melding melding;
}
