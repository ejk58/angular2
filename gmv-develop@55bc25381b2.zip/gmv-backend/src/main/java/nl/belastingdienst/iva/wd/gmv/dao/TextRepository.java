package nl.belastingdienst.iva.wd.gmv.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.gmv.domain.Text;
import nl.belastingdienst.iva.wd.gmv.domain.TextSoort;

@Repository
public interface TextRepository extends JpaRepository<Text, Integer> {
	Optional<Text> findByMelding_IdAndSoort(Integer meldingId, TextSoort soort);
}
