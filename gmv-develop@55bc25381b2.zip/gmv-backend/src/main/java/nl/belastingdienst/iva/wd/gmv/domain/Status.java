package nl.belastingdienst.iva.wd.gmv.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum Status {

	NEW(1, "Te selecteren"), SELECTED(2, "Geselecteerd"), MDR_SELECTED(3, "Geselecteerd door MDR"), ANALYZING(4,
			"Handmatige analyse"), DONE_NO_REVIEW(5, "Handmatige analyse gereed"), IN_REVIEW(6,
			"Uitzetten voor behandeling"), DONE_REVIEW(7, "Inhoudelijke beoordeling gereed");

	private final String description;
	private final int order;

	Status(int order, String description) {
		this.order = order;
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	public int getOrder() {
		return this.order;
	}

	public List<Status> getNextStatus() {
		switch (this) {
		case NEW:
			return Collections.singletonList(MDR_SELECTED);
		case ANALYZING:
			return Arrays.asList(DONE_NO_REVIEW, IN_REVIEW);
		case IN_REVIEW:
			return Collections.singletonList(DONE_REVIEW);
		case SELECTED:
			return Collections.singletonList(ANALYZING);
		case MDR_SELECTED:
			return Arrays.asList(NEW, ANALYZING);
		case DONE_NO_REVIEW:
			return Arrays.asList(ANALYZING);
		default:
			// Bij DONE_* geen next status
			return new ArrayList<>();
		}
	}
}
