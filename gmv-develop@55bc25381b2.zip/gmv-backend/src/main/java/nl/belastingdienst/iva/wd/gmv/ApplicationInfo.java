package nl.belastingdienst.iva.wd.gmv;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.info.Info;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class ApplicationInfo implements InfoContributor {
    @Autowired
    private Environment env;

    @Override
    public void contribute(Info.Builder builder) {
        Map<String, String> db = new HashMap<>();
        db.put("Url", env.getRequiredProperty("spring.datasource.url"));
        db.put("Schema", env.getRequiredProperty("spring.datasource.hikari.schema"));
        builder.withDetail("Database", db);

        Map<String, String> filenet = new HashMap<>();
        filenet.put("Userid", env.getRequiredProperty("filenet.userid"));
//        filenet.put("Password", env.getRequiredProperty("filenet.password"));
        filenet.put("Atompub", env.getRequiredProperty("filenet.atompub"));
        filenet.put("Folder", env.getRequiredProperty("filenet.folder"));
        filenet.put("Repository", env.getRequiredProperty("filenet.repository"));
        builder.withDetail("Filenet", filenet);

        Map<String, String> searchProxy = new HashMap<>();
        searchProxy.put("Url", env.getRequiredProperty("searchproxy.url"));
        //        searchProxy.put("ApiKey", env.getRequiredProperty("searchproxy.apikey"));
        builder.withDetail("Searchproxy", searchProxy);
    }
}
