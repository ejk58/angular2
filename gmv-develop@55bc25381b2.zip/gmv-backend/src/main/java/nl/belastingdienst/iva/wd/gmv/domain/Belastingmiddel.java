package nl.belastingdienst.iva.wd.gmv.domain;

public enum Belastingmiddel {

	BRB("Bronbelasting"),
	DIVBEL("Dividendbelasting"),
	IH("Inkomstenheffing"),
	LH("Loonheffing"),
	SW("Successiewet"),
	VPB("Vennootschapbelasting"),
	NB("Overig");

	private final String description;

	Belastingmiddel(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

}
