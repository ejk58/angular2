package nl.belastingdienst.iva.wd.gmv.domain;

import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LazyLoadData {
	Integer first;
	Integer rows;
	String sortField;
	Integer sortOrder;
	Map<String, List<FilterMetaData>> filters;
	String globalFilter;

	@Override
	public String toString() {
		return "LazyLoadData{" + "first=" + first + ", rows=" + rows + ", sortField='" + sortField + '\'' + ", sortOrder="
				+ sortOrder + ", filters=" + filters + ", globalFilter='" + globalFilter + '\'' + '}';
	}
}
