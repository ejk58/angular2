package nl.belastingdienst.iva.wd.gmv.domain;

public enum TextSoort {

	OP("Opmerkingen"), AA("Aanpak"), BE("Bevindingen"), CO("Conclusies");

	private final String description;

	TextSoort(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

}
