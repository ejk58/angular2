package nl.belastingdienst.iva.wd.gmv.domain;

public enum Hallmark {

	A1("A1 - Geheimhouding"),
	A2("A2 - No cure, no pay"),
	A3("A3 - Gestandaardiseerde constructie"),

	B1("B1 - Handel in verliesvennootschappen"),
	B2("B2 - Inkomsten omzetten in andere categorie"),
	B3("B3 - Circulaire transacties"),

	C1A("C1 - a) Geen inwoner"),
	C1B1("C1 - b1) Geen VPB"),
	C1B2("C1 - b2) EU zwarte lijst"),
	C1C("C1 - c) Objectvrijstelling"),
	C1D("C1 - d) Gunstregime"),
	C2("C2 - Dubbele afschrijving"),
	C3("C3 - Geen belasting door dubbele voorkoming"),
	C4("C4 - Waardering activa"),

	D1("D1 - CRS verplichting ontwijken"),
	D2("D2 - UBO afschermen"),

	E1("E1 - Gebruik veilige haven regel"),
	E2("E2 - Overdracht moeilijk te waarderen immateriële activa"),
	E3("E3 - Intragroup herstructurering");

	private final String description;

	Hallmark(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

}
