package nl.belastingdienst.iva.wd.gmv.service;

import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import nl.belastingdienst.iva.wd.gmv.domain.document.FilenetDocument;

import io.micrometer.core.annotation.Timed;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class DocumentViewerRestClient {
    private final Environment env;
    private final ClientHttpRequestFactory httpRequestFactory;

    @Timed
    public FilenetDocument findDocument(String queryParameter, String id) {
        String resource = new StringBuilder()
                .append(env.getRequiredProperty("searchproxy.url"))
                .append("docProperties")
                .append("?API_KEY=")
                .append(env.getRequiredProperty("searchproxy.apikey"))
                .append(queryParameter)
                .append(id)
                .toString();

        RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
        ResponseEntity<FilenetDocument> docs = restTemplate.getForEntity(resource, FilenetDocument.class);
        return docs.getBody();
    }

}
