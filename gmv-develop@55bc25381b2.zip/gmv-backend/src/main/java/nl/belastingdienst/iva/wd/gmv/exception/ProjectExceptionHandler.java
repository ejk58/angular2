package nl.belastingdienst.iva.wd.gmv.exception;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.NotImplementedException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import nl.belastingdienst.iva.common.springboot.exceptions.ApiError;
import nl.belastingdienst.iva.common.springboot.exceptions.GenericErrorType;
import nl.belastingdienst.iva.common.springboot.exceptions.GenericExceptionHandler;
import nl.belastingdienst.iva.common.springboot.exceptions.NotAllowedException;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class ProjectExceptionHandler extends GenericExceptionHandler {

	private static final Logger log = LogManager.getLogger(ProjectExceptionHandler.class);

	@Override
	@ExceptionHandler({ AccessDeniedException.class })
	protected ResponseEntity<Object> handleNotAllowed(NotAllowedException ex, HttpServletRequest request) {
		ApiError apiError = new ApiError(GenericErrorType.FORBIDDEN, ex.getMessage(), request.getRequestURI());
		return new ResponseEntity<>(apiError, HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler({ NotImplementedException.class })
	protected ResponseEntity<Object> handleNotImplemented(NotImplementedException ex, HttpServletRequest request) {
		ApiError apiError = new ApiError(GenericErrorType.NOT_POSSIBLE, ex.getMessage(), request.getRequestURI());
		return new ResponseEntity<>(apiError, HttpStatus.NOT_IMPLEMENTED);
	}

	@Override
	@ExceptionHandler({ Exception.class })
	protected ResponseEntity<Object> handleOtherException(Exception ex, HttpServletRequest request) {
		ApiError apiError = new ApiError(GenericErrorType.NOT_ANTICIPATED, "Er is een onverwachte fout opgetreden", request.getRequestURI());
		ResponseEntity<Object> responseEntity = new ResponseEntity<>(apiError, HttpStatus.INTERNAL_SERVER_ERROR);
		log.error("Stacktrace", ex);
		return responseEntity;
	}

}
