package nl.belastingdienst.iva.wd.gmv.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocument;

@Repository
public interface GekoppeldDocumentRepository extends JpaRepository<GekoppeldDocument, Integer> {

	List<GekoppeldDocument> getAllByMelding(Melding melding);

}
