package nl.belastingdienst.iva.wd.gmv.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import nl.belastingdienst.iva.wd.gmv.dao.MeldingRepository;
import nl.belastingdienst.iva.wd.gmv.dao.StatusLogRepository;
import nl.belastingdienst.iva.wd.gmv.domain.Belastingmiddel;
import nl.belastingdienst.iva.wd.gmv.domain.Hallmark;
import nl.belastingdienst.iva.wd.gmv.domain.LazyLoadData;
import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.Persoon;
import nl.belastingdienst.iva.wd.gmv.domain.Prioriteit;
import nl.belastingdienst.iva.wd.gmv.domain.Rol;
import nl.belastingdienst.iva.wd.gmv.domain.Status;
import nl.belastingdienst.iva.wd.gmv.domain.StatusLog;
import nl.belastingdienst.iva.wd.gmv.domain.Stroom;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class MeldingService extends AbstractService {

	private final MeldingRepository meldingRepository;
	private final StatusLogRepository statusLogRepository;
	private final StroomService stroomService;
	private final EntityManager em;

	@Transactional
	public void addMelding(Melding melding, String stroomNaam) {
		checkNewMelding(melding);
		Stroom stroom = stroomService.getStroom(stroomNaam);
		melding.getPersonen()
			   .forEach(persoon -> persoon.setMelding(melding));
		melding.getPrioriteiten()
			   .forEach(prioriteit -> prioriteit.setMelding(melding));

		StatusLog statusLog = new StatusLog();
		statusLog.setMelding(melding);
		statusLog.setStatus(Status.NEW);
		statusLog.setWijzigingsMoment(LocalDateTime.now());
		statusLog.setBehandelaarId(getBehandelaar());

		melding.setStatusLogs(Collections.singletonList(statusLog));
		melding.setStroom(stroom);
		melding.setBehandelaarId(getBehandelaar());

		meldingRepository.save(melding);
	}

	private void checkNewMelding(Melding melding) {
		Optional<Melding> duplicate = meldingRepository.findByArrangementIdAndDisclosureId(melding.getArrangementId(),
				melding.getDisclosureId());
		if (duplicate.isPresent()) {
			throw notPossible(melding.getArrangementId()+" / "+melding.getDisclosureId(), "Arrangement / Disclosure bestaat al");
		}
		if (melding.getBelastingMiddellen() == null) {
			throw notPossible(null, "Belastingmiddel is verplicht");
		}
		boolean middelenOk = Stream.of(melding.getBelastingMiddellen()
											  .split(","))
								   .allMatch(middel -> EnumUtils.isValidEnum(Belastingmiddel.class, middel));
		if (!middelenOk) {
			throw notPossible(melding.getBelastingMiddellen(), "Belastingmiddel bevat een ongeldig middel");
		}
		if (melding.getPersonen()
				   .isEmpty()) {
			throw notPossible(null, "Personen zijn verplicht");
		}
		if (melding.getPrioriteiten()
				   .isEmpty()) {
			throw notPossible(null, "Prioriteiten zijn verplicht");
		}
	}

	public List<Melding> getMeldingen(String stroomNaam, LazyLoadData sel) {
		Query query = getQuery(stroomNaam, sel);
		query.setFirstResult(sel.getFirst());
		query.setMaxResults(sel.getRows());
		return query.getResultList();
	}

	public Long getMeldingenCount(String stroomNaam, LazyLoadData sel) {
		Query query = getCountQuery(stroomNaam, sel);
		return (long) query.getSingleResult();
	}

	private Query getQuery(String stroomNaam, LazyLoadData sel) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Melding> cq = cb.createQuery(Melding.class);
		Root<Melding> from = cq.from(Melding.class);
		buildConditions(stroomNaam, sel, cb, cq, from);
		Order order;
		if (sel.getSortField() != null) {
			Expression expression;
			if (sel.getSortField()
				   .equalsIgnoreCase("prioriteit")) {
				Join<Melding, Prioriteit> joinPrioriteit = from.join("prioriteiten");
				expression = joinPrioriteit.get("prioriteit");
			} else {
				expression = from.get(sel.getSortField());
			}
			order = sel.getSortOrder() == 1 ? cb.asc(expression) : cb.desc(expression);
		} else {
			order = cb.desc(from.get("indienDatum"));
		}
		cq.orderBy(order);
		return em.createQuery(cq);
	}

	private Query getCountQuery(String stroomNaam, LazyLoadData sel) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<Melding> from = cq.from(Melding.class);
		cq.select((cb.count(from)));
		buildConditions(stroomNaam, sel, cb, cq, from);
		return em.createQuery(cq);
	}

	private void buildConditions(String stroomNaam, LazyLoadData sel, CriteriaBuilder cb, CriteriaQuery cq, Root<Melding> from) {
		List<Predicate> andPredicates = new ArrayList<>();
		Join<Melding, Stroom> joinStroom = from.join("stroom");
		Predicate stroomPredicate = cb.equal(joinStroom.get("naam"), stroomNaam);
		andPredicates.add(stroomPredicate);

		String veldNaam = "arrangementId";
		if (isIngevuld(sel, veldNaam)) {
			andPredicates.add(cb.like(from.get(veldNaam), "%" + sel.getFilters()
																   .get(veldNaam)
																   .get(0)
																   .getValue() + "%"));
		}
		veldNaam = "disclosureId";
		if (isIngevuld(sel, veldNaam)) {
			andPredicates.add(cb.like(from.get(veldNaam), "%" + sel.getFilters()
																   .get(veldNaam)
																   .get(0)
																   .getValue() + "%"));
		}
		veldNaam = "status";
		if (isIngevuld(sel, veldNaam)) {
			andPredicates.add(cb.equal(from.get("currentStatus"), Status.valueOf(sel.getFilters()
																					.get(veldNaam)
																					.get(0)
																					.getValue())));
		}
		veldNaam = "belastingMiddellen";
		if (isIngevuld(sel, veldNaam)) {
			andPredicates.add(cb.like(from.get(veldNaam), "%" + sel.getFilters()
																   .get(veldNaam)
																   .get(0)
																   .getValue() + "%"));
		}
		veldNaam = "hallmark";
		if (isIngevuld(sel, veldNaam)) {
			Join<Melding, Prioriteit> joinPrioriteit = from.join("prioriteiten");
			andPredicates.add(cb.equal(joinPrioriteit.get(veldNaam), Hallmark.valueOf(sel.getFilters()
																						 .get(veldNaam)
																						 .get(0)
																						 .getValue())));
		}
		if (sel.getGlobalFilter() != null) {
			Subquery<Persoon> subqueryPersoon = cq.subquery(Persoon.class);
			Root<Persoon> subRoot = subqueryPersoon.from(Persoon.class);
			Predicate existsName = cb.like(cb.lower(subRoot.get("naam")), "%" + sel.getGlobalFilter()
																				   .toLowerCase() + "%");
			Predicate belongsToMelding = cb.equal(subRoot.get("melding"), from.get("id"));
			subqueryPersoon.select(subRoot)
						   .where(belongsToMelding, existsName);
			andPredicates.add(cb.exists(subqueryPersoon));
		}
		cq.where(cb.and(andPredicates.toArray(andPredicates.toArray(new Predicate[0]))));
	}

	private boolean isIngevuld(LazyLoadData sel, String veldNaam) {
		return sel.getFilters() != null && sel.getFilters()
											  .containsKey(veldNaam) && sel.getFilters()
																		   .get(veldNaam)
																		   .get(0)
																		   .getValue() != null;
	}

	public Melding getMelding(String arrangementId, String disclosureId) {
		return meldingRepository.findByArrangementIdAndDisclosureId(arrangementId, disclosureId)
								.orElseThrow(() -> notFound(arrangementId +" / "+disclosureId, "Melding niet gevonden"));
	}

	public Melding getMelding(Integer id) {
		return meldingRepository.findById(id)
								.orElseThrow(() -> notFound(id.toString(), "Melding niet gevonden"));
	}

	public Melding setStatus(Integer id, String status) {
		Melding melding = getMelding(id);
		Status theStatus = Arrays.stream(Status.values())
								 .filter(st -> st.name()
												 .equals(status))
								 .findFirst()
								 .orElseThrow(() -> notFound(status, "Status niet gevonden"));
		if (!melding.getCurrentStatus()
					.getNextStatus()
					.contains(theStatus)) {
			throw notPossible(theStatus.getDescription(), "Nieuwe status is niet toegestaan");
		}
		StatusLog st = new StatusLog();
		st.setStatus(theStatus);
		st.setMelding(melding);
		st.setWijzigingsMoment(LocalDateTime.now());
		st.setBehandelaarId(getBehandelaar());
		statusLogRepository.save(st);
		// Vieze hack, omdat currentStatus met een SP wordt bijgewerkt
		melding.setCurrentStatus(theStatus);
		// Einde hack
		return melding;
	}

	@Transactional
	public void addTestdata(Integer aantal, String stroom) {
		meldingRepository.deleteAll();
		String[] middelen = { "BRB", "IH", "LH", "IH,LH", "IH,BRB" };
		for (int i = 0; i < aantal; i++) {
			Melding m = new Melding();
			m.setArrangementId(String.format("NLA20211101%06d", i));
			m.setDisclosureId(String.format("NLD20211101%06d", i));
			m.setBehandelaarId("wiggj02");
			m.setSamenvatting("samenvatting");
			Integer k = (int) (((float) i / aantal) * (float) middelen.length);
			m.setBelastingMiddellen(middelen[k]);
			m.setImplementatieDatum(LocalDate.now());
			m.setIndienDatum(LocalDate.now());
			Persoon p = new Persoon();
			p.setNaam("naam");
			p.setTin(100000000 - 1 - i);
			p.setRol(Rol.PERSON);
			m.getPersonen()
			 .add(p);
			Prioriteit pr = new Prioriteit();
			pr.setPrioriteit(i * 10);
			k = (int) (((float) i / aantal) * (float) Hallmark.values().length);
			pr.setHallmark(Hallmark.values()[k]);
			m.getPrioriteiten()
			 .add(pr);
			addMelding(m, stroom);
		}
	}
}
