package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.BEHEERDER;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.GEBRUIKER;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.security.RolesAllowed;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.services.LdapService;
import nl.belastingdienst.iva.wd.gmv.domain.LazyLoadData;
import nl.belastingdienst.iva.wd.gmv.domain.PagingSignaalDAC6OverzichtDTO;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6DTO;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6NewDTO;
import nl.belastingdienst.iva.wd.gmv.mappings.SignaalDAC6Mapper;
import nl.belastingdienst.iva.wd.gmv.service.SignaalDAC6Service;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/api/signaaldac6")
@Configuration
@RolesAllowed({ GEBRUIKER, BEHEERDER })
public class SignaalDAC6RestController extends GMVRestController {

	private final SignaalDAC6Mapper signaalMapper;
	private final SignaalDAC6Service signaalDAC6Service;
	private final LdapService ldapService;

	public SignaalDAC6RestController(SignaalDAC6Mapper signaalMapper, SignaalDAC6Service signaalDAC6Service,
			LdapService ldapService, Environment env) {
		super(env);
		this.signaalDAC6Service = signaalDAC6Service;
		this.signaalMapper = signaalMapper;
		this.ldapService = ldapService;
	}

	@PostMapping
	@CrossOrigin
	public void createSignaal(@RequestHeader(name = HEADER_STRING, required = false) String header,
			@RequestBody SignaalDAC6NewDTO body) {
		SignaalDAC6 signaal = signaalMapper.map(body);
		signaalDAC6Service.addSignaalDAC6(signaal);
	}

	@PostMapping("/overzicht")
	@CrossOrigin
	public PagingSignaalDAC6OverzichtDTO getSignalen(@RequestHeader(name = HEADER_STRING, required = false) String header,
			@RequestBody LazyLoadData lazyLoadData) {
		Long count = signaalDAC6Service.getSignalenDAC6Count(lazyLoadData);
		List<SignaalDAC6> signalen = signaalDAC6Service.getSignalenDAC6(lazyLoadData);
		PagingSignaalDAC6OverzichtDTO ret = new PagingSignaalDAC6OverzichtDTO();
		ret.setList(signalen.stream()
							.map(signaalMapper::map)
							.collect(Collectors.toList()));
		ret.setCount(count);
		return ret;
	}

	@PutMapping("/{id}/status/{status}")
	@CrossOrigin
	public SignaalDAC6DTO updateSignaalDAC6Status(@PathVariable("id") Integer id, @PathVariable("status") String status) {
		SignaalDAC6DTO ret = signaalMapper.map(this.signaalDAC6Service.setStatus(id, status));
		return addNaamAndUserid(ret, ldapService);
	}

	private SignaalDAC6DTO addNaamAndUserid(SignaalDAC6DTO ret, LdapService ldapService) {
		LdapPerson melder = ldapService.getPerson(ret.getNaam());
		ret.setNaam(String.format("%s (%s)", melder.getName(), melder.getUserId()));
		return ret;
	}

	@GetMapping("/id/{id}")
	@CrossOrigin
	public SignaalDAC6DTO getSignaalById(@PathVariable("id") Integer id) {
		SignaalDAC6DTO ret = signaalMapper.map(this.signaalDAC6Service.getSignaalDAC6(id));
		return addNaamAndUserid(ret, ldapService);
	}
}
