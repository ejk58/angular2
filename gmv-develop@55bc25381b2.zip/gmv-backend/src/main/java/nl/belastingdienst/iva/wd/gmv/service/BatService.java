package nl.belastingdienst.iva.wd.gmv.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.gmv.domain.bat.BehandelvoorstelResponse;
import nl.belastingdienst.iva.wd.gmv.domain.bat.DecodedToken;
import nl.belastingdienst.iva.wd.gmv.domain.bat.EncodedToken;
import nl.belastingdienst.iva.wd.gmv.domain.bat.Voorstel;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class BatService extends AbstractService {

	private static final String BAT_BASE = "bat.base";
	private final BatRestClient batRestClient;
	@Autowired
	protected Environment env;

	public EncodedToken requestToken(DecodedToken decodedToken) {
		return batRestClient.requestToken(decodedToken);
	}

	public BehandelvoorstelResponse getVoorstellen(String subject) {
		return batRestClient.getVoorstellen(subject);
	}

	public Voorstel getStatus(String voorstelId) {
		return batRestClient.getStatus(voorstelId);
	}

	public String getBaseUrl() {
		return env.getProperty(BAT_BASE);
	}

}
