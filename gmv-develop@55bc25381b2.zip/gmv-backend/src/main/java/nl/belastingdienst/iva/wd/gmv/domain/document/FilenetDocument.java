package nl.belastingdienst.iva.wd.gmv.domain.document;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FilenetDocument {
    private Boolean gekoppeld;
    private String docURL;
    private String finr;
    private String docId;
    private String idType;
    private String uuid;
    private String name;
    private String fileName;
    private String documentType;
    private String werkproces;
    private String richting;
    private String identificatiekenmerk;
    private String documentomSchrijving;
    private String hoofdproces;
    private String maker;
    private String aanmaakdatum;
    private String laatstGewijzigdDoor;
    private String datumLaatsteWijziging;
    private String bron;
    private String datumIndieningDagtekening;
    private String documentklasse;
    private String documenttitel;
    private String beginTijdvak;
    private String eindTijdvak;
    private String documentSoort;
}
