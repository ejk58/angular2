package nl.belastingdienst.iva.wd.gmv.service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.wd.gmv.domain.Belastingmiddel;
import nl.belastingdienst.iva.wd.gmv.domain.BhStatus;
import nl.belastingdienst.iva.wd.gmv.domain.Hallmark;
import nl.belastingdienst.iva.wd.gmv.domain.Lookup;
import nl.belastingdienst.iva.wd.gmv.domain.Rol;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6Status;
import nl.belastingdienst.iva.wd.gmv.domain.Status;
import nl.belastingdienst.iva.wd.gmv.domain.Toedeling;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class LookupService {

	public List<Lookup> getList(LookupType type) {
		switch (type) {
		case BELASTINGMIDDEL:
			return Arrays.stream(Belastingmiddel.values())
						 .map(e -> new Lookup(e.name(), e.getDescription()))
						 .sorted(Comparator.comparing(Lookup::getOmschrijving))
						 .collect(Collectors.toList());
		case ROL:
			return Arrays.stream(Rol.values())
						 .map(e -> new Lookup(e.name(), e.getDescription()))
						 .sorted(Comparator.comparing(Lookup::getOmschrijving))
						 .collect(Collectors.toList());
		case STATUS:
			return Arrays.stream(Status.values())
						 .sorted(Comparator.comparingInt(Status::getOrder))
						 .map(e -> new Lookup(e.name(), e.getDescription()))
						 .collect(Collectors.toList());
		case HALLMARK:
			return Arrays.stream(Hallmark.values())
						 .map(e -> new Lookup(e.name(), e.getDescription()))
						 .sorted(Comparator.comparing(Lookup::getOmschrijving))
						 .collect(Collectors.toList());
		case TOEDELING:
			return Arrays.stream(Toedeling.values())
						 .map(e -> new Lookup(e.name(), e.getDescription()))
						 .sorted(Comparator.comparing(Lookup::getOmschrijving))
						 .collect(Collectors.toList());
		case BHSTATUS:
			return Arrays.stream(BhStatus.values())
						 .map(e -> new Lookup(e.name(), e.getDescription()))
						 .collect(Collectors.toList());
		case SIGNAALDAC6STATUS:
			return Arrays.stream(SignaalDAC6Status.values())
						 .map(e -> new Lookup(e.name(), e.getDescription()))
						 .collect(Collectors.toList());
		default:
			throw new NotFoundException(null, null, type.name(), "Lookup bestaat niet");
		}
	}

	public enum LookupType {
		BELASTINGMIDDEL, ROL, STATUS, SIGNAALDAC6STATUS, HALLMARK, BHSTATUS, TOEDELING
	}
}
