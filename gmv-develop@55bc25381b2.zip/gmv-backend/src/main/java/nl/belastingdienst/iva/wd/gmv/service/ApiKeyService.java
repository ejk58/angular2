package nl.belastingdienst.iva.wd.gmv.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.gmv.dao.ApiKeyRepository;
import nl.belastingdienst.iva.wd.gmv.domain.ApiKey;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class ApiKeyService {

    // @Autowired via Constructor injection door @RequiredArgsConstructor
    private final ApiKeyRepository apiKeyRepository;

    private Map<String, ApiKey> apiKeyCache = new HashMap<>();

    public String getClient(String key) {
        return getApiKey(key).getClient();
    }

    public boolean checkApiKeyForMethod(String key, String method) {
        return getApiKey(key).isMethodAuthorized(method);
    }

    public Stream<String> getTypesStream(String key) {
        if (getApiKey(key).getSignalTypes() == null) {
            return null;
        }
        String[] types = getApiKey(key).getSignalTypes().split(",");
        return Arrays.stream(types);
    }

    private ApiKey getApiKey(String key) {
        ApiKey apiKey = apiKeyCache.get(key);
        if (apiKey == null) {
            throw new BadCredentialsException("Unknown apikey");
        }
        return apiKey;
    }

    @PostConstruct
    @Scheduled(initialDelay = 1000 * 3600, fixedRate = 1000 * 3600)
    public void refresh() {
        log.debug("ApiKeys Refreshing....");
        Map<String, ApiKey> newApiKeys = new HashMap<>();
        for (ApiKey apiKey : this.apiKeyRepository.findAll()) {
            newApiKeys.put(apiKey.getKey(), apiKey);
        }
        this.apiKeyCache = newApiKeys;
    }
}
