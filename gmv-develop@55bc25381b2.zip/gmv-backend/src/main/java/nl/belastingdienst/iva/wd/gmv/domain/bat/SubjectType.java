package nl.belastingdienst.iva.wd.gmv.domain.bat;

public enum SubjectType {
    ENT, PER
}
