package nl.belastingdienst.iva.wd.gmv.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import nl.belastingdienst.iva.wd.gmv.dao.SignaalDAC6Repository;
import nl.belastingdienst.iva.wd.gmv.domain.LazyLoadData;
import nl.belastingdienst.iva.wd.gmv.domain.PersoonDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6;
import nl.belastingdienst.iva.wd.gmv.domain.SignaalDAC6Status;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class SignaalDAC6Service extends AbstractService {

	private final SignaalDAC6Repository signaalDAC6Repository;
	private final EntityManager em;

	@Transactional
	public void addSignaalDAC6(SignaalDAC6 signaalDAC6) {
		checkNewSignaalDAC6(signaalDAC6);
		signaalDAC6.getPersonen()
				   .forEach(persoon -> persoon.setSignaalDAC6(signaalDAC6));
		PersoonDAC6 firstPerson = signaalDAC6.getPersonen()
											 .get(0);
		signaalDAC6.setPersoonNaam(firstPerson.getNaam());
		signaalDAC6.setPersoonTin(firstPerson.getTin());
		signaalDAC6.setBehandelaarId(getBehandelaar());
		signaalDAC6.setCurrentStatus(SignaalDAC6Status.NEW);
		Integer jaar = LocalDate.now()
								.getYear();
		Integer volgnr = signaalDAC6Repository.getMaxInJaar(jaar);
		volgnr = volgnr == null ? 1 : volgnr + 1;
		signaalDAC6.setOpvoerJaar(jaar);
		signaalDAC6.setOpvoerVolgnr(volgnr);
		signaalDAC6Repository.save(signaalDAC6);
	}

	private void checkNewSignaalDAC6(SignaalDAC6 signaalDAC6) {
		if (signaalDAC6.getPersonen()
					   .isEmpty()) {
			throw notPossible(null, "Personen zijn verplicht");
		}
		if (signaalDAC6.getSignaal()
					   .isEmpty()) {
			throw notPossible(null, "Signaal is verplicht");
		}
	}

	public List<SignaalDAC6> getSignalenDAC6(LazyLoadData sel) {
		Query query = getQuery(sel);
		query.setFirstResult(sel.getFirst());
		query.setMaxResults(sel.getRows());
		return query.getResultList();
	}

	public Long getSignalenDAC6Count(LazyLoadData sel) {
		Query query = getCountQuery(sel);
		return (long) query.getSingleResult();
	}

	private Query getQuery(LazyLoadData sel) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<SignaalDAC6> cq = cb.createQuery(SignaalDAC6.class);
		Root<SignaalDAC6> from = cq.from(SignaalDAC6.class);
		buildConditions(sel, cb, cq, from);
		List<Order> orderList = new ArrayList();
		if (sel.getSortField() != null) {
			if (sel.getSortField().equalsIgnoreCase("nummer")) {
				orderList.add(sel.getSortOrder() == 1 ? cb.asc(from.get("opvoerJaar")) : cb.desc(from.get("opvoerJaar")));
				orderList.add(sel.getSortOrder() == 1 ? cb.asc(from.get("opvoerVolgnr")) : cb.desc(from.get("opvoerVolgnr")));
			} else {
				orderList.add(sel.getSortOrder() == 1 ? cb.asc(from.get(sel.getSortField())) : cb.desc(from.get(sel.getSortField())));
			}
		} else {
			orderList.add(cb.desc(from.get("datumOntvangen")));
		}
		cq.orderBy(orderList);
		return em.createQuery(cq);
	}

	private Query getCountQuery(LazyLoadData sel) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<SignaalDAC6> from = cq.from(SignaalDAC6.class);
		cq.select((cb.count(from)));
		buildConditions(sel, cb, cq, from);
		return em.createQuery(cq);
	}

	private void buildConditions(LazyLoadData sel, CriteriaBuilder cb, CriteriaQuery cq, Root<SignaalDAC6> from) {
		List<Predicate> andPredicates = new ArrayList<>();
		String veldNaam = "status";
		if (isIngevuld(sel, veldNaam)) {
			andPredicates.add(cb.equal(from.get("currentStatus"), SignaalDAC6Status.valueOf(sel.getFilters()
																							   .get(veldNaam)
																							   .get(0)
																							   .getValue())));
		}
		addLike(sel, cb, from, andPredicates, "belastingMiddellen");
		addLike(sel, cb, from, andPredicates, "hallmarks");

		if (sel.getGlobalFilter() != null) {
			Subquery<PersoonDAC6> subqueryPersoon = cq.subquery(PersoonDAC6.class);
			Root<PersoonDAC6> subRoot = subqueryPersoon.from(PersoonDAC6.class);
			Predicate existsName = cb.like(cb.lower(subRoot.get("naam")), "%" + sel.getGlobalFilter()
																				   .toLowerCase() + "%");
			Predicate belongsToSignaal = cb.equal(subRoot.get("signaalDAC6"), from.get("id"));
			subqueryPersoon.select(subRoot)
						   .where(belongsToSignaal, existsName);
			andPredicates.add(cb.exists(subqueryPersoon));
		}
		cq.where(cb.and(andPredicates.toArray(andPredicates.toArray(new Predicate[0]))));
	}

	private void addLike(LazyLoadData sel, CriteriaBuilder cb, Root<SignaalDAC6> from, List<Predicate> andPredicates,
			String veldNaam) {
		if (isIngevuld(sel, veldNaam)) {
			andPredicates.add(cb.like(from.get(veldNaam), "%" + sel.getFilters()
																   .get(veldNaam)
																   .get(0)
																   .getValue() + "%"));
		}
	}

	private boolean isIngevuld(LazyLoadData sel, String veldNaam) {
		return sel.getFilters() != null && sel.getFilters()
											  .containsKey(veldNaam) && sel.getFilters()
																		   .get(veldNaam)
																		   .get(0)
																		   .getValue() != null;
	}

	public SignaalDAC6 getSignaalDAC6(Integer id) {
		return signaalDAC6Repository.findById(id)
									.orElseThrow(() -> notFound(id.toString(), "Signaal niet gevonden"));
	}

	public SignaalDAC6 setStatus(Integer id, String status) {
		SignaalDAC6 signaalDAC6 = getSignaalDAC6(id);
		SignaalDAC6Status theStatus = Arrays.stream(SignaalDAC6Status.values())
											.filter(st -> st.name()
															.equals(status))
											.findFirst()
											.orElseThrow(() -> notFound(status, "Status niet gevonden"));
		if (!signaalDAC6.getCurrentStatus()
						.getNextStatus()
						.contains(theStatus)) {
			throw notPossible(theStatus.getDescription(), "Nieuwe status is niet toegestaan");
		}
		signaalDAC6.setCurrentStatus(theStatus);
		signaalDAC6Repository.save(signaalDAC6);
		return signaalDAC6;
	}
}
