package nl.belastingdienst.iva.wd.gmv.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.gmv.domain.Melding;

@Repository
public interface MeldingRepository extends JpaRepository<Melding, Integer> {
	Optional<Melding> findByArrangementIdAndDisclosureId(String arrangementId, String disclosureId);
}
