package nl.belastingdienst.iva.wd.gmv.domain.bat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Voorstel {
	private String subject;
	private String behandelVoorstelReference;
	private Integer meldingId;
	private String status;
	private String toedeling;
}
