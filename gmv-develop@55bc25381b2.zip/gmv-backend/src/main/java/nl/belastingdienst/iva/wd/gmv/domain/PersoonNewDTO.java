package nl.belastingdienst.iva.wd.gmv.domain;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersoonNewDTO {
	private Integer tin; // BSN/RSIN
	private String naam; // Naam van BSN/RSIN
	@Enumerated(EnumType.STRING)
	private Rol rol;
}
