package nl.belastingdienst.iva.wd.gmv.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PagingSignaalDAC6OverzichtDTO {
	Long count;
	List<SignaalDAC6DTO> list;
}
