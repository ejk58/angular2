package nl.belastingdienst.iva.wd.gmv.rest.security;

import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.BEHEERDER;
import static nl.belastingdienst.iva.wd.gmv.rest.security.SecurityConstants.GEBRUIKER;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import nl.belastingdienst.iva.common.springboot.security.JWTAuthorizationFilter;
import nl.belastingdienst.iva.common.springboot.security.RoleMapping;
import nl.belastingdienst.iva.wd.gmv.service.ApiKeyService;

@EnableWebSecurity
public class WebSecurity extends WebSecurityConfigurerAdapter {
	@Autowired
	private LdapTemplate ldapTemplate;
	@Autowired
	private Environment env;
	@Autowired
	private ApiKeyService apiKeyService;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		List<RoleMapping> rollen = new ArrayList<>();
		rollen.add(new RoleMapping("AUG_GMV_DAC6", "DAC6"));
		rollen.add(new RoleMapping("AUG_GMV_DAC6", GEBRUIKER));
		rollen.add(new RoleMapping("AUG_GMV_DAC6_BEHEERDER", BEHEERDER));
		rollen.add(new RoleMapping("AUG_GMV_DAC6_BEHEERDER", GEBRUIKER));
		rollen.add(new RoleMapping("AUG_GMV_TESTSTROOM", "TESTSTROOM"));
		rollen.add(new RoleMapping("AUG_GMV_TESTSTROOM", GEBRUIKER));
		rollen.add(new RoleMapping("AUG_GMV_TESTSTROOM_BEHEERDER", BEHEERDER));
		rollen.add(new RoleMapping("AUG_GMV_TESTSTROOM_BEHEERDER", GEBRUIKER));
		ApikeyAuthorizationFilter apikeyAuthorizationFilter = new ApikeyAuthorizationFilter(apiKeyService);
		apikeyAuthorizationFilter.setFilterProcessesUrl("/api/external/**");
		http.cors()
			.and()
			.csrf()
			.disable()
			.addFilter(apikeyAuthorizationFilter)
			.addFilterBefore(new JWTLoginStroomFilter(env, ldapTemplate, rollen), UsernamePasswordAuthenticationFilter.class)
			.addFilterAfter(new JWTAuthorizationFilter(env), JWTLoginStroomFilter.class)
			// this disables session creation on Spring Security
			.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
	}
}

