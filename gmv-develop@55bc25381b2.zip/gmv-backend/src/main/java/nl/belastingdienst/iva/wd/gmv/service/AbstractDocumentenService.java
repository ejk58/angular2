package nl.belastingdienst.iva.wd.gmv.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import nl.belastingdienst.iva.wd.gmv.domain.document.FilenetDocument;
import nl.belastingdienst.iva.wd.gmv.domain.document.FilenetDocumentProperties;
import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocument;

public abstract class AbstractDocumentenService extends AbstractService {
	protected final FilenetClient filenetClient;
	protected final DocumentViewerRestClient documentViewerRestClient;

	public AbstractDocumentenService(FilenetClient filenetClient, DocumentViewerRestClient documentViewerRestClient) {
		this.filenetClient = filenetClient;
		this.documentViewerRestClient = documentViewerRestClient;
	}

	protected String saveInFilenet(MultipartFile file, String omschrijving) throws IOException {
		FilenetDocumentProperties props = new FilenetDocumentProperties();
		props.setFileName(file.getOriginalFilename());
		props.setDocumentSoort("Notitie");
		props.setOmschrijving(omschrijving != null ? omschrijving : "");
		String docId = filenetClient.saveDocument(props, file.getBytes());
		return docId;
	}

	public List<FilenetDocument> getFilenetDocuments(Integer meldingId) {
		List<FilenetDocument> filenetDocuments = new ArrayList<>();
		getGekoppeldeDocuments(meldingId).forEach(gekoppeldDocument -> {
			if (gekoppeldDocument.getDocId()
								 .startsWith("idd_")) {
				FilenetDocument filenetDocument = documentViewerRestClient.findDocument("&fnObjId=", gekoppeldDocument.getDocId());
				filenetDocument.setDatumIndieningDagtekening(filenetDocument.getDatumLaatsteWijziging());
				filenetDocuments.add(filenetDocument);
			} else {
				filenetDocuments.add(documentViewerRestClient.findDocument("&uuid=", gekoppeldDocument.getDocId()));
			}
		});
		return filenetDocuments;
	}

	public abstract List<GekoppeldDocument> getGekoppeldeDocuments(Integer parentId);
}
