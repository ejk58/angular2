package nl.belastingdienst.iva.wd.gmv.mappings;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.MeldingDTO;
import nl.belastingdienst.iva.wd.gmv.domain.MeldingNewDTO;
import nl.belastingdienst.iva.wd.gmv.domain.Persoon;
import nl.belastingdienst.iva.wd.gmv.domain.PersoonDTO;
import nl.belastingdienst.iva.wd.gmv.domain.Prioriteit;
import nl.belastingdienst.iva.wd.gmv.domain.PrioriteitDTO;
import nl.belastingdienst.iva.wd.gmv.domain.Text;

@Mapper(componentModel = "spring")
public abstract class MeldingMapper {

	@Mapping(target = "teksten", source = "teksten", ignore = true)
	public abstract Melding map(MeldingDTO src);

	public abstract Melding map(MeldingNewDTO src);

	public abstract MeldingDTO map(Melding src);

	public abstract PrioriteitDTO map(Prioriteit src);

	public abstract PersoonDTO map(Persoon src);

	public String map(Text src) {
		return src.getText();
	}
}
