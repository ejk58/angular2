package nl.belastingdienst.iva.wd.gmv.rest.security;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_APIKEY;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import nl.belastingdienst.iva.wd.gmv.service.ApiKeyService;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class ApikeyAuthorizationFilter extends UsernamePasswordAuthenticationFilter {
	ApiKeyService apiKeyService;

	public ApikeyAuthorizationFilter(ApiKeyService apiKeyService) {
		this.apiKeyService = apiKeyService;
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
		String apiKeyFromHeader = request.getHeader(HEADER_APIKEY);
		if (this.requiresAuthentication(request, response) && !getCleanMethodName(request).equalsIgnoreCase("mih")) {
			String cleanMethod = getCleanMethodName(request);
			log.debug("Check autorisatie voor {} ", cleanMethod);
			UsernamePasswordAuthenticationToken authentication = null;
			try {
				if (apiKeyService.checkApiKeyForMethod(apiKeyFromHeader, cleanMethod)) {
					if (apiKeyService.getTypesStream(apiKeyFromHeader) != null && apiKeyService.getTypesStream(apiKeyFromHeader).count() > 0) {
						List<GrantedAuthority> grants = apiKeyService.getTypesStream(apiKeyFromHeader).map(
								SimpleGrantedAuthority::new).collect(Collectors.toList());
						authentication = new UsernamePasswordAuthenticationToken(apiKeyService.getClient(apiKeyFromHeader), null, grants);
					}
				} else {
					((HttpServletResponse) res).setStatus(HttpStatus.FORBIDDEN.value());
                    return;
                }
            } catch (BadCredentialsException be) {
				log.info("Onbekende apikey gebruikt", be);
				((HttpServletResponse) res).setStatus(HttpStatus.UNAUTHORIZED.value());
				return;
			}
			SecurityContextHolder.getContext().setAuthentication(authentication);
		}
		chain.doFilter(req, res);
	}

	private String getCleanMethodName(HttpServletRequest request) {
		String cleanMethod = request.getRequestURI().replaceAll("V[0-9]*$", "");
		cleanMethod = cleanMethod.replaceAll("/api/external/", "");
		int slashPosition = cleanMethod.indexOf('/');
		if (slashPosition > 0) {
			cleanMethod = cleanMethod.substring(0, slashPosition);
		}
		return cleanMethod;
	}
}
