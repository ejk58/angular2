package nl.belastingdienst.iva.wd.gmv.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocumentDAC6;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
@Entity(name = "SIGNAAL_DAC6")
public class SignaalDAC6 {

	@Id
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String naam;
	private String kantoor;
	private String segment;
	private String behandelaarId;
	private String belastingMiddellen;
	private Integer jaar;
	private LocalDate datumOntvangen;
	private String signaal;
	private String hallmarks;
	private String persoonNaam;
	private Integer persoonTin;
	private Integer opvoerJaar;
	private Integer opvoerVolgnr;
	@Enumerated(EnumType.STRING)
	private SignaalDAC6Status currentStatus;
	@OneToMany(mappedBy = "signaalDAC6", orphanRemoval = true, cascade = CascadeType.ALL)
	private List<PersoonDAC6> personen;
	@OneToMany(mappedBy = "signaalDAC6", orphanRemoval = true, cascade = CascadeType.ALL)
	private List<GekoppeldDocumentDAC6> documenten;
	@OneToMany(mappedBy = "signaalDAC6", orphanRemoval = true, cascade = CascadeType.ALL)
	@MapKey(name = "soort")
	private Map<TextSoort, TextDAC6> teksten;

	public SignaalDAC6() {
		personen = new ArrayList<>();
		documenten = new ArrayList<>();
		teksten = new HashMap<>();
	}
}
