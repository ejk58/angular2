package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import nl.belastingdienst.iva.wd.gmv.domain.Stroom;
import nl.belastingdienst.iva.wd.gmv.service.ApiKeyService;
import nl.belastingdienst.iva.wd.gmv.service.StroomService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RunWith(SpringRunner.class)
@WebMvcTest(StroomRestController.class)
class StroomRestControllerTest extends AbstractControllerTest {

	@MockBean
	private StroomService stroomService;

	@MockBean
	ClientHttpRequestFactory clientHttpRequestFactory;

	@MockBean
	ApiKeyService apiKeyService;

	@Autowired
	private MockMvc mvc;

	@MockBean
	CacheManager cacheManager;

	@Test
	void getStromen() throws Exception {
		given(stroomService.getStromen()).willReturn(createStromenList());
		mvc.perform(get(START_REQUEST + "/stroom").contentType(MediaType.APPLICATION_JSON))
		   .andExpect(status().isOk())
		   .andExpect(jsonPath("$", hasSize(1)))
		   .andExpect(jsonPath("$[0].naam", is("stroom1")))
		   .andExpect(jsonPath("$[0].adGroep", is("adgroup")));
	}

	@Test
	void getCurrentStroom() throws Exception {
		String authorizationValue = loginWithStream(mvc, "DAC6", status().isOk());

		mvc.perform(get(START_REQUEST + "/stroom/current").header(HEADER_STRING, authorizationValue)
														  .contentType(MediaType.TEXT_PLAIN))
		   .andExpect(status().isOk())
		   .andExpect(content().string("\"DAC6\""));
	}

	private List<Stroom> createStromenList() {
		List<Stroom> stroomList = new ArrayList<>();
		Stroom stroom = new Stroom();
		stroom.setAdGroep("adgroup");
		stroom.setId(1);
		stroom.setNaam("stroom1");
		stroomList.add(stroom);
		return stroomList;
	}
}
