package nl.belastingdienst.iva.wd.gmv.service;

import static org.junit.Assert.assertEquals;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.wd.gmv.dao.TextRepository;
import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.Text;
import nl.belastingdienst.iva.wd.gmv.domain.TextSoort;

public class TextServiceTest {

	@Captor
	ArgumentCaptor<Text> textArgumentCaptor;
	private TextService textService;
	@Mock
	private MeldingService meldingService;
	@Mock
	private TextRepository textRepository;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		textService = new TextService(meldingService, textRepository);
	}

	@Test
	public void updateTextWrongSoort() {
		final String invalidSoort = "XX";
		try {
			textService.updateText(0, invalidSoort, "");
		} catch (NotFoundException notFoundException) {
			assertEquals(invalidSoort, notFoundException.getKey());
			assertEquals("Deze textsoort bestaat niet", notFoundException.getWhy());
		}
		Mockito.verify(textRepository, (Mockito.times(0)))
			   .save(Mockito.any());
	}

	@Test
	public void updateTextOk() {
		Melding m = new Melding();
		m.setId(1);
		Mockito.when(meldingService.getMelding(m.getId()))
			   .thenReturn(m);
		Mockito.when(textRepository.findByMelding_IdAndSoort(m.getId(), TextSoort.OP))
			   .thenReturn(Optional.empty());
		Text ret = textService.updateText(m.getId(), TextSoort.OP.name(), "test text");
		Mockito.verify(textRepository, (Mockito.times(1)))
			   .save(textArgumentCaptor.capture());
		assertEquals("test text", textArgumentCaptor.getValue()
													.getText());
		assertEquals(TextSoort.OP, textArgumentCaptor.getValue()
													 .getSoort());
	}

	@Test
	public void updateTextOkDup() {
		Melding m = new Melding();
		m.setId(1);
		Mockito.when(meldingService.getMelding(m.getId()))
			   .thenReturn(m);
		Text t = new Text();
		t.setText("previous");
		t.setSoort(TextSoort.AA);
		Mockito.when(textRepository.findByMelding_IdAndSoort(m.getId(), TextSoort.OP))
			   .thenReturn(Optional.of(t));
		Mockito.when(textRepository.save(t))
			   .thenReturn(t);
		Text ret = textService.updateText(m.getId(), TextSoort.OP.name(), "test text");
		assertEquals("test text", ret.getText());
		assertEquals(TextSoort.AA, ret.getSoort()); // Notchanged
		Mockito.verify(textRepository, (Mockito.times(1)))
			   .save(Mockito.any());
	}
}
