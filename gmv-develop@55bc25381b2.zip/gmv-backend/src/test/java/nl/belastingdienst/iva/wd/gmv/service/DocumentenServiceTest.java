package nl.belastingdienst.iva.wd.gmv.service;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doAnswer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;

import nl.belastingdienst.iva.wd.gmv.dao.GekoppeldDocumentRepository;
import nl.belastingdienst.iva.wd.gmv.dao.MeldingRepository;
import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.document.FilenetDocument;
import nl.belastingdienst.iva.wd.gmv.domain.document.FilenetDocumentProperties;
import nl.belastingdienst.iva.wd.gmv.domain.document.GekoppeldDocument;

public class DocumentenServiceTest {
	@Captor
	ArgumentCaptor<GekoppeldDocument> gekoppeldDocumentArgumentCaptor;
	@Captor
	ArgumentCaptor<FilenetDocumentProperties> filenetDocumentPropertiesArgumentCaptor;
	@Captor
	ArgumentCaptor<Melding> meldingArgumentCaptor;
	@Mock
	private MeldingService meldingService;
	@Mock
	private MeldingRepository meldingRepository;
	@Mock
	private FilenetClient filenetClient;
	@Mock
	private DocumentViewerRestClient documentViewerRestClient;
	@Mock
	private GekoppeldDocumentRepository gekoppeldDocumentRepository;
	private DocumentenService documentenService;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		documentenService = new DocumentenService(filenetClient, documentViewerRestClient, gekoppeldDocumentRepository, meldingRepository,
				meldingService);
	}

	@Test
	public void saveUploadedDocument() throws IOException {
		Melding m = new Melding();
		m.setId(1);
		Mockito.when(meldingService.getMelding(m.getId()))
			   .thenReturn(m);
		Mockito.when(filenetClient.saveDocument(Mockito.any(), Mockito.any()))
			   .thenReturn("EEN GEGENEREERD ID");
		MockMultipartFile testfile = new MockMultipartFile("data", "test.txt", "text/plain", "enige tekst".getBytes());

		doAnswer(invocation -> {
			Object[] args = invocation.getArguments();
			((GekoppeldDocument) args[0]).setId(99);
			return null;
		}).when(gekoppeldDocumentRepository)
		  .save(Mockito.any(GekoppeldDocument.class));

		documentenService.saveUploadedDocument(testfile, m.getId(), "de omschrijving");
		Mockito.verify(filenetClient, (Mockito.times(1)))
			   .saveDocument(filenetDocumentPropertiesArgumentCaptor.capture(), Mockito.any());
		assertEquals("Notitie", filenetDocumentPropertiesArgumentCaptor.getValue()
																	   .getDocumentSoort());
		assertEquals("test.txt", filenetDocumentPropertiesArgumentCaptor.getValue()
																		.getFileName());
		assertEquals("de omschrijving", filenetDocumentPropertiesArgumentCaptor.getValue()
																			   .getOmschrijving());

		Mockito.verify(gekoppeldDocumentRepository, (Mockito.times(1)))
			   .save(gekoppeldDocumentArgumentCaptor.capture());
		assertEquals("EEN GEGENEREERD ID", gekoppeldDocumentArgumentCaptor.getValue()
																		  .getDocId());
		assertEquals(m, gekoppeldDocumentArgumentCaptor.getValue()
													   .getMelding());
		assertEquals(99, gekoppeldDocumentArgumentCaptor.getValue()
														.getId());
	}

	@Test
	public void getFilenetDocuments() {
		Melding m = new Melding();
		m.setId(1);
		GekoppeldDocument d1 = new GekoppeldDocument();
		FilenetDocument fd1 = new FilenetDocument();
		d1.setDocId("idd_doc1");
		GekoppeldDocument d2 = new GekoppeldDocument();
		FilenetDocument fd2 = new FilenetDocument();
		d2.setDocId("idd_doc2");
		GekoppeldDocument d3 = new GekoppeldDocument();
		FilenetDocument fd3 = new FilenetDocument();
		d3.setDocId("doc2");
		m.setDocumenten(Arrays.asList(d1, d2, d3));
		Mockito.when(meldingService.getMelding(m.getId()))
			   .thenReturn(m);
		Mockito.when(documentViewerRestClient.findDocument("&fnObjId=", d1.getDocId()))
			   .thenReturn(fd1);
		Mockito.when(documentViewerRestClient.findDocument("&fnObjId=", d2.getDocId()))
			   .thenReturn(fd2);
		Mockito.when(documentViewerRestClient.findDocument("&uuid=", d3.getDocId()))
			   .thenReturn(fd3);
		List<GekoppeldDocument> ret = documentenService.getGekoppeldeDocuments(m.getId());
		assertNotNull(ret);
		assertEquals(3, ret.size());
		assertArrayEquals(m.getDocumenten()
						   .toArray(), ret.toArray());
		List<FilenetDocument> ret2 = documentenService.getFilenetDocuments(m.getId());
		assertNotNull(ret2);
		assertEquals(3, ret2.size());
		assertEquals(fd1, ret2.get(0));
		assertEquals(fd2, ret2.get(1));
		assertEquals(fd3, ret2.get(2));
	}

	@Test
	public void deleteDocumentFromMelding() {
		Melding m = new Melding();
		m.setId(1);
		GekoppeldDocument d1 = new GekoppeldDocument();
		d1.setDocId("idd_doc1");
		GekoppeldDocument d2 = new GekoppeldDocument();
		d2.setDocId("idd_doc2");
		GekoppeldDocument d3 = new GekoppeldDocument();
		d3.setDocId("doc2");
		m.setDocumenten(new ArrayList<>());
		m.getDocumenten()
		 .add(d1);
		m.getDocumenten()
		 .add(d2);
		m.getDocumenten()
		 .add(d3);
		Mockito.when(meldingService.getMelding(m.getId()))
			   .thenReturn(m);
		documentenService.deleteDocumentFromMelding(m.getId(), "idd_doc2");
		Mockito.verify(meldingRepository, (Mockito.times(1)))
			   .save(meldingArgumentCaptor.capture());
		assertNotNull(meldingArgumentCaptor.getValue()
										   .getDocumenten());
		assertEquals(2, meldingArgumentCaptor.getValue()
											 .getDocumenten()
											 .size());
		assertEquals(d1, meldingArgumentCaptor.getValue()
											  .getDocumenten()
											  .get(0));
		assertEquals(d3, meldingArgumentCaptor.getValue()
											  .getDocumenten()
											  .get(1));
	}
}
