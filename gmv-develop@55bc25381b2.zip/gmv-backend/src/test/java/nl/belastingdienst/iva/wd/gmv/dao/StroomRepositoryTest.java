package nl.belastingdienst.iva.wd.gmv.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.test.context.junit4.SpringRunner;

import nl.belastingdienst.iva.wd.gmv.domain.Stroom;
import nl.belastingdienst.iva.wd.gmv.service.ApiKeyService;

import lombok.extern.log4j.Log4j2;

@RunWith(SpringRunner.class)
@Log4j2
@DataJpaTest
public class StroomRepositoryTest {

	@Autowired
	StroomRepository stroomRepository;

	@MockBean
	ClientHttpRequestFactory clientHttpRequestFactory;

	@MockBean
	CacheManager cacheManager;

	@MockBean
	private ApiKeyService apiKeyService;

	@Test
//	@Ignore
	public void getStromen() {
		List<Stroom> stroomList =this.stroomRepository.findByOrderByNaam();
		assertEquals(2 , stroomList.size()); //2 in data-h2.sql al gevuld.
		assertEquals("DAC6", stroomList.get(0).getNaam());
		assertEquals("TESTSTROOM", stroomList.get(1).getNaam());
	}
}
