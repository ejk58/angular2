package nl.belastingdienst.iva.wd.gmv.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import nl.belastingdienst.iva.wd.gmv.domain.Belastingmiddel;
import nl.belastingdienst.iva.wd.gmv.domain.Hallmark;
import nl.belastingdienst.iva.wd.gmv.domain.Lookup;
import nl.belastingdienst.iva.wd.gmv.domain.Rol;
import nl.belastingdienst.iva.wd.gmv.domain.Status;

public class LookupServiceTest {
	private LookupService lookupService;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		lookupService = new LookupService();
	}

	@Test
	public void getList() {
		List<Lookup> retRol = lookupService.getList(LookupService.LookupType.ROL);
		assertEquals(Rol.PERSON.getDescription(), retRol.get(0)
														.getOmschrijving());
		List<Lookup> retMiddel = lookupService.getList(LookupService.LookupType.BELASTINGMIDDEL);
		assertEquals(Belastingmiddel.BRB.getDescription(), retMiddel.get(0)
																	.getOmschrijving());
		List<Lookup> retStatus = lookupService.getList(LookupService.LookupType.STATUS);
		assertEquals(Status.NEW.getDescription(), retStatus.get(0)
														   .getOmschrijving());
		List<Lookup> retHallmark = lookupService.getList(LookupService.LookupType.HALLMARK);
		assertEquals(Hallmark.A1.getDescription(), retHallmark.get(0)
															  .getOmschrijving());
	}
}
