package nl.belastingdienst.iva.wd.gmv.rest;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import nl.belastingdienst.iva.wd.gmv.service.ApiKeyService;
import nl.belastingdienst.iva.wd.gmv.service.StroomService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RunWith(SpringRunner.class)
@WebMvcTest(StroomRestController.class)
class LoginRestControllerTest extends AbstractControllerTest {

	@MockBean
	ClientHttpRequestFactory clientHttpRequestFactory;

	@MockBean
	ApiKeyService apiKeyService;

	@MockBean
	StroomService stroomService;

	@MockBean
	CacheManager cacheManager;

	@Autowired
	private MockMvc mvc;

	@Test
	void loginWrongCreds() throws Exception {
		String ret = loginWithStream(mvc, "dummy", "dummy", "dummy", status().isUnauthorized());
		Assertions.assertNull(ret);
	}

	@Test
	void loginGoodStream() throws Exception {
		String token = loginWithStream(mvc, "DAC6", status().isOk());
		Assertions.assertEquals("Bearer ", token.substring(0, 7));
	}

	@Test
	void loginWrongStream() throws Exception {
		String ret = loginWithStream(mvc, "TESTSTROOM", status().isForbidden());
		Assertions.assertNull(ret);
	}
}
