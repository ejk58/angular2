package nl.belastingdienst.iva.wd.gmv.service;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.wd.gmv.dao.StroomRepository;
import nl.belastingdienst.iva.wd.gmv.domain.Stroom;

public class StroomServiceTest {

	private StroomService stroomService;

	@Mock
	private StroomRepository stroomRepository;


	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		stroomService = new StroomService(stroomRepository);
	}

	@Test
	public void getStromen() {
		Stroom s = new Stroom();
		s.setNaam("DAC6");
		s.setAdGroep("AD_DAC6");
		List<Stroom> in = Collections.singletonList(s);
		Mockito.when(stroomRepository.findByOrderByNaam())
			   .thenReturn(in);
		List<Stroom> ret = stroomService.getStromen();
		assertArrayEquals(in.toArray(), ret.toArray());
	}

	@Test
	public void getStroom() {
		Stroom s = new Stroom();
		s.setNaam("DAC6");
		s.setAdGroep("AD_DAC6");
		Mockito.when(stroomRepository.getByNaam(s.getNaam()))
			   .thenReturn(s);
		try {
			this.stroomService.getStroom("DAC6fout");
		} catch (NotFoundException e) {
			Assert.assertEquals("Stroom bestaat niet", e.getWhy());
			Assert.assertEquals("DAC6fout", e.getKey());
		}
		Mockito.verify(stroomRepository, (Mockito.times(1)))
			   .getByNaam(Mockito.anyString());

		Stroom test = this.stroomService.getStroom("DAC6");
		Mockito.verify(stroomRepository, (Mockito.times(2)))
			   .getByNaam(Mockito.anyString());
		assertEquals("AD_DAC6", test.getAdGroep());
	}

}
