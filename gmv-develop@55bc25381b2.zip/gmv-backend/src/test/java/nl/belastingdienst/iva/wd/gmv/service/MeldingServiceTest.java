package nl.belastingdienst.iva.wd.gmv.service;

import static org.junit.Assert.assertEquals;

import java.util.Collections;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.common.springboot.exceptions.NotPossibleException;
import nl.belastingdienst.iva.wd.gmv.dao.MeldingRepository;
import nl.belastingdienst.iva.wd.gmv.dao.StatusLogRepository;
import nl.belastingdienst.iva.wd.gmv.domain.Melding;
import nl.belastingdienst.iva.wd.gmv.domain.Persoon;
import nl.belastingdienst.iva.wd.gmv.domain.Prioriteit;
import nl.belastingdienst.iva.wd.gmv.domain.Status;
import nl.belastingdienst.iva.wd.gmv.domain.Stroom;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class MeldingServiceTest {

	private MeldingService meldingService;

	@Mock
	private StroomService stroomService;
	@Mock
	private MeldingRepository meldingRepository;
	@Mock
	private StatusLogRepository statusLogRepository;
	@Mock
	private EntityManager entityManager;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		meldingService = new MeldingService(meldingRepository, statusLogRepository, stroomService, entityManager);
	}

	@Test
	public void getByBothIdsOk() {
		Melding m = new Melding();
		m.setId(1);
		m.setArrangementId("testa");
		m.setDisclosureId("testb");
		Mockito.when(meldingRepository.findById(m.getId()))
			   .thenReturn(Optional.of(m));
		Mockito.when(meldingRepository.findByArrangementIdAndDisclosureId(m.getArrangementId(), m.getDisclosureId()))
			   .thenReturn(Optional.of(m));
		this.meldingService.getMelding(m.getId());
		Mockito.verify(meldingRepository, (Mockito.times(1)))
			   .findById(m.getId());
		this.meldingService.getMelding(m.getArrangementId(), m.getDisclosureId());
		Mockito.verify(meldingRepository, (Mockito.times(1)))
			   .findByArrangementIdAndDisclosureId(m.getArrangementId(), m.getDisclosureId());
	}

	@Test
	public void getByBothIdsException() {
		Mockito.when(meldingRepository.findById(1))
			   .thenReturn(Optional.empty());
		Mockito.when(meldingRepository.findByArrangementIdAndDisclosureId("", ""))
			   .thenReturn(Optional.empty());
		try {
			this.meldingService.getMelding(1);
		} catch (NotFoundException e) {
			assertEquals("Melding niet gevonden", e.getWhy());
			assertEquals("1", e.getKey());
			try {
				this.meldingService.getMelding("a", "d");
			} catch (NotFoundException e2) {
				assertEquals("Melding niet gevonden", e2.getWhy());
				assertEquals("a / d", e2.getKey());
				return;
			}
			assertEquals("Exception op nummer is niet opgetreden", 0, 1);
		}
		assertEquals("Exception op id is niet opgetreden", 0, 1);
	}

	@Test
	public void setNextStatusOk() {
		Melding m = new Melding();
		m.setId(1);
		m.setCurrentStatus(Status.NEW);
		Mockito.when(meldingRepository.findById(1))
			   .thenReturn(Optional.of(m));
		this.meldingService.setStatus(m.getId(), Status.MDR_SELECTED.name());
		Mockito.verify(statusLogRepository, (Mockito.times(1)))
			   .save(Mockito.any());
		assertEquals(Status.MDR_SELECTED, m.getCurrentStatus());
	}

	@Test
	public void setNextStatusNotAllowed() {
		Melding m = new Melding();
		m.setId(1);
		m.setCurrentStatus(Status.NEW);
		Mockito.when(meldingRepository.findById(1))
			   .thenReturn(Optional.of(m));
		try {
			this.meldingService.setStatus(m.getId(), Status.DONE_REVIEW.name());
		} catch (NotPossibleException pos) {
			assertEquals(Status.DONE_REVIEW.getDescription(), pos.getKey());
			assertEquals("Nieuwe status is niet toegestaan", pos.getWhy());
		}
		Mockito.verify(statusLogRepository, (Mockito.times(0)))
			   .save(Mockito.any());
		assertEquals(Status.NEW, m.getCurrentStatus());
	}

	@Test
	public void addMeldingOk() {
		Melding m = new Melding();
		m.setArrangementId("testa");
		m.setDisclosureId("testb");
		m.setBelastingMiddellen("VPB");
		Persoon p = new Persoon();
		m.getPersonen()
		 .add(p);
		Prioriteit prio = new Prioriteit();
		m.getPrioriteiten()
		 .add(prio);
		Stroom str = new Stroom();
		str.setNaam("TEST");
		Mockito.when(stroomService.getStroom(str.getNaam()))
			   .thenReturn(str);
		Mockito.when(meldingRepository.findByArrangementIdAndDisclosureId(m.getArrangementId(), m.getDisclosureId()))
			   .thenReturn(Optional.empty());
		this.meldingService.addMelding(m, str.getNaam());
		Mockito.verify(meldingRepository, (Mockito.times(1)))
			   .save(m);
		assertEquals("SWAGGER", m.getBehandelaarId());
		assertEquals(Status.NEW, m.getStatusLogs()
								  .get(0)
								  .getStatus());
		assertEquals(m, m.getStatusLogs()
						 .get(0)
						 .getMelding());
	}

	@Test
	public void addMeldingExceptionMeldingExists() {
		Melding m = new Melding();
		m.setArrangementId("testa");
		m.setDisclosureId("testb");
		Mockito.when(meldingRepository.findByArrangementIdAndDisclosureId(m.getArrangementId(), m.getDisclosureId()))
			   .thenReturn(Optional.of(m));

		try {
			this.meldingService.addMelding(m, "DAC6");
		} catch (NotPossibleException e) {
			assertEquals("testa / testb", e.getKey());
			assertEquals("Arrangement / Disclosure bestaat al", e.getWhy());

		}
		Mockito.verify(meldingRepository, (Mockito.times(0)))
			   .save(m);
	}

	@Test
	public void addMeldingExceptionMiddelVerplicht() {
		Melding m = new Melding();
		m.setArrangementId("testa");
		m.setDisclosureId("testb");
		Mockito.when(meldingRepository.findByArrangementIdAndDisclosureId(m.getArrangementId(), m.getDisclosureId()))
			   .thenReturn(Optional.empty());

		try {
			this.meldingService.addMelding(m, "DAC6");
		} catch (NotPossibleException e) {
			assertEquals(null, e.getKey());
			assertEquals("Belastingmiddel is verplicht", e.getWhy());

		}
		Mockito.verify(meldingRepository, (Mockito.times(0)))
			   .save(m);
	}

	@Test
	public void addMeldingExceptionMiddelVerplichtBestaand() {
		Melding m = new Melding();
		m.setArrangementId("testa");
		m.setDisclosureId("testb");
		m.setBelastingMiddellen("IH,BOGUS");
		Mockito.when(meldingRepository.findByArrangementIdAndDisclosureId(m.getArrangementId(), m.getDisclosureId()))
			   .thenReturn(Optional.empty());

		try {
			this.meldingService.addMelding(m, "DAC6");
		} catch (NotPossibleException e) {
			assertEquals("IH,BOGUS", e.getKey());
			assertEquals("Belastingmiddel bevat een ongeldig middel", e.getWhy());

		}
		Mockito.verify(meldingRepository, (Mockito.times(0)))
			   .save(m);
	}

	@Test
	public void addMeldingExceptionPersonenVerplicht() {
		Melding m = new Melding();
		m.setArrangementId("testa");
		m.setDisclosureId("testb");
		m.setBelastingMiddellen("IH");
		Mockito.when(meldingRepository.findByArrangementIdAndDisclosureId(m.getArrangementId(), m.getDisclosureId()))
			   .thenReturn(Optional.empty());

		try {
			this.meldingService.addMelding(m, "DAC6");
		} catch (NotPossibleException e) {
			assertEquals(null, e.getKey());
			assertEquals("Personen zijn verplicht", e.getWhy());

		}
		Mockito.verify(meldingRepository, (Mockito.times(0)))
			   .save(m);
	}

	@Test
	public void addMeldingExceptionPrioriteitenVerplicht() {
		Melding m = new Melding();
		m.setArrangementId("testa");
		m.setDisclosureId("testb");
		m.setBelastingMiddellen("IH");
		Persoon p = new Persoon();
		m.setPersonen(Collections.singletonList(p));
		Mockito.when(meldingRepository.findByArrangementIdAndDisclosureId(m.getArrangementId(), m.getDisclosureId()))
			   .thenReturn(Optional.empty());

		try {
			this.meldingService.addMelding(m, "DAC6");
		} catch (NotPossibleException e) {
			assertEquals(null, e.getKey());
			assertEquals("Prioriteiten zijn verplicht", e.getWhy());

		}
		Mockito.verify(meldingRepository, (Mockito.times(0)))
			   .save(m);
	}
}
