package nl.belastingdienst.iva.wd.gmv.rest;

import static nl.belastingdienst.iva.common.springboot.security.SecurityConstants.HEADER_STRING;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.gmv.rest.security.LoginStroomCredentials;

abstract class AbstractControllerTest {

	protected static final String START_REQUEST = "/api";

	protected String loginWithStream(MockMvc mvc, String stream, ResultMatcher resultMatcher) throws Exception {
		return loginWithStream(mvc, "ivatest1", "Welkom01", stream, resultMatcher);
	}

	protected String loginWithStream(MockMvc mvc, String userid, String password, String stream, ResultMatcher resultMatcher)
			throws Exception {
		LoginStroomCredentials creds = new LoginStroomCredentials();
		creds.setUsername(userid);
		creds.setPassword(password);
		creds.setStroom(stream);
		String credsJson = new ObjectMapper().writeValueAsString(creds);
		MvcResult result = mvc.perform(post(START_REQUEST + "/login").content(credsJson)
																	 .accept(MediaType.APPLICATION_JSON))
							  .andExpect(resultMatcher)
							  .andReturn();
		return result.getResponse()
					 .getHeader(HEADER_STRING);
	}
}
