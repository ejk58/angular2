@Library("GENERIC") _
    pipelineDeployArtifactFromQuay {
	deploymentId = "ivagmv"
	integrationPipeline = "iva-gmv-test"
	packageChoices = "iva-gmv"
                applicationVersionChoices = "0.2.0\n0.18.0\n0.17.0\n0.15.0\n0.14.0"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "1\n2\n3\n4\n5\n6\n"
}
