export class AutorisationEvent {
  login: boolean;

  constructor(login: boolean) {
    this.login = login;
  }
}
