import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {ConfirmationService, MenuItem, MessageService} from 'primeng/api';
import {DocumentRestControllerService} from '../generated/services/document-rest-controller.service';
import {TextRestControllerService} from '../generated/services/text-rest-controller.service';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {LookupService} from '../components/lookup.service';
import {Lookup} from '../generated/models/lookup';
import {BatRestControllerService} from '../generated/services/bat-rest-controller.service';
import {timer} from 'rxjs';
import {PubsubService} from '../pubsub/pubsub.service';
import {ReloadEvent} from '../pubsub/reload-event';
import {SignaalDac6RestControllerService} from '../generated/services/signaal-dac-6rest-controller.service';
import {SignaalDAC6DTO} from '../generated/models/signaal-dac6dto';

@Component({
    selector: 'app-detail',
    templateUrl: './detail-signaal.component.html',
    styleUrls: ['./detail-signaal.component.scss']
})
export class DetailSignaalComponent implements OnInit {
    signaal: SignaalDAC6DTO | undefined;
    nextStatus: string[] = [];
    steps: MenuItem[] = [];
    statussen: Lookup[] = [];
    batReference: Window | null = null;
    showVerantwoording = false;

    constructor(private activatedRoute: ActivatedRoute,
                private messageService: MessageService,
                private pubsubService: PubsubService,
                private documentRestControllerService: DocumentRestControllerService,
                private textRestControllerService: TextRestControllerService,
                private lookupRestControllerService: LookupRestControllerService,
                private lookupService: LookupService,
                private confirmationService: ConfirmationService,
                private batRestControllerService: BatRestControllerService,
                private signaalDac6RestControllerService: SignaalDac6RestControllerService) {
    }

    ngOnInit(): void {
        this.lookupService.initialize().subscribe(() => {
            let steps: MenuItem[] = [];
            this.statussen = this.lookupService.get("STATUS");
            this.statussen.forEach(s => {
                steps.push({label: s.omschrijving, id: 'id_' + s.code})
            })
            this.steps = steps;
        })
        this.loadSignaal();
    }

    showVerantwoordingDialog() {
        this.showVerantwoording = true;
    }

    startBehandelvoorstel(tin: number) {
        this.batRestControllerService.getTokenUsingPOST({dto: {tin: tin.toString(), meldingId: this.signaal?.id}})
            .subscribe(ret => {
                this.batReference = window.open(`${ret.baseUrl}${ret.token}`, "_blank")
                if (this.batReference != null) {
                    const theTimer = timer(500, 500).subscribe(() => {
                        if (this.batReference?.closed) {
                            theTimer.unsubscribe()
                            this.loadSignaal();
                        }
                    })
                }
            }, error => {
                this.messageService.add({
                    severity: 'error',
                    detail: error.error.detail,
                    summary: 'Fout bij het starten van BAT'
                })
            })
    }

    startBehandeling(event: Event, status: string) {
            this.forwardToStatus(status);
    }

    currentStep() {
        return this.statussen.findIndex(st => this.signaal?.currentStatus == st.code);
    }

    isEndState(signaal: SignaalDAC6DTO | undefined): boolean {
        return (signaal != undefined && (signaal.currentStatus == 'DONE'))
    }

    public loadSignaal() {
        if (this.activatedRoute.snapshot.paramMap.has('id')) {
            let id = this.activatedRoute.snapshot.paramMap.get('id');
            if (id != null) {
                this.signaalDac6RestControllerService.getSignaalByIdUsingGET({id: Number.parseInt(id)}).subscribe(
                    signaal => {
                        this.signaal = signaal;
                        this.setNextActions(signaal);
                        this.pubsubService.publish(ReloadEvent, null);
                    }
                )
            }
        }
    }

    private forwardToStatus(status: string) {
        this.signaalDac6RestControllerService.updateSignaalDAC6StatusUsingPUT({
            id: this.signaal!.id!,
            status: status
        }).subscribe(updatedMelding => {
            this.signaal = updatedMelding;
            this.setNextActions(this.signaal);
        })
    }

    private setNextActions(signaal: SignaalDAC6DTO) {
        this.lookupRestControllerService.lookupNextSignaalDAC6StatusUsingGET().subscribe(next => {
            this.nextStatus = next[signaal.currentStatus];
        })
    }

    getText(soort: string): string {
        if (this.signaal)
            if (this.signaal.teksten)
                if (this.signaal.teksten[soort])
                    return this.signaal.teksten[soort];
        return "";
    }
}
