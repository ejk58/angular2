import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {FormsModule} from '@angular/forms';

import {TableModule} from 'primeng/table';
import {ButtonModule} from "primeng/button";
import {InputTextModule} from "primeng/inputtext";
import {TabMenuModule} from "primeng/tabmenu";
import {ToastModule} from 'primeng/toast';
import {DropdownModule} from 'primeng/dropdown';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {CheckboxModule} from "primeng/checkbox";
import {ConfirmationService, MessageService} from 'primeng/api';
import {DataViewModule} from 'primeng/dataview';
import {InputNumberModule} from 'primeng/inputnumber';
import {SelectButtonModule} from 'primeng/selectbutton';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {PasswordModule} from 'primeng/password';
import {SpeedDialModule} from 'primeng/speeddial';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {LoginComponent} from './login/login.component';
import {VersionComponent} from './version/version.component';
import {LogoutComponent} from './logout/logout.component';
import {HttpClientModule} from '@angular/common/http';
import {LoggedInGuard} from './login/logged-in.guard';
import {LoginService} from './login/login.service';
import {MainComponent} from './main/main.component';
import {NieuwComponent} from './nieuw/nieuw.component';
import {CalendarModule} from 'primeng/calendar';
import {PersoonComponent} from './nieuw/persoon.component';
import {PrioriteitComponent} from './nieuw/prioriteit.component';
import {RippleModule} from 'primeng/ripple';
import {DetailComponent} from './detail/detail.component';
import {DetailSignaalComponent} from './detail-signaal/detail-signaal.component';
import {MultiSelectModule} from 'primeng/multiselect';
import {DatePipe} from '@angular/common';
import {DutchDatePipe} from './components/dutch-date.pipe';
import {FileUploadModule} from 'primeng/fileupload';
import {DialogModule} from 'primeng/dialog';
import {HallmarkListComponent} from './detail/hallmark-list.component';
import {PersoonListComponent} from './components/persoon-list.component';
import {BehandelvoorstelListComponent} from './detail/behandelvoorstel-list.component';
import {StatusListComponent} from './detail/status-list.component';
import {EditorModule} from 'primeng/editor';
import {TextEditorComponent} from './components/text-editor.component';
import {LookupPipe} from './components/lookup.pipe';
import {DialogService, DynamicDialogModule} from 'primeng/dynamicdialog';
import {GlobalHandlingModule} from './global-handling/global-handling.module';
import {DividerModule} from 'primeng/divider';
import {StepsModule} from 'primeng/steps';
import {InputMaskModule} from 'primeng/inputmask';
import {ConfirmPopupModule} from 'primeng/confirmpopup';
import {VoorstellenComponent} from './detail/voorstellen.component';
import {DocumentenComponent} from './components/documenten.component';
import {NieuwSignaalComponent} from './nieuw-signaal/nieuw-signaal.component';
import {SignaalOverzichtComponent} from './signaal-overzicht/signaal-overzicht.component';
import {BsnPipe} from './components/bsn.pipe';

@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        VersionComponent,
        LogoutComponent,
        MainComponent,
        NieuwComponent,
        PersoonComponent,
        PrioriteitComponent,
        DetailComponent,
        DetailSignaalComponent,
        DutchDatePipe,
        HallmarkListComponent,
        StatusListComponent,
        PersoonListComponent,
        BehandelvoorstelListComponent,
        TextEditorComponent,
        LookupPipe,
        VoorstellenComponent,
        DocumentenComponent,
        NieuwSignaalComponent,
        SignaalOverzichtComponent,
        BsnPipe,
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        HttpClientModule,
        FormsModule,
        TableModule,
        ButtonModule,
        InputTextModule,
        TabMenuModule,
        ToastModule,
        DropdownModule,
        AutoCompleteModule,
        DataViewModule,
        CheckboxModule,
        InputNumberModule,
        SelectButtonModule,
        ConfirmDialogModule,
        PasswordModule,
        CalendarModule,
        RippleModule,
        SpeedDialModule,
        MultiSelectModule,
        FileUploadModule,
        DialogModule,
        DynamicDialogModule,
        EditorModule,
        GlobalHandlingModule,
        DividerModule,
        StepsModule,
        InputMaskModule,
        ConfirmPopupModule
    ],
    providers: [
        DialogService,
        LoggedInGuard,
        LoginService,
        MessageService,
        ConfirmationService,
        DatePipe],
    bootstrap: [AppComponent]
})
export class AppModule {
}
