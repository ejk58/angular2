import {Component} from '@angular/core';
import {DynamicDialogConfig} from 'primeng/dynamicdialog';

@Component({
    selector: 'app-global-error-dialog',
    template: `
		<p>{{config.data.message}}</p><p *ngIf="config.data.login">
			U wordt doorgestuurd naar het login scherm </p>
		<div *ngIf="config.data.stack !== 'Geen stacktrace beschikbaar'">
			<p-divider></p-divider>
			<pre>{{config.data.stack}}</pre>
		</div>
    `,
    styles: [`
      pre {
        background: #f4f4f4;
        border: 1px solid #ddd;
        border-left: 3px solid #f36d33;
        color: #666;
        page-break-inside: avoid;
        font-family: monospace;
        font-size: 15px;
        line-height: 1.6;
        margin-bottom: 1.6em;
        max-width: 100%;
        overflow: auto;
        padding: 1em 1.5em;
        display: block;
        word-wrap: break-word;
      }`
    ]
})
export class GlobalErrorDialogComponent {

    constructor(public config: DynamicDialogConfig) {
    }
}
