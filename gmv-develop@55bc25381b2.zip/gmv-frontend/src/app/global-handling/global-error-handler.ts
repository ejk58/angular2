import {ErrorHandler, Inject, Injectable, Injector, NgZone} from '@angular/core';
import {HttpErrorResponse} from '@angular/common/http';
import {DialogService} from 'primeng/dynamicdialog';
import {GlobalErrorDialogComponent} from './global-error-dialog.component';
import {Router} from '@angular/router';
import {ApiValidationError} from '../generated/models/api-validation-error';
import {ApiError} from '../generated/models';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
    constructor(
        @Inject(Injector) private readonly injector: Injector,
        private zone: NgZone,
        private router: Router
    ) {
    }

    private get dialogService() {
        return this.injector.get(DialogService);
    }

    handleError(error: any) {
        let login = false;
        let stack: string = error?.stack || 'Geen stacktrace beschikbaar';
        let message = error?.message || 'Onbekende script fout'
        if ((error instanceof HttpErrorResponse)) {
            if (error.status === 401 || error.status === 403) {
                message = 'U bent niet meer ingelogd';
                login = true;
            } else {
                if (error.status === 400 && error.error != null) {
                    let apiError: ApiError = error.error;
                    console.log(apiError)
                    if (apiError.validationErrors) {
                        let validation: ApiValidationError = apiError.validationErrors![0];
                        message = `Backend fout: ${validation.message} voor ${validation.rejectedValue}`;
                    } else {
                        message = apiError.detail
                    }
                } else {
                    message = error.message
                }
            }
        }
        this.show(message, login, stack);
    }

    private show(message: string, login: boolean, stack: string) {
        this.zone.run(() => {
                const ref = this.dialogService.open(GlobalErrorDialogComponent, {
                    data: {message: message, stack: stack, login: login},
                    header: 'Er is een technische, onverwachte fout opgetreden',
                    width: '60%'
                })
                if (login) {
                    ref.onClose.subscribe(
                        () => this.router.navigate(['login'])
                    )
                }
            }
        );
    }
}
