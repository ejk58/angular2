import {Injectable} from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class IsLoadingService {
    counter = 0;

    public start() {
        this.counter++;
    }

    public end() {
        this.counter = this.counter < 1 ? 0 : this.counter - 1;
    }

    public busy() {
        return (this.counter > 0);
    }
}
