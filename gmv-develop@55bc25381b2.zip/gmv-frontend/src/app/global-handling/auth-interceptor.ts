import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';
import {tap} from 'rxjs/operators';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    constructor() {
    }

    intercept(req: HttpRequest<any>,
              next: HttpHandler): Observable<HttpEvent<any>> {

        const idToken = localStorage.getItem('id_token');
        if (idToken && req.url !== '/api/login') {
            const cloned = req.clone({
                headers: req.headers.set('Authorization',
                    'Bearer ' + idToken)
            });

            return next.handle(cloned);
        } else {
            return next.handle(req).pipe(
                tap(
                    (event: HttpEvent<any>) => {
                        if (event instanceof HttpResponse) {
                            const tkn = event.headers.get('authorization');
                            const roles = event.headers.get('X-ROLES');
                            if (tkn) {
                                localStorage.setItem('id_token', tkn.substr(7));
                            }
                            if (roles) {
                                localStorage.setItem('roles', roles);
                            }
                        }
                    }))
        }
    }
}
