import {Component, Input} from '@angular/core';
import {PrioriteitDTO} from '../generated/models';

@Component({
    selector: 'app-hallmark-list',
    template: `
	    <label for="hallmarkTable">Hallmark(s)</label>
	    <p-table id="hallmarkTable" [value]="prioriteiten" [scrollable]="true" scrollHeight="160px"
			    styleClass="table p-datatable-sm">
		    <ng-template pTemplate="header">
			    <tr>
				    <th class="hallmark">Hallmark</th>
				    <th class="prio">Prioriteit</th>
			    </tr>
		    </ng-template>
		    <ng-template let-ri="rowIndex" let-prioriteit pTemplate="body">
			    <tr>
				    <td class="hallmark" id="hallmark-{{ri}}">{{prioriteit.hallmark | lookup:'HALLMARK' | async}}</td>
				    <td class="prio" id="prioriteit-{{ri}}">{{prioriteit.prioriteit}}</td>
			    </tr>
		    </ng-template>
	    </p-table>
    `,
    styles: [`
      #hallmarkTable {
        .prio {
          flex: 0 0 100px;
        }
      }
    `]
})
export class HallmarkListComponent {

    @Input() prioriteiten: PrioriteitDTO[];

    constructor() {
        this.prioriteiten = [];
    }
}
