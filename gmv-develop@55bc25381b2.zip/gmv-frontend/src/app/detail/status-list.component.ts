import {Component, Input} from '@angular/core';
import {StatusLogDTO} from '../generated/models';

@Component({
    selector: 'app-status-list',
    template: `
	    <label for="statusTable">Wijzigingen</label>
	    <p-table id="statusTable" [value]="statussen" [scrollable]="true" scrollHeight="160px" sortField="wijzigingsMoment"
			    sortMode="single" [sortOrder]="-1" styleClass="table p-datatable-sm">
		    <ng-template pTemplate="header">
			    <tr>
				    <th class="dtg">Tijdstip</th>
				    <th class="userid">Medewerker</th>
				    <th>Status</th>
			    </tr>
		    </ng-template>
		    <ng-template let-ri="rowIndex" let-status pTemplate="body">
			    <tr>
				    <td class="dtg" id="moment-{{ri}}">{{status.wijzigingsMoment}}</td>
				    <td class="userid" id="userid-{{ri}}">{{status.behandelaarId}}</td>
				    <td id="status-{{ri}}">{{status.status | lookup:'STATUS' | async}}</td>
			    </tr>
		    </ng-template>
	    </p-table>
    `,
    styles: [`
      #statusTable {
        .userid {
          flex: 0 0 114px;
        }

        .dtg {
          flex: 0 0 160px;
        }
      }
    `]
})
export class StatusListComponent {

    @Input() statussen: StatusLogDTO[];

    constructor() {
        this.statussen = [];
    }
}
