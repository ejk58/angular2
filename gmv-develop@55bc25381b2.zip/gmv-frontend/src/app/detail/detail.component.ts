import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {ConfirmationService, MenuItem, MessageService} from 'primeng/api';
import {DocumentRestControllerService} from '../generated/services/document-rest-controller.service';
import {MeldingRestControllerService} from '../generated/services/melding-rest-controller.service';
import {MeldingDTO} from '../generated/models/melding-dto';
import {TextRestControllerService} from '../generated/services/text-rest-controller.service';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {LookupService} from '../components/lookup.service';
import {Lookup} from '../generated/models/lookup';
import {BatRestControllerService} from '../generated/services/bat-rest-controller.service';
import {timer} from 'rxjs';
import {PubsubService} from '../pubsub/pubsub.service';
import {ReloadEvent} from '../pubsub/reload-event';

@Component({
    selector: 'app-detail',
    templateUrl: './detail.component.html',
    styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {
    melding: MeldingDTO | undefined;
    nextStatus: string[] = [];
    steps: MenuItem[] = [];
    statussen: Lookup[] = [];
    batReference: Window | null = null;
    showVerantwoording = false;

    constructor(private activatedRoute: ActivatedRoute,
                private messageService: MessageService,
                private pubsubService: PubsubService,
                private documentRestControllerService: DocumentRestControllerService,
                private textRestControllerService: TextRestControllerService,
                private lookupRestControllerService: LookupRestControllerService,
                private lookupService: LookupService,
                private confirmationService: ConfirmationService,
                private batRestControllerService: BatRestControllerService,
                private meldingRestControllerService: MeldingRestControllerService) {
    }

    ngOnInit(): void {
        this.lookupService.initialize().subscribe(() => {
            let steps: MenuItem[] = [];
            this.statussen = this.lookupService.get("STATUS");
            this.statussen.forEach(s => {
                steps.push({label: s.omschrijving, id: 'id_' + s.code})
            })
            this.steps = steps;
        })
        this.loadMelding();
    }

    showVerantwoordingDialog() {
        this.showVerantwoording = true;
    }

    startBehandelvoorstel(tin: number) {
        this.batRestControllerService.getTokenUsingPOST({dto: {tin: tin.toString(), meldingId: this.melding?.id}})
            .subscribe(ret => {
                this.batReference = window.open(`${ret.baseUrl}${ret.token}`, "_blank")
                if (this.batReference != null) {
                    const theTimer = timer(500, 500).subscribe(() => {
                        if (this.batReference?.closed) {
                            theTimer.unsubscribe()
                            this.loadMelding();
                        }
                    })
                }
            }, error => {
                this.messageService.add({
                    severity: 'error',
                    detail: error.error.detail,
                    summary: 'Fout bij het starten van BAT'
                })
            })
    }

    startBehandeling(event: Event, status: string) {
        if (status == 'DONE_REVIEW') {
            this.confirmationService.confirm({
                message: 'Weet u het zeker?',
                // acceptLabel: 'Ja',
                // rejectLabel: 'Nee',
                accept: () => {
                    this.forwardToStatus(status);
                }
            })
        } else {
            this.forwardToStatus(status);
        }
    }

    currentStep() {
        return this.statussen.findIndex(st => this.melding?.currentStatus == st.code);
    }

    isEndState(melding: MeldingDTO | undefined): boolean {
        return (melding != undefined && (melding.currentStatus == 'DONE_NO_REVIEW'
            || melding.currentStatus == 'DONE_REVIEW'))
    }

    public loadMelding() {
        if (this.activatedRoute.snapshot.paramMap.has('id')) {
            let id = this.activatedRoute.snapshot.paramMap.get('id');
            if (id != null) {
                this.meldingRestControllerService.getMeldingByIdUsingGET({id: Number.parseInt(id)}).subscribe(
                    melding => {
                        this.melding = melding;
                        this.setNextActions(melding);
                        this.pubsubService.publish(ReloadEvent, null);
                    }
                )
            }
        }
    }

    private forwardToStatus(status: string) {
        this.meldingRestControllerService.updateMeldingStatusUsingPUT({
            id: this.melding!.id!,
            status: status
        }).subscribe(updatedMelding => {
            this.melding = updatedMelding;
            this.setNextActions(this.melding);
        })
    }

    private setNextActions(melding: MeldingDTO) {
        this.lookupRestControllerService.lookupNextStatusUsingGET().subscribe(next => {
            this.nextStatus = next[melding.currentStatus];
        })
    }

    getText(soort: string): string {
        if (this.melding)
            if (this.melding.teksten)
                if (this.melding.teksten[soort])
                    return this.melding.teksten[soort];
        return "";
    }
}
