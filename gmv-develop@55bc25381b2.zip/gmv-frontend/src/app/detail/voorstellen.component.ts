import {Component, Input} from '@angular/core';
import {Voorstel} from '../generated/models/voorstel';

@Component({
    selector: 'app-voorstellen',
    template: `
		<p-table [value]="voorstellen" id="bvptable" styleClass="table p-datatable-sm">
			<ng-template let-ri="rowIndex" let-voorstel pTemplate="body">
				<tr>
					<td class="toedeling"
							id="toedeling-{{persoonIndex}}-{{ri}}">{{voorstel.toedeling | lookup:'TOEDELING' | async}}</td>
					<td class="status-value"
							id="status-value-{{persoonIndex}}-{{ri}}">{{voorstel.status | lookup:'BHSTATUS' | async}}</td>
					<td class="resultaat">
						<p-button (onClick)="showResultaat(voorstel)"
								*ngIf="voorstel.status=='COMPLETED'||voorstel.status=='DELETED'"
								id="resultaat-{{persoonIndex}}-{{ri}}" label="Resultaat" styleClass="p-button-sm"></p-button>
					</td>
					<td class="voorstel"
							id="bv-voorstel-{{persoonIndex}}-{{ri}}">{{nummerPerVoorstel.has(voorstel.behandelVoorstelReference) ? '*' + nummerPerVoorstel.get(voorstel.behandelVoorstelReference) : ''}}</td>
				</tr>
			</ng-template>
		</p-table>
		<p-dialog [closeOnEscape]="true" header="Resultaat van de beoordeling" [(visible)]="showResult"
				[style]="{width: '80vw', height: '80vh'}" [modal]="true">
			<p>{{this.currentVoorstel.subject}}</p>
			<p>{{this.currentVoorstel.toedeling}}</p>
			<p>{{this.currentVoorstel.status}}</p>
			<p>{{this.currentVoorstel.behandelVoorstelReference}}</p>
		</p-dialog>
    `,
    styles: [`
      #bvptable {
        ::ng-deep.p-datatable-tbody > tr > td {
          border-width: 0;
        }

        ::ng-deep.table {
          border-width: 0;
          width: 440px;
        }

        .toedeling {
          flex: 0 0 165px;
          padding-left: 0;
        }

        .status-value {
          flex: 0 0 150px;
        }

        .resultaat {
          flex: 0 0 80px;
          padding-top: 2px;
          padding-bottom: 0;
        }
      }
    `]
})
export class VoorstellenComponent {

    public showResult = false;
    public currentVoorstel: Voorstel = {};

    @Input() persoonIndex: number = 0;
    @Input() voorstellen: Voorstel[] = [];
    @Input() nummerPerVoorstel = new Map<string, number>();

    showResultaat(voorstel: Voorstel) {
        this.currentVoorstel = voorstel;
        //TODO: Resultaat van het voorstel ophalen (als het gedefinieerd is)
        this.showResult = true;
    }
}
