import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {MeldingDTO, PersoonDTO, StartDTO, Voorstel} from '../generated/models';
import {BatRestControllerService} from '../generated/services/bat-rest-controller.service';
import {PubsubService} from '../pubsub/pubsub.service';
import {ReloadEvent} from '../pubsub/reload-event';
import {DialogService} from 'primeng/dynamicdialog';

@Component({
    selector: 'app-behandelvoorstel-list',
    templateUrl: 'behandelvoorstel-list.component.html',
    styleUrls: ['behandelvoorstel-list.component.scss']
})
export class BehandelvoorstelListComponent implements OnInit {

    @Input() melding!: MeldingDTO;
    @Output() behandelPersoon = new EventEmitter<number>();

    public voorstellenPerSubject = new Map<string, Voorstel[]>();
    public nummerPerVoorstel = new Map<string, number>();

    constructor(private batRestControllerService: BatRestControllerService,
                private pubsubService: PubsubService,
                private dialogService: DialogService) {
        pubsubService.subscribe(ReloadEvent).subscribe(() => {
            this.ngOnInit()
        })
    }

    ngOnInit(): void {
        this.voorstellenPerSubject = new Map<string, Voorstel[]>();
        this.nummerPerVoorstel = new Map<string, number>();
        let parms: StartDTO[] = this.melding.personen.map(p => {
            return {tin: p.tin.toString(), meldingId: this.melding.id};
        })
        this.batRestControllerService.getVoorstelUsingPOST({personen: parms})
            .subscribe(voorstellen => {
                voorstellen.forEach(value => {
                    if (!this.nummerPerVoorstel.has(value.behandelVoorstelReference!)) {
                        this.nummerPerVoorstel.set(value.behandelVoorstelReference!, 0)
                    } else {
                        let prev = this.nummerPerVoorstel.get(value.behandelVoorstelReference!)!;
                        this.nummerPerVoorstel.set(value.behandelVoorstelReference!, prev + 1);
                    }
                    if (value.subject != undefined) {
                        if (!this.voorstellenPerSubject.has(value.subject)) {
                            this.voorstellenPerSubject.set(value.subject, []);
                        }
                        this.voorstellenPerSubject.get(value.subject)?.push(value)
                    }
                })
                let nummer = 1;
                this.nummerPerVoorstel.forEach((val, key, map) => {
                    if (val > 0) {
                        map.set(key, nummer)
                        nummer += 1;
                    } else {
                        map.delete(key)
                    }
                })
            })
    }

    public startBehandeling(persoonDTO: PersoonDTO, index: number) {
        this.behandelPersoon.emit(persoonDTO.tin)
    }
}
