import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {Table} from 'primeng/table';
import {MyLazyLoadEvent} from '../main/MyLazyLoadEvent';
import {FilterMetadata} from 'primeng/api/filtermetadata';
import {Lookup} from '../generated/models/lookup';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {Router} from '@angular/router';
import {LookupService} from '../components/lookup.service';
import {SignaalDAC6DTO} from '../generated/models';
import {SignaalDac6RestControllerService} from '../generated/services/signaal-dac-6rest-controller.service';

@Component({
    selector: 'app-signaal-overzicht',
    templateUrl: 'signaal-overzicht.component.html',
    styleUrls: ['signaal-overzicht.component.scss']
})
export class SignaalOverzichtComponent implements OnInit {
    @ViewChild("table") table!: Table;
    @ViewChild("naam") naam!: ElementRef;
    previousEventData!: MyLazyLoadEvent;
    rowsPerPage = 15;
    initialLoad = true;
    signalen = new Array<SignaalDAC6DTO>() ;
    signalenCount = 0;
    hallmarks: Array<Lookup> = new Array<Lookup>();
    middelen: Array<Lookup> = new Array<Lookup>();
    statussen: Array<Lookup> = new Array<Lookup>();

    constructor(private lookup: LookupRestControllerService,
                private signaalDac6RestControllerService: SignaalDac6RestControllerService,
                private router: Router,
                private lookupService: LookupService) {
    }

    ngOnInit(): void {
        this.lookupService.initialize().subscribe(() => {
            this.middelen = this.lookupService.get("BELASTINGMIDDEL");
            this.statussen = this.lookupService.get("SIGNAALDAC6STATUS");
            this.hallmarks = this.lookupService.get("HALLMARK");
        })
    }

    zoekNaam(signaal: SignaalDAC6DTO): string {
        if (signaal && signaal.personen) {
            let persoon = signaal.personen.find(p => {
                return p.naam?.toLowerCase().includes(this.previousEventData.globalFilter.toString().toLowerCase())
            })
            return persoon && persoon.naam ? persoon.naam : "foutje";
        }
        return "grote fout";
    }

    filterNaam($event: any) {
        this.table.filterGlobal($event.target.value, 'contains');
    }

    toDetail(signaal: SignaalDAC6DTO) {
        this.router.navigate(["detailsignaal", signaal.id]);
    }

    clearFilters() {
        this.table.clear();
        this.naam.nativeElement.value = "";
    }

    bgColor(naam: string): string {
        if (<boolean>(this.previousEventData.filters && this.previousEventData.filters[naam] && this.previousEventData.filters[naam].length > 0 && this.previousEventData.filters[naam][0].value)) {
            return 'lightBlue';
        } else return '';
    }

    loadMeldingen(event: MyLazyLoadEvent) {
        //
        // Eigen definitie van LazyLoadEvent vanwege verkeerde definitie in PrimeNg
        // Zie pullrequest: https://github.com/primefaces/primeng/pull/10337
        // Wanneer die gemerged is kan dit type weer standaard worden
        //
        if (this.initialLoad) {
            this.initialLoad = false;
            event.filters!["status"] = [];
            const st: FilterMetadata = {value: "NEW"};
            event.filters!["status"].push(st);
        }
        this.previousEventData = event;

        if (event.filters != null && event.filters["hallmark"] != null && event.filters["hallmark"][0].value != null) {
            event.sortField = "prioriteit";
            event.sortOrder = +1;
        }
        if (event.filters != null && event.filters["global"] != null) {
            // Deze actie is nodig omdat filterGlobal ook een global filter aanmaakt,
            // maar zonder operator, en dat levert problemen op in java
            delete event.filters["global"];
        }
        this.signaalDac6RestControllerService.getSignalenUsingPOST({lazyLoadData: event})
            .subscribe(
                signalen => {
                    if (signalen.list && signalen.count) {
                        this.signalen = signalen.list;
                        this.signalenCount = signalen.count;
                    } else {
                        this.signalen = new Array<SignaalDAC6DTO>();
                        this.signalenCount = 0;
                    }
                }
            )
    }
}
