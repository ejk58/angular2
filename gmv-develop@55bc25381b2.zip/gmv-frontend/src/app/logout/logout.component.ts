import {Component} from '@angular/core';
import {LoginService} from "../login/login.service";

@Component({
  selector: 'app-logout',
  template: `
    <a (click)="loginService.logout()" *ngIf="loginService.isLoggedIn()">{{loginService.getUser()}} Logout</a>
  `,
})
export class LogoutComponent {
  constructor(public loginService: LoginService) {
  }
}
