import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'bsn'
})
export class BsnPipe implements PipeTransform {

    transform(value: string, ...args: unknown[]): string {
        if (value && value.toString().length < 10) {
            const nr = value.toString().padStart(9, '0');
            return `${nr.slice(0, 4)}.${nr.slice(4, 6)}.${nr.slice(6)}`;
        }
        return value;
    }

}
