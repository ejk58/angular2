import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {TextRestControllerService} from '../generated/services/text-rest-controller.service';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
    selector: 'app-text-editor',
    template: `
	    <label for="tb">{{titel}}</label>
	    <button (click)="showDialog()" pButton pRipple type="button" icon="pi pi-window-maximize"
			    class="p-button-rounded p-button-text maximize"></button>
	    <div id="tb" [innerHTML]="sanitized.bypassSecurityTrustHtml(componentText)" class="textbox"></div>
	    <p-dialog [(visible)]="dialogVisible" [header]="titel" [style]="{height: '90vh', width: '90vw'}"
			    closeIcon="pi pi-window-minimize" (onHide)="hideDialog()">
		    <p-editor [readonly]="readOnly" name="editor" [(ngModel)]="dialogText" styleClass="editor"></p-editor>
		    <ng-template pTemplate="footer">
			    <p-button *ngIf="!readOnly" (click)="textOpslaan()" icon="pi pi-save" label="Opslaan"></p-button>
		    </ng-template>
	    </p-dialog>
    `,
    styles: [`
      .textbox {
        border: lightgrey solid thin;
        margin-top: 8px;
        margin-bottom: 15px;
        overflow-y: scroll;
        height: 200px;
        padding: 0 10px;
      }

      .p-button-text.maximize {
        padding: 0;
        height: 1.3rem;
      }

      ::ng-deep.editor {
        height: calc(80vh - 135px);
      }
    `]
})
export class TextEditorComponent implements OnInit, OnChanges {

    componentText = "";
    dialogText = "";
    dialogVisible = false;
    titel = "Onbekende tekstsoort";

    @Input() soort!: string;
    @Input() readOnly!: boolean;
    @Input() parentId: number | undefined;
    @Input() text!: string;
    @Input() isSignaal: boolean = false;

    constructor(
        private textRestControllerService: TextRestControllerService,
        public sanitized: DomSanitizer
    ) {
    }

    ngOnInit(): void {
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['text']) {
            this.componentText = this.text;
        }
        if (changes['soort']) {
            switch (this.soort) {
                case "OP":
                    this.titel = "Opmerkingen";
                    break;
                case "AA":
                    this.titel = "Aanpak";
                    break;
                case "BE":
                    this.titel = "Bevindingen";
                    break;
                case "CO":
                    this.titel = "Conclusies";
                    break;
            }
        }
    }

    hideDialog() {
        this.dialogVisible = false;
    }

    showDialog() {
        this.dialogText = this.componentText;
        this.dialogVisible = true;
    }

    textOpslaan() {
        if (this.isSignaal) {
            this.textRestControllerService.updateTextDAC6UsingPOST({
                parentId: this.parentId!,
                soort: this.soort,
                body: this.dialogText
            })
                .subscribe(text => {
                    this.componentText = this.dialogText;
                    this.hideDialog();
                })
        } else {
            this.textRestControllerService.updateTextUsingPOST({
                parentId: this.parentId!,
                soort: this.soort,
                body: this.dialogText
            })
                .subscribe(text => {
                    this.componentText = this.dialogText;
                    this.hideDialog();
                })
        }
    }
}
