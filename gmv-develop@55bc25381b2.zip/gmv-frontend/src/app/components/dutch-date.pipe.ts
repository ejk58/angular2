import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'dutchDate'
})
export class DutchDatePipe implements PipeTransform {

  transform(value: string, ...args: unknown[]): unknown {
    if (!value || value.length < 10) return value;
    return value.slice(8, 10) + '-' + value.slice(5, 7) + '-' + value.slice(0, 4);
  }

}
