import {Component, Input} from '@angular/core';
import {PersoonDAC6DTO, PersoonDTO} from '../generated/models';

@Component({
    selector: 'app-persoon-list',
    template: `
	    <label for="perstable">Gekoppelde personen/bedrijven</label>
	    <p-table id="perstable" [value]="personen" [scrollable]="true" scrollHeight="160px" styleClass="table p-datatable-sm">
		    <ng-template pTemplate="header">
			    <tr>
				    <th>Naam</th>
				    <th>TIN</th>
				    <th *ngIf="!isSignaal">Rol</th>
			    </tr>
		    </ng-template>
		    <ng-template let-ri="rowIndex" let-persoon pTemplate="body">
			    <tr>
				    <td id="naam-{{ri}}">{{persoon.naam}}</td>
				    <td id="tin-{{ri}}">{{persoon.tin | bsn}}</td>
				    <td *ngIf="!isSignaal" id="rol-{{ri}}">{{persoon.rol | lookup:'ROL' | async}}</td>
			    </tr>
		    </ng-template>
	    </p-table>
    `,
    styles: ['']
})
export class PersoonListComponent {

    @Input() personen: PersoonDTO[] | PersoonDAC6DTO[];
    @Input() isSignaal: boolean = false;

    constructor() {
        this.personen = [];
    }
}
