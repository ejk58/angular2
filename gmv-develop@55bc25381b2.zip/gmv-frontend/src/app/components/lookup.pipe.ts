import {Pipe, PipeTransform} from '@angular/core';
import {LookupService} from './lookup.service';
import {Observable, of} from 'rxjs';
import {LookupSoort} from '../domain/enums';

@Pipe({
  name: 'lookup'
})
export class LookupPipe implements PipeTransform {

  constructor(private lookupService: LookupService) {
  }

  transform(value: string | undefined, soort: LookupSoort): Observable<string> {
    if (!value) return of('<leeg>');
    return this.lookupService.asyncDescription(value, soort)
  }

}
