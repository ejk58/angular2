import {Injectable} from '@angular/core';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {AllLookupsDTO} from '../generated/models/all-lookups-dto';
import {Lookup} from '../generated/models/lookup';
import {Observable, of} from 'rxjs';
import {map} from 'rxjs/operators';
import {LookupSoort} from '../domain/enums';

@Injectable({
    providedIn: 'root'
})
export class LookupService {
    tabellen: AllLookupsDTO = {rol: [], belastingMiddel: [], status: [], hallmark: [], bhStatus: [], toedeling: [], signaaldac6Status: []};
    initReady = false;

    constructor(private LookupRestControllerService: LookupRestControllerService) {
    }

    public initialize(): Observable<boolean> {
        if (this.initReady) return of(true)
        else return this.LookupRestControllerService.lookupTabellenUsingGET()
            .pipe(
                map(tabellen => {
                    this.tabellen = tabellen;
                    this.initReady = true;
                    return true;
                })
            )
    }

    public get(soort: LookupSoort): Lookup[] {
        if (!this.initReady) throw new Error("Initialize not called");
        switch (soort) {
            case 'ROL':
                return this.tabellen.rol;
            case 'HALLMARK':
                return this.tabellen.hallmark;
            case 'STATUS':
                return this.tabellen.status;
            case 'BHSTATUS':
                return this.tabellen.bhStatus;
            case 'BELASTINGMIDDEL':
                return this.tabellen.belastingMiddel;
            case 'TOEDELING':
                return this.tabellen.toedeling;
            case 'SIGNAALDAC6STATUS':
                return this.tabellen.signaaldac6Status;
        }
    }

    public description(code: string, soort: LookupSoort): string {
        if (!this.initReady) throw new Error("Initialize not called");
        switch (soort) {
            case 'ROL':
                let ret1 = this.tabellen.rol.find(r => r.code?.toUpperCase() == code.toUpperCase())
                return ret1 ? ret1.omschrijving : "";
            case 'HALLMARK':
                let ret2 = this.tabellen.hallmark.find(r => r.code?.toUpperCase() == code.toUpperCase())
                return ret2 ? ret2.omschrijving : "";
            case 'STATUS':
                let ret3 = this.tabellen.status.find(r => r.code?.toUpperCase() == code.toUpperCase())
                return ret3 ? ret3.omschrijving : "";
            case 'BELASTINGMIDDEL':
                let ret4 = this.tabellen.belastingMiddel.find(r => r.code?.toUpperCase() == code.toUpperCase())
                return ret4 ? ret4.omschrijving : "";
            case 'BHSTATUS':
                let ret5 = this.tabellen.bhStatus.find(r => r.code?.toUpperCase() == code.toUpperCase())
                return ret5 ? ret5.omschrijving : "";
            case 'TOEDELING':
                let ret6 = this.tabellen.toedeling.find(r => r.code?.toUpperCase() == code.toUpperCase())
                return ret6 ? ret6.omschrijving : "";
            case 'SIGNAALDAC6STATUS':
                let ret7 = this.tabellen.signaaldac6Status.find(r => r.code?.toUpperCase() == code.toUpperCase())
                return ret7 ? ret7.omschrijving : "";
        }
    }

    public asyncDescription(code: string, soort: LookupSoort): Observable<string> {
        return this.initialize().pipe(map(() => {
            switch (soort) {
                case 'ROL':
                    let ret1 = this.tabellen.rol.find(r => r.code?.toUpperCase() == code.toUpperCase())
                    return ret1 ? ret1.omschrijving : "";
                case 'HALLMARK':
                    let ret2 = this.tabellen.hallmark.find(r => r.code?.toUpperCase() == code.toUpperCase())
                    return ret2 ? ret2.omschrijving : "";
                case 'STATUS':
                    let ret3 = this.tabellen.status.find(r => r.code?.toUpperCase() == code.toUpperCase())
                    return ret3 ? ret3.omschrijving : "";
                case 'BELASTINGMIDDEL':
                    let ret4 = this.tabellen.belastingMiddel.find(r => r.code?.toUpperCase() == code.toUpperCase())
                    return ret4 ? ret4.omschrijving : "";
                case 'BHSTATUS':
                    let ret5 = this.tabellen.bhStatus.find(r => r.code?.toUpperCase() == code.toUpperCase())
                    return ret5 ? ret5.omschrijving : "";
                case 'TOEDELING':
                    let ret6 = this.tabellen.toedeling.find(r => r.code?.toUpperCase() == code.toUpperCase())
                    return ret6 ? ret6.omschrijving : "";
                case 'SIGNAALDAC6STATUS':
                    let ret7 = this.tabellen.signaaldac6Status.find(r => r.code?.toUpperCase() == code.toUpperCase())
                    return ret7 ? ret7.omschrijving : "";
            }
        }));
    }
}

