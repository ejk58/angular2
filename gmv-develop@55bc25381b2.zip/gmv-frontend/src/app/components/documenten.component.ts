import {Component, EventEmitter, Input, Output, ViewChild} from '@angular/core';
import {MeldingDTO} from '../generated/models/melding-dto';
import {FilenetDocument} from '../generated/models/filenet-document';
import {DocumentRestControllerService} from '../generated/services/document-rest-controller.service';
import {Table} from 'primeng/table';
import {SignaalDAC6DTO} from '../generated/models/signaal-dac6dto';

@Component({
    selector: 'app-documenten',
    template: `
	    <div class="roField docs" id="docs" name="docs">
		    <span class="doctext">Aantal: {{parent?.documenten?.length}}</span>
		    <button (click)="showDocumentUploadDialog()" class="p-button-rounded p-button-text" icon="pi pi-paperclip" pButton
				    id="paperclip" pRipple style="height: 26px" type="button"></button>
	    </div>
	    <p-dialog [(visible)]="displayDocumentUpload" [modal]="true" [style]="{width: '80vw'}" [draggable]="false"
			    [resizable]="false">
		    <ng-template pTemplate="header">
			    <h2>Documenten koppelen</h2>
			    <spinner class="spinner" color="#01689b"></spinner>
		    </ng-template>
		    <p-fileUpload (uploadHandler)="onUpload($event)" *ngIf="!isEndState(parent)" [customUpload]="true"
				    [showCancelButton]="false" [accept]="acceptedTypes" chooseLabel="Kies document" name="myfile[]"
				    uploadLabel="Toevoegen">
			    <ng-template pTemplate="content">
				    <div class="p-fluid">
					    <div class="p-field">
						    <label for="omschrijving">Omschrijving</label> <textarea [(ngModel)]="omschrijving" id="omschrijving"
							    name="omschrijving" pInputText rows="3" type="text"></textarea>
					    </div>
				    </div>
			    </ng-template>
		    </p-fileUpload>
		    <p>&nbsp;</p>
		    Gekoppelde documenten
		    <p-table #dt [autoLayout]="true" [value]="documentenTable" dataKey="id" editMode="row" rowExpandMode="single"
				    styleClass="wg-tabel p-datatable-sm">
			    <ng-template pTemplate="header">
				    <tr>
					    <th id="th1">Naam</th>
					    <th id="th2"></th>
				    </tr>
			    </ng-template>
			    <ng-template let-ri="rowIndex" let-rowData pTemplate="body">
				    <tr [id]="rowData.id" [pEditableRow]="rowData">
					    <td>
						    <button (click)="showDocument(rowData)" [id]="'naam_'+ri" [label]="rowData.fileName"
								    class="p-button-link link-in-table" pButton type="button"></button>
					    </td>
					    <td *ngIf="!isEndState(parent)" style="text-align:center">
						    <button (click)="deleteDocument(rowData, ri)" [id]="'bDocumentDelete_'+ri" [ngClass]="'toolbutton'"
								    icon="pi pi-trash" pButton type="button"></button>
					    </td>
				    </tr>
			    </ng-template>
		    </p-table>
		    <ng-template pTemplate="footer">
			    <p-button (click)="closeDocumentDialog()" icon="pi pi-check" label="Ok" styleClass="p-button-text"></p-button>
		    </ng-template>
	    </p-dialog>
    `,
    styles: [`
      .docs {
        padding: 0 4px;
      }

      .doctext {
        position: relative;
        top: -4px;
      }

      .link-in-table {
        padding: 0;
      }

      td {
        ::ng-deep .p-button-label {
          flex: 0 1 auto;
        }
      }
    `]
})
export class DocumentenComponent {
    acceptedTypes = ".doc, .docx, .eml, .jpeg, .jpg, .mp3, .mp4, .mpg, .mpeg, .mxf, .odp, .ods, .odt, .pdf, .png, .ppt, .pptx, .tif, .tiff, .txt, .wav, .xbrl, .xls, .xlsx, .xml";
    @Input() parent!: MeldingDTO | SignaalDAC6DTO;
    @Output() refresh = new EventEmitter();
    @Input() isSignaal: boolean = false;

    displayDocumentUpload = false;
    documentenTable: FilenetDocument[] = [];
    omschrijving = "";

    @ViewChild("dt") table!: Table;

    constructor(private documentRestControllerService: DocumentRestControllerService) {
    }

    onUpload(event: { files: any; }) {
        for (let file of event.files) {
            this.documentRestControllerService.handleFileUploadUsingPOST({
                file: file,
                meldingId: this.parent!.id!,
                omschrijving: this.omschrijving
            }).subscribe(() => {
                this.loadDocuments();
            });
        }
    }

    deleteDocument(document: FilenetDocument, index: number) {
        this.documentRestControllerService.deleteDocumentUsingDELETE({
            meldingId: this.parent?.id || 0,
            docId: document?.docId || 'notfound'
        }).subscribe(
            () => {
                this.loadDocuments()
            }
        )
    }

    showDocument(rowData: FilenetDocument) {
        window.open(rowData.docURL, "_blank");
    }

    showDocumentUploadDialog() {
        this.loadDocuments();
        this.displayDocumentUpload = true;
    }

    closeDocumentDialog() {
        this.displayDocumentUpload = false;
        this.refresh.emit();
    }

    loadDocuments() {
        this.documentRestControllerService.getAllDocumentsUsingGET({meldingId: this.parent!.id!}).subscribe(
            result => {
                this.documentenTable = result;
                this.table.reset()
            })
    }

    isEndState(melding: MeldingDTO | SignaalDAC6DTO): boolean {
        return (melding != undefined && (melding.currentStatus == 'DONE_NO_REVIEW'
            || melding.currentStatus == 'DONE_REVIEW' || melding.currentStatus == 'DONE'))
    }
}
