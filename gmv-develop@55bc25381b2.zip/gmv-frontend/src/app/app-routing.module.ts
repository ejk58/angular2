import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoginComponent} from './login/login.component';
import {MainComponent} from './main/main.component';
import {LoggedInGuard} from './login/logged-in.guard';
import {NieuwComponent} from './nieuw/nieuw.component';
import {DetailComponent} from './detail/detail.component';
import {NieuwSignaalComponent} from './nieuw-signaal/nieuw-signaal.component';
import {SignaalOverzichtComponent} from './signaal-overzicht/signaal-overzicht.component';
import {DetailSignaalComponent} from './detail-signaal/detail-signaal.component';

const routes: Routes = [
  {path: '', component: MainComponent, canActivate: [LoggedInGuard]},
  {path: 'login', component: LoginComponent},
  {path: 'main', component: MainComponent},
  {path: 'signaaloverzicht', component: SignaalOverzichtComponent},
  {path: 'nieuw', component: NieuwComponent},
  {path: 'nieuwsignaal', component: NieuwSignaalComponent},
  {path: 'detail/:id', component: DetailComponent},
  {path: 'detailsignaal/:id', component: DetailSignaalComponent},
  {path: '**', redirectTo: ''}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
