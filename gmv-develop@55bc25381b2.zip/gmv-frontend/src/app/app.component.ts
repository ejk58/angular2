import {Component, OnInit} from '@angular/core';
import {MenuItem} from 'primeng/api';
import {LoginService} from "./login/login.service";
import {PubsubService} from './pubsub/pubsub.service';
import {AutorisationEvent} from './pubsub/autorisation-event';
import {StroomRestControllerService} from './generated/services/stroom-rest-controller.service';
import {MeldingRestControllerService} from './generated/services/melding-rest-controller.service';
import {LookupRestControllerService} from './generated/services/lookup-rest-controller.service';
import {TextRestControllerService} from './generated/services/text-rest-controller.service';
import {DocumentRestControllerService} from './generated/services/document-rest-controller.service';
import {BatRestControllerService} from './generated/services/bat-rest-controller.service';
import {SignaalDac6RestControllerService} from './generated/services/signaal-dac-6rest-controller.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    items: MenuItem[] = [];
    title = 'Generieke Meldingen Voorziening';

    constructor(
        private readonly stroomRestControllerService: StroomRestControllerService,
        private readonly meldingRestControllerService: MeldingRestControllerService,
        private readonly lookupRestControllerService: LookupRestControllerService,
        private readonly textRestControllerService: TextRestControllerService,
        private readonly documentRestControllerService: DocumentRestControllerService,
        private readonly batRestControllerService: BatRestControllerService,
        private readonly signaalDac6RestControllerService: SignaalDac6RestControllerService,
        public readonly loginService: LoginService,
        private readonly pubsub: PubsubService,
    ) {
    }

    public get stroom() {
        return localStorage.getItem('stroom');
    }

    ngOnInit(): void {
        this.stroomRestControllerService.rootUrl = location.origin;
        this.meldingRestControllerService.rootUrl = location.origin;
        this.lookupRestControllerService.rootUrl = location.origin;
        this.textRestControllerService.rootUrl = location.origin;
        this.documentRestControllerService.rootUrl = location.origin;
        this.batRestControllerService.rootUrl = location.origin;
        this.signaalDac6RestControllerService.rootUrl = location.origin;
        this.fillItems();

        this.pubsub.subscribe(AutorisationEvent).subscribe(actie => {
            this.items = [];
            if (actie.login) {
                this.fillItems();
            }
        })
    }

    private fillItems() {
        this.items.push({id: "tabOverzicht", label: 'Overzicht', icon: 'pi pi-fw pi-list', routerLink: 'main'});
        this.items.push({id: "tabNieuwMelding", label: 'Nieuwe melding', icon: 'pi pi-fw pi-pencil', routerLink: 'nieuw'});
        this.items.push({
            id: "tabSignaalOverzicht",
            label: 'Signaaloverzicht',
            icon: 'pi pi-fw pi-list',
            routerLink: 'signaaloverzicht'
        });
        this.items.push({id: "tabNieuwSignaal", label: 'Nieuw Signaal', icon: 'pi pi-fw pi-pencil', routerLink: 'nieuwsignaal'});
    }
}
