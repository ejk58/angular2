export interface ApplicationUser {
    username: string;
    password: string;
    stroom?: string;
}
