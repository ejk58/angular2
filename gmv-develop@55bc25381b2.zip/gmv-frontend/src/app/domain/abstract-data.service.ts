import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {throwError} from 'rxjs';
import {Injectable} from '@angular/core';

@Injectable()
export class AbstractDataService {
  constructor(protected http: HttpClient) {
  }

  protected handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      if (error.status === 401) {
        return throwError({
          status: error.status,
          statusText: 'Inloggen mislukt. Mogelijk is uw userid/wachtwoord niet correct.'
        })
      }
      if (error.status === 403) {
        return throwError({
          status: error.status,
          statusText: 'Inloggen mislukt. U bent niet (meer) geautoriseerd voor deze applicatie.'
        })
      }
      if (error.status === 500) {
        return throwError({status: error.status, statusText: 'Er is een onverwachte fout opgetreden op de server.'})
      }
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${JSON.stringify(error.error)}`);
    }
    return throwError(error);
  }
}
