export interface Signal {
  zaakReference: string;
  subject: string;
  subjectType: string;
  signaalCode: string;
  workgroupId: string;
  created: Number;
  specific: any;
}
