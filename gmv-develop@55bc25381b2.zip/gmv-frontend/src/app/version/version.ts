export interface Version {
  git: Git;
}

export interface Git {
  build: Build;
  commit: Commit;
}

export interface Build {
  version: string;
}

export interface Commit {
  id: Id;
  time: string;
}

export interface Id {
  abbrev: string;
}
