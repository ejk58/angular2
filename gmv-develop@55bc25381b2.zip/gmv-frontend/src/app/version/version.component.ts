import {Component, OnInit} from '@angular/core';
import {Version} from './version';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-version',
  templateUrl: './version.component.html',
  styleUrls: []
})
export class VersionComponent implements OnInit {

  public version!: Version;

  constructor(protected http: HttpClient) {
  }

  ngOnInit(): void {
    this.http.get<Version>(`/actuator/info`)
      .subscribe(value => this.version = value, error => console.log(error));
  }
}
