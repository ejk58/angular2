import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {MeldingRestControllerService} from '../generated/services/melding-rest-controller.service';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {Lookup} from '../generated/models/lookup';
import {Table} from 'primeng/table';
import {MyLazyLoadEvent} from './MyLazyLoadEvent';
import {FilterMetadata} from 'primeng/api/filtermetadata';
import {Router} from '@angular/router';
import {MeldingDTO} from '../generated/models';
import {LookupService} from '../components/lookup.service';

@Component({
    selector: 'app-main',
    templateUrl: './main.component.html',
    styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {

    meldingenCount = 0;
    meldingen = new Array<MeldingDTO>();
    hallmarks: Array<Lookup> = new Array<Lookup>();
    statussen: Array<Lookup> = new Array<Lookup>();
    middelen: Array<Lookup> = new Array<Lookup>();
    @ViewChild("table") table!: Table;
    @ViewChild("naam") naam!: ElementRef;
    previousEventData!: MyLazyLoadEvent;
    rowsPerPage = 15;
    initialLoad = true;

    constructor(private lookup: LookupRestControllerService,
                private meldingRestControllerService: MeldingRestControllerService,
                private router: Router,
                private lookupService: LookupService) {
    }

    zoekNaam(melding: MeldingDTO): string {
        if (melding && melding.personen) {
            let persoon = melding.personen.find(p => {
                return p.naam?.toLowerCase().includes(this.previousEventData.globalFilter.toString().toLowerCase())
            })
            return persoon && persoon.naam ? persoon.naam : "foutje";
        }
        return "grote fout";
    }

    clearFilters() {
        this.table.clear();
        this.naam.nativeElement.value = "";
    }

    filterNaam($event: any) {
        this.table.filterGlobal($event.target.value, 'contains');
    }

    bgColor(naam: string): string {
        if (<boolean>(this.previousEventData.filters && this.previousEventData.filters[naam] && this.previousEventData.filters[naam].length > 0 && this.previousEventData.filters[naam][0].value)) {
            return 'lightBlue';
        } else return '';
    }

    ngOnInit(): void {
        this.lookupService.initialize().subscribe(() => {
            this.middelen = this.lookupService.get("BELASTINGMIDDEL");
            this.statussen = this.lookupService.get("STATUS");
            this.hallmarks = this.lookupService.get("HALLMARK");
        })
    }

    changeHallmark(ev: { value: string }) {
        this.loadMeldingen(this.previousEventData);
    }

    toDetail(melding: MeldingDTO) {
        this.router.navigate(["detail", melding.id]);
    }

    loadMeldingen(event: MyLazyLoadEvent) {
        //
        // Eigen definitie van LazyLoadEvent vanwege verkeerde definitie in PrimeNg
        // Zie pullrequest: https://github.com/primefaces/primeng/pull/10337
        // Wanneer die gemerged is kan dit type weer standaard worden
        //
        if (this.initialLoad) {
            this.initialLoad = false;
            event.filters!["status"] = [];
            const st: FilterMetadata = {value: "NEW"};
            event.filters!["status"].push(st);
        }
        this.previousEventData = event;

        if (event.filters != null && event.filters["hallmark"] != null && event.filters["hallmark"][0].value != null) {
            event.sortField = "prioriteit";
            event.sortOrder = +1;
        }
        if (event.filters != null && event.filters["global"] != null) {
            // Deze actie is nodig omdat filterGlobal ook een global filter aanmaakt,
            // maar zonder operator, en dat levert problemen op in java
            delete event.filters["global"];
        }
        this.meldingRestControllerService.getMeldingenUsingPOST({lazyLoadData: event})
            .subscribe(
                meldingen => {
                    if (meldingen.list && meldingen.count) {
                        this.meldingen = meldingen.list;
                        this.meldingenCount = meldingen.count;
                    } else {
                        this.meldingen = [];
                        this.meldingenCount = 0;
                    }
                }
            )
    }
}
