import {SortMeta} from 'primeng/api/sortmeta';
import {FilterMetadata} from 'primeng/api/filtermetadata';

export interface MyLazyLoadEvent {
    first?: number;
    rows?: number;
    sortField?: string;
    sortOrder?: number;
    multiSortMeta?: SortMeta[];
    filters?: {
        [s: string]: FilterMetadata[];
    };
    globalFilter?: any;
}
