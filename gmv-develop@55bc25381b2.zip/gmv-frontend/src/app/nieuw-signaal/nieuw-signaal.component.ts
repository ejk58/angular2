import {Component, OnInit} from '@angular/core';
import {Lookup} from '../generated/models/lookup';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {MessageService} from 'primeng/api';
import {Router} from '@angular/router';
import {DatePipe} from '@angular/common';
import {PersoonDTO} from '../generated/models/persoon-dto';
import {PrioriteitDTO} from '../generated/models/prioriteit-dto';
import {timer} from 'rxjs';
import {LdapPerson} from '../generated/models/ldap-person';
import {SignaalDac6RestControllerService} from '../generated/services/signaal-dac-6rest-controller.service';
import {SignaalDAC6NewDTO} from '../generated/models/signaal-dac6new-dto';

@Component({
    selector: 'app-nieuw-signaal',
    templateUrl: 'nieuw-signaal.component.html',
    styleUrls: ['nieuw-signaal.component.scss']
})
export class NieuwSignaalComponent implements OnInit {
    jaar: number | undefined;
    datumOntvangen = new Date();
    selectedBelastingmiddelen: Lookup[] = [];
    belastingmiddelen: Lookup[] = [];
    toedelingen: Lookup[] = [];
    persoonInEdit = false;
    hallmarkInEdit = false;
    personen: PersoonDTO[] = [];
    prioriteiten: PrioriteitDTO[] = [];
    signaal = '';
    naam: LdapPerson = {};
    kantoor = '';
    segment!: Lookup;
    users: LdapPerson[] = [];
    selectedUser: LdapPerson = {};
    zoekText = '';

    constructor(private signaalDac6RestControllerService: SignaalDac6RestControllerService,
                private lookupService: LookupRestControllerService,
                private messageService: MessageService,
                private router: Router,
                private datePipe: DatePipe) {
    }

    ngOnInit(): void {
        this.lookupService.lookupTabelUsingGET({tabel: "BELASTINGMIDDEL"}).subscribe((result) => {
            this.belastingmiddelen = result;
        });
        this.lookupService.lookupTabelUsingGET({tabel: "TOEDELING"}).subscribe((result) => {
            this.toedelingen = result;
        });
    }

    public getJaren() {
        let ret = [2018];
        let max = new Date().getFullYear() + 5;
        for (let i = 2019; i < max; i++) {
            ret.push(i);
        }
        return ret;
    }

    private convertDate(date: Date | undefined): string {
        // The dateFormat="dd-mm-yy", defined in the HTML, doesn't convert the actual date. Need to do it manually.
        let d = this.datePipe.transform(date, 'dd-MM-yyyy');
        return d === null ? '' : d;
    }

    onSubmit() {
        if (!this.validateForm()) {
            return;
        }

        const signaal: SignaalDAC6NewDTO = {
            jaar: this.jaar,
            belastingMiddellen: this.selectedBelastingmiddelen.map(b => b.code).join(),
            signaal: this.signaal,
            kantoor: this.kantoor,
            segment: this.segment?.code,
            naam: this.naam?.userId,
            datumOntvangen: this.convertDate(this.datumOntvangen),
            personen: this.personen.map(value => {
                return {
                    tin: value.tin,
                    naam: value.naam
                }
            }),
            hallmarks: this.prioriteiten.map(value => value.hallmark)
        };

        this.signaalDac6RestControllerService.createSignaalUsingPOST({body: signaal}).subscribe(
            () => {
                this.messageService.add({
                    severity: 'info',
                    summary: 'Signaal succesvol opgeslagen',
                });
                timer(2000).subscribe(() => {
                    this.router.navigate(['signaaloverzicht']);
                });
            });
    }

    private validateForm(): boolean {
        this.messageService.clear()
        let errorMsg = '';
        if (this.persoonInEdit) {
            errorMsg += this.createCustomMsg("Er is nog een openstaande wijziging bij persoon")
        }
        if (this.hallmarkInEdit) {
            errorMsg += this.createCustomMsg("Er is nog een openstaande wijziging bij hallmark")
        }
        if (!this.naam.userId) {
            errorMsg += this.createRequiredMsg('Naam');
        }
        if (this.personen.length == 0) {
            errorMsg += this.createCustomMsg('Er zijn geen personen toegevoegd aan de melding');
        }
        if (!this.signaal) {
            errorMsg += this.createRequiredMsg('Signaal');
        }

        if (errorMsg) {
            this.messageService.add({
                severity: 'error',
                summary: 'De melding bevat nog fouten',
                detail: errorMsg,
                sticky: true
            });
            return false;
        }
        return true;
    }
    private createRequiredMsg(value: string): string {
        return '- ' + value + ' is een verplicht veld\r\n';
    }

    private createCustomMsg(msg: string): string {
        return '- ' + msg + '\r\n';
    }

    searchUser(event: any) {
        const zoek = event.query as string;
        this.lookupService.getPersonsByUseridOrLastNameUsingGET({search: zoek}).subscribe(users => {
            this.users = users;
        })
    }

    userIsSelected(selUser: LdapPerson) {
        this.naam = selUser;
    }
}
