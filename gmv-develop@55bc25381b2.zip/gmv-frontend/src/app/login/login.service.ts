import {Injectable} from '@angular/core';
import {catchError, map} from 'rxjs/operators';
import {ApplicationUser} from '../domain/applicationuser';
import {AbstractDataService} from '../domain/abstract-data.service';
import {JwtHelperService} from '@auth0/angular-jwt';
import {HttpClient} from '@angular/common/http';
import {Router} from '@angular/router';
import {PubsubService} from '../pubsub/pubsub.service';
import {AutorisationEvent} from '../pubsub/autorisation-event';

@Injectable()
export class LoginService extends AbstractDataService {
  constructor(http: HttpClient, private router: Router, private pubsub: PubsubService) {
    super(http);
  }

  isLoggedIn() {
    const token = localStorage.getItem('id_token');
    if (token == null) {
      return false;
    }
    const jwtHelper = new JwtHelperService();
    const isExpired = jwtHelper.isTokenExpired(token);
    const date = jwtHelper.getTokenExpirationDate(token);
    return !isExpired;
  }

  login(user: ApplicationUser) {
    localStorage.removeItem('id_token');
    localStorage.removeItem('user');
    localStorage.removeItem('stroom');
    return this.http.post('/api/login', user)
      .pipe(
        map(value => {
          this.pubsub.publish(AutorisationEvent, new AutorisationEvent(true))
              localStorage.setItem('user', user.username.toUpperCase());
              localStorage.setItem('stroom', user.stroom!.toUpperCase());
          return value;
        }
        ), catchError(this.handleError));
  }

  logout() {
    this.pubsub.publish(AutorisationEvent, new AutorisationEvent(false))
    localStorage.removeItem('id_token');
    localStorage.removeItem('user');
    localStorage.removeItem('roles');
    this.router.navigate(['login']);
  }

  getUser() {
    return localStorage.getItem('user')
  }

  hasRole(rol: string): boolean {
    const role = localStorage.getItem('roles');
    const roles = role?.split(',')
    let b = roles?.includes(rol);
    return b ? b : false;
  }
}
