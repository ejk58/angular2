import {Component, OnInit} from '@angular/core';
import {LoginService} from './login.service';
import {ApplicationUser} from '../domain/applicationuser';
import {Router} from '@angular/router';
import {StroomRestControllerService} from '../generated/services/stroom-rest-controller.service';
import {Stroom} from '../generated/models/stroom';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  serviceError: any;

  model: ApplicationUser = {username: '', password: ''};
  stromen!: Stroom[];

  constructor(private loginService: LoginService, private router: Router, private stroomRestControllerService: StroomRestControllerService) {
  }

  ngOnInit() {
    this.stroomRestControllerService.getStromenUsingGET().subscribe(
        stromen => {
          this.stromen = stromen;
          let stroom = localStorage.getItem('stroom');
          if (stroom != null) {
            let currentStroom = this.stromen.find(str => str.naam == stroom)?.naam
            if (currentStroom != undefined) {
              this.model.stroom = currentStroom;
            }
          }
        }
    )
  }

  login() {
    this.resetAlert();
    this.loginService.login(this.model).subscribe(
        (data) => {
          this.router.navigate(['']);
        },
        (error: any) => {
          this.serviceError = `Error ${error.status}: ${error.statusText}`;
          this.model.password = '';
        }
    );
  }

  resetAlert() {
    this.serviceError = null;
  }
}
