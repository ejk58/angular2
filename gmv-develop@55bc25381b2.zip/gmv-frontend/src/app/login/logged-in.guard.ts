import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Router} from '@angular/router';
import {LoginService} from './login.service';
import {PubsubService} from '../pubsub/pubsub.service';

@Injectable({
  providedIn: 'root'
})
export class LoggedInGuard implements CanActivate {

  constructor(private loginService: LoginService, private router: Router, private pubsub: PubsubService) {
  }

  canActivate(route: ActivatedRouteSnapshot): boolean {
    if (!this.loginService.isLoggedIn()) {
      this.router.navigate(['login']);
    }
    return true
    // return this.loginService.hasRole(route.data.role)
  }
}
