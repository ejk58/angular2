import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {Table} from 'primeng/table';
import {MessageService} from 'primeng/api';
import {Lookup} from '../generated/models/lookup';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {PrioriteitNewDTO} from '../generated/models/prioriteit-new-dto';

@Component({
    selector: 'app-prioriteit',
    templateUrl: './prioriteit.component.html',
    styleUrls: ['./prioriteit.component.css']
})
export class PrioriteitComponent implements OnInit {

    @ViewChild('dt') dataTable!: Table;
    @Input() prioriteiten: PrioriteitNewDTO[];
    @Input() inEdit!: boolean;
    @Input() isSignaal!: boolean;
    @Output() inEditChange = new EventEmitter<boolean>();

    prioriteitenTable: PrioriteitEntity[];
    hallmarks: Lookup[];
    clonedPrioriteiten: { [s: string]: PrioriteitEntity; } = {};

    constructor(private lookupService: LookupRestControllerService, private readonly messageService: MessageService) {
        this.hallmarks = [];
        this.prioriteitenTable = [];
        this.prioriteiten = [];
    }

    ngOnInit() {
        this.lookupService.lookupTabelUsingGET({tabel: "HALLMARK"})
            .subscribe((result) => {
                this.hallmarks = result;
            });
    }

    deleteHallmark(prioriteit: PrioriteitEntity, index: number) {
        this.prioriteitenTable.splice(index, 1);
        this.prioriteiten.splice(index, 1);
    }

    onRowEditInit(prioriteit: PrioriteitEntity, index: number) {
        this.clonedPrioriteiten[index] = {...prioriteit};
        this.inEditChange.emit(true);
    }

    onRowEditSave(prioriteit: PrioriteitEntity, index: number) {
        prioriteit.id = index;
        this.prioriteitenTable.splice(index, 1, prioriteit);

        let nieuw: PrioriteitNewDTO = {
            hallmark: prioriteit.hallmark,
            prioriteit: prioriteit.prioriteit
        }
        if (this.prioriteiten.length < index) {
            this.prioriteiten.push(nieuw);
        } else {
            this.prioriteiten.splice(index, 1, nieuw);
        }
        this.inEditChange.emit(false);
    }

    onRowEditCancel(index: number) {
        if (this.prioriteitenTable.filter(p => p.id == -1).length == 1) {
            this.prioriteitenTable.splice(index, 1);
        } else {
            this.prioriteitenTable[index] = this.clonedPrioriteiten[index];
            delete this.clonedPrioriteiten[index];
        }
        this.inEditChange.emit(false);
    }

    onNew() {
        if (this.prioriteitenTable.filter(p => p.id == -1).length == 1) {
            return;
        }
        let index = this.prioriteitenTable.push({id: -1});

        this.dataTable.editingRowKeys['-1'] = true;
        this.inEditChange.emit(true);
    }
}

interface PrioriteitEntity extends PrioriteitNewDTO {
    id?: number;
}
