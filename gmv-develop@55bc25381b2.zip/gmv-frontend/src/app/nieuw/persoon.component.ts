import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {Table} from 'primeng/table';
import {timer} from 'rxjs';
import {MessageService} from 'primeng/api';
import {Lookup} from '../generated/models/lookup';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {PersoonNewDTO} from '../generated/models/persoon-new-dto';

@Component({
    selector: 'app-persoon',
    templateUrl: './persoon.component.html',
    styleUrls: ['./persoon.component.css']
})
export class PersoonComponent implements OnInit {

    @ViewChild('dt') dataTable!: Table;
    @Input() personen: PersoonNewDTO[];
    @Input() inEdit!: boolean;
    @Input() isSignaal!: boolean;
    @Output() inEditChange = new EventEmitter<boolean>();
    personenTable: PersoonEntity[];
    rollen: Lookup[];
    clonedPersonen: { [s: string]: PersoonEntity; } = {};

    constructor(private lookupService: LookupRestControllerService, private readonly messageService: MessageService) {
        this.rollen = [];
        this.personenTable = [];
        this.personen = [];
    }

    ngOnInit() {
        this.lookupService.lookupTabelUsingGET({tabel: "ROL"}).subscribe((result) => {
            this.rollen = result;
        });
        let i = 0;
        this.personen.forEach(p => {
            this.personenTable.push({id: i++, rol: p.rol, tin: p.tin, naam: p.naam})
        });
    }

    deletePersoon(persoon: PersoonEntity, index: number) {
        this.personenTable.splice(index, 1);
        this.personen.splice(index, 1);
    }

    onRowEditInit(persoon: PersoonEntity, index: number) {
        // this.inEdit = true;
        this.inEditChange.emit(true)
        this.clonedPersonen[index] = {...persoon};
    }

    onRowEditSave(persoon: PersoonEntity, index: number) {
        persoon.id = index;
        this.personenTable.splice(index, 1, persoon);

        let nieuw: PersoonNewDTO = {
            naam: persoon.naam,
            tin: persoon.tin,
            rol: persoon.rol
        }
        if (this.personen.length < index) {
            this.personen.push(nieuw);
        } else {
            this.personen.splice(index, 1, nieuw);
        }
        this.inEditChange.emit(false)
    }

    onRowEditCancel(index: number) {
        if (this.personenTable.filter(p => p.id == -1).length == 1) {
            this.personenTable.splice(index, 1);
        } else {
            this.personenTable[index] = this.clonedPersonen[index];
            delete this.clonedPersonen[index];
        }
        this.inEditChange.emit(false)
    }

    onNew() {
        this.inEditChange.emit(true)
        if (this.personenTable.filter(p => p.id == -1).length == 1) {
            return;
        }

        let index = this.personenTable.push({id: -1});
        this.dataTable.editingRowKeys['-1'] = true;
        timer(200).subscribe(() => {
            let input = document.getElementById(`naamEditable_${index - 1}`)
            // @ts-ignore value should always exist
            input.focus();
        })
    }

}

interface PersoonEntity extends PersoonNewDTO {
    id?: number;
}
