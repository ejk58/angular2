import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {Lookup} from '../generated/models/lookup';
import {MessageService} from 'primeng/api';
import {PersoonDTO} from '../generated/models/persoon-dto';
import {PrioriteitDTO} from '../generated/models/prioriteit-dto';
import {MeldingRestControllerService} from '../generated/services/melding-rest-controller.service';
import {LookupRestControllerService} from '../generated/services/lookup-rest-controller.service';
import {DatePipe} from '@angular/common';
import {Router} from '@angular/router';
import {timer} from 'rxjs';
import {MeldingNewDTO} from '../generated/models/melding-new-dto';
import * as moment from 'moment';

@Component({
    selector: 'app-nieuw',
    templateUrl: './nieuw.component.html',
    styleUrls: ['page-styles.scss', './nieuw.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class NieuwComponent implements OnInit {

    arrangementId = '';
    disclosureId = '';
    indiendatum: Date | undefined;
    implementatiedatum: Date | undefined;
    samenvatting = '';
    personen: PersoonDTO[];
    prioriteiten: PrioriteitDTO[];

    belastingmiddelen: Lookup[];
    selectedBelastingmiddelen: Lookup[];
    persoonInEdit = false;
    hallmarkInEdit = false;

    constructor(private meldingService: MeldingRestControllerService,
                private lookupService: LookupRestControllerService,
                private messageService: MessageService,
                private router: Router,
                private datePipe: DatePipe) {
        this.belastingmiddelen = [];
        this.selectedBelastingmiddelen = [];
        this.personen = [];
        this.prioriteiten = [];
    }

    ngOnInit() {
        this.lookupService.lookupTabelUsingGET({tabel: "BELASTINGMIDDEL"}).subscribe((result) => {
            this.belastingmiddelen = result;
        });
    }

    onSubmit() {
        while (this.arrangementId.endsWith('_')) {
            this.arrangementId = this.arrangementId.slice(0, 14) + '0' + this.arrangementId.slice(14, 20)
        }
        while (this.disclosureId.endsWith('_')) {
            this.disclosureId = this.disclosureId.slice(0, 14) + '0' + this.disclosureId.slice(14, 20)
        }

        if (!this.validateForm()) {
            return;
        }

        const regex = / /g
        const melding: MeldingNewDTO = {
            arrangementId: this.arrangementId.replace(regex, ''),
            disclosureId: this.disclosureId.replace(regex, ''),
            indienDatum: this.convertDate(this.indiendatum),
            implementatieDatum: this.convertDate(this.implementatiedatum),
            belastingMiddellen: this.selectedBelastingmiddelen.map(b => b.code).join(),
            samenvatting: this.samenvatting,
            personen: this.personen,
            prioriteiten: this.prioriteiten,
        };

        this.meldingService.createMeldingUsingPOST({body: melding, Authorization: ""}).subscribe(() => {
            this.messageService.add({
                severity: 'info',
                summary: 'Melding succesvol opgeslagen',
            });
            timer(2000).subscribe(() => {
                this.router.navigate(['']);
            });
        });
    }

    private convertDate(date: Date | undefined): string {
        // The dateFormat="dd-mm-yy", defined in the HTML, doesn't convert the actual date. Need to do it manually.
        let d = this.datePipe.transform(date, 'dd-MM-yyyy');
        return d === null ? '' : d;
    }

    private validateForm(): boolean {
        this.messageService.clear()
        let errorMsg = '';
        if (this.persoonInEdit) {
            errorMsg += this.createCustomMsg("Er is nog een openstaande wijziging bij persoon")
        }
        if (this.hallmarkInEdit) {
            errorMsg += this.createCustomMsg("Er is nog een openstaande wijziging bij hallmark")
        }
        if (!this.arrangementId) {
            errorMsg += this.createRequiredMsg('Arrangement');
        }
        if (!moment(this.arrangementId, 'YYYY MM DD').isValid()) {
            errorMsg += this.createCustomMsg("Arrangement bevat geen geldige datum")
        }
        if (!this.disclosureId) {
            errorMsg += this.createRequiredMsg('Disclosure');
        }
        if (!moment(this.disclosureId, 'YYYY MM DD').isValid()) {
            errorMsg += this.createCustomMsg("Disclosure bevat geen geldige datum")
        }
        if (!this.indiendatum) {
            errorMsg += this.createRequiredMsg('Indiendatum');
        }
        if (!this.implementatiedatum) {
            errorMsg += this.createRequiredMsg('Implementatiedatum');
        }
        if (!this.selectedBelastingmiddelen || this.selectedBelastingmiddelen.length == 0) {
            errorMsg += this.createRequiredMsg('Belastingmiddel');
        }
        if (this.personen.length == 0) {
            errorMsg += this.createCustomMsg('Er zijn geen personen toegevoegd aan de melding');
        } else {
            if (this.personen.filter(persoon => !persoon.rol).length > 0) {
                errorMsg += this.createRequiredMsg('Rol');
            }
            if (this.personen.filter(persoon => !persoon.tin && !persoon.naam).length > 0) {
                errorMsg += this.createCustomMsg('Een persoon moet of een TIN of een naam bevatten');
            }
        }
        if (this.prioriteiten.length == 0) {
            errorMsg += this.createCustomMsg('Er zijn geen hallmarks toegevoegd aan de melding');
        } else {
            if (this.prioriteiten.filter(prio => !prio.hallmark).length > 0) {
                errorMsg += this.createRequiredMsg('Hallmark');
            }
            if (this.prioriteiten.filter(prio => !prio.prioriteit).length > 0) {
                errorMsg += this.createRequiredMsg('Prioriteit');
            }
        }
        if (!this.samenvatting) {
            errorMsg += this.createRequiredMsg('Samenvatting');
        }

        if (errorMsg) {
            this.messageService.add({
                severity: 'error',
                summary: 'De melding bevat nog fouten',
                detail: errorMsg,
                sticky: true
            });
            return false;
        }
        return true;
    }

    private createRequiredMsg(value: string): string {
        return '- ' + value + ' is een verplicht veld\r\n';
    }

    private createCustomMsg(msg: string): string {
        return '- ' + msg + '\r\n';
    }
}
