/* tslint:disable */
import {ModuleWithProviders, NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {ApiConfiguration, ApiConfigurationInterface} from './api-configuration';

import {BatRestControllerService} from './services/bat-rest-controller.service';
import {DocumentRestControllerService} from './services/document-rest-controller.service';
import {LookupRestControllerService} from './services/lookup-rest-controller.service';
import {MeldingRestControllerService} from './services/melding-rest-controller.service';
import {SignaalDac6RestControllerService} from './services/signaal-dac-6rest-controller.service';
import {StroomRestControllerService} from './services/stroom-rest-controller.service';
import {TextRestControllerService} from './services/text-rest-controller.service';

/**
 * Provider for all Api services, plus ApiConfiguration
 */
@NgModule({
  imports: [
    HttpClientModule
  ],
  exports: [
    HttpClientModule
  ],
  declarations: [],
  providers: [
    ApiConfiguration,
    BatRestControllerService,
    DocumentRestControllerService,
    LookupRestControllerService,
    MeldingRestControllerService,
    SignaalDac6RestControllerService,
    StroomRestControllerService,
    TextRestControllerService
  ],
})
export class ApiModule {
  static forRoot(customParams: ApiConfigurationInterface): ModuleWithProviders<ApiModule> {
    return {
      ngModule: ApiModule,
      providers: [
        {
          provide: ApiConfiguration,
          useValue: {rootUrl: customParams.rootUrl}
        }
      ]
    }
  }
}
