/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';

import {Lookup} from '../models/lookup';
import {AllLookupsDTO} from '../models/all-lookups-dto';
import {LdapPerson} from '../models/ldap-person';

/**
 * Lookup Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class LookupRestControllerService extends __BaseService {
  static readonly lookupTabelUsingGETPath = '/api/lookup';
  static readonly lookupTabellenUsingGETPath = '/api/lookup/all';
  static readonly lookupNextStatusUsingGETPath = '/api/lookup/next';
  static readonly lookupNextSignaalDAC6StatusUsingGETPath = '/api/lookup/nextsignaaldac6';
  static readonly getPersonsByUseridOrLastNameUsingGETPath = '/api/lookup/user/{search}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * lookupTabel
   * @param params The `LookupRestControllerService.LookupTabelUsingGETParams` containing the following parameters:
   *
   * - `tabel`: tabel
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  lookupTabelUsingGETResponse(params: LookupRestControllerService.LookupTabelUsingGETParams): __Observable<__StrictHttpResponse<Array<Lookup>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    if (params.tabel != null) __params = __params.set('tabel', params.tabel.toString());
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/lookup`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<Lookup>>;
      })
    );
  }
  /**
   * lookupTabel
   * @param params The `LookupRestControllerService.LookupTabelUsingGETParams` containing the following parameters:
   *
   * - `tabel`: tabel
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  lookupTabelUsingGET(params: LookupRestControllerService.LookupTabelUsingGETParams): __Observable<Array<Lookup>> {
    return this.lookupTabelUsingGETResponse(params).pipe(
      __map(_r => _r.body as Array<Lookup>)
    );
  }

  /**
   * lookupTabellen
   * @param Authorization Autorisation token
   * @return OK
   */
  lookupTabellenUsingGETResponse(Authorization?: string): __Observable<__StrictHttpResponse<AllLookupsDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    if (Authorization != null) __headers = __headers.set('Authorization', Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/lookup/all`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<AllLookupsDTO>;
      })
    );
  }
  /**
   * lookupTabellen
   * @param Authorization Autorisation token
   * @return OK
   */
  lookupTabellenUsingGET(Authorization?: string): __Observable<AllLookupsDTO> {
    return this.lookupTabellenUsingGETResponse(Authorization).pipe(
      __map(_r => _r.body as AllLookupsDTO)
    );
  }

  /**
   * lookupNextStatus
   * @param Authorization Autorisation token
   * @return OK
   */
  lookupNextStatusUsingGETResponse(Authorization?: string): __Observable<__StrictHttpResponse<{[key: string]: Array<string>}>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    if (Authorization != null) __headers = __headers.set('Authorization', Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/lookup/next`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<{[key: string]: Array<string>}>;
      })
    );
  }
  /**
   * lookupNextStatus
   * @param Authorization Autorisation token
   * @return OK
   */
  lookupNextStatusUsingGET(Authorization?: string): __Observable<{[key: string]: Array<string>}> {
    return this.lookupNextStatusUsingGETResponse(Authorization).pipe(
      __map(_r => _r.body as {[key: string]: Array<string>})
    );
  }

  /**
   * lookupNextSignaalDAC6Status
   * @param Authorization Autorisation token
   * @return OK
   */
  lookupNextSignaalDAC6StatusUsingGETResponse(Authorization?: string): __Observable<__StrictHttpResponse<{[key: string]: Array<string>}>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    if (Authorization != null) __headers = __headers.set('Authorization', Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/lookup/nextsignaaldac6`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<{[key: string]: Array<string>}>;
      })
    );
  }
  /**
   * lookupNextSignaalDAC6Status
   * @param Authorization Autorisation token
   * @return OK
   */
  lookupNextSignaalDAC6StatusUsingGET(Authorization?: string): __Observable<{[key: string]: Array<string>}> {
    return this.lookupNextSignaalDAC6StatusUsingGETResponse(Authorization).pipe(
      __map(_r => _r.body as {[key: string]: Array<string>})
    );
  }

  /**
   * getPersonsByUseridOrLastName
   * @param params The `LookupRestControllerService.GetPersonsByUseridOrLastNameUsingGETParams` containing the following parameters:
   *
   * - `search`: search
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getPersonsByUseridOrLastNameUsingGETResponse(params: LookupRestControllerService.GetPersonsByUseridOrLastNameUsingGETParams): __Observable<__StrictHttpResponse<Array<LdapPerson>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/lookup/user/${encodeURIComponent(String(params.search))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<LdapPerson>>;
      })
    );
  }
  /**
   * getPersonsByUseridOrLastName
   * @param params The `LookupRestControllerService.GetPersonsByUseridOrLastNameUsingGETParams` containing the following parameters:
   *
   * - `search`: search
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getPersonsByUseridOrLastNameUsingGET(params: LookupRestControllerService.GetPersonsByUseridOrLastNameUsingGETParams): __Observable<Array<LdapPerson>> {
    return this.getPersonsByUseridOrLastNameUsingGETResponse(params).pipe(
      __map(_r => _r.body as Array<LdapPerson>)
    );
  }
}

module LookupRestControllerService {

  /**
   * Parameters for lookupTabelUsingGET
   */
  export interface LookupTabelUsingGETParams {

    /**
     * tabel
     */
    tabel: 'BELASTINGMIDDEL' | 'ROL' | 'STATUS' | 'SIGNAALDAC6STATUS' | 'HALLMARK' | 'BHSTATUS' | 'TOEDELING';

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for getPersonsByUseridOrLastNameUsingGET
   */
  export interface GetPersonsByUseridOrLastNameUsingGETParams {

    /**
     * search
     */
    search: string;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }
}

export { LookupRestControllerService }
