/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';

import {FilenetDocument} from '../models/filenet-document';

/**
 * Document Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class DocumentRestControllerService extends __BaseService {
  static readonly deleteDocumentUsingDELETEPath = '/api/documents/documents/{meldingId}/document/{docId}';
  static readonly handleFileUploadUsingPOSTPath = '/api/documents/upload';
  static readonly getAllDocumentsUsingGETPath = '/api/documents/{meldingId}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * deleteDocument
   * @param params The `DocumentRestControllerService.DeleteDocumentUsingDELETEParams` containing the following parameters:
   *
   * - `meldingId`: meldingId
   *
   * - `docId`: docId
   *
   * - `Authorization`: Autorisation token
   */
  deleteDocumentUsingDELETEResponse(params: DocumentRestControllerService.DeleteDocumentUsingDELETEParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'DELETE',
      this.rootUrl + `/api/documents/documents/${encodeURIComponent(String(params.meldingId))}/document/${encodeURIComponent(String(params.docId))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }
  /**
   * deleteDocument
   * @param params The `DocumentRestControllerService.DeleteDocumentUsingDELETEParams` containing the following parameters:
   *
   * - `meldingId`: meldingId
   *
   * - `docId`: docId
   *
   * - `Authorization`: Autorisation token
   */
  deleteDocumentUsingDELETE(params: DocumentRestControllerService.DeleteDocumentUsingDELETEParams): __Observable<null> {
    return this.deleteDocumentUsingDELETEResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }

  /**
   * handleFileUpload
   * @param params The `DocumentRestControllerService.HandleFileUploadUsingPOSTParams` containing the following parameters:
   *
   * - `meldingId`: meldingId
   *
   * - `file`: file
   *
   * - `omschrijving`: omschrijving
   *
   * - `Authorization`: Autorisation token
   */
  handleFileUploadUsingPOSTResponse(params: DocumentRestControllerService.HandleFileUploadUsingPOSTParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let __formData = new FormData();
    __body = __formData;
    if (params.meldingId != null) __params = __params.set('meldingId', params.meldingId.toString());
    if (params.file != null) { __formData.append('file', params.file as string | Blob);}
    if (params.omschrijving != null) __params = __params.set('omschrijving', params.omschrijving.toString());
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/documents/upload`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }
  /**
   * handleFileUpload
   * @param params The `DocumentRestControllerService.HandleFileUploadUsingPOSTParams` containing the following parameters:
   *
   * - `meldingId`: meldingId
   *
   * - `file`: file
   *
   * - `omschrijving`: omschrijving
   *
   * - `Authorization`: Autorisation token
   */
  handleFileUploadUsingPOST(params: DocumentRestControllerService.HandleFileUploadUsingPOSTParams): __Observable<null> {
    return this.handleFileUploadUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }

  /**
   * getAllDocuments
   * @param params The `DocumentRestControllerService.GetAllDocumentsUsingGETParams` containing the following parameters:
   *
   * - `meldingId`: meldingId
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getAllDocumentsUsingGETResponse(params: DocumentRestControllerService.GetAllDocumentsUsingGETParams): __Observable<__StrictHttpResponse<Array<FilenetDocument>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/documents/${encodeURIComponent(String(params.meldingId))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<FilenetDocument>>;
      })
    );
  }
  /**
   * getAllDocuments
   * @param params The `DocumentRestControllerService.GetAllDocumentsUsingGETParams` containing the following parameters:
   *
   * - `meldingId`: meldingId
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getAllDocumentsUsingGET(params: DocumentRestControllerService.GetAllDocumentsUsingGETParams): __Observable<Array<FilenetDocument>> {
    return this.getAllDocumentsUsingGETResponse(params).pipe(
      __map(_r => _r.body as Array<FilenetDocument>)
    );
  }
}

module DocumentRestControllerService {

  /**
   * Parameters for deleteDocumentUsingDELETE
   */
  export interface DeleteDocumentUsingDELETEParams {

    /**
     * meldingId
     */
    meldingId: number;

    /**
     * docId
     */
    docId: string;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for handleFileUploadUsingPOST
   */
  export interface HandleFileUploadUsingPOSTParams {

    /**
     * meldingId
     */
    meldingId: number;

    /**
     * file
     */
    file: Blob;

    /**
     * omschrijving
     */
    omschrijving?: string;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for getAllDocumentsUsingGET
   */
  export interface GetAllDocumentsUsingGETParams {

    /**
     * meldingId
     */
    meldingId: number;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }
}

export { DocumentRestControllerService }
