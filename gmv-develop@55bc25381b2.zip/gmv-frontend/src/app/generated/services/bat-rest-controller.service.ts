/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';

import {Voorstel} from '../models/voorstel';
import {EncodedTokenDTO} from '../models/encoded-token-dto';
import {StartDTO} from '../models/start-dto';

/**
 * Bat Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class BatRestControllerService extends __BaseService {
  static readonly getStatusUsingGETPath = '/api/bat/status/{voorstelId}';
  static readonly getTokenUsingPOSTPath = '/api/bat/token';
  static readonly getVoorstelUsingPOSTPath = '/api/bat/voorstel';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * getStatus
   * @param params The `BatRestControllerService.GetStatusUsingGETParams` containing the following parameters:
   *
   * - `voorstelId`: voorstelId
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getStatusUsingGETResponse(params: BatRestControllerService.GetStatusUsingGETParams): __Observable<__StrictHttpResponse<Voorstel>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/bat/status/${encodeURIComponent(String(params.voorstelId))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Voorstel>;
      })
    );
  }
  /**
   * getStatus
   * @param params The `BatRestControllerService.GetStatusUsingGETParams` containing the following parameters:
   *
   * - `voorstelId`: voorstelId
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getStatusUsingGET(params: BatRestControllerService.GetStatusUsingGETParams): __Observable<Voorstel> {
    return this.getStatusUsingGETResponse(params).pipe(
      __map(_r => _r.body as Voorstel)
    );
  }

  /**
   * getToken
   * @param params The `BatRestControllerService.GetTokenUsingPOSTParams` containing the following parameters:
   *
   * - `dto`: dto
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getTokenUsingPOSTResponse(params: BatRestControllerService.GetTokenUsingPOSTParams): __Observable<__StrictHttpResponse<EncodedTokenDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = params.dto;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/bat/token`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<EncodedTokenDTO>;
      })
    );
  }
  /**
   * getToken
   * @param params The `BatRestControllerService.GetTokenUsingPOSTParams` containing the following parameters:
   *
   * - `dto`: dto
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getTokenUsingPOST(params: BatRestControllerService.GetTokenUsingPOSTParams): __Observable<EncodedTokenDTO> {
    return this.getTokenUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as EncodedTokenDTO)
    );
  }

  /**
   * getVoorstel
   * @param params The `BatRestControllerService.GetVoorstelUsingPOSTParams` containing the following parameters:
   *
   * - `personen`: personen
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getVoorstelUsingPOSTResponse(params: BatRestControllerService.GetVoorstelUsingPOSTParams): __Observable<__StrictHttpResponse<Array<Voorstel>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = params.personen;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/bat/voorstel`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<Voorstel>>;
      })
    );
  }
  /**
   * getVoorstel
   * @param params The `BatRestControllerService.GetVoorstelUsingPOSTParams` containing the following parameters:
   *
   * - `personen`: personen
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getVoorstelUsingPOST(params: BatRestControllerService.GetVoorstelUsingPOSTParams): __Observable<Array<Voorstel>> {
    return this.getVoorstelUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as Array<Voorstel>)
    );
  }
}

module BatRestControllerService {

  /**
   * Parameters for getStatusUsingGET
   */
  export interface GetStatusUsingGETParams {

    /**
     * voorstelId
     */
    voorstelId: string;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for getTokenUsingPOST
   */
  export interface GetTokenUsingPOSTParams {

    /**
     * dto
     */
    dto: StartDTO;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for getVoorstelUsingPOST
   */
  export interface GetVoorstelUsingPOSTParams {

    /**
     * personen
     */
    personen: Array<StartDTO>;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }
}

export { BatRestControllerService }
