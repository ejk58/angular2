/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';

import {MeldingNewDTO} from '../models/melding-new-dto';
import {MeldingDTO} from '../models/melding-dto';
import {PagingMeldingOverzichtDTO} from '../models/paging-melding-overzicht-dto';
import {LazyLoadData} from '../models/lazy-load-data';

/**
 * Melding Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class MeldingRestControllerService extends __BaseService {
  static readonly createMeldingUsingPOSTPath = '/api/melding';
  static readonly getMeldingByIdUsingGETPath = '/api/melding/id/{id}';
  static readonly getMeldingenUsingPOSTPath = '/api/melding/overzicht';
  static readonly addTestdataUsingGETPath = '/api/melding/testdata/{stroom}/{aantal}';
  static readonly getMeldingUsingGETPath = '/api/melding/{arrangementId}/{disclusureId}';
  static readonly updateMeldingStatusUsingPUTPath = '/api/melding/{id}/status/{status}';
  static readonly getMeldingenWithStatusUsingGETPath = '/api/melding/{status}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * createMelding
   * @param params The `MeldingRestControllerService.CreateMeldingUsingPOSTParams` containing the following parameters:
   *
   * - `body`: body
   *
   * - `Authorization`: Authorization
   */
  createMeldingUsingPOSTResponse(params: MeldingRestControllerService.CreateMeldingUsingPOSTParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = params.body;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/melding`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }
  /**
   * createMelding
   * @param params The `MeldingRestControllerService.CreateMeldingUsingPOSTParams` containing the following parameters:
   *
   * - `body`: body
   *
   * - `Authorization`: Authorization
   */
  createMeldingUsingPOST(params: MeldingRestControllerService.CreateMeldingUsingPOSTParams): __Observable<null> {
    return this.createMeldingUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }

  /**
   * getMeldingById
   * @param params The `MeldingRestControllerService.GetMeldingByIdUsingGETParams` containing the following parameters:
   *
   * - `id`: id
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getMeldingByIdUsingGETResponse(params: MeldingRestControllerService.GetMeldingByIdUsingGETParams): __Observable<__StrictHttpResponse<MeldingDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/melding/id/${encodeURIComponent(String(params.id))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<MeldingDTO>;
      })
    );
  }
  /**
   * getMeldingById
   * @param params The `MeldingRestControllerService.GetMeldingByIdUsingGETParams` containing the following parameters:
   *
   * - `id`: id
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getMeldingByIdUsingGET(params: MeldingRestControllerService.GetMeldingByIdUsingGETParams): __Observable<MeldingDTO> {
    return this.getMeldingByIdUsingGETResponse(params).pipe(
      __map(_r => _r.body as MeldingDTO)
    );
  }

  /**
   * getMeldingen
   * @param params The `MeldingRestControllerService.GetMeldingenUsingPOSTParams` containing the following parameters:
   *
   * - `lazyLoadData`: lazyLoadData
   *
   * - `Authorization`: Authorization
   *
   * @return OK
   */
  getMeldingenUsingPOSTResponse(params: MeldingRestControllerService.GetMeldingenUsingPOSTParams): __Observable<__StrictHttpResponse<PagingMeldingOverzichtDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = params.lazyLoadData;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/melding/overzicht`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<PagingMeldingOverzichtDTO>;
      })
    );
  }
  /**
   * getMeldingen
   * @param params The `MeldingRestControllerService.GetMeldingenUsingPOSTParams` containing the following parameters:
   *
   * - `lazyLoadData`: lazyLoadData
   *
   * - `Authorization`: Authorization
   *
   * @return OK
   */
  getMeldingenUsingPOST(params: MeldingRestControllerService.GetMeldingenUsingPOSTParams): __Observable<PagingMeldingOverzichtDTO> {
    return this.getMeldingenUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as PagingMeldingOverzichtDTO)
    );
  }

  /**
   * addTestdata
   * @param params The `MeldingRestControllerService.AddTestdataUsingGETParams` containing the following parameters:
   *
   * - `stroom`: stroom
   *
   * - `aantal`: aantal
   *
   * - `Authorization`: Autorisation token
   */
  addTestdataUsingGETResponse(params: MeldingRestControllerService.AddTestdataUsingGETParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/melding/testdata/${encodeURIComponent(String(params.stroom))}/${encodeURIComponent(String(params.aantal))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }
  /**
   * addTestdata
   * @param params The `MeldingRestControllerService.AddTestdataUsingGETParams` containing the following parameters:
   *
   * - `stroom`: stroom
   *
   * - `aantal`: aantal
   *
   * - `Authorization`: Autorisation token
   */
  addTestdataUsingGET(params: MeldingRestControllerService.AddTestdataUsingGETParams): __Observable<null> {
    return this.addTestdataUsingGETResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }

  /**
   * getMelding
   * @param params The `MeldingRestControllerService.GetMeldingUsingGETParams` containing the following parameters:
   *
   * - `disclusureId`: disclusureId
   *
   * - `arrangementId`: arrangementId
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getMeldingUsingGETResponse(params: MeldingRestControllerService.GetMeldingUsingGETParams): __Observable<__StrictHttpResponse<MeldingDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/melding/${encodeURIComponent(String(params.arrangementId))}/${encodeURIComponent(String(params.disclusureId))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<MeldingDTO>;
      })
    );
  }
  /**
   * getMelding
   * @param params The `MeldingRestControllerService.GetMeldingUsingGETParams` containing the following parameters:
   *
   * - `disclusureId`: disclusureId
   *
   * - `arrangementId`: arrangementId
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getMeldingUsingGET(params: MeldingRestControllerService.GetMeldingUsingGETParams): __Observable<MeldingDTO> {
    return this.getMeldingUsingGETResponse(params).pipe(
      __map(_r => _r.body as MeldingDTO)
    );
  }

  /**
   * updateMeldingStatus
   * @param params The `MeldingRestControllerService.UpdateMeldingStatusUsingPUTParams` containing the following parameters:
   *
   * - `status`: status
   *
   * - `id`: id
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  updateMeldingStatusUsingPUTResponse(params: MeldingRestControllerService.UpdateMeldingStatusUsingPUTParams): __Observable<__StrictHttpResponse<MeldingDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'PUT',
      this.rootUrl + `/api/melding/${encodeURIComponent(String(params.id))}/status/${encodeURIComponent(String(params.status))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<MeldingDTO>;
      })
    );
  }
  /**
   * updateMeldingStatus
   * @param params The `MeldingRestControllerService.UpdateMeldingStatusUsingPUTParams` containing the following parameters:
   *
   * - `status`: status
   *
   * - `id`: id
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  updateMeldingStatusUsingPUT(params: MeldingRestControllerService.UpdateMeldingStatusUsingPUTParams): __Observable<MeldingDTO> {
    return this.updateMeldingStatusUsingPUTResponse(params).pipe(
      __map(_r => _r.body as MeldingDTO)
    );
  }

  /**
   * getMeldingenWithStatus
   * @param params The `MeldingRestControllerService.GetMeldingenWithStatusUsingGETParams` containing the following parameters:
   *
   * - `status`: status
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getMeldingenWithStatusUsingGETResponse(params: MeldingRestControllerService.GetMeldingenWithStatusUsingGETParams): __Observable<__StrictHttpResponse<Array<MeldingDTO>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/melding/${encodeURIComponent(String(params.status))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<MeldingDTO>>;
      })
    );
  }
  /**
   * getMeldingenWithStatus
   * @param params The `MeldingRestControllerService.GetMeldingenWithStatusUsingGETParams` containing the following parameters:
   *
   * - `status`: status
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getMeldingenWithStatusUsingGET(params: MeldingRestControllerService.GetMeldingenWithStatusUsingGETParams): __Observable<Array<MeldingDTO>> {
    return this.getMeldingenWithStatusUsingGETResponse(params).pipe(
      __map(_r => _r.body as Array<MeldingDTO>)
    );
  }
}

module MeldingRestControllerService {

  /**
   * Parameters for createMeldingUsingPOST
   */
  export interface CreateMeldingUsingPOSTParams {

    /**
     * body
     */
    body: MeldingNewDTO;

    /**
     * Authorization
     */
    Authorization?: string;
  }

  /**
   * Parameters for getMeldingByIdUsingGET
   */
  export interface GetMeldingByIdUsingGETParams {

    /**
     * id
     */
    id: number;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for getMeldingenUsingPOST
   */
  export interface GetMeldingenUsingPOSTParams {

    /**
     * lazyLoadData
     */
    lazyLoadData: LazyLoadData;

    /**
     * Authorization
     */
    Authorization?: string;
  }

  /**
   * Parameters for addTestdataUsingGET
   */
  export interface AddTestdataUsingGETParams {

    /**
     * stroom
     */
    stroom: string;

    /**
     * aantal
     */
    aantal: number;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for getMeldingUsingGET
   */
  export interface GetMeldingUsingGETParams {

    /**
     * disclusureId
     */
    disclusureId: string;

    /**
     * arrangementId
     */
    arrangementId: string;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for updateMeldingStatusUsingPUT
   */
  export interface UpdateMeldingStatusUsingPUTParams {

    /**
     * status
     */
    status: string;

    /**
     * id
     */
    id: number;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for getMeldingenWithStatusUsingGET
   */
  export interface GetMeldingenWithStatusUsingGETParams {

    /**
     * status
     */
    status: string;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }
}

export { MeldingRestControllerService }
