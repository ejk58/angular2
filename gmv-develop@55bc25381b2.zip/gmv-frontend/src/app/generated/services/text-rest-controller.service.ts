/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';


/**
 * Text Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class TextRestControllerService extends __BaseService {
  static readonly updateTextUsingPOSTPath = '/api/text/melding/{parentId}/soort/{soort}';
  static readonly updateTextDAC6UsingPOSTPath = '/api/text/signaaldac6/{parentId}/soort/{soort}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * updateText
   * @param params The `TextRestControllerService.UpdateTextUsingPOSTParams` containing the following parameters:
   *
   * - `soort`: soort
   *
   * - `parentId`: parentId
   *
   * - `body`: body
   *
   * - `Authorization`: Autorisation token
   */
  updateTextUsingPOSTResponse(params: TextRestControllerService.UpdateTextUsingPOSTParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    __body = params.body;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/text/melding/${encodeURIComponent(String(params.parentId))}/soort/${encodeURIComponent(String(params.soort))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }
  /**
   * updateText
   * @param params The `TextRestControllerService.UpdateTextUsingPOSTParams` containing the following parameters:
   *
   * - `soort`: soort
   *
   * - `parentId`: parentId
   *
   * - `body`: body
   *
   * - `Authorization`: Autorisation token
   */
  updateTextUsingPOST(params: TextRestControllerService.UpdateTextUsingPOSTParams): __Observable<null> {
    return this.updateTextUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }

  /**
   * updateTextDAC6
   * @param params The `TextRestControllerService.UpdateTextDAC6UsingPOSTParams` containing the following parameters:
   *
   * - `soort`: soort
   *
   * - `parentId`: parentId
   *
   * - `body`: body
   *
   * - `Authorization`: Autorisation token
   */
  updateTextDAC6UsingPOSTResponse(params: TextRestControllerService.UpdateTextDAC6UsingPOSTParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    __body = params.body;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/text/signaaldac6/${encodeURIComponent(String(params.parentId))}/soort/${encodeURIComponent(String(params.soort))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }
  /**
   * updateTextDAC6
   * @param params The `TextRestControllerService.UpdateTextDAC6UsingPOSTParams` containing the following parameters:
   *
   * - `soort`: soort
   *
   * - `parentId`: parentId
   *
   * - `body`: body
   *
   * - `Authorization`: Autorisation token
   */
  updateTextDAC6UsingPOST(params: TextRestControllerService.UpdateTextDAC6UsingPOSTParams): __Observable<null> {
    return this.updateTextDAC6UsingPOSTResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }
}

module TextRestControllerService {

  /**
   * Parameters for updateTextUsingPOST
   */
  export interface UpdateTextUsingPOSTParams {

    /**
     * soort
     */
    soort: string;

    /**
     * parentId
     */
    parentId: number;

    /**
     * body
     */
    body: string;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for updateTextDAC6UsingPOST
   */
  export interface UpdateTextDAC6UsingPOSTParams {

    /**
     * soort
     */
    soort: string;

    /**
     * parentId
     */
    parentId: number;

    /**
     * body
     */
    body: string;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }
}

export { TextRestControllerService }
