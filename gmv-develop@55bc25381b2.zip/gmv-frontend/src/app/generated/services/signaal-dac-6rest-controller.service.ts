/* tslint:disable */
import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {BaseService as __BaseService} from '../base-service';
import {ApiConfiguration as __Configuration} from '../api-configuration';
import {StrictHttpResponse as __StrictHttpResponse} from '../strict-http-response';
import {Observable as __Observable} from 'rxjs';
import {filter as __filter, map as __map} from 'rxjs/operators';

import {SignaalDAC6NewDTO} from '../models/signaal-dac6new-dto';
import {SignaalDAC6DTO} from '../models/signaal-dac6dto';
import {PagingSignaalDAC6OverzichtDTO} from '../models/paging-signaal-dac6overzicht-dto';
import {LazyLoadData} from '../models/lazy-load-data';

/**
 * Signaal DAC 6 Rest Controller
 */
@Injectable({
  providedIn: 'root',
})
class SignaalDac6RestControllerService extends __BaseService {
  static readonly createSignaalUsingPOSTPath = '/api/signaaldac6';
  static readonly getSignaalByIdUsingGETPath = '/api/signaaldac6/id/{id}';
  static readonly getSignalenUsingPOSTPath = '/api/signaaldac6/overzicht';
  static readonly updateSignaalDAC6StatusUsingPUTPath = '/api/signaaldac6/{id}/status/{status}';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * createSignaal
   * @param params The `SignaalDac6RestControllerService.CreateSignaalUsingPOSTParams` containing the following parameters:
   *
   * - `body`: body
   *
   * - `Authorization`: Authorization
   */
  createSignaalUsingPOSTResponse(params: SignaalDac6RestControllerService.CreateSignaalUsingPOSTParams): __Observable<__StrictHttpResponse<null>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = params.body;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/signaaldac6`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<null>;
      })
    );
  }
  /**
   * createSignaal
   * @param params The `SignaalDac6RestControllerService.CreateSignaalUsingPOSTParams` containing the following parameters:
   *
   * - `body`: body
   *
   * - `Authorization`: Authorization
   */
  createSignaalUsingPOST(params: SignaalDac6RestControllerService.CreateSignaalUsingPOSTParams): __Observable<null> {
    return this.createSignaalUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as null)
    );
  }

  /**
   * getSignaalById
   * @param params The `SignaalDac6RestControllerService.GetSignaalByIdUsingGETParams` containing the following parameters:
   *
   * - `id`: id
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getSignaalByIdUsingGETResponse(params: SignaalDac6RestControllerService.GetSignaalByIdUsingGETParams): __Observable<__StrictHttpResponse<SignaalDAC6DTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/signaaldac6/id/${encodeURIComponent(String(params.id))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<SignaalDAC6DTO>;
      })
    );
  }
  /**
   * getSignaalById
   * @param params The `SignaalDac6RestControllerService.GetSignaalByIdUsingGETParams` containing the following parameters:
   *
   * - `id`: id
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  getSignaalByIdUsingGET(params: SignaalDac6RestControllerService.GetSignaalByIdUsingGETParams): __Observable<SignaalDAC6DTO> {
    return this.getSignaalByIdUsingGETResponse(params).pipe(
      __map(_r => _r.body as SignaalDAC6DTO)
    );
  }

  /**
   * getSignalen
   * @param params The `SignaalDac6RestControllerService.GetSignalenUsingPOSTParams` containing the following parameters:
   *
   * - `lazyLoadData`: lazyLoadData
   *
   * - `Authorization`: Authorization
   *
   * @return OK
   */
  getSignalenUsingPOSTResponse(params: SignaalDac6RestControllerService.GetSignalenUsingPOSTParams): __Observable<__StrictHttpResponse<PagingSignaalDAC6OverzichtDTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = params.lazyLoadData;
    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/signaaldac6/overzicht`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<PagingSignaalDAC6OverzichtDTO>;
      })
    );
  }
  /**
   * getSignalen
   * @param params The `SignaalDac6RestControllerService.GetSignalenUsingPOSTParams` containing the following parameters:
   *
   * - `lazyLoadData`: lazyLoadData
   *
   * - `Authorization`: Authorization
   *
   * @return OK
   */
  getSignalenUsingPOST(params: SignaalDac6RestControllerService.GetSignalenUsingPOSTParams): __Observable<PagingSignaalDAC6OverzichtDTO> {
    return this.getSignalenUsingPOSTResponse(params).pipe(
      __map(_r => _r.body as PagingSignaalDAC6OverzichtDTO)
    );
  }

  /**
   * updateSignaalDAC6Status
   * @param params The `SignaalDac6RestControllerService.UpdateSignaalDAC6StatusUsingPUTParams` containing the following parameters:
   *
   * - `status`: status
   *
   * - `id`: id
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  updateSignaalDAC6StatusUsingPUTResponse(params: SignaalDac6RestControllerService.UpdateSignaalDAC6StatusUsingPUTParams): __Observable<__StrictHttpResponse<SignaalDAC6DTO>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;


    if (params.Authorization != null) __headers = __headers.set('Authorization', params.Authorization.toString());
    let req = new HttpRequest<any>(
      'PUT',
      this.rootUrl + `/api/signaaldac6/${encodeURIComponent(String(params.id))}/status/${encodeURIComponent(String(params.status))}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<SignaalDAC6DTO>;
      })
    );
  }
  /**
   * updateSignaalDAC6Status
   * @param params The `SignaalDac6RestControllerService.UpdateSignaalDAC6StatusUsingPUTParams` containing the following parameters:
   *
   * - `status`: status
   *
   * - `id`: id
   *
   * - `Authorization`: Autorisation token
   *
   * @return OK
   */
  updateSignaalDAC6StatusUsingPUT(params: SignaalDac6RestControllerService.UpdateSignaalDAC6StatusUsingPUTParams): __Observable<SignaalDAC6DTO> {
    return this.updateSignaalDAC6StatusUsingPUTResponse(params).pipe(
      __map(_r => _r.body as SignaalDAC6DTO)
    );
  }
}

module SignaalDac6RestControllerService {

  /**
   * Parameters for createSignaalUsingPOST
   */
  export interface CreateSignaalUsingPOSTParams {

    /**
     * body
     */
    body: SignaalDAC6NewDTO;

    /**
     * Authorization
     */
    Authorization?: string;
  }

  /**
   * Parameters for getSignaalByIdUsingGET
   */
  export interface GetSignaalByIdUsingGETParams {

    /**
     * id
     */
    id: number;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }

  /**
   * Parameters for getSignalenUsingPOST
   */
  export interface GetSignalenUsingPOSTParams {

    /**
     * lazyLoadData
     */
    lazyLoadData: LazyLoadData;

    /**
     * Authorization
     */
    Authorization?: string;
  }

  /**
   * Parameters for updateSignaalDAC6StatusUsingPUT
   */
  export interface UpdateSignaalDAC6StatusUsingPUTParams {

    /**
     * status
     */
    status: string;

    /**
     * id
     */
    id: number;

    /**
     * Autorisation token
     */
    Authorization?: string;
  }
}

export { SignaalDac6RestControllerService }
