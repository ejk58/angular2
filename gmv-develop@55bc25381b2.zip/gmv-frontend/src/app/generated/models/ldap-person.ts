/* tslint:disable */
export interface LdapPerson {
  adGroepen?: Array<string>;
  email?: string;
  name?: string;
  userId?: string;
}
