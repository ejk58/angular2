/* tslint:disable */
export interface Voorstel {
  behandelVoorstelReference?: string;
  meldingId?: number;
  status?: string;
  subject?: string;
  toedeling?: string;
}
