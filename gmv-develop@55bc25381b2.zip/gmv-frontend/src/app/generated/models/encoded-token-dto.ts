/* tslint:disable */
export interface EncodedTokenDTO {
  baseUrl?: string;
  token?: string;
}
