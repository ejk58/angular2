/* tslint:disable */
import {GekoppeldDocumentDTO} from './gekoppeld-document-dto';
import {PersoonDAC6DTO} from './persoon-dac6dto';

export interface SignaalDAC6DTO {
  behandelaarId?: string;
  belastingMiddellen: string;
  currentStatus: 'NEW' | 'INBEHANDELING' | 'DONE';
  datumOntvangen: string;
  documenten: Array<GekoppeldDocumentDTO>;
  hallmarks: string;
  id?: number;
  jaar: number;
  kantoor: string;
  naam: string;
  nummer: string;
  personen: Array<PersoonDAC6DTO>;
  persoonNaam: string;
  persoonTin: number;
  segment: string;
  signaal: string;
  teksten: {[key: string]: string};
}
