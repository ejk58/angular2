/* tslint:disable */
export interface PersoonDAC6DTO {
  naam: string;
  tin: number;
}
