/* tslint:disable */
export interface PersoonDTO {
  naam: string;
  rol: 'DISCLOSER' | 'TAXPAYER' | 'PERSON' | 'ENTERPRISE' | 'INTERMEDIARY';
  tin: number;
}
