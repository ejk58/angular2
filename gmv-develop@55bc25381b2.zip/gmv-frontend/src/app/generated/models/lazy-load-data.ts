/* tslint:disable */
import {FilterMetaData} from './filter-meta-data';

export interface LazyLoadData {
  filters?: {[key: string]: Array<FilterMetaData>};
  first?: number;
  globalFilter?: string;
  rows?: number;
  sortField?: string;
  sortOrder?: number;
}
