/* tslint:disable */
import {ApiValidationError} from './api-validation-error';

export interface ApiError {
  detail?: string;
  instance?: string;
  timestamp?: string;
  title?: string;
  type?: string;
  validationErrors?: Array<ApiValidationError>;
}
