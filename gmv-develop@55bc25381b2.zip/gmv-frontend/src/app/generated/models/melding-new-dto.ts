/* tslint:disable */
import {PersoonNewDTO} from './persoon-new-dto';
import {PrioriteitNewDTO} from './prioriteit-new-dto';

export interface MeldingNewDTO {
  arrangementId?: string;
  belastingMiddellen?: string;
  disclosureId?: string;
  implementatieDatum?: string;
  indienDatum?: string;
  personen: Array<PersoonNewDTO>;
  prioriteiten: Array<PrioriteitNewDTO>;
  samenvatting?: string;
}
