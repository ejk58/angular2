/* tslint:disable */
import {PersoonDAC6DTO} from './persoon-dac6dto';

export interface SignaalDAC6NewDTO {
  behandelaarId?: string;
  belastingMiddellen?: string;
  datumOntvangen?: string;
  hallmarks: Array<'A1' | 'A2' | 'A3' | 'B1' | 'B2' | 'B3' | 'C1A' | 'C1B1' | 'C1B2' | 'C1C' | 'C1D' | 'C2' | 'C3' | 'C4' | 'D1' | 'D2' | 'E1' | 'E2' | 'E3'>;
  jaar?: number;
  kantoor?: string;
  naam?: string;
  personen: Array<PersoonDAC6DTO>;
  segment?: string;
  signaal?: string;
}
