/* tslint:disable */
export interface StartDTO {
  meldingId?: number;
  tin?: string;
}
