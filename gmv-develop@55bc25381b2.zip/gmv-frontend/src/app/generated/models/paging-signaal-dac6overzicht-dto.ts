/* tslint:disable */
import {SignaalDAC6DTO} from './signaal-dac6dto';

export interface PagingSignaalDAC6OverzichtDTO {
  count?: number;
  list?: Array<SignaalDAC6DTO>;
}
