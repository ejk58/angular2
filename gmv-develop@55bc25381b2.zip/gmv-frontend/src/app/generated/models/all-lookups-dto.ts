/* tslint:disable */
import {Lookup} from './lookup';

export interface AllLookupsDTO {
  belastingMiddel: Array<Lookup>;
  bhStatus: Array<Lookup>;
  hallmark: Array<Lookup>;
  rol: Array<Lookup>;
  signaaldac6Status: Array<Lookup>;
  status: Array<Lookup>;
  toedeling: Array<Lookup>;
}
