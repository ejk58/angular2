/* tslint:disable */
export interface StatusLogDTO {
  behandelaarId: string;
  status: 'NEW' | 'SELECTED' | 'MDR_SELECTED' | 'ANALYZING' | 'DONE_NO_REVIEW' | 'IN_REVIEW' | 'DONE_REVIEW';
  wijzigingsMoment: string;
}
