/* tslint:disable */
export interface PersoonNewDTO {
  naam?: string;
  rol?: 'DISCLOSER' | 'TAXPAYER' | 'PERSON' | 'ENTERPRISE' | 'INTERMEDIARY';
  tin?: number;
}
