/* tslint:disable */
export interface FilterMetaData {
  matchMode?: string;
  operator?: string;
  value?: string;
}
