/* tslint:disable */
import {MeldingDTO} from './melding-dto';

export interface PagingMeldingOverzichtDTO {
  count?: number;
  list?: Array<MeldingDTO>;
}
