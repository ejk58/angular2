/* tslint:disable */
import {GekoppeldDocumentDTO} from './gekoppeld-document-dto';
import {PersoonDTO} from './persoon-dto';
import {PrioriteitDTO} from './prioriteit-dto';
import {StatusLogDTO} from './status-log-dto';

export interface MeldingDTO {
  arrangementId: string;
  behandelaarId?: string;
  belastingMiddellen: string;
  currentStatus: 'NEW' | 'SELECTED' | 'MDR_SELECTED' | 'ANALYZING' | 'DONE_NO_REVIEW' | 'IN_REVIEW' | 'DONE_REVIEW';
  disclosureId: string;
  documenten: Array<GekoppeldDocumentDTO>;
  id?: number;
  implementatieDatum: string;
  indienDatum: string;
  personen: Array<PersoonDTO>;
  prioriteiten: Array<PrioriteitDTO>;
  samenvatting: string;
  statusLogs: Array<StatusLogDTO>;
  teksten: {[key: string]: string};
}
