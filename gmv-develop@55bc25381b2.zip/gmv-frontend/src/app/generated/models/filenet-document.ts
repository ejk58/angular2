/* tslint:disable */
export interface FilenetDocument {
  aanmaakdatum?: string;
  beginTijdvak?: string;
  bron?: string;
  datumIndieningDagtekening?: string;
  datumLaatsteWijziging?: string;
  docId?: string;
  docURL?: string;
  documentSoort?: string;
  documentType?: string;
  documentklasse?: string;
  documentomSchrijving?: string;
  documenttitel?: string;
  eindTijdvak?: string;
  fileName?: string;
  finr?: string;
  gekoppeld?: boolean;
  hoofdproces?: string;
  idType?: string;
  identificatiekenmerk?: string;
  laatstGewijzigdDoor?: string;
  maker?: string;
  name?: string;
  richting?: string;
  uuid?: string;
  werkproces?: string;
}
