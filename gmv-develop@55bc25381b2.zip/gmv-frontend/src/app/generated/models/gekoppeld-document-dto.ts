/* tslint:disable */
export interface GekoppeldDocumentDTO {

  /**
   * The identification id of the document
   */
  docId: string;
}
