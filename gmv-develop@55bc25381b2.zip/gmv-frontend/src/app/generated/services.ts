export { BatRestControllerService } from './services/bat-rest-controller.service';
export { DocumentRestControllerService } from './services/document-rest-controller.service';
export { LookupRestControllerService } from './services/lookup-rest-controller.service';
export { MeldingRestControllerService } from './services/melding-rest-controller.service';
export { SignaalDac6RestControllerService } from './services/signaal-dac-6rest-controller.service';
export { StroomRestControllerService } from './services/stroom-rest-controller.service';
export { TextRestControllerService } from './services/text-rest-controller.service';
