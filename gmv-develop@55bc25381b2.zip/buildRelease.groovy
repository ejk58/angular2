@Library("GENERIC") _
    pipelineRelease_openshift {
	deploymentId = "ivagmv"
	deployPipeline = "iva-gmv_deploy_release"
	integrationPipeline = "iva-gmv-test"
	environmentChoices = "tst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6\n"
}
