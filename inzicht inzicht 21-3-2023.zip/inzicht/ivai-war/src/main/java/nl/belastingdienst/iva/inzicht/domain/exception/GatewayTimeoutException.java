package nl.belastingdienst.iva.inzicht.domain.exception;

import javax.ejb.ApplicationException;

@ApplicationException
public class GatewayTimeoutException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    
    public GatewayTimeoutException(String message) {
        super(message);
    }
    
    public GatewayTimeoutException(String message, Throwable exception) {
        super(message, exception);
    }
}
