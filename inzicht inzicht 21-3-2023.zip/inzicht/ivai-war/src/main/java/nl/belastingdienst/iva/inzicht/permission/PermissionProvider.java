package nl.belastingdienst.iva.inzicht.permission;

import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public interface PermissionProvider {

    Permission getPermission(RestCallContext restCallContext, String key);
}
