package nl.belastingdienst.iva.inzicht.domain.datasource;

import org.apache.http.impl.client.CloseableHttpClient;

public class HttpDatasource extends AbstractDatasource {

    private CloseableHttpClient httpClient;

    public HttpDatasource(String key) {
        super(key);
    }
    
    @Override
    public DatasourceType getType() {
        return DatasourceType.REST;
    }

    public CloseableHttpClient getHttpClient() {
        return httpClient;
    }

    public void setHttpClient(CloseableHttpClient httpClient) {
        this.httpClient = httpClient;
    }
}
