package nl.belastingdienst.iva.inzicht.dataprovider;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryFilter;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;

public abstract class AbstractQueryFactory {

    protected List<QueryResultColumn> mapColumns(List<QueryColumn> queryColumns) {
        List<QueryResultColumn> columnList = new ArrayList<>();

        for (QueryColumn queryColumn : queryColumns) {
            if (queryColumn.isComposite()) {
                columnList.addAll(mapColumns(queryColumn.getColumns()));
            } else if (!queryColumn.isValue()) {
                columnList.add(new QueryResultColumn(queryColumn.getName(), queryColumn.getAlias(), queryColumn.isMaskable()));
            }
        }
        
        return columnList;
    }
    
    protected String addFilters(String queryTemplate, QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Map<String, String> queryFilterMap = buildFilters(query, queryValues);
        String filteredQueryTemplate = queryTemplate;
        
        for (Map.Entry<String, String> queryFilter : queryFilterMap.entrySet()) {
            filteredQueryTemplate = QueryUtils.addFilter(queryFilter.getKey(), filteredQueryTemplate, queryFilter.getValue());
        }
        
        checkAbsentFilterPlaceholders(query.getKey(), filteredQueryTemplate);
        
        return filteredQueryTemplate;
    }
    
    protected Map<String, String> buildFilters(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Map<String, String> queryFilterMap = new HashMap<>(); 
        List<QueryFilter> queryFilters = query.getQueryFilters();
        
        for (QueryFilter queryFilter : queryFilters) {
            String currentFilter = queryFilterMap.getOrDefault(queryFilter.getKey(), "");
            String nextFilter = buildFilter(currentFilter, queryFilter, queryValues);
            queryFilterMap.put(queryFilter.getKey(), nextFilter);
        }
        
        return queryFilterMap;
    }
    
    protected String buildFilter(String filter, QueryFilter queryFilter, MultivaluedMap<String, String> queryValues) {
        StringBuilder filterBuilder = new StringBuilder(filter);
        List<String> parameterList = queryFilter.getParameterList();
        boolean parameterAvailable = parameterList.stream().allMatch(queryValues::containsKey);
        
        if (parameterAvailable) {
            filterBuilder.append(filterBuilder.length() > 0 ? " " : "");
            filterBuilder.append(queryFilter.getFilterTemplate());
        } else if (queryFilter.hasNoFilterTemplate()) {
            filterBuilder.append(filterBuilder.length() > 0 ? " " : "");
            filterBuilder.append(queryFilter.getNoFilterTemplate());
        }
        
        return filterBuilder.toString();
    }
    
    protected void checkAbsentFilterPlaceholders(String queryKey, String queryTemplate) {
        if (QueryUtils.detectFilter(queryTemplate)) {
            String message = "The query " + queryKey + " is probably missing a filter, a placeholder is still present in query " + queryTemplate;
            throw new IllegalStateException(message);
        }
    }
    
    protected String replaceParameters(Datasource datasource, String queryTemplate, MultivaluedMap<String, String> queryParameters, Configuration configuration) {
        String query = queryTemplate;
        Matcher matcher = QueryUtils.PATTERN_ANYPARAMETER.matcher(query);

        while (matcher.find()) {
            String parameter = matcher.group();
            String value = prepareParameters(datasource, queryTemplate, parameter, queryParameters, configuration);
            query = matcher.replaceFirst(value);
            matcher = QueryUtils.PATTERN_ANYPARAMETER.matcher(query);
        }

        return query;
    }

    protected String replaceParameters(String queryTemplate, MultivaluedMap<String, String> queryParameters) {
        return replaceParameters(null, queryTemplate, queryParameters, null);
    }
    
    protected abstract String prepareValue(Datasource datasource, QueryParameterType type, String value);
    
    protected String prepareParameters(Datasource datasource, String inputQueryTemplate, String parameter, 
            MultivaluedMap<String, String> queryParameters, Configuration configuration) {

        String parameterName = QueryUtils.extractParameterName(parameter);
        QueryParameterType parameterType = QueryUtils.extractParameterType(parameter);
        String parameters;

        if (parameterType == null) {
            throw new IllegalStateException("The parameter " + parameter + " is missing a known type in query " + inputQueryTemplate);
        } else if (parameterType.isConfigurationValue()) {
            parameters = prepareConfigurationValue(datasource, inputQueryTemplate, parameterName, parameterType, configuration);
        } else if (parameterType.isSingleValue()) {
            parameters = prepareSingleValue(datasource, inputQueryTemplate, parameterName, parameterType, queryParameters);
        } else {
            parameters = prepareMultipleValues(datasource, inputQueryTemplate, parameterName, parameterType, queryParameters);
        }

        return parameters;
    }

    protected String prepareConfigurationValue(Datasource datasource, String queryTemplate, String name, QueryParameterType type, Configuration configuration) {
        String value = datasource == null ? null : datasource.getValue(name);

        if (value == null) {
            value = configuration == null ? null : configuration.getValueAsString(name);
        }

        if (value == null) {
            String message = "The configuration value " + name + " (" + type + ") does not exist for query " + queryTemplate;
            throw new InternalServerErrorException(message);
        }

        return value;
    }
    
    protected String prepareSingleValue(Datasource datasource, String queryTemplate, String name, QueryParameterType type, MultivaluedMap<String, String> queryParameters) {
        String value = queryParameters.getFirst(name);

        if (!type.validate(value)) {
            String message = "The query parameter " + name + " (" + type + ") is invalid with value '" + value + "' for query " + queryTemplate;
            throw new BadRequestException(message);
        }

        return prepareValue(datasource, type, value);
    }
    
    protected String prepareMultipleValues(Datasource datasource, String queryTemplate, String name, QueryParameterType type, MultivaluedMap<String, String> queryParameters) {
        List<String> values = queryParameters.get(name);

        if (!type.validateAll(values)) {
            String message = "The query parameter " + name + " (" + type + ") is invalid with values '"
                    + (values == null ? null : String.join(", ", values)) + "' for query " + queryTemplate;
            throw new BadRequestException(message);
        }

        return values.stream().map(value -> this.prepareValue(datasource, type, value)).collect(Collectors.joining(", "));
    }
}
