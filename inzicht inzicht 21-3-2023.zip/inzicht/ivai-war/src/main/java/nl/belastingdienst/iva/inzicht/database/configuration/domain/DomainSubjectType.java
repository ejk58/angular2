package nl.belastingdienst.iva.inzicht.database.configuration.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_DOMAIN_SUBJECTTYPE")
public class DomainSubjectType {

    @Id
    private int id;
    private String label;
    private String searchKey;
    private Integer index;
    private String searchFilter;

    public Integer getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public String getSearchKey() {
        return searchKey;
    }

    public Integer getIndex() { 
    	return index; 
    }

    public String getSearchFilter() { 
    	return searchFilter; 
    }
}
