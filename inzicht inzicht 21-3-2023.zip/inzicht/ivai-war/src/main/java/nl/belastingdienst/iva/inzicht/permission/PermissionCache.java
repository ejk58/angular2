package nl.belastingdienst.iva.inzicht.permission;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import nl.belastingdienst.iva.inzicht.domain.permission.Permission;

public class PermissionCache {
    
    private static final int INITIALCAPACITY = 1024;
    private static final float LOADFACTOR = 0.75f;
    private static final int CONCURRENCYLEVEL = 256;

    private Map<PermissionCacheKey, Permission> permissionMap;

    public PermissionCache() {
        this.permissionMap = new ConcurrentHashMap<>(INITIALCAPACITY, LOADFACTOR, CONCURRENCYLEVEL);
    }
    
    public Permission retrieve(PermissionCacheKey cacheKey) {
        return this.permissionMap.get(cacheKey);
    }

    public Permission retrieve(String permissionProvider, String domainKey, String userName, String key, String value) {
        PermissionCacheKey cacheKey = new PermissionCacheKey(permissionProvider, domainKey, userName, key, value);
        return retrieve(cacheKey);
    }

    public void store(PermissionCacheKey cacheKey, Permission access) {
        this.permissionMap.put(cacheKey, access);
    }

    public void store(String permissionProvider, String domainKey, String userName, String key, String value, Permission access) {
        PermissionCacheKey cacheKey = new PermissionCacheKey(permissionProvider, domainKey, userName, key, value);
        store(cacheKey, access);
    }

    public int getSize() {
        return this.permissionMap.size();
    }

    public void clean(long expirationAge) {
        Set<PermissionCacheKey> permissionCacheKeySet = this.permissionMap.keySet();
        long expirationMoment = System.currentTimeMillis() - expirationAge;

        for (PermissionCacheKey key : permissionCacheKeySet) {
            if (key.getMoment() < expirationMoment) {
                this.permissionMap.remove(key);
            }
        }
    }
}
