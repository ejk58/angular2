package nl.belastingdienst.iva.inzicht.releasenote;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataClient;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataQuery;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.releasenote.ReleaseNote;

public class ReleaseNoteProvider {

    private static final QueryInterface QUERY_RELEASENOTES = new TeradataQuery("rfdw_inz_releasenotes", 
            "SELECT datum AS releaseDate, releasenr AS releaseVersion, klantbeeld AS domainKey, tickettype AS changeType, " + 
            "omschrijving AS description, opleiding_ind AS prereleaseFlag, productie_ind AS productionFlag " +
            "FROM {teradataSchema:config}.{viewName} WHERE single_amp_ind = 1 AND {environmentReleaseNotesColumnName:config} = 1 ");
    
    @Inject
    private TeradataClient teradataClient;
    
    public List<ReleaseNote> retrieveReleaseNotes(Configuration configuration) {
        List<DataMap> releaseNotesData = loadReleaseNotes(configuration);
        return mapReleaseNotes(configuration, releaseNotesData);
    }

    private List<DataMap> loadReleaseNotes(Configuration configuration) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>();
        return this.teradataClient.retrieveDataAsMultiMap(QUERY_RELEASENOTES, configuration, queryValues);
    }
    
    private List<ReleaseNote> mapReleaseNotes(Configuration configuration, List<DataMap> releaseNotesData) {
        List<ReleaseNote> releaseNotes = new ArrayList<>();
        
        for (int index = 0; index < releaseNotesData.size(); index++) {
            DataMap releaseNotesRow = releaseNotesData.get(index);
            
            Date releaseDate = mapDateField(releaseNotesRow, "releaseDate");
            String version = mapTextField(releaseNotesRow, "releaseVersion");
            Domain domain = mapDomainField(configuration, releaseNotesRow, "domainKey");
            String type = mapTextField(releaseNotesRow, "changeType");
            String description = mapTextField(releaseNotesRow, "description"); 
            
            releaseNotes.add(new ReleaseNote(releaseDate, version, domain, type, description));
        }
        
        return releaseNotes;
    }
    
    private Date mapDateField(DataMap releaseNotesRow, String key) {
        return new Date((Long) releaseNotesRow.get(key));
    }
    
    private String mapTextField(DataMap releaseNotesRow, String key) {
        return (String) releaseNotesRow.get(key);
    }
    
    private Domain mapDomainField(Configuration configuration, DataMap releaseNotesRow, String key) {
        String domainKey = (String) releaseNotesRow.get(key);
        return configuration.findDomain(domainKey);
    }
}
