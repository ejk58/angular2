package nl.belastingdienst.iva.inzicht.dataprovider;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class Result {

	public static final String ALLAMPTERADATAQUERY = "allAmpTeradataQuery";
	public static final String ERRORMESSAGE = "errorMessage";
	
	private List<DataMap> data;
	private DataMap metadata;
	
	public Result(List<DataMap> data, DataMap metadata) {
		this.data = data;
		this.metadata = metadata;
	}

	public Result(DataMap[] data, DataMap metadata) {
		this(new ArrayList<>(Arrays.asList(data)), metadata);
	}

	public Result(List<DataMap> data) {
		this(data, new DataHashMap());
	}

	public Result(DataMap[] data) {
		this(new ArrayList<>(Arrays.asList(data)), new DataHashMap());
	}

	public Result() {
		this(new ArrayList<>(), new DataHashMap());
	}

	public List<DataMap> getData() {
		return data;
	}

	public DataMap getMetadata() {
		return metadata;
	}

	public void setData(List<DataMap> data) {
		this.data = data;
	}
	
	public void setData(DataMap[] data) {
		this.data = new ArrayList<>(Arrays.asList(data));
	}
	
	public void setMetadata(DataMap metadata) {
		this.metadata = metadata;
	}

	public void addData(DataMap data) {
		this.data.add(data);
	}

	public void addData(List<DataMap> data) {
		this.data.addAll(data);
	}

	public void addData(DataMap[] data) {
		this.data.addAll(new ArrayList<>(Arrays.asList(data)));
	}
}
