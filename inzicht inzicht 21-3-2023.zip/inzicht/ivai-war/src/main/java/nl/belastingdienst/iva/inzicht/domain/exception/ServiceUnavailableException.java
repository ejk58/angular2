package nl.belastingdienst.iva.inzicht.domain.exception;

import javax.ejb.ApplicationException;

@ApplicationException
public class ServiceUnavailableException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    
    public ServiceUnavailableException(String message) {
        super(message);
    }
    
    public ServiceUnavailableException(String message, Throwable exception) {
        super(message, exception);
    }
}
