package nl.belastingdienst.iva.inzicht.configuration;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;

public class DefaultValues {

    public static final Map<String, String> VALUES;

    private static final String[][] DEFAULTVALUES = {
            {ConfigurationKey.CONFIGURATIONSTATUS, "ERROR"},
            {ConfigurationKey.MIHSUBJECTVIPRESTQUERY, "/mihproxy/v1/authorizedForBsn/{fiscalNr:fiscalnumber}"},
            {ConfigurationKey.MIHENTITYVIPRESTQUERY, "/mihproxy/v1/authorizedForEntity/{entityNr:entitynumber}"},
            {ConfigurationKey.PERMISSIONCACHEACCESSIBLE, "false"},
            {ConfigurationKey.PERMISSIONPROVIDER, "Teradata"},
            {ConfigurationKey.PERMISSIONCACHEEXPIRATIONAGE, "3600000"}
            };

    static {
        Map<String, String> values = new HashMap<>();
        
        for (String[] defaultValue : DEFAULTVALUES) {
            values.put(defaultValue[0], defaultValue[1]);
        }
        
        VALUES = Collections.unmodifiableMap(values);
    }
    
    private DefaultValues() {
        throw new UnsupportedOperationException();
    }
}
