package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_DATASOURCE_PARAM")
public class DatasourceParamJPA {

    @Id
    private Integer id;
    private String key;
    private String value;
    
    public DatasourceParamJPA() {
        // Default constructor
    }
    
    public DatasourceParamJPA(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getId() {
        return this.id;
    }
    
    public String getKey() {
        return this.key;
    }
    
    public String getValue() {
        return this.value;
    }
}
