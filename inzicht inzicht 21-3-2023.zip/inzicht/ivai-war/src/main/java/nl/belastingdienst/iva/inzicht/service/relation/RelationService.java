package nl.belastingdienst.iva.inzicht.service.relation;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.service.subject.SubjectMapper;
import nl.belastingdienst.iva.inzicht.service.subject.SubjectResponse;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/relation")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class RelationService extends AbstractRestService {

    @Inject
    private DataProvider dataprovider;

    @Inject
    private SubjectMapper subjectMapper;
    
    @GET
    @Produces({ MediaType.APPLICATION_JSON })
    public Response getRelations(@Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.RELATIONSERVICE, queryValues);
        
        try {
            validateRestCallParameters(restCallContext);
            checkRequiredRoles(restCallContext);
            
            Domain domain = restCallContext.findDomain();
            List<DataMap> response = retrieveRelationsForDomain(domain, restCallContext);
            SubjectResponse[] relations = mapResponseToRelations(response);
            
            return buildResponse(Status.OK, relations, restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
    
    private List<DataMap> retrieveRelationsForDomain(Domain domain, RestCallContext restCallContext) {
        Query query = domain.getRelationQuery();

        this.dataprovider.retrieveData(query, restCallContext);
        
        Result result = restCallContext.getResult();
        return result.getData();
    }
    
    private SubjectResponse[] mapResponseToRelations(List<DataMap> response) {
    	return this.subjectMapper.map(response);    	
    }
    
    private void validateRestCallParameters(RestCallContext restCallContext) {
        if (restCallContext.getDomainKey() == null) {
            throw new BadRequestException("The domain-key is missing from this rest-call");
        }
    }
}
