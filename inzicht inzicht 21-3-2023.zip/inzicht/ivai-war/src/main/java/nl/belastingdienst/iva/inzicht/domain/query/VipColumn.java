package nl.belastingdienst.iva.inzicht.domain.query;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.domain.JsonMapper;

public class VipColumn {

  private static final String TYPEFILTER = "FILTER";
  private static final String TYPETAG = "TAG";
  private static final String TYPEMASK = "MASK";
  private static final String TYPETAGMASK = "TAG&MASK";

  private final String type;
  private final List<String> columnKeys;
  private final List<List<String>> columnKeysList;
  private final List<String> tagColumnKeys;

  private final boolean filterType;
  private final boolean tagType;
  private final boolean maskType;

  public VipColumn(String type, String columnKeys, String columnKeysList, String tagColumnKeys) {
    this.type = type;
    this.columnKeys = QueryUtils.splitColumnKeys(columnKeys);
    this.columnKeysList = columnKeysList == null ? null : createColumnKeysList(columnKeysList);
    this.tagColumnKeys = QueryUtils.splitColumnKeys(tagColumnKeys);

    this.filterType = TYPEFILTER.equals(type);
    this.tagType = TYPETAG.equals(type) || TYPETAGMASK.equals(type);
    this.maskType = TYPEMASK.equals(type) || TYPETAGMASK.equals(type);
  }

  public String getType() {
    return this.type;
  }

  public List<String> getColumnKeys() {
    return this.columnKeys;
  }

  public List<List<String>> getColumnKeysList() {
    return this.columnKeysList;
  }

  public List<String> getTagColumnKeys() {
    return this.tagColumnKeys;
  }

  public boolean isFilterType() {
    return this.filterType;
  }

  public boolean isTagType() {
    return this.tagType;
  }

  public boolean isMaskType() {
    return this.maskType;
  }

  private List<List<String>> createColumnKeysList(String columnKeysListAsString) {
    JsonMapper jsonMapper = new JsonMapper();
    String attributeDescription = "columnsKeysList in query attribute vipColumn ";
    List<String> listWithColumnKeys = jsonMapper.mapToList(attributeDescription, String.class, columnKeysListAsString);
    return listWithColumnKeys.stream().map(QueryUtils::splitColumnKeys).collect(Collectors.toList());
  }
}
