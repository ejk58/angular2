package nl.belastingdienst.iva.inzicht.permission;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;
import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataClient;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataQuery;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.domain.permission.FiscalNumberUtils;
import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.User;

@Typed(InternalPermissionProvider.class)
public class InternalPermissionProvider implements PermissionProvider {

    private static final String SQLQUERY = "CALL {teradataSchema:config}.{viewName}('{fiscalNr:fiscalnumber}')";
    private static final String VIEWNAME = "p_persoon_1";

    private static final Permission PERMISSION_FULLACCESS = new Permission(true);
    private static final Permission PERMISSION_NOBVRVIP = new Permission(false, Arrays.asList("BVR"));
    private static final Permission PERMISSION_NOAKIMINFIN = new Permission(false, Arrays.asList("AKI"));
    private static final Permission PERMISSION_NOZVP = new Permission(false, Arrays.asList("ZVP"));
    private static final Permission PERMISSION_NOATKENTITY = new Permission(false, Arrays.asList("ATK"));
    private static final Permission PERMISSION_NOSEGMENT = new Permission(false, Arrays.asList("Segment"));

    private static final String ROLE_BVRVIP = "aug_IVAI_permission_vip";
    private static final String ROLE_AKIMINFIN = "aug_IVAI_permission_minfin";
    private static final String ROLE_ZVP = "aug_IVAI_permission_zvp";
    private static final String ROLEPREFIX_ATKENTITY = "aug_go_ent_";
    private static final String ROLE_SEGMENTNONE = "aug_IVAI_permission_segment_none";
    private static final String ROLE_SEGMENTGO = "aug_IVAI_permission_segment_go";
    private static final String ROLE_SEGMENTMKB = "aug_IVAI_permission_segment_mkb";
    private static final String ROLE_SEGMENTP = "aug_IVAI_permission_segment_p";

    private static final String COLUMNKEY_BVRVIP = "is_bvr_afgeschermd_ind";
    private static final String COLUMNKEY_AKIMINFIN = "is_aki_afgeschermd_ind";
    private static final String COLUMNKEY_ZVP = "is_zvp_afgeschermd_ind";
    private static final String COLUMNKEY_ATKENTITY = "is_atk_afgeschermd_ind";
    private static final String COLUMNKEY_SEGMENT = "segment";

    private static final String COLUMNVALUE_SEGMENTP = "PDB";
    private static final String COLUMNVALUE_SEGMENTMKB = "MKB";
    private static final String COLUMNVALUE_SEGMENTGO = "GO";

    private static final Integer TRUE = Integer.valueOf(1);

    @Inject
    private TeradataClient teradataClient;

    @Override
    public Permission getPermission(RestCallContext restCallContext, String key) {
        Permission permission = PERMISSION_FULLACCESS;
        
        if (checkQueryValuesContainFiscalNumber(restCallContext, key)) {
            DataMap dataMap = getPermissionDataFromTeradata(restCallContext);
            permission = determinePermissionForUser(restCallContext, dataMap);
        }

        return permission;
    }
    
    private boolean checkQueryValuesContainFiscalNumber(RestCallContext restCallContext, String key) {
        if (QueryValueKey.FISCALNR.equals(key)) {
            MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
            String fiscalNumber = queryValues.getFirst(key);
            return fiscalNumber != null && FiscalNumberUtils.checkFiscalNumberMatchesPattern(fiscalNumber);
        }
        
        return false;
    }
    
    private DataMap getPermissionDataFromTeradata(RestCallContext restCallContext) {
        QueryInterface query = getPermissionQuery();
        List<DataMap> data = executePermissionQuery(restCallContext, query);
        
        if (data.size() > 1) {
            MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
            String fiscalNr = queryValues.getFirst(QueryValueKey.FISCALNR); 
            String message = "The internal permission provider could not determine the permission, because the permission-query for fiscal number " + 
                    fiscalNr + " did return multiple (" + data.size() + ") rows!";
            throw new IllegalStateException(message);
        }

        return data.size() == 1 ? data.get(0) : null;
    }

    private Permission determinePermissionForUser(RestCallContext restCallContext, DataMap dataMap) {
        Permission permission = PERMISSION_FULLACCESS;

        if (dataMap != null) {
            User user = restCallContext.getUser();
            List<Permission> permissionList = new ArrayList<>();
            
            permissionList.add(determineBvrVipPermissionForUser(user, dataMap));
            permissionList.add(determineAkiMinFinPermissionForUser(user, dataMap));
            permissionList.add(determineZvpPermissionForUser(user, dataMap));
            permissionList.add(determineAtkEntityPermissionForUser(user, dataMap));
            permissionList.add(determineSegmentPermissionForUser(user, dataMap));
            
            permission = createCompositePermission(permissionList);
        }

        return permission;
    }
    
    private Permission determineBvrVipPermissionForUser(User user, DataMap dataMap) {
        return (TRUE.equals(dataMap.get(COLUMNKEY_BVRVIP)) && !user.hasRole(ROLE_BVRVIP)) ? PERMISSION_NOBVRVIP : PERMISSION_FULLACCESS;
    }
    
    private Permission determineAkiMinFinPermissionForUser(User user, DataMap dataMap) {
        return (TRUE.equals(dataMap.get(COLUMNKEY_AKIMINFIN)) && !user.hasRole(ROLE_AKIMINFIN)) ? PERMISSION_NOAKIMINFIN : PERMISSION_FULLACCESS;
    }
    
    private Permission determineZvpPermissionForUser(User user, DataMap dataMap) {
        return (TRUE.equals(dataMap.get(COLUMNKEY_ZVP)) && !user.hasRole(ROLE_ZVP)) ? PERMISSION_NOZVP : PERMISSION_FULLACCESS;
    }
    
    private Permission determineAtkEntityPermissionForUser(User user, DataMap dataMap) {
        Permission permission = PERMISSION_FULLACCESS;
        
        if (TRUE.equals(dataMap.get(COLUMNKEY_ATKENTITY))) {
            Object entityValue = dataMap.get("entiteitnr");
            if (entityValue == null) {
                String message = "The internal permission provider could not determine the permission, because the entity-number of the ATK-flagged subject is null!";
                throw new IllegalStateException(message);
            }

            String entityNumber = String.format("%09d", (Integer) entityValue);
            String entityRole = ROLEPREFIX_ATKENTITY + entityNumber.substring(entityNumber.length() - 9);
            permission = !user.hasRole(entityRole) ? PERMISSION_NOATKENTITY : PERMISSION_FULLACCESS;
        }
        
        return permission;
    }
    
    private Permission determineSegmentPermissionForUser(User user, DataMap dataMap) {
        String segment = (String) dataMap.get(COLUMNKEY_SEGMENT);
        String role = ROLE_SEGMENTNONE;

        if (COLUMNVALUE_SEGMENTGO.equals(segment)) {
            role = ROLE_SEGMENTGO;
        } else if (COLUMNVALUE_SEGMENTMKB.equals(segment)) {
            role = ROLE_SEGMENTMKB;
        } else if (COLUMNVALUE_SEGMENTP.equals(segment)) {
            role = ROLE_SEGMENTP;
        }
        
        return !user.hasRole(role) ? PERMISSION_NOSEGMENT : PERMISSION_FULLACCESS;
    }
    
    private Permission createCompositePermission(List<Permission> permissionList) {
        boolean access = true;
        List<String> categories = new ArrayList<>();
        
        for (Permission permission : permissionList) {
            access = access && permission.getAccess();
            categories.addAll(permission.getCategories());
        }
        
        return new Permission(access, categories);
    }
   
    private QueryInterface getPermissionQuery() {
        return new TeradataQuery(VIEWNAME, SQLQUERY);
    }

    private List<DataMap> executePermissionQuery(RestCallContext restCallContext, QueryInterface query) {
        Configuration configuration = restCallContext.getConfiguration();
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        return this.teradataClient.retrieveDataAsMultiMap(query, configuration, queryValues);
    }
}
