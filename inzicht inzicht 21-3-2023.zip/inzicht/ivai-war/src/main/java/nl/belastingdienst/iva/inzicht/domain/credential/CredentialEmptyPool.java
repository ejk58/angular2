package nl.belastingdienst.iva.inzicht.domain.credential;

public class CredentialEmptyPool implements CredentialPool {

    @Override
    public Credential getCredential() {
        return null;
    }
}
