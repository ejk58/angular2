package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class NestedColumnMapper implements ColumnMapper {

	private static final String TOKEN_EVERYTHING = "*";
	private static final String TOKEN_FULLARRAY = "[*]";
	private static final String TOKEN_FIRSTARRAYELEMENT = "[0]";
	private static final String TOKEN_LASTARRAYELEMENT = "[$]";

	private static final String DIVIDER = "/";
	
	private String[] sourceKeys;
	private String destinationKey;
	
	public NestedColumnMapper(String sourceKeys, String destinationKey) {
		this.sourceKeys = TOKEN_EVERYTHING.equals(sourceKeys) ? new String[0] : sourceKeys.split(DIVIDER);
		this.destinationKey = destinationKey;
	}
	
	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public Object getValue(DataMap sourceDataMap) {
		return getValue(sourceDataMap, 0);
	}
	
	private Object getValue(Object sourceObject, int index) {
		Object result = sourceObject;

		if ((index < this.sourceKeys.length) && (sourceObject != null)) {
			if (sourceObject instanceof List) {
				result = getListValue((List<?>) sourceObject, index);
			} else if (sourceObject instanceof Map) {
				result = getMapValue((Map<?, ?>) sourceObject, index);
			}
		}

		return result;
	}
	
	private Object getListValue(List<?> sourceList, int index) {
		Object result = sourceList;
		
		if (!sourceList.isEmpty()) {
			if (TOKEN_FULLARRAY.equals(this.sourceKeys[index])) {
				List<Object> resultList = new ArrayList<>();
	
				for (Object sourceElement : sourceList) {
					resultList.add(getValue(sourceElement, index + 1));
				}
				
				result = resultList;
			} else if (TOKEN_FIRSTARRAYELEMENT.equals(this.sourceKeys[index])) {
				result = getValue(sourceList.get(0), index + 1);
			} else if (TOKEN_LASTARRAYELEMENT.equals(this.sourceKeys[index])) {
				result = getValue(sourceList.get(sourceList.size() - 1), index + 1);
			}
		}
		
		return result;
	}
	
	private Object getMapValue(Map<?, ?> sourceMap, int index) {
		return getValue(sourceMap.get(this.sourceKeys[index]), index + 1);
	}
}
