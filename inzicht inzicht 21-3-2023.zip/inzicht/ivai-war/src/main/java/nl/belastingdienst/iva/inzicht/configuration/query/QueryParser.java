package nl.belastingdienst.iva.inzicht.configuration.query;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryFilter;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameter;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;
import nl.belastingdienst.iva.inzicht.domain.query.VipColumn;

public class QueryParser {

  private static final Logger logger = LoggerFactory.getLogger(QueryParser.class);

  private ColumnMapperFactory columnMapperFactory;

  private ObjectMapper jsonObjectMapper;

  public QueryParser(Map<String, AttributeGroup> attributeGroupMap) {
    this.columnMapperFactory = new ColumnMapperFactory(attributeGroupMap);
    this.jsonObjectMapper = new ObjectMapper();
  }

  public QueryParser(Map<String, AttributeGroup> attributeGroupMap, ObjectMapper jsonObjectMapper) {
    this.columnMapperFactory = new ColumnMapperFactory(attributeGroupMap);
    this.jsonObjectMapper = jsonObjectMapper;
  }

  public void parse(List<Query> queryList) {
    for (Query query : queryList) {
      addParameterInformation(query);
      addVipColumns(query);
      addResultMapper(query);
    }
  }

  private void addParameterInformation(Query query) {
    List<QueryColumn> queryColumns = query.getQueryColumns();
    List<QueryFilter> queryFilters = query.getQueryFilters();

    this.addParametersFromElement(query, query.getQueryTemplate(), true);

    for (QueryColumn queryColumn : queryColumns) {
      this.addParametersFromElement(query, queryColumn.getName(), true);
    }

    for (QueryFilter queryFilter : queryFilters) {
      this.addParametersFromElement(query, queryFilter.getFilterTemplate(), false);
      this.addParametersFromElement(query, queryFilter.getNoFilterTemplate(), false);
    }
  }

  private void addVipColumns(Query query) {
    List<String> maskableColumnKeys = new ArrayList<>();
    String vipColumnValue = query.getQueryAttributeValue("vipColumn");

    try {
      if (vipColumnValue != null) {
        DataMap vipColumnMap = this.jsonObjectMapper.readValue(vipColumnValue, DataHashMap.class);
        String type = vipColumnMap.getAsString("type");
        String columnKeys = vipColumnMap.getAsString("columnKeys");
        String columnKeysList = vipColumnMap.getAsString("columnKeysList");
        String tagColumnKeys = vipColumnMap.getAsString("tagColumnKeys");
        query.setVipColumn(new VipColumn(type, columnKeys, columnKeysList, tagColumnKeys));
      }
    } catch (IOException exception) {
      String message = "The vip column attribute '" + vipColumnValue + "' of query " + query.getKey() + " could not be parsed.";
      query.addErrorMessage(message);
      logger.error(message);
    }

    for (QueryColumn column : query.getQueryColumns()) {
      if (column.isMaskable()) {
        maskableColumnKeys.add(column.getDestinationKey());
      }
    }

    if (!maskableColumnKeys.isEmpty()) {
      query.setMaskableColumnKeysList(maskableColumnKeys);
    }
  }

  private void addResultMapper(Query query) {
    List<ColumnMapper> columnMapperList = new ArrayList<>();

    for (QueryColumn column : query.getQueryColumns()) {
      columnMapperList.add(this.columnMapperFactory.getColumnMapper(query, column));
    }

    query.setResultMapper(new SimpleResultMapper(columnMapperList));
  }

  private void addParametersFromElement(Query query, String queryElement, boolean required) {
    if (queryElement != null) {
      Matcher matcher = QueryUtils.PATTERN_ANYPARAMETER.matcher(queryElement);

      while (matcher.find()) {
        String parameterDescription = matcher.group();
        String parameterName = QueryUtils.extractParameterName(parameterDescription);
        QueryParameterType parameterType = QueryUtils.extractParameterType(parameterDescription);

        if (parameterType != null) {
          query.addQueryParameter(new QueryParameter(parameterName, parameterType, required));
        } else {
          String message = "The type of the parameter '" + parameterDescription + "' in query " + query.getKey() + " is not recognized.";
          query.addErrorMessage(message);
          logger.error(message);
        }
      }
    }
  }
}
