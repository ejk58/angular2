package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class FlowAction implements Action {

	public static final String NAME = "Flow";

	private Flow flow;
	
	public FlowAction(String flowName) {
		this.flow = Flow.findFlow(flowName);
		
		if (this.flow == null) {
			throw new IllegalStateException("The Flow-action did not find a valid flow with name " + flowName + ".");
		}
	}

	@Override
	public Flow execute(RestCallContext restCallContext) {
		return this.flow;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.flow.getName() + RulesEngineKey.PARAMETEREND;
	}
}
