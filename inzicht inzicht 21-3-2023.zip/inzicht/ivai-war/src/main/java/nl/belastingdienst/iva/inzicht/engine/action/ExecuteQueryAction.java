package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class ExecuteQueryAction implements Action {

	public static final String NAME = "ExecuteQuery";
	
	private DataProvider dataProvider;
	
	public ExecuteQueryAction(DataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
	    QueryInterface query = restCallContext.getQuery();
        this.dataProvider.retrieveData(query, restCallContext);
        return Flow.CONTINUE;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + RulesEngineKey.PARAMETEREND;
	}
}
