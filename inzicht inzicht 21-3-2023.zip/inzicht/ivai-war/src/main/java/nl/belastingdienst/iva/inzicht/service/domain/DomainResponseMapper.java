package nl.belastingdienst.iva.inzicht.service.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.domain.DomainComparator;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.WidgetAttribute;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.JsonMapper;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameter;

@Typed(DomainResponseMapper.class)
public class DomainResponseMapper {

  public static final String QUERY_PARAMETERS = "queryParameters";

  @Inject
    private DomainMapper domainMapper;

    private final DomainComparator domainComparator = new DomainComparator();
    private final JsonMapper jsonMapper = new JsonMapper();

    public DataMap map(Set<Domain> domainSet, Configuration configuration) {
        List<Domain> domainList = new ArrayList<>(domainSet);
        DataMap domainResponse = new DataHashMap();
        DataMap domains = new DataHashMap();
        List<DataMap> domainMenuItems = new ArrayList<>();

        Collections.sort(domainList, this.domainComparator);
        for (Domain domain : domainList) {
            if (!domain.getPageDomains().isEmpty()) {
                String domainKey = domain.getKey();
                List<Page> pageList = configuration.findPagesByDomain(domainKey);
                DataMap mappedDomain = this.domainMapper.mapToDomain(domain, pageList);
                DataMap mappedMenuItem = this.domainMapper.mapToMenuItem(domain);

                domains.put(domainKey, mappedDomain);
                domainMenuItems.add(mappedMenuItem);
            }
        }

        Map<String, List<QueryParameter>> queryParameters = new LinkedHashMap<>();
        Map<String, Widget> widgetMap = configuration.getWidgetMap();
        for (Widget widget : widgetMap.values()) {
            List<QueryParameter> widgetQueryParameters = hasQueryParameters(widget) ? widget.getQuery().getQueryParameters() : new ArrayList<>();
            QueryParameter[] queryParametersInWidgetAttribute = getQueryParametersFromWidgetAttribute(widget);
            for (QueryParameter queryParameter : queryParametersInWidgetAttribute) {
                if (isQueryParameterNotYetPresent(widgetQueryParameters, queryParameter.getName())) {
                    widgetQueryParameters.add(queryParameter);
                }
            }
            queryParameters.put(widget.getName(), widgetQueryParameters);
        }

        domainResponse.put(ResponseKey.DOMAINS, domains);
        domainResponse.put(ResponseKey.MENUITEMS, domainMenuItems);
        domainResponse.put(ResponseKey.QUERYPARAMETERS, queryParameters);

        return domainResponse;
    }

    private QueryParameter[] getQueryParametersFromWidgetAttribute(Widget widget) {
        QueryParameter[] queryParametersInWidgetAttribute = new QueryParameter[]{};
        for (WidgetAttribute widgetAttribute : widget.getAttributeList()) {
            if (QUERY_PARAMETERS.equals(widgetAttribute.getKey())) {
                String description = "widgetAttribute in widget " + widget.getName();
                queryParametersInWidgetAttribute = jsonMapper.mapToArray(description, QueryParameter[].class, widgetAttribute.getValue());
            }
        }
        return queryParametersInWidgetAttribute;
    }

    private boolean hasQueryParameters(Widget widget) {
        return widget.getQuery() != null && widget.getQuery().getQueryParameters() != null && !widget.getQuery().getQueryParameters().isEmpty();
    }

    private boolean isQueryParameterNotYetPresent(List<QueryParameter> widgetQueryParameters, String newQueryParameterName) {
        return widgetQueryParameters.stream().noneMatch(queryParameter -> queryParameter.getName().equals(newQueryParameterName));
    }

}
