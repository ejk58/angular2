package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.domain.query.ModifiableQuery;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class AddFilterToQueryAction implements Action {

	public static final String NAME = "AddFilterToQuery";

	private String filter;
	private String queryFilter;
	
	public AddFilterToQueryAction(String filter) {
        this.filter = filter;
        this.queryFilter = "{:filter} " + filter;
    }
    
    @Override
    public Flow execute(RestCallContext restCallContext) {
        ModifiableQuery query = new ModifiableQuery(restCallContext.getQuery());
        String queryTemplate = query.getQueryTemplate();
        String filteredQueryTemplate = QueryUtils.addFilter(null, queryTemplate, this.queryFilter);
        query.setQueryTemplate(filteredQueryTemplate);
        restCallContext.setQuery(query);

        return Flow.CONTINUE;
    }
    
    @Override
    public String getAction() {
        return NAME + RulesEngineKey.PARAMETERSTART + this.filter + RulesEngineKey.PARAMETEREND;
    }
}
