package nl.belastingdienst.iva.inzicht.service.widget;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.domain.widget.WidgetMapper;
import nl.belastingdienst.iva.inzicht.engine.MultipleRule;
import nl.belastingdienst.iva.inzicht.engine.RulesEngine;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/widget")
@RolesAllowed({ RoleUtils.INZICHT_USER_ROLE })
public class WidgetService extends AbstractRestService {

    @Inject
    private DataProvider dataprovider;
    
    @Inject
    private RulesEngine rulesEngine;

    @Inject
    private WidgetMapper widgetMapper;

    @GET
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/{widgetId}")
    public Response getWidget(@PathParam(QueryValueKey.WIDGETKEY) String widgetId, @Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        queryValues.add(QueryValueKey.WIDGETKEY, widgetId);

        RestCallContext restCallContext = buildRestCallContext(RestServiceType.WIDGETSERVICE, queryValues);
        
        try {
            checkRequiredRoles(restCallContext);            

            Widget widget = restCallContext.findWidget();
            RuleGroup ruleGroup = widget.getRuleGroup();
            
            if (ruleGroup != null) {
            	MultipleRule rule = ruleGroup.getRule();
            	this.rulesEngine.run(rule, restCallContext);
            } else {
	            Query query = widget.getQuery();
	            this.dataprovider.retrieveData(query, restCallContext); 
	            mapWidgetToResponse(widget, restCallContext);
            }
            
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
    
    private void mapWidgetToResponse(Widget widget, RestCallContext restCallContext) {
    	Result result = restCallContext.getResult();
    	DataMap response = this.widgetMapper.map(widget, result);
    	restCallContext.setResponse(response);
    }
}
