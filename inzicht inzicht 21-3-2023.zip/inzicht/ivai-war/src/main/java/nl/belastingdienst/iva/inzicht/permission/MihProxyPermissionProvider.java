package nl.belastingdienst.iva.inzicht.permission;

import java.util.Collections;
import java.util.List;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.dataprovider.rest.MihVipRestQuery;
import nl.belastingdienst.iva.inzicht.dataprovider.rest.RestClient;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@Typed(MihProxyPermissionProvider.class)
public class MihProxyPermissionProvider implements PermissionProvider {

    private static final String PERMISSIONKEY = "toegestaan"; 
    private static final String CONTACTIMPORTANCEKEY = "contactImportances";
    
    @Inject
    private RestClient restClient;
    
    @Override
    public Permission getPermission(RestCallContext restCallContext, String key) {
        Configuration configuration = restCallContext.getConfiguration();
        QueryInterface mihVipRestQuery = getVipQuery(configuration, key);
        Datasource datasource = configuration.getMihProxyDatasource();
        DataMap[] response = this.restClient.retrieveDataAsMultiMap(datasource, mihVipRestQuery, restCallContext);
        return new Permission(getPermissionAccess(response), getContactImportances(response));
    }

    private QueryInterface getVipQuery(Configuration configuration, String key) {
        if (QueryValueKey.FISCALNR.equals(key)) {
        	return new MihVipRestQuery(configuration.getValueAsString(ConfigurationKey.MIHSUBJECTVIPRESTQUERY));
        } else if (QueryValueKey.ENTITYNR.equals(key)) {
        	return new MihVipRestQuery(configuration.getValueAsString(ConfigurationKey.MIHENTITYVIPRESTQUERY));
        }

    	return null;
    }

    private boolean getPermissionAccess(DataMap[] response) {
    	return Boolean.TRUE.equals(response[0].get(PERMISSIONKEY));
    }

    @SuppressWarnings("unchecked")
	private List<String> getContactImportances(DataMap[] response) {
    	Object contactImportances = response[0].get(CONTACTIMPORTANCEKEY);
    	return contactImportances instanceof List ? (List<String>) contactImportances : Collections.emptyList();
    }
}
