package nl.belastingdienst.iva.inzicht.service.releasenote;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.releasenote.ReleaseNote;

public class ReleaseNoteMapper {
	
	public List<DataMap> map(List<ReleaseNote> releaseNoteList) {
		return releaseNoteList.stream().map(this::mapElement).collect(Collectors.toList());
	}
	
	private DataMap mapElement(ReleaseNote releaseNote) {
		DataMap releaseNotes = new DataHashMap();

		releaseNotes.put(ResponseKey.RELEASEDATE, releaseNote.getReleaseDate());
		releaseNotes.put(ResponseKey.VERSION, releaseNote.getVersion());
		releaseNotes.put(ResponseKey.DOMAINNAME, releaseNote.getDomainName());
		releaseNotes.put(ResponseKey.TYPE, releaseNote.getType());
		releaseNotes.put(ResponseKey.DESCRIPTION, releaseNote.getDescription());
		
		return releaseNotes;
	}
}
