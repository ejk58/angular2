package nl.belastingdienst.iva.inzicht.domain;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.user.User;

public class MessageUtils {

    public static final String UNKNOWN = "<null>";
    
    private static final String[] SIZEUNITS = new String[]{"bytes", "kB", "MB", "GB", "TB"}; 
    private static final String ROLEPREFIX = "aug_IVAI_";
    
    private MessageUtils() {
        throw new UnsupportedOperationException();
    }
    
    public static String createMessage(MessageType type, String message) {
        return type.getLabel() + ", message = " + message;
    }
    
    public static String createDuration(long duration) {
        return duration < 120000L ? (Long.toString(duration) + " ms.") : (Long.toString(duration / 1000) + " s.");
    }
    
    public static String createSize(long size) {
        int index = 0;
        
        while (size >= 1024 && index < (SIZEUNITS.length - 1)) {
            size = size / 1024L;
            index++;
        }
        
        return Long.toString(size) + " " + SIZEUNITS[index];
    }
    
    public static String createRoles(User user) {
        List<String> roles = user.getRoles();
        return roles.stream().filter(role -> role.startsWith(ROLEPREFIX)).collect(Collectors.joining(", "));
    }
}
