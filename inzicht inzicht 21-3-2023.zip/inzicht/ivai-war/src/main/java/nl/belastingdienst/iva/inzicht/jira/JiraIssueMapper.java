package nl.belastingdienst.iva.inzicht.jira;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.jira.Feedback;
import nl.belastingdienst.iva.inzicht.domain.jira.IssueType;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.JiraIssueKey;

public class JiraIssueMapper {

	private static final String DESCRIPTIONITEMFORMAT = "*%s*: %s%n";
	private static final String UNKNOWNDOMAIN = "none";
	
	public DataMap map(Feedback feedback, Configuration configuration) {
		DataMap jiraIssue = new DataHashMap();
		
		jiraIssue.put(JiraIssueKey.PROJECT, DomainUtils.inMap(JiraIssueKey.ID, configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKPROJECT)));
        jiraIssue.put(JiraIssueKey.TYPE, DomainUtils.inMap(JiraIssueKey.ID, IssueType.STORY.getId()));
        jiraIssue.put(JiraIssueKey.SUMMARY, feedback.getSummary());       
        jiraIssue.put(JiraIssueKey.DESCRIPTION, makeDescription(feedback));
        jiraIssue.put(JiraIssueKey.FIXVERSIONS, findFixVersions(configuration, feedback.getTopic()));
        jiraIssue.put(JiraIssueKey.LABELS, new String[] {(configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKENVIRONMENT))});
        jiraIssue.put(JiraIssueKey.COMPONENT, findComponents(feedback, configuration));
        
		return DomainUtils.inMap(JiraIssueKey.ISSUE, jiraIssue);
	}
	
	private DataMap[] findComponents(Feedback feedback, Configuration configuration) {
		AttributeGroup jiraFeedbackComponentsGroup = configuration.getAttributeGroup(ConfigurationKey.JIRAFEEDBACKCOMPONENTSGROUP);
        if (jiraFeedbackComponentsGroup.getAttributeMap() == null || feedback.getDomainId() == null) {
            return null;
        }
              
        String componentKey = jiraFeedbackComponentsGroup.getAttributeMap().get(feedback.getDomainId());
        if (componentKey == null) {
        	componentKey = jiraFeedbackComponentsGroup.getAttributeMap().get(UNKNOWNDOMAIN);
        }
        
        DataMap jiraComponents = new DataHashMap();	
	    jiraComponents.put(JiraIssueKey.NAME, componentKey);
	    
	    return DomainUtils.inArray(jiraComponents);   
	}
	
	private DataMap[] findFixVersions(Configuration configuration, String topic) {
		AttributeGroup fixVersionAttributeGroup = configuration.getAttributeGroup(ConfigurationKey.JIRAFEEDBACKTOPICFIXVERSIONSGROUP);
		String fixVersionIdForTopic = fixVersionAttributeGroup.getAttributeMap().get(topic);
		return fixVersionIdForTopic == null ? DomainUtils.emptyDataMapArray() : DomainUtils.inArray(DomainUtils.inMap("id", fixVersionIdForTopic));
	}

	private String makeDescription(Feedback feedback) {
		StringBuilder description = new StringBuilder();
		
		description.append(makeDescriptionItem("Scope", feedback.getScope()));
		description.append(makeDescriptionItem("Topic", feedback.getTopic()));
		
		if (feedback.getRemark() != null) {
			if (description.length() > 0) {
				description.append(String.format("%n"));
			}
			description.append(String.format("%s%n%n", feedback.getRemark()));
		}
		
		description.append(makeDescriptionItem("Widget", feedback.getWidget()));
		description.append(makeDescriptionItem("Url", feedback.getUrl()));
		description.append(makeDescriptionItem("Scherm (zijde)", feedback.getSide()));
		description.append(makeDescriptionItem("Verstuurd door", feedback.getUsername()));
        description.append(makeDescriptionItem("Versie", feedback.getVersion()));
		
		return description.toString();
	}
	
	private String makeDescriptionItem(String label, String value) {
	    return value == null ? "" : String.format(DESCRIPTIONITEMFORMAT, label, value);
	}
}
