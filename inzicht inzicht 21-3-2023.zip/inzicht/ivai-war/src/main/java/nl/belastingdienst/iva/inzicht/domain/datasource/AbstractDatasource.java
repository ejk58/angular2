package nl.belastingdienst.iva.inzicht.domain.datasource;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.credential.Credential;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialPool;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;

public abstract class AbstractDatasource implements Datasource {

    private String key;
    private Map<String, String> parameterMap;
    private CredentialPool credentialPool;
    
    public AbstractDatasource(String key) {
        this.key = key;
        this.parameterMap = new HashMap<>();
    }
    
    @Override
    public String getKey() {
        return key;
    }

    @Override
    public Map<String, String> getParameterMap() {
        return this.parameterMap;
    }

    @Override
    public Credential getCredential() {
        return this.credentialPool.getCredential();
    }
    
    @Override
    public String getValue(String key) {
        String value = this.parameterMap.get(key);
        
        if (value == null && DatasourceKey.CREDENTIALVALUE.equals(key)) {
            Credential credential = this.credentialPool.getCredential();
            value = new String(credential.getValue());
        }
        
        return value;
    }

    @Override
    public Integer getNumber(String key) {
        String value = this.parameterMap.get(key);
        return (value == null) ? null : Integer.parseInt(value);
    }
    
    @Override
    public boolean getBoolean(String key) {
        String value = this.parameterMap.get(key);
        return DomainUtils.TRUE_ITEM.equalsIgnoreCase(value);
    }
    
    @Override
    public int hashCode() {
        return (this.key == null) ? 0 : this.key.hashCode();
    }

    @Override
    public boolean equals(Object otherObject) {
        if (this == otherObject) {
            return true;
        }

        if (otherObject == null || getClass() != otherObject.getClass()) {
            return false;
        }
        
        AbstractDatasource otherDatasource = (AbstractDatasource) otherObject;
        return (this.key == null) ? (otherDatasource.key == null) : this.key.equals(otherDatasource.key);
    }

    public void setParameterMap(Map<String, String> parameterMap) {
        this.parameterMap = parameterMap;
    }
    
    public void setCredentialPool(CredentialPool credentialPool) {
        this.credentialPool = credentialPool;
    }

    public String setValue(String key, String value) {
        return this.parameterMap.put(key, value);
    }
    
    public void lockParameterMap() {
        this.parameterMap = Collections.unmodifiableMap(this.parameterMap);
    }
}
