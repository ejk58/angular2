package nl.belastingdienst.iva.inzicht.domain.credential;

public enum CredentialTransport {
	URLPARAMETER("URLPARAMETER"),
	HTTPHEADER("HTTPHEADER"),
	COOKIE("COOKIE");
    
    private String name;
    
    private CredentialTransport(String name) {
        this.name = name;
    }

    public static CredentialTransport findCredentialTransport(String credentialTransportName) {
        for (CredentialTransport credentialTransport : values()) {
            if (credentialTransport.name.equals(credentialTransportName)) {
                return credentialTransport;
            }
        }
        
        return null;
    }
}
