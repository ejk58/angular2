package nl.belastingdienst.iva.inzicht.permission;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContextFactory;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class PermissionFactory {

    private static final Permission DEFAULTPERMISSION = new Permission(true);
    private static final String INTERNALPROVIDER = "Internal";
    private static final String TERADATAPROVIDER = "Teradata";
    private static final String MIHPROXYPROVIDER = "MIH";
    private static final long DEFAULTCACHEEXPIRATIONAGE = 3600000L;

    private static final Logger logger = LoggerFactory.getLogger(PermissionFactory.class);

    @Inject
    private ConfigurationFactory configurationFactory;

    @Inject
    private RestCallContextFactory restCallContextFactory;

    @Inject
    private InternalPermissionProvider internalPermissionProvider;

    @Inject
    private TeradataPermissionProvider teradataPermissionProvider;

    @Inject
    private MihProxyPermissionProvider mihProxyPermissionProvider;

    private PermissionCache permissionCache;
    private long cacheExpirationAge;

    public PermissionFactory() {
        this.permissionCache = new PermissionCache();
        this.cacheExpirationAge = DEFAULTCACHEEXPIRATIONAGE;
    }

    @Schedule(minute = "*/10", hour = "*", persistent = false)
    public void clean() {
        updateExpirationAge();
        cleanPermissionCache();
    }

    public Permission getPermission(RestCallContext restCallContext, QueryParameterType parameterType,
            String parameterValue) {
        Permission permission = DEFAULTPERMISSION;

        if (parameterType.isPermissionValue() && parameterValue != null) {
            RestCallContext permissionRestCallContext = createPermissionRestCallContext(restCallContext, parameterType, parameterValue);
            permission = getPermissionFromCacheOrProvider(permissionRestCallContext, parameterType);
        }

        return permission;
    }

    public Permission getPermission(RestCallContext restCallContext, String fiscalNr) {
        Permission permission = DEFAULTPERMISSION;

        if (fiscalNr != null) {
            RestCallContext permissionRestCallContext = createPermissionRestCallContext(restCallContext, QueryParameterType.FISCALNUMBER, fiscalNr);
            permission = getPermissionFromCacheOrProvider(permissionRestCallContext, QueryParameterType.FISCALNUMBER);
        }

        return permission;
    }

    public boolean getAccess(RestCallContext restCallContext, QueryParameterType parameterType, String parameterValue) {
        Permission permission = getPermission(restCallContext, parameterType, parameterValue);
        return permission.getAccess();
    }

    public boolean getAccess(RestCallContext restCallContext, String fiscalNr) {
        Permission permission = getPermission(restCallContext, fiscalNr);
        return permission.getAccess();
    }

    public boolean getAccess(RestCallContext restCallContext, List<String> fiscalNrList) {
        boolean access = DEFAULTPERMISSION.getAccess();
        List<String> fiscalNrListToBeCheckedViaProvider = new ArrayList<>();

        Iterator<String> itViaCache = fiscalNrList.iterator();
        while (itViaCache.hasNext() && access) {
            String fiscalNr = itViaCache.next();
            Permission permission = null;
            RestCallContext permissionRestCallContext = createPermissionRestCallContext(restCallContext,
                    QueryParameterType.FISCALNUMBER, fiscalNr);
            if (getCacheAvailable(permissionRestCallContext)) {
                permission = getPermissionFromCache(permissionRestCallContext, QueryParameterType.FISCALNUMBER);
            }
            if (permission != null) {
                access = permission.getAccess();
            } else {
                fiscalNrListToBeCheckedViaProvider.add(fiscalNr);
            }
        }

        Iterator<String> itViaProvider = fiscalNrListToBeCheckedViaProvider.iterator();
        while (itViaProvider.hasNext() && access) {
            String fiscalNr = itViaProvider.next();
            RestCallContext permissionRestCallContext = createPermissionRestCallContext(restCallContext, QueryParameterType.FISCALNUMBER, fiscalNr);
            Permission permission = getPermissionFromProvider(permissionRestCallContext, QueryParameterType.FISCALNUMBER);
            access = permission.getAccess();
        }

        return access;
    }

    public DataMap getStatus() {
        return createStatus();
    }

    public boolean getCacheAvailable(RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
        return DomainUtils.isTrue(configuration.getValueAsString(ConfigurationKey.PERMISSIONCACHEACCESSIBLE)) && (restCallContext.getUserName() != null);
    }

    private Permission getPermissionFromCacheOrProvider(RestCallContext restCallContext,
            QueryParameterType parameterType) {
        Permission permission = null;

        if (getCacheAvailable(restCallContext)) {
            permission = getPermissionFromCache(restCallContext, parameterType);
        }

        if (permission == null) {
            permission = getPermissionFromProvider(restCallContext, parameterType);
        }

        return permission;
    }

    private Permission getPermissionFromCache(RestCallContext restCallContext, QueryParameterType parameterType) {
        Configuration configuration = restCallContext.getConfiguration();
        String permissionProvider = configuration.getValueAsString(ConfigurationKey.PERMISSIONPROVIDER);
        PermissionCacheKey cacheKey = createPermissionCacheKey(permissionProvider, restCallContext, parameterType);
        return this.permissionCache.retrieve(cacheKey);
    }

    private Permission getPermissionFromProvider(RestCallContext restCallContext, QueryParameterType parameterType) {
        Configuration configuration = restCallContext.getConfiguration();
        String permissionProvider = configuration.getValueAsString(ConfigurationKey.PERMISSIONPROVIDER);
        Permission permission;

        if (INTERNALPROVIDER.equalsIgnoreCase(permissionProvider)) {
            permission = getInternalPermission(restCallContext, parameterType);
        } else if (TERADATAPROVIDER.equalsIgnoreCase(permissionProvider)) {
            permission = getTeradataPermission(restCallContext, parameterType);
        } else if (MIHPROXYPROVIDER.equalsIgnoreCase(permissionProvider)) {
            permission = getMihProxyPermission(restCallContext, parameterType);
        } else {
            String message = "The configured permission provider (" + permissionProvider + ") is not supported.";
            throw new IllegalStateException(message);
        }

        if (getCacheAvailable(restCallContext)) {
            PermissionCacheKey cacheKey = createPermissionCacheKey(permissionProvider, restCallContext, parameterType);
            this.permissionCache.store(cacheKey, permission);
        }

        return permission;
    }

    private Permission getInternalPermission(RestCallContext restCallContext, QueryParameterType parameterType) {
        return this.internalPermissionProvider.getPermission(restCallContext, parameterType.getPermissionKey());
    }

    private Permission getMihProxyPermission(RestCallContext restCallContext, QueryParameterType parameterType) {
        return this.mihProxyPermissionProvider.getPermission(restCallContext, parameterType.getPermissionKey());
    }

    private Permission getTeradataPermission(RestCallContext restCallContext, QueryParameterType parameterType) {
        return this.teradataPermissionProvider.getPermission(restCallContext, parameterType.getPermissionKey());
    }

    private void updateExpirationAge() {
        Configuration configuration = this.configurationFactory.getConfiguration();
        this.cacheExpirationAge = configuration.getValueAsNumber(ConfigurationKey.PERMISSIONCACHEEXPIRATIONAGE);
    }

    private void cleanPermissionCache() {
        logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Starting the cleaning of the permission cache."));

        long startTime = System.currentTimeMillis();
        try {
            this.permissionCache.clean(this.cacheExpirationAge);

            logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Cleaned the permission cache in "
                    + MessageUtils.createDuration(System.currentTimeMillis() - startTime)));
        } catch (Exception exception) {
            logger.error(
                    MessageUtils.createMessage(MessageType.ERROR, "Cleaning the permission cache throws an exception "
                            + ExceptionUtils.getExceptionsForMessage(exception)),
                    exception);
        }
    }

    private RestCallContext createPermissionRestCallContext(RestCallContext restCallContext,
            QueryParameterType parameterType, String parameterValue) {
        MultiValuedHashMap<String, String> queryValues = new MultiValuedHashMap<>();
        queryValues.putAll(restCallContext.getQueryValues());
        queryValues.putSingle(parameterType.getPermissionKey(), parameterValue);
        return this.restCallContextFactory.getRestCallContext(restCallContext, queryValues);
    }

    private PermissionCacheKey createPermissionCacheKey(String permissionProvider, RestCallContext restCallContext,
            QueryParameterType parameterType) {
        String domainKey = restCallContext.getDomainKey();
        String userName = restCallContext.getUserName();
        String key = parameterType.getPermissionKey();
        String value = restCallContext.getFirstQueryValue(key);

        return new PermissionCacheKey(permissionProvider, domainKey, userName, key, value);
    }

    private DataMap createStatus() {
        DataMap status = new DataHashMap();

        status.put(ResponseKey.CACHEEXPIRATIONAGE, MessageUtils.createDuration(this.cacheExpirationAge));
        status.put(ResponseKey.CACHESIZE, this.permissionCache.getSize());

        return status;
    }
}
