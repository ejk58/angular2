package nl.belastingdienst.iva.inzicht.domain.permission;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FiscalNumberUtils {

	private static final Pattern FISCALNUMBERPATTERN = Pattern.compile("^\\d{1,9}$");
	
	private FiscalNumberUtils() {
		throw new UnsupportedOperationException();
	}
	
	public static boolean isValidFiscalNumber(String fiscalNr) {
		return checkFiscalNumberIsNotEmpty(fiscalNr) && 
				checkFiscalNumberMatchesPattern(fiscalNr) && 
				checkFiscalNumberHasValidChecksum(fiscalNr);
	}
	
    public static boolean checkFiscalNumberMatchesPattern(String fiscalNr) {
        Matcher fiscalNrMatcher = FISCALNUMBERPATTERN.matcher(fiscalNr);
        return fiscalNrMatcher.matches();
    }
    
	private static boolean checkFiscalNumberIsNotEmpty(String fiscalNr) {
		return (fiscalNr != null && !fiscalNr.replaceFirst("^0+", "").isEmpty());
	}
	
	private static boolean checkFiscalNumberHasValidChecksum(String fiscalNr) {
		String nr = "000000000".substring(fiscalNr.length()) + fiscalNr;
		int multiplier = 9;
		int sum = 0;

		for (int index = 0; index < 9; index++) {
			sum = sum + Integer.parseInt(nr.substring(index, index + 1)) * (multiplier == 1 ? -1 : multiplier);
			multiplier--;
		}
		
		return (sum % 11) == 0;
	}
}
