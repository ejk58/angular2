package nl.belastingdienst.iva.inzicht.service.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainMenuGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainPathKey;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainSubjectType;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageDomain;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@Typed(DomainMapper.class)
public class DomainMapper {

    private static final String SEARCHPAGETYPE = "search";
    
	@Inject
	private PageMapper pageMapper;

	public DataMap mapToDomain(Domain domain, List<Page> pageList) {
		DataMap mappedDomain = new DataHashMap();

		mappedDomain.put(ResponseKey.DOMAINID, domain.getKey());
		mappedDomain.put(ResponseKey.NAME, domain.getName());
		mappedDomain.put(ResponseKey.ICONNAME, domain.getIconName());
		mappedDomain.put(ResponseKey.ATTRIBUTES, domain.getAttributes());
		mappedDomain.put(ResponseKey.PAGES, mapPages(pageList));
		mappedDomain.put(ResponseKey.MENUOPTIONS, mapMenuGroups(domain));
		mappedDomain.put(ResponseKey.PATHKEYS, mapPathKeys(domain));
		mappedDomain.put(ResponseKey.SUBJECTTYPES, mapSubjectTypes(domain));
		mappedDomain.put(ResponseKey.INITIALPAGEID, getInitialPageId(domain));
		mappedDomain.put(ResponseKey.INDEX, domain.getIndex());

		return mappedDomain;
	}

	public DataMap mapToMenuItem(Domain domain) {
		DataMap mappedMenuItem = new DataHashMap();

		mappedMenuItem.put(ResponseKey.DOMAINID, domain.getKey());
		mappedMenuItem.put(ResponseKey.NAME, domain.getName());
		mappedMenuItem.put(ResponseKey.ICONNAME, domain.getIconName());
		mappedMenuItem.put(ResponseKey.PATHKEYS, mapPathKeys(domain));
		mappedMenuItem.put(ResponseKey.SUBJECTTYPES, mapSubjectTypes(domain));
		mappedMenuItem.put(ResponseKey.INITIALPAGEID, getInitialPageId(domain));
		mappedMenuItem.put(ResponseKey.INDEX, domain.getIndex());

		return mappedMenuItem;
	}

	private DataMap[] mapMenuGroups(Domain domain) {
		SortedSet<Integer> menuGroupIndexSet = getMenuGroupIndexSet(domain);
		List<DataMap> mappedMenuGroups = new ArrayList<>();

		for (int menuGroupIndex : menuGroupIndexSet) {
			DataMap menuGroup = new DataHashMap();
			DomainMenuGroup domainMenuGroup = getMenuGroupByIndex(domain, menuGroupIndex);

			menuGroup.put(ResponseKey.TITLE, domainMenuGroup == null ? null : domainMenuGroup.getTitle());
			menuGroup.put(ResponseKey.ICONNAME, domainMenuGroup == null ? null : domainMenuGroup.getIconName());
			menuGroup.put(ResponseKey.OPTIONS, mapMenuItems(domain, menuGroupIndex));

			mappedMenuGroups.add(menuGroup);
		}

		return DomainUtils.inArray(mappedMenuGroups);
	}

	private DataMap[] mapMenuItems(Domain domain, int index) {
		List<PageDomain> pageDomains = domain.getPageDomains();
		List<DataMap> menuItems = new ArrayList<>();

		for (PageDomain pageDomain : pageDomains) {
			if (pageDomain.getGroupIndex() != null
					&& "main".equals(pageDomain.getPage().getType())
					&& pageDomain.getGroupIndex() == index) {
				Page page = pageDomain.getPage();
				int memberIndex = pageDomain.getMemberIndex();
				menuItems.add(this.pageMapper.mapToMenuItem(page, memberIndex));
			}
		}

		return DomainUtils.inArray(menuItems);
	}

	private DataMap mapPages(List<Page> pageList) {
		DataMap pageMap = new DataHashMap();

		for (Page page : pageList) {
			pageMap.put(page.getKey(), this.pageMapper.mapToPage(page));
		}

		return pageMap;
	}

	private DataMap[] mapPathKeys(Domain domain) {
		List<DomainPathKey> pathKeys = domain.getPathKeys();
		List<DataMap> mappedPathKeys = new ArrayList<>();

		for (DomainPathKey pathKey : pathKeys) {
			DataHashMap mappedPathKey = new DataHashMap();

			mappedPathKey.put(ResponseKey.KEY, pathKey.getKey());
			mappedPathKey.put(ResponseKey.NAME, pathKey.getName());
			mappedPathKey.put(ResponseKey.TITLE, pathKey.getTitle());
			mappedPathKey.put(ResponseKey.TYPE, pathKey.getType());
			mappedPathKey.put(ResponseKey.INDEX, pathKey.getIndex());
			mappedPathKey.put(ResponseKey.MANDATORY, pathKey.getMandatory());

			mappedPathKeys.add(mappedPathKey);
		}

		return DomainUtils.inArray(mappedPathKeys);
	}

	private DataMap[] mapSubjectTypes(Domain domain) {
		List<DomainSubjectType> subjectTypes = domain.getSubjectTypes();
		List<DataMap> mappedSubjectTypes = new ArrayList<>();

		for (DomainSubjectType subjectType : subjectTypes) {
			DataHashMap mappedSubjectType = new DataHashMap();

            mappedSubjectType.put(ResponseKey.LABEL, subjectType.getLabel());
            mappedSubjectType.put(ResponseKey.SEARCHKEY, subjectType.getSearchKey());
            mappedSubjectType.put(ResponseKey.INDEX, subjectType.getIndex());
            mappedSubjectType.put(ResponseKey.SEARCHFILTER, subjectType.getSearchFilter());

            mappedSubjectTypes.add(mappedSubjectType);
		}

		return DomainUtils.inArray(mappedSubjectTypes);
	}

	private String getInitialPageId(Domain domain) {
        List<PageDomain> pageDomainList = domain.getPageDomains();
        Optional<Page> searchPage = pageDomainList.stream()
                .map(PageDomain::getPage)
                .filter(page -> SEARCHPAGETYPE.equals(page.getType()))
                .findFirst();
        Page firstDomainPage = pageDomainList.isEmpty() ? null : pageDomainList.get(0).getPage();
        Page initialPage = searchPage.orElse(firstDomainPage); 

		return initialPage == null ? null : initialPage.getKey();
	}
	
	private SortedSet<Integer> getMenuGroupIndexSet(Domain domain) {
		SortedSet<Integer> menuGroupIndexSet = new TreeSet<>();

		List<PageDomain> pageDomains = domain.getPageDomains();
		for (PageDomain pageDomain : pageDomains) {
			if (pageDomain.getGroupIndex() != null) {
				menuGroupIndexSet.add(pageDomain.getGroupIndex());
			}
		}

		return menuGroupIndexSet;
	}

	private DomainMenuGroup getMenuGroupByIndex(Domain domain, int index) {
		List<DomainMenuGroup> domainMenuGroups = domain.getMenuGroups();

		for (DomainMenuGroup domainMenuGroup : domainMenuGroups) {
			if (domainMenuGroup.getIndex() == index) {
				return domainMenuGroup;
			}
		}

		return null;
	}
}
