package nl.belastingdienst.iva.inzicht.configuration.query;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class ValueColumnMapper implements ColumnMapper {

	private Object value;
	private String destinationKey;
	
	public ValueColumnMapper(Object value, String destinationKey) {
		this.value = value;
		this.destinationKey = destinationKey;
	}
	
	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public Object getValue(DataMap sourceDataMap) {
		return this.value;
	}
}
