package nl.belastingdienst.iva.inzicht.user;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class RoleUtils {
    public static final String INZICHT_USER_ROLE = "inzicht.user";

    private RoleUtils() {
        throw new UnsupportedOperationException();
    }
    
    public static List<Domain> getDomains(RestCallContext restCallContext) {
    	Configuration configuration = restCallContext.getConfiguration();
    	User user = restCallContext.getUser();
        Set<DomainRole> domainRoles = configuration.getApplicationRoles();
    	
        return domainRoles.stream()
        		.filter(domainRole -> RoleUtils.hasRole(user, domainRole))
        		.map(configuration::findDomainsByRole)
        		.flatMap(List::stream)
        		.distinct()
        		.collect(Collectors.toList());
    }

    public static boolean isAuthorizedUser(RestCallContext restCallContext) {
        return isAuthorizedUser(restCallContext.getUser(), restCallContext.getAuthorizedRoles());
    }
    
    public static boolean isAuthorizedUser(User user, Domain domain) {
    	return isAuthorizedUser(user, domain.getRoles());
    }
    
    public static boolean isAuthorizedUser(User user, List<DomainRole> authorizedRoles) {
    	return authorizedRoles.stream().anyMatch(authorizedRole -> hasRole(user, authorizedRole));
    }

    public static boolean isVipUser(RestCallContext restCallContext) {
        return isVipUser(restCallContext.getUser(), restCallContext.getAuthorizedRoles());
    }
    
    public static boolean isVipUser(User user, List<DomainRole> authorizedRoles) {
    	return authorizedRoles.stream().anyMatch(authorizedRole -> authorizedRole.hasVipAccess() && hasRole(user, authorizedRole));
    }
    
    public static boolean hasRole(User user, DomainRole role) {
        return (role.getRoleType() == RoleType.USER && user.hasName(role.getRole())) || 
                (role.getRoleType() == RoleType.ROLE && user.hasRole(role.getRole()));
    }
}
