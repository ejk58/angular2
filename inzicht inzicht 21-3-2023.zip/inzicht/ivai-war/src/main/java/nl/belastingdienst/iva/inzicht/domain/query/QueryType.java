package nl.belastingdienst.iva.inzicht.domain.query;

public enum QueryType {

    INTERNAL(0),
	TERADATA(1),
	DB2(2),
	REST(3);
	
	private int type;
	
	private QueryType(int type) {
		this.type = type;
	}
	
    public static QueryType findQueryType(int type) {
		for (QueryType queryType : values()) {
			if (queryType.type == type) {
				return queryType;
			}
		}
		
		return null;
	}
}
