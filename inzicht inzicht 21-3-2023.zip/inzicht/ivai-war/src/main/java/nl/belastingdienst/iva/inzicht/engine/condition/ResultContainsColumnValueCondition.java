package nl.belastingdienst.iva.inzicht.engine.condition;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class ResultContainsColumnValueCondition implements Condition {

	public static final String NAME = "ResultContainsColumnValue";
	
	private List<String> resultColumns;
	private String value;
	
	public ResultContainsColumnValueCondition(List<String> resultColumns, String value) {
		this.resultColumns = resultColumns;
		this.value = value;
	}
	
	@Override
	public boolean test(RestCallContext restCallContext) {
		Result result = restCallContext.getResult();
		List<DataMap> data = result.getData();
		
		return data.stream()
				.map(dataRow -> DomainUtils.getFromNestedMap(dataRow, this.resultColumns))
				.anyMatch(columnValue -> this.value.equals(columnValue == null ? null : columnValue.toString()));
	}

	@Override
	public String getCondition() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.resultColumns.stream().collect(Collectors.joining("/")) + 
				RulesEngineKey.PARAMETERSEPARATOR + this.value + RulesEngineKey.PARAMETEREND;
	}
}
