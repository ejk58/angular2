package nl.belastingdienst.iva.inzicht.service;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.http.HttpStatus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.ForbiddenException;
import nl.belastingdienst.iva.inzicht.domain.exception.GatewayTimeoutException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.exception.MissingTeradataViewException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotAuthorizedException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotFoundException;
import nl.belastingdienst.iva.inzicht.domain.exception.ServiceUnavailableException;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContextFactory;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;
import nl.belastingdienst.iva.inzicht.user.User;
import nl.belastingdienst.iva.inzicht.user.UserFactory;

public abstract class AbstractRestService {

	private static final int SC_MISSING_TERADATA_VIEW = 520;

	private static final Logger logger = LoggerFactory.getLogger(AbstractRestService.class);

	@Inject
	private ConfigurationFactory configurationFactory;

	@Inject
	private UserFactory userFactory;

	@Inject
	private RestCallContextFactory restCallContextFactory;

	public RestCallContext buildRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues,
			Configuration configuration, User user) {
		return this.restCallContextFactory.getRestCallContext(serviceType, queryValues, configuration, user);
	}

	public RestCallContext buildRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues) {
		Configuration configuration = this.configurationFactory.getConfiguration();
		User user = this.userFactory.getUser();
		return buildRestCallContext(serviceType, queryValues, configuration, user);
	}

	public RestCallContext buildRestCallContext(RestServiceType serviceType) {
		return buildRestCallContext(serviceType, new MultiValuedHashMap<String, String>());
	}

	public void checkRequiredRoles(RestCallContext restCallContext) {
		User user = restCallContext.getUser();
		List<DomainRole> authorizedRoles = restCallContext.getAuthorizedRoles();

		if (!RoleUtils.isAuthorizedUser(user, authorizedRoles)) {
			throw new NotAuthorizedException("The user lacks the required role to access this service.");
		}
	}

	public Response buildResponse(Status status, Object response, RestCallContext restCallContext) {
		logPerformance(restCallContext);
		return (status == Status.OK) ? Response.ok(response).build() : Response.status(status).build();
	}

	public Response buildResponse(RestCallContext restCallContext) {
		logPerformance(restCallContext);
		return restCallContext.getResponse() == null ? Response.noContent().build()
				: Response.ok(restCallContext.getResponse()).build();
	}

	public Response handleException(Throwable exception, RestCallContext restCallContext) {
		logException(restCallContext, exception, null);
		return createExceptionResponse(exception);
	}

	private void logPerformance(RestCallContext restCallContext) {
		logger.info(createPerformanceMessage(restCallContext));
	}

	public void logException(RestCallContext restCallContext, Throwable exception, String message) {
		String exceptionMessage = createExceptionMessage(restCallContext, exception, message);

		if (isExceptionForWarningMessage(exception)) {
			logger.warn(exceptionMessage);
		} else if (isExceptionForErrorMessage(exception)) {
			logger.error(exceptionMessage);
		} else {
			logger.error(exceptionMessage, exception);
		}
	}

	public Response createExceptionResponse(Throwable exception) {
		Response response;

		if (exception instanceof BadRequestException) {
			response = Response.status(HttpStatus.SC_BAD_REQUEST).build();
		} else if (exception instanceof NotAuthorizedException) {
			response = Response.status(HttpStatus.SC_UNAUTHORIZED).build();
		} else if (exception instanceof ForbiddenException) {
			response = Response.status(HttpStatus.SC_FORBIDDEN).build();
		} else if (exception instanceof NotFoundException) {
			response = Response.status(HttpStatus.SC_NOT_FOUND).build();
		} else if (exception instanceof BadGatewayException) {
			response = Response.status(HttpStatus.SC_BAD_GATEWAY).build();
		} else if (exception instanceof ServiceUnavailableException) {
			response = Response.status(HttpStatus.SC_SERVICE_UNAVAILABLE).build();
		} else if (exception instanceof GatewayTimeoutException) {
			response = Response.status(HttpStatus.SC_GATEWAY_TIMEOUT).build();
		} else if (exception instanceof MissingTeradataViewException) {
			response = Response.status(AbstractRestService.SC_MISSING_TERADATA_VIEW).build();
		} else {
			response = Response.serverError().build();
		}

		return response;
	}

	private String createPerformanceMessage(RestCallContext restCallContext) {
		return MessageType.PERFORMANCE.getLabel() + ", " +
				getServiceForMessage(restCallContext) + ", " +
                getBeginTimeForMessage(restCallContext) + ", " + 
				"processing time = " + MessageUtils.createDuration(restCallContext.getElapsedTime());
	}

	private String createExceptionMessage(RestCallContext restCallContext, Throwable exception, String message) {
		return (isExceptionForWarningMessage(exception) ? MessageType.WARNING.getLabel() : MessageType.ERROR.getLabel()) + ", " +
				"exception = " + ExceptionUtils.getExceptionsForMessage(exception) + ", " +
				"message = " + (message != null ? message : exception.getMessage()) + ", " +
				getBeginTimeForMessage(restCallContext) + ", " + 
				getServiceForMessage(restCallContext);
	}

	private String getServiceForMessage(RestCallContext restCallContext) {
		return "service = " + restCallContext.getServiceName() + ", parameters = (" + restCallContext.toString() + ")";
	}
	
	private String getBeginTimeForMessage(RestCallContext restCallContext) {
	    SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    String beginTime = dateFormatter.format(restCallContext.getBeginTime());
	    return "beginTime = " + beginTime;
	}

	protected boolean isExceptionForWarningMessage(Throwable exception) {
		return (exception instanceof NotAuthorizedException) ||
				(exception instanceof BadRequestException) ||
				(exception instanceof NotFoundException) ||
				(exception instanceof GatewayTimeoutException) ||
				(exception instanceof MissingTeradataViewException);
	}

	protected boolean isExceptionForErrorMessage(Throwable exception) {
		return (exception instanceof ForbiddenException) ||
				(exception instanceof InternalServerErrorException) ||
				(exception instanceof BadGatewayException);
	}
}
