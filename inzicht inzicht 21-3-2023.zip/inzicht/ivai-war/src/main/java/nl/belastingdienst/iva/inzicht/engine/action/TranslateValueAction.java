package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class TranslateValueAction implements Action {

	public static final String NAME = "TranslateValue";

	private String attributeGroupKey;
	private List<String> resultColumns;

	public TranslateValueAction(String attributeGroupKey, List<String> resultColumns) {
		this.attributeGroupKey = attributeGroupKey;
		this.resultColumns = resultColumns;
	}

	@Override
	public Flow execute(RestCallContext restCallContext) {
		Map<String, String> dictionary = getDictionary(restCallContext);
		Result result = restCallContext.getResult();
		List<DataMap> data = result.getData();
		
		result.setData(DomainUtils.inArray(translateData(dictionary, data)));
		restCallContext.setResult(result);
		
		return Flow.CONTINUE;
	}
	
	private Map<String, String> getDictionary(RestCallContext restCallContext) {
		Configuration configuration = restCallContext.getConfiguration();
		AttributeGroup group = configuration.getAttributeGroup(this.attributeGroupKey);
		return group == null ? Collections.<String, String>emptyMap() : group.getAttributeMap();
	}

	private List<DataMap> translateData(Map<String, String> dictionary, List<DataMap> data) {
		return data.stream().map(dataRow -> {
			Object sourceValue = DomainUtils.getFromNestedMap(dataRow, this.resultColumns);
			Object value = dictionary.containsKey(sourceValue) ? dictionary.get(sourceValue) : sourceValue;
			return value == null ? dataRow : DomainUtils.putInNestedMap(dataRow, this.resultColumns, value);
		}).collect(Collectors.toList());
	}

	@Override
	public String getAction() {
		String columns = this.resultColumns.stream().collect(Collectors.joining("/"));
		return NAME + RulesEngineKey.PARAMETERSTART + this.attributeGroupKey + RulesEngineKey.PARAMETERSEPARATOR + columns + RulesEngineKey.PARAMETEREND;
	}
}
