package nl.belastingdienst.iva.inzicht.service.subject;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotFoundException;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.service.audit.AuditTrailService;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/subject")
@RolesAllowed({ RoleUtils.INZICHT_USER_ROLE })
public class SubjectService extends AbstractRestService {

    @Inject
    private DataProvider dataprovider;
    
    @Inject
    private SubjectMapper subjectMapper;

    @Inject
    private AuditTrailService auditTrailService;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/get")
    public Response getSubject(@Context UriInfo uriInfo) {
    	MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.SUBJECTGETSERVICE, queryValues);
        
        try {
            checkRequiredRoles(restCallContext);
            retrieveSubjectForDomain(restCallContext);
            mapSingleSubjectToResponse(restCallContext);
            
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/find")
    public Response findSubject(@Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.SUBJECTFINDSERVICE, queryValues);
        
        try {
            logSubjectSearch(restCallContext);
            checkRequiredRoles(restCallContext);
            findSubjectsForDomain(restCallContext);
            mapMultipleSubjectsToResponse(restCallContext);
            
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }

    private void logSubjectSearch(RestCallContext restCallContext) {
        this.auditTrailService.logSubjectSearch(restCallContext);
    }

    private void retrieveSubjectForDomain(RestCallContext restCallContext) {
        Domain domain = restCallContext.findDomain();
        Query query = domain.getSubjectQuery();

        this.dataprovider.retrieveData(query, restCallContext);
    }
    
    private void findSubjectsForDomain(RestCallContext restCallContext) {
        Domain domain = restCallContext.findDomain();
        Query query = domain.getSearchQuery();

        this.dataprovider.retrieveData(query, restCallContext);
    }
    
    private void mapMultipleSubjectsToResponse(RestCallContext restCallContext) {
        Result result = restCallContext.getResult();
        List<DataMap> data = result.getData();
        
        SubjectResponse[] subjects = this.subjectMapper.map(data);        
        restCallContext.setResponse(subjects);
    }
    
    private void mapSingleSubjectToResponse(RestCallContext restCallContext) {
        Result result = restCallContext.getResult();
        List<DataMap> data = result.getData();
        
        if (data.size() > 1) {
            String message = "The query should only return a single subject, but it returned " + data.size() + " rows";
            throw new InternalServerErrorException(message);
        } else if (data.isEmpty() && restCallContext.hasDomainPathKeys()) {
            String message = "The subject could not be found";
            throw new NotFoundException(message);
        }
        
        SubjectResponse subject = this.subjectMapper.map(data.get(0));
        restCallContext.setResponse(subject);
    }
}
