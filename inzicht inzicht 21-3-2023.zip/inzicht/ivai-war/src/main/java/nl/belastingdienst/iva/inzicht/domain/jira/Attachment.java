package nl.belastingdienst.iva.inzicht.domain.jira;

import java.io.File;
import java.io.InputStream;

public class Attachment {

	private InputStream inputStream;
	private File file;
	private String filename;
	private String contentType;
	
	public Attachment(InputStream inputStream, String filename, String contentType) {
		this.inputStream = inputStream;
		this.filename = filename;
		this.contentType = contentType;
	}

	public Attachment(File file, String filename, String contentType) {
		this.file = file;
		this.filename = filename;
		this.contentType = contentType;
	}

	public InputStream getInputStream() {
		return inputStream;
	}
	
	public File getFile() {
		return file;
	}

	public String getFilename() {
		return filename;
	}

	public String getContentType() {
		return contentType;
	}
}
