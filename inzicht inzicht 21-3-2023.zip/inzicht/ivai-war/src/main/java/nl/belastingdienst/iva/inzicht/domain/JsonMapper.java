package nl.belastingdienst.iva.inzicht.domain;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;

import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;

public class JsonMapper {

  	private static final String ARRAYPATHELEMENT = "[0]";
  	private static final String DIVIDER = "/";

  	private final ObjectMapper jsonObjectMapper;
    private final JsonFactory jsonFactory;

    public JsonMapper() {
        this.jsonObjectMapper = new ObjectMapper();
        this.jsonFactory = new JsonFactory();
    }

    public JsonMapper(ObjectMapper objectMapper) {
        this.jsonObjectMapper = objectMapper;
        this.jsonFactory = new JsonFactory();
    }

    public DataMap[] mapToDataMapArray(String description, String object) {
    	return mapToDataMapArray(description, null, object);
    }

    public DataMap[] mapToDataMapArray(String description, String basePath, String object) {
        DataMap[] result = DomainUtils.emptyDataMapArray();

        try {
            JsonParser jsonParser = this.jsonFactory.createJsonParser(object);
            JsonNode rootNode = this.jsonObjectMapper.readTree(jsonParser);
            JsonNode dataNode = traversePath(rootNode, basePath);

	        if (dataNode.isValueNode() || dataNode.isObject()) {
	        	result = DomainUtils.inArray(this.jsonObjectMapper.readValue(dataNode, DataHashMap.class));
	        } else if (dataNode.isArray()) {
                result = this.jsonObjectMapper.readValue(dataNode, DataHashMap[].class);
            }
        } catch (IOException exception) {
        	String message = createExceptionMessage("Failed to parse the " + description, exception, object);
            throw new InternalServerErrorException(message, exception);
        }

        return result;
    }

    public <T> T mapToObject(String description, Class<T> objectClass, String object) {
        try {
            JsonParser jsonParser = this.jsonFactory.createJsonParser(object);
            JsonNode rootNode = this.jsonObjectMapper.readTree(jsonParser);
        	return this.jsonObjectMapper.readValue(rootNode, objectClass);
        } catch (IOException exception) {
        	String message = createExceptionMessage("Failed to parse an object from the " + description, exception, object);
            throw new InternalServerErrorException(message, exception);
        }
    }

    @SuppressWarnings("unchecked")
    public <T> List<T> mapToList(String description, Class<T> objectClass, String object) {
        try {
            JsonParser jsonParser = this.jsonFactory.createJsonParser(object);
            return this.jsonObjectMapper.readValue(jsonParser, List.class);
        } catch (IOException exception) {
            String message = createExceptionMessage("Failed to parse an list from the " + description, exception, object);
            throw new InternalServerErrorException(message, exception);
        }
    }

    public <T> T mapToArray(String description, Class<T> objectClass, String object) {
        try {
            JsonParser jsonParser = this.jsonFactory.createJsonParser(object);
            return this.jsonObjectMapper.readValue(jsonParser, objectClass);
        } catch (IOException exception) {
            String message = createExceptionMessage("Failed to parse an array from the " + description, exception, object);
            throw new InternalServerErrorException(message, exception);
        }
    }

    public JsonNode mapToJsonNode(String description, String basePath, String object) {
        try {
            JsonParser jsonParser = this.jsonFactory.createJsonParser(object);
            JsonNode rootNode = this.jsonObjectMapper.readTree(jsonParser);
            return traversePath(rootNode, basePath);
        } catch (IOException exception) {
        	String message = createExceptionMessage("Failed to extract a JSON-node from the " + description, exception, object);
            throw new InternalServerErrorException(message, exception);
        }
    }

    public String mapToJsonString(String description, DataMap object) {
        try {
        	return this.jsonObjectMapper.writeValueAsString(object);
        } catch (IOException exception) {
        	String message = createExceptionMessage("Failed to convert the " + description + " to a JSON-string", exception, object.toString());
        	throw new InternalServerErrorException(message);
        }
    }

    private JsonNode traversePath(JsonNode rootNode, String path) {
    	JsonNode dataNode = rootNode;

    	if (path != null && !path.isEmpty()) {
    		String[] pathElements = path.split(DIVIDER);
    		int index = 0;

    		while (!dataNode.isMissingNode() && index < pathElements.length) {
    			dataNode = ARRAYPATHELEMENT.equals(pathElements[index]) ? dataNode.path(0) : dataNode.path(pathElements[index]);
    			index++;
    		}
    	}

    	return dataNode;
    }

    private String createExceptionMessage(String description, Exception exception, Object object) {
        return description + " with exception " +
        		ExceptionUtils.getExceptionsForMessage(exception) +
                " (cause = '" + exception.getCause() +
                "', message = '" + exception.getMessage() +
                "', object = '" + object + "')";
    }
}
