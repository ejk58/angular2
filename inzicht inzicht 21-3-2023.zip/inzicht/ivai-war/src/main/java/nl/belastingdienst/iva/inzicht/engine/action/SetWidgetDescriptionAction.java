package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class SetWidgetDescriptionAction implements Action {

	public static final String NAME = "SetWidgetDescription";

	private String description;
	
	public SetWidgetDescriptionAction(String description) {
		this.description = description;
	}
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
	    Object widgetResponse = restCallContext.getResponse();
	    
	    if (widgetResponse instanceof DataMap) {
	        DataMap widgetMap = (DataMap) widgetResponse;
	        Object optionsResponse = widgetMap.get(ResponseKey.OPTIONS);
	        
	        if (optionsResponse instanceof DataMap) {
	            DataMap optionsMap = (DataMap) optionsResponse;
	            optionsMap.put(ResponseKey.DESCRIPTION, this.description);
	        }
	    }
	    
		return Flow.CONTINUE;
	}
	
	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.description + RulesEngineKey.PARAMETEREND;
	}
}
