package nl.belastingdienst.iva.inzicht.dataprovider.sql;

import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;

public class SqlQuery {

    Datasource datasource;
    String viewName;
    String query;
    List<QueryResultColumn> columns;
    
    public SqlQuery(Datasource datasource, String viewName, String query, List<QueryResultColumn> columns) {
        this.datasource = datasource;
        this.viewName = viewName;
        this.query = query;
        this.columns = columns;
    }

    public Datasource getDatasource() {
        return this.datasource;
    }

    public String getViewName() {
        return this.viewName;
    }

    public String getQuery() {
        return this.query;
    }

    public List<QueryResultColumn> getColumns() {
        return this.columns;
    }
    
    public boolean hasDatasource() {
        return this.datasource != null;
    }
}
