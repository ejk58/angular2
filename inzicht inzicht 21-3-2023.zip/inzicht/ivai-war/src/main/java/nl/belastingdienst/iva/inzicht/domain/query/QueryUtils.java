package nl.belastingdienst.iva.inzicht.domain.query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QueryUtils {

    public static final Pattern PATTERN_ANYPARAMETER = Pattern.compile("\\{\\w+?\\:[\\w\\-]+?\\}");
    public static final Pattern PATTERN_ANYFILTER = Pattern.compile("\\{\\w*?:filter\\}");
    public static final Pattern PATTERN_VIEWNAME = Pattern.compile("\\{viewName\\}");
    public static final Pattern PATTERN_RESULTCOLUMNS = Pattern.compile("\\{resultColumns\\}");
    public static final Pattern PATTERN_FILTERAREA = Pattern.compile("\\{:filter\\}");

    public static final String TOKEN_TYPESEPARATOR = ":";
	
	private QueryUtils() {
    	throw new UnsupportedOperationException();
	}

	public static List<String> splitColumnKeys(String columnKeys) {
	    return columnKeys == null ? null : Arrays.asList(columnKeys.split("/")); 
	}
	
    public static String addViewName(String query, String viewName) {
        return (query == null) ? null : QueryUtils.PATTERN_VIEWNAME.matcher(query).replaceAll(viewName);
    }
 
    public static String addResultColumns(String query, String resultColumns) {
        return (query == null) ? null : QueryUtils.PATTERN_RESULTCOLUMNS.matcher(query).replaceAll(resultColumns);
    }

    public static String addFilter(String key, String query, String filter) {
        String queryWithFilter = null;
        
        if (query != null) {
            Pattern filterPattern = (key == null) ? QueryUtils.PATTERN_FILTERAREA : Pattern.compile("\\{" + key + ":filter\\}"); 
            queryWithFilter = filterPattern.matcher(query).replaceAll(filter);
        }
        
        return queryWithFilter;
    }
    
    public static boolean detectFilter(String query) {
        return (query != null) && QueryUtils.PATTERN_ANYFILTER.matcher(query).find();
    }
	
	public static boolean validateParameterValue(String parameter, String value) {
		return validateParameterValue(extractParameterType(parameter), value);
	}

	public static boolean validateParameterValue(QueryParameterType type, String value) {
		return type.validate(value);
	}
	
	public static String extractParameterName(String parameter) {
		String param = stripParameter(parameter);
		return (param.contains(QueryUtils.TOKEN_TYPESEPARATOR) ? param.substring(0, param.indexOf(QueryUtils.TOKEN_TYPESEPARATOR)) : param);
	}
	
	public static QueryParameterType extractParameterType(String parameter) {
		String param = stripParameter(parameter);
		String type = param.contains(QueryUtils.TOKEN_TYPESEPARATOR) ? param.substring(parameter.indexOf(QueryUtils.TOKEN_TYPESEPARATOR)) : null;
		return QueryParameterType.findType(type);
	}
	
	public static List<String> extractParameterNamesFromTemplate(String template) {
		Matcher matcher = QueryUtils.PATTERN_ANYPARAMETER.matcher(template);
		List<String> parameterList = new ArrayList<>();
	
		while (matcher.find()) {
			String parameterGroup = matcher.group();
			String parameter = extractParameterName(parameterGroup);
			parameterList.add(parameter);
		}
	
		return parameterList;
	}
    
	private static String stripParameter(String parameter) {
		String param = parameter; 
		
		if (param.startsWith("{")) {
			param = param.substring(1);
		}
		
		if (param.endsWith("}")) {
			param = param.substring(0, param.length() - 1);
		}
		
		return param;
	}
}
