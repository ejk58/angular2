package nl.belastingdienst.iva.inzicht.service.feedback;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.wink.common.model.multipart.BufferedInMultiPart;
import org.apache.wink.common.model.multipart.InPart;

import nl.belastingdienst.iva.inzicht.domain.JsonMapper;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.jira.Attachment;
import nl.belastingdienst.iva.inzicht.domain.jira.Feedback;
import nl.belastingdienst.iva.inzicht.jira.JiraFeedbackClient;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/feedback")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class FeedbackService extends AbstractRestService {

	private static final String FEEDBACK_PART = "feedback";
	private static final String ATTACHMENT_PART = "attachment";

	private static final String HEADER_CONTENTDISPOSITION = "Content-Disposition";	
	private static final String HEADER_CONTENTTYPE = "Content-Type";	
	
    @Inject
    private JiraFeedbackClient jiraFeedbackClient;
    
    @Inject
    private JsonMapper jsonMapper;
    
    @POST
    @Consumes({MediaType.MULTIPART_FORM_DATA})
    public Response saveFeedback(BufferedInMultiPart bufferedMultiPartPayload) {
    	RestCallContext restCallContext = buildRestCallContext(RestServiceType.FEEDBACKSAVESERVICE);

        try {
        	List<InPart> payloadParts = bufferedMultiPartPayload.getParts();
        	Feedback feedback = getFeedbackFromPayload(payloadParts);
        	List<Attachment> attachments = getAttachmentsFromPayload(payloadParts);
	        this.jiraFeedbackClient.post(feedback, attachments, restCallContext);
        	return buildResponse(restCallContext);
        } catch (Exception exception) {
        	return handleException(exception, restCallContext);
        }
    }

    private Feedback getFeedbackFromPayload(List<InPart> payloadParts) throws IOException {
    	Feedback feedback = null;
    	
    	for (InPart payloadPart : payloadParts) {
    		if (FEEDBACK_PART.equals(payloadPart.getPartName())) {
    			String feedbackPayload = payloadPart.getBody(String.class, null);
    			feedback = this.jsonMapper.mapToObject("feedback payload", Feedback.class, feedbackPayload);
    		}
    	}
    	
    	if (feedback == null) {
    		throw new BadRequestException("The feedback is missing from the feedback rest-call.");
    	}
    	
    	return feedback;
    }
    
    private List<Attachment> getAttachmentsFromPayload(List<InPart> payloadParts) {
    	return payloadParts.stream()
  			.filter(payloadPart -> ATTACHMENT_PART.equals(payloadPart.getPartName()))
   			.map(this::mapPartToAttachment)
   			.collect(Collectors.toList());
    }
    
    private Attachment mapPartToAttachment(InPart payloadPart) {
		Map<String, String> headerValues = extractHeaderValuesFromPart(payloadPart);
		String filename = headerValues.get("filename");
		String contentType = headerValues.get("contentType");
		InputStream inputStream = payloadPart.getInputStream();
		return new Attachment(inputStream, filename, contentType);
    }
    
	private Map<String, String> extractHeaderValuesFromPart(InPart payloadPart) {
		MultivaluedMap<String, String> headers = payloadPart.getHeaders();
		Map<String, String> headerValues = new HashMap<>();

		for (String header : headers.get(HEADER_CONTENTDISPOSITION)) {
			String[] values = header.split(";");
			for (String value : values) {
				String[] keyValue = value.split("=");
				if (keyValue.length == 2) {
					headerValues.put(keyValue[0].trim(), keyValue[1].replace("\"", ""));
				}
			}
		}

		for (String header : headers.get(HEADER_CONTENTTYPE)) {
			headerValues.put("contentType", header);
		}
		
		return headerValues;
	}
}
