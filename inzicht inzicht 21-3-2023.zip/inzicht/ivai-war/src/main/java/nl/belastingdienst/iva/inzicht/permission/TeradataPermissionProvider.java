package nl.belastingdienst.iva.inzicht.permission;

import java.util.Arrays;
import java.util.List;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;
import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataClient;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataQuery;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.domain.permission.FiscalNumberUtils;
import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Typed(TeradataPermissionProvider.class)
public class TeradataPermissionProvider implements PermissionProvider {

    private static final String SQLQUERY = "SELECT IS_VIP as vip FROM {teradataSchema:config}.{viewName} WHERE finr = {fiscalNr:fiscalnumber}";
    private static final String VIEWNAME = "INZICHT_FINRS";
    private static final String VIPCOLUMN = "vip"; 
    private static final Integer VIPINDICATOR = 1; 

    private static final Permission PERMISSION_FULLACCESS = new Permission(true);
    private static final Permission PERMISSION_NOVIP = new Permission(false, Arrays.asList("VIP"));

    @Inject
    private TeradataClient teradataClient;

    @Override
    public Permission getPermission(RestCallContext restCallContext, String key) {
    	Permission permission = PERMISSION_FULLACCESS;

    	if (isFiscalNumber(restCallContext, key)) {    			
	    	boolean restrictedSubject = isVip(restCallContext);
	    	boolean userAccess = RoleUtils.isVipUser(restCallContext) || !restrictedSubject;
	    	permission = userAccess ? PERMISSION_FULLACCESS : PERMISSION_NOVIP;
    	}

    	return permission;
    }
    
    private boolean isFiscalNumber(RestCallContext restCallContext, String key) {
        if (QueryValueKey.FISCALNR.equals(key)) {
            MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
            String fiscalNumber = queryValues.getFirst(key);
            return fiscalNumber != null && FiscalNumberUtils.checkFiscalNumberMatchesPattern(fiscalNumber);
        }
        
        return false;
    }
    
    private boolean isVip(RestCallContext restCallContext) {
    	MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        Configuration configuration = restCallContext.getConfiguration();
    	QueryInterface query = getVipQuery();
        List<DataMap> data = this.teradataClient.retrieveDataAsMultiMap(query, configuration, queryValues);
        
        if (data.size() > 1) {
            String fiscalNr = queryValues.getFirst(QueryValueKey.FISCALNR); 
            String message = "The Teradata permission provider could not determine the permission, because the permission-query for fiscal number " + fiscalNr + 
                    " returned multiple (" + data.size() + ") rows!";
            throw new IllegalStateException(message);
        }
        
        return data.isEmpty() || VIPINDICATOR.equals(data.get(0).get(VIPCOLUMN));
    }
    
    private QueryInterface getVipQuery() {
        return new TeradataQuery(VIEWNAME, SQLQUERY);
    }
}
