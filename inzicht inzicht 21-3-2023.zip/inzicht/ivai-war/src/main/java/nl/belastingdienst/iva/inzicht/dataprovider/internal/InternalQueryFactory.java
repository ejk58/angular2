package nl.belastingdienst.iva.inzicht.dataprovider.internal;

import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.dataprovider.AbstractQueryFactory;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;

public class InternalQueryFactory extends AbstractQueryFactory {
 
    public String getInternalQuery(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        String internalQuery = query.getQueryTemplate();
        internalQuery = addResultColumns(internalQuery, query);
        internalQuery = addFilters(internalQuery, query, queryValues);
        return replaceParameters(internalQuery, queryValues); 
    }
    
    @Override
    protected String prepareValue(Datasource datasource, QueryParameterType type, String value) {
        String result = value;

        if (type == QueryParameterType.STRING || type == QueryParameterType.DATE || type == QueryParameterType.LISTOFSTRINGS) {
            result =  "'" + value + "'";
        } else if (type == QueryParameterType.FILTER) {
            result = " " + value;
        }
        
        return result;
    }
    
    private String addResultColumns(String internalQuery, QueryInterface query) {
        List<QueryResultColumn> resultColumns = mapColumns(query.getQueryColumns());
        String columns = resultColumns.stream().map(QueryResultColumn::getName).collect(Collectors.joining(" "));
        return QueryUtils.addResultColumns(internalQuery, columns);
    }
}
