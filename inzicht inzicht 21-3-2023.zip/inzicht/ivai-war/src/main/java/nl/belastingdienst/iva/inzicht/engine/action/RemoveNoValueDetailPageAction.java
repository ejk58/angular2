package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class RemoveNoValueDetailPageAction implements Action {

	public static final String NAME = "RemoveNoValueDetailPage";

	private List<String> resultColumns;

	public RemoveNoValueDetailPageAction(List<String> resultColumns) {
		this.resultColumns = resultColumns;
	}

	@Override
	public Flow execute(RestCallContext restCallContext) {
		Result result = restCallContext.getResult();
		List<DataMap> data = result.getData();
		result.setData(DomainUtils.inArray(mapData(data)));
		restCallContext.setResult(result);
		
		return Flow.CONTINUE;
	}
	
	private List<DataMap> mapData(List<DataMap> data) {
		return data.stream().map(dataRow -> {
			Object drilldownRowValue = DomainUtils.getFromNestedMap(dataRow, this.resultColumns);

			if (drilldownRowValue instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, ?> drilldownRowMap = (Map<String, ?>) drilldownRowValue;
				
				if (drilldownRowMap.get("value") == null) {
					drilldownRowMap.put("detail", null);
				}
			}
			return dataRow;
		}).collect(Collectors.toList());
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.resultColumns.stream().collect(Collectors.joining("/")) + RulesEngineKey.PARAMETEREND;
	}

}
