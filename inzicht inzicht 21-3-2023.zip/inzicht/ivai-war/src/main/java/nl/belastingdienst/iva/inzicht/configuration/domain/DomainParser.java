package nl.belastingdienst.iva.inzicht.configuration.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;

public class DomainParser {

	private List<Domain> domainList;
    private Map<String, Domain> domainMap;
    private Map<DomainRole, List<Domain>> domainsPerRoleMap;

    public DomainParser(List<Domain> domainList) {
        List<Domain> domains = new ArrayList<>(domainList);
        linkDomains(domains);

        setDomainList(domains);
        createDomainMap(domains);
        createDomainsPerRole(domains);
    }

    public List<Domain> getDomainList() {
    	return this.domainList;
    }

    public Map<String, Domain> getDomainMap() {
    	return this.domainMap;
    }

    public Map<DomainRole, List<Domain>> getDomainsPerRole() {
    	return this.domainsPerRoleMap;
    }

    public List<String> getDomainKeyList() {
    	return new ArrayList<>(this.domainMap.keySet());
    }

    private void setDomainList(List<Domain> domainList) {
    	this.domainList = domainList;
    }

    private void createDomainMap(List<Domain> domainList) {
        this.domainMap = new LinkedHashMap<>();

        for (Domain domain : domainList) {
            String domainKey = domain.getKey().toLowerCase();
            this.domainMap.put(domainKey, domain);
        }
    }

    private void createDomainsPerRole(List<Domain> domainList) {
        this.domainsPerRoleMap = new HashMap<>();

        for (Domain domain : domainList) {
            List<DomainRole> roles = domain.getRoles();

            for (DomainRole role : roles) {
                if (!this.domainsPerRoleMap.containsKey(role)) {
                    this.domainsPerRoleMap.put(role, new ArrayList<>());
                }

                this.domainsPerRoleMap.get(role).add(domain);
            }
        }
    }

    private List<Domain> linkDomains(List<Domain> domains) {
        for (Domain domain : domains) {
        	domain.linkDomain();
        }

        return domains;
    }
}
