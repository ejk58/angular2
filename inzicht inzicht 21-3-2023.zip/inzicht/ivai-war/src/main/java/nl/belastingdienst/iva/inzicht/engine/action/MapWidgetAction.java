package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.domain.widget.WidgetMapper;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class MapWidgetAction implements Action {

	public static final String NAME = "MapWidget";
	
	private WidgetMapper widgetMapper;
	
	public MapWidgetAction(WidgetMapper widgetMapper) {
	    this.widgetMapper = widgetMapper;
	}
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
        Widget widget = restCallContext.findWidget();
	    Result result = restCallContext.getResult();
	    DataMap response = this.widgetMapper.map(widget, result);
	    restCallContext.setResponse(response);
		return Flow.CONTINUE;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + RulesEngineKey.PARAMETEREND;
	}
}
