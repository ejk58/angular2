package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class ConcatValuesAction implements Action {

	public static final String NAME = "ConcatValues";

	private List<List<String>> resultColumnsList;

	public ConcatValuesAction(List<List<String>> resultColumnsList) {
		this.resultColumnsList = resultColumnsList;
	}

	@Override
	public Flow execute(RestCallContext restCallContext) {
		Result result = restCallContext.getResult();
		List<DataMap> data = result.getData();
		
		result.setData(DomainUtils.inArray(concatData(data)));
		restCallContext.setResult(result);
		
		return Flow.CONTINUE;
	}
	
	private List<DataMap> concatData(List<DataMap> data) {
		return data.stream().map(dataRow -> {
			StringBuilder valueBuilder = new StringBuilder();
			
			for (int index = 0; index < this.resultColumnsList.size(); index++) {
				List<String> resultColumns = this.resultColumnsList.get(index);
				Object value = DomainUtils.getFromNestedMap(dataRow, resultColumns);
				valueBuilder.append(value == null ? "" : value.toString());
			}

			DomainUtils.putInNestedMap(dataRow, this.resultColumnsList.get(0), valueBuilder.toString());
			return dataRow;
		}).collect(Collectors.toList());
	}

	@Override
	public String getAction() {
		StringBuilder columnsBuilder = new StringBuilder();
		for (int index = 0; index < this.resultColumnsList.size(); index++) {
			columnsBuilder.append(columnsBuilder.length() > 0 ? RulesEngineKey.PARAMETERSEPARATOR : "");
			columnsBuilder.append(this.resultColumnsList.get(index).stream().collect(Collectors.joining("/")));
		}
		
		return NAME + RulesEngineKey.PARAMETERSTART + columnsBuilder.toString() + RulesEngineKey.PARAMETEREND;
	}
}
