package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class FindPageKeyByTitleAction implements Action {

	public static final String NAME = "FindPageKeyByTitle";

	private List<String> sourceColumns;
	private List<String> resultColumns;

	public FindPageKeyByTitleAction(List<String> sourceColumns, List<String> resultColumns) {
		this.sourceColumns = sourceColumns;
		this.resultColumns = resultColumns;
	}

	@Override
	public Flow execute(RestCallContext restCallContext) {
		Map<String, String> dictionary = getDictionary(restCallContext);
		Result result = restCallContext.getResult();		
		List<DataMap> data = result.getData();
		result.setData(DomainUtils.inArray(translateData(dictionary, data)));
		restCallContext.setResult(result);
		return Flow.CONTINUE;
	}
	
	private Map<String, String> getDictionary(RestCallContext restCallContext) {
		Configuration configuration = restCallContext.getConfiguration();
		String domainKey = restCallContext.getDomainKey();
		List<Page> pageList = configuration.findPagesByDomain(domainKey);
		return pageList.stream()
				.filter(page -> "main".equals(page.getType()))
				.collect(Collectors.toMap(page -> page.getTitle().toLowerCase(), page -> page.getKey()));
	}

	private List<DataMap> translateData(Map<String, String> dictionary, List<DataMap> data) {
		return data.stream().map(dataRow -> {
			Object sourceValue = DomainUtils.getFromNestedMap(dataRow, this.sourceColumns);
			if (sourceValue instanceof String) {
				String sourceKey = (String) sourceValue;
				Object value = dictionary.get(sourceKey.toLowerCase());
				return value == null ? dataRow : DomainUtils.putInNestedMap(dataRow, this.resultColumns, value);
			}
			return dataRow;
		}).collect(Collectors.toList());
	}

	@Override
	public String getAction() {
		String sourceColumnDescription = this.sourceColumns.stream().collect(Collectors.joining("/"));
		String resultColumnDescription = this.resultColumns.stream().collect(Collectors.joining("/"));
		return NAME + RulesEngineKey.PARAMETERSTART + sourceColumnDescription + RulesEngineKey.PARAMETERSEPARATOR + resultColumnDescription + RulesEngineKey.PARAMETEREND;
	}
}
