package nl.belastingdienst.iva.inzicht.engine.condition;

import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public interface Condition {

	boolean test(RestCallContext restCallContext);
	String getCondition();
}
