package nl.belastingdienst.iva.inzicht.configuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.datasource.HttpDatasource;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;

public class DefaultConfiguration implements Configuration {

    private Map<String, Object> keyValueMap;
    
    private Map<String, AttributeGroup> attributeGroupMap;
    private Map<String, RuleGroup> ruleGroupMap;

    private List<Domain> domainList;
    private Map<String, Domain> domainMap;
    private Map<DomainRole, List<Domain>> domainsByRoleMap;

    private Map<String, Page> pageMap;
    private Map<String, List<Page>> pagesByDomainMap;

    private Map<String, Widget> widgetMap;
    
    private DataHashMap configurationDetails;
    private HttpDatasource teradataDatasource;
    private HttpDatasource mihProxyDatasource;
    private HttpDatasource jiraFeedbackDatasource;

    public DefaultConfiguration() {
        this.keyValueMap = new HashMap<>();
        this.configurationDetails = new DataHashMap();
        
        this.keyValueMap.put(ConfigurationKey.CONFIGURATIONDETAILS, this.configurationDetails);
    }

    @Override
    public Set<DomainRole> getApplicationRoles() {
        return this.domainsByRoleMap.keySet();
    }

    @Override
    public Map<String, Object> getKeyValueMap() {
        return Collections.unmodifiableMap(this.keyValueMap);
    }

    @Override
    public Map<String, AttributeGroup> getAttributeGroupMap() {
        return Collections.unmodifiableMap(this.attributeGroupMap);
    }

    @Override
    public AttributeGroup getAttributeGroup(String attributeGroupKey) {
        return this.attributeGroupMap.get(attributeGroupKey);
    }

    @Override
    public Map<String, RuleGroup> getRuleGroupMap() {
        return Collections.unmodifiableMap(this.ruleGroupMap);
    }

    @Override
    public RuleGroup getRuleGroup(String ruleGroupKey) {
        return this.ruleGroupMap.get(ruleGroupKey);
    }

    @Override
    public Object getValue(String key) {
        return this.keyValueMap.get(key);
    }

    @Override
    public String getValueAsString(String key) {
        Object value = this.keyValueMap.get(key);
        return value == null ? null : value.toString();
    }

    @Override
    public Integer getValueAsNumber(String key) {
        Object value = this.keyValueMap.get(key);
        Integer result = null;

        if (value != null) {
        	result = value instanceof Integer ? (Integer) value : Integer.parseInt(value.toString());
        }

        return result;
    }

    @Override
    public Boolean getValueAsBoolean(String key) {
        Object value = this.keyValueMap.get(key);
        return value == null ? null : DomainUtils.isTrue(value.toString()); 
    }

    @Override
    public List<Domain> getDomains() {
    	return this.domainList;
    }
    
    @Override
    public Domain findDomain(String domainKey) {
        return this.domainMap.get(domainKey);
    }

    @Override
    public List<Domain> findDomainsByRole(DomainRole role) {
        return this.domainsByRoleMap.get(role);
    }

    @Override
    public Page findPage(String pageKey) {
        return this.pageMap.get(pageKey);
    }

    @Override
    public List<Page> findPagesByDomain(String domainKey) {
        return this.pagesByDomainMap.get(domainKey);
    }

    @Override
    public Widget findWidget(String widgetName) {
        return this.widgetMap.get(widgetName);
    }
    
    @Override
    public HttpDatasource getTeradataDatasource() {
        return this.teradataDatasource;
    }
    
    @Override
    public HttpDatasource getMihProxyDatasource() {
        return this.mihProxyDatasource;
    }
    
    @Override
    public HttpDatasource getJiraFeedbackDatasource() {
    	return this.jiraFeedbackDatasource;
    }
    
    public Map<String, Widget> getWidgetMap() {
    	return this.widgetMap == null ? Collections.<String, Widget>emptyMap() : this.widgetMap;
    }

    @Override
    public String toString() {
        List<String> keyList = new ArrayList<>(this.keyValueMap.keySet());
        return keyList.stream().sorted().map(key -> key + " = " + keyValueMap.get(key)).collect(Collectors.joining(", "));
    }

    void setValues(Map<String, ? extends Object> values) {
        this.keyValueMap.putAll(values);
    }
    
    void setValue(String key, Object value) {
        this.keyValueMap.put(key, value);
    }
    
    void setDefaultValue(String key, Object value) {
        if (!this.keyValueMap.containsKey(key)) {
            this.keyValueMap.put(key, value);
        }
    }

    void setAttributeGroupMap(Map<String, AttributeGroup> attributeGroupMap) {
    	this.attributeGroupMap = attributeGroupMap;
    }
    
    void setRuleGroupMap(Map<String, RuleGroup> ruleGroupMap) {
    	this.ruleGroupMap = ruleGroupMap;
    }
    
    void setDomainList(List<Domain> domainList) {
        this.domainList = domainList;
    }

    void setDomainMap(Map<String, Domain> domainMap) {
        this.domainMap = domainMap;
    }

    void setDomainsByRoleMap(Map<DomainRole, List<Domain>> domainsByRoleMap) {
        this.domainsByRoleMap = domainsByRoleMap;
    }

    void setPageMap(Map<String, Page> pageMap) {
        this.pageMap = pageMap;
    }

    void setPagesByDomainMap(Map<String, List<Page>> pagesByDomainMap) {
        this.pagesByDomainMap = pagesByDomainMap;
    }

    void setWidgetMap(Map<String, Widget> widgetMap) {
        this.widgetMap = widgetMap;
    }
    
    void setTeradataDatasource(HttpDatasource teradataDatasource) {
        this.teradataDatasource = teradataDatasource;
    }
    
    void setMihProxyDatasource(HttpDatasource mihProxyDatasource) {
        this.mihProxyDatasource = mihProxyDatasource;
    }
    
    void setJiraFeedbackDatasource(HttpDatasource jiraFeedbackDatasource) {
    	this.jiraFeedbackDatasource = jiraFeedbackDatasource;
    }
    
    void addConfigurationDetails(String key, Object value) {
        this.configurationDetails.put(key, value);
    }
}
