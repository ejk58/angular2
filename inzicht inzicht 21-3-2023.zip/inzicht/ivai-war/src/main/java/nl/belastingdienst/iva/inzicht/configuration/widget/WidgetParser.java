package nl.belastingdienst.iva.inzicht.configuration.widget;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageAttribute;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.WidgetAttribute;
import nl.belastingdienst.iva.inzicht.domain.JsonMapper;

public class WidgetParser {

    private JsonMapper jsonMapper;
    
    private List<Widget> widgetList;
    private Map<String, Widget> widgetMap;

    public WidgetParser(List<Widget> widgetList, List<Page> pageList) {
        this.jsonMapper = new JsonMapper();
        buildWidgetListAndMap(widgetList, pageList);
    }

    public WidgetParser(List<Widget> widgetList, List<Page> pageList, JsonMapper jsonMapper) {
        this.jsonMapper = jsonMapper;
        buildWidgetListAndMap(widgetList, pageList);
    }

    public Map<String, Widget> getWidgetMap() {
        return this.widgetMap;
    }

    private void buildWidgetListAndMap(List<Widget> widgetList, List<Page> pageList) {
        this.widgetList = new ArrayList<>();
        this.widgetMap = new HashMap<>();

        for (Widget widget : widgetList) {
            buildWidgetListAndMap(widget);
        }
        
        for (Widget widget : this.widgetList) {
            linkWidgetFromWidgetAttributeToDomains(widget);
        }
        
        for (Page page : pageList) {
            linkWidgetFromPageAttributeToDomains(page);
        }
    }
    
    private void buildWidgetListAndMap(Widget widget) {
        if (!this.widgetMap.containsKey(widget.getName())) {
            this.widgetList.add(widget);
            this.widgetMap.put(widget.getName(), widget);
            
            for (Widget innerWidget : widget.getWidgetList()) {
                buildWidgetListAndMap(innerWidget);
            }
        }
    }
    
    private void linkWidgetFromWidgetAttributeToDomains(Widget widget) {
        for (WidgetAttribute widgetAttribute : widget.getAttributeList()) {
            String attributeKey = widgetAttribute.getKey();
            
            if (attributeKey.endsWith("Widget")) {
                String widgetName = widgetAttribute.getValue();
                connectInnerWidgetByName(widget, widgetName);
            }
            
            if (attributeKey.endsWith("Widgets")) {
                String attributeDescription = "widget attribute " + attributeKey;
                String attributeValue = widgetAttribute.getValue();
                List<String> widgetNames = this.jsonMapper.mapToList(attributeDescription, String.class, attributeValue);

                for (String widgetName : widgetNames) {
                    connectInnerWidgetByName(widget, widgetName);
                }
            }
        }
    }
    
    private void linkWidgetFromPageAttributeToDomains(Page page) {
        for (PageAttribute pageAttribute : page.getAttributeList()) {
            String attributeKey = pageAttribute.getKey();
            
            if (attributeKey.endsWith("Widget")) {
                String widgetName = pageAttribute.getValue();
                Widget innerWidget = this.widgetMap.get(widgetName);
                
                if (innerWidget != null) {
                    List<Domain> linkedDomains = page.getLinkedDomains();
                    linkedDomains.forEach(innerWidget::linkDomain);
                }
            }
        }
    }
    
    private void connectInnerWidgetByName(Widget widget, String innerWidgetName) {
        Widget innerWidget = this.widgetMap.get(innerWidgetName);
        
        if (innerWidget != null) {
            List<Domain> linkedDomains = widget.getLinkedDomains();
            linkedDomains.forEach(innerWidget::linkDomain);
        }
    }
}
