package nl.belastingdienst.iva.inzicht.database.configuration.query;

import javax.persistence.*;

import org.codehaus.jackson.annotate.JsonIgnore;

@Entity
@Table(name = "CONF_QUERY_ATTRIBUTE")
public class QueryAttribute {

    @Id
    private int id;

    private String key;
    private String value;

    @JsonIgnore
    public int getId() {
        return this.id;
    }

    public String getKey() {
		return this.key;
	}

	public String getValue() {
		return this.value;
	}
	
	public boolean hasKey(String key) {
		return this.key.equals(key);
	}
}
