package nl.belastingdienst.iva.inzicht.domain.jira;

public enum IssueType {
	STORY("10001"),
	PROBLEM("10100"),
	SUBTASK("10101"),
	IMPROVEMENT("10102"),
	TASK("10103"),
	CUSTOMER_REQUEST("10104"),
	WORKORDER("10105"),
	BUG("10106"),
	INCIDENT("10107");
	
	private String id;
	
	private IssueType(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

}
