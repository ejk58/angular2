package nl.belastingdienst.iva.inzicht.domain.query;

import java.util.List;

import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryFilter;
import nl.belastingdienst.iva.inzicht.database.configuration.query.ResultMapper;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;

public class ModifiableQuery implements QueryInterface {

    private QueryInterface query;
    private String queryTemplate;
    
    public ModifiableQuery(QueryInterface query) {
        this.query = query;
    }
    
    @Override
    public QueryType getType() {
        return this.query.getType();
    }

    @Override
    public String getViewName() {
        return this.query.getViewName();
    }

    @Override
    public String getQueryTemplate() {
        return this.queryTemplate == null ? this.query.getQueryTemplate() : this.queryTemplate;
    }

    @Override
    public String getKey() {
        return this.query.getKey();
    }

    @Override
    public List<QueryParameter> getQueryParameters() {
        return this.query.getQueryParameters();
    }

    @Override
    public List<QueryColumn> getQueryColumns() {
        return this.query.getQueryColumns();
    }
    
    @Override
    public List<QueryFilter> getQueryFilters() {
        return this.query.getQueryFilters();
    }
    
    @Override
    public Datasource getDatasource() {
        return this.query.getDatasource();
    }
    
    @Override
    public VipColumn getVipColumn() {
        return this.query.getVipColumn();
    }
    
    @Override
    public List<List<String>> getMaskableColumnKeysList() {
        return this.query.getMaskableColumnKeysList();
    }
    
    @Override
    public ResultMapper getResultMapper() {
        return this.query.getResultMapper();
    }
    
    @Override
    public String getErrorMessage() {
        return this.query.getErrorMessage();
    }
    
    @Override
    public boolean hasDatasource() {
        return this.query.hasDatasource();
    }
    
    public void setQueryTemplate(String queryTemplate) {
        this.queryTemplate = queryTemplate;
    }
    
    @Override
    public int hashCode() {
        return this.query.hashCode();
    }

    @Override
    public boolean equals(Object object) {
        return this.query.equals(object);
    }
}
