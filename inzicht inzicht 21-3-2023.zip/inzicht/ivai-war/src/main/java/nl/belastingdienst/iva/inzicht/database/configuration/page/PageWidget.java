package nl.belastingdienst.iva.inzicht.database.configuration.page;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;

@Entity
@Table(name = "CONF_PAGE_WIDGET")
public class PageWidget {

    @Id
    private Integer id;

    @Column(name = "GRID_COLUMNS")
    private Integer gridColumns;

    @Column(name = "ROW_INDEX")
    private Integer rowIndex;

    @Column(name = "COLUMN_INDEX")
    private Integer columnIndex;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PAGE_ID")
    private Page page;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "WIDGET_ID")
    private Widget widget;

    public Integer getId() {
        return id;
    }

    public Page getPage() {
        return page;
    }

    public Widget getWidget() {
        return widget;
    }

    public Integer getGridColumns() {
        return gridColumns;
    }

    public Integer getColumnIndex() {
        return columnIndex;
    }

    public Integer getRowIndex() {
        return rowIndex;
    }
}
