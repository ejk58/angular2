package nl.belastingdienst.iva.inzicht.releasenote;

import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.releasenote.ReleaseNote;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class ReleaseNoteFactory {

    private static final Logger logger = LoggerFactory.getLogger(ReleaseNoteFactory.class);

    @Inject
    private ConfigurationFactory configurationFactory;

	@Inject
	private ReleaseNoteProvider releaseNoteProvider;

	private List<ReleaseNote> releaseNotes;

	public ReleaseNoteFactory() {
		createEmptyReleaseNotes();
	}

    @PostConstruct
    public void initialize() {
        loadNewReleaseNotes();
    }

    @Schedule(minute = "*/30", hour = "*", persistent = false)
    public void update() {
    	loadNewReleaseNotes();
    }

    public List<ReleaseNote> getReleaseNotes() {
        return this.releaseNotes;
    }

    public DataMap getStatus() {
        return createStatus();
    }

    private void createEmptyReleaseNotes() {
    	this.releaseNotes = Collections.emptyList();
    }

    private void loadNewReleaseNotes() {
        logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Starting the update of the release notes cache."));
        long startTime = System.currentTimeMillis();

    	try {
    		Configuration configuration = this.configurationFactory.getConfiguration();
    		this.releaseNotes = getReleaseNotes(configuration);

            logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Updated the release notes cache in " +
                    MessageUtils.createDuration(System.currentTimeMillis() - startTime)));
    	} catch (Exception exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Refreshing the release notes throws an exception " +
                    ExceptionUtils.getExceptionsForMessage(exception)), exception);
    	}
    }

    private List<ReleaseNote> getReleaseNotes(Configuration configuration) {
    	return this.releaseNoteProvider.retrieveReleaseNotes(configuration);
    }

    private DataMap createStatus() {
        DataMap status = new DataHashMap();

        status.put(ResponseKey.CACHESIZE, this.releaseNotes.size());

        return status;
    }
}
