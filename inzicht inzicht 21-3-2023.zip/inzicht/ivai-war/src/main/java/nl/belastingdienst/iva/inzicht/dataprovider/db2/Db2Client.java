package nl.belastingdienst.iva.inzicht.dataprovider.db2;

import java.util.List;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.dataprovider.DataProviderClient;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.dataprovider.sql.SqlQuery;
import nl.belastingdienst.iva.inzicht.dataprovider.sql.SqlQueryFactory;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@Typed(Db2Client.class)
public class Db2Client implements DataProviderClient {

    @Inject
    private SqlQueryFactory sqlQueryFactory;
    
    @PersistenceContext(unitName = "ivai-pu-inzicht")
    private EntityManager entityManager;
    
    @Override
    public Result retrieveData(QueryInterface query, RestCallContext restCallContext) {
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        SqlQuery sqlQuery = this.sqlQueryFactory.getSqlQuery(query, queryValues);
        
        try {
        	List<?> data = executeQuery(sqlQuery.getQuery());
            return new Result(convertToDataMap(sqlQuery, data));
        } catch (Exception exception) {
            String message = "Failed to run a query on DB2 with exception " + ExceptionUtils.getExceptionsForMessage(exception) + 
                    " (cause = '" + exception.getCause() + "', message = '" + exception.getMessage() + "', query = '" + sqlQuery.getQuery() + "')";
            throw new InternalServerErrorException(message, exception);
        }
    }
 
	private List<?> executeQuery(String databaseQuery) {
    	Query db2Query = this.entityManager.createNativeQuery(databaseQuery);
		return db2Query.getResultList();
    }
    
    private DataMap[] convertToDataMap(SqlQuery sqlQuery, List<?> data) {
    	DataMap[] result = new DataMap[data.size()];
    	List<QueryResultColumn> queryColumns = sqlQuery.getColumns();
    	
    	for (int rowIndex = 0; rowIndex < data.size(); rowIndex++) {
    	    Object dataRow = data.get(rowIndex);
            DataMap resultRow = new DataHashMap();

    	    if (dataRow instanceof Object[]) {
        		Object[] dataObjects = (Object[]) dataRow;

        		for (int index = 0; index < queryColumns.size(); index++) {
        			String key = queryColumns.get(index).getName();
        			Object value = dataObjects[index];
        			resultRow.put(key, value);
        		}
    	    } else {
    	        resultRow.put(queryColumns.get(0).getName(), dataRow);
    	    }

    		result[rowIndex] = resultRow;
    	}

    	return result;
    }
}
