package nl.belastingdienst.iva.inzicht.domain.query;

public class QueryParameter {

    private String name;
    private QueryParameterType type;
    private boolean required;

    public QueryParameter() {
        // Necessary for JSON parsing
    }

    public QueryParameter(String name, QueryParameterType type, boolean required) {
        this.name = name;
        this.type = type;
        this.required = required;
    }

    public String getName() {
        return this.name;
    }

    public QueryParameterType getType() {
        return this.type;
    }

    public boolean isRequired() {
        return this.required;
    }

    // Setters are necessary for JSON parsing
    public void setName(String name) {
      this.name = name;
    }
    public void setType(QueryParameterType type) {
      this.type = type;
    }
    public void setRequired(boolean required) {
      this.required = required;
    }
}
