package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.User;

public class DefaultRestCallContext extends EngineRestCallContext {

    private User user;
    private List<DomainRole> authorizedRoles;
    
    public DefaultRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration, User user, 
            List<DomainRole> authorizedRoles, long beginTime) {
    	super(serviceType, queryValues, configuration, beginTime);
        
        this.user = user;
        this.authorizedRoles = authorizedRoles;

        setUserName(user == null ? DomainUtils.UNKNOWN_ITEM : user.getName());
    }

    @Override
    public User getUser() {
        return this.user;
    }
    
    @Override
    public List<DomainRole> getAuthorizedRoles() {
        return this.authorizedRoles;
    }
    
    private void setUserName(String userName) {
    	addQueryValue(QueryValueKey.USERNAME, userName);
    }
}
