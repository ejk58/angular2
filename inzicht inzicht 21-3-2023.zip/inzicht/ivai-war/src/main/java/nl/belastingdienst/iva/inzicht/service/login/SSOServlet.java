package nl.belastingdienst.iva.inzicht.service.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;
import nl.belastingdienst.iva.inzicht.user.User;
import nl.belastingdienst.iva.inzicht.user.UserFactory;

public class SSOServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final Logger logger = LoggerFactory.getLogger(SSOServlet.class);

    @Inject
    private UserFactory userFactory;

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        StringBuilder jsonReturn = new StringBuilder();
        String username = request.getUserPrincipal().getName();

        jsonReturn.append("{\"role\":[");
        if (request.isUserInRole(RoleUtils.INZICHT_USER_ROLE)) {
            jsonReturn.append("\"");
            jsonReturn.append(RoleUtils.INZICHT_USER_ROLE);
            jsonReturn.append("\"");
        }
        jsonReturn.append("]");

        if (request.getUserPrincipal() != null) {
            jsonReturn.append(",\"username\":\"");
            jsonReturn.append(username);
            jsonReturn.append("\"");
        }

        jsonReturn.append("}");

        try {
            PrintWriter writer = response.getWriter();
            writer.write(jsonReturn.toString());
        } catch (IOException exception) {
            logger.error("Error occured while getting writer to the response", exception);
        }

        logger.info(createLoginMessage(username));
    }

    public String createLoginMessage(String name) {
        try {
            User user = this.userFactory.getUser();
            String username = user.getName();
            String roles = MessageUtils.createRoles(user);

            return MessageUtils.createMessage(MessageType.MESSAGE,
                    "User '" + username + "' logged in with single-sign-on, roles = [" + roles + "].");
        } catch (InternalServerErrorException exception) {
            return MessageUtils.createMessage(MessageType.MESSAGE,
                    "User '" + name + "' logged in with single-sign-on (but could not access user credentials).");
        }
    }
}
