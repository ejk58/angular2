package nl.belastingdienst.iva.inzicht.domain.key;

public class DatasourceKey {

    public static final String RESTURL = "restUrl";
    public static final String CREDENTIALSHEADER = "credentialsHeader";
    public static final String ACCEPTHEADER = "acceptHeader";
    public static final String CONTENTTYPEHEADER = "contentTypeHeader";
    public static final String WSAADDRESSHEADER = "wsaAddressHeader";
    public static final String TRUSTALLCERTIFICATES = "trustAllCertificates";
    public static final String COOKIENAME = "cookieName";
    public static final String ENCODINGCHARSET = "encodingCharset";
    public static final String ZEROPADDEDFISCALNUMBER = "zeroPaddedFiscalNumber";

    public static final String JDBCURL = "jdbcUrl";
    public static final String JDBCDRIVERCLASSNAME = "jdbcDriverClassName";

    public static final String CREDENTIALMAPPING = "credentialMappingJAAS";
    public static final String CREDENTIALNAME = "credentialName";
    public static final String CREDENTIALVALUE = "credentialValue";

    public static final String CREDENTIALSPOOLSIZE = "credentialsPoolSize";
    public static final String CREDENTIALSTYPE = "credentialsType";
    public static final String CREDENTIALSENCODING = "credentialsEncoding";

    public static final String TERADATASCHEMA = "teradataSchema";

    public static final String CONNECTTIMEOUT = "connectTimeout";
    public static final String READTIMEOUT = "readTimeout";
    public static final String REQUESTTIMEOUT = "requestTimeout";
    public static final String SLOWEXECUTIONTIME = "slowQueryThreshold";
    public static final String RETRYONTIMEOUT = "retryOnTimeout";

    private DatasourceKey() {
        throw new UnsupportedOperationException();
    }
}
