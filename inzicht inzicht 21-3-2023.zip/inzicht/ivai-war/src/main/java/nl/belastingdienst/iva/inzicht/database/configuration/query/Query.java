package nl.belastingdienst.iva.inzicht.database.configuration.query;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.DatasourceJPA;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameter;
import nl.belastingdienst.iva.inzicht.domain.query.QueryType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;
import nl.belastingdienst.iva.inzicht.domain.query.VipColumn;

@Entity
@Table(name = "CONF_QUERY")
@NamedQuery(name = Query.QUERY_GETQUERIES, query = "SELECT q FROM Query q " + 
        "LEFT JOIN FETCH q.queryColumns " + 
        "LEFT JOIN FETCH q.queryFilters " + 
        "LEFT JOIN FETCH q.queryAttributes " + 
        "LEFT JOIN FETCH q.datasource " + 
        "ORDER BY q.key")
public class Query implements QueryInterface {

    public static final String QUERY_GETQUERIES = "Query.getQuery";
	
    @Id
    private Integer id;

    private Integer type;
    private String viewName;
    private String queryTemplate;
    private String key;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "QUERY_ID")
    @OrderBy(value = "index")
    private List<QueryColumn> queryColumns;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "QUERY_ID")
    private List<QueryFilter> queryFilters;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "QUERY_ID")
    @OrderBy(value = "key")
    private List<QueryAttribute> queryAttributes;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "DATASOURCE_ID")
    private DatasourceJPA datasource;

    @Transient
    private List<QueryParameter> queryParameters;
    
    @Transient
    private VipColumn vipColumn;

    @Transient
    private List<List<String>> maskableColumnKeysList;

    @Transient
    private ResultMapper resultMapper;
    
    @Transient
    private String errorMessage;
    
    public Integer getId() {
        return this.id;
    }
    
    @Override
    public QueryType getType() {
		return QueryType.findQueryType(type);
	}

    @Override
	public String getViewName() {
		return this.viewName;
	}

    @Override
	public String getQueryTemplate() {
        return this.queryTemplate;
    }
	
    @Override
	public String getKey() {
        return this.key;
    }

    @Override
    public List<QueryColumn> getQueryColumns() {
		return this.queryColumns;
	}
    
    public List<QueryParameter> getQueryParameters() {
        return this.queryParameters == null ? Collections.emptyList() : this.queryParameters;
    }
	
    @Override
	public List<QueryFilter> getQueryFilters() {
		return this.queryFilters;
	}
	
    public List<QueryAttribute> getQueryAttributes() {
        return this.queryAttributes;
    }

    @Override
	public Datasource getDatasource() {
        return this.datasource.getDatasource();
    }
    
    @Override
    public VipColumn getVipColumn() {
        return this.vipColumn;
    }
	
    @Override
    public List<List<String>> getMaskableColumnKeysList() {
        return this.maskableColumnKeysList != null ? this.maskableColumnKeysList : Collections.<List<String>>emptyList();
    }
    
    @Override
	public ResultMapper getResultMapper() {
		return this.resultMapper;
	}
    
    public String getErrorMessage() {
        return this.errorMessage;
    }
	
    @Override
    public boolean hasDatasource() {
        return this.datasource != null;
    }

    public void addQueryParameter(QueryParameter queryParameter) {
        if (this.queryParameters == null) {
            this.queryParameters = new ArrayList<>();
        }
        
        if (this.queryParameters.stream().noneMatch(p -> p.getName().equals(queryParameter.getName()) && p.getType().equals(queryParameter.getType()))) {
            this.queryParameters.add(queryParameter);
        }
    }
    
    public void setVipColumn(VipColumn vipColumnAttribute) {
        this.vipColumn = vipColumnAttribute;
    }
    
    public void setMaskableColumnKeysList(List<String> maskableColumnKeys) {
        this.maskableColumnKeysList = maskableColumnKeys.stream().map(QueryUtils::splitColumnKeys).collect(Collectors.toList());
    }
    
	public void setResultMapper(ResultMapper resultMapper) {
		this.resultMapper = resultMapper;
	}

    public void addErrorMessage(String errorMessage) {
        if (this.errorMessage == null) {
            this.errorMessage = errorMessage;
        } else {
            this.errorMessage = this.errorMessage + "\n" + errorMessage;
        }
    }

	public String getQueryAttributeValue(String key) {
		for (QueryAttribute queryAttribute : this.queryAttributes) {
			if (queryAttribute.hasKey(key)) {
				return queryAttribute.getValue();
			}
		}
		
		return null;
	}
	
	@Override
	public int hashCode() {
		return this.key == null ? 0 : this.key.hashCode();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		
		if ((object == null) || (getClass() != object.getClass())) {
			return false;
		}
		
		Query otherQuery = (Query) object;
		return this.key == null ? otherQuery.key == null : this.key.equals(otherQuery.key);
	}
}
