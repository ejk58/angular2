package nl.belastingdienst.iva.inzicht.database.configuration.query;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;

@Entity
@Table(name = "CONF_QUERY_FILTER")
public class QueryFilter {

	@Id
	private Integer id;
	
    private String key;
    private String parameter;
    private String filterTemplate;
    private String noFilterTemplate;

    @Transient
    private List<String> parameterList;
    
	@PostLoad
    private void buildParameterList() {
		this.parameterList = this.parameter != null ? 
				QueryUtils.extractParameterNamesFromTemplate(this.parameter) : 
				QueryUtils.extractParameterNamesFromTemplate(this.filterTemplate);
	}

	public Integer getId() {
		return this.id;
	}

	public String getKey() {
        return this.key;
    }

    public String getParameter() {
		return this.parameter;
	}
	
	public String getFilterTemplate() {
		return this.filterTemplate;
	}
	
    public String getNoFilterTemplate() {
        return this.noFilterTemplate;
    }
    
    public List<String> getParameterList() {
    	return this.parameterList;
    }
    
    public boolean hasNoFilterTemplate() {
        return (this.noFilterTemplate != null && this.noFilterTemplate.length() > 0);
    }
}
