package nl.belastingdienst.iva.inzicht.dataprovider;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.database.configuration.query.ResultMapper;
import nl.belastingdienst.iva.inzicht.dataprovider.db2.Db2Client;
import nl.belastingdienst.iva.inzicht.dataprovider.internal.InternalClient;
import nl.belastingdienst.iva.inzicht.dataprovider.rest.RestClient;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataClient;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotAuthorizedException;
import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.domain.permission.VipUtils;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameter;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryType;
import nl.belastingdienst.iva.inzicht.domain.query.VipColumn;
import nl.belastingdienst.iva.inzicht.permission.PermissionFactory;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

public class DataProvider {

  @Inject
  private InternalClient internalClient;

  @Inject
  private TeradataClient teradataClient;

  @Inject
  private Db2Client db2Client;

  @Inject
  private RestClient restClient;

  @Inject
  private PermissionFactory permissionFactory;

  private Map<QueryType, DataProviderClient> clientMap;

  @PostConstruct
  private void initializeClientMap() {
    this.clientMap = new EnumMap<>(QueryType.class);

    this.clientMap.put(QueryType.INTERNAL, this.internalClient);
    this.clientMap.put(QueryType.TERADATA, this.teradataClient);
    this.clientMap.put(QueryType.DB2, this.db2Client);
    this.clientMap.put(QueryType.REST, this.restClient);
  }

  public Result retrieveData(QueryInterface query, RestCallContext restCallContext) {

    if (query == null) {
      setEmptyResult(restCallContext);
    } else if (query.getErrorMessage() != null) {
      setErrorResult(query, restCallContext);
    } else {
      checkRequiredRoles(query, restCallContext);
      checkRequiredPermission(query, restCallContext);
      retrieveResult(query, restCallContext);
      mapResult(query, restCallContext);
      processVipInformation(query, restCallContext);
    }

    return restCallContext.getResult();
  }

  private void checkRequiredRoles(QueryInterface query, RestCallContext restCallContext) {
    if (!RoleUtils.isAuthorizedUser(restCallContext)) {
      throw new NotAuthorizedException(
        "The user lacks a role (" + restCallContext.getAuthorizedRoles() + ") for a domain that is linked to the query "
          + query.getKey());
    }
  }

  private void checkRequiredPermission(QueryInterface query, RestCallContext restCallContext) {
    List<QueryParameter> queryParameters = query.getQueryParameters();

    for (QueryParameter queryParameter : queryParameters) {
      String parameterName = queryParameter.getName();
      QueryParameterType parameterType = queryParameter.getType();
      String parameterValue = restCallContext.getFirstQueryValue(parameterName);

      if (parameterType == null) {
        String message =
          "The type of the parameter " + parameterName + " in query " + query.getKey() + " is not empty, it is probably unknown.";
        throw new InternalServerErrorException(message);
      }

      if (!this.permissionFactory.getAccess(restCallContext, parameterType, parameterValue)) {
        String message =
          "The user has no permission to access the data associated with " + parameterName + " (" + parameterType.getName()
            + ") value of '" + parameterValue + "' with the query " + query.getKey() + ".";
        throw new NotAuthorizedException(message);
      }
    }
  }

  private void retrieveResult(QueryInterface query, RestCallContext restCallContext) {
    DataProviderClient client = this.clientMap.get(query.getType());
    Result result = client.retrieveData(query, restCallContext);
    restCallContext.setResult(result);
  }

  private void setEmptyResult(RestCallContext restCallContext) {
    restCallContext.setResult(DomainUtils.emptyResult());
  }

  private void setErrorResult(QueryInterface query, RestCallContext restCallContext) {
    DataMap metadata = new DataHashMap();
    metadata.put(Result.ERRORMESSAGE, query.getErrorMessage());
    Result result = new Result(DomainUtils.emptyDataMapArray(), metadata);
    restCallContext.setResult(result);
  }

  private void mapResult(QueryInterface query, RestCallContext restCallContext) {
    Result result = restCallContext.getResult();
    ResultMapper resultMapper = query.getResultMapper();
    List<DataMap> data = result.getData();
    result.setData(resultMapper.map(data));
  }

  private void processVipInformation(QueryInterface query, RestCallContext restCallContext) {
    VipColumn vipColumn = query.getVipColumn();

    if (vipColumn != null) {
      if (vipColumn.isFilterType()) {
        filterVipInformation(query, restCallContext);
      }

      if (vipColumn.isTagType()) {
        tagVipInformation(query, restCallContext);
      }

      if (vipColumn.isMaskType()) {
        if (vipColumn.getColumnKeys() != null) {
          maskVipInformation(query, restCallContext);
        } else if (vipColumn.getColumnKeysList() != null) {
          maskVipInformationForList(query, restCallContext);
        }
      }
    } else if (!query.getMaskableColumnKeysList().isEmpty()) {
      maskVipInformationFromData(query, restCallContext);
    }
  }

  private void filterVipInformation(QueryInterface query, RestCallContext restCallContext) {
    VipColumn vipColumn = query.getVipColumn();
    List<String> vipColumnKeys = vipColumn.getColumnKeys();
    Result result = restCallContext.getResult();
    List<DataMap> data = result.getData();
    List<DataMap> dataRows = new ArrayList<>();

    for (DataMap dataMap : data) {
      String fiscalNr = DomainUtils.getFromNestedMapAsString(dataMap, vipColumnKeys);
      boolean access = this.permissionFactory.getAccess(restCallContext, fiscalNr);
      if (access) {
        dataRows.add(dataMap);
      }
    }

    result.setData(DomainUtils.inArray(dataRows));
  }

  private void tagVipInformation(QueryInterface query, RestCallContext restCallContext) {
    VipColumn vipColumn = query.getVipColumn();
    List<String> vipColumnKeys = vipColumn.getColumnKeys();
    List<String> vipTagColumnKeys = vipColumn.getTagColumnKeys();
    Result result = restCallContext.getResult();
    List<DataMap> data = result.getData();
    List<DataMap> dataRows = new ArrayList<>();

    for (DataMap dataMap : data) {
      String fiscalNr = DomainUtils.getFromNestedMapAsString(dataMap, vipColumnKeys);
      Permission permission = this.permissionFactory.getPermission(restCallContext, fiscalNr);
      DomainUtils.putInNestedMap(dataMap, vipTagColumnKeys, permission);

      dataRows.add(dataMap);
    }

    result.setData(dataRows);
  }

  private void maskVipInformation(QueryInterface query, RestCallContext restCallContext) {
    VipColumn vipColumn = query.getVipColumn();
    List<String> vipColumnKeys = vipColumn.getColumnKeys();
    Result result = restCallContext.getResult();
    List<DataMap> data = result.getData();
    List<List<String>> maskableColumnKeysList = query.getMaskableColumnKeysList();
    List<DataMap> dataRows = new ArrayList<>();

    for (DataMap dataMap : data) {
      String fiscalNr = DomainUtils.getFromNestedMapAsString(dataMap, vipColumnKeys);
      boolean access = this.permissionFactory.getAccess(restCallContext, fiscalNr);
      if (!access) {
        for (List<String> columnKeys : maskableColumnKeysList) {
          DomainUtils.putInNestedMap(dataMap, columnKeys, VipUtils.VIP_MASK);
        }
      }
      dataRows.add(dataMap);
    }

    result.setData(dataRows);
  }

  private void maskVipInformationForList(QueryInterface query, RestCallContext restCallContext) {
    VipColumn vipColumn = query.getVipColumn();
    List<List<String>> vipColumnKeysList = vipColumn.getColumnKeysList();
    Result result = restCallContext.getResult();
    List<DataMap> data = result.getData();
    List<List<String>> maskableColumnKeysList = query.getMaskableColumnKeysList();
    List<DataMap> dataRows = new ArrayList<>();

    for (DataMap dataMap : data) {
      // Determine fiscal numbers to be checked
      List<String> fiscalNrList = new ArrayList<>();
      for (List<String> vipColumnKeys : vipColumnKeysList) {
        String fiscalNr = DomainUtils.getFromNestedMapAsString(dataMap, vipColumnKeys);
        if (fiscalNr != null) {
          fiscalNrList.add(fiscalNr);
        }
      }
      // Remove duplicates
      LinkedHashSet<String> fiscalNrSetWithoutDuplicates = new LinkedHashSet<>(fiscalNrList);
      String[] fiscalNrArrayWithoutDuplicates = fiscalNrSetWithoutDuplicates.toArray(new String[]{});
      List<String> fiscalNrListWithoutDuplicates = Arrays.asList(fiscalNrArrayWithoutDuplicates);
      // Check access
      boolean access = this.permissionFactory.getAccess(restCallContext, fiscalNrListWithoutDuplicates);
      if (!access) {
        for (List<String> columnKeys : maskableColumnKeysList) {
          DomainUtils.putInNestedMap(dataMap, columnKeys, VipUtils.VIP_MASK);
        }
      }
      dataRows.add(dataMap);
    }

    result.setData(dataRows);
  }

  private void maskVipInformationFromData(QueryInterface query, RestCallContext restCallContext) {
    Result result = restCallContext.getResult();
    boolean vipUser = RoleUtils.isVipUser(restCallContext);
    List<DataMap> dataRows = result.getData();

    if (!vipUser) {
      List<List<String>> maskableColumnKeys = query.getMaskableColumnKeysList();

      for (DataMap dataMap : dataRows) {
        if (VipUtils.detectVipMaskRow(dataMap)) {
          for (List<String> columnKeys : maskableColumnKeys) {
            DomainUtils.putInNestedMap(dataMap, columnKeys, VipUtils.VIP_MASK);
          }
        }
      }
    }

    result.setData(dataRows);
  }
}
