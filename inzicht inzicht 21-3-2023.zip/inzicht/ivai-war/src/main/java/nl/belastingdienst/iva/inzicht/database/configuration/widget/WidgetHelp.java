package nl.belastingdienst.iva.inzicht.database.configuration.widget;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

import nl.belastingdienst.iva.inzicht.database.configuration.help.Help;

@Entity
@Table(name = "CONF_WIDGET_HELP")
public class WidgetHelp {

    @Id
    private int id;

    private Integer index;

    @JoinColumn(name = "HELP_ID")
    @ManyToOne(fetch = FetchType.EAGER)
    private Help help;

    @JsonIgnore
    public Integer getId() {
        return this.id;
    }

    public Integer getIndex() {
        return index;
    }

    public Help getHelp() {
        return this.help;
    }
}
