package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.Attribute;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class JsonColumnMapper implements ColumnMapper {

	private ColumnMapper payloadColumnMapper;
	private String destinationKey;
	private List<Attribute> attributeList;
	
	public JsonColumnMapper(ColumnMapper payloadColumnMapper, String destinationKey, List<Attribute> attributeList) {
		this.payloadColumnMapper = payloadColumnMapper;
		this.destinationKey = destinationKey;
		this.attributeList = attributeList;
	}
	
	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public Object getValue(DataMap sourceDataMap) {
		Object sourceData = this.payloadColumnMapper.getValue(sourceDataMap);
		DataMap destinationMap = new DataHashMap();
		Object result = sourceData;
		
		if (sourceData instanceof Map) {
			Map<?, ?> sourceMap = (Map<?, ?>) sourceData;
			
			for (Attribute attribute : this.attributeList) {
				Object value = sourceMap.remove(attribute.getKey());
				
				if (value != null) {
					destinationMap.put(attribute.getValue(), value);
				}
			}
			
			for (Map.Entry<?, ?> value : sourceMap.entrySet()) {
				Object key = value.getKey();
				destinationMap.put(key.toString(), value.getValue());
			}
			
			result = destinationMap;
		}

		return result;
	}
}
