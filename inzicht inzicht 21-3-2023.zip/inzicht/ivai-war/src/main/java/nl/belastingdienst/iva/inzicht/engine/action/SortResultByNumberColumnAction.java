package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class SortResultByNumberColumnAction implements Action {

	public static final String NAME = "SortResultByNumberColumn";

	private static final Integer NULLVALUE = Integer.MIN_VALUE / 2;
	
	private List<String> resultColumns;
	
	public SortResultByNumberColumnAction(List<String> resultColumns) {
		this.resultColumns = resultColumns;
	}
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
		Result result = restCallContext.getResult();
		List<DataMap> data = result.getData();
		Collections.sort(data, (resultRow, otherRow) -> getNumberColumnValue(resultRow) - getNumberColumnValue(otherRow));
		result.setData(DomainUtils.inArray(data));
		restCallContext.setResult(result);
		
		return Flow.CONTINUE;
	}
	
	private int getNumberColumnValue(Map<String, ?> resultRow) {
		Object resultRowValue = DomainUtils.getFromNestedMap(resultRow, this.resultColumns);
		int numberColumnValue = NULLVALUE;
		
		if (resultRowValue instanceof Number) {
			numberColumnValue = ((Number) resultRowValue).intValue();
		} else if (resultRowValue instanceof String) {
			numberColumnValue = Integer.parseInt((String) resultRowValue);
		}
		
		return numberColumnValue;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.resultColumns.stream().collect(Collectors.joining("/")) + RulesEngineKey.PARAMETEREND;
	}
}
