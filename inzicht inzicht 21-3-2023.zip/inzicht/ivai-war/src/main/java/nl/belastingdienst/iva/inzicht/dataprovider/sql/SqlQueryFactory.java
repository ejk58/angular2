package nl.belastingdienst.iva.inzicht.dataprovider.sql;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractQueryFactory;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;

public class SqlQueryFactory extends AbstractQueryFactory {
    
    private static final String STOREDPROCEDURESTART = "CALL ";

	public SqlQuery getSqlQuery(Datasource datasource, QueryInterface query, MultivaluedMap<String, String> queryValues, Configuration configuration) {
        String viewName = query.getViewName();
        List<QueryResultColumn> columns = mapColumns(query.getQueryColumns());
        
        String queryTemplate = query.getQueryTemplate();
        queryTemplate = addResultColumns(queryTemplate, columns);
        queryTemplate = addFilters(queryTemplate, query, queryValues);
        queryTemplate = addViewName(queryTemplate, viewName);
        queryTemplate = replaceParameters(datasource, queryTemplate, queryValues, configuration);

        return new SqlQuery(datasource, viewName, queryTemplate, columns);
    }
    
    public SqlQuery getSqlQuery(Datasource datasource, QueryInterface query, MultivaluedMap<String, String> queryValues) {
        return getSqlQuery(datasource, query, queryValues, null);
    }
    
    public SqlQuery getSqlQuery(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Datasource datasource = query.getDatasource();
        return getSqlQuery(datasource, query, queryValues, null);
    }
    
    public SqlQuery getSqlQuery(Datasource datasource, String viewName, String baseTemplate, MultivaluedMap<String, String> queryValues) {
        List<QueryResultColumn> columns = Collections.<QueryResultColumn>emptyList();
        checkAbsentFilterPlaceholders("on " + viewName, baseTemplate);

        String queryTemplate = baseTemplate;
        queryTemplate = addViewName(queryTemplate, viewName);
        queryTemplate = replaceParameters(queryTemplate, queryValues);
        
        return new SqlQuery(datasource, viewName, queryTemplate, columns);
    }
    
    @Override
    protected String prepareValue(Datasource datasource, QueryParameterType type, String value) {
        return prepareValue(type, value, false);
    }

    private String prepareValue(QueryParameterType type, String value, boolean inStoredProcedure) {
        String result = value;
        String quote = inStoredProcedure ? "" : "'";

        if (type == QueryParameterType.STRING || type == QueryParameterType.LISTOFSTRINGS) {
        	result =  quote + value.replace("'","''") + quote;
        } else if (type == QueryParameterType.DATE) {
            result =  quote + value + quote;
        } else if (type == QueryParameterType.FILTER) {
            result = " " + value;
        }

        return result;
    }
    
    @Override
    protected String prepareMultipleValues(Datasource datasource, String queryTemplate, String name, QueryParameterType type, MultivaluedMap<String, String> queryParameters) {
        List<String> values = queryParameters.get(name);

        if (!type.validateAll(values)) {
            String message = "The query parameter " + name + " (" + type + ") is invalid with values '"
                    + (values == null ? null : String.join(", ", values)) + "' for query " + queryTemplate;
            throw new BadRequestException(message);
        }
        
        if (isStoredProcedure(queryTemplate)) {
        	return "'" + values.stream().map(value -> this.prepareValue(type, value, true)).collect(Collectors.joining(", ")) + "'";
        }

        return values.stream().map(value -> this.prepareValue(datasource, type, value)).collect(Collectors.joining(", "));
    }

    private String addResultColumns(String queryTemplate, List<QueryResultColumn> columns) {
        return QueryUtils.addResultColumns(queryTemplate, buildResultColumns(columns));
    }

    private String addViewName(String queryTemplate, String viewName) {
        return QueryUtils.addViewName(queryTemplate, viewName);
    }
    
    private String buildResultColumns(List<QueryResultColumn> columnList) {
        StringBuilder resultColumns = new StringBuilder();

        if (columnList != null) {
            for (QueryResultColumn column : columnList) {
                if (resultColumns.length() > 0) {
                    resultColumns.append(", ");
                }

                resultColumns.append(column.getColumnName());
                resultColumns.append(" AS ");
                resultColumns.append(column.getName());
            }
        }

        return resultColumns.toString();
    }
    
    private boolean isStoredProcedure(String queryTemplate) {
    	return queryTemplate.trim().toUpperCase().startsWith(STOREDPROCEDURESTART);
    }
}
