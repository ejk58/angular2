package nl.belastingdienst.iva.inzicht.database.configuration.widget;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_WIDGET_COLUMN_ATTRIBUTE")
public class WidgetColumnAttribute {
	
	@Id
	private int id;
	
	private String key;
	private String value;
	
	public int getId() {
		return id;
	}
	public String getKey() {
		return key;
	}
	public String getValue() {
		return value;
	}

}
