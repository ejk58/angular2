import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[i-autofocus]'
})
export class AutofocusDirective {

  constructor(private readonly element: ElementRef) {
  }

  @Input('i-autofocus') set autofocus(value: boolean) {
    if (value != false) {
      this.element.nativeElement.focus();
    }
  }
}
