export interface DomainSubjectType {
  label: string;
  searchKey: string;
  index: number;
  searchFilter: string;
}
