export interface QueryParameter {
  name: string;
  type: 'FISCALNUMBER' | 'ENTITYNUMBER' | 'WOZNUMBER' | 'NUMBER' | 'DATE' | 'YEAR' | 'STRING' | 'RESTSTRING' | 'LISTOFNUMBERS' | 'LISTOFSTRINGS' | 'CONFIG' | 'FILTER';
  required: boolean;
}
