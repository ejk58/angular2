import {PathKey} from '@inzicht/classes/path-key';
import {Page} from '@inzicht/classes/page';
import {DomainSubjectType} from '@inzicht/classes/domain-subject-type';
import {PageMenuCategory} from '@inzicht/classes/page-menu';

export interface Domain {
  iconName: string;
  index: number;
  initPageId: string;
  name: string;
  pathKeys: Array<PathKey>;
  subjectTypes: Array<DomainSubjectType>;
  domainId: string;
  attributes?: { [key: string]: string };
  pages?: { [key: string]: Page };
  menuOptions?: PageMenuCategory[];
}
