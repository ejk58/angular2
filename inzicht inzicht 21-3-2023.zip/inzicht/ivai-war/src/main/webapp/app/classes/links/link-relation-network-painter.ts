import * as d3 from 'd3';

import {LinkPainter} from '@inzicht/classes/links/link-painter';
import {LinkSubjectType} from '@inzicht/classes/links/link-subject-type';
import {LinkSubjectPresentation} from '@inzicht/classes/links/link-subject-presentation';
import {Link} from '@inzicht/classes/links/link';
import {Node} from '@inzicht/classes/nodes/node';

export class LinkRelationNetworkPainter implements LinkPainter<LinkSubjectPresentation> {

  public static readonly linkRadius: number = 40;
  public static readonly percentagePositionRatio: number = 0.50;
  public static readonly percentageRadius: number = 15;

  protected readonly calculateSourceX = (link: Link<Node<any, any>, any, any>): number => +link.source.x + this.leftOffset;
  protected readonly calculateSourceY = (link: Link<Node<any, any>, any, any>): number => +link.source.y + this.topOffset;
  protected readonly calculateTargetX = (link: Link<Node<any, any>, any, any>): number => +link.target.x + this.leftOffset;
  protected readonly calculateTargetY = (link: Link<Node<any, any>, any, any>): number => +link.target.y + this.topOffset;

  constructor(protected readonly topOffset: number,
      protected readonly leftOffset: number) {
  }

  public drawLinks(graph: d3.Selection<any, any, any, any>, linkMainGroup: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>,
                   links: Link<Node<any, any>, any, LinkSubjectPresentation>[]): void {

    const unlabeledLinks = links.filter(link => !link.presentation.isLabeled);
    const labeledLinks = links.filter(link => link.presentation.isLabeled);
    const sortedLinks = [...unlabeledLinks, ...labeledLinks];

    const linkGroups = linkMainGroup.selectAll('g.link')
      .data(sortedLinks, (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => link.id);

    this.drawNewLinks(linkGroups.enter().append('g'));
    this.updateExistingLinks(linkGroups);
    this.removeObsoleteLinks(linkGroups.exit());
  }

  protected drawNewLinks(newLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    newLinkGroups
      .attr('class', link => `${link.classes.join(' ')} link`);

    this.drawLine(newLinkGroups);
    this.drawPercentage(newLinkGroups);
  }

  protected updateExistingLinks(existingLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    existingLinkGroups.selectAll('.link-line')
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY);

    existingLinkGroups.selectAll('.link-percentage')
      .attr('transform', (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => this.getPercentageTranslation(link));
  }

  protected removeObsoleteLinks(obsoleteLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    obsoleteLinkGroups.remove();
  }

  protected drawLine(newLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    newLinkGroups
      .append('line')
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY)
      .classed('link-line', true);
  }

  protected drawPercentage(newLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    const newLinkWithPercentageGroups = newLinkGroups
      .filter(link => link.presentation.type === LinkSubjectType.Aandeelhouder || link.presentation.type === LinkSubjectType.HeeftAandeelhouder)
      .append('g')
      .attr('transform', link => this.getPercentageTranslation(link))
      .classed('link-percentage', true);

    newLinkWithPercentageGroups
      .append('circle')
      .attr('r', LinkRelationNetworkPainter.percentageRadius)
      .attr('cx', 0)
      .attr('cy', 0)
      .classed('link-percentage-circle', true);

    newLinkWithPercentageGroups
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(LinkRelationNetworkPainter.percentageRadius / 3))
      .classed('link-percentage-text', true)
      .text(link => link.presentation.percentage ? link.presentation.percentage : '?');
  }

  protected getPercentageTranslation(link: Link<Node<any, any>, any, LinkSubjectPresentation>): string {
    const percentageX = this.getValueForPositionRatio(this.calculateSourceX(link), this.calculateTargetX(link),
      LinkRelationNetworkPainter.percentagePositionRatio);
    const percentageY = this.getValueForPositionRatio(this.calculateSourceY(link), this.calculateTargetY(link),
      LinkRelationNetworkPainter.percentagePositionRatio);
    return `translate(${percentageX},${percentageY})`;
  }

  protected getValueForPositionRatio(source: number, target: number, positionRatio: number): number {
    return (source * positionRatio + target * (1 - positionRatio));
  }
}
