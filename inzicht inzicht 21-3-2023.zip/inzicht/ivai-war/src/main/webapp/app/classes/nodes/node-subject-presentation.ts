import {SubjectType} from '@inzicht/commons/subject-type';

export class NodeSubjectPresentation {

  public type: SubjectType;
  public personType: SubjectType;
  public subjectNr: string;
  public name: string;
  public state: string;
  public age: number;
  public relation: string;
  public description: string;

  public isPerson: boolean;
  public isMasked: boolean;
  public isFiscalPartner: boolean;
  public isMarried: boolean;
  public isLivingTogether: boolean;
  public isParent: boolean;
  public isChild: boolean;
  public isExPartner: boolean;
  public isManyPeople: boolean;
  public isSameAddress: boolean;
  public isSameEntity: boolean;
  public isAccessible: boolean;
  public isPossibleHeir: boolean;
  public inheritanceRejected: boolean;

  public groupTypes: number[];

  public hasGroupType(type: number): boolean {
    return this.groupTypes.some(groupType => groupType === type);
  }
}
