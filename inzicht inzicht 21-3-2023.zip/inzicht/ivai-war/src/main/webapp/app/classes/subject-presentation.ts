import {SubjectPresentationLabel} from '@inzicht/classes/subject-presentation-label';

export class SubjectPresentation {
  constructor(
    public title: string,
    public name: string,
    public remark: string,
    public label: SubjectPresentationLabel,
    public icon: string) {
  }

  public static createWithName(name: string): SubjectPresentation {
    return new SubjectPresentation(undefined, name, undefined, undefined, undefined);
  }
}
