export interface WidgetDefinition {
  widget: string;
  title: string;
  type: string;
  gridColumns: number;
}
