import {Node} from '@inzicht/classes/nodes/node';
import {NodeSubjectPresentation} from '@inzicht/classes/nodes/node-subject-presentation';
import {TooltipSubjectPainter} from '@inzicht/classes/nodes/tooltip-subject-painter';

export class TooltipSubjectSidePainter extends TooltipSubjectPainter {

  protected tooltipEstimatedWidth = 400;

  protected drawTooltip(): void {
    super.drawTooltip();
    this.drawArrows();
  }

  public showTooltip(node: Node<any, NodeSubjectPresentation>): void {
    if (node != null) {
      this.updateLabels(node);
      const labelWidth = this.calculateLabelWidth();
      this.updateButtons(node, labelWidth);
      const width = this.tooltipPadding * 3 + labelWidth + this.tooltipButtonWidth * 2;
      this.updateBackground(width);
      const orientation = node.x > (width + this.imageRadius) ? 'left' : 'right';
      const x = node.x + (orientation === 'left' ? (-width - this.imageRadius) : this.imageRadius);
      const y = node.y - Math.floor((this.tooltipLabelHeight * 4 + this.tooltipPadding) / 2) - this.imageRadius;

      this.tooltipGroup
        .select('.tooltip-arrow-east')
        .attr('opacity', orientation === 'left' ? 1.0 : 0.0)
        .attr('transform', `translate(${width},0)`);

      this.tooltipGroup
        .select('.tooltip-arrow-west')
        .attr('opacity', orientation === 'right' ? 1.0 : 0.0);

      this.tooltipGroup
        .attr('pointer-events', 'auto')
        .attr('transform', `translate(${x},${y})`)
        .transition()
        .attr('opacity', 1.0);
    } else {
      this.tooltipGroup
        .attr('pointer-events', 'auto')
        .transition()
        .attr('opacity', 1.0);
    }
  }

  protected drawArrows(): void {
    this.tooltipGroup
      .append('g')
      .classed('tooltip-arrow', true)
      .classed('tooltip-arrow-west', true)
      .append('path')
      .attr('d', `M-9,${Math.floor(this.tooltipLabelHeight * 2 + this.tooltipPadding)}l9,-9v18z`)
      .on('mouseover', () => this.showTooltip(null))
      .on('mouseout', () => this.hideTooltip());

    this.tooltipGroup
      .append('g')
      .classed('tooltip-arrow', true)
      .classed('tooltip-arrow-east', true)
      .append('path')
      .attr('d', `M9,${Math.floor(this.tooltipLabelHeight * 2 + this.tooltipPadding)}l-9,-9v18z`)
      .on('mouseover', () => this.showTooltip(null))
      .on('mouseout', () => this.hideTooltip());
  }
}
