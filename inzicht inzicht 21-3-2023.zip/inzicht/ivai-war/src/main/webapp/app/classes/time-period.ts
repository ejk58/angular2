export class TimePeriod {
  constructor(public year: number,
              public month: number,
              public signalCount: number,
              public signals: any[]) {
  }
}
