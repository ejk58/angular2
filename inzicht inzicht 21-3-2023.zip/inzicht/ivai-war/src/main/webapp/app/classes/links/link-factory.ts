import {Link} from '@inzicht/classes/links/link';
import {Node} from '@inzicht/classes/nodes/node';

export interface LinkFactory<N extends Node<any, any>, M, P> {
  build(source: N, target: N, row: any): Link<N, M, P>;
}
