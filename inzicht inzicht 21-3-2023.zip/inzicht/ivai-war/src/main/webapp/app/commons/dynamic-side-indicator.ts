import {Side} from '@inzicht/commons/side';

export class DynamicSideIndicator {

  // Generate dynamic side key based on action payload side
  getSides(side: Side | string): { updateSide: string; staticSide: string } {
    return {
      updateSide: side === 'left' ? 'left' : 'right',
      staticSide: side === 'left' ? 'right' : 'left'
    };
  }
}
