import {padStart} from '@inzicht/commons/inzicht-functions';


function dateToParts(date: Date): {dd: string, mm: string, yyyy: string} {
  const day = date.getDate();
  const dd = (day < 10) ? `0${day}` : `${day}`;

  const month = date.getMonth() + 1;
  const mm = (month < 10) ? `0${month}` : `${month}`;

  const yyyy = `${date.getFullYear()}`;

  return {dd, mm, yyyy};
}

export function dateToDdMmYyyy(date: Date): string {
  const { dd, mm, yyyy } = dateToParts(date);
  return `${dd}-${mm}-${yyyy}`;
}
export function dateToYyyyMmDd(date: Date): string {
  const { dd, mm, yyyy } = dateToParts(date);
  return `${yyyy}-${mm}-${dd}`;
}

export function yyyyMmDdToDate(dateString: string): Date {
  const parts: number[] = dateString.split('-').map(Number);
  return new Date(parts[0], parts[1] - 1, parts[2]);
}

export function matchToYyyyMmDd(dateString: string): boolean {
  const pattern = /^[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]$/;
  return pattern.test(dateString);
}

export function calculatePeriodFromMonth(month: number): number {
  return month === 0 ? 1 : month === 3 ? 2 : month === 6 ? 3 : month === 9 ? 4 : undefined;
}

export function calculateMonthFromQuarter(quarter: number): number {
  return quarter === 1 ? 1 : quarter === 2 ? 4 : quarter === 3 ? 7 : quarter === 4 ? 10 : undefined;
}


/**
 * Validate if a number or string is a valid yearQuarter.
 *
 * @param yearQuarter combination of a four digit year and a two digit quarter (01-04)
 * @returns true if the argument is a valid year/quarter, otherwise false
 */
export function validateYearQuarter(yearQuarter: number | string): boolean {
  const yearQuarterAsString: string = String(yearQuarter);

  let isValid = false;
  if (yearQuarterAsString.length === 6) {
    const [year, quarter] = splitYearPeriod(yearQuarter);
    isValid = year >= 1900 && (quarter >= 1 && quarter <= 4);
  }

  return isValid;
}

/**
 * Validate if a number or string is a valid yearMonth.
 *
 * @param yearMonth combination of a four digit year and a two digit quarter (01-12)
 * @returns true if the argument is a valid year/month, otherwise false
 */
export function validateYearMonth(yearMonth: number | string): boolean {
  const yearMonthAsString: string = String(yearMonth);

  let isValid = false;
  if (yearMonthAsString.length === 6) {
    const [year, month] = splitYearPeriod(yearMonth);
    isValid = year >= 1900 && (month >= 1 && month <= 12);
  }

  return isValid;
}

/**
 * Convert a yearQuarter to a string date (yyyy-mm-01).
 *
 * @param yearQuarter combination of a four digit year and a two digit quarter (01-04)
 */
export function convertYearQuarterToDate(yearQuarter: number | string): string {
  const [year, quarter] = splitYearPeriod(yearQuarter);
  const month = calculateMonthFromQuarter(quarter);
  return `${year}-${padStart(month, 2, '0')}-01`;
}

/**
 * Convert a yearMonth to a string date (yyyy-mm-01).
 *
 * @param yearMonth combination of a four digit year and a two digit month (01-12)
 */
export function convertYearMonthToDate(yearMonth: number | string): string {
  const [year, month] = splitYearPeriod(yearMonth);
  const twoDigitMonth: string = padStart(month, 2, '0');
  return `${year}-${twoDigitMonth}-01`;
}

/**
 * Split a yearPeriod into a year and a period (quarter or month).
 * Example: 201601 splits into [2016, 1] where year = 2016 and period = 1.
 *
 * @param yearPeriod combination of a four digit year and a two digit period (quarter or month)
 */
export function splitYearPeriod(yearPeriod: number | string): [number, number] {
  const yearPeriodAsString: string = String(yearPeriod);
  return [
    Number(yearPeriodAsString.substring(0, 4)),
    Number(yearPeriodAsString.substring(4, 6))
  ];
}

/**
 * Formats a date, either as Date or as a formatted string (YYYY-MM-DD), and returns the year of the date
 * only on the first day of the year.
 *
 * @param inputDate A date, either as Date or as a formatted string (YYYY-MM-DD)
 * @returns the year of the given date on January 1st, or an empty string on any other day
 */
export function formatDateForYearPresentation(inputDate: string | Date): string {
  if (typeof inputDate === 'object' && inputDate instanceof Date) {
    const date: Date = inputDate;
    if (date.getMonth() == 0 || date.getDay() == 1) {
      return date.getFullYear().toString();
    }
  } else if (typeof inputDate === 'string' && /^[0-9]{4}-01-01/.test(inputDate)) {
    return inputDate.substring(0, 4);
  }

  return '';
}
