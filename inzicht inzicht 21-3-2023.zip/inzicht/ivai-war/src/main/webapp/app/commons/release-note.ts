export class ReleaseNote {
  public releaseDate: Date;
  public version: string;
  public domainName: string;
  public type: string;
  public description: string;
}
