export interface HttpError {
  statusCode: number;
  statusText: string;
  message: string;
}
