import {encodeLastUriSegment, padStart, groupBy, objectFieldsAsArray, objectPropertiesAsArray, objectEquals, sanitizeSelector} from './inzicht-functions';

describe('InzichtFunctions', () => {

  describe('encodeLastUriSegment', () => {
    it('should encode only the last part of the url', () => {
      const result = encodeLastUriSegment('https://#/#/#/docId#.pdf.pdf');
      expect(result).toEqual('https://#/#/#/docId%23.pdf.pdf');
    });

    it('should not encode the last part of the url when less that 3 slashes', () => {
      const result = encodeLastUriSegment('https://#');
      expect(result).toEqual('https://#');
    });

    it('should not encode the last part of the url when the last / is the the end of the url', () => {
      const result = encodeLastUriSegment('https://#/#$%^&*/##.pdf.pdf/');
      expect(result).toEqual('https://#/#$%^&*/##.pdf.pdf/');
    });

    it('should encode the last part of the url with many special characters', () => {
      const result = encodeLastUriSegment('https://#/, : @ & + $ #');
      expect(result).toEqual('https://#/%2C%20%3A%20%40%20%26%20%2B%20%24%20%23');
    });

    it('should not encode the last part of the url if it contains url parameters', () => {
      const result = encodeLastUriSegment('https://jira/secure/RapidBoard.jspa?rapidView=1798&view=detail');
      expect(result).toEqual('https://jira/secure/RapidBoard.jspa?rapidView=1798&view=detail');
    });
  });

  describe('padStart', () => {
    const source = 'Inzicht';

    it('should pad a string to the given length', () => {
      const result = padStart(source, 10);
      expect(result).toEqual('   Inzicht');
    });

    it('should pad a string to the given length by repeating the given filler', () => {
      const result = padStart(source, 10, 'x');
      expect(result).toEqual('xxxInzicht');
    });

    it('should pad a string to the given length by using as much of the given filler as needed', () => {
      const result = padStart(source, 10, 'veelTeLangeString');
      expect(result).toEqual('veeInzicht');
    });

    it('should not affect a string if the given length is smaller or negative', () => {
      const resultNegative = padStart(source, -5, 'x');
      expect(resultNegative).toEqual(source);
      const resultShort = padStart(source, 5, 'x');
      expect(resultShort).toEqual(source);
    });
  });

  describe('groupBy', () => {
    const cars = [
      { brand: 'Audi', color: 'black' },
      { brand: 'Mercedes', color: 'black' },
      { brand: 'Audi', color: 'red' }
    ];

    it('should group an array of objects by an existing property', () => {
      const result = groupBy(cars, 'color');
      const blackCars = result.get('black');
      const redCars = result.get('red');
      const greenCars = result.get('green');

      expect(blackCars.length).toBe(2);
      expect(blackCars.every(car => car.color === 'black')).toBeTruthy();

      expect(redCars.length).toBe(1);
      expect(redCars.every(car => car.color === 'red')).toBeTruthy();

      expect(greenCars).toBeUndefined();
    });
  });

  describe('objectFieldsAsArray', () => {
    const carSales = {
      bestSeller: { brand: 'Audi', color: 'black' },
      worstSeller: { brand: 'Mercedes', color: 'black' },
      mostRecentSale: { brand: 'Audi', color: 'red' }
    };

    it(`should form an array of all the object's values`, () => {
      const result = objectFieldsAsArray(carSales);
      expect(result.length).toBe(3);
      expect(result.every(car => car.brand != undefined && car.color != undefined)).toBeTruthy();
    });
  });

  describe('objectPropertiesAsArray', () => {
    const carSales = {
      bestSeller: { brand: 'Audi', color: 'black' },
      worstSeller: { brand: 'Mercedes', color: 'black' },
      mostRecentSale: { brand: 'Audi', color: 'red' }
    };

    it(`should form an array of all the fields' values of an object`, () => {
      const result = objectPropertiesAsArray(carSales, 'brand');
      expect(result.length).toBe(3);
      expect(result.every(brand => brand === 'Audi' || brand === 'Mercedes')).toBeTruthy();
    });
  });

  describe('objectEquals', () => {
    const person = {name: 'John', age: 34};
    const robot = {name: 'ZXB-0238', age: 1};
    const personWithAgeAsString = {name: 'John', age: '34'};
    const personWithExtraInfo = {name: 'John', age: 34, hobby: 'Painting'};
    const personWithUndefinedHobby = {name: 'John', age: 34, hobby: undefined};
    const personWithNullHobby = {name: 'John', age: 34, hobby: null};

    it('should see two identical objects as equal', () => {
      const result = objectEquals(person, person);
      expect(result).toEqual(true);
    });

    it('should see two different objects as not equal', () => {
      const result = objectEquals(person, robot);
      expect(result).toEqual(false);
    });

    it('should use strong typing', () => {
      const result = objectEquals(person, personWithAgeAsString);
      expect(result).toEqual(false);
    });

    it('should use weak typing', () => {
      const result = objectEquals(person, personWithAgeAsString, false);
      expect(result).toEqual(true);
    });

    it('should compare all properties of both objects', () => {
      const result = objectEquals(person, personWithExtraInfo);
      expect(result).toEqual(false);
    });

    it('should consider null and undefined as different with strong typing', () => {
      const resultKeyAbsent = objectEquals(person, personWithNullHobby);
      expect(resultKeyAbsent).toEqual(false);

      const resultValueUndefined = objectEquals(personWithUndefinedHobby, personWithNullHobby);
      expect(resultValueUndefined).toEqual(false);
    });

    it('should consider null and undefined as equal with weak typing', () => {
      const resultKeyAbsent = objectEquals(person, personWithNullHobby, false);
      expect(resultKeyAbsent).toEqual(true);

      const resultValueUndefined = objectEquals(personWithUndefinedHobby, personWithNullHobby, false);
      expect(resultValueUndefined).toEqual(true);
    });
  });

  describe('sanitizeSelector', () => {
    it('should leave null values as is', () => {
      const result = sanitizeSelector(null);
      expect(result).toEqual(null);
    });

    it('should leave empty string values as is', () => {
      const result = sanitizeSelector('');
      expect(result).toEqual('');
    });

    it('should leave simple selectors as is', () => {
      const result = sanitizeSelector('banana');
      expect(result).toEqual('banana');
    });

    it('should remove whitespace from complex selectors', () => {
      const result = sanitizeSelector('deze zin heeft spaties');
      expect(result).toEqual('dezezinheeftspaties');
    });
  });
});
