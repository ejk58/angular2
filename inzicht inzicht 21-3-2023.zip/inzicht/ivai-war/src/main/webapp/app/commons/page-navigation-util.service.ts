import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';

import {TrackingService} from '@inzicht/services/tracking.service';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import * as fromStore from '@inzicht/store';
import {getPagesInDomain, getPageInDomain, getSearchPageInDomain, getDomainAttributes} from '@inzicht/store/config/config.selectors';
import {getRouterSideState, getRouterSides, getActiveDomainId} from '@inzicht/store/router/router.selectors';
import {getActiveDomain} from '@inzicht/store/multi-state.selectors';
import {Subject} from '@inzicht/classes/subject';
import {Domain} from '@inzicht/classes/domain';
import {Side} from '@inzicht/commons/side';
import {Page} from '@inzicht/classes/page';

@Injectable()
export class PageNavigationUtilService {

  public static readonly urlFeatures: string = 'noreferrer,noopener';

  constructor(private readonly router: Router,
              private readonly trackingService: TrackingService,
              private readonly splitViewState: SplitViewState,
              private readonly store: Store) { }

  public openInNewTab(fromSide: string, domainId: string, pageId: string, filter: any, focus: boolean): void {
    if (domainId == null) {
      domainId = this.store.selectSync(getActiveDomainId(fromSide));
    }

    const targetPageId = this.replaceTemplateIfPresent(domainId, pageId);
    const navParams = this.composeNavParams(fromSide as Side, targetPageId, filter);
    const urlTree = this.router.createUrlTree(['/main', {outlets: {left: [domainId, targetPageId, navParams], right: null}}]);
    const serializedUrl = this.router.serializeUrl(urlTree);
    const win = window.open(`${window.location.pathname}#${serializedUrl}`, '_blank', PageNavigationUtilService.urlFeatures);

    if (focus) {
      win.focus();
    }
  }

  public navigateToPage(side: string, destinationPageId: string, filter: any): void {
    const domainId = this.store.selectSync(getActiveDomainId(side));
    const targetPageId = this.replaceTemplateIfPresent(domainId, destinationPageId);
    const navParams = this.composeNavParams(side as Side, targetPageId, filter);
    this.router.navigate(['/main', {outlets: {[side]: [domainId, targetPageId, navParams]}}]);
  }

  public navigateToSearchPage(side: string, filter: any): void {
    const domainId = this.store.selectSync(getActiveDomainId(side));
    const targetPage = this.store.selectSync(getSearchPageInDomain(domainId));
    const targetPageId = targetPage.key;
    const navParams = this.composeNavParams(side as Side, targetPageId, filter);
    this.router.navigate(['/main', {outlets: {[side]: [domainId, targetPageId, navParams]}}]);
  }

  public navigateToDomain(destinationSide: string, destinationDomainId: string, targetPageId: string, filter: any): void {
    if (destinationSide === 'right') {
      this.splitViewState.emitOpen2Screen(true);
    }

    this.router.navigate(['/main', {outlets: {[destinationSide]: [destinationDomainId, targetPageId, filter]}}]);
  }

  public navigate(side: string, destinationSide: string, destinationPageId: string, filter: any): void {
    const activeDomain = this.store.selectSync(getActiveDomain(side));
    const targetPageId = this.replaceTemplateIfPresent(activeDomain.domainId, destinationPageId);
    const destinationPageIdLocal = targetPageId ? targetPageId : activeDomain.initPageId;
    const navParams = this.composeNavParams(side as Side, destinationPageIdLocal, filter);

    if (side === 'left' && destinationSide === 'right') {
      this.splitViewState.emitOpen2Screen(true);
      this.store.dispatch(fromStore.headerSelectMenu({side: 'right', menu: 'none'}));
      this.trackingService.trackEvent('klik', 'Tweede scherm/soort:automatisch', destinationPageIdLocal, null);
    }

    this.router.navigate(['/main', {outlets: {[destinationSide]: [activeDomain.domainId, destinationPageIdLocal, navParams]}}]);
  }

  public getUrl(side: string, destinationPageId: string, filter: any): string {
    const activeDomain = this.store.selectSync(getActiveDomain(side));
    const targetPageId = this.replaceTemplateIfPresent(activeDomain.domainId, destinationPageId);
    const destinationPageIdLocal = targetPageId ? targetPageId : activeDomain.initPageId;
    const navParams = this.composeNavParams(side as Side, destinationPageIdLocal, filter);

    const urlParams = Object.entries(navParams).reduce((params, [navParamKey, navParamValue]) => params + `;${navParamKey}=${navParamValue}`, '');
    const url = `${location.origin}${location.pathname}${location.pathname.endsWith('/') ? '' : '/'}#/main/(left:${activeDomain.domainId}/${destinationPageIdLocal}${urlParams})`;
    return url;
  }

  public updateBreadcrumb(side: string, widgetId: string, domainId: string, currentPageId: string, newPageId: string): void {
    const targetPageId = this.replaceTemplateIfPresent(domainId, newPageId);
    const pages: { [key: string]: Page } = this.store.selectSync(getPagesInDomain(domainId));
    const label = pages[currentPageId].title;
    const newLabel = pages[targetPageId].title;
    const sideParams = this.store.selectSync(getRouterSideState(side));

    const outlet = {};
    outlet[side] = [domainId, currentPageId, sideParams];
    const breadcrumb = {
      label: label,
      routerLink: ['/main', {outlets: outlet}],
      command: (event) => this.breadcrumbBack(side, event)
    };
    this.store.dispatch(fromStore.breadcrumbAdd({side, breadcrumb, newLabel}));
  }

  public breadcrumbBack(side, event) {
    this.store.dispatch(fromStore.breadcrumbRemove({side: side, breadcrumb: event.item}));
  }

  public isTemplateReplacementEmpty(fromSide: string, targetId: string): boolean {
    const domainId = this.store.selectSync(getActiveDomainId(fromSide));
    return (!this.replaceTemplateIfPresent(domainId, targetId));
  }

  /*
  * A targetId (page or url) can be a template-id recognized by prefix @@ . In that case the id is replaced by the value of the relevant domain attribute.
  */
  public replaceTemplateIfPresent(domainId: string, targetId: string): string {
    let result = targetId;
    if (targetId && targetId.startsWith('@@')) {
      const domainAttributes: { [key: string]: string } = this.store.selectSync(getDomainAttributes(domainId));
      result = domainAttributes[targetId.substring(2, targetId.length)];

      if (result == null) {
        console.error(`The domain attribute "${targetId}" was not present in the domain "${domainId}", but it is necessary for page navigation.`);
      }
    }
    return result;
  }

  /*
  * @deprecated Deprecated in favor of using navigate method.
  */
  public navToPageSecondScreen(pageId: string, open2Screen: boolean = true, subject?: Subject) {
    this.splitViewState.emitOpen2Screen(open2Screen);
    this.store.dispatch(fromStore.headerSelectMenu({side: 'right', menu: 'none'}));

    this.trackingService.trackEvent('klik', 'Tweede scherm/soort:zelf', pageId, null);

    const activeDomain = this.store.selectSync(getActiveDomain('left'));
    if (activeDomain) {
      if (subject) {
        this.selectDomainAndSubject(activeDomain, pageId, 'left', subject);

        const mandatoryPathKeys = this.getMandatoryPathKeys(activeDomain.domainId, pageId);
        const subjectModel: Object = this.constructParams(subject.model, mandatoryPathKeys);
        this.updateSubject('right', activeDomain, subjectModel);
      } else {
        this.selectDomain(activeDomain);
      }
    }
  }

  private composeNavParams(side: Side, destinationPageId: string, filter: any): any {
    const sideParams = this.store.selectSync(getRouterSides)[side];
    const mandatoryPathKeys: string[] = this.getMandatoryPathKeys(sideParams.domainId, destinationPageId);
    const navParams: any = this.constructParams(sideParams, mandatoryPathKeys);

    // add the filter values on top of it (only when not null)
    if (filter) {
      Object.keys(filter)
        .filter(filterKey => filter[filterKey] !== null)
        .forEach(filterKey => navParams[filterKey] = filter[filterKey]);
    }

    return navParams;
  }

  private updateSubject(side: Side, domain: Domain, subjectModel: Object): void {
    this.store.dispatch(fromStore.subjectLoad({
      side,
      domain,
      subjectModel
    }));
  }

  private selectDomain(domain: Domain): void {
    this.store.dispatch(fromStore.selectDomainWithoutSubject({
      side: 'right',
      domain
    }));
  }

  private selectDomainAndSubject(domain: Domain, pageId: string, fromSide: Side, subject: Subject): void {
    const mandatoryPathKeys: string[] = this.getMandatoryPathKeys(domain.domainId, pageId);
    this.store.dispatch(fromStore.selectDomainWithSubject({
      side: 'right',
      domain,
      subject,
      params: this.constructParams(subject.model, mandatoryPathKeys)
    }));
  }

  private constructParams(sourceValues: any, mandatoryPathKeys: string[]): any {
    const {pageId, domainId, ...params} = sourceValues;
    mandatoryPathKeys.forEach(mpk => params[mpk] = sourceValues[mpk]);
    return params;
  }

  private getMandatoryPathKeys(domainId: string, pageId: string): string[] {
    const page: Page = this.store.selectSync(getPageInDomain(domainId, pageId));
    if (!page) {
      console.error(`Could not find mandatory pathkeys for domain "${domainId}" and page "${pageId}".`);
      return [];
    }
    return page.mandatoryPathKeys;
  }
}
