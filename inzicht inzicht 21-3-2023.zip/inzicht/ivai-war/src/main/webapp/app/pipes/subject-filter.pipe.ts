import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'subjectFilter'
})
export class SubjectFilterPipe implements PipeTransform {

  transform(subjects: any[], filter: string): any {
    return (!subjects || !filter) ? subjects : subjects.filter((subject: any) => this.applyFilter(subject, filter));
  }

  applyFilter(subject: any, filter: string): boolean {
    const filterValue = filter.toLowerCase();
    const subjectPresentation = !subject.presentation ? {} : subject.presentation;

    return Object.keys(subjectPresentation)
      .filter(key => key !== 'label')
      .reduce((filterMatch: boolean, key: string): boolean => {
        const relationValue = String(subjectPresentation[key]);
        return filterMatch || (relationValue.toLowerCase().indexOf(filterValue) > -1);
      }, false);
  }
}
