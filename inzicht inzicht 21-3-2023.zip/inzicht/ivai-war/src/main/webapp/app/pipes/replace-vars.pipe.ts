import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'replaceVars'
})
export class ReplaceVarsPipe implements PipeTransform {

  transform(value: any, year: any): string {
    if (value && isNaN(value) && year) {
      const taxYear = Number(year);
      value = this.replaceTaxYear(value, taxYear);
    }

    return value;
  }

  private replaceTaxYear(label: string, taxYear: number): string {
    let result = label;
    let taxYearMatch = result.match(/\{taxYear\s*[-+]?\s*\d*\}/);

    while (taxYearMatch !== null) {
      const taxYearPlaceholder = taxYearMatch[0];
      const taxYearModifier = taxYearPlaceholder.match(/[-+]?\s*\d/);
      const taxYearDelta = (taxYearModifier === null ? 0 : Number(taxYearModifier[0].replace(/\s/g, '')));

      result = `${result.slice(0, taxYearMatch.index)}${(taxYear + taxYearDelta)}${result.slice(taxYearMatch.index + taxYearPlaceholder.length)}`;
      taxYearMatch = result.match(/\{taxYear\s*[-+]?\s*\d*\}/);
    }

    return result;
  }
}
