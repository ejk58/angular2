import { Pipe, PipeTransform } from '@angular/core';
import { DecimalPipe } from '@angular/common';

@Pipe({
  name: 'foreignMoney'
})
export class ForeignMoneyPipe implements PipeTransform {

  constructor(private readonly dp: DecimalPipe) { }

  transform(value: any, decimalDigits: number = 0): string {
    if (value !== null && value.value != null) {
      const currency = value.currency != null ? value.currency : '';
      if (isNaN(value.value)) {
        return `<span class="money">${value.value} ${currency}</span>`;
      } else {
        return `<span class="money">${this.dp.transform(value.value, `1.${decimalDigits}-${decimalDigits}`)} ${currency}</span>`;
      }
    } else {
      return '';
    }
  }
}
