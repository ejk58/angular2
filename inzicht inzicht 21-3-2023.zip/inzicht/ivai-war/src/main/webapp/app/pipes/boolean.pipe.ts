import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'boolean'
})
export class BooleanPipe implements PipeTransform {

  transform(value: any): string {
    return (value && Object.prototype.hasOwnProperty.call(value,'value')) ? this.transformBoolean(value.value) : this.transformBoolean(value);
  }

  private isBoolean(value: any): boolean {
    const changedValue = typeof value === 'string' ? value.toLowerCase() : value;
    return changedValue === 0 || changedValue === 1 ||
        changedValue === 'ja' || changedValue === 'nee' ||
        changedValue === true || changedValue === false;
  }

  private transformBoolean(value: any): string {
    if (this.isBoolean(value)) {
      return value ? 'Ja' : 'Nee';
    }
    return value;
  }
}
