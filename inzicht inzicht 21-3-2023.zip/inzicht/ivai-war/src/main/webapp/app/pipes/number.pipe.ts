import { Pipe, PipeTransform } from '@angular/core';
import {DecimalPipe} from '@angular/common';

@Pipe({
  name: 'number'
})
export class NumberPipe implements PipeTransform {

  constructor(private readonly dp: DecimalPipe) { }

  transform(value: any, decimalDigits: number = 0): string {
    if (value !== null) {
      if (isNaN(value)) {
        return `<span class="number">${value}</span>`;
      } else {
        return '<span class="number">' +  this.dp.transform(value, `1.${decimalDigits}-${decimalDigits}`)
        + '</span>';
      }
    } else {
      return '';
    }
  }
}
