import {createSelector, DefaultProjectorFn, MemoizedSelector} from '@ngrx/store';
import {Params} from '@angular/router';
import {Side} from '@inzicht/commons/side';
import {getDomainElements} from '@inzicht/store/config/config.selectors';
import {getActiveDomainIdLeft, getActiveDomainIdRight, getRouterStateLeft, getRouterStateRight} from '@inzicht/store/router/router.selectors';
import memoize from 'lodash.memoize';

export const getActiveDomainLeft = createSelector(
  getActiveDomainIdLeft,
  getDomainElements,
  (domainId: string, domainList) => domainId && domainList ? domainList[domainId] : null
);

export const getActiveDomainRight = createSelector(
  getActiveDomainIdRight,
  getDomainElements,
  (domainId: string, domainList) => domainId && domainList ? domainList[domainId] : null
);

export const getActiveDomain = memoize((side: Side | string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => side === 'right' ? getActiveDomainRight : getActiveDomainLeft);


export const getActivePageLeft = createSelector(
  getRouterStateLeft,
  getDomainElements,
  (router: Params, domainList) => router.domainId && router.pageId && domainList ? domainList[router.domainId].pages[router.pageId] : null
);

export const getActivePageRight = createSelector(
  getRouterStateRight,
  getDomainElements,
  (router: Params, domainList) => router.domainId && router.pageId && domainList ? domainList[router.domainId].pages[router.pageId] : null
);

export const getActivePage =
  memoize((side: Side | string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => side === 'right' ? getActivePageRight : getActivePageLeft);


export const getPageInActiveDomainLeft = (pageId: string) => createSelector(
  getDomainElements,
  getActiveDomainIdLeft,
  (domains, domainId: string) => {
    const domain = domains[domainId];
    return domain ? domain.pages[pageId] : null;
  });

export const getPageInActiveDomainRight = (pageId: string) => createSelector(
  getDomainElements,
  getActiveDomainIdRight,
  (domains, domainId: string) => {
    const domain = domains[domainId];
    return domain ? domain.pages[pageId] : null;
  });

export const getPageInActiveDomain =
  memoize((side: Side | string, pageId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => side === 'right' ? getPageInActiveDomainRight(pageId) : getPageInActiveDomainLeft(pageId));
