import {createSelector,  DefaultProjectorFn, MemoizedSelector} from '@ngrx/store';
import {Side} from '@inzicht/commons/side';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {RelationsState} from '@inzicht/store';

export const getRelationsState = createSelector(
  getAppState,
  (appStore: AppState): RelationsState => appStore.relations);

export const getRelationsLeft = createSelector(
  getRelationsState,
  (relations: RelationsState): any => relations.left.list);

export const getRelationsRight = createSelector(
  getRelationsState,
  (relations: RelationsState): any => relations.right.list);

export const getRelations =
  (side: Side | string): MemoizedSelector<AppState, any, DefaultProjectorFn<any>> => side === 'right' ? getRelationsRight : getRelationsLeft;

export const getRelationLoadingLeft = createSelector(
  getRelationsState,
  (relations: RelationsState): boolean => relations.left.loading);

export const getRelationLoadingRight = createSelector(
  getRelationsState,
  (relations: RelationsState): boolean => relations.right.loading);

export const getRelationLoading =
  (side: Side | string): MemoizedSelector<AppState, boolean, DefaultProjectorFn<boolean>> => side === 'right' ? getRelationLoadingRight : getRelationLoadingLeft;

export const getRelationErrorLeft = createSelector(
  getRelationsState,
  (relations: RelationsState): string => relations.left.error);

export const getRelationErrorRight = createSelector(
  getRelationsState,
  (relations: RelationsState): string => relations.right.error);

export const getRelationError =
  (side: Side | string): MemoizedSelector<AppState, string, DefaultProjectorFn<string>> => side === 'right' ? getRelationErrorRight : getRelationErrorLeft;
