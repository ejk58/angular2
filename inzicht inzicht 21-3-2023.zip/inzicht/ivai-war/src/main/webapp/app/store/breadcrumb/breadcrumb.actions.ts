import {createAction, union} from '@ngrx/store';
import {MenuItem} from 'primeng/api';

export const breadcrumbAdd = createAction(
  '[BREADCRUMB] Add',
  (payload:  {side: string; breadcrumb: MenuItem, newLabel: string }) => ({payload})
);

export const breadcrumbRemove = createAction(
  '[BREADCRUMB] Remove',
  (payload: {side: string; breadcrumb: MenuItem }) => ({payload})
);

export const breadcrumbReset = createAction(
  '[BREADCRUMB] Reset',
  (payload: {side: string; breadcrumb: MenuItem }) => ({payload})
);

const actions = union({
  breadcrumbAdd,
  breadcrumbRemove,
  breadcrumbReset
});

export type BreadcrumbActionsUnion = typeof actions;
