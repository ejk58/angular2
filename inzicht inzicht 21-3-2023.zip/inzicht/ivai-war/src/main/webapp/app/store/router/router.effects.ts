import {Location} from '@angular/common';
import {Injectable} from '@angular/core';
import {Params, Router} from '@angular/router';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {Store} from '@ngrx/store';
import {ignoreElements, map, tap} from 'rxjs/operators';
import {RouterActionsUnion, back, forward, go, goTo, navigateWithoutParams, navigateWithParams} from '@inzicht/store/router/router.actions';
import {getRouterSideState} from '@inzicht/store/router/router.selectors';


@Injectable()
export class RouterEffects {
  constructor(
    private readonly actions$: Actions<RouterActionsUnion>,
    private readonly router: Router,
    private readonly location: Location,
    private readonly store: Store
  ) {
  }

  navigate$ = createEffect(() => this.actions$.pipe(
    ofType(go.type),
    map(action => action.payload),
    tap(({path, query: queryParams, extras}) => {
      this.router.navigate(path, {queryParams, ...extras});
    })
  ),
  {dispatch: false}
  );

  navigateTo$ = createEffect(() => this.actions$.pipe(
    ofType(goTo.type),
    map(action => action.payload),
    tap(({side, domainId, pageId, params}) => {
      this.router.navigate(['/main', {outlets: {[side]: [domainId, pageId, params]}}]);
    })
  ),
  {dispatch: false}
  );

  navigateToWithoutParams$ = createEffect(() => this.actions$.pipe(
    ofType(navigateWithoutParams.type),
    map(action => action.payload),
    tap(({side, domainId, initPageId}) => {
      const otherSide = side === 'left' ? 'right' : 'left';
      const state = this.store.selectSync(getRouterSideState(otherSide));
      const commands = {
        outlets: {
          [side]: [domainId, initPageId]
        }
      };

      if (state) {
        this.preserveOtherSide(state, commands, otherSide);
      }

      this.router.navigate(['/main', commands]);
    })
  ),
  {dispatch: false}
  );

  navigateToWithParams$ = createEffect(() => this.actions$.pipe(
    ofType(navigateWithParams.type),
    map((action) => action.payload),
    tap(({side, domain, pageId, params}) => {
      const otherSide = side === 'left' ? 'right' : 'left';
      const destinationPageId = pageId ? pageId : domain.initPageId;
      const state = this.store.selectSync(getRouterSideState(otherSide));
      const commands = {
        outlets: {
          [side]: [domain.domainId, destinationPageId, params]
        }
      };

      if (state) {
        this.preserveOtherSide(state, commands, otherSide);
      }

      this.router.navigate(['/main', commands]);
    })
  ),
  {dispatch: false}
  );

  navigateBack$ = createEffect(() => this.actions$.pipe(
    ofType(back.type),
    tap(() => this.location.back()),
    ignoreElements()
  ),
  {dispatch: false}
  );

  navigateForward$ = createEffect(() => this.actions$.pipe(
    ofType(forward.type),
    tap(() => this.location.forward()),
    ignoreElements()
  ),
  {dispatch: false}
  );


  private preserveOtherSide(state: Params, commands: any, otherSide: 'left' | 'right'): void {
    const filtersJson = (state.filters) ? JSON.stringify(state.filters) : undefined;
    const otherDomainId = state.domainId;
    const otherPageId = state.pageId;

    const {...otherParams} = state;
    delete otherParams.domainId;
    delete otherParams.pageId;
    delete otherParams.filters;

    if (state.filters) {
      commands.outlets[otherSide] = [otherDomainId, otherPageId, filtersJson, otherParams];
    } else {
      commands.outlets[otherSide] = [otherDomainId, otherPageId, otherParams];
    }
  }
}
