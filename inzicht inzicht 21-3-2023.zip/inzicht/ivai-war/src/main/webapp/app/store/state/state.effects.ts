import {Injectable} from '@angular/core';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {map} from 'rxjs/operators';
import {StateActionsUnion, selectDomainWithoutSubject, selectDomainWithSubject} from '@inzicht/store/state/state.actions';
import {navigateWithoutParams, navigateWithParams} from '@inzicht/store/router/router.actions';
import {subjectSelect} from '@inzicht/store/subject/subject.actions';
import {loadRelations} from '@inzicht/store/relation/relation.actions';


@Injectable()
export class StateEffects {

  constructor(private readonly action$: Actions<StateActionsUnion>) { }

  setSubjectForDomain$ = createEffect(() => {
    return this.action$.pipe(
      ofType(selectDomainWithoutSubject.type, selectDomainWithSubject.type),
      map((action: StateActionsUnion) => subjectSelect({side: action.payload.side, subject: action.payload.subject})));
  });

  loadRelationsForDomainWithSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(selectDomainWithSubject.type),
      map((action: StateActionsUnion) => loadRelations({side: action.payload.side, domainId: action.payload.domain.domainId, subjectModel: action.payload.subject.model})));
  });

  navigateToDomainWithSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(selectDomainWithSubject.type),
      map((action: StateActionsUnion) => navigateWithParams({side: action.payload.side, domain: action.payload.domain, pageId: action.payload.pageId, params: action.payload.params})));
  });

  navigateToDomainWithoutSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(selectDomainWithoutSubject.type),
      map((action: StateActionsUnion) => navigateWithoutParams({side: action.payload.side, domainId: action.payload.domain.domainId, initPageId: action.payload.domain.initPageId})));
  });
}
