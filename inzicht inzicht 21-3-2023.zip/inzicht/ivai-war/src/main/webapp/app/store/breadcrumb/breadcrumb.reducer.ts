import {DynamicSideIndicator} from '@inzicht/commons/dynamic-side-indicator';
import {MenuItem} from 'primeng/api';
import {BreadcrumbActionsUnion, breadcrumbAdd, breadcrumbRemove, breadcrumbReset} from '@inzicht/store/breadcrumb/breadcrumb.actions';

const sideGenerator = new DynamicSideIndicator();

export interface BreadcrumbState {
  left?: {
    breadcrumbs: MenuItem[];
  };
  right?: {
    breadcrumbs: MenuItem[];
  };
}

export const initialBreadcrumbState = {
  left: {
    breadcrumbs: []
  },
  right: {
    breadcrumbs: []
  }
};

export function breadcrumbReducer(state = initialBreadcrumbState, action: BreadcrumbActionsUnion): BreadcrumbState {

  switch (action.type) {
    case breadcrumbAdd.type: {
      const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);
      const newBreadcrumbs = state[updateSide].breadcrumbs.slice(0, state[updateSide].breadcrumbs.length - 1);
      newBreadcrumbs.push(action.payload.breadcrumb);
      newBreadcrumbs.push({ label: action.payload.newLabel});
      return {
        [updateSide]: {
          breadcrumbs: newBreadcrumbs
        },
        [staticSide]: {
          breadcrumbs: state[staticSide].breadcrumbs
        }
      };
    }

    case breadcrumbRemove.type: {
      const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);
      const index: number = state[updateSide].breadcrumbs.findIndex(obj => obj === action.payload.breadcrumb);
      const newBreadcrumbs =  state[updateSide].breadcrumbs.slice(0, index + 1);
      return {
        [updateSide]: {
          breadcrumbs: newBreadcrumbs
        },
        [staticSide]: {
          breadcrumbs: state[staticSide].breadcrumbs
        }
      };
    }

    case breadcrumbReset.type: {
      const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);
      return {
        [updateSide]: {
          breadcrumbs: []
        },
        [staticSide]: {
          breadcrumbs: state[staticSide].breadcrumbs
        }
      };
    }

    default:
      return state;
  }
}
