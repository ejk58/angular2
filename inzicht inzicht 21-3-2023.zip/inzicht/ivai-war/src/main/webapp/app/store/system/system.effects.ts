import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {Observable, of} from 'rxjs';
import {catchError, map, switchMap} from 'rxjs/operators';
import {SystemActionsUnion, systemLoad, systemVersionLoadSuccess, systemVersionLoadFailed, systemConfigurationLoadSuccess, systemConfigurationLoadFailed} from '@inzicht/store/system/system.actions';


@Injectable()
export class SystemEffects {
  constructor(
    private readonly action$: Actions<SystemActionsUnion>,
    private readonly http: HttpClient) {  }

  loadSystemVersion$ = createEffect(() => this.action$.pipe(
    ofType(systemLoad.type),
    switchMap(() => {
      return this.http
        .get('rest/system/version', {withCredentials: true, responseType: 'text'})
        .pipe(map((data: any) => systemVersionLoadSuccess(data)))
        .pipe(catchError(err => of(systemVersionLoadFailed(err))));
    })
  ));

  loadSystemConfiguration$: Observable<any> = createEffect(() => this.action$.pipe(
    ofType(systemLoad.type),
    switchMap(() => {
      return this.http
        .get('rest/system/configuration', {withCredentials: true})
        .pipe(map((data: any) => systemConfigurationLoadSuccess(data)))
        .pipe(catchError(err => of(systemConfigurationLoadFailed(err))));
    })
  ));
}
