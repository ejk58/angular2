import {createSelector} from '@ngrx/store';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {SidebarState} from '@inzicht/store';

export const selectSidebarState = createSelector(
  getAppState,
  (appStore: AppState): SidebarState => appStore.sidebar);
