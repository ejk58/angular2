import {createAction, union} from '@ngrx/store';

export const loadReleaseNotes = createAction(
  '[Release Notes] Load Release Notes',
  (payload?: {version: string}) => ({payload})
);

export const loadReleaseNotesSuccess = createAction(
  '[Release Notes] Load Release Notes Success',
  (payload: {version: string, releaseNotes: any}) => ({payload})
);

export const loadReleaseNotesFailed = createAction(
  '[Release Notes] Load Release Notes Failed',
  (payload: {version: string, error: any}) => ({payload})
);

const actions = union({
  loadReleaseNotes,
  loadReleaseNotesSuccess,
  loadReleaseNotesFailed
});

export type ReleaseNotesActionsUnion = typeof actions;
