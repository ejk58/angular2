import {createSelector, DefaultProjectorFn, MemoizedSelector} from '@ngrx/store';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {Side} from '@inzicht/commons/side';
import {Message} from '@inzicht/classes/message';


export const getStateState = createSelector(
  getAppState,
  (appStore: AppState) => appStore.state);


export const getDomainStateLeft = (domainId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => createSelector(
  getStateState,
  (stateState: any) => stateState.left.domains[domainId]);

export const getDomainStateRight = (domainId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => createSelector(
  getStateState,
  (stateState: any) => stateState.right.domains[domainId]);

export const getDomainState =
  (side: Side, domainId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => side === 'right' ? getDomainStateRight(domainId) : getDomainStateLeft(domainId);


export const getSearchResultsFromDomainStateLeft = (domainId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => createSelector(
  getStateState,
  (stateState: any) => {
    const searchResult = stateState.left.domains[domainId] ? stateState.left.domains[domainId].searchResults : {};
    return (searchResult.errorCode == undefined || searchResult.errorCode === 0) ? searchResult : {...searchResult, message: Message.getMessage(searchResult.errorCode)};
  });

export const getSearchResultsFromDomainStateRight = (domainId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => createSelector(
  getStateState,
  (stateState: any) => {
    const searchResult = stateState.right.domains[domainId] ? stateState.right.domains[domainId].searchResults : {};
    return (searchResult.errorCode == undefined || searchResult.errorCode === 0) ? searchResult : {...searchResult, message: Message.getMessage(searchResult.errorCode)};
  });

export const getSearchResultsFromDomainState =
  (side: Side, domainId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => side === 'right' ? getSearchResultsFromDomainStateRight(domainId) : getSearchResultsFromDomainStateLeft(domainId);


export const getPageStateLeft = (pageId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => createSelector(
  getStateState,
  (stateState: any) => stateState.left.pages[pageId]);

export const getPageStateRight = (pageId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => createSelector(
  getStateState,
  (stateState: any) => stateState.right.pages[pageId]);

export const getPageState =
  (side: Side, pageId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => side === 'right' ? getPageStateRight(pageId) : getPageStateLeft(pageId);


export const getWidgetStateLeft = (widgetId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => createSelector(
  getStateState,
  (stateState: any) => stateState.left.widgets[widgetId]);

export const getWidgetStateRight = (widgetId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => createSelector(
  getStateState,
  (stateState: any) => stateState.right.widgets[widgetId]);

export const getWidgetState =
  (side: Side, widgetId: string): MemoizedSelector<any, any, DefaultProjectorFn<any>> => side === 'right' ? getWidgetStateRight(widgetId) : getWidgetStateLeft(widgetId);
