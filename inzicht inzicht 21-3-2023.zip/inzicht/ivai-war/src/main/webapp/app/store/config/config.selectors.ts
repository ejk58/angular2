import {createSelector} from '@ngrx/store';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {Message} from '@inzicht/classes/message';
import {Domain} from '@inzicht/classes/domain';
import {Page} from '@inzicht/classes/page';

export const getConfig = createSelector(
  getAppState,
  (appStore: AppState) => appStore.config);

export const getConfigLoading = createSelector(
  getConfig,
  config => config.loading);

export const getConfigErrorCode = createSelector(
  getConfig,
  config => config.errorCode);

export const getConfigErrorMessage = createSelector(
  getConfig,
  config => config.errorCode === 0 ? null : Message.getMessage(config.errorCode));

export const getDomainElements = createSelector(
  getConfig,
  config => config.domains);

export const getDomainMenuOptions = createSelector(
  getConfig,
  config => config.menuItems);

export const getDomain = (domainId: string) => createSelector(
  getConfig,
  (config) => config.domains[domainId]);

export const getPagesInDomain = (domainId: string) => createSelector(
  getConfig,
  (config) => {
    const domain: Domain = config.domains[domainId];
    return domain ? domain.pages : null;
  });

export const getPageInDomain = (domainId: string, pageId: string) => createSelector(
  getConfig,
  (config) => {
    const domain: Domain = config.domains[domainId];
    return domain ? domain.pages[pageId] : null;
  });

export const getMenuOptionsInDomain = (domainId: string) => createSelector(
  getConfig,
  (config) => {
    const domain: Domain = config.domains[domainId];
    return domain ? domain.menuOptions : null;
  });

export const getDomainAttributes = (domainId: string) => createSelector(
  getConfig,
  (config) => {
    const domain: Domain = config.domains[domainId];
    return domain ? domain.attributes : null;
  });

export const getSearchPageInDomain = (domainId: string) => createSelector(
  getConfig,
  (config) => {
    const domain: Domain = config.domains[domainId];
    return domain ? Object.values(domain.pages).find((page: Page) => page.type === 'search') : null;
  });

export const getReflectionDomainAvailable = createSelector(
  getConfig,
  (config) => config.domains['reflection'] != undefined);

export const getWidgetQueryParameters = (widgetId: string) => createSelector(
  getConfig,
  (config) => config.queryParameters[widgetId]);
