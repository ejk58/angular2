import {HttpError} from '@inzicht/commons/http-error';
import {WidgetActionsUnion, widgetCleanCache, widgetCleanup, widgetLoadFailed, widgetLoadSuccess, widgetReset} from '@inzicht/store/widget/widget.actions';
import {GlobalActionsUnion, logout} from '@inzicht/store/multi-state.actions';

export interface WidgetItem {
  error?: HttpError;
  loading: boolean;
  requestUrl: string;
  timestamp: number;
  widgetData: any;
}

export interface WidgetState {
  lastCleanupTimestamp: number;
  widgetItems: WidgetItem[];
}

export const initialWidgetState = {
  lastCleanupTimestamp: null,
  widgetItems: []
};

function addWidgetItem(state: WidgetState, action) {
  const widgetItem: WidgetItem = {
    requestUrl: action.requestUrl,
    loading: false,
    timestamp: action.currentTimestamp,
    widgetData: action.payload
  };
  return {
    ...state,
    widgetItems: [...state.widgetItems.filter(widgetItem => widgetItem.requestUrl !== action.requestUrl), widgetItem]
  };
}

function addWidgetError(state: WidgetState, action) {
  const widgetItem: WidgetItem = {
    error: {statusCode: action.payload.status, statusText: action.payload.statusText, message: action.payload.message},
    loading: false,
    requestUrl: action.requestUrl,
    timestamp: action.currentTimestamp,
    widgetData: null
  };
  return {
    ...state,
    widgetItems: [...state.widgetItems.filter(widgetItem => widgetItem.requestUrl !== action.requestUrl), widgetItem]
  };
}

function cleanupWidgets(state: WidgetState, action) {
  if (state.lastCleanupTimestamp < (action.currentTimestamp - action.widgetDataExpirationTimeInMilliseconds)) {
    return {
      ...state,
      lastCleanupTimestamp: action.currentTimestamp,
      widgetItems: [...state.widgetItems.filter(widgetItem => widgetItem.timestamp > (action.currentTimestamp - action.widgetDataExpirationTimeInMilliseconds))]
    };
  } else {
    return state;
  }
}

function removeWidgetItem(state: WidgetState, action) {
  return {
    ...state,
    widgetItems: [...state.widgetItems.filter(widgetItem => widgetItem.requestUrl !== action.requestUrl)]
  };
}

export function widgetReducer(state = initialWidgetState, action: WidgetActionsUnion | GlobalActionsUnion): WidgetState {
  switch (action.type) {
    case widgetLoadSuccess.type: return addWidgetItem(state, action);
    case widgetLoadFailed.type: return addWidgetError(state, action);
    case widgetCleanup.type: return cleanupWidgets(state, action);
    case widgetCleanCache.type: return removeWidgetItem(state, action);
    case widgetReset.type: return initialWidgetState;
    case logout.type: return initialWidgetState;
    default: return state;
  }
}
