import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Store} from '@ngrx/store';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {EMPTY, of} from 'rxjs';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {WidgetActionsUnion, widgetLoad, widgetLoadSuccess, widgetLoadFailed} from '@inzicht/store/widget/widget.actions';
import {getWidget} from '@inzicht/store/widget/widget.selectors';

@Injectable()
export class WidgetEffects {
  constructor(
    private readonly action$: Actions<WidgetActionsUnion>,
    private readonly http: HttpClient,
    private readonly store: Store
  ) {
  }

  loadWidgetIfNecessary$ = createEffect(() => this.action$.pipe(
    ofType(widgetLoad.type),
    mergeMap(action => {
      const widget = this.store.selectSync(getWidget(action.payload.requestUrl));
      const isWidgetInStore = (widget != undefined && widget.widgetData != undefined && widget.error == undefined);

      if (!isWidgetInStore) {
        return this.http
          .get(action.payload.requestUrl)
          .pipe(map((data: any) => widgetLoadSuccess(data, action.payload.requestUrl)))
          .pipe(catchError(error => of(widgetLoadFailed(error, action.payload.requestUrl))));
      } else {
        return EMPTY;
      }
    })
  ));
}
