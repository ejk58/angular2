import {SubjectActionsUnion, subjectFind, subjectFindSuccess, subjectFindFailed, subjectLoad, subjectLoadFailed, subjectSelect, subjectClear, subjectReset} from '@inzicht/store';
import {GlobalActionsUnion, logout} from '@inzicht/store/multi-state.actions';
import {DynamicSideIndicator} from '@inzicht/commons/dynamic-side-indicator';
import {Subject} from '@inzicht/classes/subject';

const sideGenerator = new DynamicSideIndicator();

export interface SubjectState {
  left?: {
    loading: boolean;
    selected: Subject;
  };
  right?: {
    loading: boolean;
    selected: Subject;
  };
}

export const initialSubjectState: SubjectState = {
  left: {
    loading: false,
    selected: null
  },
  right: {
    loading: false,
    selected: null
  }
};

function findSubject(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: true,
      selected: action.payload.key ? action.payload.key : action.payload.searchKey
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      selected: state[staticSide].selected
    }
  };
}

function findSubjectSuccess(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: false,
      selected: action.payload.subjects
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      selected: state[staticSide].selected
    }
  };
}

function findSubjectFailed(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: false,
      selected: action.payload.subjects
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      selected: state[staticSide].selected
    }
  };
}

function loadSubject(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: true,
      selected: action.payload.subjectModel
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      selected: state[staticSide].selected
    }
  };
}

function loadSubjectFailed(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: false,
      selected: action.payload.subject
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      selected: state[staticSide].selected
    }
  };
}

function selectSubject(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: false,
      selected: action.payload.subject
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      selected: state[staticSide].selected
    }
  };
}

function clearSubject(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: false,
      selected: null
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      selected: state[staticSide].selected
    }
  };
}

export function subjectReducer(state = initialSubjectState, action: SubjectActionsUnion | GlobalActionsUnion): SubjectState {
  switch (action.type) {
    case subjectFind.type: return findSubject(state, action);
    case subjectFindSuccess.type: return findSubjectSuccess(state, action);
    case subjectFindFailed.type: return findSubjectFailed(state, action);
    case subjectLoad.type: return loadSubject(state, action);
    case subjectLoadFailed.type: return loadSubjectFailed(state, action);
    case subjectSelect.type: return selectSubject(state, action);
    case subjectClear.type: return clearSubject(state, action);
    case subjectReset.type: return initialSubjectState;
    case logout.type: return initialSubjectState;
    default: return state;
  }
}
