import {createSelector, DefaultProjectorFn, MemoizedSelector} from '@ngrx/store';
import {Side} from '@inzicht/commons/side';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {SubjectState} from '@inzicht/store';
import {Subject} from '@inzicht/classes/subject';

export const selectSubjectState = createSelector(
  getAppState,
  (appStore: AppState): SubjectState => appStore.subject);

export const selectSubjectLoadingLeft = createSelector(
  selectSubjectState,
  (subject: SubjectState): boolean => subject.left.loading);

export const selectSubjectLoadingRight = createSelector(
  selectSubjectState,
  (subject: SubjectState): boolean => subject.right.loading);

export const selectSubjectLoading =
  (side: Side | string): MemoizedSelector<AppState, boolean, DefaultProjectorFn<boolean>> => side === 'right' ? selectSubjectLoadingRight : selectSubjectLoadingLeft;

export const selectSelectedSubjectLeft = createSelector(
  selectSubjectState,
  (subject: SubjectState): Subject => subject.left.selected);

export const selectSelectedSubjectRight = createSelector(
  selectSubjectState,
  (subject: SubjectState): Subject => subject.right.selected);

export const selectSelectedSubject =
  (side: Side | string): MemoizedSelector<AppState, Subject, DefaultProjectorFn<Subject>> => side === 'right' ? selectSelectedSubjectRight : selectSelectedSubjectLeft;
