import {createSelector, DefaultProjectorFn, MemoizedSelector} from '@ngrx/store';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {SystemState} from '@inzicht/store';

export const selectSystemState = createSelector(
  getAppState,
  (appStore: AppState): SystemState => appStore.system);

export const selectSystemVersion = createSelector(
  selectSystemState,
  (system: SystemState): string => system.version);

export const selectSystemProperty = (key: string): MemoizedSelector<AppState, any, DefaultProjectorFn<any>> => createSelector(
  selectSystemState, (system: SystemState) => system[key]);
