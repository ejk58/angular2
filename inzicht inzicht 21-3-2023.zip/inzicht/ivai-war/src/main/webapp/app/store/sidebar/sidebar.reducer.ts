import {SidebarActionsUnion, sidebarClose, sidebarOpen} from '@inzicht/store/sidebar/sidebar.actions';

export interface SidebarState {
  type: string;
  widgetTitle?: string;
  widgetId?: string;
  side?: string;
}

export const initialSidebarState: SidebarState = {
  type: 'none'
};

export function sidebarReducer(state = initialSidebarState, action: SidebarActionsUnion): SidebarState {

  switch (action.type) {
    case sidebarOpen.type: {
      return {
        type: action.payload.type,
        widgetTitle: action.payload.widgetTitle,
        widgetId: action.payload.widgetId,
        side: action.payload.side
      };
    }

    case sidebarClose.type: {
      return {
        type: 'none'
      };
    }

    default:
      return state;
  }
}
