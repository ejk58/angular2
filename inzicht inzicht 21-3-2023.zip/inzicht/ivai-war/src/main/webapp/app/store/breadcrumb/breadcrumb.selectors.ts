import {createSelector,  DefaultProjectorFn, MemoizedSelector} from '@ngrx/store';
import {MenuItem} from 'primeng/api';
import {Side} from '@inzicht/commons/side';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {BreadcrumbState} from '@inzicht/store';

export const selectBreadcrumbState = createSelector(
  getAppState,
  (appStore: AppState): BreadcrumbState => appStore.breadcrumb);

export const selectBreadcrumbLeft = createSelector(
  selectBreadcrumbState,
  (breadcrumb: BreadcrumbState): MenuItem[] => breadcrumb.left.breadcrumbs);

export const selectBreadcrumbRight = createSelector(
  selectBreadcrumbState,
  (breadcrumb: BreadcrumbState): MenuItem[] => breadcrumb.right.breadcrumbs);

export const selectBreadcrumb =
  (side: Side | string): MemoizedSelector<AppState, MenuItem[], DefaultProjectorFn<MenuItem[]>> => side === 'right' ? selectBreadcrumbRight : selectBreadcrumbLeft;
