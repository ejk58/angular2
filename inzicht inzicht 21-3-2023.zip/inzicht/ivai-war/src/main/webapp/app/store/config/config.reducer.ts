import {ConfigActionsUnion, loadConfig, loadConfigSuccess, loadConfigFailed, resetConfig} from '@inzicht/store/config/config.actions';
import {GlobalActionsUnion, logout} from '@inzicht/store/multi-state.actions';
import {Domain} from '@inzicht/classes/domain';
import {Message} from '@inzicht/classes/message';
import {QueryParameter} from '@inzicht/classes/query-parameter';

export interface Config {
  loading: boolean;
  errorCode: number;
  domains: { [key: string]: Domain };
  menuItems: Domain[];
  queryParameters: { [key: string]: QueryParameter[] };
}

export const initialConfig: Config = {
  'loading': true,
  'errorCode': 0,
  'domains': {},
  'menuItems': [],
  'queryParameters': {}
};

function reduceLoadConfig(state: Config): Config {
  return {
    'loading': true,
    'errorCode': 0,
    'domains': state.domains,
    'menuItems': state.menuItems,
    'queryParameters': state.queryParameters
  };
}

function reduceLoadConfigSuccess(state: Config, action: any): Config {
  return {
    'loading': false,
    'errorCode': 0,
    'domains': action.payload.domains,
    'menuItems': action.payload.menuItems,
    'queryParameters': action.payload.queryParameters
  };
}

function reduceLoadConfigFailed(state: Config, action: any): Config {
  return {
    'loading': false,
    'errorCode': (action.payload && action.payload.status ? action.payload.status : Message.genericErrorCode),
    'domains': state.domains,
    'menuItems': state.menuItems,
    'queryParameters': state.queryParameters
  };
}

function reduceResetConfig(): Config {
  return initialConfig;
}

export function configReducer(state = initialConfig, action: ConfigActionsUnion | GlobalActionsUnion): Config {
  switch (action.type) {
    case loadConfig.type: return reduceLoadConfig(state);
    case loadConfigSuccess.type: return reduceLoadConfigSuccess(state, action);
    case loadConfigFailed.type: return reduceLoadConfigFailed(state, action);
    case resetConfig.type: return reduceResetConfig();
    case logout.type: return reduceResetConfig();
    default: return state;
  }
}
