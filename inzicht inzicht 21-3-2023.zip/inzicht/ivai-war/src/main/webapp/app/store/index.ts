import {ActionReducerMap} from '@ngrx/store';
import {routerReducer} from '@ngrx/router-store';
import {AppState} from '@inzicht/store/app-state';

import {configReducer} from '@inzicht/store/config/config.reducer';
import {stateReducer} from '@inzicht/store/state/state.reducer';
import {headerReducer} from '@inzicht/store/header/header.reducer';
import {subjectReducer} from '@inzicht/store/subject/subject.reducer';
import {relationsdReducer} from '@inzicht/store/relation/relations.reducer';
import {sidebarReducer} from '@inzicht/store/sidebar/sidebar.reducer';
import {breadcrumbReducer} from '@inzicht/store/breadcrumb/breadcrumb.reducer';
import {releaseNotesReducer} from '@inzicht/store/release-notes/release-notes.reducer';
import {systemReducer} from '@inzicht/store/system/system.reducer';
import {widgetReducer} from '@inzicht/store/widget/widget.reducer';

import {ConfigEffects} from '@inzicht/store/config/config.effects';
import {RouterEffects} from '@inzicht/store/router/router.effects';
import {SubjectEffects} from '@inzicht/store/subject/subject.effects';
import {RelationEffects} from '@inzicht/store/relation/relation.effects';
import {ReleaseNotesEffects} from '@inzicht/store/release-notes/release-notes.effects';
import {SystemEffects} from '@inzicht/store/system/system.effects';
import {WidgetEffects} from '@inzicht/store/widget/widget.effects';
import {StateEffects} from '@inzicht/store/state/state.effects';

export const reducers: ActionReducerMap<AppState> = {
  router: routerReducer,
  config: configReducer,
  state: stateReducer,
  header: headerReducer,
  subject: subjectReducer,
  relations: relationsdReducer,
  sidebar: sidebarReducer,
  breadcrumb: breadcrumbReducer,
  releaseNotes: releaseNotesReducer,
  system: systemReducer,
  widget: widgetReducer
};

export const effects = [
  ConfigEffects,
  RouterEffects,
  SubjectEffects,
  RelationEffects,
  ReleaseNotesEffects,
  SystemEffects,
  WidgetEffects,
  StateEffects
];

export * from '@inzicht/store/breadcrumb/breadcrumb.actions';
export * from '@inzicht/store/header/header.actions';
export * from '@inzicht/store/sidebar/sidebar.actions';
export * from '@inzicht/store/relation/relation.actions';
export * from '@inzicht/store/release-notes/release-notes.actions';
export * from '@inzicht/store/router/router.actions';
export * from '@inzicht/store/subject/subject.actions';
export * from '@inzicht/store/system/system.actions';
export * from '@inzicht/store/widget/widget.actions';
export * from '@inzicht/store/config/config.actions';
export * from '@inzicht/store/state/state.actions';
export * from '@inzicht/store/multi-state.actions';

export * from '@inzicht/store/config/config.effects';
export * from '@inzicht/store/router/router.effects';
export * from '@inzicht/store/subject/subject.effects';
export * from '@inzicht/store/relation/relation.effects';
export * from '@inzicht/store/release-notes/release-notes.effects';
export * from '@inzicht/store/system/system.effects';
export * from '@inzicht/store/widget/widget.effects';
export * from '@inzicht/store/state/state.effects';

export * from '@inzicht/store/router/router.reducer';
export * from '@inzicht/store/config/config.reducer';
export * from '@inzicht/store/state/state.reducer';
export * from '@inzicht/store/header/header.reducer';
export * from '@inzicht/store/subject/subject.reducer';
export * from '@inzicht/store/relation/relations.reducer';
export * from '@inzicht/store/sidebar/sidebar.reducer';
export * from '@inzicht/store/breadcrumb/breadcrumb.reducer';
export * from '@inzicht/store/release-notes/release-notes.reducer';
export * from '@inzicht/store/system/system.reducer';
export * from '@inzicht/store/widget/widget.reducer';

export * from '@inzicht/store/router/router.selectors';
export * from '@inzicht/store/config/config.selectors';
export * from '@inzicht/store/state/state.selectors';
export * from '@inzicht/store/subject/subject.selectors';
export * from '@inzicht/store/relation/relations.selectors';
export * from '@inzicht/store/header/header.selectors';
export * from '@inzicht/store/sidebar/sidebar.selectors';
export * from '@inzicht/store/breadcrumb/breadcrumb.selectors';
export * from '@inzicht/store/release-notes/release-notes.selectors';
export * from '@inzicht/store/system/system.selectors';
export * from '@inzicht/store/widget/widget.selectors';
export * from '@inzicht/store/multi-state.selectors';
