import {HeaderActionsUnion, headerReset, headerSelectMenu} from '@inzicht/store/header/header.actions';
import {StateActionsUnion, selectDomainWithoutSubject, selectDomainWithSubject} from '@inzicht/store/state/state.actions';
import {SidebarActionsUnion, sidebarOpen} from '@inzicht/store/sidebar/sidebar.actions';
import {ConfigActionsUnion, loadConfigFailed} from '@inzicht/store/config/config.actions';

export interface HeaderState {
  left: {
    activeMenu: string;
  };
  right: {
    activeMenu: string;
  };
}

export const initialHeaderState = {
  left: {
    'activeMenu': 'default'
  },
  right: {
    'activeMenu': 'default'
  }
};

function reduceSelectHeaderMenu(state: HeaderState, action: any): HeaderState {
  const activeMenu = action.payload.menu;

  return {
    'left': action.payload.side === 'left' ? { 'activeMenu': activeMenu } : state['left'],
    'right': action.payload.side === 'right' ? { 'activeMenu': activeMenu } : state['right']
  };
}

function reduceResetHeaderMenu(): HeaderState {
  return initialHeaderState;
}

function reduceLoadConfigError(): HeaderState {
  return {
    left: {
      'activeMenu': 'domain'
    },
    right: {
      'activeMenu': 'domain'
    }
  };
}

export function headerReducer(state = initialHeaderState, action: HeaderActionsUnion | SidebarActionsUnion | ConfigActionsUnion | StateActionsUnion): HeaderState {
  switch (action.type) {
    case headerSelectMenu.type: return reduceSelectHeaderMenu(state, action);
    case headerReset.type: return reduceResetHeaderMenu();
    case sidebarOpen.type: return reduceResetHeaderMenu();
    case loadConfigFailed.type: return reduceLoadConfigError();
    case selectDomainWithoutSubject.type: return reduceResetHeaderMenu();
    case selectDomainWithSubject.type: return reduceResetHeaderMenu();
    default: return state;
  }
}
