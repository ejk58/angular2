import { createSelector } from '@ngrx/store';
import {AppState, getAppState} from '@inzicht/store/app-state';

export const selectReleaseNotesState = createSelector(
  getAppState, (appStore: AppState) => appStore.releaseNotes);

export const selectReleaseNotes = createSelector(selectReleaseNotesState, releaseNotes => releaseNotes.releaseNotes);
export const selectReleaseNotesLoading = createSelector(selectReleaseNotesState, releaseNotes => releaseNotes.loading);
export const selectReleaseNotesError = createSelector(selectReleaseNotesState, releaseNotes => releaseNotes.error);
