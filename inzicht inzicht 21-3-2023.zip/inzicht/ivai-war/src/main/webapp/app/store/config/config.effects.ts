import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {of} from 'rxjs';
import {catchError, map, switchMap} from 'rxjs/operators';
import {ConfigActionsUnion, loadConfig, loadConfigSuccess, loadConfigFailed} from '@inzicht/store/config/config.actions';

@Injectable()
export class ConfigEffects {
  constructor(
    private readonly action$: Actions<ConfigActionsUnion>,
    private readonly http: HttpClient) { }

  loadConfig$ = createEffect(() => this.action$.pipe(
    ofType(loadConfig.type),
    switchMap(() => {
      return this.http
        .get('rest/domains')
        .pipe(map((data: any) => loadConfigSuccess(data)))
        .pipe(catchError(error => of(loadConfigFailed(error))));
    })
  ));
}
