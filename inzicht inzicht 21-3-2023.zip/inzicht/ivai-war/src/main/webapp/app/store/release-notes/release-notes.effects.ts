import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {of} from 'rxjs';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {ReleaseNotesActionsUnion, loadReleaseNotes, loadReleaseNotesSuccess, loadReleaseNotesFailed} from '@inzicht/store/release-notes/release-notes.actions';

@Injectable()
export class ReleaseNotesEffects {

  constructor(private readonly action$: Actions<ReleaseNotesActionsUnion>,
              private readonly http: HttpClient) { }

  loadReleaseNotes$ = createEffect(() => {
    return this.action$.pipe(
      ofType(loadReleaseNotes.type),
      mergeMap(action => {
        const version = (action.payload && action.payload.version) ? action.payload.version : 'latest';
        const restUrl = `rest/releasenote?version=${version}`;

        return this.http
          .get(restUrl, {withCredentials: true})
          .pipe(map((releaseNotes: any) => loadReleaseNotesSuccess({'version': version, 'releaseNotes': releaseNotes})))
          .pipe(catchError(error => of(loadReleaseNotesFailed({'version': version, 'error': error}))));
      })
    );
  });
}
