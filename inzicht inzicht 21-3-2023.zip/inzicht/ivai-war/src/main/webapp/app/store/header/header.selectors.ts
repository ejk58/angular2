import {createSelector,  DefaultProjectorFn, MemoizedSelector} from '@ngrx/store';
import {Side} from '@inzicht/commons/side';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {HeaderState} from '@inzicht/store';

export const selectHeaderState = createSelector(
  getAppState,
  (appStore: AppState): HeaderState => appStore.header);

export const selectActiveMenuLeft = createSelector(
  selectHeaderState,
  (header: HeaderState): string => header.left.activeMenu);

export const selectActiveMenuRight = createSelector(
  selectHeaderState,
  (header: HeaderState): string => header.right.activeMenu);

export const selectActiveMenu =
  (side: Side | string): MemoizedSelector<AppState, string, DefaultProjectorFn<string>> => side === 'right' ? selectActiveMenuRight : selectActiveMenuLeft;
