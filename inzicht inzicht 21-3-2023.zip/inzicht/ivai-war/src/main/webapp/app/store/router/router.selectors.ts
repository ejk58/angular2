import {createSelector, DefaultProjectorFn, MemoizedSelector} from '@ngrx/store';
import {Params} from '@angular/router';

import {Side} from '@inzicht/commons/side';
import {AppState, getAppState} from '@inzicht/store/app-state';
import {RouterSidesParams} from '@inzicht/store';

function clean(state: Params): Params {
  if (state != null) {
    const result = {};
    Object.keys(state)
      .filter(key => state[key] != null && state[key] != 'null' && state[key] != 'undefined')
      .forEach(key => result[key] = state[key]);
    return result;
  }

  return state;
}

export const selectRouterState = createSelector(
  getAppState,
  (appStore: AppState): any => appStore.router.state);

export const getActiveUrl = createSelector(
  selectRouterState,
  (router: any): string => router.url);

export const getParams = createSelector(
  selectRouterState,
  (router: any): Params => router.params);

export const getQueryParams = createSelector(
  selectRouterState,
  (router: any): Params => router.queryParams);

export const getRouterSides = createSelector(
  selectRouterState,
  (router: any): RouterSidesParams => router.routerSidesParams);


export const getRouterStateLeft = createSelector(
  selectRouterState,
  (router: any): Params => router.routerSidesParams ? clean(router.routerSidesParams.left) : null);

export const getRouterStateRight = createSelector(
  selectRouterState,
  (router: any): Params => router.routerSidesParams ? clean(router.routerSidesParams.right) : null);

export const getRouterSideState =
  (side: Side | string): MemoizedSelector<AppState, Params, DefaultProjectorFn<Params>> => side === 'right' ? getRouterStateRight : getRouterStateLeft;


export const getActiveDomainIdLeft = createSelector(
  getRouterStateLeft,
  (routerSidesParams: Params): string => routerSidesParams ? routerSidesParams.domainId : null);

export const getActiveDomainIdRight = createSelector(
  getRouterStateRight,
  (routerSidesParams: Params): string => routerSidesParams ? routerSidesParams.domainId : null);

export const getActiveDomainId =
  (side: Side | string): MemoizedSelector<AppState, string, DefaultProjectorFn<string>> => side === 'right' ? getActiveDomainIdRight : getActiveDomainIdLeft;


export const getActivePageIdLeft = createSelector(
  getRouterStateLeft,
  (routerSidesParams: Params): string => routerSidesParams.pageId);

export const getActivePageIdRight = createSelector(
  getRouterStateRight,
  (routerSidesParams: Params): string => routerSidesParams.pageId);

export const getActivePageId =
  (side: Side | string): MemoizedSelector<AppState, string, DefaultProjectorFn<string>> => side === 'right' ? getActivePageIdRight : getActivePageIdLeft;
