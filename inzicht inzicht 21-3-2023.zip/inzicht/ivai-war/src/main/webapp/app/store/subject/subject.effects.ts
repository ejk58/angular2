import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {Store} from '@ngrx/store';
import {of} from 'rxjs';
import {catchError, filter, ignoreElements, map, mergeMap, tap} from 'rxjs/operators';
import {SubjectActionsUnion, subjectFind, subjectFindSuccess, subjectFindFailed, subjectLoad, subjectSelect, subjectLoadFailed} from '@inzicht/store/subject/subject.actions';
import {selectDomainWithSubject} from '@inzicht/store/state/state.actions';
import {PageTitleService} from '@inzicht/services/page-title.service';
import {Side} from '@inzicht/commons/side';
import {Subject} from '@inzicht/classes/subject';
import {SubjectPresentation} from '@inzicht/classes/subject-presentation';
import {SubjectPresentationLabel} from '@inzicht/classes/subject-presentation-label';
import {PathKey} from '@inzicht/classes/path-key';
import {getDomain} from '@inzicht/store/config/config.selectors';

@Injectable()
export class SubjectEffects {
  constructor(
    private readonly action$: Actions<SubjectActionsUnion>,
    private readonly store: Store,
    private readonly http: HttpClient,
    private readonly pageTitleService: PageTitleService) { }

  findSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(subjectFind.type),
      mergeMap((action) => {
        const domainId = action.payload.domain.domainId;
        const domainName = action.payload.domain.name;
        const side = action.payload.side;
        const hasNoSearchType = action.payload.searchType == undefined;
        const searchKey = hasNoSearchType ? action.payload.key : action.payload.searchType.searchKey;
        const searchValue = hasNoSearchType ? action.payload.value : action.payload.searchKey;
        const searchFilter = hasNoSearchType ? action.payload.filter : action.payload.searchType.searchFilter;

        const urlFilter = searchFilter == undefined ? '' : '&'.concat(searchFilter);
        const url = `rest/subject/find?domainId=${domainId}&${searchKey}=${searchValue}${urlFilter}`;

        return this.http
          .get(url, {withCredentials: true})
          .pipe(map((subjects: Subject[]) => {
            return subjectFindSuccess({
              side: side,
              domainId: domainId,
              domainName: domainName,
              subjects: subjects,
              searchKey: searchValue,
              searchType: searchKey,
              err: (subjects.length > 0 ? undefined : 404)
            });
          }))
          .pipe(catchError((error: HttpErrorResponse) => {
            return of(subjectFindFailed({
              side: side,
              domainId: domainId,
              domainName: domainName,
              subjects: undefined,
              searchKey: searchValue,
              searchType: searchKey,
              err: error.status
            }));
          }));
      }));
  });

  // This effect will be triggered only for url navigation
  loadSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(subjectLoad.type),
      mergeMap((action) => {
        const domainId = action.payload.domain.domainId;
        const side = action.payload.side;
        const subjectModel = action.payload.subjectModel;
        const urlParameters = Object.keys(subjectModel).map(modelKey => `&${modelKey}=${subjectModel[modelKey]}`).join('');
        const url = `rest/subject/get?domainId=${domainId}${urlParameters}`;

        return this.http
          .get(url, {withCredentials: true})
          .pipe(map((subjectResponse: Subject) => {
            const subject = subjectResponse ? subjectResponse : this.createErrorSubject(subjectModel);
            return subjectSelect({side, subject: subject});
          }))
          .pipe(catchError((error: HttpErrorResponse) => {
            console.error(error);
            const subject = this.createErrorSubject(subjectModel);
            return of(subjectLoadFailed({side, subject: subject}));
          }));
      }));
  });

  selectSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(subjectSelect.type),
      map((action) => action.payload),
      tap(({side, subject}) => this.setPageTitle(side, subject)),
      ignoreElements()
    );
  }, {dispatch: false});

  navigateToSingleUnmaskedSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(subjectFindSuccess.type),
      filter((action) => this.filterSingleUnmaskedResults(action.payload.subjects)),
      map((action) => {
        const subject = action.payload.subjects[0];
        const domain = this.store.selectSync(getDomain(action.payload.domainId));

        return selectDomainWithSubject({
          side: action.payload.side as Side,
          domain: domain,
          subject: subject,
          pageId: subject.navigation ? subject.navigation.initPageId : undefined,
          params: this.constructSubjectModelParams(subject.model, domain.pathKeys)
        });
      })
    );
  });

  loadSubjectFailed$ = createEffect(() => {
    return this.action$.pipe(
      ofType(subjectLoadFailed.type),
      map((action) => action.payload),
      tap(({side, subject}) => this.setPageTitle(side, subject)),
      ignoreElements()
    );
  }, {dispatch: false});

  private createErrorSubject(subjectModel: Object): Subject {
    const label: SubjectPresentationLabel = new SubjectPresentationLabel('FOUT', 'white', 'red');
    const presentation: SubjectPresentation = new SubjectPresentation('???', '???', 'Er is een fout opgetreden', label, 'bd_report');
    return new Subject(presentation, subjectModel);
  }

  private filterSingleUnmaskedResults(subjects: Subject[]): boolean {
    return subjects != undefined && subjects.length === 1;
  }

  private constructSubjectModelParams(subjectModel: Object, pathKeys: PathKey[]): any {
    const params: any = {};
    pathKeys.forEach(pathKey => {
      if (subjectModel[pathKey.name]) {
        params[pathKey.name] = subjectModel[pathKey.name];
      }
    });
    return params;
  }

  private setPageTitle(side: string, subject: Subject): void {
    if (side === 'left' && subject && subject.model) {
      let pageTitleNr = '';
      if (subject.model['subjectNr']) {
        pageTitleNr = subject.model['subjectNr'];
      } else if (subject.model['entityNr']) {
        pageTitleNr = subject.model['entityNr'];
      } else if (subject.model['wozobjectNr']) {
        pageTitleNr = subject.model['wozobjectNr'];
      }
      this.pageTitleService.update(pageTitleNr, subject.presentation.name);
    }
  }
}
