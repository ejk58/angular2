import {RouterReducerState} from '@ngrx/router-store';
import {Config} from '@inzicht/store/config/config.reducer';
import {State} from '@inzicht/store/state/state.reducer';
import {RouterStateUrl} from '@inzicht/store/router/router.reducer';
import {HeaderState} from '@inzicht/store/header/header.reducer';
import {SubjectState} from '@inzicht/store/subject/subject.reducer';
import {RelationsState} from '@inzicht/store/relation/relations.reducer';
import {SidebarState} from '@inzicht/store/sidebar/sidebar.reducer';
import {BreadcrumbState} from '@inzicht/store/breadcrumb/breadcrumb.reducer';
import {ReleaseNotesState} from '@inzicht/store/release-notes/release-notes.reducer';
import {SystemState} from '@inzicht/store/system/system.reducer';
import {WidgetState} from '@inzicht/store/widget/widget.reducer';

export interface AppState {
  router: RouterReducerState<RouterStateUrl>;
  config: Config;
  state: State;
  header: HeaderState;
  subject: SubjectState;
  relations: RelationsState;
  sidebar: SidebarState;
  breadcrumb: BreadcrumbState;
  releaseNotes: ReleaseNotesState;
  system: SystemState;
  widget: WidgetState;
}

export const getAppState = (state: AppState): AppState => state;
