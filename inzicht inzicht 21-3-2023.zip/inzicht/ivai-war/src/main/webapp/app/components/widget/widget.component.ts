import {ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges} from '@angular/core';
import {WidgetService} from '@inzicht/services/widget.service';
import {MenuItem} from 'primeng/api/menuitem';
import {ActivatedRoute} from '@angular/router';
import {Store} from '@ngrx/store';
import {first} from 'rxjs/operators';
import * as fromStore from '@inzicht/store';
import {HelpState} from '@inzicht/services/help.service';
import {ExcelExportUtil} from '@inzicht/commons/excel-export-util';
import {AuthenticationService} from '@inzicht/services/authentication.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {Message} from '@inzicht/classes/message';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {WidgetErrorAction} from './widget-error-action';
import {WidgetColumnFilter, WidgetDataFilter} from './widget-data-filter';
import {objectUnmatchingKeys, parseJSON} from '@inzicht/commons/inzicht-functions';
import * as _ from 'lodash-es';

@Component({
  selector: 'i-widget',
  templateUrl: './widget.component.html',
  styleUrls: ['./widget.component.scss'],
  providers: [Unsubscriber],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WidgetComponent implements OnDestroy, OnInit, OnChanges {

  private static readonly defaultPadding = '20px';
  private static readonly minimumPadding = '0';

  @Input() widgetId: any;
  @Input() widgetTitle: any;
  @Input() side: string;
  @Input() params: any;
  @Input() filter: any;

  @Input() inWidget: boolean;
  @Input() hideTitle: boolean;
  @Input() initializeWidget: boolean = true;
  @Output() hasData: EventEmitter<any> = new EventEmitter<any>();

  public rawData: any;
  public widgetData: any;
  public widgetMenuError: Message;
  public error: any;
  public menuItems: MenuItem[];
  public minimize: boolean = false;
  public view: any;
  public overflowMinimize: boolean = false;
  public trendMoney: boolean = false;
  public helpTexts: any;
  public loadedRouterState: any;
  public baseYear: number;
  public noData: boolean = false;
  public allowMinimize: boolean;
  public update: boolean;
  public padding: string;
  public pageLinkButton: {pageId: string, label?: string, width?: string};

  private widgetDataFilter: WidgetDataFilter;
  private widgetColumnFilters: WidgetColumnFilter[];
  private loadedFilter: any;

  constructor(private readonly pageNavigationUtil: PageNavigationUtilService,
              private readonly widgetService: WidgetService,
              private readonly store: Store,
              private readonly authenticationService: AuthenticationService,
              private readonly trackingService: TrackingService,
              private readonly helpState: HelpState,
              private readonly excelUtil: ExcelExportUtil,
              private readonly route: ActivatedRoute,
              private readonly unsubscriber: Unsubscriber,
              private readonly changeDetectorRef: ChangeDetectorRef) {

    this.widgetDataFilter = new WidgetDataFilter();
    this.widgetColumnFilters = [];
  }

  ngOnInit(): void {
    this.route.params.pipe(first()).subscribe({
      next: () => this.side = this.route.outlet,
      error: error => console.error(`Error during initialization getting the route params (${error})`)
    });

    this.reloadWidget();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.filter && !changes.filter.isFirstChange()) {
      this.reloadWidget();
    }
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  handleResizeButtonClick(): void {
    this.toggleMinimize();
    const text = this.minimize ? `Klik min:${this.side}/widget:` : `Klik max:${this.side}/widget:`;
    this.trackingService.trackEvent('klik', `${text}${(this.widgetData ? this.widgetData.options.title : this.widgetTitle)}`, this.widgetId, null);
  }

  openHelpInSidebar(): void {
    this.helpState.emitHelpText(this.helpTexts);
    this.trackingService.trackEvent('klik', `Klik help:${this.side}/manier:widget help/widget:${this.widgetData.options.title}`, this.widgetId, null);
    this.store.dispatch(fromStore.sidebarOpen({type: 'help'}));
  }

  showTrendLegend(options: {[key: string]: string}): boolean {
    let show: boolean = false;
    if (options['showTrendLegend']) {
      show = options['showTrendLegend'] === 'true';
    } else {
      show = Object.keys(options.columns).some(key =>
        options.columns[key].columnType === 'TRENDMONEY' ||
        options.columns[key].columnType === 'DRILLDOWNTRENDMONEY'
      );
    }
    return show;
  }

  hasDetailsPageButton(): boolean {
    return this.widgetData.options.detailsPage !== undefined;
  }

  onPageLinkButtonPressed(): void {
    this.pageNavigationUtil.navigate(this.side, this.side, this.pageLinkButton.pageId, null);
  }

  getDetailsPageNavigationLabel(): string {
    return this.widgetData.options.detailsPageNavigationLabel !== undefined ? this.widgetData.options.detailsPageNavigationLabel : 'Details';
  }

  onGlobalDetails(): void {
    const activeSides = this.store.selectSync(fromStore.getRouterSides);
    const pageSideParams = activeSides[this.side];
    this.trackingService.trackEvent('klik', `Klik doorsturen:${this.side}/tab van:${pageSideParams.pageId}/widget van:${this.widgetId}/tab naar:${this.widgetData.options.detailsPage}`, null, null);
    this.pageNavigationUtil.updateBreadcrumb(this.side, this.widgetId, pageSideParams.domainId, pageSideParams.pageId, this.widgetData.options.detailsPage);
    this.pageNavigationUtil.navigateToPage(this.side, this.widgetData.options.detailsPage, null);
  }

  public handleErrorResponse(action: WidgetErrorAction): void {
    if (action === 'reloadWidget') {
      this.cleanCacheAndReloadWidget();
    } else if (action === 'reloadPage') {
      this.reloadPage();
    } else if (action === 'returnToLogin') {
      this.returnToLogin();
    }
  }

  reloadWidget(): void {
    if (this.isFullWidgetReloadNecessary()) {
      this.resetWidget();
      setTimeout(() => this.loadWidget());
    } else {
      this.flagWidgetUpdate();
      setTimeout(() => this.filterWidgetData());
    }
  }

  changeDataStatus(event: {'id': string, 'hasData': boolean}): void {
    if (!event.hasData) {
      this.noData = true;
      this.hasData.emit({id: this.widgetId, hasData: false});
      this.minimizeWidget();
    }
  }

  ktaLink(widgetId: string): void {
    this.widgetService.getWidget(widgetId, this.side, this.filter).subscribe({
      next: widget => {
        if (widget.error) {
          this.error = widget.error;
          const errorCode = (widget.error && widget.error.statusCode) ? widget.error.statusCode : Message.genericErrorCode;
          this.setWidgetMenuError(new Message(errorCode, 'error', 'Het samenstellen van een link om KTA te openen is mislukt'));
        } else {
          const url = widget.widgetData.data[0].LINK;
          const newWindow = window.open(url, '_blank', PageNavigationUtilService.urlFeatures);
          if (newWindow) {
            newWindow.focus();
          }
          this.trackingService.trackEvent('klik', `Klik externe link:${this.side}/widget:${this.widgetData.options.title}/naar:${url}`, this.widgetId, null);
        }
      },
      error: error => {
        this.error = error;
        this.setWidgetMenuError(new Message(error, 'error', 'Het samenstellen van een link om KTA te openen is mislukt'));
      }
    });
  }

  downloadExcel(widgetId: string, title: string): void {
    this.widgetService.getWidget(widgetId, this.side, this.filter).subscribe({
      next: widget => {
        if (widget.error) {
          this.error = widget.error;
          const errorCode = (widget.error && widget.error.statusCode) ? widget.error.statusCode : Message.genericErrorCode;
          this.setWidgetMenuError(new Message(errorCode, 'error', 'Het exporteren van de gegevens naar een Excel document is mislukt'));
        } else {
          const exportData = widget.widgetData;
          this.trackingService.trackEvent('klik', `Klik downloaden:${this.side}/widget:${this.widgetData.options.title}`, this.widgetId, null);
          this.excelUtil.exportToExcel(title, exportData);
        }
      },
      error: error => {
        this.error = error;
        this.setWidgetMenuError(new Message(Message.genericErrorCode, 'error', 'Het exporteren van de gegevens naar een Excel document is mislukt'));
      }
    });
  }

  public clearWidgetMenuError(): void {
    this.widgetMenuError = undefined;
  }

  private isWidgetTitleHidden(): boolean {
    return (this.widgetData.options.title == null || this.widgetData.options.title === '' || this.hideTitle || this.widgetData.options.hideTitle === 'true') &&
        this.widgetData.options.warning == undefined && this.widgetData.options.hideTitle !== 'false';
  }

  private isContainerType(): boolean {
    return this.widgetData.type === 'Container' ||
        this.widgetData.type === 'Composition' ||
        this.widgetData.type === 'RadioContainer' ||
        this.widgetData.type === 'External';
  }

  private isSearchType(): boolean {
    return this.widgetData.type === 'DefaultSearch' ||
        this.widgetData.type === 'MultiValueSearch';
  }

  private isFullWidgetReloadNecessary(): boolean {
    const newRouterState = this.store.selectSync(fromStore.getRouterSideState(this.side));
    const routerStateAvailable = this.loadedRouterState && newRouterState;
    const filterAvailable = this.filter && this.loadedFilter;
    let reloadNecessary = (!routerStateAvailable && !filterAvailable);

    if (routerStateAvailable && !reloadNecessary) {
      const changedKeys = objectUnmatchingKeys(this.loadedRouterState, newRouterState);
      reloadNecessary = changedKeys.some(changedKey => !this.widgetColumnFilters.some(widgetColumnFilter => changedKey === widgetColumnFilter.filterKey));
    }

    if (filterAvailable && !reloadNecessary) {
      const changedKeys = objectUnmatchingKeys(this.loadedFilter, this.filter);
      reloadNecessary = changedKeys.some(changedKey => !this.widgetColumnFilters.some(widgetColumnFilter => changedKey === widgetColumnFilter.filterKey));
    }

    return reloadNecessary;
  }

  private resetWidget(): void {
    this.minimize = false;
    this.overflowMinimize = false;
    this.trendMoney = false;
    this.noData = false;
    this.update = false;
    this.rawData = undefined;
    this.widgetData = undefined;
    this.menuItems = [];
    this.changeDetectorRef.markForCheck();
  }

  private flagWidgetUpdate(): void {
    this.update = true;
  }

  private finishWidgetUpdate(): void {
    this.update = false;
    this.changeDetectorRef.markForCheck();
  }

  private cleanCacheAndReloadWidget(): void {
    this.widgetService.removeWidgetFromStore(this.widgetId, this.side, this.filter);
    this.resetWidget();
    this.loadWidget();
  }

  private loadWidget(): void {
    this.widgetService.getWidget(this.widgetId, this.side, this.filter)
      .subscribe({
        next: widget => {
          const newRouterState = this.store.selectSync(fromStore.getRouterSideState(this.side));

          if (widget.error) {
            this.handleWidgetLoadError(widget.error);
          } else {
            this.processWidgetData(widget.widgetData);
            this.initializeWidgetState();
            this.emitWidgetDataStatus();
            this.loadedRouterState = newRouterState;
            this.loadedFilter = this.filter;

            if (this.widgetData.options.pageLinkButton) {
              this.pageLinkButton = JSON.parse(this.widgetData.options.pageLinkButton);
            }
          }

          this.makeHelpTextsAndMenuItems();
          this.finishWidgetUpdate();
        },
        error: error => {
          this.handleWidgetLoadError(error);
          this.finishWidgetUpdate();
        }
      });
  }

  private filterWidgetData(): void {
    const routerState = this.store.selectSync(fromStore.getRouterSideState(this.side));
    this.widgetData = this.widgetDataFilter.filterWidgetData(routerState, this.filter, this.widgetColumnFilters, this.rawData);

    this.initializeWidgetState();
    this.emitWidgetDataStatus();
    this.finishWidgetUpdate();
  }

  private processWidgetData(restCallData: any): void {
    const routerState = this.store.selectSync(fromStore.getRouterSideState(this.side));

    this.rawData = restCallData;
    this.widgetColumnFilters = this.widgetDataFilter.extractWidgetColumnFilters(this.rawData);
    this.widgetData = this.widgetDataFilter.filterWidgetData(routerState, this.filter, this.widgetColumnFilters, this.rawData);
    this.baseYear = (this.widgetData.data && this.widgetData.data.length > 0) ? this.widgetData.data[0].valutajaar : null;
  }

  private emitWidgetDataStatus(): void {
    if (this.widgetData.data) {
      if (this.widgetData.data.length > 0 || this.isContainerType() || this.isSearchType()) {
        this.noData = false;
        this.hasData.emit({id: this.widgetId, hasData: true});
        this.maximizeWidget();
      } else {
        this.noData = true;
        this.hasData.emit({id: this.widgetId, hasData: false});
        this.minimizeWidget();
      }
    }
  }

  private handleWidgetLoadError(error: any): void {
    this.loadedRouterState = undefined;
    this.rawData = null;
    this.widgetData = null;
    this.error = error;
    this.allowMinimize = true;
  }

  private minimizeWidget(): void {
    if (!this.minimize) {
      this.toggleMinimize();
    }
  }

  private maximizeWidget(): void {
    if (this.minimize) {
      this.toggleMinimize();
    }
  }

  private toggleMinimize(): void {
    if (this.allowMinimize) {
      this.toggleMinimizeWidget();
      this.toggleMinimizeIcon();
      this.changeDetectorRef.markForCheck();
    }
  }

  private toggleMinimizeWidget(): void {
    if (this.allowMinimize) {
      this.minimize = !this.minimize;
      this.overflowMinimize = this.minimize;
    }
  }

  private toggleMinimizeIcon(): void {
    const index = this.menuItems.findIndex(menuItem => menuItem.title === (this.minimize ? 'Minimaliseer' : 'Maximaliseer'));
    if (index > -1) {
      this.menuItems[index].icon = this.minimize ? 'bd_window-maximize' : 'bd_window-minimize';
      this.menuItems[index].title = this.minimize ? 'Maximaliseer' : 'Minimaliseer';
      // force Angular to see the change
      this.menuItems = _.cloneDeep(this.menuItems);
    }
  }

  private reloadPage(): void {
    document.location.reload();
  }

  private returnToLogin(): void {
    this.authenticationService.logout();
  }

  private initializeWidgetState(): void {
    this.hideTitle = this.isWidgetTitleHidden();
    this.allowMinimize = !this.hideTitle;
    this.padding = this.determineWidgetPadding();
  }

  private determineWidgetPadding(): string {
    const defaultWidgetPadding = (this.hideTitle || this.inWidget) ? WidgetComponent.minimumPadding : WidgetComponent.defaultPadding;
    return this.widgetData.options.padding == undefined ? defaultWidgetPadding : this.widgetData.options.padding;
  }

  private makeHelpTextsAndMenuItems(): void {
    this.clearMenuItems();
    this.makeConfigurationMenuItem();
    this.makeReloadItem();
    this.makeHelpTexts();
    this.makeKtaLinkMenuItem();
    this.makeIconLinkMenuItems();
    this.makeExportWidgetMenuItem();
    this.makeFeedbackMenuItem();
    this.makeHelpTextMenuItem();
    this.makeMinimizeMaximizeMenuItem();
  }

  private clearMenuItems(): void {
    this.menuItems = [];
  }

  private makeConfigurationMenuItem(): void {
    const reflectionDomainAvailable = this.store.selectSync(fromStore.getReflectionDomainAvailable);

    if (reflectionDomainAvailable) {
      this.menuItems.push({
        title: 'Bekijk configuratie',
        icon: 'bd_settings',
        command: () => this.goToReflectionDomain()
      });
    }
  }

  private makeReloadItem(): void {
    if (this.widgetData && this.widgetData.options.reloadButton) {
      this.menuItems.push({
        title: 'Herlaad de gegevens',
        icon: 'bd_refresh',
        command: () => this.cleanCacheAndReloadWidget()
      });
    }
  }

  private makeHelpTexts() {
    this.helpTexts = this.widgetData ? {'title': this.widgetData.options.helpTitle, texts: this.widgetData.options.helpTexts} : {};
  }

  private makeKtaLinkMenuItem(): void {
    if (this.widgetData && this.widgetData.options.ktaLinkWidget) {
      this.menuItems.push({
        title: 'Bekijk in KTA',
        icon: 'bd_kta',
        command: () => this.ktaLink(this.widgetData.options.ktaLinkWidget)
      });
    }
  }

  private makeIconLinkMenuItems(): void {
    if (this.widgetData && this.widgetData.options.iconLinks) {
      const iconLinks = parseJSON(this.widgetData.options.iconLinks, `widget "${this.widgetId}", attribute "iconLinks"`);

      if (iconLinks != null) {
        iconLinks.forEach(iconLink => {
          this.menuItems.push({
            'title': iconLink.title,
            'icon': iconLink.icon,
            'url': iconLink.url,
            'target': '_blank'
          });
        });
      }
    }
  }

  private makeExportWidgetMenuItem(): void {
    if (this.widgetData && this.widgetData.options.exportWidget) {
      this.menuItems.push({
        title: 'Download',
        icon: 'bd_get_app',
        command: () => this.downloadExcel(this.widgetData.options.exportWidget, this.widgetData.options.title)
      });
    }
  }

  private makeFeedbackMenuItem(): void {
    if (!this.hideTitle) {
      this.menuItems.push({
        title: 'Feedback',
        icon: 'bd_chat_bubble_outline',
        command: () => this.openFeedbackInSidebar()
      });
    }
  }

  private makeHelpTextMenuItem(): void {
    if (this.helpTexts.texts) {
      if (this.helpTexts.texts.length > 0) {
        this.menuItems.push({
          title: 'Help',
          icon: 'bd_help_outline',
          command: () => this.openHelpInSidebar()
        });
      }
    }
  }

  private makeMinimizeMaximizeMenuItem(): void {
    if (this.allowMinimize) {
      this.menuItems.push({
        title: this.minimize ? 'Maximaliseer' : 'Minimaliseer',
        icon: this.minimize ? 'bd_window-maximize' : 'bd_window-minimize',
        command: () => this.handleResizeButtonClick()
      });
    }

  }

  private openFeedbackInSidebar(): void {
    const title: string = this.widgetData ? this.widgetData.options.title : this.widgetTitle;
    this.trackingService.trackEvent('klik',
      `Klik feedback:${this.side}/widget:${title}`, this.widgetId, null);
    this.store.dispatch(fromStore.sidebarOpen({
      type: 'feedback',
      widgetTitle: title,
      widgetId: this.widgetId,
      side: this.side
    }));
  }

  private goToReflectionDomain(): void {
    this.pageNavigationUtil.navigateToDomain('right', 'reflection', 'reflection-widget-detail', {widgetKey: this.widgetId});
  }

  private setWidgetMenuError(message: Message): void {
    console.log(message);
    this.widgetMenuError = message;
  }
}
