import {Injectable} from '@angular/core';
import {BlockArgument, BlockType, Block} from './block';

@Injectable()
export class TextParser {

  public parse(text: string): Block[] {
    const blocks = [];
    const lastIndex = text ? text.length : 0;
    let index = 0;

    while (index < lastIndex) {
      const block = this.parseBlock(text, index, lastIndex);

      if (block != null) {
        if (block.startIndex > index) {
          blocks.push(this.createBlock(text, index, block.startIndex));
        }

        blocks.push(block);
        index = block.endIndex;
      } else {
        blocks.push(this.createBlock(text, index, lastIndex));
        index = lastIndex;
      }
    }

    return blocks;
  }

  public parseBlock(text: string, startIndex: number, endIndex: number): Block {
    let block = this.findFirstStartOfBlock(text, startIndex, endIndex);

    if (block != null) {
      block = this.findMatchingEndOfBlock(text, endIndex, block);
      block = this.parseArguments(text, block);
    }

    return block;
  }

  public createBlock(text: string, startIndex: number, endIndex: number): Block {
    const block = new Block(BlockType.textType, startIndex, endIndex);
    block.text = text.substring(startIndex, endIndex);
    block.plainText = true;
    return block;
  }

  findFirstStartOfBlock(text: string, startIndex: number, endIndex: number): Block {
    const remainingText = text.substring(startIndex, endIndex);
    const startTagMatch = remainingText.match('\\#([A-Z]*)\\(');
    let block = null;

    if (startTagMatch != null && startTagMatch.length > 1) {
      const blockType = startTagMatch[1];
      block = new Block(blockType, startTagMatch.index + startIndex, null);
    }

    return block;
  }

  findMatchingEndOfBlock(text: string, endIndex: number, block: Block): Block {
    let remainingIndex = block.startIndex + block.type.length + 1;
    let remainingText = text.substring(remainingIndex, endIndex);

    let endTagMatch = remainingText.match('\\)' + block.type + '\\#');
    let innerBlock = this.findFirstStartOfBlock(text, remainingIndex, endIndex);
    while (innerBlock != null && innerBlock.startIndex < endTagMatch.index + remainingIndex) {
      innerBlock = this.findMatchingEndOfBlock(text, endIndex, innerBlock);
      remainingIndex = innerBlock.endIndex;
      remainingText = text.substring(remainingIndex, endIndex);

      endTagMatch = remainingText.match('\\)' + block.type + '\\#');
      innerBlock = this.findFirstStartOfBlock(text, remainingIndex, endIndex);
    }

    block.endIndex = remainingIndex + endTagMatch.index + block.type.length + 2;
    return block;
  }

  parseArguments(text: string, block: Block): Block {
    const lastIndex = block.endIndex - block.type.length - 2;
    const firstIndex = block.startIndex + block.type.length + 2;
    let index = firstIndex;

    while (index >= firstIndex && index < lastIndex) {
      const keyValueSeparatorIndex = text.indexOf('=', index);

      if (keyValueSeparatorIndex > 0) {
        const nextKeyIndex = text.indexOf(';', keyValueSeparatorIndex);
        const endOfValueIndex = (nextKeyIndex >= firstIndex && nextKeyIndex < lastIndex) ? nextKeyIndex : lastIndex;
        const key = text.substring(index, keyValueSeparatorIndex);
        const value = text.substring(keyValueSeparatorIndex + 1, endOfValueIndex);

        if (key === 'text' || key === 'label') {
          const textBlock = this.parseTextArgument(text, keyValueSeparatorIndex + 1, lastIndex);
          index = textBlock.length > 0 ? text.indexOf(';', textBlock[textBlock.length - 1].endIndex) : (keyValueSeparatorIndex + 1);
          block[key] = this.modifyTextArgument(textBlock);
        } else if (value.startsWith('#') && !value.startsWith('##')) {
          const valueBlock = this.parseValueArgument(text, keyValueSeparatorIndex + 1, lastIndex);
          index = text.indexOf(';', valueBlock.endIndex);
          block[key] = valueBlock;
        } else {
          index = nextKeyIndex;
          block[key] = value.replace('##', '#');
        }
      } else {
        console.error(`Error: The string "${text}" contains a malformed argument at index ${index}.`);
        index = lastIndex;
      }

      index++;
    }

    block.text = (block.text != null) ? block.text : block.label;

    return block;
  }

  public parseTextArgument(text: string, startIndex: number, endIndex: number): Block[] {
    const blocks = [];
    let index = startIndex;

    while (index < endIndex) {
      const block = this.parseBlock(text, index, endIndex);
      const nextKeyIndex = text.indexOf(';', index);

      if (block != null && (nextKeyIndex < 0 || block.startIndex < nextKeyIndex)) {
        if (block.startIndex > index) {
          blocks.push(this.createBlock(text, index, block.startIndex));
        }

        blocks.push(block);
        index = block.endIndex;
      } else if (block != null && nextKeyIndex > 0 && block.startIndex >= nextKeyIndex) {
        blocks.push(this.createBlock(text, index, nextKeyIndex));
        index = endIndex;
      } else {
        blocks.push(this.createBlock(text, index, (nextKeyIndex > 0 && nextKeyIndex < endIndex) ? nextKeyIndex : endIndex));
        index = endIndex;
      }
    }

    return blocks;
  }

  public modifyTextArgument(blocks: Block[]): BlockArgument {
    return (blocks.length === 1 ? (blocks[0]['plainText'] ? blocks[0].text : blocks[0]) : (blocks.length > 0 ? blocks : null));
  }

  public parseValueArgument(text: string, startIndex: number, endIndex: number): Block {
    let block = this.findFirstStartOfBlock(text, startIndex, endIndex);

    if (block != null) {
      block = this.findMatchingEndOfBlock(text, endIndex, block);
      block = this.parseArguments(text, block);
    }

    return block;
  }
}
