export type WidgetErrorAction = 'reloadWidget' | 'reloadPage' | 'returnToLogin';
