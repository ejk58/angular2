import { Injectable } from '@angular/core';
import { Params, Resolve } from '@angular/router';
import { Store } from '@ngrx/store';
import { first } from 'rxjs/operators';
import * as fromStore from '@inzicht/store';
import { PathKey } from '@inzicht/classes/path-key';
import { RouterSidesParams, RouterStateUrl } from '@inzicht/store';
import { Domain } from '@inzicht/classes/domain';
import { objectEquals } from '@inzicht/commons/inzicht-functions';

@Injectable()
export class PageResolver implements Resolve<void> {

  private previousRouterState: RouterStateUrl;

  constructor(private readonly store: Store) { }

  public resolve(): void {
    const routerState: RouterStateUrl = this.store.selectSync(fromStore.selectRouterState);
    const routerSidesParams: RouterSidesParams = routerState.routerSidesParams;

    this.store.select(fromStore.getConfig).pipe(
      first(config => config.domains && Object.keys(config.domains).length > 0)
    ).subscribe({
      next: config => {
        Object.keys(routerSidesParams).filter(side => routerSidesParams[side]).forEach(side => {
          const previousSideParams: Params = this.previousRouterState ? this.previousRouterState.routerSidesParams[side] : null;
          const activeSideParams: Params = routerSidesParams[side];
          const activeDomain: Domain = config.domains[activeSideParams.domainId];
          const subjectModel: Object = this.constructSubjectModel(activeSideParams, activeDomain.pathKeys);
          const subjectChanged = this.isSubjectChanged(subjectModel, side);

          if (Object.keys(subjectModel).length > 0 && subjectChanged) {
            this.updateSubject(side, activeDomain, subjectModel);
          } else if (subjectChanged) {
            this.clearSubject(side);
          }

          if (activeSideParams.domainId) {
            const domainChanged = this.isDomainChanged(previousSideParams, activeSideParams);
            if (subjectChanged || domainChanged) {
              this.updateRelations(side, activeSideParams.domainId, subjectModel);
            }

            this.store.dispatch(fromStore.headerSelectMenu({ side: side, menu: 'none' }));
          }
        });

        this.previousRouterState = routerState;
      },
      error: error => console.error(`Error while handling domain state (${error})`)
    });
  }

  private updateSubject(side: string, domain: Domain, subjectModel: Object): void {
    this.store.dispatch(fromStore.subjectLoad({ side, domain: domain, subjectModel }));
  }

  private updateRelations(side: string, domainId: string, subjectModel: Object): void {
    this.store.dispatch(fromStore.loadRelations({ side, domainId, subjectModel }));
  }

  private clearSubject(side: string): void {
    this.store.dispatch(fromStore.subjectClear({ side }));
  }

  private constructSubjectModel(params: Params, pathKeys: PathKey[]): Object {
    const mandatoryPathKeys: PathKey[] = pathKeys.filter(pathKey => pathKey.mandatory);
    const subjectModel: Object = {};

    mandatoryPathKeys.forEach(pathKey => {
      if (params[pathKey.name]) {
        let parameterValue = params[pathKey.name];
        if (parameterValue === 'null') {
          parameterValue = null;
        } else if (pathKey.type === 'number') {
          parameterValue = Number(parameterValue);
        }
        subjectModel[pathKey.name] = parameterValue;
        // Temporary solution !!! See IVAI-6738 for discussion.
        if (pathKey.type === 'number' && isNaN(parameterValue)) {
          delete subjectModel[pathKey.name];
        }
      }
    });

    return subjectModel;
  }

  private isSubjectChanged(subjectModel: Object, side: string): boolean {
    const currentSubjects = this.store.selectSync(fromStore.selectSubjectState);
    const currentSideSubjectModel = currentSubjects[side].selected ? currentSubjects[side].selected.model : null;
    return currentSideSubjectModel ? !objectEquals(currentSideSubjectModel, subjectModel, false) : true;
  }

  private isDomainChanged(previousSideParams: Params, activeSideParams: Params): boolean {
    return (previousSideParams ? previousSideParams.domainId : null) !== activeSideParams.domainId;
  }
}
