import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {WidgetErrorAction} from './widget-error-action';
import {Message} from '@inzicht/classes/message';

@Component({
  selector: 'i-widget-error',
  templateUrl: './widget-error.component.html',
  styleUrls: ['./widget-error.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WidgetErrorComponent implements OnChanges, OnInit {

  // Hint-messages
  private static readonly getAdditionalAuthorizations = 'Als je van mening bent dat je toch toegang tot deze gegevens moet hebben, dan kun je aanvullende rechten aanvragen bij je manager.';
  private static readonly waitForBusySource = 'De bron is waarschijnlijk erg druk, dus het is niet aan te raden om de hele pagina opnieuw te laden.';
  private static readonly contactServicedesk = 'Lost dit het probleem niet op neem dan contact op met de servicedesk.';
  private static readonly reloadApplication = 'Probeer de gegevens opnieuw te laden. Als dit niet helpt, dan zou het kunnen helpen om heel Inzicht opnieuw te laden.';
  private static readonly loginAgain = 'Als het niet de bedoeling is om uitgelogd te zijn, dan kun je via de onderstaande knop opnieuw inloggen.';
  private static readonly reloadOrContact = 'Probeer de gegevens opnieuw te laden. Lost dit het probleem niet op neem dan contact op met de servicedesk.';
  private static readonly waitSomeMinutes = 'Probeer de gegevens opnieuw te laden. Soms kan het helpen om een paar minuten te wachten.';
  private static readonly waitForBusyServer = 'De server is mogelijk erg druk, dus het is niet aan te raden om de hele pagina opnieuw te laden.';
  private static readonly waitForFreshData = 'Waarschijnlijk worden de gegevens in de brontabel op dit moment ververst. Probeer de gegevens over een paar minuten opnieuw te laden.';

  public static readonly errorMap: Map<number, {message: string, hints: string[], reloadWidgetButton: boolean, reloadPageButton: boolean, returnToLoginButton: boolean}> = new Map([
    [400, {message: Message.badRequestMessage,
           hints: [WidgetErrorComponent.reloadApplication, WidgetErrorComponent.contactServicedesk],
           reloadWidgetButton: true, reloadPageButton: true, returnToLoginButton: false}],
    [401, {message: Message.notAuthorizedMessage,
           hints: [WidgetErrorComponent.getAdditionalAuthorizations],
           reloadWidgetButton: false, reloadPageButton: false, returnToLoginButton: false}],
    [403, {message: Message.forbiddenMessage,
           hints: [WidgetErrorComponent.loginAgain],
           reloadWidgetButton: false, reloadPageButton: false, returnToLoginButton: true}],
    [404, {message: Message.notFoundMessage,
           hints: [WidgetErrorComponent.waitSomeMinutes],
           reloadWidgetButton: true, reloadPageButton: false, returnToLoginButton: false}],
    [500, {message: Message.internalServerErrorMessage,
           hints: [WidgetErrorComponent.reloadApplication, WidgetErrorComponent.contactServicedesk],
           reloadWidgetButton: true, reloadPageButton: true, returnToLoginButton: false}],
    [502, {message: Message.badGatewayMessage,
           hints: [WidgetErrorComponent.waitSomeMinutes],
           reloadWidgetButton: true, reloadPageButton: false, returnToLoginButton: false}],
    [503, {message: Message.serviceUnavailableMessage,
           hints: [WidgetErrorComponent.waitSomeMinutes, WidgetErrorComponent.waitForBusyServer],
           reloadWidgetButton: true, reloadPageButton: false, returnToLoginButton: false}],
    [504, {message: Message.gatewayTimeoutMessage,
           hints: [WidgetErrorComponent.waitSomeMinutes, WidgetErrorComponent.waitForBusySource],
           reloadWidgetButton: true, reloadPageButton: false, returnToLoginButton: false}],
    [520, {message: Message.missingTeradataViewMessage,
           hints: [WidgetErrorComponent.waitForFreshData],
           reloadWidgetButton: true, reloadPageButton: false, returnToLoginButton: false}]
  ]);

  @Input() errorCode: any;
  @Output() errorResponse: EventEmitter<WidgetErrorAction> = new EventEmitter<WidgetErrorAction>();

  public errorMessage: string;
  public errorHints: string[];
  public hasReloadWidgetButton: boolean;
  public hasReloadPageButton: boolean;
  public hasReturnToLoginButton: boolean;

  ngOnInit() {
    this.initializeError();
  }

  ngOnChanges(): void {
    this.initializeError();
  }

  reloadWidget(): void {
    this.errorResponse.emit('reloadWidget');
  }

  reloadPage(): void {
    this.errorResponse.emit('reloadPage');
  }

  returnToLogin(): void {
    this.errorResponse.emit('returnToLogin');
  }

  private initializeError(): void {
    if (WidgetErrorComponent.errorMap.has(this.errorCode)) {
      const errorItem = WidgetErrorComponent.errorMap.get(this.errorCode);
      this.errorMessage = `${errorItem.message} (${this.errorCode}).`;
      this.errorHints = errorItem.hints;
      this.hasReloadWidgetButton = errorItem.reloadWidgetButton;
      this.hasReloadPageButton = errorItem.reloadPageButton;
      this.hasReturnToLoginButton = errorItem.returnToLoginButton;
    } else {
      this.errorMessage = `${Message.defaultErrorMessage} (${this.errorCode}).`;
      this.errorHints = [WidgetErrorComponent.reloadOrContact];
      this.hasReloadWidgetButton = true;
      this.hasReloadPageButton = true;
      this.hasReturnToLoginButton = true;
    }
  }
}
