import {Component, EventEmitter, Input, Output} from '@angular/core';

import {Filter} from '@inzicht/components/filters/filter';

@Component({
  selector: 'i-date-page-filter',
  templateUrl: './date-page-filter.component.html',
  styleUrls: ['./date-page-filter.component.scss']
})
export class DatePageFilterComponent {

  @Input() filter: Filter;

  @Input() // See: https://angular.io/guide/component-interaction#intercept-input-property-changes-with-a-setter
  get selection(): Date {
    return this.internalSelection;
  }

  set selection(selection: Date) {
    if (selection != null || !this.filter.forcedSelection) {
      this.internalSelection = selection;
    } else if (this.internalSelection != null) {
      this.selected.emit(this.internalSelection);
    }
  }

  @Output() selected: EventEmitter<Date> = new EventEmitter<Date>();

  public internalSelection: Date;
  public firstDayOfWeek: number = 1;

  public onChange(): void {
    if (this.internalSelection != null || !this.filter.forcedSelection) {
      this.selected.emit(this.internalSelection);
    }
  }
}
