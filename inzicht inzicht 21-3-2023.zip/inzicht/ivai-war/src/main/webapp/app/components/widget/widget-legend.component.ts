import {ChangeDetectionStrategy, Component} from '@angular/core';

@Component({
  selector: 'i-widget-legend',
  templateUrl: './widget-legend.component.html',
  styleUrls: ['./widget-legend.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WidgetLegendComponent {
}
