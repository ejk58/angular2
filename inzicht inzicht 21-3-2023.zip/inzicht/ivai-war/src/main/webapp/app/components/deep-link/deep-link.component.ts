import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, ParamMap, Router} from '@angular/router';

import {Store} from '@ngrx/store';
import {combineLatest, Observable, of, throwError} from 'rxjs';
import {distinctUntilChanged, filter, first, mergeMap} from 'rxjs/operators';

import {Subject} from '@inzicht/classes/subject';
import {SubjectService} from '@inzicht/services/subject.service';
import {getDomainElements} from '@inzicht/store/config/config.selectors';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {Domain} from '@inzicht/classes/domain';
import {Page} from '@inzicht/classes/page';

@Component({
  selector: 'i-deep-link',
  templateUrl: './deep-link.component.html',
  styleUrls: ['./deep-link.component.scss'],
  providers: [Unsubscriber]
})
export class DeepLinkComponent implements OnInit {

  public loading = true;
  public errorMessage: string = null;

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly subjectService: SubjectService,
    private readonly store: Store,
    private readonly unsubscriber: Unsubscriber
  ) { }

  ngOnInit(): void {
    combineLatest(this.route.paramMap, this.route.queryParamMap).pipe(
      distinctUntilChanged()
    ).subscribe({
      next: ([routeParamMap, queryParamMap]) => {
        this.reset();
        this.deepLink(routeParamMap, queryParamMap);
      },
      error: (e) => {
        console.error(e);
        this.errorMessage = `Bij het ophalen van de verwijzing is een fout opgetreden. De gegevens kunnen niet getoond worden (${e.status}).`;
        this.loading = false;
      }
    });
  }

  private reset(): void {
    this.loading = true;
    this.errorMessage = null;
  }

  private deepLink(routeParams: ParamMap, queryParams: ParamMap): void {
    const domainId = routeParams.get('domainId');

    this.store.select(getDomainElements)
      .pipe(filter((domains: { [key: string]: Domain }) => domains != null && Object.keys(domains).length > 0), first())
      .subscribe({
        next: (domains: { [key: string]: Domain }) => {
          const domain = domains[domainId];

          if (domain == undefined) {
            this.errorMessage = `De rechtstreekse verwijzing leidt naar een klantbeeld '${domainId}' dat niet bekend is binnen Inzicht.`;
            this.loading = false;
          } else if (domain.subjectTypes.length > 0) {
            this.navigateToDomainWithSubject(domain, routeParams, queryParams);
          } else {
            this.navigateToDomainWithoutSubject(domain, routeParams);
          }
        },
        error: error => console.error(`Error occurred while getting deep-linked domain (${error})`)
      });
  }

  private navigateToDomainWithSubject(domain: Domain, routeParams: ParamMap, queryParams: ParamMap): void {
    const queryParamMap = this.getMapFromParams(queryParams);
    const domainId = domain.domainId;
    const subjectSearchParams = Object.fromEntries(queryParamMap);

    this.getSubject(domainId, subjectSearchParams).subscribe({
      next: (subject) => {
        this.loading = false;

        const pageId = this.findLandingPage(domain, subject, routeParams);
        const combinedModelMap = new Map(queryParamMap);
        Object.keys(subject.model).forEach(key => combinedModelMap.set(key, subject.model[key]));
        const missingMandatoryPathKeys = this.findMissingMandatoryPathKeys(domain, pageId, combinedModelMap);

        if (domain.pages[pageId] == undefined) {
          this.errorMessage = `De rechtstreekse verwijzing leidt naar een pagina '${pageId}' die niet bekend is in klantbeeld '${domain.name}'.`;
        } else if (missingMandatoryPathKeys.length !== 0) {
          this.errorMessage = `Er is niet voldoende informatie om de pagina '${pageId}' op klantbeeld '${domainId}' te tonen. ` +
              `De volgende gegevens ontbreken in de rechtstreekse verwijzing: ${missingMandatoryPathKeys.join(', ')}.`;
        } else {
          this.router.navigate(['/main', { outlets: { 'left': [domainId, pageId, Object.fromEntries(combinedModelMap)] } }]);
        }
      },
      error: (e) => {
        console.error(e);
        this.errorMessage = (e.status || !e.message) ?
          `Bij het ophalen van de gegevens is een fout opgetreden. De gegevens kunnen niet getoond worden (${e.status}).` : e.message;
        this.loading = false;
      }
    });
  }

  private navigateToDomainWithoutSubject(domain: Domain, routeParams: ParamMap): void {
    this.loading = false;

    const domainId = domain.domainId;
    const pageId = this.findLandingPage(domain, null, routeParams);

    if (domain.pages[pageId] == undefined) {
      this.errorMessage = `De rechtstreekse verwijzing leidt naar een pagina '${pageId}' die niet bekend is in klantbeeld '${domain.name}'.`;
    } else {
      this.router.navigate(['/main', { outlets: { 'left': [domainId, pageId] } }]);
    }
  }

  private getSubject(domainId: string, params: { [key: string]: string }): Observable<Subject> {
    return this.subjectService.getSubject(domainId, params)
      .pipe(
        this.unsubscriber.takeUntilForUnsubscribe,
        mergeMap((subjects: Subject[]) => {
          if (subjects && subjects.length === 1) {
            return of(subjects[0]);
          } else if ((subjects && subjects.length > 1)) {
            return throwError(new Error(`Bij deze rechtstreekse verwijzing voor ${domainId} is meer dan één resultaat gevonden. ` +
              `Rechtstreekse verwijzingen kunnen alleen gebruikt worden voor een enkel resultaat. Het is hierdoor niet mogelijk om de ` +
              `gevraagde gegevens te tonen.`));
          } else {
            return throwError(new Error(`Bij deze rechtstreekse verwijzing voor ${domainId} zijn geen gegevens gevonden. ` +
              `Als de gegevens bij deze verwijzing niet gevonden kunnen worden, dan kunnen deze ook niet getoond worden.`));
          }
        })
      );
  }

  private findLandingPage(domain: Domain, subject: Subject, routeParams: ParamMap): string {
    if (routeParams.has('pageId')) {
      return routeParams.get('pageId');
    } else if (subject != null) {
      return subject.navigation.initPageId;
    } else {
      return domain.initPageId;
    }
  }

  private findMissingMandatoryPathKeys(domain: Domain, pageId: string, modelMap: Map<string, string>): string[] {
    const pageConfig: Page = domain.pages[pageId];
    const missingMandatoryPathKeys = pageConfig == undefined ? undefined : pageConfig.mandatoryPathKeys.filter(mandatoryPathKey => !modelMap.has(mandatoryPathKey));

    return missingMandatoryPathKeys;
  }

  private getMapFromParams(params: ParamMap): Map<string, string> {
    const resultMap = new Map<string, string>();
    params.keys.forEach(key => resultMap.set(key, params.get(key)));
    return resultMap;
  }
}
