import {ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {Observable, of, throwError} from 'rxjs';
import {map, mergeMap, take} from 'rxjs/operators';
import {Subject} from '@inzicht/classes/subject';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {DataTypeService} from '@inzicht/services/data-type.service';
import {SubjectService} from '@inzicht/services/subject.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {encodeLastUriSegment} from '@inzicht/commons/inzicht-functions';

@Component({
  selector: 'i-value',
  templateUrl: './value.component.html',
  styleUrls: ['./value.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ValueComponent implements OnInit, OnDestroy {

  @Input() type?: string;
  @Input() value?: any;
  @Input() side?: any;
  @Input() row?: any;
  @Input() column?: any;
  @Input() widgetId?: any;
  @Input() domainId?: any;
  @Input() pageId?: any;
  @Input() inner?: boolean;

  public label: string;
  public style: string;
  public hasNoDataWrapping: boolean;
  public url: string;
  public rel: string;

  constructor(private readonly trackingService: TrackingService,
              private readonly subjectService: SubjectService,
              private readonly pageNavigationUtil: PageNavigationUtilService,
              private readonly dataTypeService: DataTypeService,
              private readonly changeDetectorRef: ChangeDetectorRef,
              private readonly unsubscriber: Unsubscriber) {
  }

  ngOnInit() {
    if (this.column != null && this.row != null) {
      this.type = (!this.row['ROWTYPE'] || this.column.columnName === 'FIRSTCOL') ? this.column.columnType : this.row['ROWTYPE'];
      this.value = this.row[this.column.columnName];
      this.label = this.column.label;
      this.style = 'value' + (this.column.style == null ? '' : (` ${this.column.style}`)) + this.addDefaultStyles(this.row['alignment']);
      this.hasNoDataWrapping = this.column.noDataWrapping;
    } else {
      this.label = '';
      this.style = 'value' + this.addDefaultStyles(null);
      this.hasNoDataWrapping = false;
    }

    this.rel = 'noreferrer noopener nofollow';
    this.createUrl();
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public getBaseType(): string {
    return this.dataTypeService.getBaseType(this.type, this.value);
  }

  public getOuterType(): string {
    return this.dataTypeService.getOuterType(this.type);
  }

  public getInnerType(): string {
    return this.dataTypeService.getInnerType(this.type);
  }

  public getTypeFromSpecified(): string {
    return this.value == null ? DataTypeService.baseString : this.dataTypeService.getTypeFromSpecified(this.value);
  }

  private getValue(): any {
    return this.dataTypeService.getValue(this.type, this.value);
  }

  private addDefaultStyles(alignmentClass: string): string {
    const baseTypeAndValue = this.dataTypeService.getBaseTypeAndValue(this.type, this.value);
    const baseType = baseTypeAndValue.type;
    const baseValue = baseTypeAndValue.value;
    const possiblyNegative = DataTypeService.possiblyNegativeBaseTypes.some(possiblyNegativeBaseType => possiblyNegativeBaseType === baseType);

    let styles = ' ' + (alignmentClass ? alignmentClass : this.dataTypeService.getDefaultAlignment(this.type, this.value));

    if (possiblyNegative && !isNaN(baseValue) && baseValue < 0) {
      styles = styles + ' negative';
    }

    if (this.hasClickEvent()) {
      styles = styles + ' click-event';
    }

    if (this.hasDrillDown()) {
      styles = styles + ' drilldown';
    }

    return styles;
  }

  public handleMouseClick(event: MouseEvent): void {
    if (event.button === 0 && !event.ctrlKey) {
      event.preventDefault();

      if (this.hasDrillDown()) {
        this.goToDetailsPage();
      } else if (this.hasPageLink()) {
        this.followPageLink();
      } else if (this.hasSearchLink()) {
        this.followSearchLink();
      } else if (this.hasFileLink()) {
        this.downloadFile();
      } else if (this.hasScrollLink()) {
        this.scrollToWidget();
      }
    }
  }

  private goToDetailsPage(): void {
    const detailsPageId = this.getDetailsPage();
    const filter = this.getDetailsFilter();

    this.trackingService.trackEvent('klik', `Klik doorsturen:${this.side}/tab van:${this.pageId}/widget van:${this.widgetId}/tab naar:${detailsPageId}`, null, null);
    this.pageNavigationUtil.updateBreadcrumb(this.side, this.widgetId, this.domainId, this.pageId, detailsPageId);
    this.pageNavigationUtil.navigateToPage(this.side, detailsPageId, filter);
  }

  private followPageLink(): void {
    const target = this.value.target;

    if (target === 'externalLink') {
      const url = this.pageNavigationUtil.replaceTemplateIfPresent(this.domainId, this.value.url);
      this.trackingService.trackEvent('klik', 'Open external link', url, null);
      const win = window.open(url, '_blank', PageNavigationUtilService.urlFeatures);
      win.focus();
    } else {
      const targetSide = (target === 'currentSide') ? this.side : 'right';
      const targetPageId = this.value.page != undefined ? this.value.page : this.pageId;
      const filter = this.value.filter != undefined ? this.value.filter : {};

      if (this.side === targetSide) {
        this.trackingService.trackEvent('klik', `Klik doorsturen:${this.side}/tab van:${this.pageId}/widget van:${this.widgetId}/tab naar:${targetPageId}`, null, null);
      }
      this.pageNavigationUtil.navigate(this.side, targetSide, targetPageId, filter);
    }
  }

  private followSearchLink(): void {
    this.getSearchLinkSubject$().subscribe({
      next: subject => {
        const targetPageId = this.value.page != undefined ? this.value.page : this.pageId;
        this.pageNavigationUtil.navigate(this.side, 'right', targetPageId, subject.filter);
      },
      error: error => {
        console.log('Bij het gebruik van een SearchLink is de volgende fout opgetreden:');
        console.log(error);
      }
    });
  }

  private downloadFile(): void {
    const url = this.getFileUrl();

    if (url != null) {
      const win = window.open(url, '_blank', PageNavigationUtilService.urlFeatures);
      win.focus();
    }
  }

  private scrollToWidget(): void {
    const container = document.querySelector(`.${this.side} #${this.side}_${this.value.widget}`);
    if (container) {
      container.scrollIntoView(true);
    }
  }

  private createUrl(): void {
    if (this.hasDrillDown()) {
      this.createDrilldownUrl();
    } else if (this.hasPageLink()) {
      this.createPageLinkUrl();
    } else if (this.hasSearchLink()) {
      this.createSearchLinkUrl();
    } else if (this.hasFileLink()) {
      this.createFileUrl();
    }
  }

  private getPageLinkUrl(): string {
    const target = this.value.target;

    if (target === 'externalLink') {
      return this.pageNavigationUtil.replaceTemplateIfPresent(this.domainId, this.value.url);
    } else {
      this.rel = '';
      const pageId = this.value.page != undefined ? this.value.page : this.pageId;
      const filter = this.value.filter != undefined ? this.value.filter : {};
      return this.pageNavigationUtil.getUrl(this.side, pageId, filter);
    }
  }

  private getFileUrl(): string {
    const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/gi;

    if (this.value != null && Object.prototype.hasOwnProperty.call(this.value, 'url')) {
      return encodeLastUriSegment(this.value['url']);
    } else if (this.value.match(urlRegex)) {
      return this.value;
    }

    return null;
  }

  private createDrilldownUrl(): void {
    this.url = this.pageNavigationUtil.getUrl(this.side, this.getDetailsPage(), this.getDetailsFilter());
  }

  private createPageLinkUrl(): void {
    this.url = this.getPageLinkUrl();
  }

  private createSearchLinkUrl(): void {
    this.getSearchLinkSubject$()
      .pipe(take(1))
      .subscribe({
        'next': subject => {
          const targetPageId = this.value.page != undefined ? this.value.page : this.pageId;
          this.url = this.pageNavigationUtil.getUrl(this.side, targetPageId, subject.filter);
          this.changeDetectorRef.detectChanges();
        },
        'error': error => console.error(`Error occurred when searching for a SEARCHLINK subject (${error})`)
      });
  }

  private createFileUrl(): void {
    this.url = this.getFileUrl();
  }

  private getSearchLinkSubject$(): Observable<any> {
    const filter = this.value.filter != undefined ? this.value.filter : {};
    const domainId: string = this.domainId;
    const filterKeys: string[] = Object.keys(filter);
    const type: string = filterKeys && filterKeys.length > 0 ? filterKeys[0] : '';
    const subjectNr: string = filter && filter[type] ? filter[type] : '';

    return this.subjectService.getSubjects(domainId, type, subjectNr)
      .pipe(
        this.unsubscriber.takeUntilForUnsubscribe,
        map((subjects: Subject[]) => subjects.filter((subject: Subject) => subject.model[type])),
        mergeMap((subjects: Subject[]) => {
          if (subjects && subjects.length === 1) {
            const subject = subjects[0];
            const modelKeys: string[] = Object.keys(subject.model);
            modelKeys.forEach(key => filter[key] = subject.model[key]);

            return of({
              filter: filter
            });
          } else {
            return throwError(() => new Error(`Bij het gebruik van een SearchLink voor ${type} ${subjectNr} is er geen of meer ` +
              `dan 1 zoekresultaat. Hierdoor kan niet worden bepaald met welk zoekresultaat gewerkt moet worden.`));
          }
        })
      );
  }

  public isBaseType(): boolean {
    return this.dataTypeService.isBaseType(this.type);
  }

  public isSpecifiedType(): boolean {
    return this.dataTypeService.isSpecifiedType(this.type);
  }

  public isDrillDownType(): boolean {
    return this.dataTypeService.isDrillDownType(this.type);
  }

  public isPageLinkType(): boolean {
    return this.dataTypeService.isPageLinkType(this.type);
  }

  public isSearchLinkType(): boolean {
    return this.dataTypeService.isSearchLinkType(this.type);
  }

  public isColoredType(): boolean {
    return this.dataTypeService.isColoredType(this.type);
  }

  public isAnnotatedType(): boolean {
    return this.dataTypeService.isAnnotatedType(this.type);
  }

  public isExpandType(): boolean {
    return this.dataTypeService.isExpandType(this.type);
  }

  public isFootnotedType(): boolean {
    return this.dataTypeService.isFootnotedType(this.type);
  }

  public isTrendType(): boolean {
    return this.dataTypeService.isTrendType(this.type);
  }

  public isFileLinkType(): boolean {
    return this.dataTypeService.isFileLinkType(this.type);
  }

  public isScrollLinkType(): boolean {
    return this.dataTypeService.isScrollLinkType(this.type);
  }

  public hasDrillDown(): boolean {
    return this.isDrillDownType() && this.value.detail;
  }

  public hasValue(): boolean {
    const value = this.getValue();
    return value != null && value !== '';
  }

  public hasPageLink(): boolean {
    return this.isPageLinkType() && this.value && this.value.value && this.value.target && this.value.target !== 'none';
  }

  public hasSearchLink(): boolean {
    return this.isSearchLinkType() && this.value && this.value.value && this.value.target && this.value.target !== 'none';
  }

  public hasAnnotation(): boolean {
    return this.isAnnotatedType() && this.value.tooltip;
  }

  public hasFileLink(): boolean {
    return this.isFileLinkType() && this.value && this.value.url;
  }

  public hasScrollLink(): boolean {
    return this.isScrollLinkType() && this.value.widget;
  }

  public getDetailsPage(): string {
    return this.value.detail;
  }

  public getDetailsFilter(): any {
    return this.value.filter;
  }

  public getAnnotation(): string {
    return this.value.Tooltip;
  }

  public getFootnote(): string {
    return this.value.footnote;
  }

  getTooltipPosition(style: string): boolean {
    return style.includes('right');
  }

  public getTrendIcon(): string {
    const value = Object.prototype.hasOwnProperty.call(this.value, 'revision') ? this.value.revision : this.value.Correctie;
    return (value === 1 || value === '1' || value === 'J') ? 'trendicon bd_lens' : '';
  }

  private hasClickEvent(): boolean {
    return this.hasDrillDown() || this.hasPageLink() || this.hasSearchLink() || this.hasFileLink() || this.hasScrollLink();
  }

  public getAnnotatedIcon(): any {
    if(!this.value.icon) {
      this.value.icon = 'bd_info_outline';
    }
    return this.value.icon;
  }

  public getAnnotatedIconColor(): string {
    return !this.value.color ? 'inherit' : this.value.color;
  }
}
