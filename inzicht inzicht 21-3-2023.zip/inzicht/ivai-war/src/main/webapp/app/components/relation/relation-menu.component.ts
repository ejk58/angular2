import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import * as fromStore from '@inzicht/store';
import {Subject} from '@inzicht/classes/subject';
import {PathKey} from '@inzicht/classes/path-key';

@Component({
  selector: 'i-relation-menu',
  templateUrl: './relation-menu.component.html',
  styleUrls: ['./relation-menu.component.scss'],
  providers: [Unsubscriber]
})
export class RelationMenuComponent implements OnInit, OnDestroy {

  @Input() side: any;
  @Output() selected: EventEmitter<boolean> = new EventEmitter<boolean>();

  public relations$: Observable<any>;
  public error$: Observable<string>;
  public loading$: Observable<boolean>;

  public filterValue: string;
  public params: any;
  public selectedSubject: Subject;

  constructor(private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) {}

  ngOnInit(): void {
    this.filterValue = '';
    this.relations$ = this.store.select(fromStore.getRelations(this.side));
    this.loading$ = this.store.select(fromStore.getRelationLoading(this.side));
    this.error$ = this.store.select(fromStore.getRelationError(this.side));

    this.store.select(fromStore.selectSelectedSubject(this.side))
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeSubject => this.selectedSubject = activeSubject,
        error: error => console.error(`Error while getting selected subject (${error})`)
      });

    this.store.select(fromStore.getRouterSides)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: routerSides => {
          if (this.side && routerSides && routerSides[this.side]) {
            this.params = routerSides[this.side];
          }
        },
        error: error => console.error(`Error while handling router sides (${error})`)
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public switchToRelation(relation: Subject): void {
    const domain = this.store.selectSync(fromStore.getActiveDomain(this.side));

    this.store.dispatch(fromStore.selectDomainWithSubject({
      side: this.side,
      domain: domain,
      subject: relation,
      params: this.constructParams(relation.model, domain.pathKeys)
    }));
  }

  private constructParams(subjectModel: Object, pathKeys: PathKey[]): any {
    const params: any = {};
    pathKeys.filter(pathKey => pathKey.mandatory).forEach(pathKey => params[pathKey.name] = subjectModel[pathKey.name]);
    return params;
  }
}
