import {Component, Input, ChangeDetectionStrategy} from '@angular/core';
import {ReleaseNote} from '@inzicht/commons/release-note';

@Component({
  selector: 'i-release-note',
  templateUrl: './release-note.component.html',
  styleUrls: ['./release-note.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ReleaseNoteComponent {
  @Input() releaseNote: ReleaseNote;
}
