import { Component, ChangeDetectionStrategy, Input, OnChanges, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromStore from '@inzicht/store';
import { TabsComponent } from '@inzicht/components/tabs/tabs.component';
import { Side } from '@inzicht/commons/side';


@Component({
  selector: 'i-stateful-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StatefulTabsComponent extends TabsComponent implements OnInit, OnChanges {

  @Input() side: Side;
  @Input() name: string;

  constructor(private readonly store: Store) {
    super();
  }

  ngOnInit(): void {
    this.getActiveTabFromWidgetState();
  }

  ngOnChanges(): void {
    this.getActiveTabFromWidgetState();
  }

  public autoSelectTab(i: number): void {
    super.selectTab(i, true);
  }

  public selectTab(i: number): void {
    super.selectTab(i, false);
    this.storeCurrentTab();
  }

  private storeCurrentTab(): void {
    this.store.dispatch(fromStore.updateWidgetState({ 'side': this.side, 'widgetId': this.name, 'state': { 'selectedTab': this.activeTab } }));
  }

  private getActiveTabFromWidgetState(): void {
    if (this.side && this.name) {
      const initialWidgetState = this.store.selectSync(fromStore.getWidgetState(this.side, this.name));
      if (initialWidgetState && initialWidgetState.selectedTab) {
        this.autoSelectTab(initialWidgetState.selectedTab);
      }
    }
  }
}
