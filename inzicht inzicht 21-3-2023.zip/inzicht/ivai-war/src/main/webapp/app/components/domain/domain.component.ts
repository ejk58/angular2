import {Component, Input, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import * as fromStore from '@inzicht/store';
import {Side} from '@inzicht/commons/side';
import {Domain} from '@inzicht/classes/domain';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';

@Component({
  selector: 'i-domain',
  templateUrl: './domain.component.html',
  styleUrls: ['./domain.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})
export class DomainComponent implements OnInit, OnDestroy {

  @Input() side: Side;

  public readonly browserIsIE = /trident\//i.test(window.navigator.userAgent);

  public domainMenu$: Observable<Domain[]>;
  public domainMenuLoading$: Observable<boolean>;
  public domainMenuError$: Observable<number>;
  public username: string;
  public loading: boolean;
  public activeDomainId: string;

  constructor(private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    // Scroll top the domainMenu on start
    const domainContainer = document.getElementById('domain');
    setTimeout(() => domainContainer.scrollTop = 0, 300);

    this.domainMenu$ = this.store.select(fromStore.getDomainMenuOptions);
    this.domainMenuLoading$ = this.store.select(fromStore.getConfigLoading);
    this.domainMenuError$ = this.store.select(fromStore.getConfigErrorCode);

    this.store.select(fromStore.getActiveDomainId(this.side))
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeDomainId => this.activeDomainId = activeDomainId,
        error: error => console.error(`Error occurred while getting active domain (${error})`)
      });
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public selectDomain(domain: Domain): void {
    if (domain.subjectTypes.length === 0) {
      this.store.dispatch(fromStore.selectDomainWithoutSubject({side: this.side, domain: domain, subject: null}));
    }
  }

  public getActiveClass(domain: Domain): string {
    return this.activeDomainId === domain.domainId ? 'domain-active' : '';
  }
}
