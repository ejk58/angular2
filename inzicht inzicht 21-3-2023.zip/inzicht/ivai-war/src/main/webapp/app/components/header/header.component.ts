import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';

import {Store} from '@ngrx/store';
import {combineLatest, Observable} from 'rxjs';
import {catchError, distinctUntilChanged, map} from 'rxjs/operators';

import {SplitWidth} from '@inzicht/classes/split-width';
import {AuthenticationService} from '@inzicht/services/authentication.service';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import * as fromStore from '@inzicht/store';
import {HelpState} from '@inzicht/services/help.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {Subject} from '@inzicht/classes/subject';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {Domain} from '@inzicht/classes/domain';

interface ViewModel {
  activeDomain: Domain,
  selectedSubject: Subject,
  currentRoute: string,
  splitWidth: SplitWidth,
  searchOptionEnabled: boolean,
  subjectMenuEnabled: boolean,
  relationMenuEnabled: boolean
}

@Component({
  selector: 'i-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [Unsubscriber]
})
export class HeaderComponent implements OnInit, OnDestroy {
  vm$!: Observable<ViewModel>;

  @Input() side: any;
  @Output() secondScreenActive: EventEmitter<boolean> = new EventEmitter<boolean>();

  public readonly accountMenuOptions = [
    { label: 'Feedback', icon: 'bd_chat_bubble_outline', command: this.openFeedbackInSidebar.bind(this), selected: false },
    { label: 'Uitloggen', icon: 'bd_lock_open', command: this.logout.bind(this), selected: false }
  ];

  public view: any;
  public username: any;
  public loading: boolean;
  public selectedSubject: Subject;
  public hasSearchPage: boolean;

  private headerState: string;

  constructor(public readonly splitViewState: SplitViewState,
              private readonly route: ActivatedRoute,
              private readonly auth: AuthenticationService,
              private readonly pageNavigationUtil: PageNavigationUtilService,
              private readonly helpState: HelpState,
              private readonly trackingService: TrackingService,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    const activeDomain$: Observable<Domain> = this.store.select(fromStore.getActiveDomain(this.side));
    const activeMenu$: Observable<string> = this.store.select(fromStore.selectActiveMenu(this.side));
    const selectedSubject$: Observable<Subject> = this.store.select(fromStore.selectSelectedSubject(this.side));
    const currentRoute$: Observable<Params> = this.route.params;
    const splitWidth$: Observable<SplitWidth> = this.splitViewState.listenSizes();

    // Leave unused currentRoute in the map function as part of the returned combineLatest array.
    this.vm$ = combineLatest([
      activeDomain$,
      activeMenu$,
      selectedSubject$,
      currentRoute$,
      splitWidth$
    ]).pipe(
      distinctUntilChanged(),
      this.unsubscriber.takeUntilForUnsubscribe,
      map(([activeDomain, headerState, selectedSubject, currentRoute, splitWidth]) => {
        const splitWidthDef = (splitWidth != null) ? splitWidth : SplitWidth.default;
        const onLoginScreen = currentRoute === 'login';
        const hasDomainSubjectTypes = activeDomain?.subjectTypes.length > 0;
        const hasSelectedSubject = selectedSubject != undefined;
        const hasSearchPage = (activeDomain == null) ? false : (this.store.selectSync(fromStore.getSearchPageInDomain(activeDomain.domainId)) != undefined);
        const hasHiddenRelationMenu = activeDomain?.attributes?.hideRelationMenu === 'true';

        this.headerState = headerState;
        this.selectedSubject = selectedSubject;
        this.hasSearchPage = hasSearchPage;

        return {
          activeDomain: activeDomain,
          selectedSubject: selectedSubject,
          currentRoute: this.route.snapshot.url[0].path,
          splitWidth: splitWidthDef,
          searchOptionEnabled: !onLoginScreen && (hasSearchPage || hasDomainSubjectTypes),
          subjectMenuEnabled: !onLoginScreen && hasSelectedSubject,
          relationMenuEnabled: !onLoginScreen && hasSelectedSubject && !hasHiddenRelationMenu
        };
      }), catchError((error): Observable<ViewModel> => {
        console.error(`Error occurred while getting information (${error})`);
        return null;
      }));
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public isDomainSelected(activeDomain: Domain): boolean {
    return activeDomain !== null;
  }

  public isDomainMenuOpened(): boolean {
    return this.side && this.headerState === 'domain';
  }

  public isPageMenuOpened(): boolean {
    return this.side && this.headerState === 'page';
  }

  public isRelationMenuOpened(): boolean {
    return this.side && this.headerState === 'relation';
  }

  public isSubjectMenuOpened(): boolean {
    return this.side && this.headerState === 'subject';
  }

  public isAccountMenuOpened(): boolean {
    return this.side && this.headerState === 'account';
  }

  public selectAccountOption(index: number): void {
    for (let i = 0; i < this.accountMenuOptions.length; i++) {
      this.accountMenuOptions[i].selected = false;
    }
    this.accountMenuOptions[index].selected = true;
    this.accountMenuOptions[index].command();
  }

  private openFeedbackInSidebar(): void {
    this.trackingService.trackEvent('klik',
      `Klik feedback:${this.side}`, null, null);
    this.store.dispatch(fromStore.sidebarOpen({type: 'feedback'}));
    this.switchMenu('default');
  }

  public switchMenu(selectedMenu: string): void {
    const menuChanged = selectedMenu !== this.headerState;
    const menuClicked = selectedMenu !== 'default'; // clicking the same button twice toggles the menu
    const searchOptionClicked = selectedMenu === 'subject';

    if (searchOptionClicked && this.hasSearchPage) {
      this.pageNavigationUtil.navigateToSearchPage(this.side, null);
    } else if (menuChanged) {
      this.store.dispatch(fromStore.headerSelectMenu({ side: this.side, menu: selectedMenu }));
      if (this.selectedSubject && menuClicked) {
        this.trackingService.trackEvent('klik',
          `Klik ${selectedMenu}:${this.side}/open met icoon`,
          null, this.selectedSubject['subjectNr']);
      }
    } else if (menuClicked) {
      this.store.dispatch(fromStore.headerSelectMenu({ side: this.side, menu: 'default' }));
    }
  }

  public closeSecondScreen() {
    let subject: string;
    if (this.selectedSubject) {
      subject = this.selectedSubject['subjectNr'];
    }
    this.trackingService.trackEvent('klik',
      `Klik close:${this.side}/icoon close`,
      null, subject);
    this.secondScreenActive.emit(true);
  }

  logout() {
    this.auth.logout();
  }

  openHelpInSidebar() {
    const helpTexts = this.helpState.generalHelp;
    let subject: string;
    if (this.selectedSubject) {
      subject = this.selectedSubject['subjectNr'];
    }
    this.switchMenu('default');
    this.trackingService.trackEvent('klik',
      `Klik help:${this.side}/manier: icoon help`,
      null, subject);
    this.helpState.emitHelpText(helpTexts);
    this.store.dispatch(fromStore.sidebarOpen({type: 'help'}));
  }

  onClickedOutside(e: Event, currentRoute: string) {
    if (currentRoute !== 'login') {
      this.switchMenu('default');
    }
  }
}
