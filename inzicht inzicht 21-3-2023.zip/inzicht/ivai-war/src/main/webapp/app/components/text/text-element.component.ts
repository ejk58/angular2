import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewEncapsulation
} from '@angular/core';
import {Block, BlockType} from './block';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';

@Component({
  selector: 'i-text-element',
  templateUrl: './text-element.component.html',
  styleUrls: ['./text-element.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class TextElementComponent implements OnInit {

  @Input() block: Block;
  @Input() side: string;
  @Output() action: EventEmitter<[Block, MouseEvent]> = new EventEmitter<[Block, MouseEvent]>();

  public components: Block[];
  public text: string;
  public style: string;
  public readMore: boolean;

  constructor(private readonly pageNavigationUtil: PageNavigationUtilService) { }

  ngOnInit(): void {
    this.components = [];
    this.text = null;
    this.style = this.block.style + (this.hasClickEvent() ? ' click-event' : '');
    this.readMore = false;

    if (Array.isArray(this.block.text)) {
      this.components = this.block.text;
    } else if (this.block.text != null && typeof this.block.text === 'object') {
      this.components = [this.block.text];
    } else {
      this.text = this.block.text != null ? String(this.block.text) : null;
    }
  }

  public handleMouseClick(event: MouseEvent): boolean {
    if (this.hasClickEvent() && event.button === 0 && !event.ctrlKey) {
      event.preventDefault();
      this.action.emit([this.block, event]);
      return false;
    }

    return true;
  }

  public handleAction(action: [Block, MouseEvent]): void {
    this.action.emit(action);
  }

  public hasClickEvent(): boolean {
    return (this.block.type === BlockType.linkType || this.block.type === BlockType.buttonType) && !this.block['disabled'];
  }

  public toggleReadMoreLess(): void {
    this.readMore = !this.readMore;
  }

  public isButtonStyle(): boolean {
    return this.block.style.startsWith('text text-link button');
  }

  public createHref(): string {
    const filter = this.block.model;
    const page: string = this.block.page.toString();
    return this.pageNavigationUtil.getUrl(this.side, page, filter);
  }
}
