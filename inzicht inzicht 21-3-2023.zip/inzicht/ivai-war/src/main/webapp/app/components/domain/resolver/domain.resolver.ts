import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {Store} from '@ngrx/store';
import * as fromStore from '@inzicht/store';

@Injectable()
export class DomainResolver implements Resolve<void> {

  constructor(private readonly store: Store) { }

  resolve() {
    this.store.dispatch(fromStore.loadConfig());
  }
}
