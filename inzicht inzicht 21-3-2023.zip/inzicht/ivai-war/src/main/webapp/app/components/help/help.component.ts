import {Component, Input, OnInit, OnChanges, SimpleChanges} from '@angular/core';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {selectSidebarState} from '@inzicht/store/sidebar/sidebar.selectors';
import TabSelectionEvent from '@inzicht/commons/tab-selection-event';

@Component({
  selector: 'i-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss']
})
export class HelpComponent implements OnInit, OnChanges {

  @Input() helpTexts: any;

  public helpTextTitles: string[] = [];
  public activeTab: number = 0;
  public sidebarState$: Observable<any>;

  constructor(private readonly store: Store) { }

  ngOnInit(): void {
    this.sidebarState$ = this.store.select(selectSidebarState);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.helpTexts) {
      this.helpTextTitles = this.helpTexts.texts ? this.helpTexts.texts.map(ht => ht.title) : [];
    }
  }

  selectTab(event: TabSelectionEvent) {
    this.activeTab = event.tab;
  }
}
