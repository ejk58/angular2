import {WidgetDataFilter} from './widget-data-filter';

describe('WidgetDataFilter', () => {

  describe('extractwidgetColumnFilters', () => {
    it('should extract the correct column filters from the clientDataFilters-attributen in the widget configuration', () => {
      const clientDataFilterAttribute = '[{"column": "first", "operator": "differsFrom", "filterKey": "color"}, ' +
        '{"column": "second", "operator": "isLargerThanOrEquals", "filterKey": "lineNumber"}, ' +
        '{"column": "third", "operator": "equals", "filterKey": "amount"}, ' +
        '{"column": null, "operator": "ignores", "filterKey": "year"}]';
      const rawData = {'options': {'clientDataFilters': clientDataFilterAttribute}};
      const widgetDataFilter = new WidgetDataFilter();

      const result = widgetDataFilter.extractWidgetColumnFilters(rawData);

      expect(result.length).toEqual(4);
      expect(result[0].column).toEqual('first');
      expect(result[0].operator).toEqual('differsFrom');
      expect(result[0].filterKey).toEqual('color');
      expect(result[1].column).toEqual('second');
      expect(result[1].operator).toEqual('isLargerThanOrEquals');
      expect(result[1].filterKey).toEqual('lineNumber');
      expect(result[2].column).toEqual('third');
      expect(result[2].operator).toEqual('equals');
      expect(result[2].filterKey).toEqual('amount');
      expect(result[3].column).toBeNull();
      expect(result[3].operator).toEqual('ignores');
      expect(result[3].filterKey).toEqual('year');
    });

    it('should extract nothing from the widget configuration without a clientDataFilters-attribute', () => {
      const rawData = {'options': {'name': 'WIDGET_WITHOUT_FILTERS'}};
      const widgetDataFilter = new WidgetDataFilter();

      const result = widgetDataFilter.extractWidgetColumnFilters(rawData);

      expect(result.length).toEqual(0);
    });
  });

  describe('filterWidgetData', () => {
    function createRawData(widgetType: string, clientDataFilters: any): any {
      return {
        'type': widgetType,
        'options': {'columns': {'nr': {'columnType': 'NUMBER'}, 'first': {'columnType': 'STRING'}, 'second': {'columnType': 'NUMBER'}, 'third': {'columnType': 'NUMBER'}, 'fourth': {'columnType': 'DATE'}}, 'clientDataFilters': clientDataFilters},
        'data': [
          {'nr': 0, 'first': 'red', 'second': 10, 'third': 100, 'fourth': new Date(2020, 0, 1)},
          {'nr': 1, 'first': 'green', 'second': 20, 'third': 450, 'fourth': new Date(2020, 5, 30)},
          {'nr': 2, 'first': 'blue', 'second': null, 'third': 90, 'fourth': new Date(2020, 11, 31)}
        ]
      };
    }

    function testRowsInResult(result: any, rowIds: number[]): void {
      expect(result.length).toEqual(rowIds.length);
      rowIds.forEach((rowId, index) => expect(result[index].nr).toEqual(rowId));
    }

    function testOperatorWithoutFilterValue(operator: string): void {
      const rawData = createRawData('Table', '[{"column": "third", "operator": "' + operator + '", "filterKey": "amount"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0, 1, 2]);
    }

    it('should not filter the data if the clientDataFilters-attribute is undefined', () => {
      const rawData = createRawData('Table', undefined);
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0, 1, 2]);
    });

    it('should not filter the given column with the "ignores"-operator', () => {
      const rawData = createRawData('Table', '[{"column": null, "operator": "ignores", "filterKey": "color"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0, 1, 2]);
    });

    it('should filter the given column with the "equals"-operator and the filter value from the router-state', () => {
      const rawData = createRawData('Table', '[{"column": "first", "operator": "equals", "filterKey": "color"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'color': 'red'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0]);
    });

    it('should filter the given column with the "equals"-operator and the filter value from the filter-object', () => {
      const rawData = createRawData('Table', '[{"column": "first", "operator": "equals", "filterKey": "color"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const filter = {'color': 'green'};

      const filteredData = widgetDataFilter.filterWidgetData(null, filter, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [1]);
    });

    it('should not filter the given column with the "equals"-operator and no filter value from the router-state', () => {
      testOperatorWithoutFilterValue('equals');
    });

    it('should filter the given column with the "differsFrom"-operator and the filter value from the router-state', () => {
      const rawData = createRawData('Table', '[{"column": "first", "operator": "differsFrom", "filterKey": "color"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'color': 'red'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [1, 2]);
    });

    it('should filter the given column with the "differsFrom"-operator and the filter value from the filter-object', () => {
      const rawData = createRawData('Table', '[{"column": "first", "operator": "differsFrom", "filterKey": "color"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const filter = {'color': 'green'};

      const filteredData = widgetDataFilter.filterWidgetData(null, filter, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0, 2]);
    });

    it('should not filter the given column with the "differsFrom"-operator and no filter value from the router-state', () => {
      testOperatorWithoutFilterValue('differsFrom');
    });

    it('should filter the given column with the "isSmallerThan"-operator and the filter value from the router-state', () => {
      const rawData = createRawData('Table', '[{"column": "third", "operator": "isSmallerThan", "filterKey": "amount"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'amount': '100'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [2]);
    });

    it('should not filter the given column with the "isSmallerThan"-operator and no filter value from the router-state', () => {
      testOperatorWithoutFilterValue('isSmallerThan');
    });

    it('should filter the given column with the "isSmallerThanOrEquals"-operator and the filter value from the router-state', () => {
      const rawData = createRawData('Table', '[{"column": "third", "operator": "isSmallerThanOrEquals", "filterKey": "amount"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'amount': '100'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0, 2]);
    });

    it('should not filter the given column with the "isSmallerThanOrEquals"-operator and no filter value from the router-state', () => {
      testOperatorWithoutFilterValue('isSmallerThanOrEquals');
    });

    it('should filter the given column with the "isLargerThan"-operator and the filter value from the router-state', () => {
      const rawData = createRawData('Table', '[{"column": "third", "operator": "isLargerThan", "filterKey": "amount"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'amount': '100'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [1]);
    });

    it('should not filter the given column with the "isLargerThan"-operator and no filter value from the router-state', () => {
      testOperatorWithoutFilterValue('isLargerThan');
    });

    it('should filter the given column with the "isLargerThanOrEquals"-operator and the filter value from the router-state', () => {
      const rawData = createRawData('Table', '[{"column": "third", "operator": "isLargerThanOrEquals", "filterKey": "amount"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'amount': '100'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0, 1]);
    });

    it('should not filter the given column with the "isLargerThanOrEquals"-operator and no filter value from the router-state', () => {
      testOperatorWithoutFilterValue('isLargerThanOrEquals');
    });

    it('should convert a correct filter value of type DATE from the router-state before filtering the data', () => {
      const rawData = createRawData('Table', '[{"column": "fourth", "operator": "isLargerThanOrEquals", "filterKey": "startDate"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'startDate': '2020-06-30'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [1, 2]);
    });

    it('should not convert an incorrect filter value of type DATE from the router-state before filtering the data', () => {
      const rawData = createRawData('Table', '[{"column": "fourth", "operator": "isLargerThanOrEquals", "filterKey": "startDate"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'startDate': '19-06-20'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, []);
    });

    it('should filter the data with two operators filtering the same column', () => {
      const rawData = createRawData('Table', '[{"column": "third", "operator": "isSmallerThanOrEquals", "filterKey": "amount"}, {"column": "third", "operator": "isLargerThanOrEquals", "filterKey": "amount"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'amount': '100'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0]);
    });

    it('should filter the data with two operators filtering different columns', () => {
      const rawData = createRawData('Table', '[{"column": "first", "operator": "differsFrom", "filterKey": "color"}, {"column": "third", "operator": "isSmallerThanOrEquals", "filterKey": "amount"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'color': 'red', 'amount': '100'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [2]);
    });

    it('should skip the first row for FlexibleTable widgets when filtering the data', () => {
      const rawData = createRawData('FlexibleTable', '[{"column": "first", "operator": "equals", "filterKey": "color"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'color': 'yellow'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0]);
    });

    it('should skip the first two rows for FlexibleCollapsibleTable widgets when filtering the data', () => {
      const rawData = createRawData('FlexibleCollapsibleTable', '[{"column": "first", "operator": "equals", "filterKey": "color"}]');
      const widgetDataFilter = new WidgetDataFilter();
      const columnFilters = widgetDataFilter.extractWidgetColumnFilters(rawData);
      const routerState = {'color': 'yellow'};

      const filteredData = widgetDataFilter.filterWidgetData(routerState, null, columnFilters, rawData);
      const result = filteredData.data;

      testRowsInResult(result, [0, 1]);
    });
  });
});
