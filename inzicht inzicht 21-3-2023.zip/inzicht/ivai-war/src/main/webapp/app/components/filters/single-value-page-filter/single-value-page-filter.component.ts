import {Component, EventEmitter, Input, Output} from '@angular/core';

import {Filter} from '@inzicht/components/filters/filter';

@Component({
  selector: 'i-single-value-page-filter',
  templateUrl: './single-value-page-filter.component.html',
  styleUrls: ['./single-value-page-filter.component.scss']
})
export class SingleValuePageFilterComponent {

  @Input() filter: Filter;

  @Input() // See: https://angular.io/guide/component-interaction#intercept-input-property-changes-with-a-setter
  get selection(): string | number {
    return this.internalSelection;
  }

  set selection(selection: string | number) {
    if (!this.internalSelection || !selection) {
      this.internalSelection = selection;
    } else if (typeof (selection) !== typeof (this.internalSelection)) {
      if (typeof this.internalSelection === 'string') {
        this.internalSelection = String(selection);
      } else if (typeof this.internalSelection === 'number') {
        this.internalSelection = Number(selection);
      }
    } else {
      this.internalSelection = selection;
    }
  }

  @Output() selected: EventEmitter<string | number> = new EventEmitter<string | number>();

  public internalSelection: string | number;
  private separator: string = '<br>';

  public onChange(): void {
    this.selected.emit(this.internalSelection);
  }

  public containsSeparator(): boolean {
    return this.filter.options.some(option => option.label.toString().includes(this.separator));
  }

  public selectedLabel(selection: string): string {
    const option = this.filter.options.find(option => option.value === Number(selection));
    if (!option) {
      return null;
    }
    const selectedLabel = option.label.toString();
    return this.containsSeparator() ? selectedLabel.replace(this.separator, '-') : selectedLabel;
  }

  public splitOptionLabel(label: string): string[] {
    return label.includes(this.separator) ? label.split(this.separator) : [label, '-'];
  }
}
