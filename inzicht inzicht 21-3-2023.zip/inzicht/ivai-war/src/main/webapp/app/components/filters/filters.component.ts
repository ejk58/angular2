import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewEncapsulation} from '@angular/core';
import {ActivatedRoute, Params, Router} from '@angular/router';

import {Store} from '@ngrx/store';
import {forkJoin, Observable} from 'rxjs';
import {concatMap, filter, first, map} from 'rxjs/operators';

import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {WidgetService} from '@inzicht/services/widget.service';
import * as fromStore from '@inzicht/store';
import {Filter} from '@inzicht/components/filters/filter';
import {Message} from '@inzicht/classes/message';
import {FilterOption} from '@inzicht/components/filters/filter-option';
import {FilterValue} from '@inzicht/components/filters/filter-value';
import {RouterState} from '@inzicht/classes/router-state';
import {matchToYyyyMmDd, dateToYyyyMmDd, yyyyMmDdToDate} from '@inzicht/commons/date-functions';
import {FilterWidget, FilterWidgetData, FilterWidgetOptions} from '@inzicht/classes/filterWidget';

interface FilterWidgetInfo {
  name: string,
  title: string,
  visible: boolean
}

@Component({
  selector: 'i-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [Unsubscriber]
})
export class FiltersComponent implements OnDestroy, OnInit {

  private static readonly filtersErrorMessageText = 'Er is een fout opgetreden bij het laden van de pagina-filters';

  @Input() widgetId: string;
  @Input() side: string;
  @Input() isFixed: boolean;

  @Output() globalFilterLoaded: EventEmitter<number> = new EventEmitter<number>();

  public filters: Filter[];
  public pageSize: number;
  public filtersLoading: boolean;
  public filtersError: Message;
  public filtersOpen: boolean;

  private filterWidgetInfos: Array<FilterWidgetInfo> = [];
  private pageId: string;
  private domainId: string;

  constructor(private readonly route: ActivatedRoute,
              private readonly router: Router,
              private readonly widgetService: WidgetService,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService,
              private readonly unsubscriber: Unsubscriber,
              private readonly store: Store) {
  }

  ngOnInit(): void {
    this.initSplitViewSizesListener();
    this.initFilters();
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public onFilterChange(filter: Filter, newValue: FilterValue): void {
    this.trackingService.trackEvent('filter', `Filter globaal:${this.side}/gewijzigd:${filter.label}`, null, null);
    filter.selection = newValue;
    this.setFilterStateInUrl(false);
  }

  public selectionAsStringOrNumber(selection: FilterValue): string | number {
    return selection as (string | number);
  }

  public selectionAsStringOrNumberArray(selection: FilterValue): (string | number)[] {
    return selection as ((string | number)[]);
  }

  public selectionAsDate(selection: FilterValue): Date {
    return selection as Date;
  }

  private initSplitViewSizesListener(): void {
    this.splitViewState.listenSizes().pipe(
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe({
      next: sizes => {
        if (sizes != null) {
          this.pageSize = sizes[this.side];
        } else {
          this.pageSize = 10000;
        }
      },
      error: error => {
        const errorCode = (error && error.statusCode) ? error.statusCode : Message.genericErrorCode;
        this.filtersError = new Message(errorCode, 'error', FiltersComponent.filtersErrorMessageText);
        console.error(`Error occurred while processing split view sizes (${error})`);
      }
    });
  }

  private initFilters(): void {
    this.filters = [];
    this.filtersLoading = true;

    this.widgetService.getWidget(this.widgetId, this.side, null).pipe(
      concatMap(response => {
        this.filterWidgetInfos = response.widgetData.options.widgets;
        const filterWidgets$ = this.filterWidgetInfos.map(this.getFilterWidget, this);
        const routerState$ = this.store.select(fromStore.getRouterSideState(this.side)).pipe(first());
        return forkJoin([routerState$, ...filterWidgets$]);
      }),
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe({
      next: ([routerState, ...filterWidgets]) => {
        this.domainId = routerState.domainId;
        this.pageId = routerState.pageId;
        const error = filterWidgets.find(filterWidget => filterWidget != null && filterWidget.error != null);

        if (error == null) {
          this.filters = filterWidgets
            .filter(filterWidget => filterWidget != null && filterWidget.widgetData != null)
            .map(filterWidget => this.createFilter(filterWidget.widgetData, routerState));

          this.addDefaultValueOrForcedSelectionToUrl();
          this.startUpdatingFiltersFromRouterState();
        } else {
          this.handleFilterError(error);
        }
      },
      error: error => {
        this.handleFilterError(error);
      }
    });
  }

  private getFilterWidget(filterWidgetInfo: FilterWidgetInfo) : Observable<any> {
    return this.widgetService.getWidget(filterWidgetInfo.name, this.side, null);
  }

  private handleFilterError(error: any): void {
    const errorCode = error.status ? error.status : Message.genericErrorCode;
    this.filtersError = new Message(errorCode, 'error', FiltersComponent.filtersErrorMessageText);
    this.reportGlobalFilterIsLoaded(errorCode);
  }

  private addDefaultValueOrForcedSelectionToUrl(): void {
    if (this.filters.some(filter => filter.forcedSelection || filter.defaultValue)) {
      this.setFilterStateInUrl(true);
    }
  }

  private startUpdatingFiltersFromRouterState(): void {
    this.store.select(fromStore.getRouterSideState(this.side)).pipe(
      filter((routerState: RouterState) => routerState && routerState.domainId === this.domainId && routerState.pageId === this.pageId),
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe({
      next: routerState => {
        this.filters.forEach(filter => this.setFilterSelectionBasedOnRouterState(filter, routerState, true));
        this.setFilterOptions();
      },
      error: error => console.error(`Error occurred while processing router state (${error})`)
    });
  }

  private setFilterOptions(): void {
    const newFilter = {};
    this.filters.forEach(filter => {
      if (filter.selection != undefined) {
        newFilter[filter.key] = filter.selection;
      }
    });
    forkJoin(
      this.filterWidgetInfos.map(filterWidgetInfo => this.widgetService.getWidget(filterWidgetInfo.name, this.side, newFilter))
    ).pipe(
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe({
      next: filterWidgetResponses => {
        filterWidgetResponses.forEach((filterWidgetResponse, i) => {
          const filterWidget = filterWidgetResponse.widgetData;
          this.filters[i].options = this.createOptions(filterWidget.data, filterWidget.options.unfilteredOption);
          this.addUnknownSelectionToFilterOptions(this.filters[i]);
        });
        this.reportGlobalFilterIsLoaded(0);
      },
      error: error => {
        const errorCode = error.status ? error.status : Message.genericErrorCode;
        this.filtersError = new Message(errorCode, 'error', FiltersComponent.filtersErrorMessageText);
        console.error(`Error occurred when retrieving filter widget info (${error})`);
        this.reportGlobalFilterIsLoaded(errorCode);
      }
    });
  }

  private addUnknownSelectionToFilterOptions(filter: Filter): void {
    if (filter.selection != undefined) {
      if (Array.isArray(filter.selection)) {
        filter.selection.forEach(selection => {
          if (!this.isSelectionAlreadyInFilterOptions(filter.options, selection)) {
            filter.options.push({label: <string>selection, value: selection});
          }
        });
      } else {
        if (!this.isSelectionAlreadyInFilterOptions(filter.options, filter.selection)) {
          filter.options.push({label: <string>filter.selection, value: filter.selection});
        }
      }
    }
  }

  private reportGlobalFilterIsLoaded(errorCode: number): void {
    this.filtersLoading = false;
    this.globalFilterLoaded.emit(errorCode);
  }

  private setFilterSelectionBasedOnRouterState(filter: Filter, routerState: Params, routerStateCanClearFilters: boolean): void {
    const routerFilterValue = routerState[filter.key];
    if (routerFilterValue != null || routerStateCanClearFilters) {
      if (filter.type === 'SingleValuePageFilter') {
        filter.selection = this.toSingleValueFilterValue(routerFilterValue);
      } else if (filter.type === 'MultiValuePageFilter') {
        filter.selection = this.toMultiValueFilterValue(routerFilterValue);
      } else {
        filter.selection = this.toDateFilterValue(routerFilterValue);
      }
    }
    // In case of a forcedSelection: initialize selection when undefined
    if (this.isFilterWithForcedSelectionAndUndefinedSelection(filter)) {
      if (filter.defaultValue) {
        filter.selection = filter.defaultValue;
      } else {
        filter.selection = filter.options[0].value;
      }
    }
  }

  private setFilterStateInUrl(replaceUrl: boolean): void {
    const routerState = this.store.selectSync(fromStore.getRouterSideState(this.side));
    const params = this.makeNavigationParams(routerState);
    this.router.navigate([params], {relativeTo: this.route, replaceUrl: replaceUrl});
  }

  private makeNavigationParams(routerState: Params): Params {
    const params: Params = {...routerState};
    delete params.domainId;
    delete params.pageId;
    this.filters.forEach(filter => {
      if (filter.selection != null && !(Array.isArray(filter.selection) && filter.selection.length === 0)) {
        if (filter.selection instanceof Date) {
          params[filter.key] = dateToYyyyMmDd(filter.selection);
        } else {
          params[filter.key] = filter.selection;
        }
      } else if (this.isFilterWithForcedSelectionAndUndefinedSelection(filter)) {
        params[filter.key] = filter.options[0].value;
      } else {
        delete params[filter.key];
      }
    });
    return params;
  }

  private createFilter(filterWidget: FilterWidget, routerState: Params): Filter {
    const filter = this.createFilterBasedOnConfiguration(filterWidget);
    this.setFilterSelectionBasedOnRouterState(filter, routerState, false);
    this.addUnknownSelectionToFilterOptions(filter);
    return filter;
  }

  private createFilterBasedOnConfiguration(filterWidget: FilterWidget): Filter {
    const forcedSelection = filterWidget.options.forcedSelection ? JSON.parse(filterWidget.options.forcedSelection) : false;
    const filterOptions = this.createOptions(filterWidget.data, filterWidget.options.unfilteredOption);
    const dateValues = filterWidget.options.defaultMinMaxValueDatePageFilter ? JSON.parse(filterWidget.options.defaultMinMaxValueDatePageFilter) : {};
    const defaultValue = this.parseDateValue(dateValues.defaultDate);
    const minDateValue = this.parseDateValue(dateValues.minDate);
    const maxDateValue = this.parseDateValue(dateValues.maxDate);

    const filter: Filter = {
      key: filterWidget.options.filterKey ? filterWidget.options.filterKey : 'Configuratiefout',
      label: filterWidget.options.title,
      options: filterOptions,
      placeholder: filterWidget.options.title,
      showClear: true,
      type: filterWidget.type,
      forcedSelection: forcedSelection,
      defaultValue: defaultValue,
      minDateValue: minDateValue,
      maxDateValue: maxDateValue,
      disableManualInput: filterWidget.options.disableManualInput && filterWidget.options.disableManualInput == 'true'
    };

    if (defaultValue) {
      filter.selection = defaultValue;
    }

    if (forcedSelection) {
      filter.placeholder = null;
      filter.showClear = false;

      if (filterOptions.length > 0) {
        const defaultOption = filterOptions.find(option => option.defaultSelection);
        filter.selection = defaultOption != null ? defaultOption.value : filterOptions[0].value;
      }
    }

    return filter;
  }

  private createOptions(data: Array<FilterWidgetData>, unfilteredOption?: string): FilterOption[] {
    const filteredData = data.filter(option => option.Filter.value !== null && option.Filter.value !== undefined);

    const options: FilterOption[] = filteredData.map(option => {
      let label: string = option.Filter.label;
      if (option.Filter.count) {
        label += ` (${option.Filter.count})`;
      }

      return {
        label: label,
        value: option.Filter.value,
        defaultSelection: option.Filter.defaultSelection
      };
    });

    if (unfilteredOption) {
      options.unshift({label: unfilteredOption, value: null});
    }

    return options;
  }

  private parseDateValue(dateValue: string): Date {
    if (matchToYyyyMmDd(dateValue)) {
      return yyyyMmDdToDate(dateValue);
    } else {
      switch(dateValue) {
        case 'today':
          return new Date();
      }
    }

    return undefined;
  }

  private isSelectionAlreadyInFilterOptions(options: FilterOption[], selection: string | number | Date): boolean {
    return options.some(option => {
      if (typeof (selection) !== typeof (option.value)) {
        if (typeof option.value === 'string') {
          return option.value === String(selection);
        } else if (typeof option.value === 'number') {
          return option.value === Number(selection);
        } else if (option.value instanceof Date) {
          return option.value === this.toDateFilterValue(selection);
        }
      } else {
        return option.value === selection;
      }
    });
  }

  private isFilterWithForcedSelectionAndUndefinedSelection(filter: Filter): boolean {
    return filter.forcedSelection && filter.options.length > 0 && filter.selection === undefined;
  }

  private toSingleValueFilterValue(value: string | number): string | number {
    return isNaN(value as never) ? value : Number(value);
  }

  private toMultiValueFilterValue(value: (string | number)[] | string | number): (string | number)[] | undefined {
    if (typeof value === 'undefined' || Array.isArray(value)) {
      return value;
    } else {
      return `${value}`.split(',').map(this.toSingleValueFilterValue);
    }
  }

  private toDateFilterValue(value: string | number | Date): Date | undefined {
    if (value == null) {
      return null;
    } else if (isNaN(value as never)) {
      return yyyyMmDdToDate(`${value}`);
    } else {
      return new Date(value);
    }
  }
}
