export type BlockArgument = string | number | boolean | Block | Block[];

export class BlockType {
  public static readonly contextType: string = 'CONTEXT';
  public static readonly dataType: string = 'DATA';
  public static readonly environmentType: string = 'ENVIRONMENT';
  public static readonly objectType: string = 'OBJECT';
  public static readonly groupType: string = 'GROUP';
  public static readonly sumType: string = 'SUM';
  public static readonly coalesceType: string = 'COALESCE';

  public static readonly elementTypes: string[] = [BlockType.contextType,
    BlockType.dataType,
    BlockType.environmentType,
    BlockType.objectType,
    BlockType.groupType,
    BlockType.sumType,
    BlockType.coalesceType
  ];

  public static readonly textType: string = 'TEXT';
  public static readonly placeholderType: string = 'PLACEHOLDER';
  public static readonly linkType: string = 'LINK';
  public static readonly buttonType: string = 'BUTTON';
  public static readonly readMoreType: string = 'READMORE';
  public static readonly dotType: string = 'DOT';
  public static readonly notificationType: string = 'NOTIFICATION';
  public static readonly annotationType: string = 'ANNOTATION';

  public static readonly componentTypes: string[] = [BlockType.textType,
    BlockType.placeholderType,
    BlockType.linkType,
    BlockType.buttonType,
    BlockType.readMoreType,
    BlockType.dotType,
    BlockType.notificationType,
    BlockType.annotationType
  ];
}

export class Block {
  public text: BlockArgument;
  public label: BlockArgument;
  public style: string;
  [key: string]: BlockArgument;

  constructor(public type: string, public startIndex: number, public endIndex: number) {
    this.text = null;
    this.label = null;
    this.style = '';
  }
}
