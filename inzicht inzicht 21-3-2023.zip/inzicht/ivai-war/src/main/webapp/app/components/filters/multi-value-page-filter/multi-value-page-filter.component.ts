import {Component, EventEmitter, Input, Output} from '@angular/core';

import {Filter} from '@inzicht/components/filters/filter';

@Component({
  selector: 'i-multi-value-page-filter',
  templateUrl: './multi-value-page-filter.component.html',
  styleUrls: ['./multi-value-page-filter.component.scss']
})
export class MultiValuePageFilterComponent {

  @Input() filter: Filter;

  @Input() // See: https://angular.io/guide/component-interaction#intercept-input-property-changes-with-a-setter
  get selection(): (string | number)[] {
    return this.internalSelection;
  }

  set selection(selection: (string | number)[]) {
    this.internalSelection = selection;
  }

  @Output() selected: EventEmitter<(string | number)[]> = new EventEmitter<(string | number)[]>();

  public internalSelection: (string | number)[] = [];

  public onChange(): void {
    this.selected.emit(this.internalSelection);
  }

}
