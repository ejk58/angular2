export type FilterValue = string | number | Date | (string | number)[];
