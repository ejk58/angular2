import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs';

import {ReleaseNote} from '@inzicht/commons/release-note';
import {Store} from '@ngrx/store';
import * as fromStore from '@inzicht/store';

@Component({
  selector: 'i-release-notes',
  templateUrl: './release-notes.component.html',
  styleUrls: ['./release-notes.component.scss']
})

export class ReleaseNotesComponent implements OnInit {

  public releaseNotes$: Observable<ReleaseNote[]>;

  constructor(private readonly store: Store) {}

  ngOnInit(): void {
    this.releaseNotes$ = this.store.select(fromStore.selectReleaseNotes);
    this.store.dispatch(fromStore.loadReleaseNotes());
  }
}
