import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {Store} from '@ngrx/store';
import {SplitWidth} from '@inzicht/classes/split-width';
import {headerSelectMenu} from '@inzicht/store/header/header.actions';
import * as fromStore from '@inzicht/store';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {Params} from '@angular/router';
import {PageMenuCategory, PageMenuOption} from '@inzicht/classes/page-menu';
import {Page} from '@inzicht/classes/page';
import {Domain} from '@inzicht/classes/domain';

interface PageMenuCategoryWithEnabledStatus extends Omit<PageMenuCategory, 'options'> {
  options: PageMenuOptionWithEnabledStatus[];
}

interface PageMenuOptionWithEnabledStatus extends PageMenuOption {
  enabled: boolean;
}

@Component({
  selector: 'i-page-menu',
  templateUrl: './page-menu.component.html',
  styleUrls: ['./page-menu.component.scss'],
  providers: [Unsubscriber]
})
export class PageMenuComponent implements OnInit, OnDestroy {

  @Input() side: any;
  @Output() selected: EventEmitter<boolean> = new EventEmitter<boolean>();

  public pageMenu: PageMenuCategoryWithEnabledStatus[];

  public selectedCategory: number;
  public currentPageId: string;
  public splitWidth: SplitWidth;

  constructor(private readonly util: PageNavigationUtilService,
              private readonly splitViewState: SplitViewState,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit(): void {
    const routerState$ = this.store.select(fromStore.getRouterSideState(this.side)).pipe(this.unsubscriber.takeUntilForUnsubscribe);
    const domainConfig: { [key: string]: Domain } = this.store.selectSync(fromStore.getDomainElements);

    routerState$.subscribe({
      next: sideParams => {
        const domainId: string = sideParams.domainId;
        const menuOptions = domainConfig[domainId].menuOptions;
        const pages = domainConfig[domainId].pages;

        this.currentPageId = sideParams.pageId;
        this.pageMenu = this.calculatePageMenuWithEnabledStatus(sideParams, menuOptions, pages);
      },
      error: error => console.error(`Error occurred while handling router state (${error})`)
    });

    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: sizes => this.splitWidth = sizes == null ? SplitWidth.default : sizes,
        error: error => console.error(`Error while handling split view sizes (${error})`)
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  private calculatePageMenuWithEnabledStatus(sideParams: Params, menu: PageMenuCategory[], pages: { [key: string]: Page }): PageMenuCategoryWithEnabledStatus[] {
    return menu.map(category => {
      const optionsWithEnabledStatus = category.options.map(option => {
        const page: Page = pages[option.key];
        const enabled = page.mandatoryPathKeys.every(pathKey => typeof sideParams[pathKey] !== 'undefined'
          && sideParams[pathKey] !== 'undefined'
          && sideParams[pathKey] !== 'null'
          && sideParams[pathKey] !== null);
        return {...option, enabled};
      });

      return {...category, options: optionsWithEnabledStatus};
    });
  }

  public toggleMenuCategory(category: number): number {
    return (this.selectedCategory === category) ? this.selectedCategory = undefined : this.selectedCategory = category;
  }

  public selectPage(menuOption: PageMenuOption): void {
    const selectedPageId: string = menuOption.key;
    this.store.dispatch(headerSelectMenu({side: this.side, menu: 'none' }));
    this.util.navigateToPage(this.side, selectedPageId, null);
  }

  public splittedToMobileScreen(): boolean {
    return this.splitWidth[this.side] <= this.splitViewState.breakpointMobile;
  }
}
