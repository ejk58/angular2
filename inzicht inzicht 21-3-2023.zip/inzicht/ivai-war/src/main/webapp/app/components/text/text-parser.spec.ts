import {TestBed} from '@angular/core/testing';
import {TextParser} from './text-parser';
import {Block} from './block';

describe('TextParser', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ ],
      providers: [ ]
    });
  });

  describe('parse', () => {
    it('should parse a given text and return it as a single LINK-block',
      () => {
        const textParser = new TextParser();
        const text = '#LINK(url=http://happymail.com;key=value)LINK#';
        const blocks = textParser.parse(text);

        expect(blocks.length).toEqual(1);

        expect(blocks[0].type).toEqual('LINK');
        expect(blocks[0].startIndex).toEqual(0);
        expect(blocks[0].endIndex).toEqual(46);
        expect(blocks[0]['url']).toEqual('http://happymail.com');
        expect(blocks[0]['key']).toEqual('value');
      });

    it('should parse a given text and return it as a single OBJECT-block',
      () => {
        const textParser = new TextParser();
        const text = '#OBJECT(teamName=Inge;app=Inzicht;numberOfDevelopers=6)OBJECT#';
        const blocks = textParser.parse(text);

        expect(blocks.length).toEqual(1);

        expect(blocks[0].type).toEqual('OBJECT');
        expect(blocks[0]['teamName']).toEqual('Inge');
        expect(blocks[0]['app']).toEqual('Inzicht');
        expect(blocks[0]['numberOfDevelopers']).toEqual('6');
      });

    it('should parse a given text with two consecutive elements and return it as two blocks',
      () => {
        const textParser = new TextParser();
        const text = '#OBJECT(key=value)OBJECT##CONTEXT(key=subjectNr)CONTEXT#';
        const blocks = textParser.parse(text);

        expect(blocks.length).toEqual(2);

        expect(blocks[0].type).toEqual('OBJECT');
        expect(blocks[0].startIndex).toEqual(0);
        expect(blocks[0].endIndex).toEqual(25);
        expect(blocks[0]['key']).toEqual('value');

        expect(blocks[1].type).toEqual('CONTEXT');
        expect(blocks[1].startIndex).toEqual(25);
        expect(blocks[1].endIndex).toEqual(56);
        expect(blocks[1]['key']).toEqual('subjectNr');
      });

    it('should parse a given text without special elements and return it as a TEXT-block',
      () => {
        const textParser = new TextParser();
        const text = 'Hopefully the test will regards this sentence as a single element of type TEXT.';
        const blocks = textParser.parse(text);

        expect(blocks.length).toEqual(1);

        expect(blocks[0].type).toEqual('TEXT');
        expect(blocks[0].startIndex).toEqual(0);
        expect(blocks[0].endIndex).toEqual(79);
        expect(blocks[0].text).toEqual('Hopefully the test will regards this sentence as a single element of type TEXT.');
      });

    it('should parse a given text with a single CONTEXT-block inside plain text and return it as three blocks',
      () => {
        const textParser = new TextParser();
        const text = 'Hopefully the test will find a #CONTEXT(key=subjectNr)CONTEXT# tag in this sentence.';
        const blocks = textParser.parse(text);

        expect(blocks.length).toEqual(3);

        expect(blocks[0].type).toEqual('TEXT');
        expect(blocks[0].startIndex).toEqual(0);
        expect(blocks[0].endIndex).toEqual(31);
        expect(blocks[0].text).toEqual('Hopefully the test will find a ');

        expect(blocks[1].type).toEqual('CONTEXT');
        expect(blocks[1].startIndex).toEqual(31);
        expect(blocks[1].endIndex).toEqual(62);
        expect(blocks[1]['key']).toEqual('subjectNr');

        expect(blocks[2].type).toEqual('TEXT');
        expect(blocks[2].startIndex).toEqual(62);
        expect(blocks[2].endIndex).toEqual(84);
        expect(blocks[2].text).toEqual(' tag in this sentence.');
      });

    it('should parse a given text with nested CONTEXT-elements and return it as three blocks (and a nested block)',
      () => {
        const textParser = new TextParser();
        const text = 'Hopefully the test will find a #CONTEXT(model=#CONTEXT(key=subjectNr)CONTEXT#)CONTEXT# tag in this sentence.';
        const blocks = textParser.parse(text);

        expect(blocks.length).toEqual(3);

        expect(blocks[0].type).toEqual('TEXT');
        expect(blocks[0].startIndex).toEqual(0);
        expect(blocks[0].endIndex).toEqual(31);
        expect(blocks[0].text).toEqual('Hopefully the test will find a ');

        expect(blocks[1].type).toEqual('CONTEXT');
        expect(blocks[1].startIndex).toEqual(31);
        expect(blocks[1].endIndex).toEqual(86);

        expect(blocks[2].type).toEqual('TEXT');
        expect(blocks[2].startIndex).toEqual(86);
        expect(blocks[2].endIndex).toEqual(108);
        expect(blocks[2].text).toEqual(' tag in this sentence.');

        const model = blocks[1]['model'] as Block;
        expect(model.type).toEqual('CONTEXT');
        expect(model.startIndex).toEqual(46);
        expect(model.endIndex).toEqual(77);
        expect(model['key']).toEqual('subjectNr');
      });

    it('should parse a given text with two different elements surrounded by plain text and return five blocks',
      () => {
        const textParser = new TextParser();
        const text = 'A sentence can contain both a #LINK(url=http://nu.nl)LINK# and a #FEEDBACK(topic=global;state=empty)FEEDBACK# tag.';
        const blocks = textParser.parse(text);

        expect(blocks.length).toEqual(5);

        expect(blocks[0].type).toEqual('TEXT');
        expect(blocks[0].startIndex).toEqual(0);
        expect(blocks[0].endIndex).toEqual(30);
        expect(blocks[0].text).toEqual('A sentence can contain both a ');

        expect(blocks[1].type).toEqual('LINK');
        expect(blocks[1].startIndex).toEqual(30);
        expect(blocks[1].endIndex).toEqual(58);
        expect(blocks[1]['url']).toEqual('http://nu.nl');

        expect(blocks[2].type).toEqual('TEXT');
        expect(blocks[2].startIndex).toEqual(58);
        expect(blocks[2].endIndex).toEqual(65);
        expect(blocks[2].text).toEqual(' and a ');

        expect(blocks[3].type).toEqual('FEEDBACK');
        expect(blocks[3].startIndex).toEqual(65);
        expect(blocks[3].endIndex).toEqual(109);
        expect(blocks[3]['topic']).toEqual('global');
        expect(blocks[3]['state']).toEqual('empty');

        expect(blocks[4].type).toEqual('TEXT');
        expect(blocks[4].startIndex).toEqual(109);
        expect(blocks[4].endIndex).toEqual(114);
        expect(blocks[4].text).toEqual(' tag.');
      });

    it('should parse a given text with two complex elements and return nested blocks',
      () => {
        const textParser = new TextParser();
        const text = '#LINK(label=7777777;page=presentation-algemeen;model=#OBJECT(subjectNr=7777777;entityNr=#CONTEXT(key=entityNr)CONTEXT#)OBJECT#;target=rightSide;style=link)LINK#.';
        const blocks = textParser.parse(text);

        expect(blocks.length).toEqual(2);

        expect(blocks[0].type).toEqual('LINK');
        expect(blocks[0].startIndex).toEqual(0);
        expect(blocks[0].endIndex).toEqual(160);
        expect(blocks[0].text).toEqual('7777777');
        expect(blocks[0]['label']).toEqual('7777777');
        expect(blocks[0]['page']).toEqual('presentation-algemeen');
        expect(blocks[0]['target']).toEqual('rightSide');

        const modelObject = blocks[0]['model'] as Block;
        expect(modelObject.type).toEqual('OBJECT');
        expect(modelObject['subjectNr']).toEqual('7777777');

        const entityContext = modelObject['entityNr'] as Block;
        expect(entityContext.type).toEqual('CONTEXT');
        expect(entityContext['key']).toEqual('entityNr');

        expect(blocks[1].type).toEqual('TEXT');
        expect(blocks[1].startIndex).toEqual(160);
        expect(blocks[1].endIndex).toEqual(161);
        expect(blocks[1].text).toEqual('.');
      });
  });
});
