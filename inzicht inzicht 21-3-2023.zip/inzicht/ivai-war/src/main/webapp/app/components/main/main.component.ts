import {AfterViewChecked, ChangeDetectorRef, Component, HostListener, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {first} from 'rxjs/operators';
import {Sidebar} from 'primeng/sidebar';

import {SplitViewState} from '@inzicht/services/split-view-state.service';
import {HelpState} from '@inzicht/services/help.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import * as fromStore from '@inzicht/store';
import {Domain} from '@inzicht/classes/domain';
import {NewSizes} from '@inzicht/components/main/new-sizes';

@Component({
  selector: 'i-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
  providers: [Unsubscriber]
})
export class MainComponent implements OnInit, OnDestroy, AfterViewChecked {

  @ViewChild('sidebarFeedback', {read: Sidebar, static: true}) sidebarFeedbackRef: Sidebar;
  @ViewChild('sidebarHelp', {read: Sidebar, static: true}) sidebarHelpRef: Sidebar;

  public readonly browserIsIE = /trident\//i.test(window.navigator.userAgent);

  public screenSizePx: number = window.innerWidth;
  public mobileSreenSizePx = 320;
  public mobileBreakpointPx = 400;
  public leftSize = 100;
  public rightSize = 0;
  public horizontal = 'horizontal';
  public initDragHandle = true;
  public sidebarState: any;
  public contextText: string;
  public displayHelp: boolean = false;
  public displayFeedback: boolean = false;
  public activeDomain$: Observable<Domain>;

  @HostListener('window:resize', ['$event']) onResize(): void {
    this.screenSizePx = window.innerWidth;
    if (this.screenSizePx < this.mobileBreakpointPx) {

      this.mobileSreenSizePx = this.screenSizePx;
      if (this.leftSize > 0) {
        this.leftSize = 100;
        this.rightSize = 0;
      }
    } else {
      this.mobileSreenSizePx = this.splitViewState.breakpointMobile;
    }
  }

  constructor(private readonly changeDetectorRef: ChangeDetectorRef,
              private readonly router: Router,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService,
              private readonly helpState: HelpState,
              private readonly pageNavigationUtilService: PageNavigationUtilService,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit(): void {
    this.activeDomain$ = this.store.select(fromStore.getActiveDomainLeft);

    // initially open domain menu
    this.store.select(fromStore.getActiveDomainLeft)
      .pipe(first())
      .subscribe({
        next: activeDomain => {
          if (activeDomain === null) {
            this.store.dispatch(fromStore.headerSelectMenu({ side: 'left', menu: 'domain' }));
          }
        },
        error: error => console.error(`Error occurred while getting left active domain (${error})`)
      });

    this.store.select(fromStore.getActiveDomainRight)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeDomainRight => {
          this.updateDragHandle(activeDomainRight);
        },
        error: error => console.error(`Error occurred while getting right active domain (${error})`)
      });

    this.store.select(fromStore.selectSidebarState)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: sidebarState => {
          this.sidebarState = sidebarState;
          switch (this.sidebarState.type) {
            case 'help': {
              this.displayHelp = true;
              this.displayFeedback = false;
              break;
            }
            case 'feedback': {
              this.displayHelp = false;
              this.displayFeedback = true;
              break;
            }
            default: {
              this.displayHelp = false;
              this.displayFeedback = false;
              break;
            }
          }
        },
        error: error => console.error(`Error while getting sidebar state from store (${error})`)
      });
    const helpTexts = this.helpState.generalHelp;
    this.helpState.emitHelpText(helpTexts);

    if (this.screenSizePx < this.mobileBreakpointPx) {
      this.mobileSreenSizePx = this.screenSizePx;
      this.leftSize = 100;
      this.rightSize = 0;
    }

    this.helpState.listenHelpText()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: text => this.contextText = text,
        error: error => console.error(`Error while handling help text change (${error})`)
      });

    this.splitViewState.listenOpen2Screen()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: open2Screen => {
          if (open2Screen) {
            this.splitScreensInHalf();
            this.splitViewState.emitOpen2Screen(false);
          }
        }, error: error => console.error(`Error while handling the opening of the second screen (${error})`)
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  ngAfterViewChecked(): void {
    if (this.initDragHandle) {
      const splitGutter: HTMLElement = document.querySelector('div.as-split-gutter');
      splitGutter.classList.add('dragBarWidth');

      const newElDiv = document.createElement('div');
      const newElBlock = document.createElement('div');
      const newElBar = document.createElement('div');
      const newElBar2 = document.createElement('div');

      newElDiv.classList.add('drag-handle');
      newElBlock.classList.add('handle-block');
      newElBar.classList.add('handle-bar');
      newElBar2.classList.add('handle-bar');

      if (this.browserIsIE) {
        newElDiv.classList.add('drag-handle-iefix');
      }

      newElBlock.appendChild(newElBar);
      newElBlock.appendChild(newElBar2);
      newElDiv.appendChild(newElBlock);
      splitGutter.appendChild(newElDiv);

      this.initDragHandle = false;
    }
  }

  convertPercToPx(sizeInPercentage: number): number {
    const sizeInPx = ((this.screenSizePx / 100) * sizeInPercentage);
    return Math.round(sizeInPx);
  }

  public onGutterClick(): void {
    this.loadSecondPageOnUserEvent();
    this.updateScreenSplitOnUserEvent(50, 50);
  }

  public onDragStart(): void {
    this.loadSecondPageOnUserEvent();
  }

  public onDragEnd(e: { gutterNum: number, sizes: number[] }): void {
    const eventLeftSize = e.sizes[0];
    const eventRightSize = e.sizes[1];
    const eventLeftSizePx = this.convertPercToPx(eventLeftSize);
    const eventRightSizePx = this.convertPercToPx(eventRightSize);

    let newSizes: NewSizes = {newLeftSize: eventLeftSize, newRightSize: eventRightSize};

    if (this.screenSizePx < this.mobileBreakpointPx) {
      newSizes = this.calculateNewSizesWhenScreenSizeLessThanMobileBreakpoint(eventLeftSize);
    } else {
      if (eventLeftSizePx < this.mobileSreenSizePx) {
        newSizes = this.calculateNewSizesWhenLeftSizeLessThanMobileScreenSize(eventLeftSize);
      }
      if (eventRightSizePx < this.mobileSreenSizePx) {
        newSizes = this.calculateNewSizesWhenRightSizeLessThanMobileScreenSize(eventRightSize);
      }
    }

    this.updateScreenSplitOnUserEvent(newSizes.newLeftSize, newSizes.newRightSize);
  }

  splitScreensInHalf(): void {
    this.leftSize = 50;
    this.rightSize = 50;
    const sizesInPx = { left: this.convertPercToPx(this.leftSize), right: this.convertPercToPx(this.rightSize) };
    this.splitViewState.emitSizes(sizesInPx);
  }

  wasClosed(): void {
    this.leftSize = 100;
    this.rightSize = 0;
    const sizesInPx = { left: this.convertPercToPx(this.leftSize), right: this.convertPercToPx(this.rightSize) };
    this.splitViewState.emitSizes(sizesInPx);
    this.store.dispatch(fromStore.subjectClear({side: 'right'}));
    this.router.navigate(['/main', {outlets: {right: null}}]);
  }

  closeFeedback(): void {
    this.sidebarFeedbackRef.destroyModal();
    this.store.dispatch(fromStore.sidebarClose());
  }

  closeHelp(): void {
    this.sidebarHelpRef.destroyModal();
    this.store.dispatch(fromStore.sidebarClose());
  }

  private loadSecondPageOnUserEvent(): void {
    const activeDomainRight = this.store.selectSync(fromStore.getActiveDomainRight);
    if (activeDomainRight === null) {
      const activeDomainLeft = this.store.selectSync(fromStore.getActiveDomainLeft);
      const selectedSubjectLeft = this.store.selectSync(fromStore.selectSelectedSubjectLeft);
      const initPageId: string = activeDomainLeft ? activeDomainLeft.initPageId : null;
      this.pageNavigationUtilService.navToPageSecondScreen(initPageId, false, selectedSubjectLeft);
    }
  }

  private updateScreenSplitOnUserEvent(leftSize: number, rightSize: number): void {
    setTimeout(() => {
      const sizesInPx = {left: this.convertPercToPx(leftSize), right: this.convertPercToPx(rightSize)};
      this.trackingService.trackEvent('klik', `Scherm aanpassen/left:${leftSize} - right:${rightSize}`, null, null);

      this.leftSize = leftSize;
      this.rightSize = rightSize;
      this.splitViewState.emitSizes(sizesInPx);
      this.changeDetectorRef.detectChanges();
    });
  }

  private updateDragHandle(activeDomainRight: Domain): void {
    const dragHandle: HTMLElement = document.querySelector('div.drag-handle');

    if (dragHandle) {
      if (activeDomainRight != null) {
        dragHandle.classList.add('drag-handle-filled');
      } else {
        dragHandle.classList.remove('drag-handle-filled');
      }
    }
  }

  private calculateNewSizesWhenScreenSizeLessThanMobileBreakpoint(eventLeftSize: number): NewSizes {
    let newLeftSize: number;
    let newRightSize: number;
    if (eventLeftSize > this.leftSize) {
      newLeftSize = 100;
      newRightSize = 0;
    } else {
      newLeftSize = 0;
      newRightSize = 100;
    }
    return {newLeftSize, newRightSize};
  }

  private calculateNewSizesWhenLeftSizeLessThanMobileScreenSize(eventLeftSize: number): NewSizes {
    let newLeftSize: number;
    let newRightSize: number;
    if (eventLeftSize > this.leftSize) {
      newLeftSize = 320 / (this.screenSizePx / 100);
      newRightSize = 100 - newLeftSize;
    } else {
      newLeftSize = 0;
      newRightSize = 100;
    }
    return {newLeftSize, newRightSize};
  }

  private calculateNewSizesWhenRightSizeLessThanMobileScreenSize(eventRightSize: number): NewSizes {
    let newLeftSize: number;
    let newRightSize: number;
    if (eventRightSize > this.rightSize) {
      newRightSize = 320 / (this.screenSizePx / 100);
      newLeftSize = 100 - newRightSize;
    } else {
      newLeftSize = 100;
      newRightSize = 0;
    }
    return {newLeftSize, newRightSize};
  }
}
