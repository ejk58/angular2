import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';
import {Store} from '@ngrx/store';
import {combineLatest, Observable, of} from 'rxjs';
import {catchError, map} from 'rxjs/operators';

import {selectSystemVersion} from '@inzicht/store/system/system.selectors';

interface ViewModel {
  version: string,
  currentRoute: string;
}

@Component({
  selector: 'i-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  vm$!: Observable<ViewModel>;

  constructor(private readonly route: ActivatedRoute,
              private readonly store: Store) {}

  ngOnInit() {
    const version$: Observable<string> = this.store.select(selectSystemVersion);
    const currentRoute$: Observable<Params> = this.route.params;

    // Leave unused currentRoute in the map function as part of the returned combineLatest array.
    this.vm$ = combineLatest([version$, currentRoute$])
      .pipe(map(([version, currentRoute]) => {
        return {
          version: version,
          currentRoute: this.route.snapshot.url[0].path
        };
      }), catchError((error): Observable<ViewModel> => {
        console.error(`Error processing router changes (${error})`);
        return null;
      }));
  }
}
