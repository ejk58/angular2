import {inject, TestBed} from '@angular/core/testing';
import {DataTypeService} from './data-type.service';
import {DatePipe} from '@angular/common';
import {BooleanPipe} from '@inzicht/pipes/boolean.pipe';


describe('DataTypeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        DataTypeService, DatePipe, BooleanPipe
      ]
    });
  });

  describe('getBaseType', () => {
    it('should recognize the base type of all the base data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getBaseType('NUMBER', null)).toEqual('NUMBER');
        expect(dataTypeService.getBaseType('STRING', null)).toEqual('STRING');
        expect(dataTypeService.getBaseType('DECIMALMONEY', null)).toEqual('DECIMALMONEY');
        expect(dataTypeService.getBaseType('FOREIGNMONEY', null)).toEqual('FOREIGNMONEY');
        expect(dataTypeService.getBaseType('MONEY', null)).toEqual('MONEY');
        expect(dataTypeService.getBaseType('DATETIME', null)).toEqual('DATETIME');
        expect(dataTypeService.getBaseType('DATE', null)).toEqual('DATE');
        expect(dataTypeService.getBaseType('YEAR', null)).toEqual('YEAR');
        expect(dataTypeService.getBaseType('BOOLEAN', null)).toEqual('BOOLEAN');
        expect(dataTypeService.getBaseType('WEIGHT', null)).toEqual('WEIGHT');
        expect(dataTypeService.getBaseType('PERCENTAGE', null)).toEqual('PERCENTAGE');
        expect(dataTypeService.getBaseType('IMAGE', null)).toEqual('IMAGE');
        expect(dataTypeService.getBaseType('EVENT', null)).toEqual('EVENT');
        expect(dataTypeService.getBaseType('COMPLIANCELIGHT', null)).toEqual('COMPLIANCELIGHT');
        expect(dataTypeService.getBaseType('SCROLLLINK', null)).toEqual('SCROLLLINK');
        expect(dataTypeService.getBaseType('SPARKLINE', null)).toEqual('SPARKLINE');
        expect(dataTypeService.getBaseType('DIFFERENCEMARKER', null)).toEqual('DIFFERENCEMARKER');
        expect(dataTypeService.getBaseType('ROWMARKER', null)).toEqual('ROWMARKER');
        expect(dataTypeService.getBaseType('ASSPECIFIED', null)).toEqual('ASSPECIFIED');
      }));

    it('should recognize the base type of composite data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getBaseType('DRILLDOWNNUMBER', null)).toEqual('NUMBER');
        expect(dataTypeService.getBaseType('DRILLDOWNSTRING', null)).toEqual('STRING');
        expect(dataTypeService.getBaseType('ANNOTATEDDECIMALMONEY', null)).toEqual('DECIMALMONEY');
        expect(dataTypeService.getBaseType('FOOTNOTEDFOREIGNMONEY', null)).toEqual('FOREIGNMONEY');
        expect(dataTypeService.getBaseType('TRENDMONEY', null)).toEqual('MONEY');
        expect(dataTypeService.getBaseType('PAGELINKBOOLEAN', null)).toEqual('BOOLEAN');
        expect(dataTypeService.getBaseType('SEARCHLINKWEIGHT', null)).toEqual('WEIGHT');
        expect(dataTypeService.getBaseType('SEARCHLINKPERCENTAGE', null)).toEqual('PERCENTAGE');
        expect(dataTypeService.getBaseType('FILELINKIMAGE', null)).toEqual('IMAGE');
        expect(dataTypeService.getBaseType('FILELINKEVENT', null)).toEqual('EVENT');
        expect(dataTypeService.getBaseType('COLOREDCOMPLIANCELIGHT', null)).toEqual('COMPLIANCELIGHT');
        expect(dataTypeService.getBaseType('DRILLDOWNCOLOREDSPARKLINE', null)).toEqual('SPARKLINE');
      }));

    it('should recognize the base type of specified data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'value': 2002, 'unit': 'NUMBER'})).toEqual('NUMBER');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'value': 'Hello World!', 'unit': 'STRING'})).toEqual('STRING');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'value': 31415927, 'unit': 'MONEY'})).toEqual('MONEY');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'value': 5, 'unit': 'PERCENTAGE'})).toEqual('PERCENTAGE');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'value': 10, 'unit': 'DATE'})).toEqual('DATE');

        expect(dataTypeService.getBaseType('ASSPECIFIED', {'Waarde': 2002, 'Meeteenheid': 'GETAL'})).toEqual('NUMBER');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'Waarde': 'Hillo World!', 'Meeteenheid': 'TEKST'})).toEqual('STRING');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'Waarde': 'Hallo World!', 'Meeteenheid': 'TEKSTRECHTS'})).toEqual('STRING');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'Waarde': 'Hullo World!', 'Meeteenheid': 'STRINGRIGHT'})).toEqual('STRING');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'Waarde': 31415927, 'Meeteenheid': 'BEDRAG'})).toEqual('MONEY');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'Waarde': 5, 'Meeteenheid': 'PERCENTAGE'})).toEqual('PERCENTAGE');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'Waarde': 10, 'Meeteenheid': 'DATUM'})).toEqual('DATE');
        expect(dataTypeService.getBaseType('ASSPECIFIED', {'Waarde': 'Default Value', 'Meeteenheid': 'ONBEKEND'})).toEqual('STRING');
      }));

    it('should recognize the base type of a mix of composite and specified data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        const coloredAsSpecifiedValue = {'value': {'Waarde': 33, 'Meeteenheid': 'PERCENTAGE'}, 'backgroundColor': 'red'};
        expect(dataTypeService.getBaseType('COLOREDASSPECIFIED', coloredAsSpecifiedValue)).toEqual('PERCENTAGE');

        const annotatedAsSpecifiedValue = {'Waarde': {'Waarde': 1602164608339, 'Meeteenheid': 'DATUM'}, 'Tooltip': 'Quite a large sum of money'};
        expect(dataTypeService.getBaseType('ANNOTATEDASSPECIFIED', annotatedAsSpecifiedValue)).toEqual('DATE');

        const footnotedAsSpecifiedValue = {'value': {'value': {'value': 15, 'detail': 'detail-page', 'filter': {}}, 'unit': 'PAGELINKNUMBER'}, 'footnote': 'Small percentage'};
        expect(dataTypeService.getBaseType('FOOTNOTEDASSPECIFIED', footnotedAsSpecifiedValue)).toEqual('NUMBER');

        const nestedAsSpecifiedValue = {'value': {'value': {'value': 1200, 'unit': 'WEIGHT'}, 'detail': 'detail-page', 'filter': {}}, 'unit': 'PAGELINKASSPECIFIED'};
        expect(dataTypeService.getBaseType('ASSPECIFIED', nestedAsSpecifiedValue)).toEqual('WEIGHT');
      }));

    it('should find no base type for unknown data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getBaseType(undefined, null)).toBeUndefined();
        expect(dataTypeService.getBaseType(null, null)).toBeUndefined();
        expect(dataTypeService.getBaseType('CAT', null)).toBeUndefined();
        expect(dataTypeService.getBaseType('DOG', null)).toBeUndefined();
        expect(dataTypeService.getBaseType('MONKEY', null)).toBeUndefined();
        expect(dataTypeService.getBaseType('CAMEL', null)).toBeUndefined();
      }));
  });

  describe('getOuterType', () => {
    it('should recognize the outer type of relatively simple composite data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getOuterType('DRILLDOWNNUMBER')).toEqual('DRILLDOWN');
        expect(dataTypeService.getOuterType('TRENDSTRING')).toEqual('TREND');
        expect(dataTypeService.getOuterType('ANNOTATEDDECIMALMONEY')).toEqual('ANNOTATED');
        expect(dataTypeService.getOuterType('FOOTNOTEDFOREIGNMONEY')).toEqual('FOOTNOTED');
        expect(dataTypeService.getOuterType('COLOREDMONEY')).toEqual('COLORED');
        expect(dataTypeService.getOuterType('PAGELINKDATETIME')).toEqual('PAGELINK');
        expect(dataTypeService.getOuterType('SEARCHLINKDATE')).toEqual('SEARCHLINK');
        expect(dataTypeService.getOuterType('FILELINKYEAR')).toEqual('FILELINK');
      }));

    it('should recognize the outer type of nested composite data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getOuterType('TRENDSEARCHLINKPERCENTAGE')).toEqual('TREND');
      }));

    it('should find no outer type for base data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getOuterType('NUMBER')).toBeUndefined();
        expect(dataTypeService.getOuterType('STRING')).toBeUndefined();
        expect(dataTypeService.getOuterType('DECIMALMONEY')).toBeUndefined();
        expect(dataTypeService.getOuterType('FOREIGNMONEY')).toBeUndefined();
        expect(dataTypeService.getOuterType('MONEY')).toBeUndefined();
        expect(dataTypeService.getOuterType('DATETIME')).toBeUndefined();
        expect(dataTypeService.getOuterType('DATE')).toBeUndefined();
        expect(dataTypeService.getOuterType('YEAR')).toBeUndefined();
        expect(dataTypeService.getOuterType('BOOLEAN')).toBeUndefined();
      }));
  });

  describe('getInnerType', () => {
    it('should recognize the inner type of base data types (which is the same as the inner type)',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getInnerType('NUMBER')).toEqual('NUMBER');
        expect(dataTypeService.getInnerType('STRING')).toEqual('STRING');
        expect(dataTypeService.getInnerType('DECIMALMONEY')).toEqual('DECIMALMONEY');
        expect(dataTypeService.getInnerType('FOREIGNMONEY')).toEqual('FOREIGNMONEY');
        expect(dataTypeService.getInnerType('MONEY')).toEqual('MONEY');
        expect(dataTypeService.getInnerType('DATETIME')).toEqual('DATETIME');
        expect(dataTypeService.getInnerType('DATE')).toEqual('DATE');
        expect(dataTypeService.getInnerType('YEAR')).toEqual('YEAR');
        expect(dataTypeService.getInnerType('BOOLEAN')).toEqual('BOOLEAN');
        expect(dataTypeService.getInnerType('WEIGHT')).toEqual('WEIGHT');
        expect(dataTypeService.getInnerType('PERCENTAGE')).toEqual('PERCENTAGE');
      }));

    it('should recognize the inner type of nested composite data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getInnerType('COLOREDCOMPLIANCELIGHT')).toEqual('COMPLIANCELIGHT');
      }));
  });

  describe('getBaseValue', () => {
    it('should return the base value of the given value for the base types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getBaseValue('STRING', 'Hello World')).toEqual('Hello World');
        expect(dataTypeService.getBaseValue('NUMBER', 2002)).toEqual(2002);
        expect(dataTypeService.getBaseValue('YEAR', 1991)).toEqual(1991);
        expect(dataTypeService.getBaseValue('BOOLEAN', true)).toEqual(true);
        expect(dataTypeService.getBaseValue('PERCENTAGE', 25)).toEqual(25);
      }));

    it('should return the base value of the given value for relatively simple composite types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        const drilldownStringValue = {'value': 'Hello World', 'detail': 'detail-page', 'filter': {}};
        expect(dataTypeService.getBaseValue('DRILLDOWNSTRING', drilldownStringValue)).toEqual('Hello World');

        const trendMoneyValue = {'value': 217305, 'revision': 1};
        expect(dataTypeService.getBaseValue('TRENDMONEY', trendMoneyValue)).toEqual(217305);
      }));

    it('should return the base value of the given value for nested composite types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        const coloredDrilldownStringValue = {'value': {'value': 'Happy World', 'detail': 'detail-page', 'filter': {}}, 'backgroundColor': 'red'};
        expect(dataTypeService.getBaseValue('COLOREDDRILLDOWNSTRING', coloredDrilldownStringValue)).toEqual('Happy World');

        const annotatedTrendMoneyValue = {'value': {'value': 612207, 'revision': 1}, 'tooltip': 'Quite a large sum of money'};
        expect(dataTypeService.getBaseValue('ANNOTATEDTRENDMONEY', annotatedTrendMoneyValue)).toEqual(612207);
      }));

    it('should return the base value of the given value for specified types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        const asSpecifiedValue = {'Waarde': 12, 'Meeteenheid': 'GETAL'};
        expect(dataTypeService.getBaseValue('ASSPECIFIED', asSpecifiedValue)).toEqual(12);

        const asSpecifiedPageLinkStringValue = {'Waarde': {'value': 'Funny World', 'filter': {}, 'target': 'currentSide'}, 'Meeteenheid': 'PAGELINKSTRING'};
        expect(dataTypeService.getBaseValue('ASSPECIFIED', asSpecifiedPageLinkStringValue)).toEqual('Funny World');

        const coloredAsSpecifiedValue = {'value': {'Waarde': 'Lovely World', 'Meeteenheid': 'TEKST'}, 'backgroundColor': 'red'};
        expect(dataTypeService.getBaseValue('COLOREDASSPECIFIED', coloredAsSpecifiedValue)).toEqual('Lovely World');

        const annotatedAsSpecifiedValue = {'Waarde': {'Waarde': 1602164608339, 'Meeteenheid': 'DATUM'}, 'Tooltip': 'Quite a large sum of money'};
        expect(dataTypeService.getBaseValue('ANNOTATEDASSPECIFIED', annotatedAsSpecifiedValue)).toEqual(1602164608339);

        const nestedAsSpecifiedValue = {'value': {'value': {'value': 1200, 'unit': 'WEIGHT'}, 'detail': 'detail-page', 'filter': {}}, 'unit': 'PAGELINKASSPECIFIED'};
        expect(dataTypeService.getBaseValue('ASSPECIFIED', nestedAsSpecifiedValue)).toEqual(1200);
      }));
  });

  describe('getFilterValue', () => {
    it('should return the filter value (based on the base value) of the given value for the base types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getFilterValue('STRING', 'Cozy World')).toEqual('Cozy World');
        expect(dataTypeService.getFilterValue('NUMBER', 2002)).toEqual(2002);
        expect(dataTypeService.getFilterValue('DATE', 1602164608339)).toEqual('08-10-2020');
        expect(dataTypeService.getFilterValue('BOOLEAN', true)).toEqual('Ja');
        expect(dataTypeService.getFilterValue('PERCENTAGE', 25)).toEqual(25);
      }));

    it('should not return a filter value for types that dont make (visual) sense to be in filter results',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getFilterValue('COMPLIANCELIGHT', 7)).toEqual(undefined);
        expect(dataTypeService.getFilterValue('IMAGE', 'http://images.com/dummy.jpg')).toEqual(undefined);
      }));
  });

  describe('getSortValue', () => {
    it('should return the sort value (based on the base value) of the given value for the base types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getSortValue('STRING', 'Clumsy World')).toEqual('Clumsy World');
        expect(dataTypeService.getSortValue('NUMBER', 2002)).toEqual(2002);
        expect(dataTypeService.getSortValue('DATE', 1602164608339)).toEqual(1602164608339);
        expect(dataTypeService.getSortValue('BOOLEAN', true)).toEqual('Ja');
        expect(dataTypeService.getSortValue('PERCENTAGE', 25)).toEqual(25);
      }));
  });

  describe('isColspanAllowedForThisType', () => {
    it('should return if a colspan is allowed for the given base data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.isColspanAllowedForThisType('STRING', 'Wacky World')).toEqual(true);
        expect(dataTypeService.isColspanAllowedForThisType('NUMBER', 2002)).toEqual(false);
        expect(dataTypeService.isColspanAllowedForThisType('DATE', 1602164608339)).toEqual(false);
        expect(dataTypeService.isColspanAllowedForThisType('BOOLEAN', true)).toEqual(false);
        expect(dataTypeService.isColspanAllowedForThisType('PERCENTAGE', 25)).toEqual(false);
      }));

    it('should return if a colspan is allowed for the given relatively simple composite types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        const drilldownStringValue = {'value': 'Hello World', 'detail': 'detail-page', 'filter': {}};
        expect(dataTypeService.isColspanAllowedForThisType('DRILLDOWNSTRING', drilldownStringValue)).toEqual(true);

        const trendMoneyValue = {'value': 217305, 'revision': 1};
        expect(dataTypeService.isColspanAllowedForThisType('TRENDMONEY', trendMoneyValue)).toEqual(false);
      }));

    it('should return if a colspan is allowed for the given value for specified types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        const asSpecifiedValue = {'Waarde': 12, 'Meeteenheid': 'GETAL'};
        expect(dataTypeService.isColspanAllowedForThisType('ASSPECIFIED', asSpecifiedValue)).toEqual(false);

        const asSpecifiedPageLinkStringValue = {'Waarde': {'value': 'Hungry World', 'filter': {}, 'target': 'currentSide'}, 'Meeteenheid': 'PAGELINKSTRING'};
        expect(dataTypeService.isColspanAllowedForThisType('ASSPECIFIED', asSpecifiedPageLinkStringValue)).toEqual(true);

        const nestedAsSpecifiedValue = {'value': {'value': {'value': 1200, 'unit': 'WEIGHT'}, 'detail': 'detail-page', 'filter': {}}, 'unit': 'PAGELINKASSPECIFIED'};
        expect(dataTypeService.isColspanAllowedForThisType('ASSPECIFIED', nestedAsSpecifiedValue)).toEqual(false);
      }));
  });

  describe('getDefaultAlignment', () => {
    it('should return the default alignment for the given base data types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        expect(dataTypeService.getDefaultAlignment('STRING')).toEqual('left');
        expect(dataTypeService.getDefaultAlignment('NUMBER')).toEqual('right');
        expect(dataTypeService.getDefaultAlignment('DATE')).toEqual('left');
        expect(dataTypeService.getDefaultAlignment('BOOLEAN')).toEqual('left');
        expect(dataTypeService.getDefaultAlignment('PERCENTAGE')).toEqual('right');
      }));

    it('should return the default alignment for the given relatively simple composite types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        const drilldownStringValue = {'value': 'Hello World', 'detail': 'detail-page', 'filter': {}};
        expect(dataTypeService.getDefaultAlignment('DRILLDOWNSTRING', drilldownStringValue)).toEqual('left');

        const trendMoneyValue = {'value': 217305, 'revision': 1};
        expect(dataTypeService.getDefaultAlignment('TRENDMONEY', trendMoneyValue)).toEqual('right');
      }));

    it('should return the default alignment for the given value for specified types',
      inject([DataTypeService], (dataTypeService: DataTypeService) => {
        const asSpecifiedValue = {'Waarde': 12, 'Meeteenheid': 'GETAL'};
        expect(dataTypeService.getDefaultAlignment('ASSPECIFIED', asSpecifiedValue)).toEqual('right');

        const asSpecifiedPageLinkStringValue = {'Waarde': 'Hungry World', 'Meeteenheid': 'TEKSTRECHTS'};
        expect(dataTypeService.getDefaultAlignment('ASSPECIFIED', asSpecifiedPageLinkStringValue)).toEqual('right always-right');

        const asSpecifiedStringRightValue = {'Waarde': 'English World', 'Meeteenheid': 'STRINGRIGHT'};
        expect(dataTypeService.getDefaultAlignment('ASSPECIFIED', asSpecifiedStringRightValue)).toEqual('right always-right');

        const nestedAsSpecifiedValue = {'value': {'value': {'value': 'Angry World', 'unit': 'STRING'}, 'detail': 'detail-page', 'filter': {}}, 'unit': 'PAGELINKASSPECIFIED'};
        expect(dataTypeService.getDefaultAlignment('ASSPECIFIED', nestedAsSpecifiedValue)).toEqual('left');
      }));

  });
});
