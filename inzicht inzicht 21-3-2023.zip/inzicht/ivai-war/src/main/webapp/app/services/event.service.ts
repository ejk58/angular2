import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {delay, map} from 'rxjs/operators';

import {dateToDdMmYyyy} from '@inzicht/commons/date-functions';
import {Side} from '@inzicht/commons/side';

export enum ChartEvent {
  enterTooltip = 'enterTooltip',
  leaveTooltip = 'leaveTooltip'
}

export enum LegendEvent {
  enableItem = 'enableItem',
  disableItem = 'disableItem'
}

export enum TableEvent {
  enterRow = 'enterRow',
  leaveRow = 'leaveRow'
}

export type EventType = ChartEvent | LegendEvent | TableEvent;
export type PropertiesType = {[key: string]: {'name'?: string, 'value'?: string, 'transform'?: string}};
export type EventCallback = <T>(payload: T) => void;

export class Event<T> {
  constructor(
    public readonly type: EventType,
    public readonly payload?: T
  ) {
  }
}

export class EventListener {
  [widgetListenerName: string]: {
    'properties': PropertiesType,
    'callback': EventCallback
  };
}

export class EventListenerTypeMap {
  [type: string]: EventListener;
}

export class EventListenerSourceMap {
  [widgetSourceName: string]: EventListenerTypeMap;
}

export class EventListenerMap {
  'left': EventListenerSourceMap;
  'right': EventListenerSourceMap;
}

@Injectable()
export class EventService {

  private static readonly TransformMap = {
    'anyToNumber': (value: any): number => +value,
    'dateToLong': (date: Date): number => date.getTime(),
    'timeToDate': (time: number): Date => new Date(time),
    'timeToDdMmYyyy': (time: number): string => dateToDdMmYyyy(new Date(time))
  };

  private readonly listeners: EventListenerMap = {
    'left': {},
    'right': {}
  };

  public listen(side: Side, widgetSourceName: string, eventType: EventType, widgetListenerName: string, properties: PropertiesType, callback: EventCallback): void {
    if (this.listeners[side][widgetSourceName] == null) {
      this.listeners[side][widgetSourceName] = {};
    }

    if (this.listeners[side][widgetSourceName][eventType] == null) {
      this.listeners[side][widgetSourceName][eventType] = {};
    }

    this.listeners[side][widgetSourceName][eventType][widgetListenerName] = {
      'properties': properties == null ? {} : properties,
      'callback': callback
    };
  }

  public listenAny(side: Side, eventSourceAttribute: string, eventType: EventType, widgetListenerName: string, callback: EventCallback): void {
    const eventSource = eventSourceAttribute ? JSON.parse(eventSourceAttribute) : null;

    if (eventSource) {
      const widgetSourceName = eventSource.widget;
      const properties = eventSource.properties == null ? [] : eventSource.properties;

      this.listen(side, widgetSourceName, eventType, widgetListenerName, properties, callback);
    }
  }

  public remove(side: Side, widgetSourceName: string, eventType: EventType, widgetListenerName: string): void {
    if (this.listeners[side][widgetSourceName] != null && this.listeners[side][widgetSourceName][eventType] != null) {
      delete this.listeners[side][widgetSourceName][eventType][widgetListenerName];
    }
  }

  public removeAll(side: Side, widgetListenerName: string): void {
    let removedEventCount = 0;

    Object.keys(this.listeners[side]).forEach(widgetSourceName => {
      Object.keys(this.listeners[side][widgetSourceName]).forEach(eventType => {
        if (this.listeners[side][widgetSourceName][eventType][widgetListenerName]) {
          delete this.listeners[side][widgetSourceName][eventType][widgetListenerName];
          removedEventCount++;
        }
      });
    });
  }

  public removeAny(side: Side, eventSourceAttribute: string, widgetListenerName: string): void {
    if (eventSourceAttribute) {
      this.removeAll(side, widgetListenerName);
    }
  }

  public broadcast<T>(side: Side, widgetSourceName: string, event: Event<T>): void {
    const eventSide = this.listeners[side];
    const eventSources = eventSide[widgetSourceName];

    if (eventSources != null) {
      const eventListeners = eventSources[event.type];

      if (eventListeners != null) {
        Object.keys(eventListeners).forEach(widgetName => {
          const callback = eventListeners[widgetName].callback;
          const properties = eventListeners[widgetName].properties;
          const payload = this.transform(properties, event.payload);
          callback(payload);
        });
      }
    }
  }

  private transform(properties: PropertiesType, value: {[key: string]: any}): string | number | Date | {[key: string]: any} {
    const propertyKeys = Object.keys(properties);

    if (value == null || propertyKeys.length === 0) {
      return value;
    } else {
      const result = {};

      propertyKeys.forEach(key => {
        const propertyName = properties[key].name ? properties[key].name : key;
        const propertyTransform = properties[key].transform ? properties[key].transform : null;
        // eslint-disable-next-line no-prototype-builtins
        const transform = (propertyTransform != null && EventService.TransformMap.hasOwnProperty(propertyTransform)) ?
          EventService.TransformMap[propertyTransform] : null;

        if (Object.prototype.hasOwnProperty.call(value,key)) {
          result[propertyName] = transform == null ? value[key] : transform(value[key]);
        } else if (properties[key].value) {
          result[propertyName] = transform == null ? properties[key].value : transform(properties[key].value);
        }
      });

      return result;
    }
  }
}
