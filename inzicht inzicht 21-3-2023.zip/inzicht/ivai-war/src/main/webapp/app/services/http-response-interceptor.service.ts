import {Injectable} from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from '@angular/common/http';

import {Observable, throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';

import {AuthenticationService} from '../services/authentication.service';

@Injectable()
export class HttpResponseInterceptor implements HttpInterceptor {

  constructor(private authenticationService: AuthenticationService){}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        const isLogin: boolean = (error.url.indexOf('security/login') > -1);
        if(error.status === 403 && error.statusText === 'Forbidden' && !isLogin){
          this.authenticationService.logout(true);
        }
        return throwError(error);
      })
    );
  }
}
