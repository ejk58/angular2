import {Injectable} from '@angular/core';
import {DatePipe} from '@angular/common';

import {BooleanPipe} from '@inzicht/pipes/boolean.pipe';

@Injectable()
export class DataTypeService {

  public static readonly baseNumber: string = 'NUMBER';
  public static readonly baseFiscalNumber: string = 'FISCALNUMBER';
  public static readonly baseString: string = 'STRING';
  public static readonly baseDate: string = 'DATE';
  public static readonly baseDateTime: string = 'DATETIME';
  public static readonly baseYear: string = 'YEAR';
  public static readonly baseMoney: string = 'MONEY';
  public static readonly baseDecimalMoney: string = 'DECIMALMONEY';
  public static readonly baseForeignMoney: string = 'FOREIGNMONEY';
  public static readonly basePercentage: string = 'PERCENTAGE';
  public static readonly baseWeight: string = 'WEIGHT';
  public static readonly baseBoolean: string = 'BOOLEAN';
  public static readonly baseComplianceLight: string = 'COMPLIANCELIGHT';
  public static readonly baseImage: string = 'IMAGE';
  public static readonly baseEvent: string = 'EVENT';
  public static readonly baseScrollLink: string = 'SCROLLLINK';
  public static readonly baseSparkLine: string = 'SPARKLINE';
  public static readonly baseDifferenceMarker: string = 'DIFFERENCEMARKER';
  public static readonly baseRowMarker: string = 'ROWMARKER';
  public static readonly baseObject: string = 'OBJECT';
  public static readonly baseModel: string = 'MODEL';
  public static readonly baseFilter: string = 'FILTER';
  public static readonly baseAsSpecified: string = 'ASSPECIFIED';

  public static readonly baseTypes: string[] = [DataTypeService.baseNumber, DataTypeService.baseFiscalNumber, DataTypeService.baseString,
    DataTypeService.baseDecimalMoney, DataTypeService.baseForeignMoney, DataTypeService.baseMoney,
    DataTypeService.baseDateTime, DataTypeService.baseDate, DataTypeService.baseYear, DataTypeService.baseBoolean,
    DataTypeService.baseWeight, DataTypeService.basePercentage, DataTypeService.baseImage, DataTypeService.baseEvent,
    DataTypeService.baseComplianceLight,
    DataTypeService.baseScrollLink,
    DataTypeService.baseSparkLine, DataTypeService.baseDifferenceMarker, DataTypeService.baseRowMarker,
    DataTypeService.baseObject, DataTypeService.baseModel, DataTypeService.baseFilter, DataTypeService.baseAsSpecified];

  public static readonly nonFilterableTypes: string[] = [DataTypeService.baseComplianceLight, DataTypeService.baseImage];

  public static readonly prefixDrillDown: string = 'DRILLDOWN';
  public static readonly prefixColored: string = 'COLORED';
  public static readonly prefixAnnotated: string = 'ANNOTATED';
  public static readonly prefixExpand: string = 'EXPAND';
  public static readonly prefixFootnoted: string = 'FOOTNOTED';
  public static readonly prefixPageLink: string = 'PAGELINK';
  public static readonly prefixSearchLink: string = 'SEARCHLINK';
  public static readonly prefixFileLink: string = 'FILELINK';
  public static readonly prefixTrend: string = 'TREND';

  public static readonly prefixTypes: string[] = [DataTypeService.prefixDrillDown,
    DataTypeService.prefixFootnoted, DataTypeService.prefixAnnotated, DataTypeService.prefixExpand, DataTypeService.prefixColored,
    DataTypeService.prefixPageLink, DataTypeService.prefixSearchLink, DataTypeService.prefixFileLink,
    DataTypeService.prefixTrend];

  public static readonly leftAlignBaseTypes: string[] = [DataTypeService.baseString, DataTypeService.baseDate, DataTypeService.baseDateTime, DataTypeService.baseYear, DataTypeService.baseBoolean,
    DataTypeService.baseComplianceLight, DataTypeService.baseScrollLink];
  public static readonly possiblyNegativeBaseTypes: string[] = [DataTypeService.baseNumber, DataTypeService.baseMoney,
    DataTypeService.baseDecimalMoney, DataTypeService.baseForeignMoney];
  public static readonly enhanceableBaseTypes: string[] = [DataTypeService.baseDate, DataTypeService.baseDateTime, DataTypeService.baseBoolean];

  public static readonly maskedValue = '######';

  constructor(private readonly datePipe: DatePipe,
              private readonly booleanPipe: BooleanPipe) { }

  public getOuterType(type: string): string {
    return type ? DataTypeService.prefixTypes.find(prefixType => type.indexOf(prefixType) === 0) : type;
  }

  public getInnerType(type: string): string {
    const outerType = this.getOuterType(type);
    return (type != null && outerType != null) ? type.substring(outerType.length) : type;
  }

  public getTypeFromSpecified(value: any): string {
    let specifiedType = 'STRING';

    if (Object.prototype.hasOwnProperty.call(value, 'unit')) {
      specifiedType = value.unit ? value.unit : 'STRING';
    } else if (value.Meeteenheid === 'GETAL' || value.Meeteenheid === 'NUMBER') {
      specifiedType = 'NUMBER';
    } else if (value.Meeteenheid === 'BEDRAG' || value.Meeteenheid === 'MONEY') {
      specifiedType = 'MONEY';
    } else if (value.Meeteenheid === 'PERCENTAGE') {
      specifiedType = 'PERCENTAGE';
    } else if (value.Meeteenheid === 'DATUM' || value.Meeteenheid === 'DATE') {
      specifiedType = 'DATE';
    } else if (value.Meeteenheid === 'COMPLIANCELIGHT') {
      specifiedType = 'COMPLIANCELIGHT';
    }

    return specifiedType;
  }

  public getValue(type: string, value: any): any {
    let result = value;

    if (value != null) {
      if (Object.prototype.hasOwnProperty.call(value, 'value')) {
        result = value.value;
      } else if (this.isFileLinkType(type)) {
        result = null;
      } else if (this.isTrendType(type) && Object.prototype.hasOwnProperty.call(value,'Bedrag')) {
        result = value.Bedrag;
      } else if (this.isSpecifiedType(type) && Object.prototype.hasOwnProperty.call(value,'Waarde')) {
        result = value.Waarde;
      }
    }

    return result;
  }

  public getBaseTypeAndValue(type: string, value: any): {'type': string, 'value': any} {
    let currentType = type;
    let currentValue = value;
    let innerType = (type === DataTypeService.baseAsSpecified && value != null) ?
      this.getTypeFromSpecified(value) : this.getInnerType(type);

    while (currentType !== innerType) {
      currentValue = this.getValue(currentType, currentValue);
      currentType = innerType;
      innerType = (currentType === DataTypeService.baseAsSpecified && currentValue != null) ?
        this.getTypeFromSpecified(currentValue) : this.getInnerType(currentType);
    }

    return {'type': DataTypeService.baseTypes.find(type => currentType === type), 'value': this.getValue(currentType, currentValue)};
  }

  public getBaseType(type: string, value?: any): string {
    const baseTypeAndValue = this.getBaseTypeAndValue(type, value);
    return baseTypeAndValue.type;
  }

  public getBaseValue(type: string, value: any): any {
    const baseTypeAndValue = this.getBaseTypeAndValue(type, value);
    return baseTypeAndValue.value;
  }


  public isBaseType(type: string): boolean {
    return type && DataTypeService.baseTypes.some(baseType => type === baseType);
  }

  public isOfBaseType(type: string, baseType: string): boolean {
    const inputBaseType = this.getBaseType(type, null);
    return baseType === inputBaseType;
  }

  public isOfOuterType(type: string, outerType: string): boolean {
    return type && type.indexOf(outerType) === 0;
  }

  public isSpecifiedType(type: string): boolean {
    return type && type.indexOf(DataTypeService.baseAsSpecified, type.length - DataTypeService.baseAsSpecified.length) !== -1;
  }

  public isDrillDownType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixDrillDown);
  }

  public isPageLinkType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixPageLink);
  }

  public isSearchLinkType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixSearchLink);
  }

  public isColoredType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixColored);
  }

  public isAnnotatedType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixAnnotated);
  }

  public isExpandType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixExpand);
  }

  public isFootnotedType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixFootnoted);
  }

  public isTrendType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixTrend);
  }

  public isFileLinkType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixFileLink);
  }

  public isScrollLinkType(type: string): boolean {
    return this.isOfBaseType(type, DataTypeService.baseScrollLink);
  }

  public getFilterValue(type: string, value: any): any {
    const baseTypeAndValue = this.getBaseTypeAndValue(type, value);
    const baseType = baseTypeAndValue.type;
    const baseValue = baseTypeAndValue.value;
    let filterValue;

    if (!DataTypeService.nonFilterableTypes.includes(baseType)) {
      filterValue = baseValue;
    }

    if (baseValue != null && baseValue !== DataTypeService.maskedValue) {
      if (baseType === DataTypeService.baseDate) {
        filterValue = this.datePipe.transform(baseValue, 'dd-MM-yyyy');
      } else if (baseType === DataTypeService.baseBoolean) {
        filterValue = this.booleanPipe.transform(baseValue);
      }
    }

    return filterValue;
  }

  public getSortValue(type: string, value: any): any {
    const baseTypeAndValue = this.getBaseTypeAndValue(type, value);
    const baseType = baseTypeAndValue.type;
    const baseValue = baseTypeAndValue.value;
    let sortValue = baseValue;

    if (sortValue != null && sortValue !== DataTypeService.maskedValue) {
      if (baseType === DataTypeService.baseBoolean) {
        sortValue = this.booleanPipe.transform(baseValue);
      }
    }

    return sortValue;
  }

  public enhanceSimpleValueWithFilterAndSortField(type: string, value: any): any {
    const filterValue = this.getFilterValue(type, value);
    const sortValue = this.getSortValue(type, value);
    return {value, filterValue, sortValue};
  }

  public enhanceCompositeValueWithFilterAndSortField(type: string, value: any): any {
    const filterValue = this.getFilterValue(type, value);
    const sortValue = this.getSortValue(type, value);
    const enhancedValue = this.enhanceBaseValueWithFilterValue(type, value, filterValue);
    return {...enhancedValue, filterValue, sortValue};
  }

  private enhanceBaseValueWithFilterValue(type: string, value: any, filterValue: any): any  {
    const baseType = this.getBaseType(type, value);

    if (DataTypeService.enhanceableBaseTypes.find(enhanceableBaseType => baseType === enhanceableBaseType)) {
      let currentType = type;
      let currentValue = value;
      let innerType = (type === DataTypeService.baseAsSpecified && value != null) ?
        this.getTypeFromSpecified(value) : this.getInnerType(type);

      while (!DataTypeService.enhanceableBaseTypes.find(enhanceableBaseType => innerType === enhanceableBaseType)) {
        currentValue = this.getValue(currentType, currentValue);
        currentType = innerType;
        innerType = (currentType === DataTypeService.baseAsSpecified && currentValue != null) ?
          this.getTypeFromSpecified(currentValue) : this.getInnerType(currentType);
      }

      currentValue.value = {'value': currentValue.value, filterValue};
    }

    return value;
  }

  public enhanceValueWithFilterAndSortField(type: string, value: any): any {
    return (value === this.getValue(type, value)) ?
      this.enhanceSimpleValueWithFilterAndSortField(type, value) :
      this.enhanceCompositeValueWithFilterAndSortField(type, value);
  }

  public isColspanAllowedForThisType(type: string, value: any): boolean {
    const baseType = this.getBaseType(type, value);
    return (baseType.indexOf(DataTypeService.baseString) > -1);
  }

  public getDefaultAlignment(type: string, value?: any): string {
    const baseType = this.getBaseType(type, value);
    let alignment = DataTypeService.leftAlignBaseTypes.some(leftAlignType => leftAlignType === baseType) ? 'left' : 'right';

    if (this.isSpecifiedType(type) && value != null && (value.Meeteenheid === 'TEKSTRECHTS' || value.Meeteenheid === 'STRINGRIGHT')) {
      alignment = 'right always-right';
    }

    return alignment;
  }
}
