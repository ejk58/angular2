import {first} from 'rxjs/operators';

declare module '@ngrx/store/src/store' {
  interface Store<T> {
    selectSync<K = any>(selector: any, props?: any): K;
  }
}

export function selectSync<K = any>(selector: any, props?: any): K {
  let value: K;
  this.select(selector, props).pipe(first()).subscribe(val => value = val);
  return value;
}
