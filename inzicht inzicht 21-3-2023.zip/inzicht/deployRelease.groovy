@Library("GENERIC") _
    pipelineDeployArtifactFromNexus {
	deploymentId = "inzicht"
	integrationPipeline = "inzicht-test"
	packageChoices = "inzicht"
	applicationVersionChoices = "3.112.0\n3.111.0\n3.110.0\n3.109.0\n3.108.0"
	asVersionChoices = "n.v.t"
	environmentChoices = "tst\nont\nacc\nprd"
	streetChoices = "str11/productie\nstr12/opleiding\nstr13\nstr14"
}
