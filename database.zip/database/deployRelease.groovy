@Library("GENERIC") _
	pipelineDeployDatabaseFromNexus {
		deploymentId = "inzicht-database"
		integrationPipeline = "inzicht-test"
		packageChoices = "inzicht-database"
		applicationVersionChoices = "1.5.0\n1.4.1\n1.4.0\n1.3.2\n1.3.0"
		environmentChoices = "tst\nont\nacc\nprd"
		streetChoices = "str11/productie\nstr12/opleiding\nstr13\nstr14"
        contextIsEnvPlusStreet = "true"
	}
