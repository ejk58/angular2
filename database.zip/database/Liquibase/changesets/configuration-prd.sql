DELETE FROM "CONF_DATASOURCE_PARAM";

INSERT INTO "CONF_DATASOURCE_PARAM"("DATASOURCE_ID", "KEY", "VALUE") VALUES 
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsMappingJAAS', 'rest/teradata/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'restUrl', 'https://tdrest.prod.belastingdienst.nl/tdrest/systems/TDrest-Unity/queries'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'teradataSchema', 'DG_I_P_50PRO_INZ'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'slowQueryThreshold', '2000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsType', 'APIKEY'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsMappingJAAS', 'rest/zaakadministratie/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'restUrl', 'https://iva-zaakadministratie.belastingdienst.nl/iva-zaakadministratie/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'trustAllCertificates', '1'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsType', 'URLPARAMETER'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsMappingJAAS', 'rest/documenten/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'restUrl', 'https://appsiva.belastingdienst.nl/DocumentViewer'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'trustAllCertificates', '1'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'connectTimeout', '20000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'readTimeout', '20000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'restUrl', 'https://inzicht.belastingdienst.nl/inzicht/rest/'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'credentialsType', 'LTPA2TOKEN'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'trustAllCertificates', '1'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'slowQueryThreshold', '5000');

INSERT INTO "CONF_DOMAIN_ROLE"("DOMAIN_ID", "TYPE", "ROLE", "VIPACCESS") VALUES 
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'di'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'di'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'invordering'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'invordering'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'documenten'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'documenten'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'zaakadministratie'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'zaakadministratie'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'analytics'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'analytics'), 0, 'aug_IVA_maatwerk_ops', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'reflection'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'reflection'), 0, 'aug_IVA_maatwerk_ops', 0);

DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'di') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-analyse');
DELETE FROM CONF_PAGE_WIDGET WHERE WIDGET_ID = (SELECT ID FROM CONF_WIDGET WHERE name = 'RISICOSIGNALEN_OB_CONTAINER') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-klantprofiel');
DELETE FROM CONF_PAGE_WIDGET WHERE WIDGET_ID NOT IN (SELECT ID FROM CONF_WIDGET WHERE name LIKE '%KTA_LINK_WIDGET') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-compliance');
DELETE FROM CONF_PAGE_WIDGET WHERE WIDGET_ID NOT IN (SELECT ID FROM CONF_WIDGET WHERE name LIKE '%KTA_LINK_WIDGET') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-vennootschapsbelasting');
DELETE FROM CONF_PAGE_WIDGET WHERE WIDGET_ID NOT IN (SELECT ID FROM CONF_WIDGET WHERE name LIKE '%KTA_LINK_WIDGET') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-loonheffing');
DELETE FROM CONF_PAGE_WIDGET WHERE WIDGET_ID NOT IN (SELECT ID FROM CONF_WIDGET WHERE name LIKE '%KTA_LINK_WIDGET') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-bankgegevens');
DELETE FROM CONF_PAGE_WIDGET WHERE WIDGET_ID NOT IN (SELECT ID FROM CONF_WIDGET WHERE name LIKE '%KTA_LINK_WIDGET') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-inkomensheffing');
DELETE FROM CONF_PAGE_WIDGET WHERE WIDGET_ID NOT IN (SELECT ID FROM CONF_WIDGET WHERE name LIKE '%KTA_LINK_WIDGET') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-invordering');

DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-analyse');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'di-bankgegevens');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'invordering-invordering');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'invordering-vorderingen');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'invordering-betaalgedrag');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'invordering-looninkomsten');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'invordering-personeel-en-loon');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'invordering-renseignementen');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'invordering-balans-en-winst-en-verlies');
DELETE FROM CONF_PAGE_DOMAIN WHERE VIEW_ID = (SELECT ID FROM CONF_DOMAIN WHERE key = 'invordering') AND PAGE_ID = (SELECT ID FROM CONF_PAGE WHERE key = 'invordering-betalingen');

UPDATE CONF_WIDGET SET CONTAINER_WIDGET_ID = NULL WHERE NAME = 'NW_RELATIES_FAMILYTREEGRAPH_WIDGET';
UPDATE CONF_WIDGET SET CONTAINER_WIDGET_ID = NULL WHERE NAME = 'DI_RELATIES_FAMILYTREEGRAPH_WIDGET';
UPDATE CONF_WIDGET SET CONTAINER_WIDGET_ID = NULL WHERE NAME = 'CONCERNSTRUCTUUR_ENTERPRISEGRAPH_WIDGET';
