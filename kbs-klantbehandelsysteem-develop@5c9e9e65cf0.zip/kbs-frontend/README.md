# IvaKbsApp
KlantBehandelSysteem contains a frontend kbs-frontend build with Angular
and a backend build with SpringBoot.

The frontend uses iv-framework-lib.

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.0.3.

## Development server

Run `npm install` in the `kbs-frontend` directory once to download all dependencies. Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Backend server

Run `mvn package` in the `kbs-backend` directory once to download all dependencies. To start the Spring Boot application, run the main method in Application.java.

## Databases  

The application connects with two databases as defined in application.properties. Create your own <YOUR_USERNAME>_IVAKBS01 for the application data.  
There is also data loaded about the entiteiten from a different database KTAA05. You will find the data for the entiteiten in his views (VW048_ENTITEIT_BASISGEGEVENS).  
To connect to the database from the application it is also defined in application.properties.  
To inspect this database from Intellij you have to make sure to have a different version of the db2 driver: Db2 IBM zOS variant.
To add this variant go to the drivers tab in Data Source Properties. Than in option > dialect choose the IBM db2 zOS variant and save as a different driver to avoid problems with previous defined drivers.
The entiteitMapper defines the relation in the application.  

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Storybook
This is a tool for collaboration between design ux and development. Here we can share components and design specifications and adjust accordingly.
Run the storybook server with npm run storybook (results in localhost:6006). For building for a devserver use npm run build-storybook which results in a build in storybook-static folder.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
