export interface MultiSelectListItem {
  id: number;
  groep: string;
  kenmerk: string;
  kenmerkParentId: number
}
