export class MiddelRisico {
  id: number;
  middelId: number;
  risico: string
  parentId: number;

  constructor(id: number, middelId: number, risico: string, parentId: number) {
    this.id = id;
    this.middelId = middelId;
    this.risico = risico;
    this.parentId = parentId;
  }
}
