import {EntiteitKenmerk} from "./EntiteitKenmerk";

export interface GovernanceStructuurKenmerk extends EntiteitKenmerk {

}
