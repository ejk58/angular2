export interface EntiteitConvenantindicatie {
  value: "N" | "J"
}
