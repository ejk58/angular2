export interface EntiteitKenmerk {
  id: number;
  groep: string;
  kenmerk: string;
  kenmerkParentId?: number;
}
