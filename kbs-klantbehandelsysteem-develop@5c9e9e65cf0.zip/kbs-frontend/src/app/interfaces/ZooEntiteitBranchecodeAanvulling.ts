import {EntiteitKenmerk} from "./EntiteitKenmerk";

export interface ZooEntiteitBranchecodeAanvulling extends EntiteitKenmerk{
  selecteerbaar?: boolean;
}
