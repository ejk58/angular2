import {EntiteitKenmerk} from "./EntiteitKenmerk";

export interface ZooEntiteitAandachtsGebied extends EntiteitKenmerk{
  values: string;
}
