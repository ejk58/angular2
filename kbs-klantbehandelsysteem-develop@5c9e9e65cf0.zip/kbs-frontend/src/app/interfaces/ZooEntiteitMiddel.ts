export interface ZooEntiteitMiddel  {
  id: number;
  groep: string;
  kenmerk: string;
}
