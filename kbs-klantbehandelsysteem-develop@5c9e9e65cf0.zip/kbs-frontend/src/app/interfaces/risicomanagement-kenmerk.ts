import {EntiteitKenmerk} from "./EntiteitKenmerk";

export interface RisicomanagementKenmerken extends EntiteitKenmerk {

}
