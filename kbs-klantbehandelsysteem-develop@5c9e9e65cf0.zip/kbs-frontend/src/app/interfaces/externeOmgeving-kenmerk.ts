import {EntiteitKenmerk} from "./EntiteitKenmerk";

export interface ExterneOmgevingKenmerk extends EntiteitKenmerk{

}
