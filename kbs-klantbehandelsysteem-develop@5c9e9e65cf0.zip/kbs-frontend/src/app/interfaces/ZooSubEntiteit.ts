export interface ZooSubEntiteit {
  bsnRsin: number;
  soort: string;
  naam: string
  plaats: string;
  startDatum: string;
  eindDatum: string;
  brancheCode: string;
  aanvullingen: any[];
  spinnerHide?: boolean;
}
