import {EntiteitKenmerk} from "./EntiteitKenmerk";

export interface ComplexiteitKenmerk extends EntiteitKenmerk {

}
