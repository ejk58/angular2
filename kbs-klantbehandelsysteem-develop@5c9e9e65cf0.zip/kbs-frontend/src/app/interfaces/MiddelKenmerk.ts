export class MiddelKenmerk {
  id: number;
  middelId: number;
  kenmerk: string;
  parentId: number;

  constructor(id: number, middelId: number, kenmerk: string, parentId: number) {
    this.id = id;
    this.middelId = middelId;
    this.kenmerk = kenmerk;
    this.parentId = parentId;
  }
}
