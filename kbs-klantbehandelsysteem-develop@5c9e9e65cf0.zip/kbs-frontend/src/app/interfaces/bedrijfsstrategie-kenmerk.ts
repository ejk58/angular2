import {EntiteitKenmerk} from "./EntiteitKenmerk";

export interface BedrijfsstrategieKenmerk extends EntiteitKenmerk{

}
