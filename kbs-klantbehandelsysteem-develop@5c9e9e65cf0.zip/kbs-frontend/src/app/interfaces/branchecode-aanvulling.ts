export interface BranchecodeAanvulling {
  bsn: number;
  aanvullingen: string;
}
