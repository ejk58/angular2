import {MultiSelectListItem} from './multi-select-list-item';

export interface MultiSelectListGroep {
  id: number;
  label: string;
  items: MultiSelectListItem[];
}
