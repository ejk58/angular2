import {Entiteit} from '../entiteit/shared/entiteit';

export interface ZooEntiteitOmvang {
  entiteit: Entiteit;
  aantalBsnRsinsInEntiteit: number;
  aantalBezwarenVerzoekenEnBeroepen: number;
  aantalBuitenlandseDeelnemingen: number;
  aantalVasteInrichtingen: number;
  belastingschuld: number;
  totalenPerJaarOb: number;
  totaleVrijgesteldeOmzet: number;
  totalenPerJaarLhAantalLoongerechtigden: number;
  totalenPerJaarLhTotaalLoonsom: number;
  totalenAanslagenPerJaarVpb: number;
  totaalBetalingenJaarX: number;
  totaalBetalingenJaarXMin1: number;
  totaalBetalingenJaarXMin2: number;
  wolbSom: number;
  lastUpdated: Date;
  lastUpdatedByUserId: string;
}
