import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {tap} from 'rxjs/operators';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {UserApi} from 'iv-framework-lib';

@Injectable()
export class UserService implements UserApi {


  /**
   * Location of the endpoint for logging in (using JWT).
   * Bound to environment property `jwt.login.url`.
   */
  public static readonly ENDPOINT_LOGIN = '/api/login';
  public static readonly KEY_ID_TOKEN = 'id_token';
  public static readonly KEY_USER = 'logged_in_user';

  constructor(private readonly router: Router, private readonly httpClient: HttpClient) {  }

  signIn(username: string, password: string): Observable<any> {
    return this.httpClient.post(UserService.ENDPOINT_LOGIN, {username, password})
      .pipe(
        tap(
          () => {
            localStorage.setItem(UserService.KEY_USER, username);
            },
          (err) => {
            localStorage.removeItem(UserService.KEY_ID_TOKEN);
          }
        )
      );
  }

  signOut(): Observable<any> {
    localStorage.removeItem(UserService.KEY_ID_TOKEN);
    localStorage.removeItem(UserService.KEY_USER);
    return of({});
  }

  isSignedIn(): boolean {
    return localStorage.getItem(UserService.KEY_USER) ? true : false;
  }

  getAuthenticatedRoute(): string {
    return "/authenticated";
  }

  getSignInRoute(): string {
    return "/signin";
  }

  getUsername(): string | null {
    return localStorage.getItem(UserService.KEY_USER);
  }
}
