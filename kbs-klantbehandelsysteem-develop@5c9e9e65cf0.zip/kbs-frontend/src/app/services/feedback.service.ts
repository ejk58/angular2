import {Feedback, FeedbackApi, VersionInformation} from 'iv-framework-lib';
import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {ExceptionService} from './exception.service';
import {catchError} from 'rxjs/operators';
import {OperationsService} from '../services/operations.service';

@Injectable()
export class FeedbackService implements FeedbackApi {

  feedbackRoot = '/api/feedback';

  constructor(private readonly httpClient: HttpClient
            , private readonly exceptionService: ExceptionService
            , private operationService: OperationsService) {
  }

  addFeedback(feedback: Feedback): Observable<Feedback> {
    return this.httpClient.post<Feedback>(`${this.feedbackRoot}`, feedback)
      .pipe(catchError(e => this.exceptionService.catchBadResponse(e, `Feedback versturen is mislukt, ${ExceptionService.REFRESH_AND_TRY_AGAIN}`)));
  }
  getVersionInformation(): Observable<VersionInformation> {
    return this.operationService.getApplicationInformation();
  }
}
