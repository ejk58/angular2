import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ExceptionService} from './exception.service';
import {Observable} from 'rxjs';
import {ZooEntiteitMiddel} from '../interfaces/ZooEntiteitMiddel';
import {catchError} from 'rxjs/operators';
import {ZooEntiteitAandachtsGebied} from '../interfaces/ZooEntiteitAandachtsGebied';
import {ZooEntiteitBranchecodeAanvulling} from '../interfaces/ZooEntiteitBranchecodeAanvulling';
import {EntiteitKenmerk} from '../interfaces/EntiteitKenmerk';
import {ExterneOmgevingKenmerk} from '../interfaces/externeOmgeving-kenmerk';
import {BedrijfsstrategieKenmerk} from '../interfaces/bedrijfsstrategie-kenmerk';
import {GovernanceStructuurKenmerk} from '../interfaces/governanceStructuur-kenmerk';
import {RisicomanagementKenmerken} from '../interfaces/risicomanagement-kenmerk';
import {ComplexiteitKenmerk} from '../interfaces/complexiteit-kenmerk';
import {MultiSelectListGroep} from '../interfaces/multi-select-list-groep';

@Injectable({
  providedIn: 'root',
})
export class KenmerkenService {
  kenmerkenRoot = '/api/kenmerken';

  constructor(private readonly httpClient: HttpClient,
              private readonly exceptionService: ExceptionService) {
  }

  public getAttentiepunten(): Observable<EntiteitKenmerk[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/cijferbeoordeling/actiepunten`)
      .pipe(this.catch(`Attentiepunten actiepunten is mislukt`));
  }

  public getAttentiepuntenBalans(): Observable<EntiteitKenmerk[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/cijferbeoordeling/actiepunten-balans`)
      .pipe(this.catch(`Attentiepunten balans is mislukt`));
  }

  public getAttentiepuntenWinstEnVerlies(): Observable<EntiteitKenmerk[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/cijferbeoordeling/actiepunten-winst-en-verlies`)
      .pipe(this.catch(`Attentiepunten Winst en verlies actiepunten is mislukt`));
  }

  public getZooEntiteitMiddelen(): Observable<ZooEntiteitMiddel[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/middelen`)
      .pipe(this.catch(`Middelen ophalen is mislukt`));
  }

  public getZooEntiteitAttentiepunten(): Observable<EntiteitKenmerk[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/attentiepunten`)
      .pipe(this.catch(`Attentiepunten ophalen is mislukt`));
  }

  public getTestKenmerken(): Observable<EntiteitKenmerk[]> {
    return this.httpClient.get<EntiteitKenmerk[]>(`${this.kenmerkenRoot}/testKenmerken`)
      .pipe(this.catch(`testKenmerken ophalen is mislukt`));
  }

  public getZooEAandachtsGebieden(): Observable<ZooEntiteitAandachtsGebied[]> {
    return this.httpClient.get<ZooEntiteitAandachtsGebied[]>(`${this.kenmerkenRoot}/aandachtsgebieden`)
      .pipe(this.catch(`Aandachts gebieden ophalen is mislukt`));
  }

  public getSelectedCbAttentiepuntenInkomstenbelasting(bsnRsin: number): Observable<EntiteitKenmerk[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/${bsnRsin}/attentiepunten-inkomstenbelasting/selected`)
      .pipe(this.catch(`Attentiepunten actiepunten is mislukt`));
  }

  public getSelectedAandachtsGebieden(bsnRsin:number): Observable<ZooEntiteitAandachtsGebied[]> {
    return this.httpClient.get<ZooEntiteitAandachtsGebied[]>(`${this.kenmerkenRoot}/${bsnRsin}/aandachtsgebieden/selected`)
      .pipe(this.catch(`Aandachts gebieden ophalen is mislukt`));
  }

  public getSelectedMiddelen(bsnRsin:number): Observable<ZooEntiteitMiddel[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/${bsnRsin}/middelen/selected`)
      .pipe(this.catch(`Middelen ophalen is mislukt`));
  }

  public getSelectedMiddelByNameAndGroup(bsnRsin:number, name: string, groep: string): Observable<ZooEntiteitMiddel> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/${bsnRsin}/${name}/${groep}/middel/selected`)
      .pipe(this.catch(`Middel ophalen is mislukt`, true));
  }

  public getSelectedAttentiepunten(bsnRsin:number): Observable<ZooEntiteitMiddel[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/${bsnRsin}/attentiepunten/selected`)
      .pipe(this.catch(`Attentiepunten ophalen is mislukt`));
  }

  public getSelectedActiepunten(bsnRsin:number): Observable<ZooEntiteitMiddel[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/${bsnRsin}/actiepunten/selected`)
      .pipe(this.catch(`Actiepunten gebieden ophalen is mislukt`));
  }

  public getSelectedActiepuntenBalans(bsnRsin:number): Observable<ZooEntiteitMiddel[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/${bsnRsin}/actiepunten-balans/selected`)
      .pipe(this.catch(`Actiepunten gebieden ophalen is mislukt`));
  }

  public getSelectedActiepuntenWinstEnVerlies(bsnRsin:number): Observable<ZooEntiteitMiddel[]> {
    return this.httpClient.get<ZooEntiteitMiddel[]>(`${this.kenmerkenRoot}/${bsnRsin}/actiepunten-winst-en-verlies/selected`)
      .pipe(this.catch(`Actiepunten gebieden ophalen is mislukt`));
  }

  public getZooAardSector(bsnRsin: number): Observable<number> {
    return this.httpClient.get<number>(`${this.kenmerkenRoot}/${bsnRsin}/sector`)
      .pipe(this.catch(`Sector ophalen is mislukt`));
  }

  public setZooAardSector(bsnRsin: number, sector: number) {
    if (sector === null) {
      sector = -1;
    }
    return this.httpClient.post(`${this.kenmerkenRoot}/${bsnRsin}/sector`, sector)
      .pipe(this.catch('Opslaan van de geselecteerde sector is mislukt'));
  }

  public getCbAttentiepuntenInkomstenbelasting(): Observable<MultiSelectListGroep[]> {
    return this.httpClient.get<MultiSelectListGroep[]>(`${this.kenmerkenRoot}/attentiepunten-inkomstenbelasting`)
      .pipe(this.catch(`Attentiepunten inkomsten belasting in Cijferboordeling ophalen is mislukt`));
  }

  public saveSelectionIds(bsnRsin: number, kenmerkType: string, entiteitKenmerkIds: number[]) {
    return this.httpClient.post<number[]>(`${this.kenmerkenRoot}/${bsnRsin}/${kenmerkType}/selection-ids/save`, entiteitKenmerkIds)
      .pipe(this.catch('Opslaan van geselecteerde ids is mislukt'));
  }

  public saveSelections(bsnRsin: number, kenmerkType: string, entiteitKenmerk: EntiteitKenmerk[]) {
    return this.httpClient.post<EntiteitKenmerk[]>(`${this.kenmerkenRoot}/${bsnRsin}/${kenmerkType}/selections/save`, entiteitKenmerk)
      .pipe(this.catch('Opslaan van geselecteerde kenmerken is mislukt'));
  }

  public saveSelectedAandachtsGebieden(bsnRsin: number, kenmerkType: string, aandachtsgebieden: ZooEntiteitAandachtsGebied[]) {
    aandachtsgebieden.map(ag=>{
      if (ag.values === undefined) {
        ag.values = 'false'
      }
      return ag;
    })
    return this.httpClient.post<ZooEntiteitAandachtsGebied[]>(`${this.kenmerkenRoot}/${bsnRsin}/${kenmerkType}/selectedAandachtsgebieden/save`, aandachtsgebieden)
      .pipe(this.catch('Opslaan van geselecteerde aandachtsgebieden is mislukt'));
  }

  public allBedrijfsstrategieKenmerken(): Observable<BedrijfsstrategieKenmerk[]> {
    return this.httpClient.get<BedrijfsstrategieKenmerk[]>(`${this.kenmerkenRoot}/bedrijfsstrategien`)
      .pipe(this.catch(`bedrijfsstrategie kenmerken ophalen is mislukt`));
  }
  public getSelectedBedrijfsstrategien(bsnRsin:number): Observable<BedrijfsstrategieKenmerk[]> {
    return this.httpClient.get<BedrijfsstrategieKenmerk[]>(`${this.kenmerkenRoot}/${bsnRsin}/bedrijfsstrategien/selected`)
      .pipe(this.catch(`Ophalen van geselecteerde bedrijfsstrategie kenmerken is mislukt`));
  }

  public allExterneOmgevingKenmerken(): Observable<ExterneOmgevingKenmerk[]> {
    return this.httpClient.get<ExterneOmgevingKenmerk[]>(`${this.kenmerkenRoot}/externeOmgeving`)
      .pipe(this.catch(`externeOmgeving kenmerken ophalen is mislukt`));
  }
  public getSelectedExterneOmgeving(bsnRsin:number): Observable<ExterneOmgevingKenmerk[]> {
    return this.httpClient.get<ExterneOmgevingKenmerk[]>(`${this.kenmerkenRoot}/${bsnRsin}/externeOmgeving/selected`)
      .pipe(this.catch(`Ophalen van geselecteerde externe omgeving kenmerken is mislukt`));
  }

  public allGovernanceStructuurKenmerken(): Observable<GovernanceStructuurKenmerk[]> {
    return this.httpClient.get<ExterneOmgevingKenmerk[]>(`${this.kenmerkenRoot}/governanceStructuur`)
      .pipe(this.catch(`Governance structuur Kenmerken ophalen is mislukt`));
  }
  public getSelectedGovernanceStructuurKenmerken(bsnRsin:number): Observable<GovernanceStructuurKenmerk[]> {
    return this.httpClient.get<GovernanceStructuurKenmerk[]>(`${this.kenmerkenRoot}/${bsnRsin}/governanceStructuur/selected`)
      .pipe(this.catch(`Ophalen van geselecteerde governance structuur Kenmerken is mislukt`));
  }

  public allRisicomanagementKenmerken(): Observable<RisicomanagementKenmerken[]> {
    return this.httpClient.get<ExterneOmgevingKenmerk[]>(`${this.kenmerkenRoot}/risicomanagement`)
      .pipe(this.catch(`Risicomanagement Kenmerken ophalen is mislukt`));
  }
  public getSelectedRisicomanagementKenmerken(bsnRsin:number): Observable<RisicomanagementKenmerken[]> {
    return this.httpClient.get<RisicomanagementKenmerken[]>(`${this.kenmerkenRoot}/${bsnRsin}/risicomanagement/selected`)
      .pipe(this.catch(`Ophalen van geselecteerde risicomanagement kenmerken is mislukt`));
  }

  public getZooBranchecodeAanvulling(): Observable<ZooEntiteitBranchecodeAanvulling[]> {
    return this.httpClient.get<ZooEntiteitBranchecodeAanvulling[]>(`${this.kenmerkenRoot}/branche-code-aanvullingen`)
      .pipe(this.catch(`Branchecode Aanvullingen gebieden ophalen is mislukt`));
  }

  public getZooBranchecodeAanvullingBy(bsnRsin:number): Observable<ZooEntiteitBranchecodeAanvulling[]> {
    return this.httpClient.get<ZooEntiteitBranchecodeAanvulling[]>(`${this.kenmerkenRoot}/${bsnRsin}/zoo/branchecodeaanvulling/selected`)
      .pipe(this.catch(`Branchecode Aanvullingen van de entiteit ${bsnRsin} ophalen is mislukt`));
  }

  public allComplexiteitKenmerken(): Observable<ComplexiteitKenmerk[]> {
    return this.httpClient.get<ComplexiteitKenmerk[]>(`${this.kenmerkenRoot}/complexiteit`)
      .pipe(this.catch(`Complexiteit kenmerken ophalen is mislukt`));
  }

  public getSelectedComplexiteitKenmerken(bsnRsin:number): Observable<ComplexiteitKenmerk[]> {
    return this.httpClient.get<ComplexiteitKenmerk>(`${this.kenmerkenRoot}/${bsnRsin}/complexiteit/selected`)
      .pipe(this.catch(`Ophalen van geselecteerde complexiteit kenmerken is mislukt`));
  }

  private catch(msg: string, ignore404=false) {
    return catchError(e => this.exceptionService.catchBadResponse(e, `${msg}, ${ExceptionService.REFRESH_AND_TRY_AGAIN}`, ignore404));
  }
}

