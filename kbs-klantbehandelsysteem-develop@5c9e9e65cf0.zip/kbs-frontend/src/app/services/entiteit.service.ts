import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {BehaviorSubject, Observable} from 'rxjs';
import {catchError, map} from 'rxjs/operators';
import {Entiteit, SubEntiteit} from '../entiteit/shared/entiteit';
import {Behandelvoorstel} from '../entiteit/shared/behandelvoorstel';
import {Kenmerken} from '../entiteit/shared/kenmerken';
import {ExceptionService} from './exception.service';
import {Opdracht} from '../entiteit/shared/opdracht';
import {ZooEntiteitOmvang} from '../interfaces/zoo-entiteit-omvang';
import {MessageService} from "primeng/api";
import {Router} from "@angular/router";
import {MSG_KEY_NO_ENTITY_SELECTED} from '../app.constants';
import {ZooSubEntiteit} from "../interfaces/ZooSubEntiteit";
import {EntiteitConvenantindicatie} from '../interfaces/entiteit-convenantindicatie';
import {EntiteitKzbGegevens} from "../entiteit/shared/entiteit-kzb-gegevens";
import {KlantGroep} from "../entiteit/entiteit-algemene-gegevens/entiteit-behandelteam/klant-groep";
import {OrgKantoorTeam} from "../entiteit/entiteit-algemene-gegevens/entiteit-behandelteam/kantoor-team";
import {OrgUrls} from "../entiteit/shared/org-urls";
import {BehandelTeam} from "../entiteit/entiteit-algemene-gegevens/entiteit-behandelteam/behandel-team-gegevens";

@Injectable({
  providedIn: 'root',
})

export class EntiteitService {

  entiteitenRoot = '/api/entiteiten';
  searchEntiteit = new BehaviorSubject(0);

  constructor(private readonly httpClient: HttpClient,
              private readonly exceptionService: ExceptionService,
              private readonly messageService: MessageService,
              private readonly router: Router) {
  }

  public search(entiteitNumber: string, entiteitName: string, klantpakket: string): Observable<Entiteit[]> {
    let p = new HttpParams();
    if (entiteitNumber) {
      p = p.set('entiteitNumber', entiteitNumber?.toString().trim());
    }
    if (entiteitName) {
      p = p.set('entiteitName', entiteitName?.toString().trim());
    }
    if (klantpakket) {
      p = p.set('klantpakket', klantpakket?.toString().trim());
    }

    return this.httpClient.get<Entiteit[]>(`${this.entiteitenRoot}/search`, {params: p})
      .pipe(this.catch('Zoeken is mislukt'));
  }

  public getEntiteit(entiteitNummer: number): Observable<Entiteit> {
    return this.httpClient.get<Entiteit>(`${this.entiteitenRoot}/${entiteitNummer}`)
      .pipe(this.catch(`Entiteit ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getEntiteitOrgKantoorTeamGegevens(entiteitNummer: number): Observable<OrgKantoorTeam> {
    return this.httpClient.get<OrgKantoorTeam>(`${this.entiteitenRoot}/${entiteitNummer}/kantoorteam-org-gegevens`)
      .pipe(this.catch(`Kantoor team Org gegevens ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getEntiteitBehandelTeamGegevens(entiteitNr: number): Observable<BehandelTeam[]> {
    return this.httpClient.get<BehandelTeam[]>(`${this.entiteitenRoot}/${entiteitNr}/behandelteam-org-gegevens`)
      .pipe(this.catch(`BehandelTeam gegevens ophalen voor entiteit ${entiteitNr} is mislukt`));
  }

  public getOrgKlantGroepGegevens(entiteitNummer: number): Observable<KlantGroep> {
    return this.httpClient.get<KlantGroep>(`${this.entiteitenRoot}/${entiteitNummer}/klantgroep-org-gegevens`)
      .pipe(this.catch(`Klant groep gegevens ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getEntiteitOrgMissingGegevens(entiteitNummer: number): Observable<EntiteitKzbGegevens> {
    return this.httpClient.get<EntiteitKzbGegevens>(`${this.entiteitenRoot}/${entiteitNummer}/missing-entiteit-org-gegevens`)
      .pipe(this.catch(`KzbGegevens gegevens ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getOrggevegensUrl(): Observable<OrgUrls> {
    return this.httpClient.get<OrgUrls>(`${this.entiteitenRoot}/org-gegevens-url`)
      .pipe(this.catch(` Ophalen voor org gegevens urls is mislukt`));
  }

  getAlgemeneGegevens_Kenmerken(entiteitNummer: number): Observable<Kenmerken> {
    return this.httpClient.get<Kenmerken>(`${this.entiteitenRoot}/${entiteitNummer}/algemeneGegevens/kenmerken`)
      .pipe(this.catch(`Kenmerken ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  getAlgemeneGegevens_Samenstelling(entiteitNummer: number): Observable<SubEntiteit[]> {
    return this.httpClient.get<SubEntiteit[]>(`${this.entiteitenRoot}/${entiteitNummer}/algemeneGegevens/samenstelling`)
      .pipe(this.catch(`Samenstelling ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getDashboard_Behandelvoorstellen(entiteitNummer: number): Observable<Behandelvoorstel[]> {
    return this.httpClient.get<Behandelvoorstel[]>(`${this.entiteitenRoot}/${entiteitNummer}/dashboard/behandelvoorstellen`)
      .pipe(this.catch(`Behandelvoorstellen ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getDashboard_OpdrachtenLijst(entiteitNummer: number): Observable<Opdracht[]> {
    return this.httpClient.get<Opdracht[]>(`${this.entiteitenRoot}/${entiteitNummer}/dashboard/opdrachten`)
      .pipe(this.catch(`Opdrachten ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  getDashboard_Kenmerkenlijst(entiteitNummer: number): Observable<string[][][]> {
    return this.httpClient.get<string[][][]>(`${this.entiteitenRoot}/${entiteitNummer}/dashboard/kenmerken`)
      .pipe(this.catch(`Kenmerken ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getZooEntiteitOmvang(entiteitNummer: number): Observable<ZooEntiteitOmvang> {
    return this.httpClient.get<ZooEntiteitOmvang>(`${this.entiteitenRoot}/${entiteitNummer}/zoo/omvang`)
      .pipe(this.deserializeZooEntiteitOmvang)
      .pipe(this.catch(`Omvang ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public saveOrUpdateZooEntiteitOmvang(entiteitNummer: number, zooOmvang: ZooEntiteitOmvang): Observable<ZooEntiteitOmvang> {
    return this.httpClient.put<ZooEntiteitOmvang>(`${this.entiteitenRoot}/${entiteitNummer}/zoo/omvang`, zooOmvang)
      .pipe(this.deserializeZooEntiteitOmvang)
      .pipe(this.catch(`Opslaan van aanpassingen van Omvang voor entiteit ${entiteitNummer} is mislukt. Probeer het opnieuw.`));
  }

  public saveSubEntiteitSelections(entiteitNummer: number, zooSubEntiteiten: ZooSubEntiteit[]) {
    return this.httpClient.post<ZooSubEntiteit[]>(`${this.entiteitenRoot}/${entiteitNummer}/subEntiteitSelections/save`, zooSubEntiteiten)
      .pipe(this.catch('Opslaan van geselecteerde subEntiteiten is mislukt'));
  }

  public getSelectedSubEntiteiten(entiteitNummer: number): Observable<ZooSubEntiteit[]> {
    return this.httpClient.get<ZooSubEntiteit>(`${this.entiteitenRoot}/${entiteitNummer}/subEntiteiten/selected`)
      .pipe(this.catch(`Ophalen van geselecteerde zooSubEntiteiten voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getZooSubEntiteiten(entiteitNummer: number): Observable<ZooSubEntiteit[]> {
    return this.httpClient.get<ZooSubEntiteit>(`${this.entiteitenRoot}/${entiteitNummer}/zooSubEntiteiten`)
      .pipe(this.catch(`zooSubEntiteiten ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  public getConvenantindicatie(entiteitNummer: number): Observable<EntiteitConvenantindicatie>{
    return this.httpClient.get<EntiteitConvenantindicatie>(`${this.entiteitenRoot}/${entiteitNummer}/convenantindicatie`)
      .pipe(this.catch(`convenantindicatie ophalen voor entiteit ${entiteitNummer} is mislukt`));
  }

  private readonly deserializeZooEntiteitOmvang = map((o: ZooEntiteitOmvang) => {
    if (o.lastUpdated) {
      // Deserialize date-like object to real Date()
      o.lastUpdated = new Date(o.lastUpdated);
    }
    return o;
  });

  private catch(msg: string) {
    return catchError(e => this.exceptionService.catchBadResponse(e, `${msg}, ${ExceptionService.REFRESH_AND_TRY_AGAIN}`));
  }

  setSearchEntiteitNummer(entiteitNummer: number) {
    this.messageService.clear(MSG_KEY_NO_ENTITY_SELECTED);
    this.searchEntiteit.next(entiteitNummer);
  }

  getSearchEntiteitNummer(doneFn: (entiteitNummer: number) => void) {
    this.searchEntiteit.subscribe((nr) => {
      if (nr > 0) {
        doneFn(nr);
      } else {
        this.warnAndNavigateToSearchScreen();
      }
    });
  }

  private warnAndNavigateToSearchScreen() {
    this.messageService.clear(MSG_KEY_NO_ENTITY_SELECTED);
    this.messageService.add({
      key: MSG_KEY_NO_ENTITY_SELECTED, severity: 'warn', summary: 'Geen entiteit geselecteerd',
      detail: 'Selecteer eerst een entiteit om te weergeven.'
    });
    this.router.navigate(['/authenticated/entiteit-zoeken']);
  }
}
