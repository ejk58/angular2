import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {VersionInformation} from 'iv-framework-lib';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable()
export class OperationsService {

  private readonly ENDPOINT_OPERATIONS = '/actuator/info';

  constructor(private readonly httpClient: HttpClient) {}

  public getApplicationInformation(): Observable<VersionInformation> {
    return this.httpClient.get<any>(this.ENDPOINT_OPERATIONS).pipe(
      map( r => { return {
        application: r.Application.application,
        version: r.Application.version,
        buildNumber: r.Application.buildNumber,
        buildTime: r.Application.buildTime
      } as VersionInformation;
      }));
  }
}
