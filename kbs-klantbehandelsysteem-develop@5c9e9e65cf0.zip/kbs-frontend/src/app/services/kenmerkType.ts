export enum KenmerkType {
    AG = 'AG', //aandachtsgebieden
    CBAP = 'CBAP', // cijferbeoordeling actiepunten
    CBAPB = 'CBAPB', // cijferbeoordeling actiepunten Balans
    CBAPW = 'CBAPW', // cijferbeoordeling actiepunten Winst en verlies
    CBOBA = 'CBOBA', // cijferbeoordeling attentiepunten
    CBIBV = 'CBIBV', // cijferbeoordeling attentiepunten inkomsten belasting en verzekeringen
    MID = 'MID', //(belangrijke) middelen
    BCAV = 'BCAV',  //Branchecode aanvulling
    RM = 'RM', //Kenmerken risicomanagement
    GS = 'GS', //Kenmerken governance-structuur
    EO = 'EO', //Externe omgeving
    BS = 'BS', //Bedrijfsstrategie
    SECTR = 'SECTR', //Sector
    CK = 'CK',  //ComplexiteitKenmerken
    RSTAT = 'RSTAT' //zicht op fiscliteit - middel specifieke risico statussen
}
