import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';
import {UserService} from './user.service';
import {tap} from "rxjs/operators";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  public static readonly HEADER_AUTHORIZATION = 'Authorization';
  public static readonly BODY_BEARER = 'Bearer ';

  constructor() {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const idToken = localStorage.getItem(UserService.KEY_ID_TOKEN);
    if (idToken && req.url !== UserService.ENDPOINT_LOGIN) {
      const cloned = req.clone({
        headers: req.headers.set(AuthInterceptor.HEADER_AUTHORIZATION, AuthInterceptor.BODY_BEARER + idToken)
      });

      return next.handle(cloned);
    } else {
      return next.handle(req)
        .pipe(tap((event: HttpEvent<any>) => {
          if (event instanceof HttpResponse) {
            let tkn = event.headers.get(AuthInterceptor.HEADER_AUTHORIZATION);
            if (tkn) {
              tkn = tkn.replace(AuthInterceptor.BODY_BEARER, '');
              localStorage.setItem(UserService.KEY_ID_TOKEN, tkn);
            }
          }
        }, (err: any) => {
          if (err instanceof HttpErrorResponse) {
            if (err.status === 401 || err.status === 403) {
              console.log('Token niet meer geldig');
              // TODO: redirect to the login route
              // or show a modal
            }
          }
        }));
    }
  }
}
