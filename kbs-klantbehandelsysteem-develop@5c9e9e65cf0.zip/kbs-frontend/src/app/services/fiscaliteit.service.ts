import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {ExceptionService} from "./exception.service";
import {catchError} from "rxjs/operators";
import {Observable} from "rxjs";
import {MiddelKenmerk} from "../interfaces/MiddelKenmerk";
import {EntiteitMiddelKenmerk} from "../entiteit/entiteit-zicht-op-fiscaliteit/middelspecifieke-kenmerken/EntiteitMiddelKenmerk";
import {MiddelRisico} from "../interfaces/MiddelRisico";
import {EntiteitKenmerk} from "../interfaces/EntiteitKenmerk";
import {EntiteitMiddelRisico} from "../entiteit/entiteit-zicht-op-fiscaliteit/middelspecifieke-riscos/EntiteitMiddelRisico";

@Injectable({
  providedIn: 'root'
})
export class FiscaliteitService {
  fiscaliteitRoot = '/api/fiscaliteit';

  constructor(private readonly httpClient: HttpClient,
              private readonly exceptionService: ExceptionService) {
  }

  public getKenmerkenByMiddelId(middelId: number): Observable<MiddelKenmerk[]> {
    return this.httpClient.get<MiddelKenmerk[]>(`${this.fiscaliteitRoot}/${middelId}/middelKenmerken`)
      .pipe(this.catch(`Middel Kenmerken ophalen is mislukt`));
  }

  public getRisiscosByMiddelId(middelId: number): Observable<MiddelRisico[]> {
    return this.httpClient.get<MiddelRisico[]>(`${this.fiscaliteitRoot}/${middelId}/middelRisicos`)
      .pipe(this.catch(`Middel Risicos ophalen is mislukt`));
  }

  public getRisicoStatussen(): Observable<EntiteitKenmerk[]> {
    return this.httpClient.get<EntiteitKenmerk[]>(`${this.fiscaliteitRoot}/middelRisicoStatussen`)
      .pipe(this.catch(`Middel Risico Statussen ophalen is mislukt`));

  }

  public getSelectedEntiteitMiddelKenmerken(entiteitNummer: number): Observable<EntiteitMiddelKenmerk[]> {
    return this.httpClient.get<EntiteitMiddelKenmerk[]>(`${this.fiscaliteitRoot}/${entiteitNummer}/entiteitMiddelKenmerken`)
      .pipe(this.catch(`Entiteit middelKenmerken ophalen is mislukt`));
  }

  public getSelectedMiddelRisicosByEntiteitNummerAndMiddelId(entiteitNummer: number, middelId: number): Observable<EntiteitMiddelRisico[]> {
    return this.httpClient.get<EntiteitMiddelRisico[]>(`${this.fiscaliteitRoot}/${entiteitNummer}/${middelId}/selectedEntiteitMiddelRisicos`)
      .pipe(this.catch(`Entiteit middel risicos ophalen is mislukt`));
  }

  public addEntiteitMiddelKenmerk(entiteitMiddelKenmerk: EntiteitMiddelKenmerk) {
    return this.httpClient.post<EntiteitMiddelKenmerk>(`${this.fiscaliteitRoot}/addEntiteitMiddelKenmerk`, entiteitMiddelKenmerk)
      .pipe(this.catch('Opslaan van entiteit middelKenmerken is mislukt'));
  }

  public addEntiteitMiddelRisico(entiteitMiddelRisico: EntiteitMiddelRisico) {
    return this.httpClient.post<EntiteitMiddelRisico>(`${this.fiscaliteitRoot}/addEntiteitMiddelRisico`, entiteitMiddelRisico)
      .pipe(this.catch('Opslaan van entiteit middel risico is mislukt'));
  }

  public deleteEntiteitMiddelKenmerk(entiteitMiddelKenmerk: EntiteitMiddelKenmerk) {
    return this.httpClient.delete<void>(`${this.fiscaliteitRoot}/${entiteitMiddelKenmerk.id}/deleteEntiteitMiddelKenmerk`)
      .pipe(this.catch(`Verwijderen voor EntiteitMiddelKenmerk id ${entiteitMiddelKenmerk.id} is mislukt`));

  }

  private catch(msg: string) {
    return catchError(e => this.exceptionService.catchBadResponse(e, `${msg}, ${ExceptionService.REFRESH_AND_TRY_AGAIN}`));
  }

  public getEntiteitMiddelKenmerkenForRisico(entiteitNummer: number, middelRisicoId: number): Observable<Map<number, MiddelKenmerk>> {
    return this.httpClient.get<Map<number, string>>(`${this.fiscaliteitRoot}/${entiteitNummer}/getEntiteitMiddelKenmerkenForRisico/${middelRisicoId}`)
      .pipe(this.catch(`Middel Kenmerken ophalen voor deze Middel Risico is mislukt`));
  }

  public getEntiteitMiddelKenmerkById(id: number): Observable<EntiteitMiddelKenmerk> {
    return this.httpClient.get<EntiteitMiddelKenmerk[]>(`${this.fiscaliteitRoot}/${id}/entiteitMiddelKenmerk`)
      .pipe(this.catch(`Entiteit middelKenmerk ophalen is mislukt`));
  }

  public deleteEntiteitMiddelRisico(entiteitMiddelRisico: EntiteitMiddelRisico) {
    return this.httpClient.delete<void>(`${this.fiscaliteitRoot}/${entiteitMiddelRisico.id}/deleteEntiteitMiddelRisico`)
      .pipe(this.catch(`Verwijderen voor entiteitMiddelRisico id ${entiteitMiddelRisico.id} is mislukt`));

  }
}
