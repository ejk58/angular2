import {Injectable} from '@angular/core';
import {HttpErrorResponse} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {MessageService} from 'primeng/api';

@Injectable({
  providedIn: 'root'
})
export class ExceptionService {

  public static readonly REFRESH_AND_TRY_AGAIN = 'ververs de pagina en probeer het opnieuw.';

  constructor(private readonly messageService: MessageService) {
  }

  catchBadResponse(errorResponse: HttpErrorResponse, msg?: string, ignore404=false): Observable<any> {
    console.log(`Bad Response gevangen: ${errorResponse.status}: ${errorResponse.statusText}`);
    switch (errorResponse.status) {
      case 400:
        if (!msg) {
          msg = errorResponse.error ? errorResponse.error : 'Onbekende fout opgetreden.';
        }
        this.messageService.add({key: 'error', severity: 'error', summary: 'Technische fout', detail: msg});
        break;
      case 403:
        this.messageService.add({key: 'warn', severity: 'warn', summary: 'Autorisatie fout', detail: 'Log alstublieft opnieuw in.'});
        break;
      case 404:
        if (! ignore404) {
          this.messageService.add({key: 'warn', severity: 'warn', summary: 'Geen gegevens gevonden', detail: 'Er zijn geen gegevens gevonden.'});
        }
        break;
      default:
        if (!msg) {
          msg = 'Onbekende fout opgetreden.';
        }
        this.messageService.add({key: 'error', severity: 'error', summary: 'Technische fout', detail: msg});
        break;
    }
    return throwError(`Technische fout opgetreden, ${ExceptionService.REFRESH_AND_TRY_AGAIN}`);
  }
}
