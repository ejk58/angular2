import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {tap} from 'rxjs/operators';

export interface LdapPerson {
  userId: string,
  name: string,
  email: string,
  role: string,
}

@Injectable({
  providedIn: 'root',
})
export class DummyService {

  constructor(private readonly httpClient: HttpClient) {
  }

  public answer(): Observable<LdapPerson> {
    return this.httpClient.get<LdapPerson>('/api/answer')
      .pipe(tap(answer => console.log('Answer: ', answer)));
  }
}
