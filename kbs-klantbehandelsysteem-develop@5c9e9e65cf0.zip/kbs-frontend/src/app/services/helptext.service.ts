import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {Helptext} from "../componenten-generiek/helptext/helptext";
import {ExceptionService} from "./exception.service";
import {catchError} from "rxjs/operators";

@Injectable({
  providedIn: 'root',
})
export class HelptextService {

  constructor(private readonly httpClient: HttpClient,
              private readonly exceptionService: ExceptionService) {
  }

  public getHelptextTooltip(id: string): Observable<Helptext> {
    return this.httpClient.get<Helptext>(`/api/helptext/${id}`);
  }

  public getHelptextForEntiteit(id: string, entiteit: number): Observable<Helptext> {
    return this.httpClient.get<Helptext>(`/api/helptext/${id}/for/${entiteit}`)
      .pipe(this.catch('Ophalen van helptekst is mislukt'));
  }

  saveHelptext(helptext: Helptext) {
    return this.httpClient.post<Helptext>(`/api/helptext/save`, helptext)
      .pipe(this.catch('Opslaan van gewijzigde tekst is mislukt'));
  }

  private catch(msg: string) {
    return catchError(e => this.exceptionService.catchBadResponse(e, `${msg}, ${ExceptionService.REFRESH_AND_TRY_AGAIN}`));
  }
}
