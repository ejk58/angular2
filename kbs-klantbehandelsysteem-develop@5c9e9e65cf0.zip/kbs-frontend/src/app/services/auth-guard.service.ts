import {CanActivate, Router} from '@angular/router';
import {Injectable} from '@angular/core';
import {UserService} from './user.service';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private readonly userService: UserService, private readonly router: Router) {
  }

  canActivate(): boolean {
    if (!this.userService.isSignedIn()) {
      this.router.navigate(['/signin']);
    }
    return this.userService.isSignedIn();
  }
}
