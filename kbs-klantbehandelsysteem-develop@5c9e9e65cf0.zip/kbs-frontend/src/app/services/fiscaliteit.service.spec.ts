import { TestBed } from '@angular/core/testing';

import { FiscaliteitService } from './fiscaliteit.service';

describe('FiscaliteitService', () => {
  let service: FiscaliteitService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FiscaliteitService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
