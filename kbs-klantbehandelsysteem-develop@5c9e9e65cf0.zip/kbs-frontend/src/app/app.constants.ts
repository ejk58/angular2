export const PATH_PARAM_NUMMER = 'nummer';

export const MSG_KEY_NO_ENTITY_SELECTED = 'noEntitySelected';
