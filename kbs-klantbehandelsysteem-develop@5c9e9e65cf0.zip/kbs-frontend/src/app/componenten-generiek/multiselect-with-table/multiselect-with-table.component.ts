import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {EntiteitKenmerk} from "../../interfaces/EntiteitKenmerk";
import {ZooEntiteitAandachtsGebied} from '../../interfaces/ZooEntiteitAandachtsGebied';

@Component({
  selector: 'app-multiselect-with-table',
  templateUrl: './multiselect-with-table.component.html',
  styleUrls: ['./multiselect-with-table.component.scss']
})
export class MultiselectWithTableComponent implements OnInit {

  asZooEntiteitAandachtsGebied = (ag: ZooEntiteitAandachtsGebied) => ag;

  @Input()
  aandachtsgebieden: ZooEntiteitAandachtsGebied[];
  @Input()
  selectedAandachtsgebieden: ZooEntiteitAandachtsGebied[];
  @Output()
  onSave = new EventEmitter<ZooEntiteitAandachtsGebied[]>();

  saveSelections() {
    this.onSave.emit(this.selectedAandachtsgebieden);
  }

  ngOnInit(): void {
  }

  removeFromSelection(entityId: number) {
    this.selectedAandachtsgebieden = this.selectedAandachtsgebieden.filter(e => e.id !== entityId)
    this.saveSelections()
  }

  checkboxChange(e: { checked: boolean, originalEvent: any }, entity: ZooEntiteitAandachtsGebied) {
    this.selectedAandachtsgebieden.filter(k => k.id === entity.id)[0].values = `${e.checked}`;
    this.saveSelections()
  }

  setSwitch(entity: ZooEntiteitAandachtsGebied): boolean {
    return entity.values === "true";
  }
}

