import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiselectWithTableComponent } from './multiselect-with-table.component';

describe('MultiselectWithTableComponent', () => {
  let component: MultiselectWithTableComponent;
  let fixture: ComponentFixture<MultiselectWithTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultiselectWithTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiselectWithTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
