import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KbsButtonComponent } from './kbs-button.component';

describe('KbsButtonComponent', () => {
  let component: KbsButtonComponent;
  let fixture: ComponentFixture<KbsButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KbsButtonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KbsButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
