import {Helptext} from '../helptext/helptext';

export interface TextPopEditorConfig {
  helptext: Helptext;
  maxLength?: number;
  editorTitle:string;
  editorTitleTextType: string;
}
