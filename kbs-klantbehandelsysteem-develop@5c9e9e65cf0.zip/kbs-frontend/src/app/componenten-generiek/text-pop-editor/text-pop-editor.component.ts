import {Component, Inject} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {Helptext} from '../helptext/helptext';
import Quill from 'quill';
import {TextPopEditorConfig} from './text-pop-editor-config';
import {ContentChange} from 'ngx-quill';
import {ByteUtil} from '../../utils/byte-util';

@Component({
  selector: 'app-text-pop-editor',
  templateUrl: './text-pop-editor.component.html',
  styleUrls: ['./text-pop-editor.component.scss']
})
export class TextPopEditorComponent {

  ByteUtil = ByteUtil;

  editor: Quill;
  info: Helptext;
  maxLength: number; // For text only
  readonly maxContentLength = 1048576; // For full HTML contents, value based on datatype of HELPTEXT.HELPTEXT CLOB column
  changedContent: ContentChange;
  editorTitle:string;
  editorTitleTextType: string;

  constructor(private readonly dialogRef: MatDialogRef<TextPopEditorComponent>,
              @Inject(MAT_DIALOG_DATA) data: TextPopEditorConfig) {
    this.info = data.helptext;
    this.maxLength = data.maxLength > 0 ? data.maxLength : undefined;
    this.editorTitle = data.editorTitle;
    this.editorTitleTextType = data.editorTitleTextType;
  }

  onContentChanged(event: ContentChange) {
    this.changedContent = event;
  }

  saveValues() {
    const editedText = new Helptext(
      this.info.id,
      this.changedContent ? this.changedContent.html : this.info.txt,
      this.info.userId,
      this.info.changed,
      this.info.entiteit
    );
    this.dialogRef.close(editedText);
  }

  onCancel() {
    this.dialogRef.close();
  }

  onEditorCreated(editor: Quill) {
    if (editor) {
      this.editor = editor;
      this.editor.setSelection(editor.getLength(), 0); // Place cursor at end of text and give focus
    }
  }

  canEditHelptext() {
    //TODO: Permissions to users who can edit the tooltip will be determined at a later stage.
    return true;
  }

  getContentLength(): number {
    return this.changedContent?.html?.length ?? 0;
  }

  isContentTooLong(): boolean {
    return this.getContentLength() > this.maxContentLength;
  }
}
