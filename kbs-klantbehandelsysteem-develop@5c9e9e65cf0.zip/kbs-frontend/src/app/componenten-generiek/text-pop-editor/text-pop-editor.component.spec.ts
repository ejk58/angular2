import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TextPopEditorComponent } from './text-pop-editor.component';

describe('TextPopEditorComponent', () => {
  let component: TextPopEditorComponent;
  let fixture: ComponentFixture<TextPopEditorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TextPopEditorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TextPopEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
