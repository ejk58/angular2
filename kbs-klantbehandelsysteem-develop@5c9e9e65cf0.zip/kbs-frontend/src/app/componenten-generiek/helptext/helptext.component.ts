import {Component, Input} from '@angular/core';
import {MatDialog} from "@angular/material/dialog";
import {TextPopEditorComponent} from "../text-pop-editor/text-pop-editor.component";
import {Helptext} from "./helptext";
import {HelptextService} from "../../services/helptext.service";
import {TextPopEditorConfig} from '../text-pop-editor/text-pop-editor-config';

@Component({
  selector: 'app-helptext',
  templateUrl: './helptext.component.html',
  styleUrls: ['./helptext.component.scss']
})
export class HelptextComponent {

  @Input() helpText: Helptext;
  @Input() maxLength: number;
  @Input() editorTitle:string;

  constructor(private readonly dialog: MatDialog,
              private readonly helptextService: HelptextService) {
  }

  public editContent() {
    const editorConfig: TextPopEditorConfig = {
      helptext: this.helpText,
      maxLength: this.maxLength,
      editorTitle: this.editorTitle,
      editorTitleTextType: '(toelichting)'
    };
    const dialogRef = this.dialog.open(TextPopEditorComponent, {
      data: editorConfig,
      width: '1000px',
      position: {
        top: '20vh',
        left: '20vw'
      },
      autoFocus: false
    });
    dialogRef.beforeClosed().subscribe((result: Helptext | undefined) => {
      if (result !== undefined) {
        result.txt = result.txt ?? '';
        this.saveEditedInfo(result);
      }
    });
  }

  private saveEditedInfo(helptext: Helptext) {
    this.helpText = undefined;
    this.helptextService.saveHelptext(helptext).subscribe(editedInfo => this.helpText = editedInfo);
  }
}
