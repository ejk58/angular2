export class Helptext {
  id: string
  txt: string
  userId: string
  changed: Date
  entiteit: number

  constructor(id: string, txt: string, userId: string, changed: Date, entiteit: number) {
    this.id = id;
    this.txt = txt;
    this.userId = userId;
    this.changed = changed;
    this.entiteit = entiteit;
  }
}
