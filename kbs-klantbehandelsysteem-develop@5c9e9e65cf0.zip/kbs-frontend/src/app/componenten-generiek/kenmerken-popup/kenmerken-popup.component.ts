import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {ZooEntiteitBranchecodeAanvulling} from "../../interfaces/ZooEntiteitBranchecodeAanvulling";
import {KenmerkenService} from "../../services/kenmerken.service";
import {KenmerkType} from "../../services/kenmerkType";

@Component({
  selector: 'app-kenmerken-popup',
  templateUrl: './kenmerken-popup.component.html',
  styleUrls: ['./kenmerken-popup.component.scss']
})
export class KenmerkenPopupComponent implements OnInit {

  subEntiteitBsn: number;
  allKenmerken: ZooEntiteitBranchecodeAanvulling[] = [];
  selectedChildKenmerken: ZooEntiteitBranchecodeAanvulling[] = [];

  constructor(@Inject(MAT_DIALOG_DATA) data: [number],
              private readonly dialogRef: MatDialogRef<KenmerkenPopupComponent>,
              private kenmerkenService: KenmerkenService) {
      this.subEntiteitBsn = data[0];
  }

  ngOnInit() {
    this.kenmerkenService.getZooBranchecodeAanvulling().subscribe((data) => {
      this.allKenmerken = data;
    })
    this.kenmerkenService.getZooBranchecodeAanvullingBy(this.subEntiteitBsn).subscribe(data => {
      this.selectedChildKenmerken = data;
    });

  }

  onCancel(dialogRef: MatDialogRef<KenmerkenPopupComponent>) {
    dialogRef.close();
  }

  saveKenmerken(selectedSubKenmerken: ZooEntiteitBranchecodeAanvulling[]) {
    this.kenmerkenService.saveSelections(this.subEntiteitBsn, KenmerkType.BCAV, selectedSubKenmerken).subscribe();
    this.selectedChildKenmerken = selectedSubKenmerken;
    this.dialogRef.close();
  }

}
