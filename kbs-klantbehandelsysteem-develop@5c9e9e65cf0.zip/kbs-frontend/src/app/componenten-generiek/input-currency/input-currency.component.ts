import {Component, Input, OnInit} from '@angular/core';
import {InputNumberComponent} from '../input-number/input-number.component';
import {AbstractValueAccessor} from '../abstract-value-accessor';

@Component({
  selector: 'app-input-currency',
  templateUrl: './input-currency.component.html',
  styleUrls: ['./input-currency.component.scss'],
  providers: [AbstractValueAccessor.makeProvider(InputCurrencyComponent)]
})
export class InputCurrencyComponent extends InputNumberComponent implements OnInit {

  @Input() minFractionDigits: number;
  @Input() maxFractionDigits: number;

  placeholder: string;

  constructor() {
    super();
  }

  ngOnInit() {
    this.minFractionDigits = this.minFractionDigits || 0;
    this.maxFractionDigits = this.maxFractionDigits || 0;
    this.placeholder = this.createPlaceholder();
  }

  createPlaceholder(): string {
    let p = '0';
    if (this.maxFractionDigits > 0) {
      p += ',';
      p = p.padEnd(p.length + this.maxFractionDigits, '0')
    }
    return p;
  }
}
