import {Component, Input, OnInit} from '@angular/core';
import {AbstractValueAccessor} from '../abstract-value-accessor';

@Component({
  selector: 'app-input-number',
  templateUrl: './input-number.component.html',
  styleUrls: ['./input-number.component.scss'],
  providers: [AbstractValueAccessor.makeProvider(InputNumberComponent)]
})
export class InputNumberComponent extends AbstractValueAccessor implements OnInit {

  // Do not allow user to increment/decrement the input value using the up and down arrow keys
  readonly step = 0;

  @Input() label: string;
  @Input() modelName: string;
  @Input() size: number;
  @Input() min: number;
  @Input() cTabIndex: string;
  @Input() disabled: boolean;

  constructor() {
    super();
  }

  ngOnInit() {
    this.size = this.size || 3;
    this.min = this.min || 0;
    this.disabled = this.disabled || false;
  }
}
