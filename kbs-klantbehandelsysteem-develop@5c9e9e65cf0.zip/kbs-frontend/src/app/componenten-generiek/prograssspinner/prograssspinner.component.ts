import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-prograssspinner',
  templateUrl: './prograssspinner.component.html',
  styleUrls: ['./prograssspinner.component.scss']
})
export class PrograssspinnerComponent {
  @Input() style: any = null;
}
