import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrograssspinnerComponent } from './prograssspinner.component';

describe('PrograssspinnerComponent', () => {
  let component: PrograssspinnerComponent;
  let fixture: ComponentFixture<PrograssspinnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrograssspinnerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrograssspinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
