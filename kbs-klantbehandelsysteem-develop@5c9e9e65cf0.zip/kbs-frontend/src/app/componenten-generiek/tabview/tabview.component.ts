import {Component, Input} from '@angular/core';
import {TabviewData} from "./interfaces/tabviewData";
import {TabpanelData} from "./interfaces/tabpanelData";
import {CBTabPanel} from "../../entiteit/cijferbeoordeling/cijferbeoordelingTabpanels";

@Component({
  selector: 'app-tabview',
  templateUrl: './tabview.component.html',
  styleUrls: ['./tabview.component.scss']
})
export class TabviewComponent {
  @Input() tabviewData: TabviewData[];

  getTabPanelData(entiteitId: number, header: CBTabPanel): TabpanelData {
    return {entiteitId: entiteitId, panelType: header};
  }
}
