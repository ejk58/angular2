import {CBTabPanel} from "../../../entiteit/cijferbeoordeling/cijferbeoordelingTabpanels";

export interface TabpanelData {
  entiteitId: number;
  panelType: CBTabPanel;
}
