import {CBTabPanel} from "../../../entiteit/cijferbeoordeling/cijferbeoordelingTabpanels";

export interface TabviewData {
  tabId: number;
  entiteitId: number;
  groep: string;
  header: CBTabPanel;
}
