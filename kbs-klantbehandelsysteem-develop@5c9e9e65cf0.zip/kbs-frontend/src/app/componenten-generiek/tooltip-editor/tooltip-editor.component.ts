import {Component, Inject} from '@angular/core';
import {Helptext} from "../helptext/helptext";
import {FormGroup} from "@angular/forms";
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from "@angular/material/dialog";
import {HelptextService} from "../../services/helptext.service";
import {TextPopEditorComponent} from "../text-pop-editor/text-pop-editor.component";
import {TextPopEditorConfig} from '../text-pop-editor/text-pop-editor-config';
import {Subject} from "rxjs";

@Component({
  selector: 'app-tooltip-editor',
  templateUrl: './tooltip-editor.component.html',
  styleUrls: ['./tooltip-editor.component.scss']
})
export class TooltipEditorComponent {

  cfg: TextPopEditorConfig | null;
  toolTipForm: FormGroup;

  constructor(@Inject(MAT_DIALOG_DATA) data: TextPopEditorConfig | null,
              private readonly dialog: MatDialog,
              private readonly dialogRef: MatDialogRef<TooltipEditorComponent>,
              private readonly helptextService: HelptextService) {
    this.cfg = data;

    this.toolTipForm = new FormGroup({});
  }

  editToolTipText() {
    const dialogRef = this.dialog.open(TextPopEditorComponent, {
      data: this.cfg,
      width: '1000px',
      position: {
        top: '20vh',
        left: '20vw'
      },
      autoFocus: false
    });
    const onHelptext: Subject<Helptext> = new Subject<Helptext>();
    this.dialogRef.close(onHelptext.asObservable());
    dialogRef.afterClosed().subscribe((result: Helptext | undefined) => {
      if (result !== undefined) {
        result.txt = result.txt ?? '';
        this.helptextService.saveHelptext(result).subscribe(r => {
          onHelptext.next(r);
        });
      }
    });
  }

  onCancel() {
    this.dialogRef.close()
    return false;
  }

  canEditTooltip() {
    //TODO: Permissions to users who can edit the tooltip will be determined at a later stage.
    return true;
  }
}
