import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TooltipEditorComponent } from './tooltip-editor.component';

describe('TooltipEditorComponent', () => {
  let component: TooltipEditorComponent;
  let fixture: ComponentFixture<TooltipEditorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TooltipEditorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TooltipEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
