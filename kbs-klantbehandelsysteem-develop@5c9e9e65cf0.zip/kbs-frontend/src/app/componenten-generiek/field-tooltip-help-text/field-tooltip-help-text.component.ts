import {Component, Input, OnInit} from '@angular/core';
import {HelptextService} from '../../services/helptext.service';
import {Observable} from 'rxjs';
import {Helptext} from '../helptext/helptext';
import {EntiteitService} from '../../services/entiteit.service';

@Component({
  selector: 'kbs-field-tooltip-help-text',
  templateUrl: './field-tooltip-help-text.component.html',
  styleUrls: ['./field-tooltip-help-text.component.scss']
})
export class FieldTooltipHelpTextComponent implements OnInit {

  @Input()
  title: string;
  @Input()
  helpTextId: string;
  @Input()
  tooltipText: string;

  textToelichtingTooltip$: Observable<Helptext>;
  textToelichting$: Observable<Helptext>;

  constructor(
    private readonly entiteitService: EntiteitService,
    private readonly helptextService: HelptextService
  ) {
  }

  ngOnInit(): void {
    this.textToelichtingTooltip$ = this.helptextService.getHelptextTooltip(this.tooltipText);
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.textToelichting$ = this.helptextService.getHelptextForEntiteit(this.helpTextId, nr);
    });

  }

}
