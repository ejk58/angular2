import {Component, OnInit} from '@angular/core';
import {DummyService, LdapPerson} from '../services/dummy.service';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  answer$: Observable<LdapPerson>;

  constructor(private readonly dummyService: DummyService) { }

  ngOnInit(): void {
    this.answer$ = this.dummyService.answer();
  }

}
