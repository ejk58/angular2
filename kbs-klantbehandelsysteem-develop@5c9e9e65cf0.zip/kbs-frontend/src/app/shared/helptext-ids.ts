export abstract class HelptextIds {
  static readonly ZOO_ORGANISATIEAARD_TITLE = 'organisatieAard_title';
  static readonly ORGANISATIEAARD_TOELICHTING = 'organisatieAard_toelichting';
  static readonly ORGANISATIEAARD_TOELICHTING_TOOLTIP = 'organisatieAard_toelichting_tooltip';
  static readonly ORGANISATIEAARD_SECTOR_TOOLTIP = 'organisatieAard_sector_tooltip';
  static readonly ORGANISATIEAARD_BRANCHE_TOOLTIP = 'organisatieAard_branche_tooltip';
  static readonly ORGANISATIEAARD_AANDACHTSGEBIEDEN_TOOLTIP = 'organisatieAard_aandachtsgebieden_tooltip';
  static readonly ORGANISATIEAARD_MIDDELEN_TOOLTIP = 'organisatieAard_middelen_tooltip';

  static readonly ORGANISATIEOMVANG_TOELICHTING = 'organisatieOmvang_toelichting';

  static readonly COMPLEXITEIT_TOELICHTING = 'complexiteit_toelichting';
  static readonly COMPLEXITEIT_TOOLTIP = 'complexiteit_tooltip';

  static readonly IN_EN_EXTERNE_BEDRIJFSSTRATEGIE_TOOLTIP = 'in_en_externe_bedrijfsstrategie_tooltip';
  static readonly IN_EN_EXTERNE_BEDRIJFSSTRATEGIE_TOELICHTING = 'in_en_externe_bedrijfsstrategie_toelichting';
  static readonly IN_EN_EXTERNE_EXTERNEOMGEVING_TOOLTIP = 'in_en_externe_externeomgeving_tooltip';
  static readonly IN_EN_EXTERNE_EXTERNEOMGEVING_TOELICHTING = 'in_en_externe_externeomgeving_toelichting';
  static readonly IN_EN_EXTERNE_INTERNEORGANISATIE_TOOLTIP = 'in_en_externe_interneorganisatie_tooltip';
  static readonly IN_EN_EXTERNE_GOVERNANCE_STRUCTUUR_TOOLTIP = 'in_en_externe_governancestructuur_tooltip';
  static readonly IN_EN_EXTERNE_GOVERNANCE_STRUCTUUR_TOELICHTING = 'in_en_externe_governancestructuur_toelichting';
  static readonly IN_EN_EXTERNE_VERDIENMODELKERNACTIVITEITEN_TOELICHTING = 'verdienmodel_kernactiviteiten_toelichting';
  static readonly IN_EN_EXTERNE_VERDIENMODELKERNACTIVITEITEN_TOOLTIP = 'verdienmodel_kernactiviteiten_tooltip';
  static readonly IN_EN_EXTERNE_RISCOMANAGEMENT_TOOLTIP = 'in_en_externe_risicoManagement_tooltip';
  static readonly IN_EN_EXTERNE_RISCOMANAGEMENT_TOELICHTING = 'in_en_externe_risicoManagement_toelichting';

  static readonly CIJFERBEOORDELING_ORGANISATIEOMVANG_TITLE               = 'organisatieomvang_title';
  static readonly CIJFERBEOORDELING_ORGANISATIEOMVANG_TOELICHTING_TOOLTIP = 'organisatieomvang_toelichting_tooltip';
  static readonly CIJFERBEOORDELING_ORGANISATIEOMVANG_TEXT_TOELICHTING    = 'organisatieomvang_text_toelichting';

  static readonly CIJFERBEOORDELING_OVERIGEMIDDELEN_TITLE_TOOLTIP       = 'zoo_overigemiddelen_title_tooltip';
  static readonly CIJFERBEOORDELING_OVERIGEMIDDELEN_ANALYSE_TOOLTIP      = 'zoo_overigemiddelen_analyse_tooltip';
  static readonly CIJFERBEOORDELING_OVERIGEMIDDELEN_ANALYSE_TOELICHTING  = 'zoo_overigemiddelen_analyse_toelichting';
  static readonly CIJFERBEOORDELING_OVERIGEMIDDELEN_CONCLUSIE_TOOLTIP      = 'zoo_overigemiddelen_conclusie_tooltip';
  static readonly CIJFERBEOORDELING_OVERIGEMIDDELEN_CONCLUSIE_TOELICHTING  = 'zoo_overigemiddelen_conclusie_toelichting';

  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_TITLE               = 'organisatieomvang_venbel_title';
  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_TOELICHTING_TOOLTIP = 'organisatieomvang_venbel_toelichting_tooltip';
  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_TEXT_TOELICHTING    = 'organisatieomvang_venbel_text_toelichting';

  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_BALANSANALYSE_TOOLTIP     = 'orgomv_venbel_bana_toelichting_tooltip';
  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_BALANSANALYSE_TOELICHTING = 'orgomv_venbel_bana_text_toelichting';

  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_ANALYSE_WINSTVERLIES_TOOLTIP
                                                                              = 'orgomv_venbel_analyse_wv_tooltip';
  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_ANALYSE_WINSTVERLIES_TOELICHTING
                                                                              = 'orgomv_venbel_analyse_wv_toelichting';

  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_CONCLUSIE_TOOLTIP
    = 'orgomv_venbel_conclusie_tooltip';
  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_CONCLUSIE_TOELICHTING
    = 'orgomv_venbel_conclusie_toelichting';
  static readonly CIJFERBEOORDELING_OMZETBELASTING_TITLE_TOOLTIP  = 'orgomv_omzetbel_title_tooltip'
  static readonly CIJFERBEOORDELING_OMZETBELASTING_ANALYSE_TOOLTIP  = 'orgomv_omzetbel_analyse_tooltip'
  static readonly CIJFERBEOORDELING_OMZETBELASTING_ANALYSE_TOELICHTING  = 'orgomv_omzetbel_analyse_toelichting'
  static readonly CIJFERBEOORDELING_OMZETBELASTING_CONCLUSIE_TOOLTIP  = 'orgomv_omzetbel_conclusie_tooltip'
  static readonly CIJFERBEOORDELING_OMZETBELASTING_CONCLUSIE_TOELICHTING  = 'orgomv_omzetbel_conclusie_toelichting'
  static readonly CIJFERBEOORDELING_OMZETBELASTING_ATTENTIEPUNTEN_TOOLTIP  = 'orgomv_omzetbel_attentiepunten_tooltip'

  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELATING_ATTENTITEPUNTEN_TOOLTIP = 'orgomv-venbel_attentiepunten_tooltip'
  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELATING_ATTENTITEPUNTEN_BALANS_TOOLTIP = 'orgomv-venbel_attentiepunten_balans_tooltip'
  static readonly CIJFERBEOORDELING_VENNOOTSCHAPBELATING_ATTENTITEPUNTEN_WV_TOOLTIP = 'orgomv-venbel_attentiepunten__wv_tooltip'

  static readonly CIJFERBEOORDELING_LOONHEFFINGEN_TITLE_TOOLTIP = 'cijferb_loonheffingen_title_tooltip';
  static readonly CIJFERBEOORDELING_LOONHEFFINGEN_AANGIFTE_TOOLTIP = 'cijferb_loonheffingen_aangifte_tooltip';
  static readonly CIJFERBEOORDELING_LOONHEFFINGEN_AANGIFTE_TOELICHTING= 'cijferb_loonheffingen_aangifte_toelichting';

  static readonly CIJFERBEOORDELING_LOONHEFFINGEN_AANDACHTSPUNTEN_TOOLTIP = 'cijferb_loonheffingen_aandachtspunten_tooltip';
  static readonly CIJFERBEOORDELING_LOONHEFFINGEN_AANDACHTSPUNTEN_TOELICHTING= 'cijferb_loonheffingen_aandachtspunten_toelichting';

  static readonly FISCALITEIT_MIDDELSPECIFIEKE_KENMERKEN_TITLE_TOOLTIP = 'fiscal_kenmerken_title_tooltip';
  static readonly FISCALITEIT_MIDDELSPECIFIEKE_KENMERKEN_TOOLTIP = 'fiscal_kenmerken_tooltip';
  static readonly FISCALITEIT_MIDDELSPECIFIEKE_KENMERKEN_TOELICHTING = 'fiscal_kenmerken_toelichting';
  static readonly FISCALITEIT_MIDDELSPECIFIEKE_RISICOS_TITLE_TOOLTIP = 'fiscal_risicos_title_tooltip';
  static readonly FISCALITEIT_MIDDELSPECIFIEKE_RISICOS_TOOLTIP = 'fiscal_risicos_tooltip';
  static readonly FISCALITEIT_MIDDELSPECIFIEKE_RISICOS_TOELICHTING = 'fiscal_risicos_toelichting';

  static readonly CIJFERBEOORDELING_INVORDERING_TITLE_TOOLTIP = 'cijferb_invordering_title_tooltip';
  static readonly CIJFERBEOORDELING_INVORDERING_ANALYSE_TOOLTIP = 'cijferb_invordering_analyse_tooltip';
  static readonly CIJFERBEOORDELING_INVORDERING_ANALYSE_TOELICHTING= 'cijferb_invordering_analyse_toelichting';
  static readonly CIJFERBEOORDELING_INVORDERING_AANDACHTSPUNTEN_TOOLTIP = 'cijferb_invordering_aandachtspunten_tooltip';
  static readonly CIJFERBEOORDELING_INVORDERING_AANDACHTSPUNTEN_TOELICHTING= 'cijferb_invordering_aandachtspunten_toelichting';

  static readonly CIJFERBEOORDELING_INKOMSTENBELASTING_TITLE_TOOLTIP = 'cijferb_inkomsten-belasting_title_tooltip';
  static readonly CIJFERBEOORDELING_INKOMSTENBELASTING_ANALYSE_TOELICHTING = 'cijferb_inkomsten-belasting_analyse_toelichting';
  static readonly CIJFERBEOORDELING_INKOMSTENBELASTING_ANALYSE_TITLE_TOOLTIP = 'cijferb_inkomsten-belasting_analyse_title-tooltip';
  static readonly CIJFERBEOORDELING_INKOMSTENBELASTING_ATTENTIEPUNTEN_TITLE_TOOLTIP = 'cijferb_inkomsten-belasting_attent_tooltip';
  static readonly CIJFERBEOORDELING_INKOMSTENBELASTING_CONCLUSIE_TITLE_TOOLTIP = 'cijferb_inkomsten-belasting_conclus_title-tooltip';
  static readonly CIJFERBEOORDELING_INKOMSTENBELASTING_CONCLUSIE_TOELICHTING = 'cijferb_inkomsten-belasting_conclus_toelichting';

}
