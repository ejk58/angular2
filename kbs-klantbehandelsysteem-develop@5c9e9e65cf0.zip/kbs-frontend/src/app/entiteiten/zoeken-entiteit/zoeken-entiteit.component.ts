import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Entiteit} from '../../entiteit/shared/entiteit';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-zoeken-entiteit',
  templateUrl: './zoeken-entiteit.component.html',
  styleUrls: ['./zoeken-entiteit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ZoekenEntiteitComponent implements OnInit {

  readonly numericPattern = new RegExp('^[0-9]+$');

  entiteit: Entiteit;

  @Input() isSearchInProgress: boolean;
  @Output() search: EventEmitter<Entiteit> = new EventEmitter();

  constructor() {
  }

  ngOnInit() {
    this.entiteit = {
      nummer: null,
      naam: null,
      klantpakket: null,
      adres: null,
      brancheCode: null,
      brancheNaam: null,
      bestuurlijkVerband: null,
      kantoorCode: null,
      kantoorNaam: null,
      klantCoordinator: null,
      klantGroep: null,
      teamCode: null,
      teamNaam: null,
    };
  }

  submit(form: NgForm) {
    if (form.valid) {
      this.search.emit(this.entiteit);
    }
  }

  isSearchDisabledOrInProgress(): boolean {
    return !(this.entiteit.nummer || this.entiteit.naam || this.entiteit.klantpakket) || this.isSearchInProgress;
  }
}
