import {ComponentFixture, TestBed} from '@angular/core/testing';

import {ZoekenEntiteitComponent} from './zoeken-entiteit.component';

describe('ZoekenEntiteitComponent', () => {
  let component: ZoekenEntiteitComponent;
  let fixture: ComponentFixture<ZoekenEntiteitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZoekenEntiteitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZoekenEntiteitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
