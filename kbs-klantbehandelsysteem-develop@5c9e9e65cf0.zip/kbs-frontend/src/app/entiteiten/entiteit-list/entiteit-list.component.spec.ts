import {ComponentFixture, TestBed} from '@angular/core/testing';

import {EntiteitListComponent} from './entiteit-list.component';

describe('EntiteitListComponent', () => {
  let component: EntiteitListComponent;
  let fixture: ComponentFixture<EntiteitListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
