import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {Entiteit} from '../../entiteit/shared/entiteit';
import {Router} from '@angular/router';
import {EntiteitService} from "../../services/entiteit.service";

@Component({
  selector: 'app-entiteit-list',
  templateUrl: './entiteit-list.component.html',
  styleUrls: ['./entiteit-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EntiteitListComponent implements OnInit {

  @Input() entiteiten$: Observable<Entiteit[]>;

  asEntiteit = (e: Entiteit) => e;

  constructor(private readonly router: Router, private readonly entiteitenService: EntiteitService) {
  }

  ngOnInit() {
  }

  getDetails(entiteitNummer: number) {
    this.entiteitenService.setSearchEntiteitNummer(entiteitNummer);
    this.router.navigate(['/authenticated/raadplegen-klant-gegevens'])
  }
}
