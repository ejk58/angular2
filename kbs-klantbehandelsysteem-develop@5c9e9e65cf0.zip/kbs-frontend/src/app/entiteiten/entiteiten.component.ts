import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {Entiteit} from '../entiteit/shared/entiteit';
import {EntiteitService} from '../services/entiteit.service';
import {tap} from 'rxjs/operators';

@Component({
  selector: 'app-entiteiten',
  templateUrl: './entiteiten.component.html',
  styleUrls: ['./entiteiten.component.scss']
})
export class EntiteitenComponent implements OnInit {

  entiteiten$: Observable<Entiteit[]>;
  isSearchInProgress: boolean;

  constructor(private readonly entiteitService: EntiteitService) {
  }

  ngOnInit() {
  }

  search(e: Entiteit) {
    this.isSearchInProgress = true;
    this.entiteiten$ = this.entiteitService.search(e.nummer, e.naam, e.klantpakket)
      .pipe(tap(() => this.done(), () => this.done(), () => this.done())); // Consider the search completed when any events occur on this observable.
  }

  done() {
    this.isSearchInProgress = false;
  }
}
