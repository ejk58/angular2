import {Component, OnInit} from '@angular/core';
import {initialMenuItems, searchedEntityMenuItems, searchedEntityMenuItems1} from './app.menu';
import {ConfigurationService, FrameworkConfigSettings, MenuItem, MenuService} from 'iv-framework-lib';
import {EntiteitService} from "./services/entiteit.service";
import {MSG_KEY_NO_ENTITY_SELECTED} from './app.constants';
import {KenmerkenService} from "./services/kenmerken.service";

export const urlZichtOpFiscaliteit: string = 'authenticated/zicht-op-fiscaliteit';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  readonly MSG_KEY_NO_ENTITY_SELECTED = MSG_KEY_NO_ENTITY_SELECTED;
  middelSubmenu: Array<MenuItem> = [];

  zichtOpFiscaliteit: MenuItem = {
    text: 'Zicht op fiscaliteit',
    route: urlZichtOpFiscaliteit
  };

  constructor(private readonly menuService: MenuService,
              private readonly configService: ConfigurationService,
              private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService
  ) {
    const config: FrameworkConfigSettings = {
      applicationName: 'Klantbehandelsysteem',
      useFeedback: true,
      hideLinkToBelastingdienst: true,
      hideButtonToSwitchVerticalMenuToTopStyle: true,
      showLeftIconForMenuItem: false
    }
    configService.configure(config);

    menuService.items = initialMenuItems;
  }

  ngOnInit() {
    this.entiteitService.searchEntiteit.subscribe((id)=>{
      if (id > 0) {
        this.kenmerkenService.getSelectedMiddelen(id).subscribe(data => {
          this.middelSubmenu = [];
          const dynamicallyAddedMiddel: MenuItem[] = data
            .map((middel) => ({
              text: middel.kenmerk,
              route: urlZichtOpFiscaliteit + "/" + middel.kenmerk
            } as MenuItem));
          this.middelSubmenu.push(...dynamicallyAddedMiddel);
          if(this.middelSubmenu.length !== 0)
            this.zichtOpFiscaliteit.submenu = this.middelSubmenu;
          this.menuService.items = initialMenuItems.concat(searchedEntityMenuItems).concat(this.zichtOpFiscaliteit).concat(searchedEntityMenuItems1);
        });
      }
      //todo: this does not work dynamically
      else {
        this.menuService.items = initialMenuItems;
      }
    });
  }
}
