import {QuillConfig, QuillToolbarConfig} from 'ngx-quill';
import Quill from 'quill';
import MagicUrl from 'quill-magic-url';

Quill.register('modules/magicUrl', MagicUrl);

const QUILL_ALLOWED_FORMATS: string[] = [
  'header',
  'bold', 'italic', 'underline', 'strike',
  'blockquote',
  'list',
  'indent',
  'image',
  'link'
];
const QUILL_TOOLBAR_CONFIG: QuillToolbarConfig = [
  [{header: [1, 2, 3, false]}],
  ['bold', 'italic', 'underline', 'strike'],
  ['blockquote'],
  [{list: 'ordered'}, {list: 'bullet'}],
  [{indent: '-1'}, {indent: '+1'}],          // outdent/indent
  ['clean'],                                 // remove formatting-button
  ['image']
];
export const QUILL_CONFIG: QuillConfig = {
  formats: QUILL_ALLOWED_FORMATS,
  modules: {toolbar: QUILL_TOOLBAR_CONFIG, magicUrl: true},
  placeholder: ''
};
