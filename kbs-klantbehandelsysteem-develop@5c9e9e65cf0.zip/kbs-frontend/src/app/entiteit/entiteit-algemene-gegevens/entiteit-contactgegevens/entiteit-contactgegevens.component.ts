import {Component, Input, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {Entiteit} from "../../shared/entiteit";
import {Contactgegevens, Person} from "./contact-gegevens";

@Component({
  selector: 'app-entiteit-contactgegevens',
  templateUrl: './entiteit-contactgegevens.component.html',
  styleUrls: ['./entiteit-contactgegevens.component.scss']
})
export class EntiteitContactgegevensComponent implements OnInit {

  @Input() entiteit$: Observable<Entiteit>;

  contactgegevens: Contactgegevens[]=[]

  constructor() {
  }

  ngOnInit(): void {
    this.fakeData();
  }

  //todo liz: use this fake data to test expansion
  fakeData() {
    const person1: Person = new Person(1, 'test1', '011111111', 'test1@changeme.com');
    const person2: Person = new Person(2, 'test2', '0222222', 'test2@changeme.com');
    const person3: Person = new Person(3, 'test3', '033333333', 'test3@changeme.com');
    this.contactgegevens.push(
      new Contactgegevens('Financieel directeur (CFO)', person1),
      new Contactgegevens('Bedrijfsspecialist', person2),
      new Contactgegevens('Middelspecialist VPB', person3));
  }

}
