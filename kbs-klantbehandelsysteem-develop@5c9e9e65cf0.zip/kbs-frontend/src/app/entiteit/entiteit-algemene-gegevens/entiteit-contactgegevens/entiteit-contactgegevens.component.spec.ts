import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitContactgegevensComponent } from './entiteit-contactgegevens.component';

describe('EntiteitContactgegevensComponent', () => {
  let component: EntiteitContactgegevensComponent;
  let fixture: ComponentFixture<EntiteitContactgegevensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitContactgegevensComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitContactgegevensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
