export class Contactgegevens {
  naam: string;
  person: Person

  constructor(naam: string, person: Person) {
    this.naam = naam;
    this.person = person;
  }
}

export class Person {
  id: number
  naam: string;
  telefoonnummer: string;
  emailAddress: string;

  constructor(id: number, naam: string, telefoonnummer: string, emailAddress: string) {
    this.id = id;
    this.naam = naam;
    this.telefoonnummer = telefoonnummer;
    this.emailAddress = emailAddress;
  }
}
