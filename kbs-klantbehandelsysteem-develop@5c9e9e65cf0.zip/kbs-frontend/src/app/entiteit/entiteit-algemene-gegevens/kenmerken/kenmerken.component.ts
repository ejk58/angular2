import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';
import {EMPTY, Observable} from 'rxjs';
import {Kenmerken} from '../../shared/kenmerken';
import {Entiteit} from '../../shared/entiteit';
import {EntiteitService} from '../../../services/entiteit.service';

@Component({
  selector: 'app-entiteit-kenmerken',
  templateUrl: './kenmerken.component.html',
  styleUrls: ['./kenmerken.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class KenmerkenComponent implements OnInit {

  @Input() entiteit$: Observable<Entiteit>;
  kenmerken$: Observable<Kenmerken>;

  constructor(private readonly entiteitService: EntiteitService) {
  }

  ngOnInit() {
    this.entiteitService.searchEntiteit.subscribe((id)=>{
      if (id > 0) {
        this.kenmerken$ = this.entiteitService.getAlgemeneGegevens_Kenmerken(id);
      } else {
        console.log('no search entity...');
        this.kenmerken$ = EMPTY;
      }
    });
  }
}
