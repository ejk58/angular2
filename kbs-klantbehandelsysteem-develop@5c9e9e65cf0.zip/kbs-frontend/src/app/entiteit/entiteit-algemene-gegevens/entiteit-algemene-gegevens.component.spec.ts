import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitAlgemeneGegevensComponent } from './entiteit-algemene-gegevens.component';

describe('EntiteitAlgemeneGegevensComponent', () => {
  let component: EntiteitAlgemeneGegevensComponent;
  let fixture: ComponentFixture<EntiteitAlgemeneGegevensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitAlgemeneGegevensComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitAlgemeneGegevensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
