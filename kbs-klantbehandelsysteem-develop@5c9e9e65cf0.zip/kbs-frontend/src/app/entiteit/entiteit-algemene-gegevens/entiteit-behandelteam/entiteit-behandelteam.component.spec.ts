import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitBehandelteamComponent } from './entiteit-behandelteam.component';

describe('EntiteitBehandelteamComponent', () => {
  let component: EntiteitBehandelteamComponent;
  let fixture: ComponentFixture<EntiteitBehandelteamComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitBehandelteamComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitBehandelteamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
