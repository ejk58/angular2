export interface BehandelTeam {
  naam: string;
  rolNaam: string;
  toelichting: string;
  userid: string;

}
