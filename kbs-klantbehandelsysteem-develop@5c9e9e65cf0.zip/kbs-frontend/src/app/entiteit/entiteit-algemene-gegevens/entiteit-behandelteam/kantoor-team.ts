export interface OrgKantoorTeam {
  subject: string;
  kantoorCode: number;
  team: string;

}
