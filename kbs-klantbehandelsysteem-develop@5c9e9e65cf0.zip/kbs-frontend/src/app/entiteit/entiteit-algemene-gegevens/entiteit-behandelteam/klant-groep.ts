export interface KlantGroep {
  klantcoordinator: string;
  klantgroepNaam: number;
  werkgroep: string;

}
