import {Component, Input, OnDestroy, OnInit, Renderer2} from '@angular/core';
import {Observable} from 'rxjs';
import {EntiteitService} from '../../../services/entiteit.service';
import {EntiteitKzbGegevens} from '../../shared/entiteit-kzb-gegevens';
import {BehandelTeam} from './behandel-team-gegevens';
import {KlantGroep} from './klant-groep';
import {OrgKantoorTeam} from './kantoor-team';

@Component({
  selector: 'app-entiteit-behandelteam',
  templateUrl: './entiteit-behandelteam.component.html',
  styleUrls: ['./entiteit-behandelteam.component.scss']
})
export class EntiteitBehandelteamComponent implements OnInit, OnDestroy {
  @Input() entiteitKzbGegevens$: Observable<EntiteitKzbGegevens>;
  kantoorTeam$: Observable<OrgKantoorTeam>
  klantGroep$: Observable<KlantGroep>
  behandelTeams: BehandelTeam[]
  wijzigBehandelteamUrl: string;
  entiteitNummer: number;

  //will be called later to remove the event listener in the OnDestroy cycle, which gets called when the component gets destroyed.
  private unlistener: () => void;

  constructor(private readonly entiteitService: EntiteitService,
              private renderer2: Renderer2) {
  }

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitNummer = nr;
      this.loadData();
    });
    this.entiteitService.getOrggevegensUrl().subscribe(url => {
      this.wijzigBehandelteamUrl = url.wijzigBehandelteamUrl;
    });

    this.unlistener = this.renderer2.listen("document", "visibilitychange", event => {
      const document = event.currentTarget
      if (!document.hidden) {
        this.loadData();
      }
    });
  }

  loadData() {
    this.kantoorTeam$ = this.entiteitService.getEntiteitOrgKantoorTeamGegevens(this.entiteitNummer);
    this.klantGroep$ = this.entiteitService.getOrgKlantGroepGegevens(this.entiteitNummer);
    this.entiteitService.getEntiteitBehandelTeamGegevens(this.entiteitNummer).subscribe(data => {
      this.behandelTeams = data
    });
  }

  // Properly removing an event listener that is added manually is crucial as it prevents memory leaks as well as performance drag on your application.
  ngOnDestroy() {
    this.unlistener();
  }

}
