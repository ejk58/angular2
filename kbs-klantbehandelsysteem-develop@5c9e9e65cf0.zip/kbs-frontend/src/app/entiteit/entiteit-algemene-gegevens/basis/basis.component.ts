import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {Entiteit} from '../../shared/entiteit';
import {EntiteitKzbGegevens} from "../../shared/entiteit-kzb-gegevens";

@Component({
  selector: 'app-entiteit-basis',
  templateUrl: './basis.component.html',
  styleUrls: ['./basis.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BasisComponent {

  @Input() entiteit$: Observable<Entiteit>;
  @Input() entiteitKzbGegevens$: Observable<EntiteitKzbGegevens>;

 }
