import {Component, Input, OnInit} from '@angular/core';
import {EMPTY, Observable} from 'rxjs';
import {Entiteit, SubEntiteit} from '../../shared/entiteit';
import {EntiteitService} from '../../../services/entiteit.service';

@Component({
  selector: 'app-entiteit-samenstelling',
  templateUrl: './samenstelling.component.html',
  styleUrls: ['./samenstelling.component.scss']
})
export class SamenstellingComponent implements OnInit {

  @Input() entiteit$: Observable<Entiteit>;
  samenstellingItems$: Observable<SubEntiteit[]>;

  constructor(private readonly entiteitService: EntiteitService) { }

  ngOnInit(): void {
    this.entiteitService.searchEntiteit.subscribe((id)=>{
      if (id > 0) {
        this.samenstellingItems$ = this.entiteitService.getAlgemeneGegevens_Samenstelling(id);
      } else {
        console.log('no search entity...');
        this.samenstellingItems$ = EMPTY;
      }
    });
  }

}
