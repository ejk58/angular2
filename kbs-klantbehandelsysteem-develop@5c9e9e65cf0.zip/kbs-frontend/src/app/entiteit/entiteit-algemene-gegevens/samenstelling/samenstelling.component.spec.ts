import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SamenstellingComponent } from './samenstelling.component';

describe('EntiteitSamenstellingComponent', () => {
  let component: SamenstellingComponent;
  let fixture: ComponentFixture<SamenstellingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SamenstellingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SamenstellingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
