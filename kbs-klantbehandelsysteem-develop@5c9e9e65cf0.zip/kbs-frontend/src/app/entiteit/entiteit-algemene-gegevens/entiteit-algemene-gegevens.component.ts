import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {Entiteit} from '../shared/entiteit';
import {EntiteitService} from "../../services/entiteit.service";
import {EntiteitKzbGegevens} from "../shared/entiteit-kzb-gegevens";

@Component({
  selector: 'app-entiteit-algemene-gegevens',
  templateUrl: './entiteit-algemene-gegevens.component.html',
  styleUrls: ['./entiteit-algemene-gegevens.component.scss']
})
export class EntiteitAlgemeneGegevensComponent implements OnInit {

  entiteit$: Observable<Entiteit>;
  entiteitKzbGegevens$: Observable<EntiteitKzbGegevens>;

  constructor(private readonly entiteitService: EntiteitService) {
  }

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteit$ = this.entiteitService.getEntiteit(nr);
      this.entiteitKzbGegevens$ = this.entiteitService.getEntiteitOrgMissingGegevens(nr);
    });
  }

}
