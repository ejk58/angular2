import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitLogboekComponent } from './entiteit-logboek.component';

describe('EntiteitLogboekComponent', () => {
  let component: EntiteitLogboekComponent;
  let fixture: ComponentFixture<EntiteitLogboekComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitLogboekComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitLogboekComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
