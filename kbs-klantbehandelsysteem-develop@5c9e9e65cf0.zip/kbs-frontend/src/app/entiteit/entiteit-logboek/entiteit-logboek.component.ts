import { Component, OnInit } from '@angular/core';
import {Observable} from "rxjs";
import {Entiteit} from "../shared/entiteit";
import {EntiteitService} from "../../services/entiteit.service";

@Component({
  selector: 'app-entiteit-logboek',
  templateUrl: './entiteit-logboek.component.html',
  styleUrls: ['./entiteit-logboek.component.scss']
})
export class EntiteitLogboekComponent implements OnInit {
  entiteit$: Observable<Entiteit>;

  constructor(private readonly entiteitService: EntiteitService) {
  }

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteit$ = this.entiteitService.getEntiteit(nr);
    });
  }
}
