import {Component, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {Entiteit} from "../shared/entiteit";
import {EntiteitService} from "../../services/entiteit.service";

@Component({
  selector: 'app-entiteit-klantdocumenten',
  templateUrl: './entiteit-klantdocumenten.component.html',
  styleUrls: ['./entiteit-klantdocumenten.component.scss']
})
export class EntiteitKlantdocumentenComponent implements OnInit {

  entiteit$: Observable<Entiteit>;

  constructor(private readonly entiteitService: EntiteitService) {
  }

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteit$ = this.entiteitService.getEntiteit(nr);
    });
  }
}
