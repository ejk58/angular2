import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitKlantdocumentenComponent } from './entiteit-klantdocumenten.component';

describe('EntiteitKlantdocumentenComponent', () => {
  let component: EntiteitKlantdocumentenComponent;
  let fixture: ComponentFixture<EntiteitKlantdocumentenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitKlantdocumentenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitKlantdocumentenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
