import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitStrategieComponent } from './entiteit-strategie.component';

describe('EntiteitStrategieComponent', () => {
  let component: EntiteitStrategieComponent;
  let fixture: ComponentFixture<EntiteitStrategieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitStrategieComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitStrategieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
