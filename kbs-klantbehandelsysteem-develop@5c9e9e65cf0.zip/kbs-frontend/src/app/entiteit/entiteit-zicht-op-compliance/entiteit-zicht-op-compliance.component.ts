import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entiteit-zicht-op-compliance',
  templateUrl: './entiteit-zicht-op-compliance.component.html',
  styleUrls: ['./entiteit-zicht-op-compliance.component.scss']
})
export class EntiteitZichtOpComplianceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
