import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitZichtOpComplianceComponent } from './entiteit-zicht-op-compliance.component';

describe('EntiteitZichtOpComplianceComponent', () => {
  let component: EntiteitZichtOpComplianceComponent;
  let fixture: ComponentFixture<EntiteitZichtOpComplianceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitZichtOpComplianceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitZichtOpComplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
