export interface Entiteit {
  nummer: string;
  naam: string;
  klantpakket: string;
  adres: string;
  brancheCode: number;
  brancheNaam: string;
  bestuurlijkVerband: string;
  kantoorCode: number;
  kantoorNaam: string;
  teamCode: string;
  teamNaam: string;
  klantCoordinator: string;
  klantGroep: string;
}
export interface SubEntiteit {
  nummer: string;
  subject: string;
  type: string;
}
