//This should be used for the json of the urls(those not intended for rest calls) saved in application.propertied file.
export interface OrgUrls {
wijzigBehandelteamUrl: string;

}
