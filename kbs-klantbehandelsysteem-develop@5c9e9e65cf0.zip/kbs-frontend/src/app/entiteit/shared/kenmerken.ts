export interface Kenmerken {
  aandachtsCategorie: string;
  vipIndicatie: string;
  zwaarteCategorie: string;
  goCategorie: string;
  convenantDeelname: string;
  wolbSom: number;
}
