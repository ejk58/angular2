export interface Opdracht {
  naam: string;
  aantal: number;
}
