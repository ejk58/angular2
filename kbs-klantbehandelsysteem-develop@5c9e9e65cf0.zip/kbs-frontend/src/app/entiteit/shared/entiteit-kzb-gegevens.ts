//This should be used to map all Kzb Gegevens which are missing in the org service.
export interface EntiteitKzbGegevens {
  kantoornaam: string;
  teamnaam: number;
  branchecode: number;
  branchenaam: string;

}
