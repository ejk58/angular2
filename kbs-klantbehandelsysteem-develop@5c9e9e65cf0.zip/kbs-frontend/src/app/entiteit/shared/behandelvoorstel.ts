export interface Behandelvoorstel {
  middel:string;
  heffing: string;
  bezwaar: string;
  beroep: string;
  controle: string;
  vooroverleg: string;
  invordering: string;
  overig: string;
  totalen: string;
}
