import {MiddelKenmerk} from "../../interfaces/MiddelKenmerk";
import {MiddelRisico} from "../../interfaces/MiddelRisico";

export class KenmerkRisicosKoppeling {
  compositeId: [number, number];
  middelKenmerk: MiddelKenmerk;
  middelRisico: MiddelRisico;
}


/*
[
{"compositeId":{"middelKenmerkId":17,"middelRisicoId":16},
  "middelKenmerk":{"id":17,"middelId":12,"kenmerk":"Het concern houdt vennootschappen in laagbelaste jurisdicties","parentId":9},
  "middelRisico":{"id":16,"middelId":12,"risico":"ART. 08b t/m 8c Verrekenprijzen","parentId":null}},
{"compositeId":{"middelKenmerkId":30,"middelRisicoId":16},
  "middelKenmerk":{"id":30,"middelId":12,"kenmerk":"Er zijn transacties met een gelieerde buitenlandse ondernemingen","parentId":29},
  "middelRisico":{"id":16,"middelId":12,"risico":"ART. 08b t/m 8c Verrekenprijzen","parentId":null}},
{"compositeId":{"middelKenmerkId":31,"middelRisicoId":16},
  "middelKenmerk":{"id":31,"middelId":12,"kenmerk":"Er zijn transacties met gelieerde binnenlandse ondernemingen met een fiscaal belang","parentId":29},
  "middelRisico":{"id":16,"middelId":12,"risico":"ART. 08b t/m 8c Verrekenprijzen","parentId":null}},
{"compositeId":{"middelKenmerkId":32,"middelRisicoId":16},
  "middelKenmerk":{"id":32,"middelId":12,"kenmerk":"De in de entiteit opgenomen vennootschappen hebben een entrepreneursfunctie","parentId":29},
  "middelRisico":{"id":16,"middelId":12,"risico":"ART. 08b t/m 8c Verrekenprijzen","parentId":null}},
{"compositeId":{"middelKenmerkId":33,"middelRisicoId":16},
  "middelKenmerk":{"id":33,"middelId":12,"kenmerk":"De activiteiten van de in de entiteit opgenomen vennootschappen hebben nagenoeg geheel (> 90%) een routinematig karakter","parentId":29},
  "middelRisico":{"id":16,"middelId":12,"risico":"ART. 08b t/m 8c Verrekenprijzen","parentId":null}},
{"compositeId":{"middelKenmerkId":35,"middelRisicoId":16},
  "middelKenmerk":{"id":35,"middelId":12,"kenmerk":"Door het behandelteam is (minder dan 3 jaar geleden) een risicoanalyse uitgevoerd gericht op transfer pricing ","parentId":34},
  "middelRisico":{"id":16,"middelId":12,"risico":"ART. 08b t/m 8c Verrekenprijzen","parentId":null}},
{"compositeId":{"middelKenmerkId":36,"middelRisicoId":16},
  "middelKenmerk":{"id":36,"middelId":12,"kenmerk":"De bevindingen uit de risicoanalyse zijn gedeeld met een lid van de CGVP","parentId":35},
  "middelRisico":{"id":16,"middelId":12,"risico":"ART. 08b t/m 8c Verrekenprijzen","parentId":null}},
{"compositeId":{"middelKenmerkId":37,"middelRisicoId":16},
  "middelKenmerk":{"id":37,"middelId":12,"kenmerk":"Er zijn verrekenprijsrisico's in behandeling, of het voornemen bestaat om deze het komend jaar in behandeling te nemen","parentId":34},
  "middelRisico":{"id":16,"middelId":12,"risico":"ART. 08b t/m 8c Verrekenprijzen","parentId":null}}
]*/
