import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {HelptextService} from "../../../services/helptext.service";
import {FiscaliteitService} from "../../../services/fiscaliteit.service";
import {EntiteitService} from "../../../services/entiteit.service";
import {ZooEntiteitMiddel} from "../../../interfaces/ZooEntiteitMiddel";
import {MiddelRisico} from "../../../interfaces/MiddelRisico";
import {HelptextIds} from "../../../shared/helptext-ids";
import {forkJoin, Observable, of} from "rxjs";
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {EntiteitMiddelRisico} from "./EntiteitMiddelRisico";
import {EntiteitKenmerk} from "../../../interfaces/EntiteitKenmerk";
import {defaultIfEmpty, map} from "rxjs/operators";
import {MiddelKenmerk} from "../../../interfaces/MiddelKenmerk";
import {ConfirmationService, MenuItem} from "primeng/api";
import {EntiteitMiddelKenmerk} from "../middelspecifieke-kenmerken/EntiteitMiddelKenmerk";


@Component({
  selector: 'app-middelspecifieke-riscos',
  templateUrl: './middelspecifieke-riscos.component.html',
  styleUrls: ['./middelspecifieke-riscos.component.scss']
})
export class MiddelspecifiekeRiscosComponent implements OnInit, OnChanges {
  keyRiskMapping: {label : string, value : number} [];
  asEntiteitMiddelRisico = (entiteitMiddelRisico: EntiteitMiddelRisico) => entiteitMiddelRisico;

  @Input() selectedMiddel: ZooEntiteitMiddel;

  entiteitNummer: number;
  title: string;
  titleTooltip$: Observable<Helptext>;
  toelichtingRisicosTitle: string = "Toelichting risico's"
  helptextIds = HelptextIds;

  middelRisicos: MiddelRisico[] = [];
  risicoStatussen: EntiteitKenmerk[];
  //gekoppeld aan kenmerken
  entiteitMiddelKenmerkIdToMiddelKenmerkKenmerk: Map<number, MiddelKenmerk>; //get from backend
  gekoppeldeKenmerken: MiddelKenmerk[] = [];
  gekoppeldeKenmerkenEditable: MiddelKenmerk[] = [];

  selectedMiddelKenmerkForKenmerk: MiddelKenmerk;

  //dropdowns selection
  selectedHoofdRisico: MiddelRisico | null = null;
  selectedSubRisico: MiddelRisico | null = null;
  isKeyRisk: {label : string, value : number};
  selectedRisicoStatus: EntiteitKenmerk | null = null;
  selectedHoofdRisicoEditable: MiddelRisico | number | null = null;
  selectedSubRisicoEditable: MiddelRisico | number | null = null;
  selectedMiddelKenmerkEditable: MiddelKenmerk | null = null;
  selectedKeyRiskEditable: {label : string, value : number};
  selectedRisicoStatusEditable: EntiteitKenmerk | number | null = null;

  currentRowIndex: number | null = null;
  editing = false;
  backupEntiteitMiddelRisico: EntiteitMiddelRisico;

  //for table
  selectedEntiteitMiddelRisicos: EntiteitMiddelRisico[];

  kenmerkNames: string[];
  middelKenmerken: MiddelKenmerk[] = [];

  constructor(private readonly helptextService: HelptextService,
              private readonly fiscaliteitService: FiscaliteitService,
              private readonly entiteitService: EntiteitService,
              private readonly confirmationService: ConfirmationService) {

    this.fiscaliteitService.getRisicoStatussen().subscribe(risicoStatussen =>
      this.risicoStatussen = risicoStatussen
    );
    this.keyRiskMapping = [
      {label: "Key risk", value : 1},
      {label: "Non key risk", value : 0}
    ];
  }

  ngOnInit() {
    this.titleTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.FISCALITEIT_MIDDELSPECIFIEKE_RISICOS_TITLE_TOOLTIP);
  }

  ngOnChanges(changes: SimpleChanges): void {
    const selectedMiddelFromParent = changes?.selectedMiddel?.currentValue as ZooEntiteitMiddel;
    if (selectedMiddelFromParent) {
      this.selectedMiddel = selectedMiddelFromParent;
      this.title = this.selectedMiddel ? 'Middelspecifieke risico\'s ' + this.selectedMiddel.kenmerk : 'Middelspecifieke risico\' onbekend';
      this.fiscaliteitService.getRisiscosByMiddelId(this.selectedMiddel?.id).subscribe(middelRisicos => {
        this.middelRisicos = middelRisicos;
        this.entiteitService.getSearchEntiteitNummer((nr) => {
          this.entiteitNummer = nr;
          this.loadSelectedEntiteitMiddelRisicos();
        });
      });
      this.fiscaliteitService.getKenmerkenByMiddelId(this.selectedMiddel?.id).subscribe( data => {
        this.middelKenmerken = data;
      });
    }
  }

  filterRisicosBasedOnParentId(parentId: number) : MiddelRisico[]{
    return this.middelRisicos.filter(r => r.parentId === parentId);
  }

  getKenmerkenForRisico(middelRisicoId: number){
    this.fetchKenmerkenForRisico(middelRisicoId).subscribe((gekoppeldeKenmerken) => {
      if (gekoppeldeKenmerken !== null) {
        this.gekoppeldeKenmerken = gekoppeldeKenmerken;
      }
    });
  }

  getKenmerkenForRisicoEditable(middelRisicoId: MiddelRisico | number){
    if (middelRisicoId instanceof MiddelRisico) {
      middelRisicoId = middelRisicoId.id;
    }
    this.fetchKenmerkenForRisico(middelRisicoId).subscribe((gekoppeldeKenmerken) => {
      if (gekoppeldeKenmerken !== null) {
        this.gekoppeldeKenmerkenEditable = gekoppeldeKenmerken;
      }
    });
  }

  fetchKenmerkenForRisico(middelRisicoId: number){
    if(middelRisicoId == null) return of(null);
    return this.fiscaliteitService.getEntiteitMiddelKenmerkenForRisico(this.entiteitNummer, middelRisicoId)
      .pipe(map((data) => {
        this.entiteitMiddelKenmerkIdToMiddelKenmerkKenmerk = data;
        return Object.values(this.entiteitMiddelKenmerkIdToMiddelKenmerkKenmerk);
      }));
  }

  saveEntiteitMiddelRisico(){
    this.fiscaliteitService.addEntiteitMiddelRisico(this.makeEntiteitMiddelRisico()).subscribe(() =>
      this.loadSelectedEntiteitMiddelRisicos()
    );
  }

  disableSaveButton() {
    const toSave = this.makeEntiteitMiddelRisico();
    const selectedCombinationExists = this.selectedCombinationExists(toSave.hoofdRisicoId, toSave.subRisicoId, toSave.entiteitMiddelKenmerkId)
    const selectedHoofdRisicoIdIsNullish = this.selectedHoofdRisico?.id == null;
    const selectedRiskeyIsNullish = this.isKeyRisk?.value == null;
    const selectedRisicoStatusIsNullish = this.selectedRisicoStatus?.id == null;
    return selectedCombinationExists || selectedHoofdRisicoIdIsNullish || selectedRiskeyIsNullish || selectedRisicoStatusIsNullish;
  }

  selectedCombinationExists(hoofdRisicoId: number, subRisicoId: number, entiteitMiddelKenmerkId: number) {
    const exist: EntiteitMiddelRisico[] = this.selectedEntiteitMiddelRisicos.filter(selected => {
      return selected.hoofdRisicoId == hoofdRisicoId &&
        selected.subRisicoId == subRisicoId &&
        selected.entiteitMiddelKenmerkId == entiteitMiddelKenmerkId
    });
    return exist.length > 0;
  }

  loadSelectedEntiteitMiddelRisicos() {
    this.fiscaliteitService.getSelectedMiddelRisicosByEntiteitNummerAndMiddelId(this.entiteitNummer, this.selectedMiddel.id)
      .subscribe(data => {
        return forkJoin(data.map(risico => {
          if (risico.entiteitMiddelKenmerkId) {
            return this.fiscaliteitService.getEntiteitMiddelKenmerkById(risico.entiteitMiddelKenmerkId);
          } else {
            return of(null);
          }
        })).pipe(defaultIfEmpty(null))
          .subscribe(entiteitMiddelKenmerken => {
            this.kenmerkNames = entiteitMiddelKenmerken
                ?.map(entiteitMiddelKenmerk => entiteitMiddelKenmerk ? this.getLowestLevelKenmerkId(entiteitMiddelKenmerk) : null)
              .map(id => {
                return id ? this.getMiddelKenmerkNameById(id) : '';
              });
            this.selectedEntiteitMiddelRisicos = data;
          });
      });
  }

  getMiddelKenmerkNameById(id: number) {
    return  this.middelKenmerken.find(k => k.id === id)?.kenmerk;
  }

  getLowestLevelKenmerkId(entiteitMiddelKenmerk: EntiteitMiddelKenmerk) {
    if(entiteitMiddelKenmerk.subKenmerk3Id) {
      return entiteitMiddelKenmerk.subKenmerk3Id;
    }else if (entiteitMiddelKenmerk.subKenmerk2Id){
      return entiteitMiddelKenmerk.subKenmerk2Id;
    }else if (entiteitMiddelKenmerk.subKenmerk1Id){
      return entiteitMiddelKenmerk.subKenmerk1Id;
    } else return entiteitMiddelKenmerk.hoofdKenmerkId;
  }

  makeEntiteitMiddelRisico() {
    const entiteitMiddelKenmerkId = this.getKeyFromValue(this.selectedMiddelKenmerkForKenmerk);
    return new EntiteitMiddelRisico(
      null,
      this.selectedHoofdRisico ? this.selectedHoofdRisico.id : null,
      this.selectedSubRisico ? this.selectedSubRisico.id : null,
      entiteitMiddelKenmerkId,
      this.isKeyRisk?.value,
      this.selectedRisicoStatus?.id ? this.selectedRisicoStatus.id : null,
      null,
      this.entiteitNummer
    );
  }

  //find key (entiteitMiddelKenmerkId) for the matching value (MiddelKenmerk)
  getKeyFromValue(middelKenmerk: MiddelKenmerk): number {
    if(!this.entiteitMiddelKenmerkIdToMiddelKenmerkKenmerk) {
      return null;
    } else {
      for(const [key, value] of Object.entries(this.entiteitMiddelKenmerkIdToMiddelKenmerkKenmerk)){
        if(value === middelKenmerk) {
          return Number(key);
        }
    }
    }
    return null;
  }

  getMiddelRisicoById(id: number) {
    return this.middelRisicos.find(k => k.id === id);
  }

  getStatusById(id: number){
    return this.risicoStatussen.find(k => k.id === id);
  }

  getKeyRisk(keyRisk: number){
    return this.keyRiskMapping.find(k => k.value === keyRisk)?.label;
  }

  riscosByParent(middelRisicos: MiddelRisico[], parent: MiddelRisico | number) {
    let id = parent;
    if ((<MiddelRisico>parent)?.id) {
      id = (<MiddelRisico>parent).id;
    }
    return this.subRiscosByParentId(middelRisicos, <number>id);
  }

  subRiscosByParentId(middelRisicos: MiddelRisico[], parentId: number) {
    const result: MiddelRisico[] = [];
    for (let entry of middelRisicos) {
      if (entry.parentId === parentId) {
        result.push(entry);
      }
    }
    return result;
  }

  onRowEditCancel() {
    this.currentRowIndex = null;
    const index = this.findIndexOfBackupEntiteitMiddelRisco();
    this.selectedEntiteitMiddelRisicos[index].hoofdRisicoId = this.backupEntiteitMiddelRisico.hoofdRisicoId;
    this.selectedEntiteitMiddelRisicos[index].subRisicoId = this.backupEntiteitMiddelRisico.subRisicoId;
    this.selectedEntiteitMiddelRisicos[index].entiteitMiddelKenmerkId = this.backupEntiteitMiddelRisico.entiteitMiddelKenmerkId;
    this.selectedEntiteitMiddelRisicos[index].statusId = this.backupEntiteitMiddelRisico.statusId;
    this.selectedEntiteitMiddelRisicos[index].keyRisk = this.backupEntiteitMiddelRisico.keyRisk;
    this.backupEntiteitMiddelRisico = null;
    this.editing = false;
  }

  private findIndexOfBackupEntiteitMiddelRisco(): number {
    let index = 0;
    for(let x = 0; x < this.selectedEntiteitMiddelRisicos.length; x++) {
      if ( this.selectedEntiteitMiddelRisicos[x].id === this.backupEntiteitMiddelRisico.id) {
        index = x;
        break;
      }
    }
    return index;
  }

  onRowEditInit($event, item: EntiteitMiddelRisico, editButton: HTMLButtonElement, editing: boolean) {
    this.backupEntiteitMiddelRisico = JSON.parse(JSON.stringify(item));
    this.selectedHoofdRisicoEditable = this.getMiddelRisicoById(item.hoofdRisicoId)?.id;
    this.selectedSubRisicoEditable = this.getMiddelRisicoById(item.subRisicoId)?.id;
    const middelRisicoId = this.selectedSubRisicoEditable ? this.selectedSubRisicoEditable :  this.selectedHoofdRisicoEditable;
    this.getKenmerkenForRisicoEditable(middelRisicoId);
    this.fiscaliteitService.getEntiteitMiddelKenmerkenForRisico(this.entiteitNummer, middelRisicoId)
      .subscribe((data) => {
        this.selectedMiddelKenmerkEditable = data[item.entiteitMiddelKenmerkId];
      });
    this.selectedKeyRiskEditable = item.keyRisk === 1 ? {label: "Key risk", value: 1} : {
      label: "Non key risk",
      value: 0
    };
    this.selectedRisicoStatusEditable = this.getStatusById(item.statusId)?.id;
    editButton.click();
    this.editing = editing;
  }

  onRowEditSave() {
    this.currentRowIndex = null;
    const toSave = this.makeEditedEntiteitMiddelRisico();
    this.fiscaliteitService.addEntiteitMiddelRisico(toSave).subscribe(e => {
      this.loadSelectedEntiteitMiddelRisicos();
      this.backupEntiteitMiddelRisico = null;
      this.editing = false;
    });
  }

  makeEditedEntiteitMiddelRisico() {
    const index = this.findIndexOfBackupEntiteitMiddelRisco();
    this.selectedEntiteitMiddelRisicos[index].hoofdRisicoId = <number>this.selectedHoofdRisicoEditable;
    this.selectedEntiteitMiddelRisicos[index].subRisicoId = <number>this.selectedSubRisicoEditable;
    this.selectedEntiteitMiddelRisicos[index].entiteitMiddelKenmerkId = this.selectedMiddelKenmerkEditable ? this.getKeyFromValue(this.selectedMiddelKenmerkEditable) : null;
    this.selectedEntiteitMiddelRisicos[index].keyRisk = this.selectedKeyRiskEditable?.value;
    this.selectedEntiteitMiddelRisicos[index].statusId = <number>this.selectedRisicoStatusEditable;
    return this.selectedEntiteitMiddelRisicos[index]
  }

  disableWijzgenButton() {
    const selectedKeyRiskEditableIsNullish = this.selectedKeyRiskEditable?.value == null;
    const selectedRisicoStatusEditableIsNullish = <number>this.selectedRisicoStatusEditable == null;
    return this.selectedCombinationExists(
      <number>this.selectedHoofdRisicoEditable,
      <number>this.selectedSubRisicoEditable,
      this.selectedMiddelKenmerkEditable ? this.getKeyFromValue(this.selectedMiddelKenmerkEditable) : null)
      || !this.selectedHoofdRisicoEditable ||selectedKeyRiskEditableIsNullish || selectedRisicoStatusEditableIsNullish;
  }

  getMenuItemsForItem(item: EntiteitMiddelRisico, editButton: HTMLButtonElement, editing: boolean, rowIndex: number): MenuItem[] {
    const context = item;
    return [
      {
        label: 'Wijzigen',
        command: e => {
          this.currentRowIndex = rowIndex;
          this.onRowEditInit(e, context, editButton, editing)
        }
      },
      {
        label: 'Verwijderen',
        command: e => {
          this.deleteEntiteitMiddelRisico(e, context, editing, rowIndex)
        }
      }
    ]
  }

  deleteEntiteitMiddelRisico($event, item: EntiteitMiddelRisico, editing: boolean, rowIndex: number) {
    this.editing = editing;
    this.confirm($event, item, rowIndex)
  }

  confirm(event: any, item: EntiteitMiddelRisico, rowIndex: number) {
    this.confirmationService.confirm({
      //The event.originalEvent.target is needed to determine the relative position of the popup.
      target: event?.originalEvent?.target,
      key: 'delete-selected-row-' + rowIndex,
      message: "Weet u zeker dat u deze item wilt verwijderen?",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Ja",
      rejectLabel: "Nee",
      accept: () => {
        this.fiscaliteitService.deleteEntiteitMiddelRisico(item).subscribe(() => {
          this.loadSelectedEntiteitMiddelRisicos();
        });
      },
    });
  }

  volgordeAanpassen() {
    //Todo:  de gewenste volgorde slepen jira issue IVAKBS-226
  }
}


