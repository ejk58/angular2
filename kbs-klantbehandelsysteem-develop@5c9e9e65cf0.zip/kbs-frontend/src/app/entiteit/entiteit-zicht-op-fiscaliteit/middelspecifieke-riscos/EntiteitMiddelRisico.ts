export class EntiteitMiddelRisico {
  id: number | null;
  hoofdRisicoId: number;
  subRisicoId: number | null;
  entiteitMiddelKenmerkId: number | null;
  keyRisk: number;
  statusId: number;
  rank: number | null;
  entiteitNummer: number;


  constructor(id: number, hoofdRisicoId: number, subRisicoId: number, entiteitMiddelKenmerkId: number, keyRisk: number, statusId: number,
              rank: number, entiteitNummer: number) {
    this.id = id;
    this.hoofdRisicoId = hoofdRisicoId;
    this.subRisicoId = subRisicoId;
    this.entiteitMiddelKenmerkId = entiteitMiddelKenmerkId;
    this.keyRisk = keyRisk;
    this.statusId = statusId;
    this.rank = rank;
    this.entiteitNummer = entiteitNummer;
  }
}
