import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiddelspecifiekeRiscosComponent } from './middelspecifieke-riscos.component';

describe('MiddelspecifiekeRiscosComponent', () => {
  let component: MiddelspecifiekeRiscosComponent;
  let fixture: ComponentFixture<MiddelspecifiekeRiscosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiddelspecifiekeRiscosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiddelspecifiekeRiscosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
