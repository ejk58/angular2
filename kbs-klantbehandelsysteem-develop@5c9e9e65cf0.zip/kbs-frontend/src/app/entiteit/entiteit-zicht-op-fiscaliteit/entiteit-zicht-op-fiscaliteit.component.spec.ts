import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitZichtOpFiscaliteitComponent } from './entiteit-zicht-op-fiscaliteit.component';

describe('EntiteitZichtOpFiscaliteitComponent', () => {
  let component: EntiteitZichtOpFiscaliteitComponent;
  let fixture: ComponentFixture<EntiteitZichtOpFiscaliteitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitZichtOpFiscaliteitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitZichtOpFiscaliteitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
