import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';
import {Observable} from "rxjs";
import {Entiteit} from "../../shared/entiteit";
import {EntiteitService} from "../../../services/entiteit.service";
import {ZooEntiteitMiddel} from "../../../interfaces/ZooEntiteitMiddel";
import {KenmerkenService} from "../../../services/kenmerken.service";

@Component({
  selector: 'app-middelspecifiek-tabs',
  templateUrl: './middelspecifiek-tabs.component.html',
  styleUrls: ['./middelspecifiek-tabs.component.scss']
})
export class MiddelspecifiekTabsComponent implements OnChanges {

  selectedTabNumber = 0;
  entiteit$: Observable<Entiteit>;

  @Input() middelSubMenu: string;

  selectedMiddel: ZooEntiteitMiddel

  constructor(private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService) {
  }

  ngOnChanges(changes: SimpleChanges): void {
    const selectedMiddelSubMenu = changes?.middelSubMenu?.currentValue as string;
    if (selectedMiddelSubMenu) {
      this.middelSubMenu = selectedMiddelSubMenu;
      this.entiteitService.getSearchEntiteitNummer((nr) => {
        this.entiteit$ = this.entiteitService.getEntiteit(nr);
        this.kenmerkenService.getSelectedMiddelByNameAndGroup(nr, this.middelSubMenu, 'MID').subscribe(data => {
          this.selectedMiddel = data;
        });
      });
    }
  }

  isTabSelected(tabNumber: number) {
    return tabNumber === this.selectedTabNumber;
  }

  selectTab(e: any) {
    this.selectedTabNumber = e.index
  }
}
