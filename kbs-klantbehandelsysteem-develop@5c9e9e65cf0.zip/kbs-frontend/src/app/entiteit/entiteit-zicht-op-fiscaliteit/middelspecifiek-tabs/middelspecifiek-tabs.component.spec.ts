import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiddelspecifiekTabsComponent } from './middelspecifiek-tabs.component';

describe('MiddelspecifiekTabsComponent', () => {
  let component: MiddelspecifiekTabsComponent;
  let fixture: ComponentFixture<MiddelspecifiekTabsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiddelspecifiekTabsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiddelspecifiekTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
