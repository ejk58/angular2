import {Component, OnChanges, SimpleChanges} from '@angular/core';
import {EntiteitService} from "../../services/entiteit.service";
import {Router} from "@angular/router";
import {urlZichtOpFiscaliteit} from "../../app.component";

@Component({
  selector: 'app-entiteit-zicht-op-fiscaliteit',
  templateUrl: './entiteit-zicht-op-fiscaliteit.component.html',
  styleUrls: ['./entiteit-zicht-op-fiscaliteit.component.scss']
})
export class EntiteitZichtOpFiscaliteitComponent implements OnChanges {
  href: string = "";

  constructor(private readonly entiteitService: EntiteitService,
              private router: Router) {
  }


  ngOnChanges(changes: SimpleChanges): void {
    this.getUrl();
  }

  getUrl() {
    let url: string = this.router.url;
    if (url.substring(1) === urlZichtOpFiscaliteit)
      return urlZichtOpFiscaliteit;

    var re = new RegExp("%20", 'g');
    return url.substring(urlZichtOpFiscaliteit.length + 2).replace(re, " ");
  }

}
