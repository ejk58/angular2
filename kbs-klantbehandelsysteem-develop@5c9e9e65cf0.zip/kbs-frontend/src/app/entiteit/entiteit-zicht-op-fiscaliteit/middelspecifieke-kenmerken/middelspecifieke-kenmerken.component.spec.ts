import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiddelspecifiekeKenmerkenComponent } from './middelspecifieke-kenmerken.component';

describe('MiddelspecifiekeKenmerkenComponent', () => {
  let component: MiddelspecifiekeKenmerkenComponent;
  let fixture: ComponentFixture<MiddelspecifiekeKenmerkenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiddelspecifiekeKenmerkenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiddelspecifiekeKenmerkenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
