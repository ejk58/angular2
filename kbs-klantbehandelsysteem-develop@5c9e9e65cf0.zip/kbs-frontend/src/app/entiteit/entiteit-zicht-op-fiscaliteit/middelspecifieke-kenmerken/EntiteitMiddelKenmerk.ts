export class EntiteitMiddelKenmerk {
  id: number | null;
  hoofdKenmerkId: number | null;
  subKenmerk1Id: number | null;
  subKenmerk2Id: number | null;
  subKenmerk3Id: number | null;
  rank: number | null;
  entiteitNummer: number;


  constructor(id: number | null, hoodfKenmerkId: number, subKenmerk1Id: number, subKenmerk2Id: number, subKenmerk3Id: number,
              rank: number, entiteitNummer: number) {
    this.id = id;
    this.hoofdKenmerkId = hoodfKenmerkId;
    this.subKenmerk1Id = subKenmerk1Id;
    this.subKenmerk2Id = subKenmerk2Id;
    this.subKenmerk3Id = subKenmerk3Id;
    this.rank = rank;
    this.entiteitNummer = entiteitNummer;
  }
}
