import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {Observable} from "rxjs";
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {HelptextIds} from "../../../shared/helptext-ids";
import {HelptextService} from "../../../services/helptext.service";
import {FiscaliteitService} from "../../../services/fiscaliteit.service";
import {MiddelKenmerk} from "../../../interfaces/MiddelKenmerk";
import {EntiteitService} from "../../../services/entiteit.service";
import {EntiteitMiddelKenmerk} from "./EntiteitMiddelKenmerk";
import {ConfirmationService, MenuItem} from "primeng/api";
import {ZooEntiteitMiddel} from "../../../interfaces/ZooEntiteitMiddel";
import {EntiteitMiddelRisico} from "../middelspecifieke-riscos/EntiteitMiddelRisico";
import {MiddelRisico} from "../../../interfaces/MiddelRisico";

@Component({
  selector: 'app-middelspecifieke-kenmerken',
  templateUrl: './middelspecifieke-kenmerken.component.html',
  styleUrls: ['./middelspecifieke-kenmerken.component.scss']
})
export class MiddelspecifiekeKenmerkenComponent implements OnInit, OnChanges {

  currentRowIndex: number | null = null;
  title: string;
  titleTooltip$: Observable<Helptext>;
  helptextIds = HelptextIds;
  toelichtingKenmerkenTitle: string = "Toelichting kenmerken"

  @Input() selectedMiddel: ZooEntiteitMiddel
  entiteitNummer: number;

  selectedMiddelKenmerken: EntiteitMiddelKenmerk[];
  displayedMiddelKenmerken: EntiteitMiddelKenmerk[];

  middelKenmerken: MiddelKenmerk[] = [];
  showPaginator = true;
  numberOfRowsToDisplayPerPage: number = 10;

  editing = false;

  asEntiteitMiddelKenmerk = (middelKenmerk: EntiteitMiddelKenmerk) => middelKenmerk;
  backupEntiteitMiddelKenmerk: EntiteitMiddelKenmerk;

  selectedHoofdkenmerk: MiddelKenmerk | null = null;
  selectedSubkenmerk1: MiddelKenmerk | null = null;
  selectedSubkenmerk2: MiddelKenmerk | null = null;
  selectedSubkenmerk3: MiddelKenmerk | null = null;

  selectedHoofdkenmerkEditable: MiddelKenmerk | number | null = null;
  selectedSubkenmerk1Editable: MiddelKenmerk | number | null = null;
  selectedSubkenmerk2Editable: MiddelKenmerk | number | null = null;
  selectedSubkenmerk3Editable: MiddelKenmerk | number | null = null;

  selectedEntiteitMiddelRisicos: EntiteitMiddelRisico[];
  middelRisicos: MiddelRisico[];

  constructor(private readonly helptextService: HelptextService,
              private readonly fiscaliteitService: FiscaliteitService,
              private readonly entiteitService: EntiteitService,
              private readonly confirmationService: ConfirmationService) {
  }

  ngOnChanges(changes: SimpleChanges): void {
    const selectedMiddelFromParent = changes?.selectedMiddel?.currentValue as ZooEntiteitMiddel;
    if (selectedMiddelFromParent) {
      this.selectedMiddel = selectedMiddelFromParent;
      this.title = this.selectedMiddel ? 'Middelspecifieke kenmerken ' + this.selectedMiddel.kenmerk : 'Middelspecifieke kenmerken onbekend';
      this.fiscaliteitService.getKenmerkenByMiddelId(this.selectedMiddel?.id).subscribe(middelKenmerken => {
        this.middelKenmerken = middelKenmerken;
        this.entiteitService.getSearchEntiteitNummer((nr) => {
          this.entiteitNummer = nr;
          this.loadSelectedMiddelKenmerken();
          this.loadSelectedEntiteitMiddelRisicos(this.entiteitNummer, this.selectedMiddel.id);
        });
      });
      this.fiscaliteitService.getRisiscosByMiddelId(this.selectedMiddel?.id).subscribe( riscos => {
        this.middelRisicos = riscos;
      });
    }
  }

  ngOnInit(): void {
    this.titleTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.FISCALITEIT_MIDDELSPECIFIEKE_KENMERKEN_TITLE_TOOLTIP);
  }

  getSelectedKenmerkenBySelectedMiddel(selectedMiddelKenmerken: EntiteitMiddelKenmerk[], selectedMiddel: ZooEntiteitMiddel) {
    this.displayedMiddelKenmerken = this.selectedMiddelKenmerken?.filter(selected => {
      return this.getMiddelKenmerkById(selected.hoofdKenmerkId)?.middelId === selectedMiddel.id;
    });
  }

  getMenuItemsForItem(item: EntiteitMiddelKenmerk, editButton: HTMLButtonElement, editing: boolean, rowIndex: number): MenuItem[] {
    const context = item;
    return [
      {
        label: 'Risico aan kenmerk toevoegen',
        command: e => {
          console.log('Risico aan kenmerk toevoegen '); //Todo:  in another jira issue IVAKBS-226 add Risicos
        },
      },
      {
        label: 'Wijzigen',
        command: e => {
          this.currentRowIndex = rowIndex;
          this.onRowEditInit(e, context, editButton, editing)
        }
      },
      {
        label: 'Verwijderen',
        command: e => {
          this.deleteEntiteitMiddelKenmerk(e, context, editing, rowIndex)
        }
      }
    ]
  }

  onRowEditInit($event, item: EntiteitMiddelKenmerk, editButton: HTMLButtonElement, editing: boolean) {
    this.backupEntiteitMiddelKenmerk = JSON.parse(JSON.stringify(item));
    this.selectedHoofdkenmerkEditable = this.getMiddelKenmerkById(item.hoofdKenmerkId)?.id;
    this.selectedSubkenmerk1Editable = this.getMiddelKenmerkById(item.subKenmerk1Id)?.id;
    this.selectedSubkenmerk2Editable = this.getMiddelKenmerkById(item.subKenmerk2Id)?.id;
    this.selectedSubkenmerk3Editable = this.getMiddelKenmerkById(item.subKenmerk3Id)?.id;

    editButton.click();
    this.editing = editing;
  }

  onRowEditSave() {
    this.currentRowIndex = null;
    const toSave = this.makeEditedEntiteitMiddelKenmerk();
    this.fiscaliteitService.addEntiteitMiddelKenmerk(toSave).subscribe(e => {
      this.loadSelectedMiddelKenmerken();
      this.backupEntiteitMiddelKenmerk = null;
      this.editing = false;
    });
  }

  makeEditedEntiteitMiddelKenmerk() {
    const index = this.findIndexOfBackupEntiteitMiddelKenmerk();
    this.selectedMiddelKenmerken[index].hoofdKenmerkId = <number>this.selectedHoofdkenmerkEditable;
    this.selectedMiddelKenmerken[index].subKenmerk1Id = <number>this.selectedSubkenmerk1Editable;
    this.selectedMiddelKenmerken[index].subKenmerk2Id = <number>this.selectedSubkenmerk2Editable;
    this.selectedMiddelKenmerken[index].subKenmerk3Id = <number>this.selectedSubkenmerk3Editable;
    return this.selectedMiddelKenmerken[index]
  }

  disableWijzgenButton() {
    return this.selectedCombinationExists(
      <number>this.selectedHoofdkenmerkEditable,
      <number>this.selectedSubkenmerk1Editable,
      <number>this.selectedSubkenmerk2Editable,
      <number>this.selectedSubkenmerk3Editable);
  }

  onRowEditCancel() {
    this.currentRowIndex = null;
    const index = this.findIndexOfBackupEntiteitMiddelKenmerk();
    this.selectedMiddelKenmerken[index].hoofdKenmerkId = this.backupEntiteitMiddelKenmerk.hoofdKenmerkId;
    this.selectedMiddelKenmerken[index].subKenmerk1Id = this.backupEntiteitMiddelKenmerk.subKenmerk1Id;
    this.selectedMiddelKenmerken[index].subKenmerk2Id = this.backupEntiteitMiddelKenmerk.subKenmerk2Id;
    this.selectedMiddelKenmerken[index].subKenmerk3Id = this.backupEntiteitMiddelKenmerk.subKenmerk3Id;
    this.backupEntiteitMiddelKenmerk = null;
    this.editing = false;
  }

  private findIndexOfBackupEntiteitMiddelKenmerk(): number {
    let index = 0;
    for(let x = 0; x < this.selectedMiddelKenmerken.length; x++) {
      if ( this.selectedMiddelKenmerken[x].id === this.backupEntiteitMiddelKenmerk.id) {
        index = x;
        break;
      }
    }
    return index;
  }

  deleteEntiteitMiddelKenmerk($event, item: EntiteitMiddelKenmerk, editing: boolean, rowIndex: number) {
    this.editing = editing;
    this.confirm($event, item, rowIndex)
  }

  confirm(event: any, item: EntiteitMiddelKenmerk, rowIndex: number) {
    this.confirmationService.confirm({
      //The event.originalEvent.target is needed to determine the relative position of the popup.
      target: event?.originalEvent?.target,
      key: 'delete-selected-row-' + rowIndex,
      message: "Weet u zeker dat u deze item wilt verwijderen?",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Ja",
      rejectLabel: "Nee",
      accept: () => {
        //Todo: Een waarschuwingsmelding om de gebruiker in kennis te stellen als er gekoppelde risico's zijn die opnieuw moeten worden opgevoerd: jira issue IVAKBS-226
        this.fiscaliteitService.deleteEntiteitMiddelKenmerk(item).subscribe(() => {
          this.loadSelectedMiddelKenmerken();
        });
      },
    });
  }

  loadSelectedMiddelKenmerken() {
    this.fiscaliteitService.getSelectedEntiteitMiddelKenmerken(this.entiteitNummer).subscribe(data => {
      this.selectedMiddelKenmerken = data;
      this.getSelectedKenmerkenBySelectedMiddel(this.selectedMiddelKenmerken, this.selectedMiddel);
    });
  }

  subkenmerkenByParentId(middelKenmerken: MiddelKenmerk[], parentId: number) {
    const result: MiddelKenmerk[] = [];
    for (let entry of middelKenmerken) {
      if (entry.parentId === parentId) {
        result.push(entry);
      }
    }
    return result;
  }

  subkenmerkenByParent(middelKenmerken: MiddelKenmerk[], parent: MiddelKenmerk | number) {
    let id = parent;
    if ((<MiddelKenmerk>parent)?.id) {
      id = (<MiddelKenmerk>parent).id;
    }
    return this.subkenmerkenByParentId(middelKenmerken, <number>id);
  }

  saveSelectedKenmerken() {
    this.fiscaliteitService.addEntiteitMiddelKenmerk(this.makeEntiteitMiddelKenmerk()).subscribe(e => {
      this.loadSelectedMiddelKenmerken();
    });
  }

  disableSaveButton() {
    const toSave = this.makeEntiteitMiddelKenmerk();
    const selectedCombinationExists = this.selectedCombinationExists(toSave.hoofdKenmerkId, toSave.subKenmerk1Id, toSave.subKenmerk2Id, toSave.subKenmerk3Id);
    const selectedHoofdkenmerkIdIsNullish = this.selectedHoofdkenmerk?.id == null;
    return selectedCombinationExists || selectedHoofdkenmerkIdIsNullish;
  }

  selectedCombinationExists(hoodfKenmerkId: number, subKenmerk1Id: number, subKenmerk2Id: number, subKenmerk3Id: number) {
    const exist: EntiteitMiddelKenmerk[] = this.selectedMiddelKenmerken.filter(selected => {
      return selected.hoofdKenmerkId == hoodfKenmerkId &&
        selected.subKenmerk1Id == subKenmerk1Id &&
        selected.subKenmerk2Id == subKenmerk2Id &&
        selected.subKenmerk3Id == subKenmerk3Id
    });
    return exist.length > 0;
  }

  makeEntiteitMiddelKenmerk() {
    return new EntiteitMiddelKenmerk(
      null,
      this.selectedHoofdkenmerk ? this.selectedHoofdkenmerk.id : null,
      this.selectedSubkenmerk1 ? this.selectedSubkenmerk1.id : null,
      this.selectedSubkenmerk2 ? this.selectedSubkenmerk2.id : null,
      this.selectedSubkenmerk3 ? this.selectedSubkenmerk3.id : null,
      null,
      this.entiteitNummer
    );
  }

  loadSelectedEntiteitMiddelRisicos(entiteitNummer: number, middelId: number) {
    this.fiscaliteitService.getSelectedMiddelRisicosByEntiteitNummerAndMiddelId(entiteitNummer, middelId).subscribe(selected => {
      this.selectedEntiteitMiddelRisicos = selected;
    });
  }

  entiteitMiddelKenmerkRiscosTooltipList(entiteitMiddelKenmerkId: number) {
    const tooltipRiscosList: string[] = [];
    const tooltipMiddelRisicosIds = this.getEntiteitMiddelRisicosIdsPerRow(entiteitMiddelKenmerkId);
    tooltipMiddelRisicosIds.forEach(id => {
      const riscoName = this.getRiscoNameById(id);
      tooltipRiscosList.push(riscoName);
    });
    tooltipRiscosList.sort((a, b) => a.localeCompare(b));
    return tooltipRiscosList;
  }

  getEntiteitMiddelRisicosIdsPerRow(entiteitMiddelKenmerkId: number) {
    const middelRisicosByEntiteitMiddelKenmerkId = this.selectedEntiteitMiddelRisicos?.filter(risco => {
      return risco.entiteitMiddelKenmerkId === entiteitMiddelKenmerkId;
    });
    const tooltipMiddelRisicosIds: number[] = [];
    middelRisicosByEntiteitMiddelKenmerkId?.filter(entiteitMiddelRisico => {
      const riscoIdToAdd = entiteitMiddelRisico.subRisicoId ? entiteitMiddelRisico.subRisicoId : entiteitMiddelRisico.hoofdRisicoId;
      tooltipMiddelRisicosIds.push(riscoIdToAdd);
    });
    return tooltipMiddelRisicosIds;
  }

  getRiscoNameById(id: number) {
    return this.middelRisicos.find(k => k.id === id)?.risico;
  }

  getMiddelKenmerkById(id: number) {
    return this.middelKenmerken.find(k => k.id === id);
  }

  volgordeAanpassen() {
    //Todo:  de gewenste volgorde slepen jira issue IVAKBS-225
  }

  ifMiddelenFound() {
    return this.selectedMiddel;
  }
}
