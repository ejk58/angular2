import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbTabpanelComponent } from './zoo-cb-tabpanel.component';

describe('TabpanelComponent', () => {
  let component: ZooCbTabpanelComponent;
  let fixture: ComponentFixture<ZooCbTabpanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbTabpanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbTabpanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
