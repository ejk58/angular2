import {Component, Input, OnInit} from '@angular/core';
import {TabpanelData} from "../../../componenten-generiek/tabview/interfaces/tabpanelData";
import {CBTabPanel} from "../cijferbeoordelingTabpanels";

@Component({
  selector: 'app-zoo-cb-tabpanel',
  templateUrl: './zoo-cb-tabpanel.component.html',
  styleUrls: ['./zoo-cb-tabpanel.component.scss']
})
export class ZooCbTabpanelComponent implements OnInit {
  CBTabpanels = CBTabPanel;
  @Input() tabpanelData: TabpanelData;

  constructor() { }

  ngOnInit(): void {
  }

}
