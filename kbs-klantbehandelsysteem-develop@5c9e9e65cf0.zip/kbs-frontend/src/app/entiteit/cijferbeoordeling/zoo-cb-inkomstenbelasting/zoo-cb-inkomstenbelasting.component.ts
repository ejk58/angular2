import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {Helptext} from '../../../componenten-generiek/helptext/helptext';
import {EntiteitService} from '../../../services/entiteit.service';
import {HelptextService} from '../../../services/helptext.service';
import {HelptextIds} from '../../../shared/helptext-ids';
import {KenmerkenService} from '../../../services/kenmerken.service';
import {KenmerkType} from '../../../services/kenmerkType';
import {MultiSelectListGroep} from '../../../interfaces/multi-select-list-groep';

@Component({
  selector: 'app-zoo-cb-inkomstenbelasting',
  templateUrl: './zoo-cb-inkomstenbelasting.component.html',
  styleUrls: ['./zoo-cb-inkomstenbelasting.component.scss']
})
export class ZooCbInkomstenbelastingComponent implements OnInit {

  HelptextIds = HelptextIds;

  textToelichtingTitleZooInkomstenBelTooltip$: Observable<Helptext>;
  textToelichtingSectorTooltip$: Observable<Helptext>;

  entiteitnummer: number;

  attentiepunten: MultiSelectListGroep[] = [];
  selectedAttentiepunten: MultiSelectListGroep[];
  selectedAttentiepuntIds: number[] = [];

  constructor(private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService,
              private readonly helptextService: HelptextService) {
  }

  ngOnInit(): void {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitnummer = nr;
      this.kenmerkenService.getCbAttentiepuntenInkomstenbelasting().subscribe((data) => {
        this.attentiepunten = data;
        this.getSelectedAttentiepunten(nr);
      });
    });

    this.textToelichtingTitleZooInkomstenBelTooltip$ = this.helptextService
      .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_INKOMSTENBELASTING_TITLE_TOOLTIP);
    this.textToelichtingSectorTooltip$ = this.helptextService
      .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_INKOMSTENBELASTING_ATTENTIEPUNTEN_TITLE_TOOLTIP);
  }

  private getSelectedAttentiepunten(bsnRsin: number) {
    this.kenmerkenService.getSelectedCbAttentiepuntenInkomstenbelasting(bsnRsin).subscribe((selectedApArr) => {
      this.selectedAttentiepuntIds = selectedApArr.map(d => d.id);
      this.selectedAttentiepunten = this.getGroepenWithSelectedAttentiepunten();
    });
  }

  saveSelectedAndUpdateSelectedAttentiepunten() {
    this.kenmerkenService.saveSelectionIds(this.entiteitnummer, KenmerkType.CBIBV, this.selectedAttentiepuntIds)
      .subscribe( () => this.getSelectedAttentiepunten(this.entiteitnummer));
  }

  private getGroepenWithSelectedAttentiepunten(): MultiSelectListGroep[] {
    return this.attentiepunten
      .map(groep => {
        // Make deep copy using object destructuring to prevent modification of original groep
        const groepCopy: MultiSelectListGroep = {...groep};
        // Filter out items in groep that aren't in user selection
        groepCopy.items = groepCopy.items.filter(i => this.selectedAttentiepuntIds.includes(i.id));
        return groepCopy;
      })
      .filter(groep => groep.items.length > 0); // Only return groepen that have (selected) items
  }
}
