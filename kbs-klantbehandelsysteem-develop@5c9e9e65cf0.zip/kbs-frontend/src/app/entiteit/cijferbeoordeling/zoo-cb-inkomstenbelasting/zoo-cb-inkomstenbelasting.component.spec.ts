import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbInkomstenbelastingComponent } from './zoo-cb-inkomstenbelasting.component';

describe('ZooCbInkomstenbelastingComponent', () => {
  let component: ZooCbInkomstenbelastingComponent;
  let fixture: ComponentFixture<ZooCbInkomstenbelastingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbInkomstenbelastingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbInkomstenbelastingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
