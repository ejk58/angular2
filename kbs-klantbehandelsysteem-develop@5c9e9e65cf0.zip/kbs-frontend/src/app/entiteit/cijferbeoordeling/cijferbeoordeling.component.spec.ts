import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CijferbeoordelingComponent } from './cijferbeoordeling.component';

describe('CijferbeoordelingComponent', () => {
  let component: CijferbeoordelingComponent;
  let fixture: ComponentFixture<CijferbeoordelingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CijferbeoordelingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CijferbeoordelingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
