import {Component, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {Entiteit} from "../shared/entiteit";
import {EntiteitService} from "../../services/entiteit.service";
import {ZooEntiteitMiddel} from "../../interfaces/ZooEntiteitMiddel";
import {KenmerkenService} from "../../services/kenmerken.service";
import {CBTabPanel, CBTabPanelCheck} from "./cijferbeoordelingTabpanels";
import {TabviewData} from "../../componenten-generiek/tabview/interfaces/tabviewData";

@Component({
  selector: 'app-cijferbeoordeling',
  templateUrl: './cijferbeoordeling.component.html',
  styleUrls: ['./cijferbeoordeling.component.scss']
})
export class CijferbeoordelingComponent implements OnInit {

  selectedTabNumber = 0;
  entiteit$: Observable<Entiteit>;
  selectedMiddelen$: Observable<ZooEntiteitMiddel[]>;
  private entiteitnummer: number;

  constructor(private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService,
  ) {}

  tabviewData: TabviewData[] = [];

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteit$ = this.entiteitService.getEntiteit(nr);
      this.entiteitnummer = nr;
      this.selectedMiddelen$ = this.kenmerkenService.getSelectedMiddelen(this.entiteitnummer);
      // <!--    first tab fixed..-->
      this.tabviewData.push({
        tabId: 0,
        entiteitId: this.entiteitnummer,
        groep: "OrgOmvang",
        header: CBTabPanel.ORGANISATIEOMVANG
      });
      this.selectedMiddelen$.subscribe(data => {

        const addTabsDynamicallyWithSpecificComponents: TabviewData[] = data
          .filter((d:ZooEntiteitMiddel) => CBTabPanelCheck.getKey(d.kenmerk) !== null)
          .map((dataForTabs) => ({
            tabId: dataForTabs.id,
            entiteitId: this.entiteitnummer,
            groep: dataForTabs.groep,
            header: dataForTabs.kenmerk
          } as TabviewData))
        this.tabviewData.push(...addTabsDynamicallyWithSpecificComponents);

        const addTabsDynamicallyOverig: TabviewData[] = data
          .filter((d:ZooEntiteitMiddel) => CBTabPanelCheck.getKey(d.kenmerk) === null)
          .map((dataForTabs) => ({
            tabId: dataForTabs.id,
            entiteitId: this.entiteitnummer,
            groep: dataForTabs.groep,
            header: dataForTabs.kenmerk
          } as TabviewData))
        this.tabviewData.push(...addTabsDynamicallyOverig);
      })
    });
  }

}
