import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbVpbComponent } from './zoo-cb-vpb.component';

describe('ZooCbVpbComponent', () => {
  let component: ZooCbVpbComponent;
  let fixture: ComponentFixture<ZooCbVpbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbVpbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbVpbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
