import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zoo-cb-vpb',
  templateUrl: './zoo-cb-vpb.component.html',
  styleUrls: ['./zoo-cb-vpb.component.scss']
})
export class ZooCbVpbComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
