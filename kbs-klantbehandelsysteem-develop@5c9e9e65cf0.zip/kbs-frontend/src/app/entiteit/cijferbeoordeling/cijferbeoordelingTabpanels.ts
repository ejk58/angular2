export enum CBTabPanel {
  ORGANISATIEOMVANG = 'Organisatieomvang',
  VENNOOTSCHAPSBELASTING ='Vennootschapsbelasting',
  OMZETBELASTING = 'Omzetbelasting',
  LOONHEFFINGEN ='Loonheffingen c.s.',
  INKOMSTENBELASTING = 'Inkomstenbelasting en premie volksverzekeringen',
  INVORDERING = 'Invordering',
  OVERIGE ='Overige middelen' //  TODO: wordt niet meer gebruikt, mag weg

}

export class CBTabPanelCheck {
  static getKey(enumValue): string {
    let keys = Object.keys(CBTabPanel).filter(x => CBTabPanel[x] == enumValue);
    return keys.length > 0 ? keys[0] : null;
  }
}
