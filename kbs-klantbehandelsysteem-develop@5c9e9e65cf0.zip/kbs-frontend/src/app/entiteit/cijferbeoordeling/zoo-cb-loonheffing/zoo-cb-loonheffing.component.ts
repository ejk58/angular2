import {Component, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {HelptextIds} from "../../../shared/helptext-ids";
import {EntiteitService} from "../../../services/entiteit.service";
import {HelptextService} from "../../../services/helptext.service";

@Component({
  selector: 'app-zoo-cb-loonheffing',
  templateUrl: './zoo-cb-loonheffing.component.html',
  styleUrls: ['./zoo-cb-loonheffing.component.scss']
})
export class ZooCbLoonheffingComponent implements OnInit {

  loonheffingenTitle: string = "Cijferbeoordeling loonheffingen"
  loonheffingenTitleTooltip$: Observable<Helptext>;

  helptextIds = HelptextIds;
  aangifteTitle: string = "Analyse op aangifte loonheffingen"
  aandachtspuntenTitle: string = "Conclusie met aandachtspunten voor de klantbehandeling"

  constructor(private readonly entiteitService: EntiteitService,
              private readonly helptextService: HelptextService) {
  }

  ngOnInit(): void {
    this.loonheffingenTitleTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_LOONHEFFINGEN_TITLE_TOOLTIP);
  }

}
