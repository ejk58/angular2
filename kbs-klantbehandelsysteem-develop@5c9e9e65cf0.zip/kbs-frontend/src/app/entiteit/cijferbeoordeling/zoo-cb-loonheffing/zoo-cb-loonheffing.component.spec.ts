import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbLoonheffingComponent } from './zoo-cb-loonheffing.component';

describe('ZooCbLoonheffingComponent', () => {
  let component: ZooCbLoonheffingComponent;
  let fixture: ComponentFixture<ZooCbLoonheffingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbLoonheffingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbLoonheffingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
