import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbOmzetbelastingComponent } from './zoo-cb-omzetbelasting.component';

describe('ZooCbOmzetbelastingComponent', () => {
  let component: ZooCbOmzetbelastingComponent;
  let fixture: ComponentFixture<ZooCbOmzetbelastingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbOmzetbelastingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbOmzetbelastingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
