import { Component, OnInit } from '@angular/core';
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {Observable, of} from "rxjs";
import {EntiteitService} from "../../../services/entiteit.service";
import {HelptextService} from "../../../services/helptext.service";
import {HelptextIds} from "../../../shared/helptext-ids";
import {ZooEntiteitMiddel} from "../../../interfaces/ZooEntiteitMiddel";
import {EntiteitKenmerk} from "../../../interfaces/EntiteitKenmerk";
import {KenmerkType} from "../../../services/kenmerkType";
import {KenmerkenService} from "../../../services/kenmerken.service";

@Component({
  selector: 'app-zoo-cb-omzetbelasting',
  templateUrl: './zoo-cb-omzetbelasting.component.html',
  styleUrls: ['./zoo-cb-omzetbelasting.component.scss']
})
export class ZooCbOmzetbelastingComponent implements OnInit {
  helptextIds = HelptextIds;
  panelType: string = "omzetbelasting";
  titleOmzetbelastingTitleTooltip$: Observable<Helptext>;
  titleAttentiepuntenTooltip$: Observable<Helptext>;

  private entiteitnummer: number;

  attentiepunten$: Observable<EntiteitKenmerk[]>;
  selectedAttentiepuntenOmzetbelasting$: Observable<EntiteitKenmerk[]> = of([]);

  constructor(private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService,
              private readonly helptextService: HelptextService) { }

  ngOnInit(): void {
    this.attentiepunten$ =this.kenmerkenService.getZooEntiteitAttentiepunten();
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitnummer = nr;
      this.titleOmzetbelastingTitleTooltip$ = this.helptextService
        .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_OMZETBELASTING_TITLE_TOOLTIP);
      this.titleAttentiepuntenTooltip$ = this.helptextService
        .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_OMZETBELASTING_ATTENTIEPUNTEN_TOOLTIP);
      this.selectedAttentiepuntenOmzetbelasting$ = this.kenmerkenService.getSelectedAttentiepunten(nr);
    })
  }

  saveMiddelenSelections(selectedAttentiepunten: ZooEntiteitMiddel[]) {
    this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.CBOBA, selectedAttentiepunten).subscribe();
  }
}
