import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbOrganisatieomvangComponent } from './zoo-cb-organisatieomvang.component';

describe('ZooCbOrganisatieomvangComponent', () => {
  let component: ZooCbOrganisatieomvangComponent;
  let fixture: ComponentFixture<ZooCbOrganisatieomvangComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbOrganisatieomvangComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbOrganisatieomvangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
