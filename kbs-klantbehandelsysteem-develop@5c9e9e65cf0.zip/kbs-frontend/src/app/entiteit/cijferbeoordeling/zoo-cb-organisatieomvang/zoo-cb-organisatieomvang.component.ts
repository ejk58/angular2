import {Component, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {HelptextService} from "../../../services/helptext.service";
import {HelptextIds} from "../../../shared/helptext-ids";

@Component({
  selector: 'app-zoo-cb-organisatieomvang',
  templateUrl: './zoo-cb-organisatieomvang.component.html',
  styleUrls: ['./zoo-cb-organisatieomvang.component.scss']
})
export class ZooCbOrganisatieomvangComponent implements OnInit {
  HelptextIds = HelptextIds;

  textToelichtingTitleZooTooltip$: Observable<Helptext>;
  titelToelichting = 'Algemeen - organisatieomvang';

  constructor(private readonly helptextService: HelptextService) {
  }

  ngOnInit(): void {
    this.textToelichtingTitleZooTooltip$ = this.helptextService
      .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_ORGANISATIEOMVANG_TITLE);
  }

}
