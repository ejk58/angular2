import {Component, Input, OnInit} from '@angular/core';
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {Observable} from "rxjs";
import {EntiteitService} from "../../../services/entiteit.service";
import {HelptextService} from "../../../services/helptext.service";
import {HelptextIds} from "../../../shared/helptext-ids";

@Component({
  selector: 'app-zoo-cb-overigemiddelen',
  templateUrl: './zoo-cb-overigemiddelen.component.html',
  styleUrls: ['./zoo-cb-overigemiddelen.component.scss']
})
export class ZooCbOverigemiddelenComponent implements OnInit {
  @Input() panelType: string;
  titleOverigeMiddlelenTooltip$: Observable<Helptext>;

  private entiteitnummer: number;

  constructor(private readonly entiteitService: EntiteitService,
              private readonly helptextService: HelptextService) {
  }

  ngOnInit(): void {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitnummer = nr;
      this.titleOverigeMiddlelenTooltip$ = this.helptextService
        .getHelptextTooltip(`zoo_over-mid_title_${this.preserveMaxLength(this.panelType).toLowerCase()}_tooltip`);
    })
  }

  preserveMaxLength(text: string): string {
    let id: string = text.toLowerCase().split(" ").join("_");
    if (id.length > 16) {
      id = id.substr(0,16);
    }
    return id;
  }

  getToelichtingText(middel: string) {
    return `zoo_over-mid_${this.preserveMaxLength(middel)}_toelichting`;
  }

  getTooltip(middel: string) {
    return `zoo_over-mid_${this.preserveMaxLength(middel)}_tooltip`
  }

  getToelichtingConclusieText(middel: string) {
    return `zoo_over-mid_conc_${this.preserveMaxLength(middel)}_toelichting`;
  }

  getTooltipConclusie(middel: string) {
    return `zoo_over-mid_conc_${this.preserveMaxLength(middel)}_tooltip`
  }

  getTitleAnalyse(panelType: string) {
    return `Analyse op ${this.panelType.toLowerCase()}`
  }
}
