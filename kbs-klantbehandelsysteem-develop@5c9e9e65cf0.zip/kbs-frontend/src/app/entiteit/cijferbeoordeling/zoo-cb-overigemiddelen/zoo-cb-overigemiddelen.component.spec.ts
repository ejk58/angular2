import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbOverigemiddelenComponent } from './zoo-cb-overigemiddelen.component';

describe('ZooCbOverigemiddelenComponent', () => {
  let component: ZooCbOverigemiddelenComponent;
  let fixture: ComponentFixture<ZooCbOverigemiddelenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbOverigemiddelenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbOverigemiddelenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
