import {Component, OnInit} from '@angular/core';
import {Observable, of} from "rxjs";
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {HelptextIds} from "../../../shared/helptext-ids";
import {EntiteitService} from "../../../services/entiteit.service";
import {HelptextService} from "../../../services/helptext.service";
import {KenmerkenService} from "../../../services/kenmerken.service";
import {EntiteitKenmerk} from "../../../interfaces/EntiteitKenmerk";
import {KenmerkType} from "../../../services/kenmerkType";


@Component({
  selector: 'app-zoo-cb-vennootschapsbelasting',
  templateUrl: './zoo-cb-vennootschapsbelasting.component.html',
  styleUrls: ['./zoo-cb-vennootschapsbelasting.component.scss']
})
export class ZooCbVennootschapsbelastingComponent implements OnInit {
  HelptextIds = HelptextIds;

  titleCijferbeoordelingVennootschapTooltip: Observable<Helptext>;
  attentiepuntenBalansTitleTooltip$: Observable<Helptext>;
  attentiepuntenWinstenVerliesTitleTooltip$: Observable<Helptext>;

  attentiepuntenTitleTooltip$: Observable<Helptext>;
  attentiepunten$: Observable<EntiteitKenmerk[]>;
  attentiepuntenBalans$: Observable<EntiteitKenmerk[]>;
  attentiepuntenWinstEnVerlies$: Observable<EntiteitKenmerk[]>;
  selectedActiepunten$: Observable<EntiteitKenmerk[]> = of([]);
  selectedBalansActiepunten$: Observable<EntiteitKenmerk[]> = of([]);
  selectedWinstEnVerliesActiepunten$: Observable<EntiteitKenmerk[]> = of([]);

  private entiteitnummer: number;

  constructor(private readonly entiteitService: EntiteitService,
              private readonly helptextService: HelptextService,
              private readonly kenmerkenService: KenmerkenService) {
  }

  ngOnInit(): void {
    this.attentiepunten$ = this.kenmerkenService.getAttentiepunten();
    this.attentiepuntenBalans$ = this.kenmerkenService.getAttentiepuntenBalans();
    this.attentiepuntenWinstEnVerlies$ = this.kenmerkenService.getAttentiepuntenWinstEnVerlies();

    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitnummer = nr;
      this.selectedActiepunten$               = this.kenmerkenService.getSelectedActiepunten(this.entiteitnummer);
      this.selectedBalansActiepunten$         = this.kenmerkenService.getSelectedActiepuntenBalans(this.entiteitnummer);
      this.selectedWinstEnVerliesActiepunten$ = this.kenmerkenService.getSelectedActiepuntenWinstEnVerlies(this.entiteitnummer);
    });

    this.titleCijferbeoordelingVennootschapTooltip = this.helptextService
      .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_VENNOOTSCHAPBELASTING_TITLE);

    this.attentiepuntenTitleTooltip$ = this.helptextService
      .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_VENNOOTSCHAPBELATING_ATTENTITEPUNTEN_TOOLTIP);

    this.attentiepuntenBalansTitleTooltip$ = this.helptextService
      .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_VENNOOTSCHAPBELATING_ATTENTITEPUNTEN_BALANS_TOOLTIP);
    this.attentiepuntenWinstenVerliesTitleTooltip$ = this.helptextService
      .getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_VENNOOTSCHAPBELATING_ATTENTITEPUNTEN_WV_TOOLTIP);
  }

  saveActiepuntenSelections(selectedActiepunten: EntiteitKenmerk[]) {
    this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.CBAP, selectedActiepunten).subscribe();
  }

  saveActiepuntBalansenSelections(selectedBalansActiepunten: EntiteitKenmerk[]) {
    this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.CBAPB, selectedBalansActiepunten).subscribe();
  }

  saveActiepuntWinstEnVerliesSelections(selectedWinstEnVerliesActiepunten: EntiteitKenmerk[]) {
    this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.CBAPW, selectedWinstEnVerliesActiepunten).subscribe();
  }
}
