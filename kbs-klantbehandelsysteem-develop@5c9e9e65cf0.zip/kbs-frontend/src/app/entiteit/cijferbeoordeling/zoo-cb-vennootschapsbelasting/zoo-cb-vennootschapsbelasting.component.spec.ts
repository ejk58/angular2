import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbVennootschapsbelastingComponent } from './zoo-cb-vennootschapsbelasting.component';

describe('ZooCbVennootschapsbelastingComponent', () => {
  let component: ZooCbVennootschapsbelastingComponent;
  let fixture: ComponentFixture<ZooCbVennootschapsbelastingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbVennootschapsbelastingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbVennootschapsbelastingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
