import {Component, OnInit} from '@angular/core';
import {HelptextIds} from '../../../shared/helptext-ids';
import {HelptextService} from '../../../services/helptext.service';

@Component({
  selector: 'app-zoo-cb-invordering',
  templateUrl: './zoo-cb-invordering.component.html',
  styleUrls: ['./zoo-cb-invordering.component.scss']
})
export class ZooCbInvorderingComponent implements OnInit {

  readonly HelptextIds = HelptextIds;

  readonly title = "Cijferbeoordeling invordering";
  readonly titleTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.CIJFERBEOORDELING_INVORDERING_TITLE_TOOLTIP);

  readonly analyseTitle = "Analyse op invordering";
  readonly aandachtspuntenTitle = "Conclusie met aandachtspunten voor de klantbehandeling";

  constructor(private readonly helptextService: HelptextService) {
  }

  ngOnInit(): void {
  }
}
