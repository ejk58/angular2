import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooCbInvorderingComponent } from './zoo-cb-invordering.component';

describe('ZooCbInvorderingComponent', () => {
  let component: ZooCbInvorderingComponent;
  let fixture: ComponentFixture<ZooCbInvorderingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooCbInvorderingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooCbInvorderingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
