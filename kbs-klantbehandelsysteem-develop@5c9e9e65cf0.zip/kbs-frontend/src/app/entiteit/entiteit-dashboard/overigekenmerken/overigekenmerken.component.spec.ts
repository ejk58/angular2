import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverigekenmerkenComponent } from './overigekenmerken.component';

describe('EntiteitDashboardOverigekenmerkenComponent', () => {
  let component: OverigekenmerkenComponent;
  let fixture: ComponentFixture<OverigekenmerkenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OverigekenmerkenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OverigekenmerkenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
