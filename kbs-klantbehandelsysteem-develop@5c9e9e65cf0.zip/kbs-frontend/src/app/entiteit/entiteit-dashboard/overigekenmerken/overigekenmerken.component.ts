import {Component, Input, OnInit} from '@angular/core';
import {EMPTY, Observable} from 'rxjs';
import {Entiteit} from '../../shared/entiteit';
import {EntiteitService} from '../../../services/entiteit.service';

@Component({
  selector: 'app-entiteit-dashboard-overigekenmerken',
  templateUrl: './overigekenmerken.component.html',
  styleUrls: ['./overigekenmerken.component.scss']
})
export class OverigekenmerkenComponent implements OnInit {

  @Input() entiteit$: Observable<Entiteit>;

  kenmerkenLijst$: Observable<string[][][]>

  constructor(private readonly entiteitService: EntiteitService) { }

  ngOnInit(): void {
    this.entiteitService.searchEntiteit.subscribe((id)=> {
      if (id > 0) {
        console.log('search entity found...');
        this.kenmerkenLijst$ = this.entiteitService.getDashboard_Kenmerkenlijst(id);
      } else {
        console.log('no search entity...');
        this.kenmerkenLijst$ = EMPTY;
      }
    });
  }

}
