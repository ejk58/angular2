import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitDashboardComponent } from './entiteit-dashboard.component';

describe('EntiteitDashboardComponent', () => {
  let component: EntiteitDashboardComponent;
  let fixture: ComponentFixture<EntiteitDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
