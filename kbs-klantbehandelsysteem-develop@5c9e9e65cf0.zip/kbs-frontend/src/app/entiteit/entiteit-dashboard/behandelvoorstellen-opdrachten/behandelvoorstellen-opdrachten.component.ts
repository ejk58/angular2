import {Component, Input, OnInit} from '@angular/core';
import {EntiteitService} from "../../../services/entiteit.service";
import {Observable, EMPTY} from "rxjs";
import {Behandelvoorstel} from "../../shared/behandelvoorstel";
import {Opdracht} from "../../shared/opdracht";
import {Entiteit} from '../../shared/entiteit';

@Component({
  selector: 'app-behandelvoorstellen-opdrachten',
  templateUrl: './behandelvoorstellen-opdrachten.component.html',
  styleUrls: ['./behandelvoorstellen-opdrachten.component.scss']
})
export class BehandelvoorstellenOpdrachtenComponent implements OnInit {

  @Input() entiteit$: Observable<Entiteit>;

  behandelvoorstellen$: Observable<Behandelvoorstel[]>;
  opdrachtenlijst$: Observable<Opdracht[]>

  constructor(private readonly entiteitService: EntiteitService) { }

  ngOnInit(): void {
    this.entiteitService.searchEntiteit.subscribe((id)=>{
      if (id > 0) {
        console.log('search entity found...');
        this.behandelvoorstellen$ = this.entiteitService.getDashboard_Behandelvoorstellen(id);
        this.opdrachtenlijst$ = this.entiteitService.getDashboard_OpdrachtenLijst(id);
      } else {
        console.log('no search entity...');
        this.behandelvoorstellen$ = EMPTY;
      }
    });
  }

}
