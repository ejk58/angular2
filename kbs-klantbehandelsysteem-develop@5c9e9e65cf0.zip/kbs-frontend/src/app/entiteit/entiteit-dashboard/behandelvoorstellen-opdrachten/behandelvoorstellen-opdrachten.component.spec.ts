import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BehandelvoorstellenOpdrachtenComponent } from './behandelvoorstellen-opdrachten.component';

describe('EntiteitDashboardBehandelvoorstellenOpdrachtenComponent', () => {
  let component: BehandelvoorstellenOpdrachtenComponent;
  let fixture: ComponentFixture<BehandelvoorstellenOpdrachtenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BehandelvoorstellenOpdrachtenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BehandelvoorstellenOpdrachtenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
