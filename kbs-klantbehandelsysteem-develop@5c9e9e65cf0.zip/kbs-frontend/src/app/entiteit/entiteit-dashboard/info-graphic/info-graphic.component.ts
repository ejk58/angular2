import {Component, Input, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {Entiteit} from '../../shared/entiteit';

@Component({
  selector: 'app-info-graphic',
  templateUrl: './info-graphic.component.html',
  styleUrls: ['./info-graphic.component.scss']
})
export class InfoGraphicComponent implements OnInit {

  @Input() entiteit$: Observable<Entiteit>;

  basicData: any;
  basicOptions1: any;
  basicOptions2: any;
  basicOptions3: any;

  constructor() { }

  ngOnInit(): void {
    this.basicData = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [
        {
          label: '!!! My First dataset',
          backgroundColor: '#42A5F5',
          data: [65, 59, 80, 81, 56, 55, 40]
        },
        {
          label: '!!! My Second dataset',
          backgroundColor: '#FFA726',
          data: [28, 48, 40, 19, 86, 27, 90]
        }
      ]
    };

    this.basicOptions1 = {
      title: {
        display: true,
        text: 'Line dummy',
        fontSize: 16
      },
      legend: {
        position: 'bottom'
      }
    };
    this.basicOptions2 = {
      title: {
        display: true,
        text: 'Bar dummy',
        fontSize: 16
      },
      legend: {
        position: 'bottom'
      }
    };
    this.basicOptions3 = {
      title: {
        display: true,
        text: 'Horizontal dummy',
        fontSize: 16
      },
      legend: {
        position: 'bottom'
      }
    };
  }

}
