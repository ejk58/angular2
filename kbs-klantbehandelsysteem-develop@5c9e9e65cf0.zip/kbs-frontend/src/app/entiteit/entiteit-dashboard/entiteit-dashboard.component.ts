import {Component, Input, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {Entiteit} from '../shared/entiteit';
import {EntiteitService} from "../../services/entiteit.service";

@Component({
  selector: 'app-entiteit-dashboard',
  templateUrl: './entiteit-dashboard.component.html',
  styleUrls: ['./entiteit-dashboard.component.scss']
})
export class EntiteitDashboardComponent implements OnInit {

  entiteit$: Observable<Entiteit>;

  constructor(private readonly entiteitService: EntiteitService) {
  }

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteit$ = this.entiteitService.getEntiteit(nr);
    });
  }

}
