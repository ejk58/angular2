import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitBehandelplangegevensComponent } from './entiteit-behandelplangegevens.component';

describe('EntiteitBehandelplangegevensComponent', () => {
  let component: EntiteitBehandelplangegevensComponent;
  let fixture: ComponentFixture<EntiteitBehandelplangegevensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitBehandelplangegevensComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitBehandelplangegevensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
