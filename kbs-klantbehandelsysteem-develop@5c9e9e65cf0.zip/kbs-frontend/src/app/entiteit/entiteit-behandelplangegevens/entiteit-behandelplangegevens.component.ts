import { Component, OnInit } from '@angular/core';
import {KenmerkenService} from '../../services/kenmerken.service';
import {Observable} from 'rxjs';
import {EntiteitKenmerk} from '../../interfaces/EntiteitKenmerk';

@Component({
  selector: 'app-entiteit-behandelplangegevens',
  templateUrl: './entiteit-behandelplangegevens.component.html',
  styleUrls: ['./entiteit-behandelplangegevens.component.scss']
})
export class EntiteitBehandelplangegevensComponent implements OnInit {

  public kenmerken$: Observable<EntiteitKenmerk[]>;
  constructor(private readonly kenmerkenService: KenmerkenService) { }

  ngOnInit(): void {
    this.kenmerken$ = this.kenmerkenService.getTestKenmerken();
  }

}
