import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entiteit-verantwoorden',
  templateUrl: './entiteit-verantwoorden.component.html',
  styleUrls: ['./entiteit-verantwoorden.component.scss']
})
export class EntiteitVerantwoordenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
