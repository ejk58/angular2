import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitVerantwoordenComponent } from './entiteit-verantwoorden.component';

describe('EntiteitVerantwoordenComponent', () => {
  let component: EntiteitVerantwoordenComponent;
  let fixture: ComponentFixture<EntiteitVerantwoordenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitVerantwoordenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitVerantwoordenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
