import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bedrijfsactiviteiten',
  templateUrl: './bedrijfsactiviteiten.component.html',
  styleUrls: ['./bedrijfsactiviteiten.component.scss']
})
export class BedrijfsactiviteitenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
