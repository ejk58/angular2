import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BedrijfsactiviteitenComponent } from './bedrijfsactiviteiten.component';

describe('BedrijfsactiviteitenComponent', () => {
  let component: BedrijfsactiviteitenComponent;
  let fixture: ComponentFixture<BedrijfsactiviteitenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BedrijfsactiviteitenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BedrijfsactiviteitenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
