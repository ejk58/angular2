import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitLetsGoComponent } from './entiteit-lets-go.component';

describe('EntiteitLetsGoComponent', () => {
  let component: EntiteitLetsGoComponent;
  let fixture: ComponentFixture<EntiteitLetsGoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitLetsGoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitLetsGoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
