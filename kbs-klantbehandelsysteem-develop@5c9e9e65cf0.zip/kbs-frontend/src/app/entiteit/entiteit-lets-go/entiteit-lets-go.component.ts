import { Component, OnInit } from '@angular/core';
import {Observable} from "rxjs";
import {Entiteit} from "../shared/entiteit";
import {EntiteitService} from "../../services/entiteit.service";

@Component({
  selector: 'app-entiteit-lets-go',
  templateUrl: './entiteit-lets-go.component.html',
  styleUrls: ['./entiteit-lets-go.component.scss']
})
export class EntiteitLetsGoComponent implements OnInit {
  entiteit$: Observable<Entiteit>;

  constructor(private readonly entiteitService: EntiteitService) {
  }

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteit$ = this.entiteitService.getEntiteit(nr);
    });
  }
}
