import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooKenmerkenComponent } from './zoo-kenmerken.component';

describe('ZooKenmerkenComponent', () => {
  let component: ZooKenmerkenComponent;
  let fixture: ComponentFixture<ZooKenmerkenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooKenmerkenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooKenmerkenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
