import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zoo-kenmerken',
  templateUrl: './zoo-kenmerken.component.html',
  styleUrls: ['./zoo-kenmerken.component.scss']
})
export class ZooKenmerkenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
