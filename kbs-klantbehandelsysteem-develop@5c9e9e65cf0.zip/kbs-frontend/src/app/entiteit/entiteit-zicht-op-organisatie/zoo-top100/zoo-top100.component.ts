import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zoo-top100',
  templateUrl: './zoo-top100.component.html',
  styleUrls: ['./zoo-top100.component.scss']
})
export class ZooTop100Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
