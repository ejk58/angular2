import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooTop100Component } from './zoo-top100.component';

describe('ZooTop100Component', () => {
  let component: ZooTop100Component;
  let fixture: ComponentFixture<ZooTop100Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooTop100Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooTop100Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
