import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooInenexterneKenmerkenComponent } from './zoo-inenexterne-kenmerken.component';

describe('ZooInenexterneKenmerkrenComponent', () => {
  let component: ZooInenexterneKenmerkenComponent;
  let fixture: ComponentFixture<ZooInenexterneKenmerkenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooInenexterneKenmerkenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooInenexterneKenmerkenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
