import {Component, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {HelptextIds} from "../../../shared/helptext-ids";
import {HelptextService} from "../../../services/helptext.service";
import {EntiteitService} from "../../../services/entiteit.service";
import {KenmerkenService} from "../../../services/kenmerken.service";
import {ExterneOmgevingKenmerk} from "../../../interfaces/externeOmgeving-kenmerk";
import {BedrijfsstrategieKenmerk} from "../../../interfaces/bedrijfsstrategie-kenmerk";
import {GovernanceStructuurKenmerk} from "../../../interfaces/governanceStructuur-kenmerk";
import {RisicomanagementKenmerken} from "../../../interfaces/risicomanagement-kenmerk";
import {KenmerkType} from '../../../services/kenmerkType';

@Component({
  selector: 'app-zoo-inenexterne-kenmerken',
  templateUrl: './zoo-inenexterne-kenmerken.component.html',
  styleUrls: ['./zoo-inenexterne-kenmerken.component.scss']
})
export class ZooInenexterneKenmerkenComponent implements OnInit {

  HelptextIds = HelptextIds;

  textBedrijfsstrategie = 'Bedrijfsstrategie';
  bedrijfsstrategieTooltip$: Observable<Helptext>;
  bedrijfsstrategieToelichting$: Observable<Helptext>;
  bedrijfsstrategien$: Observable<BedrijfsstrategieKenmerk[]>;
  selectedBedrijfsstrategien$: Observable<BedrijfsstrategieKenmerk[]>;

  externeOmgeving = 'Externe omgeving';
  externeOmgevingTooltip$: Observable<Helptext>;
  externeOmgevingToelichting$: Observable<Helptext>;
  externeOmgevingKenmerken$: Observable<ExterneOmgevingKenmerk[]>;
  selectedExterneOmgeving$: Observable<ExterneOmgevingKenmerk[]>;

  interneOrganisatie = 'Interne organisatie';
  interneOrganisatieTooltip$: Observable<Helptext>;
  governanceStructuurTooltip$: Observable<Helptext>;
  governanceStructuurToelichting$: Observable<Helptext>;
  allGovernanceStructuurKenmerken: GovernanceStructuurKenmerk[];
  selectedGovernanceStructuurKenmerken: GovernanceStructuurKenmerk[];
  risicoManagementTooltip$: Observable<Helptext>;
  risicoManagementToelichting$: Observable<Helptext>;
  risicomanagementKenmerken: RisicomanagementKenmerken[];
  selectedRisicomanagementKenmerken: RisicomanagementKenmerken[];

  entiteitnummer: number;

  constructor(private readonly helptextService: HelptextService,
              private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService) {
  }

  ngOnInit(): void {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitnummer = nr;
      if (this.entiteitnummer > 0) {
        this.bedrijfsstrategieToelichting$ = this.helptextService.getHelptextForEntiteit(HelptextIds.IN_EN_EXTERNE_BEDRIJFSSTRATEGIE_TOELICHTING, this.entiteitnummer);
        this.bedrijfsstrategieTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.IN_EN_EXTERNE_BEDRIJFSSTRATEGIE_TOOLTIP);
        this.externeOmgevingToelichting$ = this.helptextService.getHelptextForEntiteit(HelptextIds.IN_EN_EXTERNE_EXTERNEOMGEVING_TOELICHTING, this.entiteitnummer);
        this.externeOmgevingTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.IN_EN_EXTERNE_EXTERNEOMGEVING_TOOLTIP);
        this.interneOrganisatieTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.IN_EN_EXTERNE_INTERNEORGANISATIE_TOOLTIP);
        this.governanceStructuurTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.IN_EN_EXTERNE_GOVERNANCE_STRUCTUUR_TOOLTIP);
        this.governanceStructuurToelichting$ = this.helptextService.getHelptextForEntiteit(HelptextIds.IN_EN_EXTERNE_GOVERNANCE_STRUCTUUR_TOELICHTING, this.entiteitnummer);
        this.risicoManagementTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.IN_EN_EXTERNE_RISCOMANAGEMENT_TOOLTIP);
        this.risicoManagementToelichting$ = this.helptextService.getHelptextForEntiteit(HelptextIds.IN_EN_EXTERNE_RISCOMANAGEMENT_TOELICHTING, this.entiteitnummer);

        this.bedrijfsstrategien$ = this.kenmerkenService.allBedrijfsstrategieKenmerken();
        this.selectedBedrijfsstrategien$ = this.kenmerkenService.getSelectedBedrijfsstrategien(this.entiteitnummer);
        this.externeOmgevingKenmerken$ = this.kenmerkenService.allExterneOmgevingKenmerken();
        this.selectedExterneOmgeving$ = this.kenmerkenService.getSelectedExterneOmgeving(this.entiteitnummer);


        this.kenmerkenService.getSelectedGovernanceStructuurKenmerken(this.entiteitnummer)
          .subscribe(kenmerken => {
            this.selectedGovernanceStructuurKenmerken = kenmerken
          })

        this.kenmerkenService.allGovernanceStructuurKenmerken()
          .subscribe(kenmerken => {
            this.allGovernanceStructuurKenmerken = kenmerken
          })

        this.kenmerkenService.getSelectedRisicomanagementKenmerken(this.entiteitnummer)
          .subscribe(kenmerken => {
            this.selectedRisicomanagementKenmerken = kenmerken
          })

        this.kenmerkenService.allRisicomanagementKenmerken()
          .subscribe(kenmerken => {
            this.risicomanagementKenmerken = kenmerken
          })
      }
    });
  }

  saveBedrijfsstrategienSelections(selected: BedrijfsstrategieKenmerk[]) {
    this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.BS, selected).subscribe();
  }

  saveEexterneOmgevingSelections(selected: ExterneOmgevingKenmerk[]) {
    this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.EO, selected).subscribe();
  }

  onChangeGovernanceStructuur(event: any, governanceStructuurKenmerk: GovernanceStructuurKenmerk) {
    if (!this.selectedGovernanceStructuurKenmerken) {
      return;
    }
    if (event.checked) {
      this.selectedGovernanceStructuurKenmerken.push(governanceStructuurKenmerk);
      this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.GS, this.selectedGovernanceStructuurKenmerken).subscribe();
    } else {
      const index = this.selectedGovernanceStructuurKenmerken.map(kenmerk=>kenmerk.id).indexOf(governanceStructuurKenmerk.id);
      if (index > -1) {
        this.selectedGovernanceStructuurKenmerken.splice(index, 1);
        this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.GS, this.selectedGovernanceStructuurKenmerken).subscribe();
      }
    }
  }

  isGovernanceStructuurKenmerkenChecked(governanceStructuurKenmerk: GovernanceStructuurKenmerk): boolean {
    return this.selectedGovernanceStructuurKenmerken === undefined ? false:
      this.selectedGovernanceStructuurKenmerken.map(kenmerk=>kenmerk.id).indexOf(governanceStructuurKenmerk.id) > -1;
  }

  onChangeRisicomanagement(event: any, risicomanagementKenmerk: RisicomanagementKenmerken) {
    if (!this.selectedRisicomanagementKenmerken) {
      return;
    }
    if (event.checked) {
      this.selectedRisicomanagementKenmerken.push(risicomanagementKenmerk);
      this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.RM, this.selectedRisicomanagementKenmerken).subscribe();
    } else {
      const index = this.selectedRisicomanagementKenmerken.map(kenmerk=>kenmerk.id).indexOf(risicomanagementKenmerk.id);
      if (index > -1) {
        this.selectedRisicomanagementKenmerken.splice(index, 1);
        this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.RM, this.selectedRisicomanagementKenmerken).subscribe();
      }
    }
  }

  isRisicomanagementKenmerkenChecked(risicomanagementKenmerken: RisicomanagementKenmerken): boolean {
    return this.selectedRisicomanagementKenmerken === undefined ? false:
      this.selectedRisicomanagementKenmerken.map(kenmerk=>kenmerk.id).indexOf(risicomanagementKenmerken.id) > -1;
  }

}
