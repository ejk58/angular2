import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiselectToolComponent } from './multiselect-tool.component';

describe('MultiselectToolComponent', () => {
  let component: MultiselectToolComponent;
  let fixture: ComponentFixture<MultiselectToolComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultiselectToolComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiselectToolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
