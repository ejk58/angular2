import {Component, EventEmitter, Input, Output} from '@angular/core';
import {EntiteitKenmerk} from "../../../interfaces/EntiteitKenmerk";

@Component({
  selector: 'app-multiselect-tool',
  templateUrl: './multiselect-tool.component.html',
  styleUrls: ['./multiselect-tool.component.scss']
})
export class MultiselectToolComponent {

  @Input()
  entiteitKenmerken: EntiteitKenmerk[];
  @Input()
  selectedEntiteitKenmerken: EntiteitKenmerk[];
  @Output()
  onSave = new EventEmitter<EntiteitKenmerk[]>();

  getSelections() {
    this.onSave.emit(this.selectedEntiteitKenmerken);
  }
}
