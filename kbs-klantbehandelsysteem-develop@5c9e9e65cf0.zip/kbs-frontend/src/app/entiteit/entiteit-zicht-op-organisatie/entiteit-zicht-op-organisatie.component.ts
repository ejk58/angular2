import {Component, OnInit} from '@angular/core';
import {Observable} from "rxjs";
import {Entiteit} from "../shared/entiteit";
import {EntiteitService} from "../../services/entiteit.service";
@Component({
  selector: 'app-entiteit-zicht-op-organisatie',
  templateUrl: './entiteit-zicht-op-organisatie.component.html',
  styleUrls: ['./entiteit-zicht-op-organisatie.component.scss']
})
export class EntiteitZichtOpOrganisatieComponent implements OnInit {

  selectedTabNumber = 0;
  entiteit$: Observable<Entiteit>;

  constructor(private readonly entiteitService: EntiteitService) {
  }

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteit$ = this.entiteitService.getEntiteit(nr);
    });
  }

  isTabSelected(tabNumber: number) {
    return tabNumber === this.selectedTabNumber;
  }

  selectTab(e: any) {
    this.selectedTabNumber = e.index
  }
}
