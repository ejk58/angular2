import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooAardvanorganisatieComponent } from './zoo-aardvanorganisatie.component';

describe('ZooAardvanorganisatieComponent', () => {
  let component: ZooAardvanorganisatieComponent;
  let fixture: ComponentFixture<ZooAardvanorganisatieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooAardvanorganisatieComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooAardvanorganisatieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
