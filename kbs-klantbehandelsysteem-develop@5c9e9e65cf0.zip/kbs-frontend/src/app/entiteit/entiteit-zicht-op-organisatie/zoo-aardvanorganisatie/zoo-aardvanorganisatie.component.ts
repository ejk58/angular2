import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {HelptextIds} from '../../../shared/helptext-ids';
import {Observable, of} from 'rxjs';
import {Entiteit} from '../../shared/entiteit';
import {EntiteitService} from '../../../services/entiteit.service';
import {Helptext} from "../../../componenten-generiek/helptext/helptext";
import {HelptextService} from "../../../services/helptext.service";
import {ZooEntiteitMiddel} from "../../../interfaces/ZooEntiteitMiddel";
import {ZooEntiteitAandachtsGebied} from "../../../interfaces/ZooEntiteitAandachtsGebied";
import {KenmerkenService} from "../../../services/kenmerken.service";
import {ZooSubEntiteit} from "../../../interfaces/ZooSubEntiteit";
import {FilterService, LazyLoadEvent, SelectItemGroup} from 'primeng/api';
import {KenmerkType} from "../../../services/kenmerkType";
import {map} from "rxjs/operators";
import {Table} from "primeng/table";
import {DateNLPipe} from "../../../pipes/date-nl.pipe";
import {EntiteitConvenantindicatie} from '../../../interfaces/entiteit-convenantindicatie';

@Component({
  selector: 'app-zoo-aardvanorganisatie',
  templateUrl: './zoo-aardvanorganisatie.component.html',
  styleUrls: ['./zoo-aardvanorganisatie.component.scss']
})
export class ZooAardvanorganisatieComponent implements OnInit {

  HelptextIds = HelptextIds;

  asZooSubEntiteit = (z: ZooSubEntiteit) => z;

  entiteit$: Observable<Entiteit>;

  titelToelichting = 'De organisatie op één A4 toelichting';
  textToelichtingTitleZooTooltip$: Observable<Helptext>;
  textToelichtingSectorTooltip$: Observable<Helptext>;
  textToelichtingBrancheTooltip$: Observable<Helptext>;
  textToelichtingAandachtsgebiedenTooltip$: Observable<Helptext>;
  textToelichtingMiddelenTooltip$: Observable<Helptext>;

  sectoren: SelectItemGroup[] = [
    {
      label: 'Profit', items: [
        {value: 1, label: 'Primaire sector: (grondstoffen) landbouw, visserij, delfstofwinning'},
        {value: 2, label: 'Secundaire sector: grondstofverwerkende industrie en maakindustrie'},
        {value: 3, label: 'Tertiaire sector: diensten, handel en verkeer'}
      ]
    },
    {
      label: 'Non-profit', items: [
        {
          value: 4,
          label: 'Quartaire sector: maatschappelijke organisaties, infrastructuur, milieudienstverlening en volkshuisvesting'
        }
      ]
    }
  ];
  initiallySelectedSector: number;
  selectedSector: number;

  allSubEntiteiten$: Observable<ZooSubEntiteit[]>;
  displayedZooSubEntiteiten: ZooSubEntiteit[];
  previouslySelectedZooSubEntiteiten$: Observable<ZooSubEntiteit[]>;
  currentlySelectedZooSubEntiteiten: ZooSubEntiteit[] = [];
  initiallySelectedZooSubEntiteiten: ZooSubEntiteit[] = [];
  subEntiteitenSelectionStarted = false;

  middelen$: Observable<ZooEntiteitMiddel[]>;
  selectedMiddelen$: Observable<ZooEntiteitMiddel[]>;
  aandachtsgebieden$: Observable<ZooEntiteitAandachtsGebied[]>;
  selectedAandachtsgebieden$: Observable<ZooEntiteitAandachtsGebied[]>;

  entiteitnummer: number;
  showPaginator = true;
  numberOfRowsToDisplayPerPage: number;
  numberOfRowsToDisplayPerPageOptions = [10, 25, 50, 100];
  totalRecords: number = 0;
  filterFields: string[] =['bsnRsin','soort', 'naam', 'plaats','startDatum', 'eindDatum', 'brancheCode'];
  loading: boolean;
  lazyLoadedSubEntiteiten: ZooSubEntiteit[];
  indexOfFirstDisplayedSubEntiteit = 0;
  lastLazyLoadEvent: LazyLoadEvent;
  @ViewChild(Table)
  table: Table;
  dateRegex = new RegExp('[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}', 'g');
  convenantindicatie$: Observable<EntiteitConvenantindicatie>;

  constructor(private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService,
              private readonly helptextService: HelptextService,
              private filterService: FilterService,
              @Inject(DateNLPipe) private dateNLPipe: DateNLPipe) {
    //created a customized filterMatchMode to also support search filters on the dates with 'dateNL' pipe
    this.filterService.register('filterMatchModeWithNLDateSupport', (value: any, filter: any, filterLocale?: any): boolean => {
      if (this.dateRegex.test(value) === true) {
        return this.filterService.filters.contains(this.dateNLPipe.transform(value), filter, filterLocale);
      }
      return this.filterService.filters.contains(value, filter, filterLocale);
    })
  }

  ngOnInit(): void {
    this.middelen$ = this.kenmerkenService.getZooEntiteitMiddelen();
    this.aandachtsgebieden$ = this.kenmerkenService.getZooEAandachtsGebieden();
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitnummer = nr;
      this.selectedMiddelen$ = this.kenmerkenService.getSelectedMiddelen(this.entiteitnummer);
      this.selectedAandachtsgebieden$ = this.kenmerkenService.getSelectedAandachtsGebieden(this.entiteitnummer)
        .pipe(map(arr => arr.map(aandachtsgebied => {
          if (aandachtsgebied.values !== "true") {
            aandachtsgebied.values = "false"
          }
          return aandachtsgebied;
        })));
      this.allSubEntiteiten$ = this.entiteitService.getZooSubEntiteiten(this.entiteitnummer)
      this.convenantindicatie$ = this.entiteitService.getConvenantindicatie(this.entiteitnummer);
      this.previouslySelectedZooSubEntiteiten$ = this.entiteitService.getSelectedSubEntiteiten(this.entiteitnummer);
      this.previouslySelectedZooSubEntiteiten$.subscribe(data => {
        this.initiallySelectedZooSubEntiteiten = data;
        this.currentlySelectedZooSubEntiteiten = [...this.initiallySelectedZooSubEntiteiten];
      });
      this.displayPreviouslySelectedZooSubEntiteiten();
      this.loadSector(nr);
    });
    this.textToelichtingTitleZooTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.ZOO_ORGANISATIEAARD_TITLE);
    this.textToelichtingSectorTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.ORGANISATIEAARD_SECTOR_TOOLTIP);
    this.textToelichtingBrancheTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.ORGANISATIEAARD_BRANCHE_TOOLTIP);
    this.textToelichtingAandachtsgebiedenTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.ORGANISATIEAARD_AANDACHTSGEBIEDEN_TOOLTIP);
    this.textToelichtingMiddelenTooltip$ = this.helptextService.getHelptextTooltip(HelptextIds.ORGANISATIEAARD_MIDDELEN_TOOLTIP);
    if (!this.numberOfRowsToDisplayPerPage) {
      this.numberOfRowsToDisplayPerPage = this.numberOfRowsToDisplayPerPageOptions[0];
    }
  }

  saveAandachtsGebiedenSelections(selectedAandachtsgebieden: ZooEntiteitAandachtsGebied[]) {
    this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.AG, selectedAandachtsgebieden).subscribe();
  }

  saveMiddelenSelections(selectedMiddelen: ZooEntiteitMiddel[]) {
    this.kenmerkenService.saveSelections(this.entiteitnummer, KenmerkType.MID, selectedMiddelen).subscribe();
  }

  hasSelectedSectorChanged() {
    return this.selectedSector !== this.initiallySelectedSector;
  }

  saveSector() {
    this.kenmerkenService.setZooAardSector(this.entiteitnummer, this.selectedSector)
      .subscribe(() => this.loadSector(this.entiteitnummer));
  }

  private loadSector(bsnRsin: number) {
    this.kenmerkenService.getZooAardSector(bsnRsin).subscribe(sector => {
      this.selectedSector = sector;
      this.initiallySelectedSector = this.selectedSector;
    });
  }

  saveSubEntiteitSelections() {
    this.entiteitService.saveSubEntiteitSelections(this.entiteitnummer, this.currentlySelectedZooSubEntiteiten).subscribe();
    this.initiallySelectedZooSubEntiteiten = [...this.currentlySelectedZooSubEntiteiten];
    this.previouslySelectedZooSubEntiteiten$ = of([...this.currentlySelectedZooSubEntiteiten]);
    this.displayPreviouslySelectedZooSubEntiteiten();
    this.subEntiteitenSelectionStarted = false;
  }

  startSubEntiteitenSelection() {
    this.subEntiteitenSelectionStarted = true;
    this.resetSubEntiteitenSelections();
  }

  displayPreviouslySelectedZooSubEntiteiten() {
    this.loading = true;
    this.previouslySelectedZooSubEntiteiten$.subscribe(selected => {
      if (selected.length > 0) {
        this.displayedZooSubEntiteiten = selected;
        if (this.lastLazyLoadEvent) {
          if (this.lastLazyLoadEvent.first > this.displayedZooSubEntiteiten.length) {
            this.lastLazyLoadEvent.first = 0;
          }
          this.lazyLoadZooSubEntiteiten(this.lastLazyLoadEvent);
        } else {
          this.lazyLoadZooSubEntiteiten({
            rows: this.numberOfRowsToDisplayPerPage,
            first: 0,
          });
        }
      } else {
        this.resetSubEntiteitenSelections();
      }
    });
  }

  resetSubEntiteitenSelections() {
    this.loading = true;
    this.displayedZooSubEntiteiten = undefined;
    this.allSubEntiteiten$.subscribe(allSubEntiteiten => { // TODO Proper error handling
      this.displayedZooSubEntiteiten = allSubEntiteiten;
      this.loading = false;
    });
  }

  cancelSelection() {
    this.subEntiteitenSelectionStarted = false;
    this.displayPreviouslySelectedZooSubEntiteiten();
    this.currentlySelectedZooSubEntiteiten = [...this.initiallySelectedZooSubEntiteiten];
  }

  onSearchSubEntiteiten(event) {
    this.table.filterGlobal(event.target.value, 'filterMatchModeWithNLDateSupport');
  }

  lazyLoadZooSubEntiteiten(event: LazyLoadEvent) {
    this.lastLazyLoadEvent = event;
    //Using setTimeout(..., 0) as a work-around for a known primeng bug:https://github.com/primefaces/primeng/issues/3300#issuecomment-380979429
    setTimeout(() => {
      if (this.displayedZooSubEntiteiten) {
        //Using primeng filterService to force global filters in (onLazyLoad)
        const filtered: ZooSubEntiteit[] = this.filterService.filter(this.displayedZooSubEntiteiten,
          this.filterFields, event.globalFilter, 'filterMatchModeWithNLDateSupport');

        this.lazyLoadedSubEntiteiten = filtered.slice(event.first, (event.first + event.rows));
        this.totalRecords = filtered.length;
        this.indexOfFirstDisplayedSubEntiteit = event.first;
        this.loading = false;
      }
    }, 0);
  }
}
