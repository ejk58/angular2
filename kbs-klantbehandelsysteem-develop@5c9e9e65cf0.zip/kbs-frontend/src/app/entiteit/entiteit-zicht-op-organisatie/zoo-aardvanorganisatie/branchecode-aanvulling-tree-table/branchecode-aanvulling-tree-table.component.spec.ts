import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchecodeAanvullingTreeTableComponent } from './branchecode-aanvulling-tree-table.component';

describe('BranchecodeAanvullingTreeTableComponent', () => {
  let component: BranchecodeAanvullingTreeTableComponent;
  let fixture: ComponentFixture<BranchecodeAanvullingTreeTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchecodeAanvullingTreeTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchecodeAanvullingTreeTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
