import {TreeNode} from 'primeng/api';
import {ZooEntiteitBranchecodeAanvulling} from "../../../../interfaces/ZooEntiteitBranchecodeAanvulling";

export class NodeService {

  static getNestedChildren(kenmerken: ZooEntiteitBranchecodeAanvulling[], parent?: number): TreeNode[] {
    let nodes: TreeNode[] = [];
    for (const kenmerk of kenmerken) {
      if (kenmerk.kenmerkParentId == parent) {
        const children = this.getNestedChildren(kenmerken, kenmerk.id);
        const node: TreeNode = {
          data: {id: kenmerk.id, groep: kenmerk.groep, kenmerk: kenmerk.kenmerk, kenmerkParentId: kenmerk.kenmerkParentId},
          children
        };
        nodes.push(node);
      }
    }
    return nodes;
  }

  static filterSelectedChildren(treeNodes: TreeNode[], selectedKenmerken: ZooEntiteitBranchecodeAanvulling[]): TreeNode[] {
    const selectedKenmerkIds: number[] = selectedKenmerken.map(child => { return child.id });
    return this.filterSelectedKenmerkIds(treeNodes, selectedKenmerkIds);
  }

  static filterSelectedKenmerkIds(treeNodes: TreeNode[], selectedKenmerkIds: number[]): TreeNode[] {
    let nodes: TreeNode[] = [];
    for (const treeNode of treeNodes) {
      const isSelected: boolean = selectedKenmerkIds.includes(treeNode.data.id);
      if (isSelected) {
        nodes.push(treeNode);
      }
      const selectedChildren = this.filterSelectedKenmerkIds(treeNode.children, selectedKenmerkIds);
      if (selectedChildren.length) {
        treeNode.partialSelected = true;
      }
      nodes.push(...selectedChildren);
    }
    return nodes;
  }

  static filterChildNodes(treenodes?: TreeNode[]): TreeNode[] {
    return treenodes?.filter(selection => { return selection.children.length === 0; })
  }

  static mapToZooEntiteitBranchecodeAanvulling(treeNode: TreeNode){
    return {
      id: treeNode.data.id,
      groep: treeNode.data.groep,
      kenmerk: treeNode.data.kenmerk,
      kenmerkParentId: treeNode.data.kenmerkParentId
    } as ZooEntiteitBranchecodeAanvulling;
  }
}
