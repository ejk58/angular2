import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {TreeNode} from 'primeng/api';
import {NodeService} from './node.service';
import {TreeTable} from 'primeng/treetable';
import {ZooEntiteitBranchecodeAanvulling} from "../../../../interfaces/ZooEntiteitBranchecodeAanvulling";
import {MatDialogRef} from "@angular/material/dialog";
import {KenmerkenPopupComponent} from "../../../../componenten-generiek/kenmerken-popup/kenmerken-popup.component";

@Component({
  selector: 'app-branchecode-aanvulling-tree-table',
  templateUrl: './branchecode-aanvulling-tree-table.component.html',
  styleUrls: ['./branchecode-aanvulling-tree-table.component.scss']
})
export class BranchecodeAanvullingTreeTableComponent implements OnInit, OnChanges {

  allTreeNodes: TreeNode[];
  selectedTreeNodes: TreeNode[];
  cols: { field: string; header: string }[] = [
    {field: 'kenmerk', header: 'Kenmerk'}
  ];

  showPaginator = true;
  numberOfRowsToDisplayPerPage: number = 10;
  searchFilters: string[] = this.cols.map(c => c.field);

  @Input()
  selectedChildKenmerken: ZooEntiteitBranchecodeAanvulling[];
  @Input()
  allKenmerken: ZooEntiteitBranchecodeAanvulling[];
  @Input()
  subEntiteitBsn: number;
  @Output()
  onSelect = new EventEmitter<ZooEntiteitBranchecodeAanvulling[]>();
  @Output()
  onCancel = new EventEmitter<any>();

  constructor(private readonly dialogRef: MatDialogRef<KenmerkenPopupComponent>) {
  }

  ngOnInit() {
  }

  //Used the ngOnChanges to keep updating the treetable nodes every time there is a selection change.
  ngOnChanges(changes: SimpleChanges): void {
    this.allTreeNodes = NodeService.getNestedChildren(this.allKenmerken);
    this.selectedTreeNodes = NodeService.filterSelectedChildren(this.allTreeNodes, this.selectedChildKenmerken);
  }

  emitSelectionsToSave() {
    const selectedZooEntiteitBranchcodeAanvullingen = NodeService.filterChildNodes(this.selectedTreeNodes)
      .map(NodeService.mapToZooEntiteitBranchecodeAanvulling);
    this.onSelect.emit(selectedZooEntiteitBranchcodeAanvullingen);
  }

  closePopup() {
    this.onCancel.emit(this.dialogRef)
  }

  //on search expand the treetable till the searched value and then on clear search input return to the default unxapanded list.
  onSearchKenmerken(tt: TreeTable, event, branchecodeAanvullingTree: TreeNode[]) {
    tt.filterGlobal(event.target.value, 'contains')
    branchecodeAanvullingTree?.forEach(tree => {
      const expanded: boolean = event.target.value?.length;
      this.expandRecursively(tree, expanded)
    });
  }

  expandRecursively(treeNode: TreeNode, expanded: boolean) {
    treeNode.expanded = expanded;
    if (treeNode.children) {
      for (const child of treeNode.children) {
        this.expandRecursively(child, expanded);
      }
    }
  }
}
