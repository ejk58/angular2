import {ComponentFixture, TestBed} from '@angular/core/testing';

import {BranchecodeAanvullingComponent} from './branchecode-aanvulling.component';

describe('BranchecodeAanvullingComponent', () => {
  let component: BranchecodeAanvullingComponent;
  let fixture: ComponentFixture<BranchecodeAanvullingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchecodeAanvullingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchecodeAanvullingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
