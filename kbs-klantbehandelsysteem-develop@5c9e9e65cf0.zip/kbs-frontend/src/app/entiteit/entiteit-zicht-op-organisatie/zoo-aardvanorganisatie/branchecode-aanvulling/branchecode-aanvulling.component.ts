import {Component, Input, OnInit} from '@angular/core';
import {MatDialog} from "@angular/material/dialog";
import {KenmerkenPopupComponent} from "../../../../componenten-generiek/kenmerken-popup/kenmerken-popup.component";
import {ZooEntiteitBranchecodeAanvulling} from "../../../../interfaces/ZooEntiteitBranchecodeAanvulling";
import {KenmerkenService} from "../../../../services/kenmerken.service";

@Component({
  selector: 'app-branchecode-aanvulling',
  templateUrl: './branchecode-aanvulling.component.html',
  styleUrls: ['./branchecode-aanvulling.component.scss']
})
export class BranchecodeAanvullingComponent implements OnInit{

  @Input() subEntiteitBsn: number;
  selected: ZooEntiteitBranchecodeAanvulling[];
  loading = false;

  constructor(private readonly dialog: MatDialog, private readonly kenmerkenService: KenmerkenService) {
  }

  ngOnInit() {
    this.getAanvullingen();
  }

  getAanvullingen(){
    this.loading = true;
    this.kenmerkenService.getZooBranchecodeAanvullingBy(this.subEntiteitBsn).subscribe((data) => {
      this.selected = data;
      this.loading = false;
    });
  }

  showKenmerkenPopup(){
    const dialogRef = this.dialog.open(KenmerkenPopupComponent, {
      data: [this.subEntiteitBsn],
      width: '1000px',
      disableClose: true,
      position: {
        top: '10vh',
        left: '30vw'
      },
    });
    dialogRef.afterClosed().subscribe(() =>{
      this.getAanvullingen();
    });
  }

  getTooltipList() : string[] {
    const kenmerk: string[] = [];
    this.selected?.forEach(k => kenmerk.push(k.kenmerk));
    kenmerk.sort((a,b) => a.localeCompare(b));
    return kenmerk;
  }
}
