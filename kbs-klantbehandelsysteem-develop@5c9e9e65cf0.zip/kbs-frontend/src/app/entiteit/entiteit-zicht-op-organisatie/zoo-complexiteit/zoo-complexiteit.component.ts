import {Component, OnInit} from '@angular/core';
import {EntiteitService} from "../../../services/entiteit.service";
import {Observable} from "rxjs";
import {HelptextIds} from "../../../shared/helptext-ids";
import {KenmerkenService} from "../../../services/kenmerken.service";
import {KenmerkType} from "../../../services/kenmerkType";
import {ComplexiteitKenmerk} from "../../../interfaces/complexiteit-kenmerk";

@Component({
  selector: 'app-zoo-complexiteit',
  templateUrl: './zoo-complexiteit.component.html',
  styleUrls: ['./zoo-complexiteit.component.scss']
})
export class ZooComplexiteitComponent implements OnInit {

  HelptextIds = HelptextIds;

  pageTitle = 'Complexiteit van de organisatie';
  complexiteitKenmerken$: Observable<ComplexiteitKenmerk[]>;
  selectedComplexiteitKenmerken$: Observable<ComplexiteitKenmerk[]>;
  entiteitNummer: number;
  textToelichting = 'Toelichting complexiteit';

  constructor(private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService) {
  }

  ngOnInit(): void {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitNummer = nr;

      this.complexiteitKenmerken$ = this.kenmerkenService.allComplexiteitKenmerken();
      this.selectedComplexiteitKenmerken$ = this.kenmerkenService.getSelectedComplexiteitKenmerken(this.entiteitNummer);
    });
  }

  saveComplexiteitSelections(selected: ComplexiteitKenmerk[]) {
    this.kenmerkenService.saveSelections(this.entiteitNummer, KenmerkType.CK, selected).subscribe();
  }

}
