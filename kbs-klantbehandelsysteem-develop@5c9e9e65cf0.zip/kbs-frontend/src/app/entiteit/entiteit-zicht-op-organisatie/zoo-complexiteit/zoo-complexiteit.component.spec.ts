import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooComplexiteitComponent } from './zoo-complexiteit.component';

describe('ZooComplexiteitComponent', () => {
  let component: ZooComplexiteitComponent;
  let fixture: ComponentFixture<ZooComplexiteitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooComplexiteitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooComplexiteitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
