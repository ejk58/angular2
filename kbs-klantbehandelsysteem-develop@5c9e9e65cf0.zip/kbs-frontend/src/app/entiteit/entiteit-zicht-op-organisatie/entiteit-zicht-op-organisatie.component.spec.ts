import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitZichtOpOrganisatieComponent } from './entiteit-zicht-op-organisatie.component';

describe('EntiteitZichtOpOrganisatieComponent', () => {
  let component: EntiteitZichtOpOrganisatieComponent;
  let fixture: ComponentFixture<EntiteitZichtOpOrganisatieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitZichtOpOrganisatieComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitZichtOpOrganisatieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
