import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooHelptekstComponent } from './zoo-helptekst.component';

describe('ZooHelptekstComponent', () => {
  let component: ZooHelptekstComponent;
  let fixture: ComponentFixture<ZooHelptekstComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooHelptekstComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooHelptekstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
