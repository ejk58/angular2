import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zoo-helptekst',
  templateUrl: './zoo-helptekst.component.html',
  styleUrls: ['./zoo-helptekst.component.scss']
})
export class ZooHelptekstComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
