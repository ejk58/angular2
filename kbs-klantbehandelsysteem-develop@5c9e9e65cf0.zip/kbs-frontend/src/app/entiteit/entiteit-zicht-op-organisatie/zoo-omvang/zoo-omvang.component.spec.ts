import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZooOmvangComponent } from './zoo-omvang.component';

describe('ZooOmvangComponent', () => {
  let component: ZooOmvangComponent;
  let fixture: ComponentFixture<ZooOmvangComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZooOmvangComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZooOmvangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
