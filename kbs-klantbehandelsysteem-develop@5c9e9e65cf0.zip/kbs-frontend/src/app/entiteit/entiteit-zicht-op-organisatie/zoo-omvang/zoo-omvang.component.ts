import {Component, OnInit} from '@angular/core';
import {EntiteitService} from '../../../services/entiteit.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {forkJoin} from 'rxjs';
import {Helptext} from '../../../componenten-generiek/helptext/helptext';
import {HelptextIds} from '../../../shared/helptext-ids';
import {HelptextService} from '../../../services/helptext.service';
import {ZooEntiteitOmvang} from '../../../interfaces/zoo-entiteit-omvang';

@Component({
  selector: 'app-zoo-omvang',
  templateUrl: './zoo-omvang.component.html',
  styleUrls: ['./zoo-omvang.component.scss']
})
export class ZooOmvangComponent implements OnInit {

  asZooOmvang = (o: ZooEntiteitOmvang) => o;

  readonly pageTitle = 'Omvang van de organisatie';

  isLoading: boolean;
  isProcessingFormSubmission: boolean;
  omvangForm: FormGroup;
  lastUpdated: Date;
  lastUpdatedByUserId: string;

  toelichting: Helptext;

  constructor(private readonly formBuilder: FormBuilder,
              private readonly entiteitService: EntiteitService,
              private readonly helptextService: HelptextService) {
  }

  ngOnInit() {
    this.isLoading = true;
    this.isProcessingFormSubmission = true;
    this.initializeOmvangForm();
    this.loadOmvangData();
  }

  private initializeOmvangForm() {
    this.omvangForm = this.formBuilder.group({
      aantalBsnRsinsInEntiteit: [''],
      aantalBezwarenVerzoekenEnBeroepen: [''],
      aantalBuitenlandseDeelnemingen: [''],
      aantalVasteInrichtingen: [''],
      belastingschuld: [''],
      totalenPerJaarOb: [''],
      totaleVrijgesteldeOmzet: [''],
      totalenPerJaarLhAantalLoongerechtigden: [''],
      totalenPerJaarLhTotaalLoonsom: [''],
      totalenAanslagenPerJaarVpb: [''],
      totaalBetalingenJaarX: [''],
      totaalBetalingenJaarXMin1: [''],
      totaalBetalingenJaarXMin2: [''],
      wolbSom: ['']
    });
  }

  private loadOmvangData() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
        forkJoin([
          this.entiteitService.getZooEntiteitOmvang(nr),
          this.helptextService.getHelptextForEntiteit(HelptextIds.ORGANISATIEOMVANG_TOELICHTING, nr)
        ]).subscribe(this.obsNext, this.obsDone, this.obsDone);
    });
  }

  submitForm() {
    this.isProcessingFormSubmission = true;
    const omvangToSave: ZooEntiteitOmvang = this.omvangForm.value;

    this.entiteitService.getSearchEntiteitNummer((nr) => {
        forkJoin([
          this.entiteitService.saveOrUpdateZooEntiteitOmvang(nr, omvangToSave),
          this.helptextService.getHelptextForEntiteit(HelptextIds.ORGANISATIEOMVANG_TOELICHTING, nr)
        ]).subscribe(this.obsNext, this.obsDone, this.obsDone);
    });
  }

  private obsNext = ([o, h]: [ZooEntiteitOmvang, Helptext]) => {
    this.processOmvangResults(o);
    this.toelichting = h;
    this.obsDone();
  }

  private processOmvangResults(o: ZooEntiteitOmvang) {
    this.omvangForm.reset(o);
    this.omvangForm.markAsPristine();
    this.lastUpdated = o.lastUpdated;
    this.lastUpdatedByUserId = o.lastUpdatedByUserId;
  }

  private obsDone = () => {
    this.isProcessingFormSubmission = false;
    this.isLoading = false;
  }

  resetForm() {
    this.loadOmvangData();
  }

  isFormUnmodifiedOrInvalidOrSubmitting(): boolean {
    return this.omvangForm.pristine || this.omvangForm.invalid || this.isProcessingFormSubmission;
  }
}
