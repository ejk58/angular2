import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-concernstructuur',
  templateUrl: './concernstructuur.component.html',
  styleUrls: ['./concernstructuur.component.scss']
})
export class ConcernstructuurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
