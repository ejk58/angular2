import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConcernstructuurComponent } from './concernstructuur.component';

describe('ConcernstructuurComponent', () => {
  let component: ConcernstructuurComponent;
  let fixture: ComponentFixture<ConcernstructuurComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConcernstructuurComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConcernstructuurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
