export class ByteUtil {

  /**
   * Formats a number of bytes to a usable textual representation. E.g. 1048576 becomes '1 megabyte'.
   *
   * @param byteAmount The number of bytes to format.
   * @param decimals The number of decimals to round to.
   * @param long Whether to use long unit names ('kilobytes') or abbreviations ('KB').
   */
  static formatToHumanReadableString(byteAmount: number, decimals = 0, long = true): string {
    if (byteAmount == 0) {
      return `0 ${long ? 'bytes' : 'B'}`;
    }
    const k = 1024, // Use binary (IEC) units, aka powers of 1024, instead of Metric (SI) units, aka powers of 1000.
      i = Math.floor(Math.log(byteAmount) / Math.log(k)),
      units = long ? ['byte', 'kilobyte', 'megabyte', 'gigabyte', 'terabyte', 'petabyte', 'exabyte', 'zettabyte', 'yottabyte'] :
        ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
      result = parseFloat((byteAmount / Math.pow(k, i)).toFixed(decimals));
    return `${result} ${units[i]}${long && result !== 1 ? 's' : ''}`;
  }
}
