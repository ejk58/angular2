import {MenuItem} from 'iv-framework-lib';

export const initialMenuItems: Array<MenuItem> = [
  {
    text: 'Zoeken klant',
    route: 'authenticated/entiteit-zoeken',
    icon: 'fas fa-search'
  }
];

export const searchedEntityMenuItems: Array<MenuItem> = [
  {
    text: 'Raadplegen klant',
    route: 'authenticated/raadplegen-klant-gegevens',
    submenu: [
      {
        text: 'Algemene gegevens',
        route: 'authenticated/raadplegen-klant-gegevens/algemene-gegevens'
      },
      {
        text: 'Dashboard',
        route: 'authenticated/raadplegen-klant-gegevens/dashboard'
      },
      {
        text: 'Let\'s go',
        route: 'authenticated/raadplegen-klant-gegevens/lets-go'
      },
      {
        text: 'Logboek',
        route: 'authenticated/raadplegen-klant-gegevens/logboek'
      },
      {
        text: 'Klantdocumenten',
        route: 'authenticated/raadplegen-klant-gegevens/Klantdocumenten'
      }
      ]
  },
  {
    text: 'Zicht op organisatie',
    route: 'authenticated/zicht-op-organisatie',
    submenu: [
      {
        text: 'Bedrijfsactiviteiten',
        route: 'authenticated/zicht-op-organisatie/bedrijfsactiviteiten'
      },
      {
        text: 'Cijferbeoordeling',
        route: 'authenticated/cijferbeoordeling'
      },
      {
        text: 'Concernstructuur',
        route: 'authenticated/concernstructuur'
      }]
  }];

export const searchedEntityMenuItems1: Array<MenuItem> = [
  {
    text: 'Zicht op compliance',
    route: 'authenticated/zicht-op-compliance'
  },
  {
    text: 'Strategie',
    route: 'authenticated/strategie'
  },
  {
    text: 'Verantwoorden',
    route: 'authenticated/verantwoorden'
  },
  {
    text: 'Behandelplangegevens',
    route: 'authenticated/behandelplangegevens'
  }
];

