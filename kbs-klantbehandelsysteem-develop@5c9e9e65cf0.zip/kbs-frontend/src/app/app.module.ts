import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import localeNL from '@angular/common/locales/nl';
import {AppComponent} from './app.component';
import {CurrencyPipe, DatePipe, HashLocationStrategy, LocationStrategy, registerLocaleData} from '@angular/common';
import {AuthenticatedUserComponent} from './authenticated-user/authenticated-user.component';
import {RouterModule} from '@angular/router';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {UserService} from './services/user.service';
import {APP_ROUTES} from './app.routing';
import {DashboardComponent} from './dashboard/dashboard.component';
import {FeedbackApi, FrameworkModule, UserApi} from 'iv-framework-lib';
import {AuthGuard} from './services/auth-guard.service';
import {AuthInterceptor} from './services/auth-interceptor';
import {ZoekenEntiteitComponent} from './entiteiten/zoeken-entiteit/zoeken-entiteit.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {EntiteitListComponent} from './entiteiten/entiteit-list/entiteit-list.component';
import {BasisComponent} from './entiteit/entiteit-algemene-gegevens/basis/basis.component';
import {KenmerkenComponent} from './entiteit/entiteit-algemene-gegevens/kenmerken/kenmerken.component';
import {EntiteitenComponent} from './entiteiten/entiteiten.component';
import {FeedbackService} from './services/feedback.service';
import {BooleanStringPipe} from './pipes/boolean-string.pipe';
import {CurrencyNLPipe} from './pipes/currency-nl.pipe';
import {TabViewModule} from 'primeng/tabview';
import {CardModule} from 'primeng/card';
import {PanelModule} from 'primeng/panel';
import {SamenstellingComponent} from './entiteit/entiteit-algemene-gegevens/samenstelling/samenstelling.component';
import {EntiteitDashboardComponent} from './entiteit/entiteit-dashboard/entiteit-dashboard.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {TableModule} from 'primeng/table';
import {InputTextModule} from 'primeng/inputtext';
import {DividerModule} from 'primeng/divider';
import {FieldsetModule} from 'primeng/fieldset';
import {BadgeModule} from 'primeng/badge';
import {
  BehandelvoorstellenOpdrachtenComponent
} from './entiteit/entiteit-dashboard/behandelvoorstellen-opdrachten/behandelvoorstellen-opdrachten.component';
import {OverigekenmerkenComponent} from './entiteit/entiteit-dashboard/overigekenmerken/overigekenmerken.component';
import {InfoGraphicComponent} from './entiteit/entiteit-dashboard/info-graphic/info-graphic.component';
import {ChartModule} from 'primeng/chart';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {EntiteitZichtOpOrganisatieComponent} from './entiteit/entiteit-zicht-op-organisatie/entiteit-zicht-op-organisatie.component';
import {EntiteitZichtOpFiscaliteitComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/entiteit-zicht-op-fiscaliteit.component';
import {EntiteitZichtOpComplianceComponent} from './entiteit/entiteit-zicht-op-compliance/entiteit-zicht-op-compliance.component';
import {EntiteitStrategieComponent} from './entiteit/entiteit-strategie/entiteit-strategie.component';
import {EntiteitVerantwoordenComponent} from './entiteit/entiteit-verantwoorden/entiteit-verantwoorden.component';
import {EntiteitBehandelplangegevensComponent} from './entiteit/entiteit-behandelplangegevens/entiteit-behandelplangegevens.component';
import {QuillModule} from 'ngx-quill';
import {QUILL_CONFIG} from './quill.constants';
import {EntiteitAlgemeneGegevensComponent} from './entiteit/entiteit-algemene-gegevens/entiteit-algemene-gegevens.component';
import {
  ZooAardvanorganisatieComponent
} from './entiteit/entiteit-zicht-op-organisatie/zoo-aardvanorganisatie/zoo-aardvanorganisatie.component';
import {ZooKenmerkenComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-kenmerken/zoo-kenmerken.component';
import {ZooHelptekstComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-helptekst/zoo-helptekst.component';
import {ButtonModule} from 'primeng/button';
import {DropdownModule} from 'primeng/dropdown';
import {ZooOmvangComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-omvang/zoo-omvang.component';
import {ZooComplexiteitComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-complexiteit/zoo-complexiteit.component';
import {ZooTop100Component} from './entiteit/entiteit-zicht-op-organisatie/zoo-top100/zoo-top100.component';
import {
  ZooInenexterneKenmerkenComponent
} from './entiteit/entiteit-zicht-op-organisatie/zoo-inenexterne-kenmerken/zoo-inenexterne-kenmerken.component';
import {HelptextComponent} from './componenten-generiek/helptext/helptext.component';
import {InfoPopComponent} from './componenten-generiek/info-pop/info-pop.component';
import {PrograssspinnerComponent} from './componenten-generiek/prograssspinner/prograssspinner.component';
import {TooltipModule} from 'primeng/tooltip';
import {MatDialogModule} from '@angular/material/dialog';
import {MatButtonModule} from '@angular/material/button';
import {TextPopEditorComponent} from './componenten-generiek/text-pop-editor/text-pop-editor.component';
import {InputCurrencyComponent} from './componenten-generiek/input-currency/input-currency.component';
import {MultiSelectModule} from 'primeng/multiselect';
import {InputNumberComponent} from './componenten-generiek/input-number/input-number.component';
import {InputNumberModule} from 'primeng/inputnumber';
import {TooltipEditorComponent} from './componenten-generiek/tooltip-editor/tooltip-editor.component';
import {MessagesModule} from 'primeng/messages';
import {ConfirmationService, MessageService} from 'primeng/api';
import {MatTooltipModule} from '@angular/material/tooltip';
import {BedrijfsactiviteitenComponent} from './entiteit/bedrijfsactiviteiten/bedrijfsactiviteiten.component';
import {CijferbeoordelingComponent} from './entiteit/cijferbeoordeling/cijferbeoordeling.component';
import {ConcernstructuurComponent} from './entiteit/concernstructuur/concernstructuur.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MultiselectToolComponent} from './entiteit/entiteit-zicht-op-organisatie/multiselect-tool/multiselect-tool.component';
import {CheckboxModule} from 'primeng/checkbox';
import {MultiselectWithTableComponent} from './componenten-generiek/multiselect-with-table/multiselect-with-table.component';
import {DateNLPipe} from './pipes/date-nl.pipe';
import {FieldContainerComponent} from './componenten-generiek/field-container/field-container.component';
import {ZooCbOrganisatieomvangComponent} from './entiteit/cijferbeoordeling/zoo-cb-organisatieomvang/zoo-cb-organisatieomvang.component';
import {ZooCbVpbComponent} from './entiteit/cijferbeoordeling/zoo-cb-vpb/zoo-cb-vpb.component';
import {ZooCbOmzetbelastingComponent} from './entiteit/cijferbeoordeling/zoo-cb-omzetbelasting/zoo-cb-omzetbelasting.component';
import {ZooCbLoonheffingComponent} from './entiteit/cijferbeoordeling/zoo-cb-loonheffing/zoo-cb-loonheffing.component';
import {ZooCbInkomstenbelastingComponent} from './entiteit/cijferbeoordeling/zoo-cb-inkomstenbelasting/zoo-cb-inkomstenbelasting.component';
import {ZooCbInvorderingComponent} from './entiteit/cijferbeoordeling/zoo-cb-invordering/zoo-cb-invordering.component';
import {ZooCbOverigemiddelenComponent} from './entiteit/cijferbeoordeling/zoo-cb-overigemiddelen/zoo-cb-overigemiddelen.component';
import {ZooCbTabpanelComponent} from './entiteit/cijferbeoordeling/tabpanel/zoo-cb-tabpanel.component';
import {TabviewComponent} from './componenten-generiek/tabview/tabview.component';
import {
  ZooCbVennootschapsbelastingComponent
} from './entiteit/cijferbeoordeling/zoo-cb-vennootschapsbelasting/zoo-cb-vennootschapsbelasting.component';
import {
  BranchecodeAanvullingComponent
} from './entiteit/entiteit-zicht-op-organisatie/zoo-aardvanorganisatie/branchecode-aanvulling/branchecode-aanvulling.component';
import {KenmerkenPopupComponent} from './componenten-generiek/kenmerken-popup/kenmerken-popup.component';
import {FieldTooltipHelpTextComponent} from './componenten-generiek/field-tooltip-help-text/field-tooltip-help-text.component';
import {
  MiddelspecifiekeKenmerkenComponent
} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifieke-kenmerken/middelspecifieke-kenmerken.component';
import {
  MiddelspecifiekeRiscosComponent
} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifieke-riscos/middelspecifieke-riscos.component';
import {MenuModule} from 'primeng/menu';
import {RippleModule} from 'primeng/ripple';
import {MiddelspecifiekTabsComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifiek-tabs/middelspecifiek-tabs.component';
import {ConfirmPopupModule} from 'primeng/confirmpopup';
import {KbsButtonComponent} from './componenten-generiek/kbs-button/kbs-button.component';
import {OperationsService} from './services/operations.service';
import {
  BranchecodeAanvullingTreeTableComponent
} from './entiteit/entiteit-zicht-op-organisatie/zoo-aardvanorganisatie/branchecode-aanvulling-tree-table/branchecode-aanvulling-tree-table.component';
import {TreeTableModule} from 'primeng/treetable';
import {EntiteitLetsGoComponent} from './entiteit/entiteit-lets-go/entiteit-lets-go.component';
import {EntiteitLogboekComponent} from './entiteit/entiteit-logboek/entiteit-logboek.component';
import {EntiteitKlantdocumentenComponent} from './entiteit/entiteit-klantdocumenten/entiteit-klantdocumenten.component';
import {EntiteitBehandelteamComponent} from './entiteit/entiteit-algemene-gegevens/entiteit-behandelteam/entiteit-behandelteam.component';
import {
  EntiteitContactgegevensComponent
} from './entiteit/entiteit-algemene-gegevens/entiteit-contactgegevens/entiteit-contactgegevens.component';

registerLocaleData(localeNL, 'nl');

@NgModule({
    declarations: [
        AppComponent,
        DashboardComponent,
        AuthenticatedUserComponent,
        ZoekenEntiteitComponent,
        EntiteitListComponent,
        BasisComponent,
        KenmerkenComponent,
        EntiteitenComponent,
        BooleanStringPipe,
        CurrencyNLPipe,
        DateNLPipe,
        SamenstellingComponent,
        EntiteitZichtOpOrganisatieComponent,
        EntiteitZichtOpFiscaliteitComponent,
        EntiteitZichtOpComplianceComponent,
        EntiteitStrategieComponent,
        EntiteitVerantwoordenComponent,
        EntiteitBehandelplangegevensComponent,
        EntiteitDashboardComponent,
        BehandelvoorstellenOpdrachtenComponent,
        OverigekenmerkenComponent,
        InfoGraphicComponent,
        EntiteitAlgemeneGegevensComponent,
        ZooHelptekstComponent,
        ZooAardvanorganisatieComponent,
        ZooKenmerkenComponent,
        ZooHelptekstComponent,
        ZooOmvangComponent,
        ZooComplexiteitComponent,
        ZooTop100Component,
        ZooInenexterneKenmerkenComponent,
        HelptextComponent,
        InfoPopComponent,
        PrograssspinnerComponent,
        TextPopEditorComponent,
        InputNumberComponent,
        InputCurrencyComponent,
        TooltipEditorComponent,
        BedrijfsactiviteitenComponent,
        CijferbeoordelingComponent,
        ConcernstructuurComponent,
        MultiselectToolComponent,
        MultiselectWithTableComponent,
        ZooCbOrganisatieomvangComponent,
        ZooCbVpbComponent,
        ZooCbOmzetbelastingComponent,
        ZooCbLoonheffingComponent,
        ZooCbInkomstenbelastingComponent,
        ZooCbInvorderingComponent,
        ZooCbOverigemiddelenComponent,
        ZooCbTabpanelComponent,
        TabviewComponent,
        FieldContainerComponent,
        ZooCbVennootschapsbelastingComponent,
        FieldTooltipHelpTextComponent,
        BranchecodeAanvullingComponent,
        KenmerkenPopupComponent,
        ZooCbVennootschapsbelastingComponent,
        MiddelspecifiekeKenmerkenComponent,
        MiddelspecifiekeRiscosComponent,
        MiddelspecifiekTabsComponent,
        KbsButtonComponent,
        BranchecodeAanvullingTreeTableComponent,
        EntiteitLetsGoComponent,
        EntiteitLogboekComponent,
        EntiteitKlantdocumentenComponent,
        EntiteitBehandelteamComponent,
        EntiteitContactgegevensComponent,
    ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FrameworkModule,
    RouterModule.forRoot(APP_ROUTES),
    HttpClientModule,
    FormsModule,
    TabViewModule,
    CardModule,
    PanelModule,
    TableModule,
    InputTextModule,
    DividerModule,
    FieldsetModule,
    BadgeModule,
    ChartModule,
    ProgressSpinnerModule,
    QuillModule.forRoot(QUILL_CONFIG),
    ButtonModule,
    DropdownModule,
    TooltipModule,
    MatDialogModule,
    MatButtonModule,
    ReactiveFormsModule,
    MultiSelectModule,
    InputNumberModule,
    MessagesModule,
    MatTooltipModule,
    MatCheckboxModule,
    CheckboxModule,
    MenuModule,
    RippleModule,
    ConfirmPopupModule,
    TreeTableModule,
  ],
  entryComponents: [
    TextPopEditorComponent,
  ],
  providers: [
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    UserService,
    {
      provide: UserApi,
      useExisting: UserService
    },
    FeedbackService,
    {
      provide: FeedbackApi,
      useExisting: FeedbackService
    },
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    CurrencyPipe,
    DatePipe,
    MessageService,
    DateNLPipe,
    ConfirmationService,
    OperationsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
