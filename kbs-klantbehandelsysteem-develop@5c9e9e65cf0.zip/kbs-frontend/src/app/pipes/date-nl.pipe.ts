import {Pipe, PipeTransform} from '@angular/core';
import {DatePipe} from '@angular/common';

/**
 * @see transform
 */
@Pipe({name: 'dateNL'})
export class DateNLPipe implements PipeTransform {

  private readonly FORMAT_DATE = 'dd-MM-yyyy';
  private readonly FORMAT_TIME = 'HH:mm:ss';
  private readonly FORMAT_DATETIME = `${this.FORMAT_DATE} ${this.FORMAT_TIME}`;

  constructor(private readonly pipe: DatePipe) {
  }

  transform(value: Date | string | number, format: 'date' | 'datetime' | 'time' = 'datetime'): string {
    let f = this.FORMAT_DATETIME;
    if (format === 'date') {
      f = this.FORMAT_DATE;
    } else if (format === 'time') {
      f = this.FORMAT_TIME;
    }
    return this.pipe.transform(value, f);
  }
}
