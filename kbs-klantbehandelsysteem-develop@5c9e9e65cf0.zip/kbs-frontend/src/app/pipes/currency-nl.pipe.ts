import {Pipe, PipeTransform} from '@angular/core';
import {CurrencyPipe} from '@angular/common';

/**
 * @see transform
 */
@Pipe({name: 'currencyNL'})
export class CurrencyNLPipe implements PipeTransform {

  constructor(private readonly pipe: CurrencyPipe) {
  }

  transform(value: string | number): string {
    return this.pipe.transform(value, 'EUR', 'symbol', '1.0-2', 'nl') ?? 'Onbekend';
  }
}
