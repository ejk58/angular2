// also exported from '@storybook/angular' if you can deal with breaking changes in 6.1
import {Meta, Story} from '@storybook/angular/types-6-0';
import {InputCurrencyComponent} from "../app/componenten-generiek/input-currency/input-currency.component";
import {CommonModule} from "@angular/common";
import {moduleMetadata} from "@storybook/angular";
import {InputNumberModule} from "primeng/inputnumber";
// More on default export: https://storybook.js.org/docs/angular/writing-stories/introduction#default-export
export default {
  title: 'KBS/Input',
  component: InputCurrencyComponent,
  decorators: [
    moduleMetadata({
      imports: [CommonModule, InputNumberModule]
    })
  ],
  // More on argTypes: https://storybook.js.org/docs/angular/api/argtypes
  // argTypes: {
  //   backgroundColor: { control: 'color' },
  // },
} as Meta;

// More on component templates: https://storybook.js.org/docs/angular/writing-stories/introduction#using-args
const Template: Story<InputCurrencyComponent> = (args: InputCurrencyComponent) => ({
  props: args,
  // template: `<div>
  //               <app-input-currency
  //                   [maxFractionDigits]="${nederlands.args.maxFractionDigits}"
  //                   [minFractionDigits]="${nederlands.args.minFractionDigits}"
  //               ></app-input-currency></div>`
});
// midden in de zin : "Dit toetsenbord is nu...."
// klapte de verbinding eruit!

export const currencyComponent = Template.bind({});
// More on args: https://storybook.js.org/docs/angular/writing-stories/args
currencyComponent.args = {
  ...currencyComponent.args,
  modelName: "totaleVrijgesteldeOmzet",
  formControlName: "totaleVrijgesteldeOmzet",
  label: "Totale vrijgestelde omzet",
  maxFractionDigits: 2,
  minFractionDigits: 2,
  placeholder: '2.2',
  value: '123,12'
};


