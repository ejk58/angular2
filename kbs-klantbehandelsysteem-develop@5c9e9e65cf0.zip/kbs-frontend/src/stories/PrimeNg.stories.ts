// also exported from '@storybook/angular' if you can deal with breaking changes in 6.1
import {Meta, Story} from '@storybook/angular/types-6-0';
import {ButtonModule} from 'primeng/button'
import {moduleMetadata} from '@storybook/angular';

export default {
  title: 'Kbs/Button',
  decorators: [
    moduleMetadata({
      imports: [ButtonModule]
    })
  ],
} as Meta;

export const MetIcon: Story = () => ({
  template: `<p-button icon="pi pi-pencil" label="Wijzigen"></p-button>`
});

export const Zoeken: Story = () => ({
  template: `<p-button  label="Zoeken"></p-button>`
});

export const Annuleren: Story = () => ({
  template: `<button pButton type="button" icon="pi pi-times" iconPos="left" style="width: 132px" label="Annuleren" tabindex="16"
          class="p-button-secondary" [disabled]="true" ></button>`
});

export const Secondary: Story = () => ({
  template: `<button pButton type="button" label="Volgorde wijzigen"
              class="btn btn btn-outline-primary"></button>`
});
