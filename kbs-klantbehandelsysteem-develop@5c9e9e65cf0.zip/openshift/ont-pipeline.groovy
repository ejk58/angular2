#!groovy

// Deze variabelen zijn project specifiek
def projectBase = "kbs"

// Deze variabelen alleen als je niet de standaard volgt
def backendName = "${projectBase}-backend"
def frontendName = "${projectBase}-frontend"
def openshiftDeployment = "ont"

// Deze variabelen in principe niet veranderen
def mvnCmd = "mvn -B -s openshift/maven-settings.xml"

pipeline {
    agent none
    options {
		skipDefaultCheckout()
	}
    stages {
        stage('Checkout') {
            agent {
                label "maven35-openjdk11"
            }
            steps {
                checkout scm
                // ITT Jeroen's versie, .git niet excluden omdat die voor de git-commit plugin nodig is
                stash(name: 'ws', includes: '**', excludes: '**/node_modules/**')
            }
        }
        stage('NPM') {
            agent {
                label "nodejs10"
            }
            steps {
                unstash 'ws'
                dir(frontendName) {
                    sh (script: "node -v" )
                    sh (script: "npm i" ) // Dit moet later nog npm ci worden
                    sh (script: "npm run build" )
                    // Onderstaand is afhankelijk van de "name": "frontend" in package.json
                    stash(name: 'frontend', includes: 'dist/frontend/**')
                }
            }
        }
        stage('Maven package') {
            agent {
                label "maven35-openjdk11"
            }
            steps {
                unstash 'ws'
                dir(frontendName) {
                    unstash 'frontend'
                }
                sh(script: "${mvnCmd} -pl ${backendName} package -Ps2i" )
                stash name: 'jar', includes: '**/target/**/*'
            }
//            post {
//                success {
//                    junit '**/surefire-reports/**/*.xml'
//                }
//            }
        }
//        stage('Maven sonar') {
//            agent {
//                label "maven35-openjdk11"
//            }
//            steps {
//                unstash 'ws'
//                sh(script: "${mvnCmd} sonar:sonar")
//            }
//		}
        stage('Create Image Builder') {
            when {
                expression {
                    openshift.withCluster() {
                        return !openshift.selector("bc", openshiftDeployment).exists()
                    }
                }
            }
            steps {
                script {
                    openshift.withCluster() {
                        openshift.newBuild("--name=${openshiftDeployment}", "-i=openjdk-11-rhel7", "--binary=true")
                    }
                }
            }
        }
        stage('Build Image') {
            agent {
                label "maven35-openjdk11"
            }
            steps {
                script {
                    unstash 'jar'
                    openshift.withCluster() {
                        openshift.selector("bc", openshiftDeployment).startBuild("--from-file=${backendName}/target/${backendName}.jar", "--wait=true")
                    }
                }
            }
        }
        stage('Create deployment in O') {
            when {
                expression {
                    openshift.withCluster() {
                        return !openshift.selector('dc', openshiftDeployment).exists()
                    }
                }
            }
            agent {
                label "maven35-openjdk11"
            }
            steps {
                script {
                    unstash 'ws'
                    openshift.withCluster() {
                        // ruim eerst de objecten als die zijn blijven staan
                        if (openshift.selector('dc', openshiftDeployment).exists()) {
                            openshift.selector('dc', openshiftDeployment).delete()
                        }
                        if (openshift.selector('svc', openshiftDeployment).exists()) {
                            openshift.selector('svc', openshiftDeployment).delete()
                        }
                        if (openshift.selector('route', openshiftDeployment).exists()) {
                            openshift.selector('route', openshiftDeployment).delete()
                        }
                        
                        result = openshift.raw("apply", "-f openshift/${openshiftDeployment}-template.yaml")
                        // dit template moet een deployment hebben van het image met tag 'latest'
                        // er zit geen trigger in om te deployen bij image change

                        // stel dat het trigger er toch is, deze op manual zetten, Jenkins is in control
                        openshift.set("triggers", "dc/${openshiftDeployment}", "--manual")
                    }
                }
            }
        }
        stage('Deploy in O') {
            steps {
                script {
                    openshift.withCluster() {
//                        openshift.tag("ont:latest", "ont:${gitVersion}")
                        def dc = openshift.selector("dc", openshiftDeployment)
                        dc.rollout().latest()
                        // wachten tot alle replicas beschikbaar zijn.
                        while (dc.object().spec.replicas != dc.object().status.availableReplicas) {
                            echo "Wait for all replicas are available"
                            sleep 10
                        }
                    }
                }
            }
        }
    }
}
