@Library("GENERIC") _
    pipelineRelease_openshift_v1 {
	deploymentId = "ivakbs"
	deployPipeline = "iva-kbs_deploy_release"
	integrationPipeline = "iva-kbs-test"
	environmentChoices = "tst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6"
	mvnVersion = "maven36-openjdk11"
}
