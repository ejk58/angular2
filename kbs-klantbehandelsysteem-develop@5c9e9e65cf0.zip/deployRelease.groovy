@Library("GENERIC") _
    pipelineDeployArtifactFromQuay {
	deploymentId = "ivakbs"
	integrationPipeline = "iva-kbs-test"
	packageChoices = "iva-kbs"
                applicationVersionChoices = "0.5.0\n0.4.0\n0.1.0\n0.0.4"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "1\n2\n3\n4\n5\n6\n-pat\n-krb\n-baa"
}
