## Klantbehandelsysteem

The backend runs on Java 11 and Spring Framework. We use various Spring components to handle things:
- Spring Boot for creating an executable JAR using the `spring-boot-starter-parent` Maven parent POM
- Spring IoC container for dependency injection (using `@Autowired`/constructor-based injection)
- Spring Data JPA with Hibernate for accessing databases
- Spring Web with Jackson and ObjectMapper for serving REST endpoints
- Swagger for REST API developer support
- Spring Security for various security and authentication features in the REST API and using LDAP
- Bean Validation 2.0 using the Hibernate Validator
- Logging using SLF4J
- JUnit and Mockito
- Lombok
- MapStruct for mapping DTO's to domain entities
- Various Belastingdienst Java Components (JaCoB)
- iva-common-springboot
- JsonWebToken

### Local development with custom database schema for backend
1. Copy `application-dev-userid.properties.template` and replace your user ID: e.g. `application-dev-dekkj15.properties`
1. Adjust the schema name inside this `.properties` file: e.g. `spring.datasource.hikari.schema=DEKKJ15_IVAKBS01`
1. Use the new profile to overwrite the default configuration of `application.properties` by adjusting the setting `Active profiles:` of your Spring run configuration to the `dev-userid` part of the filename: e.g. `dev-dekkj15`.
1. When you run the Spring backend now, it should list the following line in the server console output and use your custom schema when connecting to the KBS Db2 database: `2021-05-19 12:04:52.760 INFO [boot.SpringApplication.logStartupProfileInfo()] The following profiles are active: dev-dekkj15`

### Want to connect to the KTA database in IntelliJ?
Make sure that your IBM Db2 driver lists the following two JARs under `Data Sources and Drivers > Drivers (subtab) > IBM Db2 > General (subtab) > Driver Files`:
1. DB2 ver. 4.26.14 [stable] (usually installed as `C:\Users\dekkj15\AppData\Roaming\JetBrains\IntelliJIdea2021.1\jdbc-drivers\DB2\4.26.14\db2jcc4_4.26.14.jar`)
1. db2jcc_license_cisuz.jar

The last one is usually missing, but is required when connecting to an IBM Db2 Mainframe or z/OS server! Add it in the aforementioned `Driver Files` window by clicking `+ > Custom JARs... >` Navigate to `C:\Users\dekkj15\AppData\Roaming\JetBrains\IntelliJIdea2021.1\jdbc-drivers\DB2\4.26.14\db2jcc_license_cisuz.jar`. 
