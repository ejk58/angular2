package nl.belastingdienst.iva.wd.kbs.security;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

class AnchorElementSanitizerTest {

	private static Stream<Arguments> provideInputStringsAndExpectedBooleansFor_hrefHttpPattern() {
		return Stream.of(
				Arguments.of(true,  "<a href=\"//belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a href=\"http://belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a href=\"https://belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a HREF=\"HTTPS://belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(false, "blah blah"),
				Arguments.of(false, "<a href=\"belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(false, "<a href=\"www.belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(false, "<a href=\"WWW.belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(false, "<a href=\"jm_dekker@belastingdienst.nl\">jm_dekker@belastingdienst.nl</a>"),
				Arguments.of(false, "<a href=\"mailto:jm_dekker@belastingdienst.nl\">jm_dekker@belastingdienst.nl</a>"),
				Arguments.of(false, "<a href=\"tel:0031613245678\">Belastingtelefoon</a>")
		);
	}
	@ParameterizedTest
	@MethodSource("provideInputStringsAndExpectedBooleansFor_hrefHttpPattern")
	void hrefHttpPattern_TestCases(boolean expectMatch, String input) {
		assertEquals(expectMatch, AnchorElementSanitizer.HREF_HTTP_PATTERN.matcher(input).find());
	}

	private static Stream<Arguments> provideInputStringsAndExpectedBooleansFor_anchorElementPattern() {
		return Stream.of(
				Arguments.of(true,  "<a href=\"//belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a href=\"http://belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a href=\"https://belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a HREF=\"HTTPS://belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a href=\"belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a href=\"www.belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a href=\"WWW.belastingdienst.nl\">Belastingdienst</a>"),
				Arguments.of(true,  "<a href=\"jm_dekker@belastingdienst.nl\">jm_dekker@belastingdienst.nl</a>"),
				Arguments.of(true,  "<a href=\"mailto:jm_dekker@belastingdienst.nl\">jm_dekker@belastingdienst.nl</a>"),
				Arguments.of(true,  "<a href=\"tel:0031613245678\" >Belastingtelefoon</a>"),
				Arguments.of(true,  "<p>Nog geen toelichting aangemaakt.</p><p><br></p><p><a href=\"jm_dekker@belastingdienst.nl\" rel=\"noopener noreferrer\" target=\"_blank\">jm_dekker@belastingdienst.nl</a> </p>"),
				Arguments.of(true,  "<p>Nog geen toelichting aangemaakt.</p><p><br></p><p><a rel=\"noopener noreferrer\" href=\"jm_dekker@belastingdienst.nl\" target=\"_blank\">jm_dekker@belastingdienst.nl</a> </p>"),
				Arguments.of(true,  "<p>Nog geen toelichting aangemaakt.</p><p><br></p><p><a rel=\"noopener noreferrer\" target=\"_blank\" href=\"jm_dekker@belastingdienst.nl\" >jm_dekker@belastingdienst.nl</a> </p>"),
				Arguments.of(false, "blah blah"),
				Arguments.of(false, "<p>blah blah</p>"),
				Arguments.of(false, "<p href=\"d\">a</p>"),
				Arguments.of(false, "<ahref=\"d\">a</a>")
		);
	}
	@ParameterizedTest
	@MethodSource("provideInputStringsAndExpectedBooleansFor_anchorElementPattern")
	void anchorElementPattern_TestCases(boolean expectMatch, String input) {
		assertEquals(expectMatch, AnchorElementSanitizer.ANCHOR_ELEMENT_PATTERN.matcher(input).find());
	}

	@ParameterizedTest
	@ValueSource(strings = {
			// Email address and has mailto scheme
			"<a rel=\"noopener noreferrer\" href=\"mailto:jm_dekker@belastingdienst.nl\" target=\"_blank\">jm_dekker@belastingdienst.nl</a>",
			// HTTP URL and has http scheme
			"<a rel=\"noopener noreferrer\" href=\"http://belastingdienst.nl\" target=\"_blank\">Belastingdienst.nl</a>",
			// HTTPS URL and has https scheme
			"<a rel=\"noopener noreferrer\" href=\"https://belastingdienst.nl\" target=\"_blank\">Belastingdienst</a>",
			// scheme-relative URL and has double forward slashes
			"<a rel=\"noopener noreferrer\" href=\"//belastingdienst.nl\" target=\"_blank\">Belastingdienst.nl</a>",
	})
	void fixAnchorHrefUrlScheme_ShouldNotModifyAnything_WhenInputHasCorrectUrlScheme(String input) {
		assertEquals(input, AnchorElementSanitizer.fixAnchorHrefUrlScheme(input));
	}

	private static Stream<Arguments> provideInputAndExpectedStringsFor_fixAnchorHrefUrlScheme() {
		return Stream.of(
				Arguments.of( // Email address without mailto scheme
						"<a rel=\"noopener noreferrer\" href=\"jm_dekker@belastingdienst.nl\" target=\"_blank\">jm_dekker@belastingdienst.nl</a>",
						"<a rel=\"noopener noreferrer\" href=\"mailto:jm_dekker@belastingdienst.nl\" target=\"_blank\">jm_dekker@belastingdienst.nl</a>"
				),
				Arguments.of( // Missing HTTP(S) scheme
						"<a href=\"belastingdienst.nl\">Belastingdienst</a>",
						"<a href=\"https://belastingdienst.nl\">Belastingdienst</a>"
				),
				Arguments.of( // Match www subdomain
						"<a href=\"www.belastingdienst.nl\">Belastingdienst</a>",
						"<a href=\"https://www.belastingdienst.nl\">Belastingdienst</a>"
				),
				Arguments.of( // Also match other subdomains
						"<a href=\"intranet.belastingdienst.nl\">Belastingdienst</a>",
						"<a href=\"https://intranet.belastingdienst.nl\">Belastingdienst</a>"
				),
				Arguments.of( // Case-insensitive
						"<a href=\"WWW.belastingdienst.nl\">Belastingdienst</a>",
						"<a href=\"https://WWW.belastingdienst.nl\">Belastingdienst</a>"
				),
				Arguments.of( // Treat any URL scheme other than mailto as HTTP(S)
						"<a href=\"tel:0031613245678\" >Belastingtelefoon</a>",
						"<a href=\"https://tel:0031613245678\" >Belastingtelefoon</a>"
				)
		);
	}
	@ParameterizedTest
	@MethodSource("provideInputAndExpectedStringsFor_fixAnchorHrefUrlScheme")
	void fixAnchorHrefUrlScheme_ShouldPrependUrlScheme_WhenInputIsMissingUrlScheme(String input, String expected) {
		assertEquals(expected, AnchorElementSanitizer.fixAnchorHrefUrlScheme(input));
	}
}
