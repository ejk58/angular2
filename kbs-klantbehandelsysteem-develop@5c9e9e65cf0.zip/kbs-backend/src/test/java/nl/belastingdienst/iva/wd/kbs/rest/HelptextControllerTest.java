package nl.belastingdienst.iva.wd.kbs.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;

import nl.belastingdienst.iva.wd.kbs.domain.Helptext;
import nl.belastingdienst.iva.wd.kbs.service.HelptextService;

@WebMvcTest(controllers = HelptextController.class)
@ExtendWith(MockitoExtension.class)
@WithMockUser("ivatest1")
class HelptextControllerTest {

	@MockBean
	private HelptextService serviceMock;

	@Autowired
	private HelptextController sut;

	@Test
	void storeHelptext_SanitizesHtmlFully_BeforeSavingHelptext() {
		final String input =
				// Rearrange/add/overwrite target and rel atribute values, missing HTTPS scheme should be added
				"<p><a rel=\"noopener noreferrer\" href=\"mailto:jm_dekker@belastingdienst.nl\" target=\"_blank\">jm_dekker@belastingdienst.nl</a></p>\n"
				+ "<p><a href=\"https://intranet.belastingdienst.nl/\" rel=\"noopener noreferrer\" target=\"_blank\">https://intranet.belastingdienst.nl/</a></p>\n"
				+ "<p><a href=\"www.example.org\" rel=\"noopener noreferrer\" target=\"_blank\">www.example.org</a></p>\n"
				+ "<p><a href=\"example.org\" rel=\"noopener noreferrer\" target=\"_blank\">example.org</a></p>\n"
				+ "<p><a href=\"//example.org\" rel=\"noopener noreferrer\" target=\"_blank\">example.org</a></p>\n"
				+ "<p><ahref=\"//example.org\" rel=\"noopener noreferrer\" target=\"_blank\">example.org</a></p>\n"
				+ "<p>Nog geen toelichting aangemaakt.</p>\n"
				+ "<p>jm_dekker@belastingdienst.nl</p>\n"
				+ "<p><a rel=\"noopener noreferrer\" href=\"jm_dekker@belastingdienst.nl\" target=\"_blank\">jm_dekker@belastingdienst.nl</a></p>\n"
				// Href should point to https://Belastingtelefoon because tel: scheme is not allowed
				+ "<p><a href=\"tel:0031613245678\" >Belastingtelefoon</a>,</p>\n"
				+ "<p><br></p>\n"
				+ "<p>Klantbeeld (KTA), Company.info,&nbsp;<a href=\"http://INTERNETSERVICE4U.belastingdienst.nl/\" rel=\"noopener noreferrer\" target=\"_blank\">http://INTERNETSERVICE4U.belastingdienst.nl/</a></p>\n"
				// Href should point to connectpeople.belastingdienst.nl
				+ "<p><a href=\"https://evil-corp.example.org\" rel=\"noopener noreferrer\" target=\"_blank\">https://connectpeople.belastingdienst.nl/</a></p>\n"
				+ "<p><br></p>\n"
				+ "<p>In het tekstveld dient een screenshot opgenomen te worden van “<a href=\"intranet.belastingdienst.nl\" rel=\"noopener noreferrer\" target=\"_blank\">Totalen aanslagen per jaar VPB</a>” in KTA, op het niveau van de gehele entiteit</p>\n"
				+ "<p><br></p>\n"
				+ "<p><a href=\"https://jira.belastingdienst.nl/secure/RapidBoard.jspa?rapidView=1977&amp;view=detail&amp;selectedIssue=IVAKBS-141\" rel=\"noopener noreferrer\" target=\"_blank\">https://jira.belastingdienst.nl/secure/RapidBoard.jspa?rapidView=1977&amp;view=detail&amp;selectedIssue=IVAKBS-141</a></p>\n"
				// Script elements are not allowed
				+ "<p><script>alert('XSS_VULNERABILITY_FROM_DB')</script></p>\n"
				+ "<p><script type=\"text/javascript\">alert('XSS_VULNERABILITY_FROM_DB')</script></p><p>SANITIZATION_SUCCESSFUL</p>'\n"
				// Invalid images
				+ "<p><img></p>\n"
				+ "<p><img /></p>\n"
				+ "<p><img src=\"\"></p>\n"
				+ "<p><img src=\"a.jpg\"></p>\n"
				+ "<p><img src=\"//example.org/a.jpg\"></p>\n"
				+ "<p><img src=\"http://example.org/a.jpg\"></p>\n"
				+ "<p><img src=\"https://example.org/a.jpg\"></p>\n"
				+ "<p><img src=\"data:image/jpg;base63,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n"
				// Valid images
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n"
				+ "<p><img src=\"data:image/JPG;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n" // Case-insensitive
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" ></p>\n"
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"\\></p>\n"
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" \\></p>\n"
				// Alt should be stripped
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" alt=\"Afbeelding\"></p>\n"
				// Support various common image formats
				+ "<p><img src=\"data:image/gif;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n"
				+ "<p><img src=\"data:image/png;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n"
				// Various xss tests
				+ "<img src=x onerror=\"&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041\">\n"
				+ "\\<a onmouseover=\"alert(document.cookie)\"\\>xxs link\\</a\\>\n"
				+ "<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script:&#97lert(1)>ClickMe\n"
				;
		final String expectedHtml =
				// Rearranged/added/overwrote target and rel atribute values, href has HTTPS scheme where missing
				"<p><a href=\"mailto:jm_dekker&#64;belastingdienst.nl\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">jm_dekker&#64;belastingdienst.nl</a></p>\n"
				+ "<p><a href=\"https://intranet.belastingdienst.nl/\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">https://intranet.belastingdienst.nl/</a></p>\n"
				+ "<p><a href=\"https://www.example.org\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">www.example.org</a></p>\n"
				+ "<p><a href=\"https://example.org\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">example.org</a></p>\n"
				+ "<p><a href=\"https://example.org\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">example.org</a></p>\n"
				+ "<p>example.org</p>\n"
				+ "<p>Nog geen toelichting aangemaakt.</p>\n"
				+ "<p>jm_dekker&#64;belastingdienst.nl</p>\n"
				+ "<p><a href=\"mailto:jm_dekker&#64;belastingdienst.nl\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">jm_dekker&#64;belastingdienst.nl</a></p>\n"
				// Href points to Belastingtelefoon with HTTPS scheme
				+ "<p><a href=\"https://Belastingtelefoon\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">Belastingtelefoon</a>,</p>\n"
				+ "<p><br /></p>\n"
				+ "<p>Klantbeeld (KTA), Company.info, <a href=\"http://INTERNETSERVICE4U.belastingdienst.nl/\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">http://INTERNETSERVICE4U.belastingdienst.nl/</a></p>\n"
				// Href points to connectpeople.belastingdienst.nl
				+ "<p><a href=\"https://connectpeople.belastingdienst.nl/\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">https://connectpeople.belastingdienst.nl/</a></p>\n"
				+ "<p><br /></p>\n"
				+ "<p>In het tekstveld dient een screenshot opgenomen te worden van “<a href=\"https://Totalen%20aanslagen%20per%20jaar%20VPB\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">Totalen aanslagen per jaar VPB</a>” in KTA, op het niveau van de gehele entiteit</p>\n"
				+ "<p><br /></p>\n"
				+ "<p><a href=\"https://jira.belastingdienst.nl/secure/RapidBoard.jspa?rapidView&#61;1977&amp;view&#61;detail&amp;selectedIssue&#61;IVAKBS-141\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">https://jira.belastingdienst.nl/secure/RapidBoard.jspa?rapidView&#61;1977&amp;view&#61;detail&amp;selectedIssue&#61;IVAKBS-141</a></p>\n"
				// Script elements have been stripped
				+ "<p></p>\n"
				+ "<p></p><p>SANITIZATION_SUCCESSFUL</p>&#39;\n"
				// Invalid images have been stripped
				+ "<p></p>\n"
				+ "<p></p>\n"
				+ "<p></p>\n"
				+ "<p></p>\n"
				+ "<p></p>\n"
				+ "<p></p>\n"
				+ "<p></p>\n"
				+ "<p></p>\n"
				// Valid images
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
				+ "<p><img src=\"data:image/JPG;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n" // Case-insensitive
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
				// Alt has been stripped
				+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
				// Support various common image formats
				+ "<p><img src=\"data:image/gif;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
				+ "<p><img src=\"data:image/png;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
				// Various xss test
				+ "\n"
				+ "\\<a target=\"_blank\">xxs link\\\n" + "</a>"
				+ "<a href=\"j&amp;#97v&amp;#97script:&amp;#97lert%281%29\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">ClickMe\n" + "</a>"
				;

		when(serviceMock.getHelptextForEntiteit(any(), any())).thenReturn(Optional.empty());

		Helptext h = new Helptext();
		h.setTxt(input);
		sut.storeHelptext(h);

		ArgumentCaptor<Helptext> argument = ArgumentCaptor.forClass(Helptext.class);
		verify(serviceMock, times(1)).saveHelptext(argument.capture());
		String actualHtml = argument.getValue().getTxt();
		assertEquals(expectedHtml, actualHtml);
	}
}
