package nl.belastingdienst.iva.wd.kbs.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.dao.SubEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteiten;
import nl.belastingdienst.iva.wd.kbs.domain.ZooSubEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.dao.KtaEntiteitBrancheRepository;
import nl.belastingdienst.iva.wd.kbs.kta.dao.KtaSubEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteitBranche;
import nl.belastingdienst.iva.wd.kbs.mappings.SubEntiteitMapper;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Scope(value = "singleton")
@Slf4j
@RequiredArgsConstructor
public class SubEntiteitService {

    private final SubEntiteitRepository subEntiteitRepository;
    private final KtaSubEntiteitRepository ktaSubEntiteitRepository;
    private final KtaEntiteitBrancheRepository ktaEntiteitBrancheRepository;
    private final SubEntiteitMapper subEntiteitMapper;

    public void saveSubEntiteiten(Long entiteitNummer, List<ZooSubEntiteit> zooSubEntiteiten) {
        subEntiteitRepository.deleteByEntiteitNummer(entiteitNummer);
        zooSubEntiteiten.forEach(zooSubEntiteit -> subEntiteitRepository.save(new SubEntiteiten(entiteitNummer, zooSubEntiteit.getBsnRsin())));
    }

    public List<SubEntiteiten> getSelectedSubEntiteiten(Long entiteitNummer) {
        return this.subEntiteitRepository.findAllByEntiteitNummer(entiteitNummer);
    }

    public List<ZooSubEntiteit> getZooSubEntiteitenByEntiteitNummer(Long entiteitNummer) {
        List<ZooSubEntiteit> results = new ArrayList<>();
        List<ZooSubEntiteit> mappedListWithOutBrancheCodes = subEntiteitMapper
                .map(ktaSubEntiteitRepository.findByEntiteitNummer(entiteitNummer));
        for (int i = 0; i < mappedListWithOutBrancheCodes.size(); i++) {
            ZooSubEntiteit mapped = mappedListWithOutBrancheCodes.get(i);
            KtaEntiteitBranche branch = ktaEntiteitBrancheRepository.findByBsnRsin(mapped.getBsnRsin());
            if (branch != null) {
                mapped = subEntiteitMapper.update(branch, mapped);
            }
            results.add(mapped);
        }
        return results;
    }

    public ZooSubEntiteit getZooSubEntiteit(Long entiteitNummer, Long bsnRsin) {
        return subEntiteitMapper.map(ktaSubEntiteitRepository.findByEntiteitNummerAndBsnRsin(entiteitNummer, bsnRsin));
    }
}
