package nl.belastingdienst.iva.wd.kbs.domain;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "API_KEY")
@Data // TODO Jelle: JPA Buddy-plugin complains about this annotation being unsafe?
public class ApiKey {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "API_KEY")
	private String key;
	private String customer;
	private String authorizedMethods;

	public boolean isMethodAuthorized(String method) {
		Set<String> methods = new HashSet<>(Arrays.asList(authorizedMethods.split(",")));
		return methods.contains(method);
	}
}