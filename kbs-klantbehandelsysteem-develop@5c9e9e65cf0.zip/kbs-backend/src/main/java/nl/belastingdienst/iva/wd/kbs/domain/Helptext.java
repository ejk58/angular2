package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@IdClass(Helptext.PrimaryKey.class)
@Table(name = "HELPTEXT")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Helptext {
	@Id
	private String id;
	@Column(name = "HELPTEXT")
	private String txt;
	@Column(name = "USER")
	private String userId;
	@Column(name = "CHANGE_DT")
	private Date changed;
	@Id
	private Integer entiteit;

	public static class PrimaryKey implements Serializable {
		private String id;
		private Integer entiteit;
	}
}
