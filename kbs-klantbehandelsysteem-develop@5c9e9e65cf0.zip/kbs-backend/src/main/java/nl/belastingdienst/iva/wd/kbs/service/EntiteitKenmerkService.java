/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: FeedbackService.java
 *             Auteur: hubeh00
 *    Creatietijdstip: 15-4-2021 11:46
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.EntiteitKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerkId;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkType;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkWithValuesDto;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Scope(value = "singleton")
@Slf4j
@RequiredArgsConstructor
public class EntiteitKenmerkService {

    private final EntiteitKenmerkRepository entiteitKenmerkRepository;

    Optional<EntiteitKenmerk> getEntiteitKenmerkByRsinAndType(Long bsnRsin, KenmerkType type) {
        return this.entiteitKenmerkRepository.findAllByEntiteitKenmerkId(new EntiteitKenmerkId(bsnRsin, type.getValue()));
    }

    public Optional<EntiteitKenmerk> getBranchecodeAanvullingen(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.BCAV);
    }

    public Optional<EntiteitKenmerk> getSelectedAandachtsgebieden(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.AG);
    }

    public Optional<EntiteitKenmerk> getSelectedMiddelen(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.MID);
    }

    public Optional<EntiteitKenmerk> getSelectedAttentiepunten(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.CBOBA);
    }

    public Optional<EntiteitKenmerk> getSelectedActiepunten(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.CBAP);
    }

    public Optional<EntiteitKenmerk> getSelectedActiepuntenBalans(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.CBAPB);
    }

    public Optional<EntiteitKenmerk> getSelectedActiepuntenWinstenVerlies(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.CBAPW);
    }

    public Optional<EntiteitKenmerk> getSelectedBedrijfsstrategieen(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.BS);
    }

    public Optional<EntiteitKenmerk> getSelectedExterneOmgevingKenmerken(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.EO);
    }

    public Optional<EntiteitKenmerk> getSelectedGovernanceStructuurKenmerken(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.GS);
    }

    public Optional<EntiteitKenmerk> getSelectedRisicomanagementKenmerken(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.RM);
    }

    public Optional<EntiteitKenmerk> getSelectedComplexiteitKenmerken(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.CK);
    }

    public Optional<EntiteitKenmerk> getSelectedSector(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.SECTR);
    }

    public void saveSelectedSector(Long bsnRsin, int sector) {
        var kenmerkId = new EntiteitKenmerkId(bsnRsin, KenmerkType.SECTR.getValue());
        if (sector == -1) {
            this.entiteitKenmerkRepository.deleteById(kenmerkId);
        } else {
            this.entiteitKenmerkRepository.save(new EntiteitKenmerk(kenmerkId, String.valueOf(sector)));
        }
    }

    public Optional<EntiteitKenmerk> getSelectedAttentiepuntIds(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.CBIBV);
    }

    private void createEntiteitKenmerk(EntiteitKenmerkId entiteitKenmerkId, List<Integer> kenmerkenIds,
            List<Integer> kenmerkenIdsWithValues) {
        if (kenmerkenIds.isEmpty() && entiteitKenmerkRepository.existsById(entiteitKenmerkId)) {
            entiteitKenmerkRepository.deleteById(entiteitKenmerkId);
            return;
        }

        var entiteitKenmerk = new EntiteitKenmerk();
        entiteitKenmerk.setEntiteitKenmerkId(entiteitKenmerkId);
        entiteitKenmerk.setKenmerken(kenmerkenIds);
        entiteitKenmerk.setValues(kenmerkenIdsWithValues);
        entiteitKenmerkRepository.save(entiteitKenmerk);
    }

    public void saveEntiteitKenmerkIds(Long bsnRsin, String kenmerkType, List<Integer> kenmerkenListIds) {
        createEntiteitKenmerk(
            new EntiteitKenmerkId(bsnRsin, kenmerkType),
            new ArrayList<>(kenmerkenListIds),
            new ArrayList<>()
        );
    }

    public void saveEntiteitKenmerken(Long bsnRsin, String kenmerkType, List<KenmerkWithValuesDto> kenmerkenList) {
        var entiteitKenmerkId = new EntiteitKenmerkId(bsnRsin, kenmerkType);
        var kenmerkenIds = kenmerkenList.stream().map(KenmerkWithValuesDto::getId).collect(Collectors.toList());
        List<Integer> kenmerkenIdsWithValues = new ArrayList<>();
        for (KenmerkWithValuesDto withValuesDto : kenmerkenList) {
            if (withValuesDto.getValues() != null && withValuesDto.getValues().equals("true"))
                kenmerkenIdsWithValues.add(withValuesDto.getId());
        }
        createEntiteitKenmerk(entiteitKenmerkId, kenmerkenIds, kenmerkenIdsWithValues);
    }
}

