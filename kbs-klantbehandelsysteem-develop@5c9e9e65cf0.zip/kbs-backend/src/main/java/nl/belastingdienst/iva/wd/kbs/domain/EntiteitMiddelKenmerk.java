package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ENTITEIT_MIDDEL_KENMERK")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EntiteitMiddelKenmerk {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @Column(name = "HOOFDKENMERK_ID")
    private Long hoofdKenmerkId;
    @Column(name = "SUBKENMERK1_ID")
    private Long subKenmerk1Id;
    @Column(name = "SUBKENMERK2_ID")
    private Long subKenmerk2Id;
    @Column(name = "SUBKENMERK3_ID")
    private Long subKenmerk3Id;
    @Column(name = "RANK")
    private Long rank;
    @Column(name = "ENTITEITNUMMER")
    private Long entiteitNummer;
}
