package nl.belastingdienst.iva.wd.kbs.domain;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "ZICHT_OP_ORGANISATIE_OMVANG")
@RequiredArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ZooOmvang {

	public ZooOmvang(Long entiteitNummer) {
		this.entiteitNummer = entiteitNummer;
	}

	@Id
	@Getter(onMethod_ = { @Deprecated })
	@Setter(onMethod_ = { @Deprecated })
	private Long entiteitNummer;

	@Transient private Integer aantalBsnRsinsInEntiteit;
	@Transient private Integer aantalBezwarenVerzoekenEnBeroepen;
	private Integer aantalBuitenlandseDeelnemingen;
	private Integer aantalVasteInrichtingen;
	@Transient private BigInteger belastingschuld;
	@Transient private BigInteger totalenPerJaarOb;
	private BigInteger totaleVrijgesteldeOmzet;
	@Transient private BigInteger totalenPerJaarLhAantalLoongerechtigden;
	@Transient private BigInteger totalenPerJaarLhTotaalLoonsom;
	@Transient private BigInteger totalenAanslagenPerJaarVpb;
	@Transient private BigInteger totaalBetalingenJaarX;
	@Transient private BigInteger totaalBetalingenJaarXMin1;
	@Transient private BigInteger totaalBetalingenJaarXMin2;
	@Transient private BigDecimal wolbSom;

	private LocalDateTime lastUpdated;
	private String lastUpdatedByUserId;

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		ZooOmvang zooOmvang = (ZooOmvang) o;

		if (!entiteitNummer.equals(zooOmvang.entiteitNummer))
			return false;
		if (!Objects.equals(aantalBsnRsinsInEntiteit, zooOmvang.aantalBsnRsinsInEntiteit))
			return false;
		if (!Objects.equals(aantalBezwarenVerzoekenEnBeroepen, zooOmvang.aantalBezwarenVerzoekenEnBeroepen))
			return false;
		if (!Objects.equals(aantalBuitenlandseDeelnemingen, zooOmvang.aantalBuitenlandseDeelnemingen))
			return false;
		if (!Objects.equals(aantalVasteInrichtingen, zooOmvang.aantalVasteInrichtingen))
			return false;
		if (!Objects.equals(belastingschuld, zooOmvang.belastingschuld))
			return false;
		if (!Objects.equals(totalenPerJaarOb, zooOmvang.totalenPerJaarOb))
			return false;
		if (!Objects.equals(totaleVrijgesteldeOmzet, zooOmvang.totaleVrijgesteldeOmzet))
			return false;
		if (!Objects.equals(totalenPerJaarLhAantalLoongerechtigden, zooOmvang.totalenPerJaarLhAantalLoongerechtigden))
			return false;
		if (!Objects.equals(totalenPerJaarLhTotaalLoonsom, zooOmvang.totalenPerJaarLhTotaalLoonsom))
			return false;
		if (!Objects.equals(totalenAanslagenPerJaarVpb, zooOmvang.totalenAanslagenPerJaarVpb))
			return false;
		if (!Objects.equals(totaalBetalingenJaarX, zooOmvang.totaalBetalingenJaarX))
			return false;
		if (!Objects.equals(totaalBetalingenJaarXMin1, zooOmvang.totaalBetalingenJaarXMin1))
			return false;
		if (!Objects.equals(totaalBetalingenJaarXMin2, zooOmvang.totaalBetalingenJaarXMin2))
			return false;
		if (!Objects.equals(wolbSom, zooOmvang.wolbSom))
			return false;
		if (!lastUpdated.equals(zooOmvang.lastUpdated))
			return false;
		return lastUpdatedByUserId.equals(zooOmvang.lastUpdatedByUserId);
	}

	@Override
	public int hashCode() {
		int result = entiteitNummer.hashCode();
		result = 31 * result + (aantalBsnRsinsInEntiteit != null ? aantalBsnRsinsInEntiteit.hashCode() : 0);
		result = 31 * result + (aantalBezwarenVerzoekenEnBeroepen != null ? aantalBezwarenVerzoekenEnBeroepen.hashCode() : 0);
		result = 31 * result + (aantalBuitenlandseDeelnemingen != null ? aantalBuitenlandseDeelnemingen.hashCode() : 0);
		result = 31 * result + (aantalVasteInrichtingen != null ? aantalVasteInrichtingen.hashCode() : 0);
		result = 31 * result + (belastingschuld != null ? belastingschuld.hashCode() : 0);
		result = 31 * result + (totalenPerJaarOb != null ? totalenPerJaarOb.hashCode() : 0);
		result = 31 * result + (totaleVrijgesteldeOmzet != null ? totaleVrijgesteldeOmzet.hashCode() : 0);
		result = 31 * result + (totalenPerJaarLhAantalLoongerechtigden != null ?
				totalenPerJaarLhAantalLoongerechtigden.hashCode() :
				0);
		result = 31 * result + (totalenPerJaarLhTotaalLoonsom != null ? totalenPerJaarLhTotaalLoonsom.hashCode() : 0);
		result = 31 * result + (totalenAanslagenPerJaarVpb != null ? totalenAanslagenPerJaarVpb.hashCode() : 0);
		result = 31 * result + (totaalBetalingenJaarX != null ? totaalBetalingenJaarX.hashCode() : 0);
		result = 31 * result + (totaalBetalingenJaarXMin1 != null ? totaalBetalingenJaarXMin1.hashCode() : 0);
		result = 31 * result + (totaalBetalingenJaarXMin2 != null ? totaalBetalingenJaarXMin2.hashCode() : 0);
		result = 31 * result + (wolbSom != null ? wolbSom.hashCode() : 0);
		result = 31 * result + lastUpdated.hashCode();
		result = 31 * result + lastUpdatedByUserId.hashCode();
		return result;
	}
}
