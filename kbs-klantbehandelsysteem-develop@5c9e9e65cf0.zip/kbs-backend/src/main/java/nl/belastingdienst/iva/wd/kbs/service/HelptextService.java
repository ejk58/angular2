package nl.belastingdienst.iva.wd.kbs.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.dao.HelptextRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Helptext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Scope(value = "singleton")
@Slf4j
@RequiredArgsConstructor
public class HelptextService {

    private final HelptextRepository repo;

    public Optional<Helptext> getHelptext(String id) {
        return repo.findById(id);
    }

    public Helptext saveHelptext(Helptext helptext) {
        return repo.save(helptext);
    }

    public Optional<Helptext> getHelptextForEntiteit(String helptextId, Integer entiteitId) {
        return repo.findByIdAndEntiteit(helptextId, entiteitId);
    }
}
