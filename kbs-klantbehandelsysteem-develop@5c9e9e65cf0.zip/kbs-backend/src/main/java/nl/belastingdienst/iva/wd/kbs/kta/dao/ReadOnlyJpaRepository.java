package nl.belastingdienst.iva.wd.kbs.kta.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * Extension of {@link org.springframework.data.jpa.repository.JpaRepository} but with all create, update and delete functionality
 * disabled, effectively making it read-only.
 *
 * @param <T>
 * 		the domain type the repository manages
 * @param <I>
 * 		the type of the id of the entity the repository manages
 */
@SuppressWarnings({ "java:S1133", "java:S1123" })
@NoRepositoryBean
public interface ReadOnlyJpaRepository<T, I> extends JpaRepository<T, I> {

	@Deprecated
	@Override
	default <S extends T> List<S> saveAll(Iterable<S> entities) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default void flush() {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default <S extends T> S saveAndFlush(S entity) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default void deleteInBatch(Iterable<T> entities) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default void deleteAllInBatch() {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default <S extends T> S save(S entity) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default void deleteById(I i) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default void delete(T entity) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default void deleteAll(Iterable<? extends T> entities) {
		throw new UnsupportedOperationException();
	}

	@Deprecated
	@Override
	default void deleteAll() {
		throw new UnsupportedOperationException();
	}
}
