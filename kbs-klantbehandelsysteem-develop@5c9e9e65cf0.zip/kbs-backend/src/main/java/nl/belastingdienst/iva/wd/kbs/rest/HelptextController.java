package nl.belastingdienst.iva.wd.kbs.rest;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.kbs.domain.Helptext;
import nl.belastingdienst.iva.wd.kbs.security.HtmlSanitizer;
import nl.belastingdienst.iva.wd.kbs.service.HelptextService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/helptext")
public class HelptextController {

	/**
	 * Reserved default value of ENTITEIT_NUMMER column in HELPTEXT table of Db2 database
	 */
	private static final Integer ENTITEIT_NUMMER_DATABASE_DEFAULT = 0;

	private final HelptextService helptextService;

	@GetMapping("/{helptextId}")
	public Helptext getHelptext(@PathVariable String helptextId) {
		return helptextService.getHelptext(helptextId)
				.orElse(doesNotExist(helptextId, null));
	}

	@GetMapping("/{helptextId}/for/{entiteitId}")
	public Helptext getHelptextForEntiteit(@PathVariable String helptextId, @PathVariable Integer entiteitId) {
		return helptextService.getHelptextForEntiteit(helptextId, entiteitId)
				.orElse(doesNotExist(helptextId, entiteitId));
	}

	@PostMapping("/save")
	public Helptext storeHelptext(@RequestBody Helptext helptext) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		if (StringUtils.isBlank(currentPrincipalName)) throw new NullPointerException("Helptext opslaan is mislukt: gebruiker is niet ingelogd!");

		if (helptext.getEntiteit() == null) {
			helptext.setEntiteit(ENTITEIT_NUMMER_DATABASE_DEFAULT);
		}

		if (helptext.getTxt() == null) {
			helptext.setTxt("");
		}
		helptext.setTxt(HtmlSanitizer.sanitizeHtml(helptext.getTxt()));

		Helptext toSave = helptextService.getHelptextForEntiteit(helptext.getId(), helptext.getEntiteit())
				.map(fromDb -> {
					// The helptext exists in the database. Update that instance with new value of text.
					fromDb.setTxt(helptext.getTxt());
					return fromDb;
				})
				// If the helptext did not exist in the database, then store the received instance.
				.orElse(helptext);

		toSave.setChanged(new Date());
		toSave.setUserId(currentPrincipalName);
		return helptextService.saveHelptext(toSave);
	}

	private static Helptext doesNotExist(String helptextId, Integer entiteit) {
		return Helptext.builder()
				.txt("Nog geen toelichting aangemaakt.") //lets give a default text to let a user know if the text does not exit yet.
				.id(helptextId)
				.entiteit(entiteit)
				.userId("")
				.changed(null)
				.build();
	}

}
