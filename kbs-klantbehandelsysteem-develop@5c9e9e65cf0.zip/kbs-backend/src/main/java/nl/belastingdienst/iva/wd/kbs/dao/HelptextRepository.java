package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.Helptext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface HelptextRepository extends JpaRepository<Helptext, Helptext.PrimaryKey> {
	Optional<Helptext> findById(String id);
	Optional<Helptext> findByIdAndEntiteit(String id, Integer entiteit);
}
