package nl.belastingdienst.iva.wd.kbs.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@IdClass(SubEntiteiten.PrimaryKey.class)
@Table(name = "SUB_ENTITEITEN")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubEntiteiten { // TODO Must be merged with SubEntiteit.java
	@Id
	@Column(name = "ENTITEIT_BSN")
	private Long entiteitNummer;
	@Id
	@Column(name = "SUB_ENTITEIT_BSN")
	private Long subEntiteitBsnRsin;

	public static class PrimaryKey implements Serializable {

		private static final long serialVersionUID = 3826512463034005824L;

		private Long entiteitNummer;
		private Long subEntiteitBsnRsin;
	}
}
