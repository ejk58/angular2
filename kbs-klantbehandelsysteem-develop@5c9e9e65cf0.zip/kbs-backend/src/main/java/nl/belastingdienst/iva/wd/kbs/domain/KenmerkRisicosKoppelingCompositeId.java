package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class KenmerkRisicosKoppelingCompositeId implements Serializable {
    @Column(name = "MIDDEL_KENMERK_ID")
    private Long middelKenmerkId;
    @Column(name = "MIDDEL_RISICO_ID")
    private Long middelRisicoId;
}
