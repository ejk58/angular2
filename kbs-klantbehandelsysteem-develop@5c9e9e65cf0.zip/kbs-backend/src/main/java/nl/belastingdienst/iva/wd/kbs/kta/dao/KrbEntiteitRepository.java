package nl.belastingdienst.iva.wd.kbs.kta.dao;

import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.kta.domain.KrbEntiteit;

@Repository
public interface KrbEntiteitRepository extends ReadOnlyJpaRepository<KrbEntiteit, Long> {
}
