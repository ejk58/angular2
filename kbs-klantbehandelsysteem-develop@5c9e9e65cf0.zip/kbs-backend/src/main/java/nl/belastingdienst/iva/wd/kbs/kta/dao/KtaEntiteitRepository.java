package nl.belastingdienst.iva.wd.kbs.kta.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteit;

@Repository
public interface KtaEntiteitRepository extends ReadOnlyJpaRepository<KtaEntiteit, String> {

	/**
	 * @see org.springframework.data.repository.CrudRepository#findById(Object)
	 */
	default Optional<KtaEntiteit> findById(Long id) {
		return findById(id.toString());
	}

	/**
	 * @see org.springframework.data.jpa.repository.JpaRepository#findAllById(Iterable)
	 */
	default List<KtaEntiteit> findAllByIds(Iterable<Long> ids) {
		List<String> idStrings = new ArrayList<>();
		for (Long id : ids) {
			idStrings.add(id.toString());
		}
		return findAllById(idStrings);
	}
}
