package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MIDDEL_KENMERKEN")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MiddelKenmerk {
	@Id
	@Column(name = "ID")
	private Long id;
	@Column(name = "MIDDEL_ID")
	private Long middelId;
	@Column(name = "KENMERK")
	private String kenmerk;
	@Column(name = "PARENT_ID")
	private Long parentId;
}
