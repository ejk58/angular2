package nl.belastingdienst.iva.wd.kbs.kta.dao;

import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaSubEntiteit;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KtaSubEntiteitRepository extends ReadOnlyJpaRepository<KtaSubEntiteit, Long> {
    List<KtaSubEntiteit> findByEntiteitNummer(Long entiteitNummer);
    KtaSubEntiteit findByEntiteitNummerAndBsnRsin(Long entiteitNummer, Long bsnRsin);
}
