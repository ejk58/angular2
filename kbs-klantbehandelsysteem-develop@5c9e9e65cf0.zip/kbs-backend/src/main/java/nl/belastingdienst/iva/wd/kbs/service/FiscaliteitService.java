package nl.belastingdienst.iva.wd.kbs.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkType;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class FiscaliteitService {

    private final MiddelKenmerkRepository middelKenmerkRepository;
    private final EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;
    private final MiddelRisicoRepository middelRisicoRepository;
    private final EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;
    private final KenmerkService kenmerkService;
    private final KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;

    public List<MiddelKenmerk> getMiddelKenmerken() {
        return middelKenmerkRepository.findAll();
    }

    public List<MiddelKenmerk> getKenmerkenByMiddelId(Long middelId) {
        return middelKenmerkRepository.findAllByMiddelId(middelId);
    }

    public List<EntiteitMiddelKenmerk> getEntiteitMiddelKenmerken(Long entiteitNummer) {
        return entiteitMiddelKenmerkRepository.findEntiteitMiddelKenmerkByEntiteitNummer(entiteitNummer);
    }

    public Optional<EntiteitMiddelKenmerk> getEntiteitMiddelKenmerkById(Long id) {
        return entiteitMiddelKenmerkRepository.findById(id);
    }

    public void saveEntiteitMiddelKenmerk(EntiteitMiddelKenmerk entiteitMiddelKenmerk) {
        entiteitMiddelKenmerkRepository.save(entiteitMiddelKenmerk);
    }

    public void deleteEntiteitMiddelKenmerk(Long id) {
        entiteitMiddelKenmerkRepository.deleteById(id);
    }

    public List<Kenmerk> getZoFMiddelRisicoStatussen() {
        return kenmerkService.findKenmerkenByType(KenmerkType.RSTAT);
    }

    public List<MiddelRisico> getMiddelRisicos() {
        return middelRisicoRepository.findAll();
    }

    public List<MiddelRisico> getRisicosByMiddelId(Long middelId) {
        return middelRisicoRepository.findAllByMiddelId(middelId);
    }

    public List<EntiteitMiddelRisico> getEntiteitMiddelRisicos(Long entiteitNummer) {
        return entiteitMiddelRisicoRepository.findEntiteitMiddelRisicosByEntiteitNummer(entiteitNummer);
    }

    public void saveEntiteitMiddelRisico (EntiteitMiddelRisico entiteitMiddelRisico) {
        entiteitMiddelRisicoRepository.save(entiteitMiddelRisico);
    }

    public void deleteEntiteitMiddelRisico (Long id) {
        entiteitMiddelRisicoRepository.deleteById(id);
    }

    public EntiteitMiddelKenmerk findEntiteitMiddelKenmerkById (Long id){
        return entiteitMiddelKenmerkRepository.findEntiteitMiddelKenmerkById(id);
    }

    public MiddelRisico findLowestLevelMiddelRisicoFromEntiteitMiddelRisico(EntiteitMiddelRisico emr){
        return emr.getSubRisicoId() == null ?
                middelRisicoRepository.findMiddelRisicoById(emr.getHoofdRisicoId()) :
                middelRisicoRepository.findMiddelRisicoById(emr.getSubRisicoId());
    }

    public MiddelKenmerk findLowestLevelMiddelKenmerkFromEntiteitMiddelKenmerk(EntiteitMiddelKenmerk emk){
        if(emk.getSubKenmerk3Id() != null)
            return middelKenmerkRepository.findMiddelKenmerkById(emk.getSubKenmerk3Id());
        else if(emk.getSubKenmerk2Id() != null)
            return middelKenmerkRepository.findMiddelKenmerkById(emk.getSubKenmerk2Id());
        else if(emk.getSubKenmerk1Id() != null)
            return middelKenmerkRepository.findMiddelKenmerkById(emk.getSubKenmerk1Id());
        else
            return middelKenmerkRepository.findMiddelKenmerkById(emk.getHoofdKenmerkId());
    }

    //todo: possibly use in IVAKBS-225
    public List<KenmerkRisicosKoppeling> findAllPossibleRisicosForMiddelKenmerkById(Long kenmerkId){
        return kenmerkRisicoKoppelingRepository.findAllByMiddelKenmerkId(kenmerkId);
    }

    public List<KenmerkRisicosKoppeling> findAllPossibleKenmerkenForMiddelRisicoById(Long risicoId){
        return kenmerkRisicoKoppelingRepository.findAllByMiddelRisicoId(risicoId);
    }

    //find all possible kenmerken to be koppeld to risico and checks if there is an EntiteitMiddelKenmerk with that kenmerk
    //returns EntiteitMiddelKenmerk ID and MiddelKenmerk KENMERK
    public Map<Long, MiddelKenmerk> findAllEntiteitMiddelKenmerkenForRisico(Long entiteitNummer, Long risicoId){
        List<KenmerkRisicosKoppeling> arr = findAllPossibleKenmerkenForMiddelRisicoById(risicoId);
        List<EntiteitMiddelKenmerk> arr1 = entiteitMiddelKenmerkRepository.findEntiteitMiddelKenmerkByEntiteitNummer(entiteitNummer);

        HashMap<Long, MiddelKenmerk> toReturn = new HashMap<>();
        for(KenmerkRisicosKoppeling krk: arr){
            for(EntiteitMiddelKenmerk emk: arr1)
                if(krk.getMiddelKenmerk().getId().equals(findLowestLevelMiddelKenmerkFromEntiteitMiddelKenmerk(emk).getId()))
                    toReturn.put(emk.getId(), krk.getMiddelKenmerk());
        }
        return toReturn;
    }

    //sorting method to see which EntiteitMiddelRisicos contain MiddelRisicos for a specific middel
    public List<EntiteitMiddelRisico> getEntiteitMiddelRisicosForEntiteitEnMiddel(Long entiteitNummer, Long middelId) {
        List<EntiteitMiddelRisico> all = getEntiteitMiddelRisicos(entiteitNummer);
        List<EntiteitMiddelRisico> filtered = new ArrayList<>();
        MiddelRisico middelRisico;
        for(EntiteitMiddelRisico emr: all){
            middelRisico = findLowestLevelMiddelRisicoFromEntiteitMiddelRisico(emr);
            if(middelRisico.getMiddelId().equals(middelId))
                filtered.add(emr);
        }
        return filtered;
    }
}
