package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerkId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;

import java.util.Optional;

@Repository
public interface EntiteitKenmerkRepository extends JpaRepository<EntiteitKenmerk, EntiteitKenmerkId> {
    Optional<EntiteitKenmerk> findAllByEntiteitKenmerkId(EntiteitKenmerkId entiteitKenmerkId);
}
