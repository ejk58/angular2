/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: EntiteitMapper.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 6-5-2021 14:32
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.mappings;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import nl.belastingdienst.iva.wd.kbs.domain.ZooOmvang;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KrbEntiteit;

@Mapper(componentModel = "spring")
public interface ZooOmvangMapper {

	/**
	 * Updates an existing instance of ZooOmvang with matching property values from another instance. Ignored properties:
	 * <ul>
	 *     <li>entiteitNummer</li>
	 *     <li>lastUpdated</li>
	 *     <li>lastUpdatedByUserId</li>
	 * </ul>
	 *
	 * @see <a href="https://mapstruct.org/documentation/stable/reference/html/#updating-bean-instances">relevant MapStruct
	 * documentation</a>
	 */
	@Mapping(target = "entiteitNummer", ignore = true)
	@Mapping(target = "lastUpdated", ignore = true)
	@Mapping(target = "lastUpdatedByUserId", ignore = true)
	ZooOmvang update(@MappingTarget ZooOmvang instanceToUpdate, ZooOmvang instanceToCopyFrom);

	/**
	 * Updates an existing instance of ZooOmvang with matching property values from a KrbEntiteit.
	 */
	// Properties with identical names between target Entiteit and source KtaEntiteit: entiteitNummer, wolbSom
	@Mapping(target = "entiteitNummer", ignore = true)
	ZooOmvang update(@MappingTarget ZooOmvang instanceToUpdate, KrbEntiteit instanceToCopyFrom);
}