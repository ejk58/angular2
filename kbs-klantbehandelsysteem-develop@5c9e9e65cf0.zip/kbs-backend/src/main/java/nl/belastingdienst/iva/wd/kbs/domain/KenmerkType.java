package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.Getter;

/**
 * For an explanation, see: kbs-klantbehandelsysteem\kbs-frontend\src\app\services\kenmerkType.ts
 */
@Getter
public enum KenmerkType {
    AG("AG"),
    CBAP("CBAP"),// cijferbeoordeling actiepunten
    CBAPW("CBAPW"),// cijferbeoordeling actiepunten winst en verlies
    CBAPB("CBAPB"),// cijferbeoordeling actiepunten balans
    CBOBA("CBOBA"), // cijferbeoordeling attentiepunten
    CBIBV("CBIBV"), // cijferbeoordeling attentiepunten Inkomsten belasting en volksverzekeringen
    MID("MID"),
    BCAV("BCAV"),
    RM(  "RM"),
    GS(  "GS"),
    EO ( "EO"),
    BS ( "BS"),
    SECTR ( "SECTR"),
    CK ( "CK"),
    TEST ( "TEST"),
    RSTAT ( "RSTAT"); //middel specifieke risico statussen

	private final String value;

    KenmerkType(String value) {
        this.value = value;
    }
}
