/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: EntiteitMapper.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 6-5-2021 14:32
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.mappings;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import nl.belastingdienst.iva.wd.kbs.domain.Entiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.OrgEntiteit;

@Mapper(componentModel = "spring")
public interface EntiteitMapper {

	/**
	 * Maps a KTA entiteit to a new, JPA-unmanaged instance of Entiteit.
	 */
	// Properties with identical names between target Entiteit and source KtaEntiteit: n/a
	@Mapping(target = "nummer", source = "dosnr")
	@Mapping(target = "naam", source = "dosnaam")
	@Mapping(target = "kantoorCode", source = "kantoorId")
	@Mapping(target = "kantoorNaam", source = "kantnm")
	@Mapping(target = "teamCode", source = "dosteam")
	@Mapping(target = "teamNaam", source = "teamomschr")
	//@Mapping(target = "", source = "formatiedat")
	//@Mapping(target = "", source = "ontbinddat")

	/* TODO IVAKBS-32: Map the remaining properties below from the DTO to the entity.*/
	//@Mapping(target = "adres", source = "")

	//@Mapping(target = "bestuurlijkVerband", source = "")

	@Mapping(target = "brancheCode", source = "branchecd")
	@Mapping(target = "brancheNaam", source = "omschr")

	//@Mapping(target = "klantCoordinator", source = "")
	//@Mapping(target = "klantGroep", source = "")
	//@Mapping(target = "klantpakket", source = "")
	Entiteit map(KtaEntiteit dto);

	/**
	 * Maps a List of KTA entiteiten to a List of new, JPA-unmanaged instances of Entiteit.
	 */
	List<Entiteit> map(List<KtaEntiteit> dtoList);

	/**
	 * Updates an existing instance of Entiteit with matching property values from an OrgEntiteit.
	 * @see <a href="https://mapstruct.org/documentation/stable/reference/html/#updating-bean-instances">relevant MapStruct documentation</a>
	 */
	// Properties with identical names between target Entiteit and source KtaEntiteit: n/a
	//@Mapping(target = "", source = "")
	Entiteit update(OrgEntiteit dto, @MappingTarget Entiteit e);
}