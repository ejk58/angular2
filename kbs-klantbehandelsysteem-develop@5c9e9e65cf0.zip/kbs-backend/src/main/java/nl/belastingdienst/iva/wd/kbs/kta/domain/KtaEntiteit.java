/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: Entiteit.java
 *             Auteur: schop13
 *    Creatietijdstip: 7-4-2021 11:41
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.kta.domain;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(schema = "KTAA05", name = "VW048_ENTITEIT_BASISGEGEVENS") // TODO: Make schema a configurable property. On first look it cannot be removed because of JPA errors: DB2 SQL Error: SQLCODE=-204, SQLSTATE=42704, SQLERRMC=$AKZB83.VW048_ENTITEIT_BASISGEGEVENS, DRIVER=4.25.1301
@Data // TODO Jelle: JPA Buddy-plugin complains about this annotation being unsafe?
public class KtaEntiteit {

	/**
	 * dosnr is actually a Long (INTEGER in the database), but we treat it as a String so
	 * we can perform partial String matches during a query-by-example in
	 * {@link nl.belastingdienst.iva.wd.kbs.service.EntiteitService#search(KtaEntiteit)}.
	 */
	@Id
	private String dosnr;
	private String dosnaam;
	private Long kantoorId;
	private String kantnm;
	private String dosteam;
	private String teamomschr;
	private Date formatiedat;
	private Date ontbinddat;
	private Long branchecd;
	private String omschr;
}
