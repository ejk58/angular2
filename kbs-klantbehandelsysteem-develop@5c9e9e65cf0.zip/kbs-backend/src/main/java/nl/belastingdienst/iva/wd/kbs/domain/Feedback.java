/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: Feedback.java
 *             Auteur: schop13
 *    Creatietijdstip: 15-4-2021 11:33
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Data // TODO Jelle: JPA Buddy-plugin complains about this annotation being unsafe?
@Entity
public class Feedback {

	public static final String REGEX_BELASTINGDIENST_EMAIL = "^.+@belastingdienst\\.nl$";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Setter(AccessLevel.NONE)
	private Long id;

	@NotBlank
	@Size(max = 200)
	private String naam;

	@NotBlank
	@Size(max = 50)
	@Email(regexp = REGEX_BELASTINGDIENST_EMAIL)
	private String email;

	@NotBlank
	@Size(max = 250)
	private String melding;

	@NotBlank
	@Size(max = 200)
	private String pagina;

	@Column(name = "USERID")
	@NotBlank
	@Size(max = 8)
	private String userId;

	@NotNull
	@Size(max = 50)
	private String rollen;

	@NotNull
	@PastOrPresent
	private LocalDateTime created;

	@Column(name = "VERSION_INFO")
	public String versionInfo;

	@Transient
	private VersionInformation versionInformation;
}
