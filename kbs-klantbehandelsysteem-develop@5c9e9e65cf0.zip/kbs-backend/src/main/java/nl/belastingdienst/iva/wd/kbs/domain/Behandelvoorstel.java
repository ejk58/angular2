package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Behandelvoorstel {
	private String middel;
	private String heffing;
	private String beroep;
	private String bezwaar;
	private String controle;
	private String vooroverleg;
	private String invordering;
	private String overig;
	private String totalen;
}
