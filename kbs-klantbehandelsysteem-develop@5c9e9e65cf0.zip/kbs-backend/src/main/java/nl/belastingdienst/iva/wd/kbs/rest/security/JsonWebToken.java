/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: JWTToken.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 10-5-2021 11:15
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.rest.security;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;

@Data
public class JsonWebToken {

	public static final String HEADER_AUTHORIZATION = "Authorization";
	public static final String BODY_BEARER = "Bearer ";

	/**
	 * Subject
	 */
	private String sub;
	/**
	 * Timestamp (in seconds since Unix epoch) when token expires
	 */
	private Instant exp;
	/**
	 * Roles
	 */
	private List<String> authorities;

	public static JsonWebToken fromTokenString(ObjectMapper mapper, String encodedToken) {
		String decodedToken = decodeTokenBody(encodedToken);

		try {
			return mapper.readValue(decodedToken, JsonWebToken.class);
		} catch (JsonProcessingException e) {
			throw new RuntimeException("Fout opgetreden bij het parsen van het JsonWebToken", e);
		}
	}

	private static String decodeTokenBody(String encodedToken) {
		encodedToken = encodedToken.replace(BODY_BEARER, "");
		String[] parts = encodedToken.split("\\.");
		byte[] bytes = Base64.getUrlDecoder().decode(parts[1]);
		return new String(bytes, StandardCharsets.UTF_8);
	}
}
