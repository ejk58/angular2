package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppelingCompositeId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KenmerkRisicoKoppelingRepository extends JpaRepository<KenmerkRisicosKoppeling, KenmerkRisicosKoppelingCompositeId> {
    List<KenmerkRisicosKoppeling> findAllByMiddelKenmerkId(Long middelKenmerkId);
    List<KenmerkRisicosKoppeling> findAllByMiddelRisicoId(Long middelRisicoId);
}
