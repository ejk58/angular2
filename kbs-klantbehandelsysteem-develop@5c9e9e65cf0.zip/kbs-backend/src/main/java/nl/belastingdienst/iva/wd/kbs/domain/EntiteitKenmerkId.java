package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Getter
public class EntiteitKenmerkId implements Serializable {
    @Column(name="BSN_RSIN")
    private Long bsnRsin;

    @Column(name="KENMERK_TYPE")
    private String kenmerkType;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EntiteitKenmerkId)) return false;
        EntiteitKenmerkId that = (EntiteitKenmerkId) o;
        return bsnRsin.equals(that.bsnRsin) && kenmerkType.equals(that.kenmerkType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(bsnRsin, kenmerkType);
    }
}
