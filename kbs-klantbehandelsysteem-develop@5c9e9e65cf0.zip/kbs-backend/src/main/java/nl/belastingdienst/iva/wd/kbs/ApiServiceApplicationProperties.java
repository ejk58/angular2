package nl.belastingdienst.iva.wd.kbs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:application.properties")
public class ApiServiceApplicationProperties {

    @Autowired
    private Environment env;

    public String getOrgGegevensBaseUrl() {
        return env.getProperty("org.gegevens.base.url");
    }

    public String getApiKeyKantoorteam() {
        return env.getProperty("api.key.kantoorteam");
    }

    public String getApiKeyKlantgroep() {
        return env.getProperty("api.key.klantgroep");
    }

    public String getApiKeyBehandelteam() {
        return env.getProperty("api.key.behandelteam");
    }

    public String getWijzenBehandelteamUrl() {
        return env.getProperty("wijzen.behandelteam.gegevens.url");
    }
}
