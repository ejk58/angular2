package nl.belastingdienst.iva.wd.kbs.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;


@Deprecated
@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
public class ApiValidationError {
    private String field;
    private String rejectedValue;
    private String message;
}
