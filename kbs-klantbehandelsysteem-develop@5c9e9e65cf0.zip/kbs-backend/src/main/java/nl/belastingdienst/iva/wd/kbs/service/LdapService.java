package nl.belastingdienst.iva.wd.kbs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.common.springboot.security.LdapGroup;
import nl.belastingdienst.iva.common.springboot.security.LdapGroupAttributesMapper;
import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.security.LdapPersonAttributesMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Deprecated
@Service
@Scope(value = "singleton")
@Slf4j
@RequiredArgsConstructor
public class LdapService {

	private final Environment environment;
	private final LdapTemplate ldapTemplate;

	@Timed
	public List<LdapPerson> getControleLeidersFromAugGroup(String augGroup) {
		List<LdapPerson> result = new ArrayList<>();
		LdapGroup controleurGroup = getLdapGroup("aug_pat_controleur");
		LdapGroup kzbKantoorGroup = getLdapGroup(augGroup);

		if (controleurGroup != null && kzbKantoorGroup != null) {
			// Alleen controleurs die ook in kzbKantoor voorkomen
			List<String> userIds = controleurGroup.getMembers().stream().filter(m -> kzbKantoorGroup.getMembers().contains(m))
					.collect(Collectors.toList());
			userIds.stream().forEach(member -> {
				LdapPerson ldapPerson = this.getPerson(member);
				if (ldapPerson != null)
					result.add(ldapPerson);
			});
		}
		return result;
	}

	private LdapGroup getLdapGroup(String augGroup) {
		LdapGroup result = null;
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("group").and("cn").is(augGroup);
		List<LdapGroup> adGroepen = ldapTemplate.search(query, new LdapGroupAttributesMapper());
		if (adGroepen.size() == 1) {
			result = adGroepen.get(0);
		}
		return result;
	}

	public List<LdapPerson> getPersons(String userid) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
				.is(userid.trim());
		return ldapTemplate.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));
	}

	public LdapPerson getPerson(String userid) {
		List<LdapPerson> ldapPersonList = getPersons(userid);
		if (ldapPersonList.size() != 1) {
			log.warn("Persoon met userid {} is niet aanwezig in ldap", userid);
			return null;
		}
		return ldapPersonList.get(0);
	}

	public boolean isAdGroep(String werkgroep) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("group").and("cn").is(werkgroep);
		List<LdapGroup> adGroepen = ldapTemplate.search(query, new LdapGroupAttributesMapper());
		return adGroepen.size() == 1;
	}
}
