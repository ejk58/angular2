package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "ENTITEIT_MIDDEL_RISICO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EntiteitMiddelRisico {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @Column(name = "ENTITEITNUMMER")
    private Long entiteitNummer;
    @Column(name = "ENTITEIT_MIDDEL_KENMERK_ID")
    private Long entiteitMiddelKenmerkId;
    @Column(name = "HOOFDRISICO_ID")
    private Long hoofdRisicoId;
    @Column(name = "SUBRISICO_ID")
    private Long subRisicoId;
    @Column(name = "KEY_RISK")
    private Short keyRisk;
    @Column(name = "STATUS_ID")
    private Long statusId;
    @Column(name = "RANK")
    private Long rank;
}
