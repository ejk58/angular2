/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.common.springboot.exceptions.NetworkException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Component
@RequiredArgsConstructor
@Slf4j
public class RestTemplateClient {

    private final RestTemplate restTemplate;

    public <T, U> ResponseEntity<U> doRequest(HttpMethod httpMethod, URI uri, T body, Class<T> requestClazz, Class<U> responseClass, String xAPIKey) {
        HttpHeaders headers = getHeaders(xAPIKey);
        HttpEntity<T> request = new HttpEntity<>(body, headers);
        ResponseEntity<U> response = null;
        try {
            response = restTemplate.exchange(uri, httpMethod, request, responseClass);

        } catch (RestClientException e) {
            throw new NetworkException(e.getLocalizedMessage());
        }
        if (response.getStatusCode() == BAD_REQUEST) {
            log.error(response.getBody().toString());
        }
        return response;
    }

    private HttpHeaders getHeaders(String xAPIKey) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-APIKEY", xAPIKey);
        headers.set("Accept", "application/json");
        return headers;

    }
}
