package nl.belastingdienst.iva.wd.kbs.rest;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FakeResponseTime {

    @Autowired
    private Environment env;

    private Boolean useFakeResonseTime = null;

    public void fakeResponseTime() {
        if (useFakeResonseTime == null) {
            useFakeResonseTime = Boolean.parseBoolean(env.getProperty("kbs.use.fake.responsetime", "false"));
            if (useFakeResonseTime) { log.debug("Using fake responsetime."); }
            else { log.debug("Skipping fake responsetime."); }
        }
        if (useFakeResonseTime) {
            Random rnd = new Random(System.currentTimeMillis());
            try {
                int sleepTime = rnd.nextInt(7);
                System.out.println("Sleeping " + sleepTime + " sec.");
                TimeUnit.SECONDS.sleep(sleepTime);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
