package nl.belastingdienst.iva.wd.kbs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.domain.ZooOmvang;

@Repository
public interface ZooOmvangRepository extends JpaRepository<ZooOmvang, Long> {
}
