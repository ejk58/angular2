package nl.belastingdienst.iva.wd.kbs.exception;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.List;


@Deprecated
@Getter
@Setter
@ToString
public class ApiError {
    private String type;
    private String title;
    private String detail = "";
    private String instance = "";
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    private LocalDateTime timestamp;
    private List<ApiValidationError> validationErrors;

    ApiError(ErrorType type, String detail) {
        timestamp = LocalDateTime.now();
        this.type = type.getType();
        this.title = type.getTitle();
        this.detail = detail;
    }

    ApiError(ErrorType type, String detail, String instance) {
        this(type, detail);
        this.instance = instance;
    }
}

