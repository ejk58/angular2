package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.EntiteitMiddelKenmerk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EntiteitMiddelKenmerkRepository extends JpaRepository<EntiteitMiddelKenmerk, Long> {

    List<EntiteitMiddelKenmerk> findEntiteitMiddelKenmerkByEntiteitNummer(Long entiteitNummer);
    EntiteitMiddelKenmerk findEntiteitMiddelKenmerkById(Long id);

}
