package nl.belastingdienst.iva.wd.kbs.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkWithValuesDto;
import nl.belastingdienst.iva.wd.kbs.domain.MultiSelectKenmerk;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitKenmerkService;
import nl.belastingdienst.iva.wd.kbs.service.KenmerkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/kenmerken")
public class KenmerkController {

    @Autowired
    private KenmerkService kenmerkService;
    @Autowired
    private EntiteitKenmerkService entiteitKenmerkService;

    @GetMapping()
    public List<Kenmerk> getKenmerken() {
        List<Kenmerk> kenmerken = kenmerkService.getKenmerken();
        if (kenmerken.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No kenmerken found.");
        }
        return kenmerken;
    }

    @GetMapping("/testKenmerken")
    public List<Kenmerk> getTestKenmerken() {
        return kenmerkService.findTestKenmerken();
    }

    @GetMapping("/middelen")
    public List<Kenmerk> getZooMiddelen() {
        return kenmerkService.findZooEntiteitMiddelen();
    }

    @GetMapping("/attentiepunten")
    public List<Kenmerk> getZooAttentiepunten() {
        return kenmerkService.findZooEntiteitAttentiepunten();
    }

    @GetMapping("/aandachtsgebieden")
    public List<Kenmerk> getZooAandachtsgebieden() {
        return kenmerkService.findZooEntiteitAandachtsgebieden();
    }

    @GetMapping("/bedrijfsstrategien")
    public List<Kenmerk> getBedrijfsstrategien() {
        return kenmerkService.findBedrijfsstrategieKenmerken();
    }

    @GetMapping("/externeOmgeving")
    public List<Kenmerk> getExterneOmgeving() {
        return kenmerkService.findExterneOmgevingKenmerken();
    }

    @GetMapping("/governanceStructuur")
    public List<Kenmerk> getGovernanceStructuur() {
        return kenmerkService.findGovernanceStructuurKenmerken();
    }

    @GetMapping("/risicomanagement")
    public List<Kenmerk> getRisicomanagement() {
        return kenmerkService.findRisicomanagementKenmerken();
    }

    @GetMapping("/branche-code-aanvullingen")
    public List<Kenmerk> getZooBranchecodeAanvullingen() {
        return kenmerkService.findZooBranchecodeAanvullingen();
    }

    @GetMapping("/complexiteit")
    public List<Kenmerk> getComplexiteitKenmerken() {
        return kenmerkService.findComplexiteitKenmerken();
    }

    @GetMapping("/cijferbeoordeling/actiepunten")
    public List<Kenmerk> getActiepuntenKenmerken() {
        return kenmerkService.actiePuntenKenmerken();
    }

    @GetMapping("/cijferbeoordeling/actiepunten-balans")
    public List<Kenmerk> getActiepuntenBalansKenmerken() {
        return kenmerkService.actiePuntenBalansKenmerken();
    }

    @GetMapping("/cijferbeoordeling/actiepunten-winst-en-verlies")
    public List<Kenmerk> getActiepuntenWinstEnVerliesKenmerken() {
        return kenmerkService.actiePuntenWinstEnVerliesKenmerken();
    }

    @GetMapping("/{bsnRsin}/complexiteit/selected")
    public List<Kenmerk> getSelectedComplexiteitKenmerken(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedComplexiteitKenmerken(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/aandachtsgebieden/selected")
    public List<KenmerkWithValuesDto> getSelectedAandachtsgebieden(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedAandachtsgebieden(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        List<Kenmerk> kenmerkenlist = entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
        List<KenmerkWithValuesDto> result = new ArrayList<>();
        for (Kenmerk kenmerk : kenmerkenlist) {
            KenmerkWithValuesDto kwd = new KenmerkWithValuesDto();
            kwd.setId(kenmerk.getId());
            kwd.setKenmerk(kenmerk.getKenmerk());
            kwd.setGroep(kenmerk.getGroep());
            kwd.setValues("false");
            if (!entiteitKenmerk.get().getValues().isEmpty()) {
                var values = entiteitKenmerk.get().getValues();
                if (values.contains(kenmerk.getId())) {
                    kwd.setValues("true");
                }
            }
            result.add(kwd);
        }
        return result;
    }

    @GetMapping("/{bsnRsin}/middelen/selected")
    public List<Kenmerk> geSelectedMiddelen(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedMiddelen(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/{name}/{groep}/middel/selected")
    public Kenmerk getSelectedMiddelByNameAndGroup(@PathVariable Long bsnRsin, @PathVariable String name, @PathVariable String groep) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedMiddelen(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return null;
        }
        List<Kenmerk>  list =  entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
        return list.stream().
                filter(k -> k.getKenmerk().equals(name) && k.getGroep().equals(groep))
                .findAny()
                .orElse(null);
    }

    @GetMapping("/{bsnRsin}/attentiepunten/selected")
    public List<Kenmerk> geSelectedAttentiepunten(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedAttentiepunten(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/actiepunten/selected")
    public List<Kenmerk> geSelectedActiepunten(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedActiepunten(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/actiepunten-balans/selected")
    public List<Kenmerk> geSelectedActiepuntenBalans(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedActiepuntenBalans(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/actiepunten-winst-en-verlies/selected")
    public List<Kenmerk> geSelectedActiepuntenWinstEnVerlies(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedActiepuntenWinstenVerlies(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/bedrijfsstrategien/selected")
    public List<Kenmerk> geSelectedBedrijfsstrategien(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedBedrijfsstrategieen(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/externeOmgeving/selected")
    public List<Kenmerk> getSelectedExterneOmgeving(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedExterneOmgevingKenmerken(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/governanceStructuur/selected")
    public List<Kenmerk> getSelectedGovernanceStructuur(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedGovernanceStructuurKenmerken(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/risicomanagement/selected")
    public List<Kenmerk> getSelectedRisicomanagement(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedRisicomanagementKenmerken(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/attentiepunten-inkomstenbelasting")
    public List<MultiSelectKenmerk> getZooAttentiepuntenInkomstenBelasting() {

        List<Kenmerk> kenmerken = kenmerkService.findZooEntiteitAttentiepuntenInkomstenBelasting();

        List<Kenmerk> groups = kenmerken.stream()
                .filter(kenmerk -> kenmerk.getKenmerkParentId() == null)
                .collect(Collectors.toList());
        List<Kenmerk> items = kenmerken.stream()
                .filter(kenmerk -> kenmerk.getKenmerkParentId() != null)
                .collect(Collectors.toList());

        List<MultiSelectKenmerk> result = new ArrayList<>();
        for (Kenmerk group : groups) {
            result.add(new MultiSelectKenmerk(group.getId(), group.getKenmerk()));
        }

        for (Kenmerk child : items) {
            result.stream()
                    .filter(p -> p.getId().equals(child.getKenmerkParentId()))
                    .findFirst()
                    .ifPresent(group -> group.getItems().add(child));
        }
        return result;
    }

    @GetMapping("/{bsnRsin}/attentiepunten-inkomstenbelasting/selected")
    public List<Kenmerk> getSelectedActiepuntIds(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedAttentiepuntIds(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return Collections.emptyList();
        }
        return entiteitKenmerk.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @PostMapping("/{bsnRsin}/{kenmerkType}/selection-ids/save")
    public void saveSelectedIds(@PathVariable Long bsnRsin,
                                @PathVariable String kenmerkType,
                                @RequestBody List<Integer> kenmerkIds) {
        entiteitKenmerkService.saveEntiteitKenmerkIds(bsnRsin, kenmerkType, kenmerkIds);
    }

    @PostMapping("/{bsnRsin}/{kenmerkType}/selections/save")
    public void saveSelectedKenmerken(@PathVariable Long bsnRsin,
                                      @PathVariable String kenmerkType,
                                      @RequestBody List<KenmerkWithValuesDto> kenmerken) {
        entiteitKenmerkService.saveEntiteitKenmerken(bsnRsin, kenmerkType, kenmerken);
    }

    @PostMapping("/{bsnRsin}/{kenmerkType}/selectedAandachtsgebieden/save")
    public void saveSelectedAandachtsgebieden(@PathVariable Long bsnRsin,
                                              @PathVariable String kenmerkType,
                                              @RequestBody List<KenmerkWithValuesDto> kenmerken) {
        entiteitKenmerkService.saveEntiteitKenmerken(bsnRsin, kenmerkType, kenmerken);
    }

    @GetMapping("/{entiteitNummer}/zoo/branchecodeaanvulling/selected")
    public List<Kenmerk> getEntiteitKenmerkAanvullingenBranchecode(@PathVariable Long entiteitNummer) {
        Optional<EntiteitKenmerk> result = entiteitKenmerkService.getBranchecodeAanvullingen(entiteitNummer);
        if (result.isEmpty()) {
            return Collections.emptyList();
        }
        return result.get().getKenmerken()
                .stream()
                .map(kenmerkService::getKenmerkOrNull)
                .collect(Collectors.toList());
    }

    @GetMapping("/{bsnRsin}/sector")
    public Integer getZooAardSector(@PathVariable Long bsnRsin) {
        Optional<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedSector(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return null;
        }
        return entiteitKenmerk.get().getKenmerken().stream().findFirst().orElse(null);
    }

    @PostMapping("/{bsnRsin}/sector")
    public void saveZooAardSector(@PathVariable Long bsnRsin, @RequestBody int sector) {
        entiteitKenmerkService.saveSelectedSector(bsnRsin, sector);
    }
}