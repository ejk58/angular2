package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Table(name = "ENTITEIT_KENMERK")
@Data
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EntiteitKenmerk {
	@EmbeddedId
	private EntiteitKenmerkId entiteitKenmerkId;

	@Column(name="KENMERKEN")
	private String kenmerken;

	@Column(name="VALUES")
	private String values;

	public EntiteitKenmerk(EntiteitKenmerkId entiteitKenmerkId, String kenmerken) {
		this.kenmerken = kenmerken;
		this.entiteitKenmerkId = entiteitKenmerkId;
	}

	public List<Integer> getKenmerken() {
		if (kenmerken == null || kenmerken.isEmpty()) {
			return Collections.emptyList();
		}
		return Arrays.stream(kenmerken.split(",")).map(Integer::parseInt).collect(Collectors.toList());
	}

	public void setKenmerken(List<Integer> kenmerken) {
		this.kenmerken = kenmerken.stream().map(Object::toString).collect(Collectors.joining(","));
	}
	public void setValues(List<Integer> valueNumbers) {
		this.values = valueNumbers.stream().map(Object::toString).collect(Collectors.joining(","));
	}
	public List<Integer> getValues() {
		if (values == null || values.isEmpty()) {
			return Collections.emptyList();
		}
		return Arrays.stream(values.split(",")).map(Integer::parseInt).collect(Collectors.toList());
	}
}
