package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.OneToOne;
import javax.persistence.JoinColumn;
import java.io.Serializable;


@Entity
@Table(name = "KENMERK_RISICOS_KOPPELING")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class KenmerkRisicosKoppeling implements Serializable {
    @EmbeddedId
    private KenmerkRisicosKoppelingCompositeId compositeId;

    @OneToOne
    @JoinColumn(name = "MIDDEL_KENMERK_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    private MiddelKenmerk middelKenmerk;

    @OneToOne
    @JoinColumn(name = "MIDDEL_RISICO_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    private MiddelRisico middelRisico;
}
