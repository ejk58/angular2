package nl.belastingdienst.iva.wd.kbs.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.service.FiscaliteitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/fiscaliteit")
public class FiscaliteitController {

    @Autowired
    private FiscaliteitService fiscaliteitService;

    //kenmerken
    @GetMapping("/middelKenmerken")
    public List<MiddelKenmerk> getMiddelKenmerken() {
        return fiscaliteitService.getMiddelKenmerken();
    }

    @GetMapping("/{middelId}/middelKenmerken")
    public List<MiddelKenmerk> getKenmerkenByMiddelId(@PathVariable Long middelId) {
        return fiscaliteitService.getKenmerkenByMiddelId(middelId);
    }

    @GetMapping("/{entiteitNummer}/entiteitMiddelKenmerken")
    public List<EntiteitMiddelKenmerk> getSelectedEntiteitMiddelKenmerken(@PathVariable Long entiteitNummer) {
        return fiscaliteitService.getEntiteitMiddelKenmerken(entiteitNummer);
    }

    @DeleteMapping("/{id}/deleteEntiteitMiddelKenmerk")
    public void deleteEntiteitMiddelKenmerk(@PathVariable Long id) {
        //TODO: remove EntiteitMiddelRisico where EntiteitMiddelKenmerkId == id - Discuss with @Charlottha
        fiscaliteitService.deleteEntiteitMiddelKenmerk(id);
    }

    @PostMapping("/addEntiteitMiddelKenmerk")
    public void addEntiteitMiddelKenmerk(@RequestBody EntiteitMiddelKenmerk entiteitMiddelKenmerk) {
        fiscaliteitService.saveEntiteitMiddelKenmerk(entiteitMiddelKenmerk);
    }

    @PostMapping("/updateEntiteitMiddelKenmerk")
    public void updateEntiteitMiddelKenmerk(@RequestBody EntiteitMiddelKenmerk entiteitMiddelKenmerk) {
        EntiteitMiddelKenmerk toUpdate = fiscaliteitService.getEntiteitMiddelKenmerkById(entiteitMiddelKenmerk.getId()).orElse(null);
        if (toUpdate != null) {
            toUpdate.setHoofdKenmerkId(entiteitMiddelKenmerk.getHoofdKenmerkId());
            toUpdate.setSubKenmerk1Id(entiteitMiddelKenmerk.getSubKenmerk1Id());
            toUpdate.setSubKenmerk2Id(entiteitMiddelKenmerk.getSubKenmerk2Id());
            toUpdate.setSubKenmerk3Id(entiteitMiddelKenmerk.getSubKenmerk3Id());
            toUpdate.setRank(entiteitMiddelKenmerk.getRank());
            fiscaliteitService.saveEntiteitMiddelKenmerk(toUpdate);
        }
    }

    //risicos
    @GetMapping("/{middelId}/middelRisicos")
    public List<MiddelRisico> getRisicosByMiddelId(@PathVariable Long middelId) {
        return fiscaliteitService.getRisicosByMiddelId(middelId);
    }

    @GetMapping("/{id}/entiteitMiddelKenmerk")
    public EntiteitMiddelKenmerk getEntiteitMiddelKenmerkById(@PathVariable Long id) {
        return fiscaliteitService.getEntiteitMiddelKenmerkById(id).orElse(null);
    }

    @DeleteMapping("/{id}/deleteEntiteitMiddelRisico")
    public void deleteEntiteitMiddelRisico(@PathVariable Long id) {
        fiscaliteitService.deleteEntiteitMiddelRisico(id);
    }

    @GetMapping("/middelRisicos")
    public List<MiddelRisico> getMiddelRisicos() {
        return fiscaliteitService.getMiddelRisicos();
    }

    @GetMapping("/middelRisicoStatussen")
    public List<Kenmerk> getMiddelRisicoStatussen() {
        return fiscaliteitService.getZoFMiddelRisicoStatussen();
    }

    @GetMapping("/{entiteitNummer}/{middelId}/selectedEntiteitMiddelRisicos")
    public List<EntiteitMiddelRisico> getSelectedEntiteitMiddelRisicos(@PathVariable Long entiteitNummer, @PathVariable Long middelId) {
        return fiscaliteitService.getEntiteitMiddelRisicosForEntiteitEnMiddel(entiteitNummer, middelId);
    }

    @PostMapping("/addEntiteitMiddelRisico")
    public void addEntiteitMiddelRisico(@RequestBody EntiteitMiddelRisico entiteitMiddelRisico) {
        fiscaliteitService.saveEntiteitMiddelRisico(entiteitMiddelRisico);
    }

    @GetMapping("/getKenmerkenForRisico/{middelRisicoId}")
    public List<KenmerkRisicosKoppeling> getKenmerkenForRisico(@PathVariable Long middelRisicoId){
        return fiscaliteitService.findAllPossibleKenmerkenForMiddelRisicoById(middelRisicoId);
    }

    @GetMapping("/{entiteitNummer}/getEntiteitMiddelKenmerkenForRisico/{middelRisicoId}")
    public Map<Long, MiddelKenmerk> getEntiteitMiddelKenmerkenForRisico(@PathVariable Long entiteitNummer, @PathVariable Long middelRisicoId){
        return fiscaliteitService.findAllEntiteitMiddelKenmerkenForRisico(entiteitNummer, middelRisicoId);
    }
}
