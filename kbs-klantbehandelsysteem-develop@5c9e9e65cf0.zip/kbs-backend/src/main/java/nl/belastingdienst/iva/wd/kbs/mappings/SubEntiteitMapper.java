package nl.belastingdienst.iva.wd.kbs.mappings;

import nl.belastingdienst.iva.wd.kbs.domain.ZooSubEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteitBranche;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaSubEntiteit;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SubEntiteitMapper {


    @Mapping(target = "bsnRsin", source = "bsnRsin")
    @Mapping(target = "soort", source = "soortPersoon")
    @Mapping(target = "naam", source = "naam")
    @Mapping(target = "plaats", source = "plaats")
    @Mapping(target = "startDatum", source = "beginDatum")
    @Mapping(target = "eindDatum", source = "eindDatum")
    ZooSubEntiteit map(KtaSubEntiteit ktaSubEntiteit);

    List<ZooSubEntiteit> map(List<KtaSubEntiteit> list);

    @Mapping(target = "bsnRsin", source = "bsnRsin", ignore = true)
    ZooSubEntiteit update(KtaEntiteitBranche ktaEntiteitBranche, @MappingTarget ZooSubEntiteit e);
}