/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.kta.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

@Entity
@Table(name = "VW156_KZB_ZICHT_OP_ORGANISATIE_ENTITEIT")
@Data
public class KtaSubEntiteit {
    @Id
    @Column(name = "BSN_RSIN")
    private Long bsnRsin;
    @Column(name = "BEGINDATUM")
    private Date beginDatum;
    @Column(name = "EINDDATUM")
    private Date eindDatum;
    private String plaats;
    private String naam;
    @Column(name = "SOORT_PERSOON")
    private String soortPersoon;
    @Column(name = "ENTITEITNUMMER")
    private Long entiteitNummer;
}
