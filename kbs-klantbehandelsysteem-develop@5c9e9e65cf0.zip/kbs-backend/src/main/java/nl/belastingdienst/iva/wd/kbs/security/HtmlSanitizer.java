/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: HtmlSanitizer.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 23-12-2021 16:01
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.security;

import java.util.regex.Pattern;

import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.owasp.html.Sanitizers;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class HtmlSanitizer {

	public static final String ANCHOR = "a";
	public static final String HREF = "href";

	public static final String IMAGE = "img";
	public static final String SRC = "src";

	public static final String DATA = "data";
	/**
	 * Matches values of the src attribute of image elements where the src is a Base-64 encoded (embedded) image (case-insensitive).
	 */
	public static final Pattern EMBEDDED_IMAGE = Pattern.compile("^" + DATA + ":image/.*;base64,.*$", Pattern.CASE_INSENSITIVE);
	private static final PolicyFactory EMBEDDED_IMAGES_ONLY_POLICY = new HtmlPolicyBuilder()
			.allowUrlProtocols(DATA)
			.allowElements(IMAGE)
			// Only allow embedded images in src attribute of img elements, no URLs:
			.allowAttributes(SRC).matching(EMBEDDED_IMAGE).onElements(IMAGE)
			// TODO <IMG SRC=`javascript:alert("RSnake says, 'XSS'")`>
			// TODO https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html
			.toFactory();

	private static final PolicyFactory CUSTOM_ANCHOR_ELEMENTS_POLICY = new HtmlPolicyBuilder()
			.allowStandardUrlProtocols()
			// Allow anchor elements and set target="_blank"
			.allowElements(AnchorElementSanitizer::addOrSetTargetToBlank, ANCHOR)
			// Also allow href attribute on anchor elements
			.allowAttributes(HREF).onElements(ANCHOR)
			.requireRelsOnLinks("noopener", "noreferrer", "nofollow")
			.toFactory();

	public static final PolicyFactory DEFAULT_POLICY = Sanitizers.BLOCKS.and(Sanitizers.FORMATTING)
			.and(CUSTOM_ANCHOR_ELEMENTS_POLICY).and(EMBEDDED_IMAGES_ONLY_POLICY);

	public static String sanitizeHtml(@NonNull String html) {
		String fixedHrefs = AnchorElementSanitizer.sanitizeHrefAttributeIfAnchorElementsPresent(html);
		return DEFAULT_POLICY.sanitize(fixedHrefs);
	}
}
