package nl.belastingdienst.iva.wd.kbs.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;

@Repository
public interface KenmerkRepository extends JpaRepository<Kenmerk, Integer> {
    List<Kenmerk> findByGroepOrderById(String groupname);
}
