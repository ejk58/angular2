package nl.belastingdienst.iva.wd.kbs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.info.Info;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@PropertySource("classpath:application.git.properties")
public class ApplicationInfo implements InfoContributor {

    @Autowired
    private Environment env;

    @Override
    public void contribute(Info.Builder builder) {
        Map<String, String> app = new HashMap<>();
        app.put("application", env.getProperty("applicationDescription"));
        app.put("version", env.getProperty("version"));
        app.put("buildNumber", env.getProperty("buildNumber"));
        app.put("buildTime", env.getProperty("buildTime"));
        app.put("branch", env.getProperty("scmBranch"));
        app.put("dbUrl", env.getProperty("spring.datasource.url"));
        app.put("dbSchema", env.getProperty("spring.datasource.hikari.schema"));

        builder.withDetail("Application", app);
    }
}
