package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MiddelKenmerkRepository extends JpaRepository<MiddelKenmerk, Long> {
    MiddelKenmerk findMiddelKenmerkById(Long id);
    List<MiddelKenmerk> findAllByMiddelId(Long id);
}
