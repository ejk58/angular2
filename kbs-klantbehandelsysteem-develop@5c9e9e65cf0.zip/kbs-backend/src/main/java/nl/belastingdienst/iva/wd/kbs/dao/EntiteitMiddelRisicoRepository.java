package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.EntiteitMiddelRisico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EntiteitMiddelRisicoRepository extends JpaRepository<EntiteitMiddelRisico, Long> {
    EntiteitMiddelRisico findEntiteitMiddelRisicoById(Long id);
    List<EntiteitMiddelRisico> findEntiteitMiddelRisicosByEntiteitNummer(Long entiteitNummer);
    List<EntiteitMiddelRisico> findEntiteitMiddelRisicosByHoofdRisicoIdAndSubRisicoId(Long hoofdRisicoId, Long subRisicoId);
    List<EntiteitMiddelRisico> findEntiteitMiddelRisicosByHoofdRisicoIdAndSubRisicoIdAndAndEntiteitNummer(Long entiteitNummer, Long hoofdRisicoId, Long subRisicoId);
}
