package nl.belastingdienst.iva.wd.kbs.kta.dao;

import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteitBranche;
import org.springframework.stereotype.Repository;

@Repository
public interface KtaEntiteitBrancheRepository extends ReadOnlyJpaRepository<KtaEntiteitBranche, Long> {
    KtaEntiteitBranche findByBsnRsin(Long bsnRsin);

}
