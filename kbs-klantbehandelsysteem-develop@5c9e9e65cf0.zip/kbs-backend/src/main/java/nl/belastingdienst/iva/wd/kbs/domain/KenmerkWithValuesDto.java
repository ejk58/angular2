package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class KenmerkWithValuesDto {
    @Id
    private Integer id;
    private String groep;
    private String kenmerk;
    private String values;
    private Integer kenmerkParentId;
}
