package nl.belastingdienst.iva.wd.kbs.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteiten;

@Repository
public interface SubEntiteitRepository extends JpaRepository<SubEntiteiten, SubEntiteiten.PrimaryKey> {

    List<SubEntiteiten> findAllByEntiteitNummer(Long entiteitNummer);

	@Transactional
    void deleteByEntiteitNummer(Long entiteitNummer);
}
