/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: EntiteitController.java
 *             Auteur: schop13
 *    Creatietijdstip: 7-4-2021 11:38
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.rest.entiteit;

import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.ApiServiceApplicationProperties;
import nl.belastingdienst.iva.wd.kbs.domain.Behandelteam;
import nl.belastingdienst.iva.wd.kbs.domain.Behandelvoorstel;
import nl.belastingdienst.iva.wd.kbs.domain.Convenantindicatie;
import nl.belastingdienst.iva.wd.kbs.domain.Entiteit;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKzbGegevens;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerken;
import nl.belastingdienst.iva.wd.kbs.domain.Opdracht;
import nl.belastingdienst.iva.wd.kbs.domain.OrgKantoorTeam;
import nl.belastingdienst.iva.wd.kbs.domain.OrgKlantGroep;
import nl.belastingdienst.iva.wd.kbs.domain.OrgUrls;
import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteit;
import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteiten;
import nl.belastingdienst.iva.wd.kbs.domain.ZooOmvang;
import nl.belastingdienst.iva.wd.kbs.domain.ZooSubEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteit;
import nl.belastingdienst.iva.wd.kbs.rest.FakeResponseTime;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitConvenantindicatieService;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitKzbGegevensService;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitService;
import nl.belastingdienst.iva.wd.kbs.service.OrgGegevensService;
import nl.belastingdienst.iva.wd.kbs.service.SubEntiteitService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/entiteiten")
public class EntiteitRestController {

	private final EntiteitService service;
	private final SubEntiteitService subEntiteitService;
	private final EntiteitConvenantindicatieService entiteitConvenantindicatieService;
	private final FakeResponseTime fakeResponseTime;
	private final EntiteitKzbGegevensService entiteitKzbGegevensService;
	private final OrgGegevensService orgGegevensService;
	private final ApiServiceApplicationProperties apiServiceApplicationProperties;


	@GetMapping("/search")
	public List<Entiteit> searchEntiteiten(@RequestParam Optional<String> entiteitNumber, @RequestParam Optional<String> entiteitName,
			@RequestParam Optional<String> klantpakket) {
		var searchParams = Stream.of(entiteitNumber, entiteitName, klantpakket);
		if (searchParams.allMatch(strOpt -> strOpt.isEmpty() || strOpt.get().isBlank())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No search parameters specified!");
		}

		var querySearchParams = new KtaEntiteit();
		entiteitNumber.ifPresent(querySearchParams::setDosnr);
		entiteitName.ifPresent(querySearchParams::setDosnaam);
		//klantpakket.ifPresent(querySearchParams::setKlantPakket); // TODO IVAKBS-32: not supported by KtaEntiteit yet!
		List<Entiteit> mappedResults = service.search(querySearchParams);

		// TODO IVAKBS-32: Replace dummy data with the real deal.
		for (Entiteit e : mappedResults) {
			e.setAdres("!!! Juweelstraat 12, 5643FG  Eindhoven");
			e.setKlantpakket("!!! Onbekend");
		}

		return mappedResults;
	}

	@GetMapping("/{entiteitNummer}")
	public Entiteit getEntiteit(@PathVariable Long entiteitNummer) {
		Optional<Entiteit> result = service.findByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown entiteitNummer!");
		}
		return result.get();
	}

	@GetMapping("/{entiteitNummer}/dashboard/kenmerken")
	public String[][][] getEntiteitKenmerken(@PathVariable Long entiteitNummer) {
		Optional<String[][][]> result = service.findDashboardKenmerkenByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown entiteitNummer!");
		}
		return result.get();
	}

	//TODO checken of deze met entiteitnummer opgehaald kunnen worden uit DB
	@GetMapping("/{entiteitNummer}/algemeneGegevens/kenmerken")
	public Kenmerken getAlgemeneGegevensKenmerken(@PathVariable Long entiteitNummer) {
		Optional<Kenmerken> result = service.findAlgemeneGegevensKenmerkenByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No kenmerken found for entiteitNummer!");
		}
		return result.get();
	}

	@GetMapping("/{entiteitNummer}/algemeneGegevens/samenstelling")
	public List<SubEntiteit> getAlgemeneGegevensSamenstelling(@PathVariable Long entiteitNummer) {
		Optional<List<SubEntiteit>> result = service.findSamenstellingByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No samenstelling found for entiteitNummer!");
		}
		return result.get();
	}

	@GetMapping("/{entiteitNummer}/dashboard/behandelvoorstellen")
	public List<Behandelvoorstel> getDashboardBehandelvoorstellen(@PathVariable Long entiteitNummer) {
		Optional<List<Behandelvoorstel>> result = service.findBehandelvoorstellenByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No behandelvoorstellen found for entiteitNummer!");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}
	@GetMapping("/{entiteitNummer}/dashboard/opdrachten")
	public List<Opdracht> getDashboardOpdrachten(@PathVariable Long entiteitNummer) {
		Optional<List<Opdracht>> result = service.findOpdrachtenByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No opdrachten found for entiteitNummer!");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}

	@GetMapping("/{entiteitNummer}/zoo/omvang")
	public ZooOmvang getZooOmvang(@PathVariable Long entiteitNummer) {
		Optional<ZooOmvang> result = service.findZooEntiteitOmvang(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No omvang found for entiteitNummer!");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}

	@PutMapping("/{entiteitNummer}/zoo/omvang")
	public ZooOmvang saveOrUpdateZooOmvang(@PathVariable Long entiteitNummer, @RequestBody ZooOmvang o) {
		ZooOmvang zooOmvang = service.saveZooEntiteitOmvang(entiteitNummer, o);
		fakeResponseTime.fakeResponseTime();
		// TODO remove fake response delay:
		return zooOmvang; // return service.saveZooEntiteitOmvang(entiteitNummer, o);
	}

	@PostMapping("/{entiteitNummer}/subEntiteitSelections/save")
	public void saveSubEntiteitSelections(@PathVariable Long entiteitNummer, @RequestBody List<ZooSubEntiteit> ZooSubEntiteiten) {
		subEntiteitService.saveSubEntiteiten(entiteitNummer, ZooSubEntiteiten);
	}

	@GetMapping("/{entiteitNummer}/zooSubEntiteiten")
	public List<ZooSubEntiteit> getZooSubEntiteiten(@PathVariable Long entiteitNummer) {
		return subEntiteitService.getZooSubEntiteitenByEntiteitNummer(entiteitNummer);
	}

	@GetMapping("/{entiteitNummer}/subEntiteiten/selected")
	public List<ZooSubEntiteit> getSubEntiteitSelections(@PathVariable Long entiteitNummer) {
		List<SubEntiteiten> subEntiteiten = subEntiteitService.getSelectedSubEntiteiten(entiteitNummer);
		return subEntiteiten.stream()
				.map(subEntiteit -> subEntiteitService.getZooSubEntiteit(entiteitNummer, subEntiteit.getSubEntiteitBsnRsin()))
				.collect(Collectors.toList());
	}

	@GetMapping("/{entiteitNummer}/convenantindicatie")
	public Convenantindicatie getConvenantindicatie(@PathVariable Long entiteitNummer) {
		var result = this.entiteitConvenantindicatieService.findByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No convenantindicatie found for entiteitNummer!");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}

	@GetMapping("/{entiteitNummer}/missing-entiteit-org-gegevens")
	public EntiteitKzbGegevens getMissingEntiteitOrgGegevens(@PathVariable Long entiteitNummer) {
		EntiteitKzbGegevens entiteitKzbGegevens = entiteitKzbGegevensService.findEntiteitKzbGegevensByNummer(entiteitNummer);
		return entiteitKzbGegevens;
	}

	@GetMapping("/{entiteitNummer}/kantoorteam-org-gegevens")
	public OrgKantoorTeam getOrgKantoorTeamGegevens(@PathVariable Long entiteitNummer) {
		return  orgGegevensService.getOrgKantoorTeamGegevens(entiteitNummer);
	}

	@GetMapping("/{entiteitNummer}/klantgroep-org-gegevens")
	public OrgKlantGroep getOrgKlantGroepGegevens(@PathVariable Long entiteitNummer) {
		return  orgGegevensService.getOrgKlantGroepGegevens(entiteitNummer);
	}

	@GetMapping("/{entiteitNummer}/behandelteam-org-gegevens")
	public List<Behandelteam> getOrgBehandelteam(@PathVariable Long entiteitNummer) {
		return  orgGegevensService.getOrgBehandelteam(entiteitNummer);
	}

	@GetMapping("/org-gegevens-url")
	public OrgUrls getOrggevegensUrl() {
		OrgUrls toSend = new OrgUrls();
		toSend.setWijzigBehandelteamUrl(apiServiceApplicationProperties.getWijzenBehandelteamUrl());
		return toSend;
	}

}
