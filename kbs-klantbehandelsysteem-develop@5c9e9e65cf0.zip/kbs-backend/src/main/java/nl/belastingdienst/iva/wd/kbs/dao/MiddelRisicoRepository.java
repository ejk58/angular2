package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MiddelRisicoRepository extends JpaRepository<MiddelRisico, Long> {
    List<MiddelRisico> findAllByMiddelId(Long id);
    MiddelRisico findMiddelRisicoById(Long id);
}
