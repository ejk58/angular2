/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KrbEntiteit.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 7-4-2021 11:41
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.kta.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(schema = "KRBA05", name = "VW018_KZB_RISICOASPECTEN") // TODO: Make schema a configurable property. See KtaEntiteit.java
@Data // TODO Jelle: JPA Buddy-plugin complains about this annotation being unsafe?
public class KrbEntiteit {

	@Id
	@Column(name = "ENTITEITNUMMER")
	private Long entiteitNummer;
	/**
	 * Column datatype is DECIMAL(16,2)
	 */
	@Column(name = "WOLBSOM")
	private BigDecimal wolbSom;
}
