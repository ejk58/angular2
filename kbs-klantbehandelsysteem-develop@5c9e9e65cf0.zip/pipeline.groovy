@Library("GENERIC") _
pipelineCode_openshift_v3 {
	deploymentId = "ivakbs"
	integrationPipeline = "iva-kbs_test-Robot"
	environmentChoices = "ont\ntst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6"
	vervangenOpenjdk11Image = "true"
	mvnVersion = "maven36-openjdk11"
	nodeVersion = "nodejs14"
	updateImageTo=[["project": "wd-kbs", "deploymentConfig": "tst", "container": "tst"]]
	vervangenOpenshiftObjects = true
}
