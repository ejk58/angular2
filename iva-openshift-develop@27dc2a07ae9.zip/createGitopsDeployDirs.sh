#!/bin/bash

PROJECTBASE=$1
ENVIRONMENT=$2
STREET=$3

if [ "${PROJECTBASE}" = "" ]; then
  echo "PROJECTBASE:  3 of 4-letterige applicatiecode ( bat, ihm of kbs) is verplicht"
  exit
fi

if [ "${ENVIRONMENT}" = "" ]; then
  echo "ENVIRONMENT:  keuze uit ont|tst|acc|prod verplicht"
  exit
fi

if [ "${STREET}" = "" ]; then
  if [ "${ENVIRONMENT}" != "ont" ]; then
    echo "STREET: moet worden gevuld ( behalve voor ont mag die leeg zijn!"
    exit
  fi
fi

tmpOcDir="/tmp/$(basename $0)"
homedir=${HOME}
lijst="${homedir}/webdev_appl_info.txt"
tmpConfig="${homedir}/config.xml" 
workdir="/tmp/${PROJECTBASE}-deploy"

rm -rf ${tmpOcDir} || true
rm -rf ${workdir} || true

run="False"

# clone de algemene repo
mkdir -p ${tmpOcDir}
cd ${tmpOcDir}
git clone ssh://git@git.belastingdienst.nl:7999/ivacommon/openshift   .
mkdir -p ${workdir}

cp -r ${tmpOcDir}/base ${workdir}/
cp -r ${tmpOcDir}/overlays ${workdir}/
mv  ${workdir}/overlays/sample-env ${workdir}/overlays/${ENVIRONMENT}
cp -r ${tmpOcDir}/*sh ${workdir}/
mv  ${workdir}/overlays/${ENVIRONMENT}/sample-street ${workdir}/overlays/${ENVIRONMENT}/${ENVIRONMENT}${STREET}


# het goed zetten van de projectbase, de environment en street
find ${workdir}/{base,overlays/${ENVIRONMENT}} -iname  "*yaml" -o -iname "*properties" -type f | while read f 
do
  sed -i "s/@@STREET@@/${STREET}/g ; s/@@ENVIRONMENT@@/${ENVIRONMENT}/g ; s/@@PROJECTBASE@@/${PROJECTBASE}/g " ${f}
  if [ "$(echo $f | grep 'dc-trigger')" != "" ]; then
    if [ "${ENVIRONMENT}" = "ont" ] &&  [ "$(echo $f | grep 'tstaccprod')" != "" ]; then
      rm $f
    fi
    if [ "${ENVIRONMENT}" != "ont" ] &&  [ "$(echo $f | grep 'tstaccprod')" != "" ]; then
      dirNaam=$(dirname ${f}) 
      mv ${dirNaam}/patch-dc-triggers-tstaccprod.yaml ${dirNaam}/patch-dc-triggers.yaml
    fi
  fi
done

echo "de yaml's staan in ${workdir} vul ze aan en copieer ze naar je repo dir"

