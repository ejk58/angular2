DELETE FROM "CONF_DATASOURCE_PARAM";

INSERT INTO "CONF_DATASOURCE_PARAM"("DATASOURCE_ID", "KEY", "VALUE") VALUES 
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'credentialMappingJAAS', 'ivai/teradata/login'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'restUrl', 'https://tdrest.tst.belastingdienst.nl/tdrest/systems/TeradataTst/queries'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'teradataSchema', 'DG_I_P_50PRO_INZ'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'slowQueryThreshold', '2000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'retryOnTimeout', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'acceptHeader', 'application/vnd.com.teradata.rest-v1.0+json'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Teradata/IVAI'), 'contentTypeHeader', 'application/json'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsType', 'APIKEY'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'credentialMappingJAAS', 'rest/zaakadministratie/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'restUrl', 'https://iva-gsv.str13.tst.belastingdienst.nl/iva-gsv/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Zaakadministratie'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'restUrl', 'https://jira-opleiding.belastingdienst.nl/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialsType', 'LOGINPASSWORD'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialsEncoding', 'BASE64'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'credentialMappingJAAS', 'rest/jirafeedback/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/JiraFeedback'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsType', 'URLPARAMETER'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'credentialMappingJAAS', 'rest/documenten/ivai'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'restUrl', 'https://appsiva-rel.tst.belastingdienst.nl/DocumentViewer'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'connectTimeout', '20000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'readTimeout', '20000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Documenten'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'restUrl', 'https://inzicht.str13.tst.belastingdienst.nl/inzicht/rest/'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'credentialsType', 'LTPA2TOKEN'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/Inzicht'), 'slowQueryThreshold', '5000'),

((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'restUrl', 'https://iva-mihproxyservice-stub.str11.tst.belastingdienst.nl/iva-mihproxyservice-stub/rest'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'credentialsType', 'LTPA2TOKEN'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'credentialsEncoding', 'PLAINTEXT'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'trustAllCertificates', 'true'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'connectTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'readTimeout', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'slowQueryThreshold', '5000'),
((SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'Rest/MihProxy'), 'wsaAddressHeader', 'http://servicespecifications.belastingdienst.nl/ivaccent/zaakadministratie');

INSERT INTO "CONF_DOMAIN_ROLE"("DOMAIN_ID", "TYPE", "ROLE", "VIPACCESS") VALUES 
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'niet_winst'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'di'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'di'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'invordering'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'invordering'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'documenten'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'documenten'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'zaakadministratie'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'zaakadministratie'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'erf'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'erf'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantgeg'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'klantgeg'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'ib_kis'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'ib_kis'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'upi'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'upi'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'schenk'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'schenk'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'go'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'go'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'mkb'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'mkb'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'vastgoed'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'vastgoed'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'anbi'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'anbi'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'analytics'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'analytics'), 0, 'aug_IVA_maatwerk_dev', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'reflection'), 0, 'aug_IVAI_dfa', 0),
((SELECT ID FROM CONF_DOMAIN WHERE KEY = 'reflection'), 0, 'aug_IVA_maatwerk_dev', 0);

-- Test users
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivaall', 0 FROM CONF_DOMAIN;
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest1', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest2', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest3', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest4', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest5', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest6', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest7', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest8', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest9', 0 FROM CONF_DOMAIN WHERE KEY NOT IN ('reflection');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest10', 0 FROM CONF_DOMAIN WHERE KEY IN ('go');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest11', 0 FROM CONF_DOMAIN WHERE KEY IN ('mkb');
INSERT INTO CONF_DOMAIN_ROLE(DOMAIN_ID, TYPE, ROLE, VIPACCESS) SELECT ID, 1, 'ivatest12', 0 FROM CONF_DOMAIN WHERE KEY IN ('scherfbel', 'schenkbel');

-- Internal permission-provider
UPDATE "CONF_ATTRIBUTE" SET VALUE = 'Internal' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'permissionProvider';

-- Switch the KTA-link and KRB-link to the test-environment
UPDATE "CONF_ATTRIBUTE" SET VALUE = 'kta.str25.tst' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'ktaEnvironment';
UPDATE "CONF_ATTRIBUTE" SET VALUE = 'krb.str12.tst' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'krbEnvironment';

-- Allow access to the Zaakadministratie-view with all fi-nrs and bypass the Teradata INZICHT_FINRS-view
UPDATE "CONF_QUERY" SET TYPE = 0, VIEWNAME = '', QUERYTEMPLATE = '{"subjectNr":"{subjectNr:fiscalnumber}","subjectTitle":"{subjectNr:fiscalnumber}","name":"{subjectNr:fiscalnumber}","remark":"{subjectNr:fiscalnumber}","label":"ZELF","color":"#FFFFFF","backgroundColor":"#800000"}', DATASOURCE_ID = NULL WHERE KEY LIKE 'GENERICSUBJECT_SEARCH_%';

-- Jira
UPDATE "CONF_ATTRIBUTE" SET VALUE = '10102' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'jiraFeedbackProject';
UPDATE "CONF_ATTRIBUTE" SET VALUE = 'Test' WHERE ATTRIBUTE_GROUP_ID = (SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'GENERAL') AND KEY = 'jiraFeedbackEnvironment';

-- Attribute-group JIRA_FEEDBACK_COMPONENTS
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 1, 'none', 'Algemeen: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 2, 'niet_winst', 'Niet-Winst: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 3, 'di', 'MKB / GO: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 4, 'invordering', 'Invordering: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 5, 'documenten', 'Documenten: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 6, 'zaakadministratie', 'Zaakadministratie: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 7, 'analytics', 'Analytics: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 8, 'reflection', 'Reflectie: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 9, 'presentation', 'Presentatie: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 10, 'erf', 'Erfbelasting: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 11, 'ib_kis', 'I&B KI&S: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 12, 'upi', 'UPI: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 13, 'schenk', 'Schenkbelasting: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 14, 'go', 'GO: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 15, 'mkb', 'MKB: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 16, 'vastgoed', 'Vastgoed: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 17, 'klantgeg', 'Klantgegevens: Te beoordelen');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_COMPONENTS'), 18, 'anbi', 'ANBI: Te beoordelen');

-- Attribute-group JIRA_FEEDBACK_TOPIC_FIX_VERSIONS
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 1, 'De getoonde gegevens zijn onjuist, onvolledig of niet actueel.', '10404');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 2, 'De snelheid waarmee de applicatie reageert of foutmeldingen die in beeld verschijnen.', '10403');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 3, 'Onderdelen van de applicatie of velden die verwarring oproepen.', '10402');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 4, 'Gebruikersgemak.', '10401');
INSERT INTO "CONF_ATTRIBUTE"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES ((SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY = 'JIRA_FEEDBACK_TOPIC_FIX_VERSIONS'), 5, 'Overige wensen.', '10400');
