@Library("GENERIC") _
  pipelineDatabase {
	  	project = "inzicht"
		dbUser = "27a2a787-f5b2-4d17-b13c-44c7c2598504"
		changelogFile = "iva-inzicht.xml"
		gitUrl = "ssh://git@git.belastingdienst.nl:7999/ivai/database.git"
		dbUrlOnt = "jdbc:db2://on03p377.ont.belastingdienst.nl:50000/ivadb"
		dbUrlTst = "jdbc:db2://ts03p605.tst.belastingdienst.nl:50000/ivadb"
		dbSchema = "IVAI01\nIVAI02\nIVAI03\nIVAI04\nIVAI05"
		codePipeline = ["inzicht"]
	}