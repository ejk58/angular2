# pip install --index-url http://externerepos.belastingdienst.nl/pypi/web/simple --trusted-host externerepos.belastingdienst.nl pandas

import calendar
import pandas


kwaliteitenprofielColumn = 'Kwaliteitenprofielen'
familieColumnPrefix = 'Functiefamilie ' 
groepColumnPrefix = 'Functiegroep '
sqlFilename = '913-functiefamilie.sql'

data = pandas.read_excel('Inhuurformulier ICT Belastingdienst 4.17 (onbeveiligde versie).xlsm', sheet_name = 'Kwaliteitsraamwerk I(v)')
sql = []


print('Reading information about "functiefamilie"...')    
for rowindex, datarow in data.iterrows():
    kwaliteitenprofiel = str(datarow[kwaliteitenprofielColumn]).strip().replace('  ', ' ')
        
    if kwaliteitenprofiel is not None and len(kwaliteitenprofiel) > 3:
        for columnindex in range(1, 3):
            naam = str(datarow[familieColumnPrefix + str(columnindex)]).strip()
            functiegroep = str(datarow[groepColumnPrefix + str(columnindex)]).strip()
            index = rowindex * 3 + columnindex
            
            if naam is not None and len(naam) > 3:
                sql.append(f'MERGE INTO FUNCTIEFAMILIE AS F USING (VALUES ({str(index)}, (SELECT ID FROM KWALITEITENPROFIEL WHERE NAAM = \'{kwaliteitenprofiel}\'), (SELECT ID FROM FUNCTIEGROEP WHERE NAAM = \'{functiegroep}\'), \'{naam}\')) AS X(INDEX, KWALITEITENPROFIEL_ID, FUNCTIEGROEP_ID, NAAM) ON F.KWALITEITENPROFIEL_ID = X.KWALITEITENPROFIEL_ID AND F.FUNCTIEGROEP_ID = X.FUNCTIEGROEP_ID WHEN MATCHED THEN UPDATE SET INDEX = X.INDEX, KWALITEITENPROFIEL_ID = X.KWALITEITENPROFIEL_ID, FUNCTIEGROEP_ID = X.FUNCTIEGROEP_ID, NAAM = X.NAAM WHEN NOT MATCHED THEN INSERT (INDEX, KWALITEITENPROFIEL_ID, FUNCTIEGROEP_ID, NAAM) VALUES (X.INDEX, X.KWALITEITENPROFIEL_ID, X.FUNCTIEGROEP_ID, X.NAAM);\n')


print('Writing SQL file...')    
sqlFile = open(sqlFilename, 'w', encoding = 'utf-8')
sqlFile.writelines(sql)
sqlFile.close()

print('Done.')
