# pip install --index-url http://externerepos.belastingdienst.nl/pypi/web/simple --trusted-host externerepos.belastingdienst.nl pandas

import calendar
import pandas


kwaliteitenprofielColumn = 'Kwaliteitenprofielen'
kennisgebiedColumnPrefix = 'PK'
certificatenColumnPrefix = 'C' 
sqlFilename = '914-kennisgebied.sql'

data = pandas.read_excel('Inhuurformulier ICT Belastingdienst 4.17 (onbeveiligde versie).xlsm', sheet_name = 'Kwaliteitsraamwerk I(v)')
kwaliteitenprofielList = []
sql = []

print('Reading information about "kennisgebied"...')    
for rowindex, datarow in data.iterrows():
    kwaliteitenprofiel = str(datarow[kwaliteitenprofielColumn]).strip().replace('  ', ' ')
        
    if kwaliteitenprofiel is not None and len(kwaliteitenprofiel) > 3:
        for columnindex in range(1, 6):
            naam = str(datarow[kennisgebiedColumnPrefix + str(columnindex)]).strip()
            certificaten = str(datarow[certificatenColumnPrefix + str(columnindex)])
            index = rowindex * 6 + columnindex
            
            if naam is not None and len(naam) > 3:
                sql.append(f'MERGE INTO KENNISGEBIED AS K USING (VALUES ({str(index)}, (SELECT ID FROM KWALITEITENPROFIEL WHERE NAAM = \'{kwaliteitenprofiel}\'), \'{naam}\', \'{certificaten}\')) AS X(INDEX, KWALITEITENPROFIEL_ID, NAAM, CERTIFICATEN) ON K.NAAM = X.NAAM WHEN MATCHED THEN UPDATE SET INDEX = X.INDEX, KWALITEITENPROFIEL_ID = X.KWALITEITENPROFIEL_ID, NAAM = X.NAAM, CERTIFICATEN = X.CERTIFICATEN WHEN NOT MATCHED THEN INSERT (INDEX, KWALITEITENPROFIEL_ID, NAAM, CERTIFICATEN) VALUES (X.INDEX, X.KWALITEITENPROFIEL_ID, X.NAAM, X.CERTIFICATEN);\n')


print('Writing SQL file...')    
sqlFile = open(sqlFilename, 'w', encoding = 'utf-8')
sqlFile.writelines(sql)
sqlFile.close()

print('Done.')
