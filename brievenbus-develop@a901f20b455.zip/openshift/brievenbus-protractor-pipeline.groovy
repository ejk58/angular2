#!groovy

// Deze variabelen zijn project specifiek
def projectBase = "brievenbus"

// Deze variabelen alleen als je niet de standaard volgt
def frontendName = "bvb-frontend"

// Deze variabelen in principe niet veranderen
def protractorCmd = "node ./node_modules/protractor-flake/bin/protractor-flake --parser=./my-custom-parser.js --max-attempts=4 --color=yellow -- ./protractor.conf.js"

pipeline {
    agent {
        label "nodejs10"
    }
    options {
		skipDefaultCheckout()
	}
    stages {
        stage('Checkout') {
            steps {
                checkout scm
                // ITT Jeroen's versie, .git niet excluden omdat die voor de git-commit plugin nodig is
                stash(name: 'ws', includes: '**', excludes: '**/node_modules/**')
            }
        }
        stage('NPM') {
            steps {
                unstash 'ws'
                dir(frontendName) {
                    sh (script: "npm i" ) // Dit moet later nog npm ci worden
                    sh (script: "npm run build" )
                    // Onderstaand is afhankelijk van de "name": "frontend" in package.json
                    stash(name: 'frontend', includes: 'dist/frontend/**')
                }
            }
        }
        stage('Protractor') {
            steps {
                unstash 'ws'
                dir(frontendName) {
                    sh(script: "npm ci --ignore-scripts; ${protractorCmd}")
                }
            }
        }
    }
}
