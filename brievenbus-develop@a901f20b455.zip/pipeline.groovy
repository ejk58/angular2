pipelineCode_openshift_v3 {
    deploymentId = "iva-brievenbus"
    integrationPipeline = ""
    environmentChoices = "ont\ntst\nacc"
    streetChoices = "1\n2\n3\n4\n5\n6"
    mvnVersion = "maven35-openjdk11"
    nodeVersion = "nodejs12"
    vervangenOpenjdk11Image = false
}