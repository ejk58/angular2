package nl.belastingdienst.iva.wd.brievenbus.controller;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.domain.DeliveryBuilder;
import nl.belastingdienst.iva.wd.brievenbus.service.FileService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(FileController.class)
public class FileControllerTest {

    private static final String API_DOWNLOAD = "/api/download/";
    private static final String INVALID_UUID = "uuid1";
    private static final String UUID1 = "db5582d9-444a-4451-957b-33a22168a094";
    private static final String UUID2 = "db5582d9-444a-4451-957b-33a22168a022";

    @MockBean
    LdapContextSource ldapContextSource;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private DeliveryRepository deliveryRepository;

    @MockBean
    FileService fileService;

    @Test
    @WithMockUser(username = "receiver1")
    public void testInvalidUUID()
            throws Exception {
        mvc.perform(get(API_DOWNLOAD + INVALID_UUID)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"Failed to convert value of type 'java.lang.String' to required type 'java.util.UUID'; nested exception is java.lang.IllegalArgumentException: Invalid UUID string: uuid1\"}"))
                .andExpect(status().is(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    }

    @Test
    public void testNoPrincipal()
            throws Exception {
        stubDeliveryRepository(UUID1, true);
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.FORBIDDEN.value()));
    }

    @Test
    @WithMockUser(username = "receiver1")
    public void testNoDelivery()
            throws Exception {
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"Levering met dit uuid niet gevonden db5582d9-444a-4451-957b-33a22168a094\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    @WithMockUser(username = "receiver1")
    public void testCompleteDeliveryReceiver1()
            throws Exception {
        stubDeliveryRepository(UUID1, true);
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("Ik ben een interessante file!"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "receiver2")
    public void testCompleteDeliveryReceiver2()
            throws Exception {
        stubDeliveryRepository(UUID1, true);
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("Ik ben een interessante file!"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "receiver3")
    public void testCompleteDeliveryUnknownReceiver()
            throws Exception {
        stubDeliveryRepository(UUID1, true);
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"receiver3 komt niet voor in lijst met ontvangers\"}"))
                .andExpect(status().is(HttpStatus.PRECONDITION_FAILED.value()));
    }

    @Test
    @WithMockUser(username = "receiver1")
    public void testCompleteDeliveryExpired()
            throws Exception {
        stubDeliveryRepository(UUID2, true);
        mvc.perform(get(API_DOWNLOAD + UUID2)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"De download periode is verstreken\"}"))
                .andExpect(status().is(HttpStatus.PRECONDITION_FAILED.value()));
    }

    @Test
    @WithMockUser(username = "receiver1")
    public void testCompleteDeliveryFileNotFound()
            throws Exception {
        stubDeliveryRepository(UUID1, false);
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"File db5582d9-444a-4451-957b-33a22168a094/null niet gevonden\"}"))
                .andExpect(status().is(HttpStatus.NOT_FOUND.value()));
    }

    private void stubDeliveryRepository(String uuid, boolean filePresent) throws IOException {
        if (filePresent) {
            stubFileService(uuid);
        } else {
            stubFileNotExistsService(uuid);
        }

        if (uuid.equals(UUID1)) {
            when(deliveryRepository.findFirstByUuid(UUID.fromString(uuid))).thenReturn(DeliveryBuilder.buildCompleteDelivery(UUID.fromString(uuid)));
        } else {
            when(deliveryRepository.findFirstByUuid(UUID.fromString(uuid))).thenReturn(DeliveryBuilder.buildExpiredDelivery(UUID.fromString(uuid)));
        }
    }

    private void stubFileService(String uuid) throws IOException {
        String mockFile = "Ik ben een interessante file!";
        InputStream is = new ByteArrayInputStream(mockFile.getBytes());
        Resource mockResource = Mockito.mock(Resource.class);

        when(mockResource.exists()).thenReturn(true);
        when(mockResource.getInputStream()).thenReturn(is);
        when(fileService.getFileSystem(eq(uuid), any(), any())).thenReturn(mockResource);
    }

    private void stubFileNotExistsService(String uuid) throws IOException {
        Resource mockResource = Mockito.mock(Resource.class);

        when(mockResource.exists()).thenReturn(false);
        when(fileService.getFileSystem(eq(uuid), any(), any())).thenReturn(mockResource);
    }


}
