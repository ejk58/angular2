package nl.belastingdienst.iva.wd.brievenbus.domain;

public class FileBuilder {

    public static File buildFile(int i) {
        File file = new File();
        file.setId(new Long(i));
        file.setHash("hash"+i);
        file.setBytes(new Long(1000*1));
        file.setName("filename"+i);
        return file;
    }
}
