package nl.belastingdienst.iva.wd.brievenbus.domain;

import java.util.ArrayList;
import java.util.List;

public class ReceiverBuilder {

    public static List buildReceiverList(String... receiverIds) {
        List receiverList = new ArrayList();
        for (String receiverId: receiverIds) {
            Receiver receiver = new Receiver();
            receiver.setUserid(receiverId);
            receiverList.add(receiver);
        }
        return receiverList;
    }

    public static String buildIvaTestReceiverJson(int i) {
        return createReceiverJson("ivatest" + i, "ivatest" + i + "@test.com", "ivatest" + i + "Name");
    }

    private static String createReceiverJson(String userId, String email, String name) {
        return "{" +
                "\"userId\": \"" + userId + "\"," +
                "\"email\": \"" + email + "\"," +
                "\"name\": \"" + name + "\"" +
                "}";
    }

}
