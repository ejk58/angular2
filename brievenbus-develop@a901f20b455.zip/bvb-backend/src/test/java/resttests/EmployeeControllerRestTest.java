package resttests;

import org.springframework.http.HttpStatus;
import org.testng.annotations.*;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.testng.Assert.assertNotNull;

public class EmployeeControllerRestTest {

    private static final String BASE_PATH = "/api/employee/find/";

    @BeforeMethod
    public void setup() {
        RestUtils.setBaseURI(RestConstants.BASE_ADP_URI);
        RestUtils.setBasePort(RestConstants.PORT);
        RestUtils.setBasePath(BASE_PATH);
        RestUtils.setContentType(RestConstants.HEADER);
        RestUtils.setRelaxedHTTPSValidation();
    }

    @AfterMethod
    public void afterTest (){
        RestUtils.resetBaseURI();
        RestUtils.resetBasePort();
        RestUtils.resetBasePath();
    }

    @Test
    @Ignore
    public void get_employee_with_correct_userid() {
        given().log().all()
                .pathParam("userid", "ivatest1")
            .when()
                .get("{userid}")
            .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
                .body("userId", equalTo("ivatest1"))
                .body("name", equalTo("Iva I. Test1"))
                .body("email", equalTo("ivatest1@ont.belastingdienst.nl"));
    }

    @Test
    @Ignore
    public void get_employee_with_incorrect_userid() {
        RestUtils.setBasePath(BASE_PATH);
        String response =
                given()
                .pathParam("userid", "ivatest1@ont.belastingdienst.nl")
            .when()
                .get("{userid}")
            .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
            .extract()
                .asString();

        assertNotNull(response, "[]");
    }

    @Test
    @Ignore
    public void get_employee_with_wrong_path() {
        RestUtils.setBasePath("/api/employee/finderror/");
        given().log().all()
                .pathParam("userid", "ivatest1")
                .when()
                .get("{userid}")
                .then()
                .assertThat()
                .statusCode(HttpStatus.NOT_FOUND.value());
    }


}