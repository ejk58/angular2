package nl.belastingdienst.iva.wd.brievenbus.domain;

public enum ApplicationPlatform {
    ADP("ADP"),
    DWB("DWB");

    private String platform;

    ApplicationPlatform(String platform) {
        this.platform = platform;
    }

    public String getPlatform() {
        return platform;
    }
}
