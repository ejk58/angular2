package nl.belastingdienst.iva.wd.brievenbus.dto;

import lombok.Data;

@Data
public class ReceiverJson {

    private String userId;
    private String email;
    private String name;

}