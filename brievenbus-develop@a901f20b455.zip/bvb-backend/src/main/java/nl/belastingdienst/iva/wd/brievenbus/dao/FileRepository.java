package nl.belastingdienst.iva.wd.brievenbus.dao;

import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FileRepository extends CrudRepository<File, Long> {



}
