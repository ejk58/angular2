package nl.belastingdienst.iva.wd.brievenbus.service;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.UUID;

public class AuditService {
    private AuditService() {
    }

    private static final String ACTION_LABEL = " ACTION: ";
    private static final String USERNAME_LABEL = "USERNAME: ";
    private static final String FILE_LABEL = "FILE: ";
    private static final String DELIVERY_UUID_LABEL = "DELIVERY UUID: ";

    protected static final Logger LOGGER = LogManager.getLogger(AuditService.class);

    protected static final String CUSTOM_LEVEL = "AUDIT";
    protected static final int CUSTOM_INT_VALUE = 250;

    public static void logUserAction(String action, String username, String fileName, UUID deliveryUUID) {
        LOGGER.log(Level.forName(CUSTOM_LEVEL, CUSTOM_INT_VALUE),
                ACTION_LABEL + action + "\t " +
                        USERNAME_LABEL + username + "\t " +
                        DELIVERY_UUID_LABEL + (deliveryUUID == null ? "" : deliveryUUID.toString()) + "\t " +
                        FILE_LABEL + fileName);
    }

    public static void logUserAction(String action, String username, String fileName) {
        AuditService.logUserAction(action, username, fileName, null);
    }

    public static void logUserAction(String action, String username, UUID deliveryUUID) {
        AuditService.logUserAction(action, username, "", deliveryUUID);
    }

    public static void logUserAction(String action, String username) {
        AuditService.logUserAction(action, username, "", null);
    }

    public static void logUserAction(String action, UUID deliveryUUID) {
        AuditService.logUserAction(action, "", "", deliveryUUID);
    }

}