package nl.belastingdienst.iva.wd.brievenbus.service;

import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.Mail;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Properties;

@Service("mailService")
public class MailService {

    private static final String EMAIL_DOMAIN = "@belastingdienst.nl";
    private static final String DOUBLE_LF = "\n\n";
    private static final String MAIL_SUBJECT = "Er staat een document voor u klaar";
    private static final String MAIL_CONTENT = "heeft u een document gestuurd.\nOnderstaande link geeft toegang tot de beveiligde data.";
    private static final String DATE_FORMAT = "d MMMM yyyy";
    private static final String EXPIRATION_DATE_LABEL = "Vervaldatum: ";
    public static final String EMAIL_SEND_ERROR = "Er is iets misgegegaan bij het verzenden van de email naar ";

    @Value("${mail.smtp.host}")
    private String smtpHost;

    @Value("${mail.from.address}")
    private String mailFrom;

    @Value("${mail.link.url}")
    private String mailLink;

    public void createAndSendMail(Delivery delivery, List<ReceiverJson> receivers) {
        Mail mail = createMail(receivers, delivery);
        sendEmail(mail, delivery);
    }

    private Mail createMail(List<ReceiverJson> receivers, Delivery delivery) {
        Mail mail = new Mail();
        mail.setMailBcc(createBccList(receivers));
        mail.setMailFrom(mailFrom);
        mail.setMailSubject(MAIL_SUBJECT);
        mail.setMailContent(createContent(delivery));
        return mail;
    }

    private String createBccList(List<ReceiverJson> receivers) {
        StringBuilder bccString = new StringBuilder();
        for (ReceiverJson receiver : receivers) {
            bccString.append(receiver.getUserId()).append(EMAIL_DOMAIN).append(",");
        }
        return bccString.substring(0, bccString.length() - 1);
    }

    private String createContent(Delivery delivery) {
        StringBuilder content = new StringBuilder();
        content.append(delivery.getSender())
                .append(' ')
                .append(MAIL_CONTENT)
                .append(DOUBLE_LF)
                .append("  " + mailLink)
                .append(delivery.getUuid())
                .append(DOUBLE_LF)
                .append(EXPIRATION_DATE_LABEL)
                .append(delivery.getExpiration().format(DateTimeFormatter.ofPattern(DATE_FORMAT)));
        return content.toString();
    }

    private void sendEmail(Mail mail, Delivery delivery) {
        AuditService.logUserAction("Email wordt verzonden", delivery.getSender(), delivery.getUuid());
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", smtpHost);

            Session session = Session.getInstance(props);

            MimeMessage msg = new MimeMessage(session);
            msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
            msg.addHeader("format", "flowed");
            msg.addHeader("Content-Transfer-Encoding", "8bit");

            msg.setFrom(new InternetAddress(mail.getMailFrom()));
            msg.setSubject(mail.getMailSubject(), "UTF-8");
            msg.setText(mail.getMailContent(), "UTF-8");
            msg.setSentDate(new Date());

            msg.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(mail.getMailBcc(), false));

            Transport.send(msg);
            AuditService.logUserAction("Email is verstuurd naar " + mail.getMailBcc(), delivery.getSender(), delivery.getUuid());
        } catch (MessagingException me) {
            AuditService.logUserAction(EMAIL_SEND_ERROR + mail.getMailBcc(), delivery.getSender(), delivery.getUuid());
            throw new UnprocessableException(EMAIL_SEND_ERROR + mail.getMailBcc(), me);
        }
    }
}
