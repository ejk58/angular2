package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class LdapDwbClient {

    @Value("${ldap.dwb.url}")
    private String ldapDwbUrl;

    @Value("${ldap.dwb.user}")
    private String ldapDwbUser;

    @Value("${ldap.dwb.password}")
    private String ldapDwbPassword;

    @Value("${ldap.dwb.partitionSuffix}")
    private String partitionSuffix;

    public List<Person> getPersons(String userId) {
        LdapTemplate ldapTemplate = getLdapTemplate();

        LdapQuery query = LdapQueryBuilder.query()
                .searchScope(SearchScope.SUBTREE)
                .timeLimit(3000)
                .countLimit(10)
                .base(partitionSuffix)
                .where("objectclass").is("person")
                .and("cn").is(userId);

        return ldapTemplate.search(query, new PersonAttributesMapper());
    }

    private LdapTemplate getLdapTemplate() {
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(ldapDwbUrl);
        contextSource.setUserDn(ldapDwbUser);
        contextSource.setPassword(ldapDwbPassword);
        contextSource.afterPropertiesSet();
        return new LdapTemplate(contextSource);
    }
}
