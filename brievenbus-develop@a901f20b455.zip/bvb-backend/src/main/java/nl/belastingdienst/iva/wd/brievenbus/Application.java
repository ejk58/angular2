package nl.belastingdienst.iva.wd.brievenbus;

import nl.belastingdienst.iva.wd.brievenbus.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
@EnableScheduling
public class Application {

    private static String ldapPrefix = "ldap.";

    @Autowired
    private Environment env;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public LdapContextSource contextSource() {
        String applicationPlatform = env.getRequiredProperty("application.platform", String.class).toLowerCase();
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(env.getRequiredProperty(ldapPrefix + applicationPlatform + ".url"));
        contextSource.setUserDn(env.getRequiredProperty(ldapPrefix + applicationPlatform + ".user"));
        contextSource.setPassword(env.getRequiredProperty(ldapPrefix + applicationPlatform + ".password"));
        return contextSource;
    }

    @Bean
    public LdapTemplate ldapTemplate() {
        return new LdapTemplate(contextSource());
    }

    @Bean
    public JwtUtils jwtUtils() {
        return new JwtUtils(env);
    }
}
