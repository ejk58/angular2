module.exports = {
  name: 'my-custom-parser',
  parse (output) {
    const context = String.raw `\[object Object\]|Object|Context|UserContext|Suite`;
    const source = String.raw `<anonymous>|it|beforeEach|afterEach|before|after`;
    const filepath = String.raw `(([A-Za-z]:\\)?.*?):.*`;

    //regexString value: at (?:\[object Object\]|Object|Context|UserContext|Suite)\.(?:<anonymous>|it|beforeEach|afterEach|before|after) \((([A-Za-z]:\\)?.*?):.*\)
    const regexString = String.raw `at (?:${context})\.(?:${source}) \(${filepath}\)`;
    const regexWebdriver = String.raw `\[\d\d:\d\d:\d\d\].*?PID:.*?\n.*?Specs: (.*)\n(.+\n)*?.+?Error`;

    let failedSpecs = new Set();
    let match = null;
    let FAILED_LINES = new RegExp(regexString, 'g');
    let FAILED_LINES_WEBDRIVER = new RegExp(regexWebdriver, 'g');

    while (match = FAILED_LINES.exec(output)) { // eslint-disable-line no-cond-assign
      // windows output includes stack traces from
      // webdriver so we filter those out here
      if (!/node_modules/.test(match[1])) {
        failedSpecs.add(match[1]);
      }
    }

    while (match = FAILED_LINES_WEBDRIVER.exec(output)) { // eslint-disable-line no-cond-assign
      if (!/node_modules/.test(match[1])) {
        failedSpecs.add(match[1]);
      }
    }

    return [...failedSpecs];
  }
}