/**
 * Configuration to run protractor on 1 browser instance on local selenium grid (to start Chrome locally).
 *
 * Two configuration settings have been changed compared to protractor.conf.js:
 * - multiCapabilities (no 'shardTestFiles' and no 'maxInstances');
 * - seleniumAddress ('seleniumAddress' is empty).
 *
 * Reminder: run the pree2e script from package.json first!
 */
protractor = require('./protractor.conf.js');
let config = protractor.config;

// Capabilities for the webdriver instance
config.multiCapabilities = [
    {
      browserName: 'chrome',
      logName: 'chrome-latest',
      'goog:chromeOptions': {
            // Disable warnings and disable infobars when starting chrome
            'w3c': false,
            args: ["--disable-gpu", "--disable-infobars", "--disable-extensions"],
            // Allow to disable browser extentions that can interrupt tests
            useAutomationExtension: false
        }
    }
];

// Run tests on Selenium server, needed for run on Jenkins
config.directConnect = true;

exports.config = config;
