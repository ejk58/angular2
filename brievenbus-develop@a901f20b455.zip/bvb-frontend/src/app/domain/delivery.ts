import {Receiver} from './receiver';

export interface Delivery {
  uuid: string;
  receivers: Receiver[];
  file: File;
  sender: string;
  created: string;
  expiration: string;
}
