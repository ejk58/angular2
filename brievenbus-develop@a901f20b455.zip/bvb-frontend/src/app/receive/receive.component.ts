import {Component, OnInit} from '@angular/core';
import {DeliveryService} from '../services/delivery.service';
import {ActivatedRoute} from '@angular/router';
import {catchError, filter, map, switchMap, tap} from 'rxjs/operators';
import {Observable, throwError} from 'rxjs';
import {Delivery} from '../domain/delivery';
import {MessageService} from 'primeng/api';
import {DownloadService} from '../services/download.service';
import * as fileSaver from 'file-saver';
import {DisclaimerType} from '../domain/disclaimer-type';

@Component({
  selector: 'app-receive',
  templateUrl: './receive.component.html',
  styleUrls: ['./receive.component.scss'],
  providers: [MessageService]
})
export class ReceiveComponent implements OnInit {

  public readonly disclaimerType: DisclaimerType = 'receive';

  public isChecked: boolean = false;
  public delivery$: Observable<Delivery>;
  public hasUuid$: Observable<boolean>;
  public downloading = false;
  public error: any = null;

  constructor(private readonly deliveryService: DeliveryService,
              private activatedRoute: ActivatedRoute,
              private downloadService: DownloadService,
              private readonly messageService: MessageService) {
  }

  ngOnInit(): void {
    this.hasUuid$ = this.activatedRoute.queryParamMap.pipe(
      map(paramMap => paramMap.has('uuid'))
    );

    this.delivery$ = this.activatedRoute.queryParamMap.pipe(
      filter(paramMap => paramMap.has('uuid')),
      tap(() => this.error = null),
      switchMap(paramMap => this.deliveryService.getDelivery(paramMap.get('uuid'))),
      catchError(err => {
        this.error = err;
        return throwError(err);
      })
    );
  }

  public onChangeChecked(isChecked: boolean): void {
    this.isChecked = isChecked;
  }

  downloadFile(deliveryUUID: string): void {
    this.downloading = true;
    this.downloadService.download(deliveryUUID)
      .subscribe(response => {
        this.saveFile(response.body, response.headers.get('filename'));
        this.downloading = false;
      },
      error => {
        console.error(error);
        this.downloading = false;
        this.messageService.add({
          closable: true,
          sticky: true,
          severity: 'error',
          summary: `Fout bij file download (${error.status})`,
          detail: `${(error.error.message) ? error.error.message : ''}`
        });
      },
      () => {
        this.messageService.add({
          closable: false,
          severity: 'success',
          summary: `Bestand is gedownload`
        });
      });
  }

  private saveFile(data: any, filename?: string): void {
    const blob = new Blob([data], {type: '*/*'});
    fileSaver.saveAs(blob, filename);
  }

  public readyToDownload(): boolean {
    return  this.isChecked && !this.downloading;
  }

}

