import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Router} from '@angular/router';

@Injectable()
export class AppConfigService {

  private appConfig: {
    applicationPlatform: string
  };

  constructor(private readonly http: HttpClient, private readonly router: Router) {
  }

  loadAppConfig(): Promise<Object | never> {
    return this.http
      .get('/api/appconfig/applicationplatform')
      .toPromise()
      .then((config: any) => this.appConfig = config)
      .catch((error: any) => {
        console.error('Error while initializing the application-platform', error);
        if (error.status === 401 || error.status === 403) {
          localStorage.removeItem('id_token');
        }
        this.router.navigateByUrl('');
      });
  }

  getApplicationPlatform(): string {
    return this.appConfig.applicationPlatform;
  }
}
