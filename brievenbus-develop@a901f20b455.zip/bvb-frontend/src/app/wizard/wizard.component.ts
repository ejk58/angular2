import {Component, OnInit} from '@angular/core';
import {Delivery} from '../domain/delivery';
import {ConfirmationService, MenuItem, MessageService} from 'primeng/api';
import {Receiver} from '../domain/receiver';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.scss'],
  providers: [ConfirmationService, MessageService]
})

export class WizardComponent implements OnInit {

  public items: MenuItem[];
  public step: number = 0;
  public isChecked: boolean = false;
  public isSending: boolean = false;

  public delivery: Delivery = {
    uuid: null,
    receivers: [],
    file: null,
    sender: null,
    created: null,
    expiration: null
  };

  constructor(private confirmationService:ConfirmationService,
              private readonly messageService: MessageService,
              private readonly httpClient:HttpClient) { }

  ngOnInit() {
    this.items = [{
      label: 'Selecteren',
      command: (event: any) => {
        this.step = 0;
        // this.messageService.add({severity:'info', summary:'Select receivers and a file', detail: event.item.label});
      }
    },
    {
      label: 'Bevestigen',
      command: (event: any) => {
        this.step = 1;
        // this.messageService.add({severity:'info', summary:'Control', detail: event.item.label});
      }
    },
    {
      label: 'Verstuurd',
      command: (event: any) => {
        this.step = 2;
        // this.messageService.add({severity:'info', summary:'Succes', detail: event.item.label});
      }
    }
    ];
  }

  public disabledSteps(step): void {
    if (step == 0) {
      this.items[0].disabled = false;
      this.items[1].disabled = true;
      this.items[2].disabled = true;
    }
    if (step == 1) {
      this.items[0].disabled = false;
      this.items[1].disabled = false;
      this.items[2].disabled = true;
    }
    if (step == 2) {
      this.items[0].disabled = true;
      this.items[1].disabled = true;
      this.items[2].disabled = false;
    }
  }

  public debugStep(increment: number): void {
    this.step += increment;
  }

  public onSend(delivery: Delivery): void {
    this.delivery = delivery;
    this.step++;
  }

  public onChangeChecked(isChecked: boolean): void {
    this.isChecked = isChecked;
  }

  public onChangeFile(file: File): void {
    this.delivery.file = file;
  }

  public onChangeReceivers(receivers: Receiver[]): void {
    this.delivery.receivers = receivers;
  }

  public promptEraseAll(): void {
    this.confirmationService.confirm({
      message: 'Weet je zeker dat je alle gegevens binnen het formulier wilt wissen?',
      accept: () => {
        this.delivery = {
          uuid: null,
          receivers: [],
          file: null,
          sender: null,
          created: null,
          expiration: null
        };
      }
    });
  }

  public send(): void {
    if (this.delivery) {
      const formData = new FormData();
      formData.append('file', this.delivery.file);
      this.delivery.receivers.forEach(user => formData.append('receivers', JSON.stringify(user)));

      this.isSending = true;

      this.httpClient.post('/api/upload/offer', formData).subscribe(
        (res) => {
          this.isSending = false;
          this.step++;
        },
        (err) => {
          this.isSending = false;
          this.messageService.add({
            closable: true,
            sticky: true,
            severity: 'error',
            summary: `Fout bij aanleveren (${err.status})`,
            detail: `${(err.error.message) ? err.error.message : ''}`
          });
        }
      );
    }
  }

  public allFieldsFilled(): boolean {
    return this.delivery.receivers.length > 0 && this.delivery.file != null;
  }

  public readyToSend(): boolean {
    return !this.isSending && this.isChecked;
  }

  public goToVerify(): void {
    if (this.allFieldsFilled()) {
      this.step++;
    }
  }

  public onStartOver(): void {
    this.delivery = {
      uuid: null,
      receivers: [],
      file: null,
      sender: null,
      created: null,
      expiration: null
    };
    this.step = 0;
    this.disabledSteps(this.step);
    this.isChecked = false;
  }

}
