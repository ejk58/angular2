import {ErrorHandler, Injectable} from '@angular/core';
import {HttpErrorResponse} from '@angular/common/http';
import {ErrorService} from '../services/error.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

  constructor(private readonly errorService: ErrorService) { }

  handleError(error: Error | HttpErrorResponse): void {
    if (error instanceof HttpErrorResponse) {
      // Server error
      if (error.status === 401 || error.status === 403) {
        console.error(error.error.message);
        localStorage.removeItem('id_token');
        this.errorService.addErrorMessage('Uw autorisatie is verlopen. U moet uitloggen en opnieuw inloggen.');
      } else {
        console.error(error.error.message);
        this.errorService.addErrorMessage('Er is een fout opgetreden op de server. Probeer het opnieuw.');
      }
    } else {
      // Client error
      console.error(error.message);
      this.errorService.addErrorMessage('Er is een fout opgetreden. Probeer het opnieuw.');
    }
  }

}
