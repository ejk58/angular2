import {checkRegion, checkWindow} from '../../../shared/imageCompare';
import {Login} from '../../../shared/login';
import {BRIEVENBUS_USER} from '../../../shared/shared.constants';
import {browser, by, element} from 'protractor';
import LoginPo from './login.po';
import HeaderPo from '../../../shared/header.po';

describe('Login', () => {

  let login, loginPo, headerPo;

  beforeAll(async () => {
    login = new Login();
    loginPo = new LoginPo();
    headerPo = new HeaderPo();
  });

  describe('Input field', () => {

    it('should show initial login page', async () => {
      await browser.waitForAngularEnabled(false);
      await login.openApp('adp');
      await checkWindow('loginInitial');
    });

    it('should not show the logged in content in the header before logging in', async () => {
      await expect(headerPo.headerLoggedInContent.isPresent()).toBeFalsy();
      await checkRegion(headerPo.header, 'loginHeaderContentNotPresentBeforeLoggingIn');
    });

    it('should not login with invalid password', async () => {
      await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password + '1', true);
      await expect(loginPo.loginError.getText()).toEqual(loginPo.errorMessageRetry);

      await checkRegion(loginPo.authenticationContainer, 'loginError');

      await loginPo.userIdInput.clear();
      await loginPo.userPasswordInput.clear();
    });

    it('should not login with invalid user', async () => {
      await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1 + 'Wrong', BRIEVENBUS_USER.user.password, true);
      await expect(loginPo.loginError.getText()).toEqual(loginPo.errorMessageRetry);

      await loginPo.userIdInput.clear();
      await loginPo.userPasswordInput.clear();
    });

    it('should not login without password', async () => {
      await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, '', true);

      await checkRegion(loginPo.authenticationContainer, 'loginErrorNoPassword');

      await loginPo.userIdInput.clear();
      await loginPo.userPasswordInput.clear();
    });

    it('should login with correct user', async () => {
      await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
      await expect(element(by.css('.receivers-container .sub-header')).getText()).toEqual('Ontvangers');
    });

    it('should show the logged in content in the header after logging in', async () => {
      await expect(headerPo.headerLoggedInContent.isPresent()).toBeTruthy();
      await expect(headerPo.headerLoggedInUser.getText()).toEqual(BRIEVENBUS_USER.user.ivatest1);
      await checkRegion(headerPo.header, 'loginHeaderContentPresentAfterLoggingIn');
    });

    it('should logout', async () => {
      await login.logoutFromApp();
    });

  });

});
