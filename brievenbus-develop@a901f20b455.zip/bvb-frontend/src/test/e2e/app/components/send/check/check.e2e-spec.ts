import {checkRegion, checkWindow} from '../../../../shared/imageCompare';
import {Login} from '../../../../shared/login';
import {BRIEVENBUS_USER} from '../../../../shared/shared.constants';
import SelectPo from '../select/select.po';
import CheckPo from './check.po';
import {browser} from 'protractor';

describe('Send (adp): Check', () => {

  let remote = require('selenium-webdriver/remote');
  let login, selectPo, checkPo;

  beforeAll(async () => {
    login = new Login();
    selectPo = new SelectPo();
    checkPo = new CheckPo();

    await browser.setFileDetector(new remote.FileDetector());
    await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
    await selectPo.receiversUserid.sendKeys('ivatest1');
    await selectPo.receiversButtonPlus.click();
    await selectPo.fileUploadInput.sendKeys(`${process.cwd()}/src/test/e2e/resources/upload.txt`);
    await selectPo.buttonContainerConfirm.click();
  });

  afterAll(async () => {
    await login.logoutFromApp();
  });

  describe('Check', () => {

    it('should show initial check page', async () => {
      await checkWindow('sendCheckInitial');
    });

    it('should show check page when navigated back to add user and replaced file', async () => {
      await checkPo.buttonContainerBack.click();
      await selectPo.receiversUserid.sendKeys('ivatest2');
      await selectPo.receiversButtonPlus.click();
      await selectPo.fileUploadRemove.click();
      await selectPo.fileUploadInput.sendKeys(`${process.cwd()}/src/test/e2e/resources/uploadSecond.txt`);
      await selectPo.buttonContainerConfirm.click();
      await checkRegion(checkPo.wizardContainer,'sendCheckNavigateBackWithNewData',false,false);
    });

  });

});
