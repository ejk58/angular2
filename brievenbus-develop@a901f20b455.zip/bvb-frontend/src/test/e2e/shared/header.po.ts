'use strict'

import { by, element } from 'protractor';

export default class HeaderPo {
    header = element(by.tagName('header'));
    headerImg = this.header.element(by.tagName('img'));

    headerLoggedInContent = element(by.className('logged-in-header-content'));
    headerLoggedInUser = this.headerLoggedInContent.element(by.tagName('span'));
    headerLogoutButton = this.headerLoggedInContent.element(by.tagName('button'));
}
