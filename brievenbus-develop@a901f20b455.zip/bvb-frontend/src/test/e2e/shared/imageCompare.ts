'use strict';

import {browser, by, element, ElementFinder, protractor} from 'protractor';

export async function checkFullPage(imageName: string) {
    await setCaretColor('white');
    await setVersionContainerValue();
    return (await browser.protractorImageComparison.checkFullPageScreen(imageName, {
        ignoreAntialiasing: true,
        disableCSSAnimation: true,
        hideAfterFirstScroll: [element(by.css('header'))]
    }));
}

export async function checkRegion(element: ElementFinder, imageName: string, hover?: boolean, scrollElementIntoView: boolean = true) {
    if (scrollElementIntoView) {
        await scrollIntoView(element);
    }
    await setCaretColor('white');
    if (hover != true) {
        await moveMouseTo();
    }
    await setVersionContainerValue();
    return (await browser.protractorImageComparison.checkElement(element, imageName, {
        ignoreAntialiasing: true,
        disableCSSAnimation: true
    }));
}

export async function checkWindow(imageName: string, scrollIntoViewElement?: ElementFinder) {
    if (scrollIntoViewElement != null) {
        await scrollIntoView(scrollIntoViewElement);
    }
    await setCaretColor('white');
    await moveMouseTo();
    await setVersionContainerValue();
    return (await browser.protractorImageComparison.checkScreen(imageName, {
        ignoreAntialiasing: true,
        disableCSSAnimation: true,
    }));
}

/**
 * Scroll element in to view.
 *
 * @param {ElementFinder} element Element to scroll to.
 * @param {string} position Optional argument to scroll to bottom of element.
 */
export async function scrollIntoView(element: ElementFinder, position?: string) {
    if (position === 'bottom') {
        await browser.executeScript('arguments[0].scrollIntoView(false);', element);
        await browser.wait(protractor.ExpectedConditions.visibilityOf(element), 5000, 'Element not visible.').then(async function (isVisible) {
            if (isVisible == false) {
                await browser.executeScript('arguments[0].scrollIntoView(false);', element);
                await browser.wait(protractor.ExpectedConditions.visibilityOf(element), 5000, 'Element not visible.');
            }
        });
    } else {
        await browser.executeScript('arguments[0].scrollIntoView(true);', element);
        await browser.wait(protractor.ExpectedConditions.visibilityOf(element), 5000, 'Element not visible.').then(async function (isVisible) {
            if (isVisible === false) {
                await browser.executeScript('arguments[0].scrollIntoView(true);', element);
                await browser.wait(protractor.ExpectedConditions.visibilityOf(element), 5000, 'Element not visible.');
            }
        });
    }
    await browser.sleep(2000);
}

/**
 * Scroll in an element to a particular set of coordinates. If there are multiple elements with the same class the first one will be selected.
 *
 * @param {string} elementClassName Element to scroll in.
 * @param {string} x X-coordinate is the pixel along the horizontal axis of the element.
 * @param {string} y Y-coordinate is the pixel along the horizontal axis of the element.
 */
export async function elementScrollTo(elementClassName: string, x: number, y: number ) {
    await browser.executeScript('document.getElementsByClassName("' + elementClassName + '")[0].scrollTo(' + x + ', ' + y + ');');
}

/**
 * Move mouse to certain position and/or element.
 *
 * @param {ElementFinder} el Optional element to move the mouse to.
 * @param {number} x Optional x axis to move the mouse to.
 * @param {number} y Optional y axis to move the mouse to.
 */
export async function moveMouseTo(el?: ElementFinder, x?: number, y?: number) {
    if (element != null && x != null && y != null) {
        await browser.actions().mouseMove(el, {x: x, y: y}).perform();
    } else if (element === null && x != null && y != null) {
        await browser.actions().mouseMove({x: x, y: y}).perform();
    } else {
        let pageAppContent = await element(by.css('.app-content')).getWebElement();
        await browser.actions().mouseMove(pageAppContent, {x: 0, y: 0}).perform();
    }
}


export async function hoverMouseOver(element: ElementFinder) {
  let mouseOverScript = `if(document.createEvent) {
        var evObj = document.createEvent('MouseEvents');
        evObj.initEvent('mouseover', true, false);
        arguments[0].dispatchEvent(evObj);
      } else if (document.createEventObject) {
        arguments[0].fireEvent('onmouseover');
      }`;

    await browser.executeScript(mouseOverScript, element.getWebElement());
}

/**
 * Set the caret color of a input element.
 *
 * @param {string} color The color of the the inputfield caret.
 */
async function setCaretColor(color: string) {
    await browser.executeScript('var inputs, index; ' +
        "inputs = document.getElementsByTagName('input'); " +
        'for (index = 0; index < inputs.length; ++index) { ' +
        "    inputs[index].setAttribute('style', 'caret-color: " + color + ";'); " +
        '}');
}

/**
 * Set the version in the version container in the right corner of the left and right screen.
 */
async function setVersionContainerValue() {
    await browser.executeScript('var version = document.querySelectorAll(\'.versie-container\');' +
        'if (version.length > 0)' +
        '        for (var i = 0; i < version.length; i++) {' +
        '           version[i].innerText = \'Versie: X.X.X-SNAPSHOT Build: x00000x\'' +
        '        }');
}
