@Library("GENERIC") _
    pipelineDeployArtifactFromHarbor_v1 {
	deploymentId = "ivakbs"
	integrationPipeline = "iva-kbs-test"
	packageChoices = "iva-kbs"
                applicationVersionChoices = "0.25.0\n0.24.0\n0.23.0\n0.22.0\n0.21.0"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "1\n2\n3\n4\n5\n6\n-pat\n-krb\n-baa"
}
