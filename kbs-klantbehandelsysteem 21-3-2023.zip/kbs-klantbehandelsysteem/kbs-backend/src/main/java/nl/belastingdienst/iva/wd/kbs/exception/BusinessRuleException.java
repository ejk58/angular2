package nl.belastingdienst.iva.wd.kbs.exception;

public class BusinessRuleException extends RuntimeException{

    public BusinessRuleException() {}

    public BusinessRuleException(String message)
    {
        super(message);
    }
}
