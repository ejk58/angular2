/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.logging.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "LOGGING_2")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Logging2 {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter(AccessLevel.NONE)
    @Column(name = "ID")
    private Long id;
    @Column(name = "USERNAME")
    private String username;
    @Column(name = "CHANGED_AT")
    private LocalDateTime changedAt;
    @Column(name = "ENTITEIT_NUMMER")
    private Long entiteitNummer;
    @Column(name = "LOGGING_ID")
    private String loggingId;
    @Column(name = "BEWERKING")
    private String bewerking;
    @Column(name = "CODE_SOURCE")
    private String codeSource;

    public enum Bewerking {
        UPDATE, DELETE, INSERT
    }
}

