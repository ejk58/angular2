package nl.belastingdienst.iva.wd.kbs.logging.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;

@Repository
public interface Logging2Repository extends JpaRepository<Logging2, Long> {
	Optional<Logging2> findFirstByLoggingIdAndEntiteitNummerOrderByChangedAtDesc(String loggingId, Long enteitnummer);
	Optional<Logging2> findFirstByLoggingIdOrderByChangedAtDesc(String loggingId);

	/* Contains native query to remove logging
	 * - Most recent logging record grouped by loggingId, entiteitnummer
	 *   must NOT be deleted (can be older than 5 years)
	 * - records older than 5 years need to be removed (except the most recent record)
	 *  */
	@Modifying
	@Query(value = "DELETE FROM LOGGING_2 "
			+ " WHERE "
			/* CHANGED_AT must be older than x years */
			+ " CHANGED_AT < :beforeDate"
			+ " AND ID NOT IN "
			+ " (SELECT ID FROM LOGGING_2 AS L JOIN ("
			+ "            SELECT MAX(CHANGED_AT) AS CHANGED_AT, ENTITEIT_NUMMER, LOGGING_ID  FROM LOGGING_2"
			+ "            GROUP BY ENTITEIT_NUMMER, LOGGING_ID) as logging_latest"
			+ "    ON (L.CHANGED_AT, L.ENTITEIT_NUMMER, L.LOGGING_ID) = (logging_latest.CHANGED_AT, logging_latest.ENTITEIT_NUMMER, logging_latest.LOGGING_ID)"
			+ ")"
	, nativeQuery = true)
	void deleteOldLoggingWithoutMostRecent(@Param("beforeDate") String beforeDate);

}
