/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GetSelectedRisicoService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 11-8-2022 10:09
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie;

import java.util.List;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStrategieRisicosRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class GetSelectedRisicoService {
	private final KlantsessieStrategieRisicosRepository klantsessieStrategieRisicosRepository;
	private final KlantsessieService klantsessieService;

	public List<KlantsessieStrategieRisico> getSelectedList(Long entiteitnummer, Integer middelId) {
		var klantsessieId = this.klantsessieService.getCurrentKlantsessie(entiteitnummer).getId();
		return this.klantsessieStrategieRisicosRepository.findKlantsessieStrategieRisicosByKlantsessieIdAndMiddelId(klantsessieId,
				middelId);
	}

}
