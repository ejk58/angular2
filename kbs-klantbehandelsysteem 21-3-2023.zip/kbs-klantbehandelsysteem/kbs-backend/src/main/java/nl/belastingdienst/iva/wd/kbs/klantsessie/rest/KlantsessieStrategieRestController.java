/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KlantsessieComplianceRestController.java
 *             Auteur: duisr01
 *    Creatietijdstip: 30-6-2022 16:21
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie.GetSelectedRisicoService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie.KlantsessieStrategieService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.security.HtmlSanitizer;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.GetLowestEntiteitMiddelRisicoService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@RequiredArgsConstructor
@RestController
@RequestMapping("/api/klantsessie/strategie")
@Slf4j
public class KlantsessieStrategieRestController {
    private final KlantsessieStrategieService klantsessieStrategieService;
    private final GetLowestEntiteitMiddelRisicoService getLowestEntiteitMiddelRisicoService;
    private final GetSelectedRisicoService getSelectedRisicoService;

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/previous/{entiteitNummer}/{middelId}")
    public KlantsessieStrategieDto getPreviousKlantsessieStrategie(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
        return klantsessieStrategieService.getPreviousKlantsessieStrategie(entiteitNummer, middelId);
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/current/{entiteitNummer}/{middelId}")
    public KlantsessieStrategieDto getCurrentKlantsessieStrategie(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
        return klantsessieStrategieService.getCurrentKlantsessieStrategie(entiteitNummer, middelId);
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @PostMapping("/save/korteTermijn/{entiteitNummer}")
    public KlantsessieStrategieDto saveKorteTermijnKlantsessieStrategie(@PathVariable Long entiteitNummer,
                                                                        @RequestBody LoggingWrapper<KlantsessieStrategieDto> klantsessieStrategieDtoWrapper) {
        var klantsessieStrategieDto = klantsessieStrategieDtoWrapper.getWrappedObject();
        if (klantsessieStrategieDto.getKorteTermijn() != null) {
            klantsessieStrategieDto.setKorteTermijn(HtmlSanitizer.sanitizeHtml(klantsessieStrategieDto.getKorteTermijn()));
        }
        return klantsessieStrategieService.saveKlantsessieStrategieKorteTermijn(klantsessieStrategieDto, entiteitNummer, klantsessieStrategieDto.getMiddelId(), klantsessieStrategieDtoWrapper.getLoggingId());
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @PostMapping("/save/middellangeTermijn/{entiteitNummer}")
    public KlantsessieStrategieDto saveMiddellangeTermijnKlantsessieStrategie(@PathVariable Long entiteitNummer,
                                                                              @RequestBody LoggingWrapper<KlantsessieStrategieDto> klantsessieStrategieDtoWrapper) {
        var klantsessieStrategieDto = klantsessieStrategieDtoWrapper.getWrappedObject();
        if (klantsessieStrategieDto.getMiddellangeTermijn() != null) {
            klantsessieStrategieDto.setMiddellangeTermijn(HtmlSanitizer.sanitizeHtml(klantsessieStrategieDto.getMiddellangeTermijn()));
        }
        return klantsessieStrategieService.saveKlantsessieStrategieMiddelLangeTermijn(klantsessieStrategieDto,
                entiteitNummer, klantsessieStrategieDto.getMiddelId(), klantsessieStrategieDtoWrapper.getLoggingId());
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/risico/options/{entiteitNummer}/{middelId}")
    public List<MiddelRisico> getRisicoOptions(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
        return getLowestEntiteitMiddelRisicoService.getEntiteitMiddelRisicoWithLowestByEntiteitnummerAndMiddelId(entiteitNummer, middelId).stream().map(
                LowestEntiteitMiddelRisico::getLowest).collect(Collectors.toList());
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/risico/selected/{entiteitNummer}/{middelId}")
    public List<MiddelRisico> getSelectedRisicos(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
        return getSelectedRisicoService.getSelectedList(entiteitNummer, middelId).stream().map(
                KlantsessieStrategieRisico::getMiddelRisico).collect(Collectors.toList());
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @PostMapping("/risico/selections/save/{entiteitNummer}")
    public void saveSelectedRisicos(@PathVariable Long entiteitNummer, @RequestBody LoggingWrapper<List<KlantsessieStrategieRisico>> klantsessieStrategieRisicoWrapper) {
         klantsessieStrategieService.saveSelectedRisicos(entiteitNummer, klantsessieStrategieRisicoWrapper.getWrappedObject(), klantsessieStrategieRisicoWrapper.getLoggingId() );
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @DeleteMapping("/risico/delete/{entiteitNummer}/{klantsessieId}/{middelId}/{riscoId}")
    public void deleteKlantsessieStrategieRisico(@PathVariable Long entiteitNummer, @PathVariable Long klantsessieId,
            @PathVariable Integer middelId, @PathVariable Long riscoId, @RequestBody LoggingWrapper<Void> loggingWrapper) {
        klantsessieStrategieService.deleteKlantsessieStrategieRisico(entiteitNummer, klantsessieId, middelId, riscoId, loggingWrapper.getLoggingId());
    }
}
