package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class KenmerkRisicosKoppelingEntiteitMiddelKenmerkIdDto {

    private final MiddelKenmerk middelKenmerk;
    private final MiddelRisico middelRisico;
    private final Long entiteitMiddelKenmerkId;
}
