package nl.belastingdienst.iva.wd.kbs.zof.rest;

import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.GetRisicoDropdownOptionsService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/fiscaliteit/options")
public class FiscaliteitOptionsController {

    private final GetRisicoDropdownOptionsService getRisicoDropdownOptionsService;

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/middel-risico-status")
    public List<Kenmerk> getMiddelRisicoStatussen() {
        return getRisicoDropdownOptionsService.getZoFMiddelRisicoStatussen();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/middel-risico-beheersing")
    public List<Kenmerk> getZoFMiddelRisicoBeheersingOptions() {
        return getRisicoDropdownOptionsService.getZoFMiddelRisicoBeheersingOptions();
    }
}
