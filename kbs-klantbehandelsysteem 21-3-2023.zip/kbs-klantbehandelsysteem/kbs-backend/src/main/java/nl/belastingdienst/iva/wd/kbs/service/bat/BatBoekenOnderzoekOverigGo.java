package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

@Data
public class BatBoekenOnderzoekOverigGo extends  BatBoekenOnderzoek {

}
