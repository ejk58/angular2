package nl.belastingdienst.iva.wd.kbs.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.HelptextRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Helptext;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class HelptextService {
    /**
     * Reserved default value of ENTITEIT_NUMMER column in HELPTEXT table of Db2 database
     */
    private static final Long ENTITEIT_NUMMER_DATABASE_DEFAULT = 0L;

    private final HelptextRepository repo;
    private final Logging2Service logging2Service;

    public Optional<Helptext> getHelptext(String id) {
        return repo.findById(id).map(helptext -> {
            if(helptext.getEntiteit().equals(ENTITEIT_NUMMER_DATABASE_DEFAULT)){
                helptext.setEntiteit(null);
            }
            return helptext;
        });
    }

    public Helptext saveHelptext(Helptext helptext, String loggingId) {
        boolean exists = repo.existsById(new Helptext.PrimaryKey(helptext.getId(), helptext.getEntiteit()));
        Logging2.Bewerking bewerking = exists ? Logging2.Bewerking.UPDATE : Logging2.Bewerking.INSERT;

        if(helptext.getEntiteit() == null){
            helptext.setEntiteit(ENTITEIT_NUMMER_DATABASE_DEFAULT);
        } else {
            this.logging2Service.save(loggingId, helptext.getEntiteit(), bewerking);
        }

        return repo.save(helptext);
    }

    public Optional<Helptext> getHelptextForEntiteit(String helptextId, Long entiteitId) {
        return repo.findByIdAndEntiteit(helptextId, entiteitId);
    }

}
