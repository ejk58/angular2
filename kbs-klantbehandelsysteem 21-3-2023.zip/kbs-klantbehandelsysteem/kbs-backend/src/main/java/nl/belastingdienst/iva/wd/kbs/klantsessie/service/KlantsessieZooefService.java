package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieZooefRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieZooef;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.status.CheckZooefService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.security.HtmlSanitizer;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class KlantsessieZooefService {
    private final CheckZooefService checkZooefService;
    private final KlantsessieStatusService klantsessieStatusService;

    private final KlantsessieService klantsessieService;
    private final KlantsessieZooefRepository repo;
    private final Logging2Service logging2Service;

    private KlantsessieZooef saveAndSetStatus(Long entiteitnummer, KlantsessieZooef zooef){
        repo.save(zooef);
        klantsessieStatusService.setStepStatus(entiteitnummer, zooef.getMiddelId(), checkZooefService.getStepEnum(), checkZooefService.check(zooef.getKlantsessieId(), zooef.getMiddelId()));
        return zooef;
    }

    public KlantsessieZooef updateObservatiesActueel(Long entiteitNummer, Integer middelId, boolean observatiesActueel,
            String loggingId) {
        var ksHuidige = klantsessieService.getCurrentKlantsessie(entiteitNummer);
        Optional<KlantsessieZooef> zooefOpt = repo.findByKlantsessieIdAndMiddelId(ksHuidige.getId(), middelId);
        KlantsessieZooef zooef = zooefOpt
                .orElse(new KlantsessieZooef(ksHuidige.getId(), middelId, null, observatiesActueel));
        zooef.setVorigeObservatiesNogActueel(observatiesActueel);

        this.logging2Service.save(loggingId, entiteitNummer, Logging2.Bewerking.UPDATE);

        klantsessieService.getPreviousKlantsessie(entiteitNummer).ifPresent(klantsessie -> {
            if (observatiesActueel) {
                //business rule: when toggle is on (observatieActueel == true), observatie has to be copied from previous klantsessie
                KlantsessieZooef zooefVorige = klantsessie.getZichtOpOrganisatieEnFiscaliteitForMiddel(middelId);
                zooef.setObservaties(zooefVorige.getObservaties());
            } else {
                //business rule: when toggle is off (observatieActueel == false), observatie has to be set to null
                zooef.setObservaties(null);
            }
        });
        return saveAndSetStatus(entiteitNummer, zooef);
    }

    public KlantsessieZooef updateNieuweInzichtenEnObservaties(Long entiteitNummer, Integer middelId, String nieuweInzichtenEnObservaties, String loggingId) {
        var ksHuidige = klantsessieService.getCurrentKlantsessie(entiteitNummer);
        Optional<KlantsessieZooef> zooefOpt = repo.findByKlantsessieIdAndMiddelId(ksHuidige.getId(), middelId);
        KlantsessieZooef zooef = zooefOpt
                .orElse(new KlantsessieZooef(ksHuidige.getId(), middelId, null, false));
        zooef.setObservaties(nieuweInzichtenEnObservaties != null ? HtmlSanitizer.sanitizeHtml(nieuweInzichtenEnObservaties) : null);

        this.logging2Service.save(loggingId, entiteitNummer, Logging2.Bewerking.UPDATE);
        return saveAndSetStatus(entiteitNummer, zooef);
    }

    public KlantsessieZooef getHuidigeKlantsessieZooefObservatie(Long entiteitNummer, Integer middelId) {
        var ksHuidige = klantsessieService.getCurrentKlantsessie(entiteitNummer);
        Optional<KlantsessieZooef> zooefOpt = repo.findByKlantsessieIdAndMiddelId(ksHuidige.getId(), middelId);
        return zooefOpt.orElse(new KlantsessieZooef(ksHuidige.getId(), middelId));
    }
}
