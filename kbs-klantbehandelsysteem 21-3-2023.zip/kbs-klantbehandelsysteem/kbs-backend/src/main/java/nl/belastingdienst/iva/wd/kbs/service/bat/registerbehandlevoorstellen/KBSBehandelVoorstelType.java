package nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen;

import lombok.Getter;

@Getter
public enum KBSBehandelVoorstelType {

	BPV01("BPV01"),
	HEF01("HEF01");

	private String type;
	KBSBehandelVoorstelType(String type) { this.type = type; }

}
