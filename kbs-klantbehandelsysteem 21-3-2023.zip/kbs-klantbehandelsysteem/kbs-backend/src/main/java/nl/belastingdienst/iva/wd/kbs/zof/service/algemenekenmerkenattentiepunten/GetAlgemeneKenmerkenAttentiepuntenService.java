/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GetAlgemeneKenmerkenAttentiepuntenService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 8-6-2022 13:24
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service.algemenekenmerkenattentiepunten;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.EntiteitKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelspecifiekeKenmerkenRulesRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelspecifiekeKenmerkenRules;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class GetAlgemeneKenmerkenAttentiepuntenService {

	private final MiddelspecifiekeKenmerkenRulesRepository middelspecifiekeKenmerkenRulesRepository;
	private final EntiteitKenmerkRepository entiteitKenmerkRepository;

	public List<Kenmerk> getAlgemeneKenmerkenEnAttentiepunten(Long entiteitNummer, Integer middelId){
		List<MiddelspecifiekeKenmerkenRules> possibleChoices =
				middelspecifiekeKenmerkenRulesRepository.findAllByCompositeId_MiddelId(middelId);
		List<Kenmerk> toReturn = new ArrayList<>();

		for (MiddelspecifiekeKenmerkenRules mskr: possibleChoices){
			entiteitKenmerkRepository.findByEntiteitKenmerkId_BsnRsinAndEntiteitKenmerkId_KenmerkId(entiteitNummer, mskr.getCompositeId().getKenmerkId())
									 .ifPresent(selected -> toReturn.add(mskr.getKenmerk()));
		}
		return toReturn;
	}

}
