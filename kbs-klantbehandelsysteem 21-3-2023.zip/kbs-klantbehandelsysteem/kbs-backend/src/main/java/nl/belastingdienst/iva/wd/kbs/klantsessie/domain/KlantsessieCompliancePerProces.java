package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "KLANTSESSIE_COMPLIANCE_PER_PROCESS")
@IdClass(KlantsessieCompliancePerProces.PrimaryKey.class)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class KlantsessieCompliancePerProces {

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PrimaryKey implements Serializable {
        private static final long serialVersionUID = 5171068883494731859L;
        private Long klantsessieId;
        private Integer middelId;
    }

    @Id
    @Column(name = "KLANTSESSIE_ID", nullable = false)
    private Long klantsessieId;
    @Id
    @Column(name = "MIDDEL_ID", nullable = false)
    private Integer middelId;

    @Column(name = "VOOROVERLEG")
    private Integer vooroverleg;
    @Column(name = "HEFFING")
    private Integer heffing;
    @Column(name = "BEZWAREN")
    private Integer bezwaren;
}
