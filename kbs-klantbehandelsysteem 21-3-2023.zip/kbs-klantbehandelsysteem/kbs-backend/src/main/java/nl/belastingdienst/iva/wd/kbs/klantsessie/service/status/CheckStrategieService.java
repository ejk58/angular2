/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: CheckStrategieService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 3-8-2022 10:56
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.service.status;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieStrategieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStrategieRisicosRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.CheckStatusInterface;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CheckStrategieService implements CheckStatusInterface {

	public static final int STRATEGIE_EXPECTED_COUNT = 1;
	private final KlantSessieStrategieRepository klantSessieStrategieRepository;
	private final KlantsessieStrategieRisicosRepository klantsessieStrategieRisicosRepository;

	@Override
	public StepStatusEnum check(Long klantsessieId, Integer middelId) {
		var countRecordStrategieComplete = klantSessieStrategieRepository.countAllByKlantsessieIdAndMiddelIdAndMiddellangeTermijnNotNullAndKorteTermijnNotNull(
				klantsessieId, middelId);

		if(countRecordStrategieComplete == STRATEGIE_EXPECTED_COUNT){
			return StepStatusEnum.COMPLETED;
		}

		var countRisicosSelectie = klantsessieStrategieRisicosRepository.countAllByKlantsessieIdAndMiddelId(klantsessieId, middelId);
		var countRecordStrategie = klantSessieStrategieRepository.countAllByKlantsessieIdAndMiddelId(klantsessieId, middelId);

		if(countRecordStrategie > 0 || countRisicosSelectie > 0){
			return StepStatusEnum.TOUCHED;
		}

		return StepStatusEnum.INITIAL;
	}

	@Override
	public StepEnum getStepEnum() {
		return StepEnum.STRATEGIE;
	}
}
