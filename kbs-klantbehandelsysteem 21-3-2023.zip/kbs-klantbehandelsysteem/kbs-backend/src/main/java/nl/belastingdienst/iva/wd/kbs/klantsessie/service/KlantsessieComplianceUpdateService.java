/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KlantsessieComplianceUpdateService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 30-6-2022 13:45
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieComplianceRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkChild;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.status.CheckComplianceService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class KlantsessieComplianceUpdateService {
	private final CheckComplianceService checkComplianceService;
	private final KlantsessieStatusService klantsessieStatusService;

	private final KlantsessieService klantsessieService;
	private final KlantSessieComplianceRepository klantSessieComplianceRepository;

	private final Logging2Service logging2Service;

	private KlantsessieCompliance saveAndSetStatus(Long entiteitnummer, KlantsessieCompliance klantsessieCompliance){
		klantSessieComplianceRepository.save(klantsessieCompliance);
		klantsessieStatusService.setStepStatus(entiteitnummer, klantsessieCompliance.getMiddelId(),
				checkComplianceService.getStepEnum(), checkComplianceService.check(klantsessieCompliance.getKlantsessieId(), klantsessieCompliance.getMiddelId()));
		return klantsessieCompliance;
	}

	public KlantsessieCompliance updateScore(Long entiteitNummer, Integer middelId, KenmerkChild kenmerkChild, String loggingId) {
		var klantsessieCompliance = getKlantsessieCompliance(entiteitNummer, middelId, kenmerkChild);
		klantsessieCompliance.setScore(kenmerkChild.getScore());
		logging2Service.save(loggingId, entiteitNummer, Logging2.Bewerking.UPDATE);
		return saveAndSetStatus(entiteitNummer, klantsessieCompliance);
	}

	public KlantsessieCompliance updateToelichting(Long entiteitNummer, Integer middelId, KenmerkChild kenmerkChild, String loggingId) {
		var klantsessieCompliance = getKlantsessieCompliance(entiteitNummer, middelId, kenmerkChild);
		klantsessieCompliance.setToelichting(kenmerkChild.getToelichting());
		this.logging2Service.save(loggingId, entiteitNummer, Logging2.Bewerking.UPDATE);
		return saveAndSetStatus(entiteitNummer, klantsessieCompliance);
	}

	private KlantsessieCompliance getKlantsessieCompliance(Long entiteitNummer, Integer middelId,
			KenmerkChild kenmerkChild) {
		var klantsessie = this.klantsessieService.getCurrentKlantsessie(entiteitNummer);
		var primaryKey = new KlantsessieCompliance.PrimaryKey(
				klantsessie.getId(), middelId,
				kenmerkChild.getKenmerk().getId()
		);

		var klantsessieCompliance = this.klantSessieComplianceRepository.findById(primaryKey);
		if(klantsessieCompliance.isEmpty()){
			return new KlantsessieCompliance(
					klantsessie.getId(),
					middelId,
					kenmerkChild.getKenmerk().getId(),
					null,
					null, kenmerkChild.getKenmerk()
			);
		}

		return klantsessieCompliance.get();
	}
}
