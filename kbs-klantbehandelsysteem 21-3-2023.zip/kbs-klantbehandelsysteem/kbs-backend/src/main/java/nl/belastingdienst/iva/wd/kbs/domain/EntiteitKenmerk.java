package nl.belastingdienst.iva.wd.kbs.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ENTITEIT_KENMERK")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EntiteitKenmerk {

	@EmbeddedId
	private EntiteitKenmerkId entiteitKenmerkId;

	@Column(name="VALUE_LIST")
	private String values;

	public Long getBsnRsin() {
		return entiteitKenmerkId.getBsnRsin();
	}

	public String getKenmerkType() {
		return entiteitKenmerkId.getKenmerkType();
	}

	public Integer getKenmerkId() {
		return entiteitKenmerkId.getKenmerkId();
	}
}
