package nl.belastingdienst.iva.wd.kbs.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@IdClass(Helptext.PrimaryKey.class)
@Table(name = "HELPTEXT")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Helptext {
	@Id
	private String id;
	@Lob
	@Column(name = "HELPTEXT", columnDefinition = "CLOB")
	private String txt;
	@Column(name = "USER")
	private String userId;
	@Column(name = "CHANGE_DT")
	private Date changed;
	@Id
	private Long entiteit;

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class PrimaryKey implements Serializable {
		private static final long serialVersionUID = 2553702140795021901L;
		private String id;
		private Long entiteit;
	}
}
