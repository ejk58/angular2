/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GkvApiClient.java
 *             Auteur: duisr01
 *    Creatietijdstip: 28-2-2023 10:38
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.gkv.component;

import java.net.URI;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.kbs.service.RestTemplateClient;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class GkvApiClient {

	@Value("${gkv.api.base.url}")
	private String baseUrl;

	@Value("${gkv.api.key}")
	private String apiKey;

	private final RestTemplateClient restTemplateClient;

	public <T, U> ResponseEntity<U> doRequest(HttpMethod httpMethod, String uri, T body,
			Class<U> responseClass) {

		var completeUri = URI.create(baseUrl +uri);

		ParameterizedTypeReference<U> responseType = ParameterizedTypeReference.forType(responseClass);
		return this.restTemplateClient.doRequest(httpMethod, completeUri, body, responseType, apiKey, false);
	}

}
