package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

public interface PerProcesWithAbbreviatedMiddelProjection {
	String getAfkorting();
	String getVooroverleg();
	String getHeffing();
	String getBezwaren();
}
