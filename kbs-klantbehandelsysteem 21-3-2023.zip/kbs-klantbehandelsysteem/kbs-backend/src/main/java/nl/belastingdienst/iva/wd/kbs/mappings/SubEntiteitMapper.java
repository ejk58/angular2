package nl.belastingdienst.iva.wd.kbs.mappings;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import nl.belastingdienst.iva.wd.kbs.domain.ZooSubEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteitBranche;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaSubEntiteit;

@Mapper(componentModel = "spring")
public interface SubEntiteitMapper {
	@Mapping(target = "brancheCode", ignore = true)
	@Mapping(target = "aanvullingen", ignore = true)
	ZooSubEntiteit map(KtaSubEntiteit ktaSubEntiteit);

	@Mapping(target = "bsnRsin", source = "bsnRsin", ignore = true)
	@Mapping(target = "soortPersoon", ignore = true)
	@Mapping(target = "naam", ignore = true)
	@Mapping(target = "plaats", ignore = true)
	@Mapping(target = "beginDatum", ignore = true)
	@Mapping(target = "eindDatum", ignore = true)
	@Mapping(target = "aanvullingen", ignore = true)
	ZooSubEntiteit update(KtaEntiteitBranche ktaEntiteitBranche, @MappingTarget ZooSubEntiteit e);
}
