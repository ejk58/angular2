package nl.belastingdienst.iva.wd.kbs.klantsessie.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliancePerProces;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesWithAbbreviatedMiddelProjection;

@Repository
public interface KlantsessieCompliancePerProcesRepository extends JpaRepository<KlantsessieCompliancePerProces, KlantsessieCompliancePerProces.PrimaryKey> {
	Optional<KlantsessieCompliancePerProces> findByKlantsessieIdAndMiddelId(Long klantsessieId, Integer middelId);

	@Query(value = "SELECT ma.afkorting as afkorting, kv.kenmerk as vooroverleg, kh.kenmerk as heffing, kb.kenmerk as bezwaren "
			+ "from KlantsessieCompliancePerProces as kcpp "
			+ "LEFT JOIN MiddelnaamAfkorting as ma on kcpp.middelId=ma.middelId "
			+ "LEFT JOIN Kenmerk as kv on kcpp.vooroverleg=kv.id "
			+ "LEFT JOIN Kenmerk as kh on kcpp.heffing=kh.id "
			+ "LEFT JOIN Kenmerk as kb on kcpp.bezwaren=kb.id "
			+ "WHERE kcpp.klantsessieId=?1 ORDER BY ma.rank")
	List<PerProcesWithAbbreviatedMiddelProjection> findByKlantsessieIdWithAbbreviatedMiddel(Long klantsessieId);
}
