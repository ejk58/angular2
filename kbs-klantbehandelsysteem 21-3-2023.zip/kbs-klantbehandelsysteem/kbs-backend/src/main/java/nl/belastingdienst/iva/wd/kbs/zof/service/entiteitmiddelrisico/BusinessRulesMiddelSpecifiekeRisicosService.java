package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRulePolicies;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelection;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.BusinessRuleMiddelSpecifiekeRisicoDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.DuplicatePolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.HoofdRisicoSubRisicoWithKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.HoofdRisicoSubRisicoWithoutKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.HoofdRisicoWithKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.HoofdRisicoWithoutKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.mappings.EntiteitMiddelRisicoMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BusinessRulesMiddelSpecifiekeRisicosService {

	private final EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;
	private final EntiteitMiddelRisicoMapper entiteitMiddelRisicoMapper;
	private final ValidateRisicoLinkableToKenmerkService validateRisicoLinkableToKenmerkService;

	private static final BusinessRulePolicies<BusinessRuleMiddelSpecifiekeRisicoDto, EntiteitMiddelRisico> BUSINESS_RULE_MIDDEL_SPECIFIEKE_RISICO_POLICIES
			= new BusinessRulePolicies<BusinessRuleMiddelSpecifiekeRisicoDto, EntiteitMiddelRisico>()
																			.policy(new DuplicatePolicy())
																			.policy(new HoofdRisicoWithoutKenmerkPolicy())
																			.policy(new HoofdRisicoSubRisicoWithoutKenmerkPolicy())
																			.policy(new HoofdRisicoWithKenmerkPolicy())
																			.policy(new HoofdRisicoSubRisicoWithKenmerkPolicy())
			;

	/* Using optional of BusinessRuleError instead of an exception because exceptions are expensive
	*  and the violation of business rules will not be an exception in the program flow
	* */
	Optional<BusinessRuleError> validToBusinessRules(BusinessRuleMiddelSpecifiekeRisicoDto businessRuleMiddelSpecifiekeRisicoDto) {


		if(businessRuleMiddelSpecifiekeRisicoDto.getSelection().getEntiteitMiddelKenmerkId() != null){
			var kenmerkLinkableBusinessRuleError = validateRisicoLinkableToKenmerkService.validate(businessRuleMiddelSpecifiekeRisicoDto.getSelection());
			if(kenmerkLinkableBusinessRuleError.isPresent()){
				return kenmerkLinkableBusinessRuleError;
			}
		}


		for (var businessRulePolicy : BUSINESS_RULE_MIDDEL_SPECIFIEKE_RISICO_POLICIES.getBusinessRulePolicyList()) {
			boolean b = businessRuleMiddelSpecifiekeRisicoDto.getCollection()
															 .stream()
															 .anyMatch(
																	 businessRulePolicy.getPredicates(businessRuleMiddelSpecifiekeRisicoDto)
															 );
			if (b) {
				return Optional.of(new BusinessRuleError(businessRulePolicy.getErrorMessage(), businessRulePolicy.getPolicyClass()));
			}
		}

		return Optional.empty();
	}

	public Optional<BusinessRuleError> validate(Long entiteitNummer, MiddelSpecifiekeRisicoSelection selectie){
		List<EntiteitMiddelRisico> collectie = entiteitMiddelRisicoRepository.findEntiteitMiddelRisicosByEntiteitNummer(
				entiteitNummer);

		return this.validToBusinessRules(
				new BusinessRuleMiddelSpecifiekeRisicoDto(
						selectie,
						collectie
				)
		);
	}

	public Optional<BusinessRuleError> validateWithList(Long entiteitNummer, MiddelSpecifiekeRisicoSelection selectie, List<MiddelSpecifiekeRisicoSelection> selectionList){
		List<EntiteitMiddelRisico> entiteitMiddelRisicoInDb = entiteitMiddelRisicoRepository.findEntiteitMiddelRisicosByEntiteitNummer(
				entiteitNummer);

		var entiteitMiddelRisicosInMemory = entiteitMiddelRisicoMapper.map(selectionList);

		var combinedList = new ArrayList<EntiteitMiddelRisico>();
		combinedList.addAll(entiteitMiddelRisicoInDb);
		combinedList.addAll(entiteitMiddelRisicosInMemory);

		return this.validToBusinessRules(
				new BusinessRuleMiddelSpecifiekeRisicoDto(
						selectie,
						combinedList
				)
		);
	}

	public Optional<BusinessRuleError> validateList(Long entiteitNummer, List<MiddelSpecifiekeRisicoSelection> selectionList){
		List<EntiteitMiddelRisico> entiteitMiddelRisicoInDb = entiteitMiddelRisicoRepository.findEntiteitMiddelRisicosByEntiteitNummer(
				entiteitNummer);

		var combinedList = new ArrayList<>(entiteitMiddelRisicoInDb);
		for (MiddelSpecifiekeRisicoSelection selectie : selectionList) {
			Optional<BusinessRuleError> businessRuleError = this.validToBusinessRules(
					new BusinessRuleMiddelSpecifiekeRisicoDto(selectie, combinedList));

			if(businessRuleError.isPresent()){
				return businessRuleError;
			}

			combinedList.add(
					entiteitMiddelRisicoMapper.map(selectie)
			);
		}

		return Optional.empty();
	}


	public Optional<BusinessRuleError> validateWithCurrentId(Long entiteitNummer, MiddelSpecifiekeRisicoSelection selectie, Long currentId){
		List<EntiteitMiddelRisico> collectie = entiteitMiddelRisicoRepository.findEntiteitMiddelRisicosByEntiteitNummer(
				entiteitNummer).stream()
								 .filter(p -> !p.getId()
												.equals(currentId))
								 .collect(Collectors.toList());

		return this.validToBusinessRules(
				new BusinessRuleMiddelSpecifiekeRisicoDto(
						selectie,
						collectie
				)
		);
	}

}
