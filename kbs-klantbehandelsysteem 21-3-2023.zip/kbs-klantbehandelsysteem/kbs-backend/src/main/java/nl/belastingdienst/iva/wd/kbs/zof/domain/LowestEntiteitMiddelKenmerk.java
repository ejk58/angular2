/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: LowestEntiteitMiddelKenmerk.java
 *             Auteur: duisr01
 *    Creatietijdstip: 10-8-2022 08:40
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;

import lombok.Getter;

@Entity
@Table(name = "V_LOWESTKENMERK")
@Immutable
@Getter
public class LowestEntiteitMiddelKenmerk {
	@Id
	@Column(name = "ID")
	private Long id;
	@Column(name = "HOOFDKENMERK_ID")
	private Long hoofdKenmerkId;
	@Column(name = "SUBKENMERK1_ID")
	private Long subKenmerk1Id;
	@Column(name = "SUBKENMERK2_ID")
	private Long subKenmerk2Id;
	@Column(name = "SUBKENMERK3_ID")
	private Long subKenmerk3Id;
	@Column(name = "RANK")
	private Long rank;
	@Column(name = "ENTITEITNUMMER")
	private Long entiteitNummer;
	@OneToOne
	@JoinColumn(name = "LOWEST", referencedColumnName = "ID", insertable = false, updatable = false)
	private MiddelKenmerk lowest;
}
