package nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/* Here we are using the Map<String, Map<String, String>> to map the api response with below format
 {
  "HEF01": {
    "AB": "Aangiftebehandeling"
  },
 "BPV01": {
     "BPV01": "Actualiseren strategisch behandelplan/ITP"
  }
}
**/
@Data
public class Activiteit {

    @JsonIgnore
    private Map<String, ActiviteitenVanVoorstel> activiteitenPerVoorstelCode = new HashMap<>();

    @JsonAnySetter
    public void add(String voorstelCode, ActiviteitenVanVoorstel voorstelActiviteiten) {
        activiteitenPerVoorstelCode.put(voorstelCode, voorstelActiviteiten);
    }

    @Data
    public static class ActiviteitenVanVoorstel {

        @JsonIgnore
        private Map<String, String> activiteiten = new HashMap<>();

        @JsonAnySetter
        public void add(String key, String value) {
            activiteiten.put(key, value);
        }
    }
}
