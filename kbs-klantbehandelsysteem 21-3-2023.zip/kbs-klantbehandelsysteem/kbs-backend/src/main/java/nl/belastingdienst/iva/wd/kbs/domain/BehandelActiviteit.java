package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatPersoon;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BehandelActiviteit {
    private String id;
    private String bsnRsin;
    private String naam;
    private String behandelactiviteit;
    private List<String> behandelaars;
    private String middel;
    private String status;
    private List<BatPersoon> personen;
    private String voorstelType;
    private String subjectType;
    private String behandelActiviteitCode;
}
