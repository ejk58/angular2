package nl.belastingdienst.iva.wd.kbs.zof.domain;

import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class EntiteitMiddelKenmerkSelection  {
    private final Long hoofdKenmerkId;
    private final Long subKenmerk1Id;
    private final Long subKenmerk2Id;
    private final Long subKenmerk3Id;
    private final EntiteitMiddelKenmerkEnum entiteitMiddelKenmerkEnum;

    public EntiteitMiddelKenmerkSelection(Long hoofdKenmerkId, Long subKenmerk1Id, Long subKenmerk2Id, Long subKenmerk3Id) {

        EntiteitMiddelKenmerkEnum entiteitMiddelKenmerkEnumValue = EntiteitMiddelKenmerkEnum.valueOf(hoofdKenmerkId, subKenmerk1Id,
                subKenmerk2Id, subKenmerk3Id);
        if(entiteitMiddelKenmerkEnumValue.equals(EntiteitMiddelKenmerkEnum.UNKNOWN)){
            throw new BusinessRuleException("Wrongly formatted");
        }

        this.entiteitMiddelKenmerkEnum = entiteitMiddelKenmerkEnumValue;
        this.hoofdKenmerkId = hoofdKenmerkId;
        this.subKenmerk1Id = subKenmerk1Id;
        this.subKenmerk2Id = subKenmerk2Id;
        this.subKenmerk3Id = subKenmerk3Id;
    }

    public static EntiteitMiddelKenmerkSelection fromDto(EntiteitMiddelKenmerkDto selectieDto) {
        return new EntiteitMiddelKenmerkSelection(
                selectieDto.getHoofdKenmerkId(),
                selectieDto.getSubKenmerk1Id(),
                selectieDto.getSubKenmerk2Id(),
                selectieDto.getSubKenmerk3Id()
        );
    }

    public static EntiteitMiddelKenmerkSelection fromEntiteitMiddelKenmerk(EntiteitMiddelKenmerk entiteitMiddelKenmerk){
        return new EntiteitMiddelKenmerkSelection(
                entiteitMiddelKenmerk.getHoofdKenmerkId(),
                entiteitMiddelKenmerk.getSubKenmerk1Id(),
                entiteitMiddelKenmerk.getSubKenmerk2Id(),
                entiteitMiddelKenmerk.getSubKenmerk3Id()
        );
    }
}
