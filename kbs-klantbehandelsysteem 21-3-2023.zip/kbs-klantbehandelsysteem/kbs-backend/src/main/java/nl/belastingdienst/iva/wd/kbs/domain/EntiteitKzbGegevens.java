/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: Entiteit.java
 *             Auteur: schop13
 *    Creatietijdstip: 7-4-2021 11:41
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.Data;

//This should be used to map all Kzb Gegevens which are missing in the org service.
@Data
public class EntiteitKzbGegevens {

	private String kantoornaam;
	private String teamnaam;
	private Long branchecode;
	private String branchenaam;

}
