package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

/**
 * Interface needed for the auto mapping of the sql query result.
 *
 * @author hubeh00
 */
public interface ComplianceAankomendeKlantsessieProjection {
	Integer getId();

	String getKenmerk();

	Integer getKenmerkParentId();

	Integer getScore();

	Integer getStrategieGerichtOp();

	String getToelichting();
}

