package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieResultaatDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieResultaatService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/klantsessie/resultaat")
public class KlantsessieResultaatRestController {
    private final KlantsessieResultaatService klantsessieResultaatService;

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/{entiteitNummer}")
    public KlantsessieResultaatDto getKlantsessieResultaat(@PathVariable Long entiteitNummer) {
        return klantsessieResultaatService.getKlantsessieResultaat(entiteitNummer);
    }
}

