package nl.belastingdienst.iva.wd.kbs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkType;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class KenmerkService {

    private final KenmerkRepository repo;

    public Optional<Kenmerk> getKenmerk(Integer id) {
        return repo.findById(id);
    }

    public Optional<Kenmerk> getMiddelKenmerkByName(String middelName) {
        var groepen = List.of(KenmerkType.MID.getValue(), KenmerkType.KS_MID.getValue());
        return getKenmerkByNameAndGroepIn(middelName, groepen);
    }

    public Optional<Kenmerk> getKenmerkByNameAndGroepIn(String kenmerkName, List<String> groepen) {
        return repo.findByGroepInAndKenmerk(groepen, kenmerkName);
    }

    public Kenmerk getKenmerkOrNull(Integer id) {
        return repo.findById(id).orElse(null);
    }

    public List<Kenmerk> findKenmerkenByType(KenmerkType type) {
        return repo.findByGroepOrderById(type.getValue());
    }

    public List<Kenmerk> findZooEntiteitMiddelen() { return findKenmerkenByType(KenmerkType.MID); }

    public List<Kenmerk> findZooEntiteitAttentiepunten() { return findKenmerkenByType(KenmerkType.CBOBA); }

    public List<Kenmerk> findZooEntiteitAttentiepuntenLoonheffing() { return findKenmerkenByType(KenmerkType.CBLH); }

    public List<Kenmerk> findZooEntiteitAttentiepuntenInkomstenBelasting() { return findKenmerkenByType(KenmerkType.CBIBV); }

    public List<Kenmerk> findZooEntiteitAandachtsgebieden() {
        return findKenmerkenByType(KenmerkType.AG);
    }

    public List<Kenmerk> findZooBranchecodeAanvullingen() {
        return findKenmerkenByType(KenmerkType.BCAV);
    }

    public List<Kenmerk> findBedrijfsstrategieKenmerken() {
        return findKenmerkenByType(KenmerkType.BS);
    }

    public List<Kenmerk> findExterneOmgevingKenmerken() {
        return findKenmerkenByType(KenmerkType.EO);
    }

    public List<Kenmerk> findGovernanceStructuurKenmerken() {
        return findKenmerkenByType(KenmerkType.GS);
    }

    public List<Kenmerk> findRisicomanagementKenmerken() {
        return findKenmerkenByType(KenmerkType.RM);
    }

    public List<Kenmerk> findComplexiteitKenmerken() { return findKenmerkenByType(KenmerkType.CK); }

    public List<Kenmerk> actiePuntenKenmerken() { return findKenmerkenByType(KenmerkType.CBAP); }

    public List<Kenmerk> actiePuntenBalansKenmerken() { return findKenmerkenByType(KenmerkType.CBAPB); }

    public List<Kenmerk> actiePuntenWinstEnVerliesKenmerken() { return findKenmerkenByType(KenmerkType.CBAPW); }

    public List<Kenmerk> findKlantsessieComplianceComfort() { return findKenmerkenByType(KenmerkType.KS_COM); }

    public List<Kenmerk> findTestKenmerken() {
        return findKenmerkenByType(KenmerkType.TEST);
    }
}
