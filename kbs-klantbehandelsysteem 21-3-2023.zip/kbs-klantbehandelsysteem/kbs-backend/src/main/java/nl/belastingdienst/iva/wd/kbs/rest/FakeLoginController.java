package nl.belastingdienst.iva.wd.kbs.rest;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/*
* Controller to simulate log in/out via Swagger
* https://stackoverflow.com/questions/34386337/documenting-springs-login-logout-api-in-swagger
* */
@RestController
@Slf4j
@RequestMapping("/api")
public class FakeLoginController {

	//do not remove: configuration for authorization in Swagger
	private static class FakeLoginBody {
		@SuppressWarnings({"UnusedDeclaration"})
		String username;
		@SuppressWarnings({"UnusedDeclaration"})
		String password;
	}

	@ApiOperation("Login.")
	@PostMapping("/login")
	public void fakeLogin(@ApiParam(name = "body", value = "Example body (with qoutes and curly brackets):\n\n{\"username\": \"\", \"password\": \"\"}", required = true)
			@RequestBody FakeLoginBody body) {
		throw new IllegalStateException("This method shouldn't be called. It's implemented by Spring Security filters.");
	}

	@ApiOperation("Logout.")
	@PostMapping("/logout")
	public void fakeLogout() {
		throw new IllegalStateException("This method shouldn't be called. It's implemented by Spring Security filters.");
	}
}