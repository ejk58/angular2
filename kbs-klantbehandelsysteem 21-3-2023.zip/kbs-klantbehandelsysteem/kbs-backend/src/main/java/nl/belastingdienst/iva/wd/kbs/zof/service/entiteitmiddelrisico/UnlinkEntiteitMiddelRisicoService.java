/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: RemoveKenmerkRisicoKoppelingService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 19-4-2022 09:08
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UnlinkEntiteitMiddelRisicoService {
	private final EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;

	public void unlinkRisicosForEntiteitMiddelKenmerkId(Long entiteitMiddelKenmerkId){
		this.entiteitMiddelRisicoRepository.findAllByEntiteitMiddelKenmerkId(entiteitMiddelKenmerkId)
										   .forEach(emk -> {
											   emk.setEntiteitMiddelKenmerkId(null);
											   this.entiteitMiddelRisicoRepository.save(emk);
										   });
	}
}
