/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: Entiteit.java
 *             Auteur: schop13
 *    Creatietijdstip: 7-4-2021 11:41
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.kta.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Data;

@Entity
@Immutable
@Table(name = "VW154_KZB_ALGEMENE_GEGEVENS_ENTITEIT")
@Data
public class KtaEntiteit {

	/**
	 * dosnr is actually a Long (INTEGER in the database), but we treat it as a String so
	 * we can perform partial String matches during a query-by-example in
	 * {@link nl.belastingdienst.iva.wd.kbs.service.EntiteitService#search(KtaEntiteit)}.
	 */
	@Id
	@Column(name = "ENTITEITNUMMER")
	private String dosnr;
	@Column(name = "ENTITEITNAAM")
	private String dosnaam;
	@Column(name = "KANTOORCODE")
	private Long kantoorId;
	@Column(name = "KANTOORNAAM")
	private String kantnm;
	@Column(name = "TEAMCODE")
	private String dosteam;
	@Column(name = "TEAMNAAM")
	private String teamomschr;
	@Column(name = "FORMATIEDATUM")
	private Date formatiedat;
	@Column(name = "ONTBINDINGSDATUM")
	private Date ontbinddat;
	@Column(name = "BRANCHECODE")
	private Long branchecd;
	@Column(name = "BRANCHENAAM")
	private String omschr;
	@Column(name = "CONVENANTINDICATIE")
	private String convenantIndicatie;
}

