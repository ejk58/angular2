package nl.belastingdienst.iva.wd.kbs.configuration;

import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfiguration {
	private ApiInfo apiInfo() {
		return new ApiInfo("KBS Rest APIs",
				"To log in, use fake-login-controller login api to generate JWT token. Click \"Try it out\" and "
						+ "fill in username and password. Generated token can be found in server response. \n "
                        + "Token (in format \"Bearer kiuadshfiuha\") should be pasted in JWT field when clicking Authorize.",
				"1.0",
				"",
				new Contact("Webdevelopment Team 3", "", ""),
				"",
				"",
				Collections.emptyList());
	}

	@Bean
	public Docket api() {
		return new Docket(DocumentationType.SWAGGER_2)
				.apiInfo(apiInfo())
				.securityContexts(List.of(securityContext()))
				.securitySchemes(List.of(apiKey()))
				.select()
				.apis(RequestHandlerSelectors.any())
				.paths(PathSelectors.any())
				.build();
	}

	/*
	* credits: https://www.baeldung.com/spring-boot-swagger-jwt
	* */
	private ApiKey apiKey() {
		return new ApiKey("JWT","Authorization", "header");
	}

	private SecurityContext securityContext() {
		return SecurityContext.builder()
				.securityReferences(defaultAuth())
				.build();
	}

	List<SecurityReference> defaultAuth() {
		var authorizationScope
				= new AuthorizationScope("global", "accessEverything");
		var authorizationScopes = new AuthorizationScope[1];
		authorizationScopes[0] = authorizationScope;
		return List.of(new SecurityReference("JWT", authorizationScopes));
	}
}
