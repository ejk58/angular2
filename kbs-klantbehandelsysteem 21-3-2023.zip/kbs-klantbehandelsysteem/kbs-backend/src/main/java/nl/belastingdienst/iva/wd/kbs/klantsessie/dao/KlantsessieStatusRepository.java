package nl.belastingdienst.iva.wd.kbs.klantsessie.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStatus;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;

public interface KlantsessieStatusRepository extends JpaRepository<KlantsessieStatus, KlantsessieStatus.PrimaryKey> {
	Optional<KlantsessieStatus> findByKlantsessieIdAndMiddelId(Long klantsessieId, Integer middelId);
	int countAllByKlantsessieIdAndVoorbereidingAfgerondIsTrueAndVoorbereidingAfrondenStatus(Long klantsessieId, StepStatusEnum status);
}
