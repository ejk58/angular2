package nl.belastingdienst.iva.wd.kbs.rest;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkType;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkWithValuesDto;
import nl.belastingdienst.iva.wd.kbs.domain.MultiSelectKenmerk;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitKenmerkService;
import nl.belastingdienst.iva.wd.kbs.service.KenmerkService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/kenmerken")
public class KenmerkController {

    private final KenmerkService kenmerkService;
    private final EntiteitKenmerkService entiteitKenmerkService;

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/testKenmerken")
    public List<Kenmerk> getTestKenmerken() {
        return kenmerkService.findTestKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/middelen")
    public List<Kenmerk> getZooMiddelen() {
        return kenmerkService.findZooEntiteitMiddelen();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/middelen/{name}")
    public Optional<Kenmerk> getMiddelByName(@PathVariable String name) {
        return kenmerkService.getMiddelKenmerkByName(name);
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/attentiepunten")
    public List<Kenmerk> getZooAttentiepunten() { return kenmerkService.findZooEntiteitAttentiepunten(); }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/attentiepunten-loonheffing")
    public List<Kenmerk> getZooAttentiepuntenLoonheffing() { return kenmerkService.findZooEntiteitAttentiepuntenLoonheffing(); }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/aandachtsgebieden")
    public List<Kenmerk> getZooAandachtsgebieden() {
        return kenmerkService.findZooEntiteitAandachtsgebieden();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/bedrijfsstrategien")
    public List<Kenmerk> getBedrijfsstrategien() {
        return kenmerkService.findBedrijfsstrategieKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/externeOmgeving")
    public List<Kenmerk> getExterneOmgeving() {
        return kenmerkService.findExterneOmgevingKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/governanceStructuur")
    public List<Kenmerk> getGovernanceStructuur() {
        return kenmerkService.findGovernanceStructuurKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/risicomanagement")
    public List<Kenmerk> getRisicomanagement() {
        return kenmerkService.findRisicomanagementKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/branche-code-aanvullingen")
    public List<Kenmerk> getZooBranchecodeAanvullingen() {
        return kenmerkService.findZooBranchecodeAanvullingen();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/complexiteit")
    public List<Kenmerk> getComplexiteitKenmerken() {
        return kenmerkService.findComplexiteitKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/cijferbeoordeling/actiepunten")
    public List<Kenmerk> getActiepuntenKenmerken() {
        return kenmerkService.actiePuntenKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/cijferbeoordeling/actiepunten-balans")
    public List<Kenmerk> getActiepuntenBalansKenmerken() {
        return kenmerkService.actiePuntenBalansKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/cijferbeoordeling/actiepunten-winst-en-verlies")
    public List<Kenmerk> getActiepuntenWinstEnVerliesKenmerken() {
        return kenmerkService.actiePuntenWinstEnVerliesKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/klantsessie/compliance-comfort")
    public List<Kenmerk> getKlantsessieComplianceComfort() {
        return kenmerkService.findKlantsessieComplianceComfort();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/complexiteit/selected")
    public List<Kenmerk> getSelectedComplexiteitKenmerken(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedComplexiteitKenmerken(bsnRsin));
    }

    private List<Kenmerk> mapToKenmerken(List<EntiteitKenmerk> ekList) {
        return ekList.stream()
                .map(ek -> kenmerkService.getKenmerkOrNull(ek.getKenmerkId()))
                .collect(Collectors.toList());
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/aandachtsgebieden/selected")
    public List<KenmerkWithValuesDto> getSelectedAandachtsgebieden(@PathVariable Long bsnRsin) {
        List<EntiteitKenmerk> ekList = entiteitKenmerkService.getSelectedAandachtsgebieden(bsnRsin);
        if (ekList.isEmpty()) {
            return Collections.emptyList();
        }

        List<KenmerkWithValuesDto> result = new ArrayList<>();
        List<Kenmerk> kenmerken = mapToKenmerken(ekList);
        for (int i = 0; i < kenmerken.size(); i++) {
            Kenmerk kenmerk = kenmerken.get(i);
            KenmerkWithValuesDto kwd = new KenmerkWithValuesDto();
            kwd.setId(kenmerk.getId());
            kwd.setKenmerk(kenmerk.getKenmerk());
            kwd.setGroep(kenmerk.getGroep());
            kwd.setValues(Boolean.parseBoolean(ekList.get(i).getValues()));
            result.add(kwd);
        }
        return result;
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/middelen/selected")
    public List<Kenmerk> geSelectedMiddelen(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedMiddelen(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/{name}/{groep}/middel/selected")
    public Kenmerk getSelectedMiddelByNameAndGroup(@PathVariable Long bsnRsin, @PathVariable String name, @PathVariable String groep) {
        List<EntiteitKenmerk> entiteitKenmerk = entiteitKenmerkService.getSelectedMiddelen(bsnRsin);
        if (entiteitKenmerk.isEmpty()) {
            return null;
        }

        return mapToKenmerken(entiteitKenmerk).stream()
                .filter(k -> k.getKenmerk().equals(name) && k.getGroep().equals(groep))
                .findFirst()
                .orElse(null);
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/attentiepunten/selected")
    public List<Kenmerk> geSelectedAttentiepunten(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedAttentiepunten(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/attentiepunten-loonheffing/selected")
    public List<Kenmerk> getSelectedAttentiepuntenLoonheffing(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedAttentiepuntenLoonheffing(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/actiepunten/selected")
    public List<Kenmerk> geSelectedActiepunten(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedActiepunten(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/actiepunten-balans/selected")
    public List<Kenmerk> geSelectedActiepuntenBalans(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedActiepuntenBalans(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/actiepunten-winst-en-verlies/selected")
    public List<Kenmerk> geSelectedActiepuntenWinstEnVerlies(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedActiepuntenWinstenVerlies(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/bedrijfsstrategien/selected")
    public List<Kenmerk> geSelectedBedrijfsstrategien(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedBedrijfsstrategieen(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/externeOmgeving/selected")
    public List<Kenmerk> getSelectedExterneOmgeving(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedExterneOmgevingKenmerken(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/governanceStructuur/selected")
    public List<Kenmerk> getSelectedGovernanceStructuur(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedGovernanceStructuurKenmerken(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/risicomanagement/selected")
    public List<Kenmerk> getSelectedRisicomanagement(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedRisicomanagementKenmerken(bsnRsin));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/attentiepunten-inkomstenbelasting")
    public List<MultiSelectKenmerk> getZooAttentiepuntenInkomstenBelasting() {

        List<Kenmerk> kenmerken = kenmerkService.findZooEntiteitAttentiepuntenInkomstenBelasting();

        List<Kenmerk> groups = kenmerken.stream()
                .filter(kenmerk -> kenmerk.getKenmerkParentId() == null)
                .collect(Collectors.toList());
        List<Kenmerk> items = kenmerken.stream()
                .filter(kenmerk -> kenmerk.getKenmerkParentId() != null)
                .collect(Collectors.toList());

        List<MultiSelectKenmerk> result = new ArrayList<>();
        for (Kenmerk group : groups) {
            result.add(new MultiSelectKenmerk(group.getId(), group.getKenmerk()));
        }

        for (Kenmerk child : items) {
            result.stream()
                    .filter(p -> p.getId().equals(child.getKenmerkParentId()))
                    .findFirst()
                    .ifPresent(group -> group.getItems().add(child));
        }
        return result;
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/attentiepunten-inkomstenbelasting/selected")
    public List<Kenmerk> getSelectedActiepuntIds(@PathVariable Long bsnRsin) {
        return mapToKenmerken(entiteitKenmerkService.getSelectedAttentiepuntIds(bsnRsin));
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @PostMapping("/{bsnRsin}/{kenmerkType}/selections/save")
    public void saveSelectedKenmerken(@PathVariable Long bsnRsin,
                                      @PathVariable String kenmerkType,
                                      @RequestBody LoggingWrapper<List<KenmerkWithValuesDto>> kenmerken) {
        entiteitKenmerkService.saveEntiteitKenmerken(bsnRsin, kenmerkType, kenmerken.getWrappedObject(), kenmerken.getLoggingId());
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @PostMapping("/{bsnRsin}/{kenmerkType}/selections/remove")
    public void removeSelectedKenmerken(@PathVariable Long bsnRsin,
            @PathVariable String kenmerkType,
            @RequestBody LoggingWrapper<List<Integer>> kenmerkenIds) {
                kenmerkenIds.getWrappedObject().forEach(id -> {
                    entiteitKenmerkService.deleteEntiteitKenmerk(bsnRsin, kenmerkType, id, kenmerkenIds.getLoggingId());
        });
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @DeleteMapping("/{bsnRsin}/{kenmerkType}/selections/{kenmerkId}/delete")
    public void saveSelectedKenmerk(@PathVariable Long bsnRsin,
            @PathVariable String kenmerkType,
            @PathVariable Integer kenmerkId,
            @RequestBody LoggingWrapper<Void> loggingWrapper) {
        entiteitKenmerkService.deleteEntiteitKenmerk(bsnRsin, kenmerkType, kenmerkId, loggingWrapper.getLoggingId());
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/{entiteitNummer}/zoo/branchecodeaanvulling/selected")
    public List<Kenmerk> getEntiteitKenmerkAanvullingenBranchecode(@PathVariable Long entiteitNummer) {
        return mapToKenmerken(entiteitKenmerkService.getBranchecodeAanvullingen(entiteitNummer));
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @GetMapping("/{bsnRsin}/sector")
    public Integer getZooAardSector(@PathVariable Long bsnRsin) {
        return entiteitKenmerkService.getSelectedSector(bsnRsin)
                .map(EntiteitKenmerk::getValues).map(Integer::parseInt)
                .orElse(null);
        // TODO: Return 404 instead of null if Optional is empty?
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @PostMapping("/{bsnRsin}/sector")
    public void saveZooAardSector(@PathVariable Long bsnRsin, @RequestBody LoggingWrapper<Integer> sector) {
        entiteitKenmerkService.saveSelectedSector(bsnRsin, sector.getWrappedObject(), sector.getLoggingId());
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#bsnRsin)")
    @PutMapping(value = "/{bsnRsin}/{kenmerkType}/selections/update/{parentEntiteitnummer}")
    public void updateSelectedKenmerken(@PathVariable Long bsnRsin,
                                      @PathVariable String kenmerkType,
                                        @PathVariable Long parentEntiteitnummer,
                                      @RequestBody LoggingWrapper<KenmerkUpdateBody> kenmerken2Update) {
        entiteitKenmerkService.deleteEntiteitKenmerken(bsnRsin, kenmerkType, kenmerken2Update.getWrappedObject().getEntiteitKenmerken2Remove(), kenmerken2Update.getLoggingId(), parentEntiteitnummer);
        entiteitKenmerkService.saveEntiteitKenmerken(bsnRsin, kenmerkType, kenmerken2Update.getWrappedObject().getEntiteitKenmerken2Save(), kenmerken2Update.getLoggingId(), parentEntiteitnummer);
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/strategie-gebaseerd-op")
    public List<Kenmerk> getStrategieenGebaseerdOp() {
        return kenmerkService.findKenmerkenByType(KenmerkType.KS_STRAT);
    }

}
@Data
class KenmerkUpdateBody {
    private List<KenmerkWithValuesDto> entiteitKenmerken2Save;
    private List<KenmerkWithValuesDto> entiteitKenmerken2Remove;
}
