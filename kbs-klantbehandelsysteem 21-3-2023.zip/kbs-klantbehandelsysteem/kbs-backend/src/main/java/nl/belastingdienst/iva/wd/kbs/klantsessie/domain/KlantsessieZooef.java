/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KlantsessieZooef.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 13-5-2022 14:28
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Setter;

@Entity
@IdClass(KlantsessieZooef.PrimaryKey.class)
@Table(name = "KLANTSESSIE_ZOOEF")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class KlantsessieZooef {
	public static final String NON_PRIMARY_COLUMN_NAME_OBSERVATIES = "observaties";
	public static final String NON_PRIMARY_COLUMN_NAME_OBSERVATIES_ACTUEEL = "vorigeObservatiesNogActueel";

	@Data
	public static class PrimaryKey implements Serializable {
		private static final long serialVersionUID = -9033625430937003553L;

		private Long klantsessieId;
		private Integer middelId;
	}

	@Id
	@Column(name = "KLANTSESSIE_ID", nullable = false)
	private Long klantsessieId;
	@Id
	@Column(name = "MIDDEL_ID", nullable = false)
	private Integer middelId;
	@Column(name = "OBSERVATIES")
	private String observaties;
	@Column(name = "VORIGE_OBSERVATIES_NOG_ACTUEEL", nullable = false)
	private Boolean vorigeObservatiesNogActueel;

	public KlantsessieZooef(Long klantsessieId, Integer middelId) {
		setKlantsessieId(klantsessieId);
		setMiddelId(middelId);
		setVorigeObservatiesNogActueel(Boolean.FALSE);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		KlantsessieZooef that = (KlantsessieZooef) o;
		return klantsessieId.equals(that.klantsessieId) && middelId.equals(that.middelId) && Objects.equals(observaties, that.observaties) && vorigeObservatiesNogActueel.equals(that.vorigeObservatiesNogActueel);
	}

	@Override
	public int hashCode() {
		return Objects.hash(klantsessieId, middelId, observaties, vorigeObservatiesNogActueel);
	}
}
