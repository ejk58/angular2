package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface MiddelRisicoRepository extends JpaRepository<MiddelRisico, Long> {
    List<MiddelRisico> findAllByMiddelIdOrderByRank(Integer middelId);
    MiddelRisico findMiddelRisicoById(Long id);
    List<MiddelRisico> findAllByIdIn(Set<Long> ids);
}
