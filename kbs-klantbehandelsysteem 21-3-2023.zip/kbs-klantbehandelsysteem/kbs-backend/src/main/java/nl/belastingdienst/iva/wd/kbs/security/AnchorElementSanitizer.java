/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: AnchorElementSanitizer.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 29-12-2021 16:10
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.security;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AnchorElementSanitizer {

	public static final String TARGET = "target";
	public static final String BLANK = "_blank";
	public static final String AT_SIGN = "@";
	public static final String HREF_START = "href=\"";
	public static final String HREF_MAILTO = HREF_START + "mailto:";
	private static final String HREF_HTTPS = HREF_START + "https://";
	/**
	 * <pre>
	 * Matches the start of the href attribute where the value starts with the HTTP URL scheme (case-insensitive).
	 *
	 * Example matches:
	 * - href="http://
	 * - href="https://
	 * - href="//
	 * </pre>
	 */
	static final Pattern HREF_HTTP_PATTERN = Pattern.compile(HREF_START + "(https?:)?//", Pattern.CASE_INSENSITIVE);
	/**
	 * Matches anchor elements from opening tag &lt;a> to closing tag &lt;/a> (case-insensitive).
	 * Capture group 1 is the value of the {@code href} attribute. Capture group 2 is the content (textual representation).
	 */
	public static final Pattern ANCHOR_ELEMENT_PATTERN = Pattern.compile("<a [^>]*?" + HREF_START + "(.*?)\"[^>]*?>(.*?)</a>",
			Pattern.CASE_INSENSITIVE);

	public static String addOrSetTargetToBlank(String elementName, List<String> attrs) {
		final int targetIndex = attrs.indexOf(TARGET);
		if (-1 == targetIndex) {
			attrs.add(TARGET);
			attrs.add(BLANK);
		} else {
			attrs.set(targetIndex + 1, BLANK);
		}
		return elementName;
	}

	/**
	 * Replaces the {@code href} part of anchor elements with the textual representation.
	 * This helps prevent users getting tricked into clicking on malicious links, such as:
	 * <pre>{@code
	 * <a href="https://evil-corp.example.org">https://belastingdienst.nl</a>
	 *          ^-- href part             --^  ^-- text part          --^
	 * }</pre>
	 */
	public static String sanitizeHrefAttributeIfAnchorElementsPresent(String html) {
		Matcher m = ANCHOR_ELEMENT_PATTERN.matcher(html);
		StringBuilder sb = new StringBuilder();
		while (m.find()) { // For each anchor element found in HTML
			String fullMatch = m.group();
			String hrefPart = m.group(1);
			String textPart = m.group(2);
			String sanitizedAnchorHtml = fullMatch.replace(hrefPart, textPart);
			sanitizedAnchorHtml = fixAnchorHrefUrlScheme(sanitizedAnchorHtml);
			m.appendReplacement(sb, sanitizedAnchorHtml);
		}
		m.appendTail(sb);
		return sb.toString();
	}
	// TODO: Consider replace this implementation with a custom HtmlStreamEventProcessor for anchor elements:
	//   https://github.com/OWASP/java-html-sanitizer/issues/101#issuecomment-280969324

	public static String fixAnchorHrefUrlScheme(String anchorHtml) {
		if (anchorHtml.contains(AT_SIGN)) {
			// Link contains an email address
			if (!anchorHtml.contains(HREF_MAILTO)) {
				// The mailto URL scheme is missing
				anchorHtml = anchorHtml.replace(HREF_START, HREF_MAILTO);
			}
		} else if (!HREF_HTTP_PATTERN.matcher(anchorHtml).find()) {
			// Link should point to a website, but is missing the HTTP(S) URL scheme
			anchorHtml = anchorHtml.replace(HREF_START, HREF_HTTPS);
		}
		return anchorHtml;
	}
}
