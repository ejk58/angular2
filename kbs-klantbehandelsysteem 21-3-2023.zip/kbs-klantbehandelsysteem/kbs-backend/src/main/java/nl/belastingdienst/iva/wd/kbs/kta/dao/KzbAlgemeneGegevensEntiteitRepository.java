package nl.belastingdienst.iva.wd.kbs.kta.dao;

import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.kta.domain.KzbAlgemeneGegevensEntiteit;

@Repository
public interface KzbAlgemeneGegevensEntiteitRepository extends ReadOnlyJpaRepository<KzbAlgemeneGegevensEntiteit, Long> {
}
