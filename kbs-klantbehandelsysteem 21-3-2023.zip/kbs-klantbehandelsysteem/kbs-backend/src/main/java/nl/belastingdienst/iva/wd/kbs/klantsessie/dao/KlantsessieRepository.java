package nl.belastingdienst.iva.wd.kbs.klantsessie.dao;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface KlantsessieRepository extends JpaRepository<Klantsessie, Long> {

	Optional<Klantsessie> findFirstByEntiteitNummerAndEinddatumIsNotNullOrderByStartdatumDesc(Long entiteitnummer);

	/**
	 * @deprecated Please use {@link KlantsessieService#getCurrentKlantsessie(Long)}. It guarantees that a valid Klantsessie is
	 * returned
	 */
	@Deprecated
	@SuppressWarnings({ "java:S1133", "java:S1123", "DeprecatedIsStillUsed" })
	Optional<Klantsessie> findByEntiteitNummerAndEinddatumIsNull(Long entiteitNummer);

	Integer countKlantsessiesByIdAndControlePlaatsgevondenFalse(Long id);

	List<Klantsessie> findFirst3ByEntiteitNummerAndEinddatumIsNotNullOrderByEinddatumDesc(Long entiteitnummer);
}
