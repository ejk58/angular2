package nl.belastingdienst.iva.wd.kbs.zof.rest;

import java.util.Optional;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleResponse;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkSelection;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk.BusinessRulesMiddelSpecifiekeKenmerkenService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/middel-specifieke-kenmerken")
public class MiddelSpecifiekeKenmerkenController {

	private final BusinessRulesMiddelSpecifiekeKenmerkenService businessRulesMiddelSpecifiekeKenmerkenService;

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("check/{entiteitNummer}")
	public BusinessRuleResponse checkValidToBusinessRules(@RequestBody EntiteitMiddelKenmerkDto selectieDto,
			@PathVariable Long entiteitNummer) {

		var selectie = EntiteitMiddelKenmerkSelection.fromDto(selectieDto);

		Optional<BusinessRuleError> businessRuleError;
		if (selectieDto.getId() != null) {
			businessRuleError = businessRulesMiddelSpecifiekeKenmerkenService.validateExcludingCurrentId(entiteitNummer, selectie, selectieDto.getId());
		} else {
			businessRuleError = businessRulesMiddelSpecifiekeKenmerkenService.validate(entiteitNummer, selectie);
		}
		return new BusinessRuleResponse(businessRuleError.map(BusinessRuleError::getMessage).orElse(null));
	}
}
