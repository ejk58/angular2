/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GetLoggingService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 26-9-2022 12:02
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.logging.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.logging.dao.Logging2Repository;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.exception.FailedToRetrieveLoggingDataException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class Logging2Service {
	private final Logging2Repository logging2Repository;

	public Optional<Logging2> getLatestLogging(String loggingId, Long entiteitnummer){
		return this.logging2Repository.findFirstByLoggingIdAndEntiteitNummerOrderByChangedAtDesc(loggingId, entiteitnummer);
	}

	public void save(String loggingId, Long entiteitNummer, Logging2.Bewerking bewerking) {

		if(loggingId == null || bewerking == null || entiteitNummer == null){
			throw new FailedToRetrieveLoggingDataException();
		}

		var sourceMethod = StackWalker.getInstance()
									  .walk(s -> s.skip(1)
												  .findFirst()
												  .map(stackFrame -> stackFrame.getClassName() + "." + stackFrame.getMethodName())
												  .orElse(null)
									  );

		var currentPrincipalName = SecurityContextHolder.getContext().getAuthentication().getName();
		if (currentPrincipalName.isBlank()){
			throw new FailedToRetrieveLoggingDataException("Logging is mislukt: gebruiker is niet ingelogd!");
		}

		this.logging2Repository.save(
				new Logging2(
						null,
						currentPrincipalName,
						LocalDateTime.now(), entiteitNummer, loggingId,
						bewerking.name(),
						sourceMethod
				)
		);
	}
}
