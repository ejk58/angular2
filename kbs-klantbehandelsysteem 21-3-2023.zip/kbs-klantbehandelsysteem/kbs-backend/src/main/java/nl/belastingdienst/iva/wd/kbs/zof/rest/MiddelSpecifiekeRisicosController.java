package nl.belastingdienst.iva.wd.kbs.zof.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleResponse;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisicoDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisicoDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoCheckListDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelection;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelectionDto;
import nl.belastingdienst.iva.wd.kbs.zof.mappings.EntiteitMiddelRisicoMapper;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.BusinessRulesMiddelSpecifiekeRisicosService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.GetRisicoOverviewService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.SaveNewEntiteitMiddelRisicoListService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/middel-specifieke-risicos")
public class MiddelSpecifiekeRisicosController {

	private final BusinessRulesMiddelSpecifiekeRisicosService businessRulesMiddelSpecifiekeRisicosService;
	private final SaveNewEntiteitMiddelRisicoListService saveNewEntiteitMiddelRisicoListService;
	private final GetRisicoOverviewService getRisicoOverviewService;
	private final EntiteitMiddelRisicoMapper entiteitMiddelRisicoMapper;

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("{entiteitNummer}")
	public List<LowestEntiteitMiddelRisicoDto> getOverview(@PathVariable Long entiteitNummer){
		return this.getRisicoOverviewService.getRisicoOverview(entiteitNummer);
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("check/{entiteitNummer}")
	public BusinessRuleResponse checkValidToBusinessRules(@RequestBody MiddelSpecifiekeRisicoSelectionDto selectieDto,
			@PathVariable Long entiteitNummer) {

		var selectie = MiddelSpecifiekeRisicoSelection.fromDto(selectieDto);

		if (selectieDto.getCurrentId() != null) { // when editing, omit current entity in db.
			Optional<BusinessRuleError> businessRuleError = businessRulesMiddelSpecifiekeRisicosService.validateWithCurrentId(entiteitNummer, selectie, selectieDto.getCurrentId());
			return new BusinessRuleResponse(businessRuleError.map(BusinessRuleError::getMessage)
															 .orElse(null));
		}

		Optional<BusinessRuleError> businessRuleError = businessRulesMiddelSpecifiekeRisicosService.validate(entiteitNummer, selectie);
		return new BusinessRuleResponse(businessRuleError.map(BusinessRuleError::getMessage)
														 .orElse(null));

	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("check/list/{entiteitNummer}")
	public BusinessRuleResponse checkListValidToBusinessRules(@RequestBody MiddelSpecifiekeRisicoCheckListDto middelSpecifiekeRisicoCheckListDto,
			@PathVariable Long entiteitNummer) {

		var middelSpecifiekeRisicoList = middelSpecifiekeRisicoCheckListDto.getMiddelSpecifiekeRisicoList();
		var middelSpecifiekeRisico = middelSpecifiekeRisicoCheckListDto.getMiddelSpecifiekeRisico();

		if(middelSpecifiekeRisico.getCurrentId() != null){
			middelSpecifiekeRisicoList = middelSpecifiekeRisicoList.stream()
					.filter(msrs -> !msrs.getId().equals(middelSpecifiekeRisico.getCurrentId())).collect(Collectors.toList());
		}

		Optional<BusinessRuleError> businessRuleError = businessRulesMiddelSpecifiekeRisicosService.validateWithList(
				entiteitNummer,
				MiddelSpecifiekeRisicoSelection.fromDto(middelSpecifiekeRisico),
				MiddelSpecifiekeRisicoSelection.from(middelSpecifiekeRisicoList)
		);
		return new BusinessRuleResponse(businessRuleError.map(BusinessRuleError::getMessage)
														 .orElse(null));

	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("save/list/{entiteitNummer}")
	public BusinessRuleResponse saveListValidToBusinessRules(@RequestBody LoggingWrapper<List<EntiteitMiddelRisicoDto>> entiteitMiddelRisicoDtoList,
			@PathVariable Long entiteitNummer) {

		var entiteitMiddelRisico = this.entiteitMiddelRisicoMapper.mapFromDto(entiteitMiddelRisicoDtoList.getWrappedObject());

		try {
			this.saveNewEntiteitMiddelRisicoListService.save(entiteitMiddelRisico, entiteitNummer,
					entiteitMiddelRisicoDtoList.getLoggingId());
		} catch (BusinessRuleException e){
			log.info(e.getMessage(), e);
			return new BusinessRuleResponse(e.getMessage());
		}

		return null;
	}


}
