/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: DeleteEntiteitMiddelKenmerkService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 8-6-2022 13:06
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DeleteEntiteitMiddelKenmerkService {

	private final EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;
	private final Logging2Service logging2Service;

	public void delete(Long entiteitNummer, Long id, String loggingId) {
		entiteitMiddelKenmerkRepository.findByEntiteitNummerAndId(entiteitNummer, id).ifPresent(entiteitMiddelKenmerk -> {
			this.logging2Service.save(loggingId, entiteitMiddelKenmerk.getEntiteitNummer(), Logging2.Bewerking.DELETE);

			entiteitMiddelKenmerkRepository.delete(entiteitMiddelKenmerk);
		});
	}
}
