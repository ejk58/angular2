package nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BehandelvoorstelOption {
    private VoorstelType voorstelType;
    private Map<String, String> activiteitCodes;
}
