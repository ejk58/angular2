package nl.belastingdienst.iva.wd.kbs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.EntiteitKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerkId;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkType;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkWithValuesDto;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class EntiteitKenmerkService {

    private final EntiteitKenmerkRepository entiteitKenmerkRepository;
    private final Logging2Service logging2Service;

    Optional<EntiteitKenmerk> getEntiteitKenmerkByRsinAndType(Long bsnRsin, KenmerkType type) {
        return this.entiteitKenmerkRepository.findFirstByEntiteitKenmerkId_BsnRsinAndEntiteitKenmerkId_KenmerkType(bsnRsin, type.getValue());
    }

    List<EntiteitKenmerk> getEntiteitKenmerkenByRsinAndType(Long bsnRsin, KenmerkType type) {
        return this.entiteitKenmerkRepository.findAllByEntiteitKenmerkId_BsnRsinAndEntiteitKenmerkId_KenmerkType(bsnRsin, type.getValue());
    }

    public List<EntiteitKenmerk> getBranchecodeAanvullingen(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.BCAV);
    }

    public List<EntiteitKenmerk> getSelectedAandachtsgebieden(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.AG);
    }

    public List<EntiteitKenmerk> getSelectedMiddelen(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.MID);
    }

    public List<EntiteitKenmerk> getSelectedAttentiepunten(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.CBOBA);
    }

    public List<EntiteitKenmerk> getSelectedAttentiepuntenLoonheffing(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.CBLH);
    }

    public List<EntiteitKenmerk> getSelectedActiepunten(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.CBAP);
    }

    public List<EntiteitKenmerk> getSelectedActiepuntenBalans(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.CBAPB);
    }

    public List<EntiteitKenmerk> getSelectedActiepuntenWinstenVerlies(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.CBAPW);
    }

    public List<EntiteitKenmerk> getSelectedBedrijfsstrategieen(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.BS);
    }

    public List<EntiteitKenmerk> getSelectedExterneOmgevingKenmerken(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.EO);
    }

    public List<EntiteitKenmerk> getSelectedGovernanceStructuurKenmerken(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.GS);
    }

    public List<EntiteitKenmerk> getSelectedRisicomanagementKenmerken(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.RM);
    }

    public List<EntiteitKenmerk> getZooAttentiepuntenLoonheffing(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.CBLH);
    }

    public List<EntiteitKenmerk> getSelectedComplexiteitKenmerken(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.CK);
    }

    public Optional<EntiteitKenmerk> getSelectedSector(Long bsnRsin) {
        return getEntiteitKenmerkByRsinAndType(bsnRsin, KenmerkType.SECTR);
    }

    public void saveSelectedSector(Long bsnRsin, int sector, String loggingId) {
        var kenmerkId = new EntiteitKenmerkId(bsnRsin, KenmerkType.SECTR.getValue(), -1);
        var toSave = new EntiteitKenmerk(kenmerkId, String.valueOf(sector));
        if (sector == -1) {
            this.entiteitKenmerkRepository.deleteById(kenmerkId);
            this.logging2Service.save(loggingId, toSave.getBsnRsin(), Logging2.Bewerking.DELETE);
        } else {
            boolean exists = this.entiteitKenmerkRepository.existsById(kenmerkId);
            Logging2.Bewerking bewerking = exists ? Logging2.Bewerking.UPDATE : Logging2.Bewerking.INSERT;
            this.entiteitKenmerkRepository.save(toSave);
            this.logging2Service.save(loggingId, toSave.getBsnRsin(), bewerking);
        }
    }

    public List<EntiteitKenmerk> getSelectedAttentiepuntIds(Long bsnRsin) {
        return getEntiteitKenmerkenByRsinAndType(bsnRsin, KenmerkType.CBIBV);
    }

    private void createEntiteitKenmerk(EntiteitKenmerkId entiteitKenmerkId, List<Integer> kenmerkenIdsWithValues, String loggingId) {
        String valuesStr = kenmerkenIdsWithValues.contains(entiteitKenmerkId.getKenmerkId()) ? "true" : "false";
        Optional<EntiteitKenmerk> existingEntiteitKenmerkOpt = entiteitKenmerkRepository.findById(entiteitKenmerkId);
        if (existingEntiteitKenmerkOpt.isPresent()) {
            var existingEntiteitKenmerk = existingEntiteitKenmerkOpt.get();

            boolean valuesWasUpdated = !existingEntiteitKenmerk.getValues().equalsIgnoreCase(valuesStr);
            if (valuesWasUpdated) {
                // Update existing EntiteitKenmerk
                existingEntiteitKenmerk.setValues(valuesStr);
                entiteitKenmerkRepository.save(existingEntiteitKenmerk);
                logging2Service.save(loggingId, entiteitKenmerkId.getBsnRsin(), Logging2.Bewerking.UPDATE);
            }
        } else {
            // Insert new Entiteitkenmerk
            try {
                var newEntiteitKenmerk = new EntiteitKenmerk();
                newEntiteitKenmerk.setEntiteitKenmerkId(entiteitKenmerkId);
                newEntiteitKenmerk.setValues(valuesStr);
                entiteitKenmerkRepository.save(newEntiteitKenmerk);
                logging2Service.save(loggingId, entiteitKenmerkId.getBsnRsin(), Logging2.Bewerking.INSERT);
            } catch (Exception exception){
                log.error("error entiteitkenmerk composite id: " + exception.getMessage() + "entiteit id: " +entiteitKenmerkId.getKenmerkId() + " bsn "+ entiteitKenmerkId.getBsnRsin() + " type " + entiteitKenmerkId.getKenmerkType());
                throw exception;
            }
        }
    }

    private void createEntiteitKenmerk(EntiteitKenmerkId entiteitKenmerkId, List<Integer> kenmerkenIdsWithValues, String loggingId, Long parentEntiteitnummer) {
        String valuesStr = kenmerkenIdsWithValues.contains(entiteitKenmerkId.getKenmerkId()) ? "true" : "false";
        Optional<EntiteitKenmerk> existingEntiteitKenmerkOpt = entiteitKenmerkRepository.findById(entiteitKenmerkId);
        if (existingEntiteitKenmerkOpt.isPresent()) {
            var existingEntiteitKenmerk = existingEntiteitKenmerkOpt.get();

            boolean valuesWasUpdated = !existingEntiteitKenmerk.getValues().equalsIgnoreCase(valuesStr);
            if (valuesWasUpdated) {
                // Update existing EntiteitKenmerk
                existingEntiteitKenmerk.setValues(valuesStr);
                entiteitKenmerkRepository.save(existingEntiteitKenmerk);
                logging2Service.save(loggingId, parentEntiteitnummer, Logging2.Bewerking.UPDATE);
            }
        } else {
            // Insert new Entiteitkenmerk
            try {
                var newEntiteitKenmerk = new EntiteitKenmerk();
                newEntiteitKenmerk.setEntiteitKenmerkId(entiteitKenmerkId);
                newEntiteitKenmerk.setValues(valuesStr);
                entiteitKenmerkRepository.save(newEntiteitKenmerk);
                logging2Service.save(loggingId, parentEntiteitnummer, Logging2.Bewerking.INSERT);
            } catch (Exception exception){
                log.error("error entiteitkenmerk composite id: " + exception.getMessage() + "entiteit id: " +entiteitKenmerkId.getKenmerkId() + " bsn "+ entiteitKenmerkId.getBsnRsin() + " type " + entiteitKenmerkId.getKenmerkType());
                throw exception;
            }
        }
    }

    public void saveEntiteitKenmerkIds(Long bsnRsin, String kenmerkType, Integer kenmerkId, String loggingId) {
        createEntiteitKenmerk(new EntiteitKenmerkId(bsnRsin, kenmerkType, kenmerkId), new ArrayList<>(), loggingId);
    }

    public void saveEntiteitKenmerken(Long bsnRsin, String kenmerkType, List<KenmerkWithValuesDto> kenmerkenList, String loggingId) {
        List<Integer> kenmerkenIdsWithValues = new ArrayList<>();
        for (KenmerkWithValuesDto withValuesDto : kenmerkenList) {
            var entiteitKenmerkId = new EntiteitKenmerkId(bsnRsin, kenmerkType, withValuesDto.getId());
            if (withValuesDto.isValues()) {
                kenmerkenIdsWithValues.add(withValuesDto.getId());
            }
            createEntiteitKenmerk(entiteitKenmerkId, kenmerkenIdsWithValues, loggingId);
        }
    }

    public void saveEntiteitKenmerken(Long bsnRsin, String kenmerkType, List<KenmerkWithValuesDto> kenmerkenList, String loggingId, Long parentEntiteitnummer) {
        List<Integer> kenmerkenIdsWithValues = new ArrayList<>();
        for (KenmerkWithValuesDto withValuesDto : kenmerkenList) {
            var entiteitKenmerkId = new EntiteitKenmerkId(bsnRsin, kenmerkType, withValuesDto.getId());
            if (withValuesDto.isValues()) {
                kenmerkenIdsWithValues.add(withValuesDto.getId());
            }
            createEntiteitKenmerk(entiteitKenmerkId, kenmerkenIdsWithValues, loggingId, parentEntiteitnummer);
        }
    }

    public void deleteEntiteitKenmerken(Long bsnRsin, String kenmerkType, List<KenmerkWithValuesDto> kenmerkenList, String loggingId, Long parentEntiteitnummer) {
        for( KenmerkWithValuesDto k  : kenmerkenList) {
            deleteEntiteitKenmerk(bsnRsin, kenmerkType, k.getId(), loggingId, parentEntiteitnummer);
        }
    }

    public void deleteEntiteitKenmerk(Long bsnRsin, String kenmerkType, Integer kenmerkId, String loggingId, Long parentEntiteitnummer) {
        Optional<EntiteitKenmerk> ekOpt = entiteitKenmerkRepository.findById(new EntiteitKenmerkId(bsnRsin, kenmerkType, kenmerkId));
        if (ekOpt.isPresent()) {
            EntiteitKenmerk ek = ekOpt.get();
            entiteitKenmerkRepository.delete(ek);
            this.logging2Service.save(loggingId, parentEntiteitnummer, Logging2.Bewerking.DELETE);
        }
    }

    public void deleteEntiteitKenmerk(Long bsnRsin, String kenmerkType, Integer kenmerkId, String loggingId) {
        Optional<EntiteitKenmerk> ekOpt = entiteitKenmerkRepository.findById(new EntiteitKenmerkId(bsnRsin, kenmerkType, kenmerkId));
        if (ekOpt.isPresent()) {
            EntiteitKenmerk ek = ekOpt.get();
            entiteitKenmerkRepository.delete(ek);
            this.logging2Service.save(loggingId, ek.getBsnRsin(), Logging2.Bewerking.DELETE);
        }
    }
}

