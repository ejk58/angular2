package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.EntiteitKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieUitkomstRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStatusRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class KlantsessieAfrondenService {
	private static final int CONTROLE_AND_KLANTCOORDINATOR = 2;
	private static final int KLANTCOORDINATOR = 1;

	private final KenmerkRepository kenmerkRepository;
	private final EntiteitKenmerkRepository entiteitKenmerkRepository;
	private final KlantsessieService klantsessieService;
	private final KlantSessieUitkomstRepository klantSessieUitkomstRepository;
	private final KlantsessieStatusRepository klantsessieStatusRepository;

	public boolean checkKlantsessieAfrondenEnabled(Long entiteitNummer) {
		var ks = klantsessieService.getCurrentKlantsessie(entiteitNummer);
		Long klantsessieId = ks.getId();

		int klantsessieCategorieKenmerken = kenmerkRepository.countAllByGroepAndKenmerkParentIdIsNotNullOrderById("KS_CAT");
		int uitkomstRecordsWhereScoreAndToelichtingNotNull = klantSessieUitkomstRepository.countAllByKlantsessieIdAndScoreNotNullAndStrategieGerichtOpNotNullAndToelichtingNotNull(klantsessieId);
		boolean uitkomstVolledig = uitkomstRecordsWhereScoreAndToelichtingNotNull == klantsessieCategorieKenmerken;

		boolean actGebaseerdOp = ks.getActGebaseerdGehoudenKlantsessie();

		if(!uitkomstVolledig) {
			return false;
		}

		if(!actGebaseerdOp && ks.getToelichtingGehoudenKlantsessie() == null){
			return false;
		}

		int extraMiddelen = Boolean.TRUE.equals(ks.getControlePlaatsgevonden()) ? CONTROLE_AND_KLANTCOORDINATOR : KLANTCOORDINATOR;
		int countSelectedMiddelenForEntiteitNummer = entiteitKenmerkRepository.countAllByEntiteitKenmerkId_BsnRsinAndEntiteitKenmerkId_KenmerkType(entiteitNummer, "MID") + extraMiddelen;
		int countAllStepsCompleted = klantsessieStatusRepository.countAllByKlantsessieIdAndVoorbereidingAfgerondIsTrueAndVoorbereidingAfrondenStatus(klantsessieId, StepStatusEnum.DONE);

		return countSelectedMiddelenForEntiteitNummer == countAllStepsCompleted;

	}

	public Klantsessie updateKlantsessieAfgerond(Long entiteitNummer, String loggingId) {
		var ks = klantsessieService.getCurrentKlantsessie(entiteitNummer);
		ks.setEinddatum(LocalDateTime.now());
		return klantsessieService.save(ks, loggingId);
	}
}
