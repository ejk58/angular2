package nl.belastingdienst.iva.wd.kbs.klantsessie.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieRisico;

@Repository
public interface KlantsessieStrategieRisicosRepository
		extends JpaRepository<KlantsessieStrategieRisico, KlantsessieStrategieRisico.PrimaryKey> {
	List<KlantsessieStrategieRisico> findKlantsessieStrategieRisicosByKlantsessieIdAndMiddelId(Long klantsessieId, Integer middelId);
	int countAllByKlantsessieIdAndMiddelId(Long klantsessieId, Integer middelId);
	@Transactional
	void deleteByKlantsessieIdAndRisicoId(Long klantsessieId, Long risicoId);
}
