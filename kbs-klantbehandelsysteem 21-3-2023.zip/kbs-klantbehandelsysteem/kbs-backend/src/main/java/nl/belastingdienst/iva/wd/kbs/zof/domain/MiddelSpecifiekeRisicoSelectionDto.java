package nl.belastingdienst.iva.wd.kbs.zof.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class MiddelSpecifiekeRisicoSelectionDto {
    private Long hoofdRisicoId;
    private Long subRisicoId;
    private Long kenmerkId;
    private Short keyRisk;
    private Long statusId;
    private Long currentId;
    private Integer beheersing;
}
