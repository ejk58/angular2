package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BatCreateBehandelVoorstel {
    private Long subjectId;
    private String subjectType;

    public BatCreateBehandelVoorstel(Long entiteitNummer, String type) {
        this.subjectId = entiteitNummer;
        this.subjectType = type;
    }
}
