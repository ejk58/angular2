package nl.belastingdienst.iva.wd.kbs.zof.domain;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;

import lombok.Data;

@Data
public class MiddelSpecifiekeRisicoSelection {
    private Long hoofdRisicoId;
    private Long subRisicoId;
    private Long entiteitMiddelKenmerkId;
    private Short keyRisk;
    private Long statusId;
    private Integer beheersing;
    private SelectionMiddelSpecifiekEnum selectionMiddelSpecifiekEnum;

    @SuppressWarnings("java:S107") // this is a custom constructor, not a method ..
    public MiddelSpecifiekeRisicoSelection(Long hoofdRisicoId, Long subRisicoId, Long entiteitMiddelKenmerkId, Short keyRisk, Long statusId, Integer beheersing) {
        if(keyRisk == null || statusId == null || beheersing == null){
            throwBusinessRuleException();
        }

        if(SelectionMiddelSpecifiekEnum.valueOf(hoofdRisicoId, subRisicoId, entiteitMiddelKenmerkId).equals(SelectionMiddelSpecifiekEnum.UNKNOWN)){
            throwBusinessRuleException();
        }

        this.hoofdRisicoId = hoofdRisicoId;
        this.subRisicoId = subRisicoId;
        this.entiteitMiddelKenmerkId = entiteitMiddelKenmerkId;
        this.keyRisk = keyRisk;
        this.statusId = statusId;
        this.beheersing = beheersing;
        this.selectionMiddelSpecifiekEnum = SelectionMiddelSpecifiekEnum.valueOf(hoofdRisicoId, subRisicoId,
                entiteitMiddelKenmerkId);

    }

    public static MiddelSpecifiekeRisicoSelection fromDto(MiddelSpecifiekeRisicoSelectionDto middelSpecifiekeRisicoSelectionDto){
        return new MiddelSpecifiekeRisicoSelection(
          middelSpecifiekeRisicoSelectionDto.getHoofdRisicoId(),
                middelSpecifiekeRisicoSelectionDto.getSubRisicoId(),
                middelSpecifiekeRisicoSelectionDto.getKenmerkId(),
                middelSpecifiekeRisicoSelectionDto.getKeyRisk(),
                middelSpecifiekeRisicoSelectionDto.getStatusId(),
                middelSpecifiekeRisicoSelectionDto.getBeheersing()
        );
    }

    public static List<MiddelSpecifiekeRisicoSelection> from(List<EntiteitMiddelRisicoDto> entiteitMiddelRisicoList){
        return entiteitMiddelRisicoList.stream().map(MiddelSpecifiekeRisicoSelection::fromDto).collect(Collectors.toList());
    }

    public static MiddelSpecifiekeRisicoSelection fromDto(EntiteitMiddelRisicoDto entiteitMiddelRisicoDto){
        return new MiddelSpecifiekeRisicoSelection(
                entiteitMiddelRisicoDto.getHoofdRisicoId(),
                entiteitMiddelRisicoDto.getSubRisicoId(),
                entiteitMiddelRisicoDto.getEntiteitMiddelKenmerkId(),
                entiteitMiddelRisicoDto.getKeyRisk(),
                entiteitMiddelRisicoDto.getStatusId(),
                entiteitMiddelRisicoDto.getBeheersing()
        );
    }

    public static List<MiddelSpecifiekeRisicoSelection> fromDto(List<MiddelSpecifiekeRisicoSelectionDto> middelSpecifiekeRisicoSelectionDtoList){
        return middelSpecifiekeRisicoSelectionDtoList.stream().map(MiddelSpecifiekeRisicoSelection::fromDto).collect(Collectors.toList());
    }

    private void throwBusinessRuleException() {
        throw new BusinessRuleException("Wrongly formatted.");
    }
}
