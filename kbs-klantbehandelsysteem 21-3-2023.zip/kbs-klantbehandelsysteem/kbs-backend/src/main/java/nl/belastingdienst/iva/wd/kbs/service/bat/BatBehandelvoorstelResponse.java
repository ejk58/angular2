package nl.belastingdienst.iva.wd.kbs.service.bat;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BatBehandelvoorstelResponse {

    private List<BatBehandelopdrachtMDR> behandelopdrachtenMDR;
    private List<BatBehandelplanvoorstel> behandelplanVoorstellen;
    private List<BatBoekenOnderzoek> boekenOnderzoeken;
    private List<BatBoekenOnderzoekInvordering> boekenOnderzoekenInvordering;
    private List<BatBoekenOnderzoekOverig> boekenOnderzoekenOverig;
    private List<BatBoekenOnderzoekOverigGo> boekenOnderzoekenOverigGo;
    private List<BatBoekenOnderzoekOverigMkb> boekenOnderzoekenOverigMkb;
    private List<BatHeffing> heffingen;
}
