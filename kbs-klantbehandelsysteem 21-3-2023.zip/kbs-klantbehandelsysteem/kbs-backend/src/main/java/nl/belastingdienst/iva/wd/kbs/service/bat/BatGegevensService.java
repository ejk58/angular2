package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.ApiServiceApplicationProperties;
import nl.belastingdienst.iva.wd.kbs.service.RestTemplateClient;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.VoorstelType;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class BatGegevensService {

    private static final String BEHANDELVOORSTEL_TYPE_ENT = "ENT";
    private final ApiServiceApplicationProperties apiServiceApplicationProperties;
    private final RestTemplateClient restTemplateClient;

    private Map<String, String> behandelActiviteitCodesCache = null;
    private Map<String, String> statusCodesCache = null;

    public String createBehandelVoorstel(Long entiteitNummer, String behandelVoorstelType) {
        var uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/behandelvoorstel/voorsteltype/" + behandelVoorstelType);
        var body = new BatCreateBehandelVoorstel(entiteitNummer, BEHANDELVOORSTEL_TYPE_ENT);

        ResponseEntity<String> id = restTemplateClient.doRequest(
                HttpMethod.POST, uri, body, String.class,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel(), true);

        return id.getBody();
    }

    public BatBehandelvoorstelResponse getBehandelVoorstellen(Long entiteitnummer) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("Fetching behandel voorstellen for entiteit " + entiteitnummer);
        URI uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/behandelvoorstel/subject/" + entiteitnummer);
        ResponseEntity<BatBehandelvoorstelResponse> responseBehandelvoorstellen = restTemplateClient.doRequest(HttpMethod.GET, uri, null,
                BatBehandelvoorstelResponse.class, apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel(), false);
        stopWatch.stop();
        Set<Long> personen = getPersonenFromBehandelvoorstellen(responseBehandelvoorstellen);

        stopWatch.start("Fetching behandel voorstellen for " + personen.size() + " personen.");
        uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/behandelvoorstel/personen");
        ResponseEntity<BatBehandelvoorstelResponse> responseEntity = restTemplateClient.doRequest(HttpMethod.POST, uri, personen,
                BatBehandelvoorstelResponse.class, apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel(), false);
        stopWatch.stop();

        stopWatch.start("Merging behandel voorstellen.");
        BatBehandelvoorstelResponse batBehandelvoorstellen = mergeResponseEntities(responseBehandelvoorstellen.getBody(), responseEntity.getBody());
        stopWatch.stop();
        log.debug(stopWatch.prettyPrint());

        return batBehandelvoorstellen;
    }

    public Map<String, String> getBehandelActiviteitCodes() {
        if (behandelActiviteitCodesCache == null) {
            URI uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/lookuptabel?tabel=OMSCHRIJVING_VOORSTELTYPE");
            behandelActiviteitCodesCache = getBatCodeMap(uri);
        }
        return behandelActiviteitCodesCache;
    }

    public Map<String, String> getStatusCodes() {
        if (statusCodesCache == null) {
            URI uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/lookuptabel?tabel=STATUS");
            statusCodesCache = getBatCodeMap(uri);
        }
        return statusCodesCache;
    }

    @Scheduled(cron="0 0 5 * * *")
    public void clearCaches() {
        log.debug("Clearing caches");
        statusCodesCache = null;
        behandelActiviteitCodesCache = null;
    }
    private Map<String, String> getBatCodeMap(URI uri) {
        var responseStatusCodes = restTemplateClient.doRequest(
                HttpMethod.GET, uri, null,
                new ParameterizedTypeReference<List<VoorstelType>>() {},
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel(), false);

        Map<String, String> result = new HashMap<>();
        if (!responseStatusCodes.getStatusCode().isError() && responseStatusCodes.getBody() != null) {
            for (VoorstelType baCode : responseStatusCodes.getBody()) {
                result.put(baCode.getCode(), baCode.getOmschrijving());
            }
        }

        return result;
    }

    private BatBehandelvoorstelResponse mergeResponseEntities(BatBehandelvoorstelResponse responseEntity, BatBehandelvoorstelResponse responsePersons) {
        BatBehandelvoorstelResponse result = new BatBehandelvoorstelResponse();
        result.setBehandelopdrachtenMDR(new ArrayList<>());
        result.getBehandelopdrachtenMDR().addAll(responseEntity.getBehandelopdrachtenMDR());
        result.getBehandelopdrachtenMDR().addAll(responsePersons.getBehandelopdrachtenMDR());

        result.setBehandelplanVoorstellen(new ArrayList<>());
        result.getBehandelplanVoorstellen().addAll(responsePersons.getBehandelplanVoorstellen());
        result.getBehandelplanVoorstellen().addAll(responseEntity.getBehandelplanVoorstellen());

        result.setBoekenOnderzoeken(new ArrayList<>());
        result.getBoekenOnderzoeken().addAll(responseEntity.getBoekenOnderzoeken());
        result.getBoekenOnderzoeken().addAll(responsePersons.getBoekenOnderzoeken());

        result.setBoekenOnderzoekenInvordering(new ArrayList<>());
        result.getBoekenOnderzoekenInvordering().addAll(responseEntity.getBoekenOnderzoekenInvordering());
        result.getBoekenOnderzoekenInvordering().addAll(responsePersons.getBoekenOnderzoekenInvordering());

        result.setBoekenOnderzoekenOverig(new ArrayList<>());
        result.getBoekenOnderzoekenOverig().addAll(responseEntity.getBoekenOnderzoekenOverig());
        result.getBoekenOnderzoekenOverig().addAll(responsePersons.getBoekenOnderzoekenOverig());

        result.setBoekenOnderzoekenOverigGo(new ArrayList<>());
        result.getBoekenOnderzoekenOverigGo().addAll(responseEntity.getBoekenOnderzoekenOverigGo());
        result.getBoekenOnderzoekenOverigGo().addAll(responsePersons.getBoekenOnderzoekenOverigGo());

        result.setBoekenOnderzoekenOverigMkb(new ArrayList<>());
        result.getBoekenOnderzoekenOverigMkb().addAll(responseEntity.getBoekenOnderzoekenOverigMkb());
        result.getBoekenOnderzoekenOverigMkb().addAll(responsePersons.getBoekenOnderzoekenOverigMkb());

        result.setHeffingen(new ArrayList<>());
        result.getHeffingen().addAll(responseEntity.getHeffingen());
        result.getHeffingen().addAll(responsePersons.getHeffingen());

        return result;
    }

    private Set<Long> getPersonenFromBehandelvoorstellen(ResponseEntity<BatBehandelvoorstelResponse> behandelvoorstellenResponse) {
        Set<Long> personen = new HashSet<>();
        if (! behandelvoorstellenResponse.getStatusCode().isError()) {
            BatBehandelvoorstelResponse behandelvoorstellen = behandelvoorstellenResponse.getBody();
            if (behandelvoorstellen != null) {
                personen.addAll( getPersonen(behandelvoorstellen.getBehandelopdrachtenMDR()));
                personen.addAll( getPersonen(behandelvoorstellen.getBehandelplanVoorstellen()));
                personen.addAll( getPersonen(behandelvoorstellen.getBoekenOnderzoeken()));
                personen.addAll( getPersonen(behandelvoorstellen.getBoekenOnderzoekenInvordering()));
                personen.addAll( getPersonen(behandelvoorstellen.getBoekenOnderzoekenOverig()));
                personen.addAll( getPersonen(behandelvoorstellen.getBoekenOnderzoekenOverigGo()));
                personen.addAll( getPersonen(behandelvoorstellen.getBoekenOnderzoekenOverigMkb()));
                personen.addAll( getPersonen(behandelvoorstellen.getHeffingen()));

            }
        }
        return personen;
    }

    private Set<Long> getPersonen(List<? extends BatBehandelplanvoorstel> behandelplanVoorstellen) {
        return behandelplanVoorstellen.stream()
                .flatMap(bv -> bv.getPersonen().stream())
                .map(BatPersoon::getSubject)
                .collect(Collectors.toSet());
    }

}
