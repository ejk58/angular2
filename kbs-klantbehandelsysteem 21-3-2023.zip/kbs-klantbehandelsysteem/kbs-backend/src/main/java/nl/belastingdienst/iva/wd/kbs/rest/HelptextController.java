package nl.belastingdienst.iva.wd.kbs.rest;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.kbs.domain.Helptext;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.security.HtmlSanitizer;
import nl.belastingdienst.iva.wd.kbs.service.HelptextService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/helptext")
public class HelptextController {

	private final HelptextService helptextService;

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
	@GetMapping("/{helptextId}")
	public Helptext getHelptext(@PathVariable String helptextId) {
		return helptextService.getHelptext(helptextId)
				.orElse(doesNotExist(helptextId, null));
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{helptextId}/for/{entiteitNummer}")
	public Helptext getHelptextForEntiteit(@PathVariable String helptextId, @PathVariable Long entiteitNummer) {
		return helptextService.getHelptextForEntiteit(helptextId, entiteitNummer)
				.orElse(doesNotExist(helptextId, entiteitNummer));
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#helptextDto.wrappedObject.entiteit)")
	@PostMapping("/save")
	public Helptext storeHelptext(@RequestBody LoggingWrapper<Helptext> helptextDto) {
		var helptext = helptextDto.getWrappedObject();
		var authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		if (StringUtils.isBlank(currentPrincipalName)) throw new NullPointerException("Helptext opslaan is mislukt: gebruiker is niet ingelogd!");

		if (helptext.getTxt() == null) {
			helptext.setTxt("");
		}
		helptext.setTxt(HtmlSanitizer.sanitizeHtml(helptext.getTxt()));

		Helptext toSave = helptextService.getHelptextForEntiteit(helptext.getId(), helptext.getEntiteit())
				.map(fromDb -> {
					// The helptext exists in the database. Update that instance with new value of text.
					fromDb.setTxt(helptext.getTxt());
					return fromDb;
				})
				// If the helptext did not exist in the database, then store the received instance.
				.orElse(helptext);

		toSave.setChanged(new Date());
		toSave.setUserId(currentPrincipalName);

		return helptextService.saveHelptext(toSave, helptextDto.getLoggingId());
	}

	private static Helptext doesNotExist(String helptextId, Long entiteit) {
		return Helptext.builder()
				.txt("")
				.id(helptextId)
				.entiteit(entiteit)
				.userId("")
				.changed(null)
				.build();
	}
}
