/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KlantsessieCompliancePerProcesRestController.java
 *             Auteur: duisr01
 *    Creatietijdstip: 9-11-2022 09:51
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliancePerProces;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesWithAbbreviatedMiddelProjection;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieCompliancePerProcesService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/klantsessie/compliance/per-proces/")
public class KlantsessieCompliancePerProcesRestController {

	private final KlantsessieCompliancePerProcesService klantsessieCompliancePerProcesService;

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("{entiteitNummer}/{middelId}")
	public KlantsessieCompliancePerProces getKlantsessieCompliancePerProces(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
		return klantsessieCompliancePerProcesService.getPerProces(entiteitNummer, middelId) ;
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("{entiteitNummer}")
	public KlantsessieCompliancePerProces updateKlantsessieCompliancePerProces(@RequestBody LoggingWrapper<PerProcesDto> perproces, @PathVariable Long entiteitNummer) {
		return klantsessieCompliancePerProcesService.update(perproces.getWrappedObject(), entiteitNummer, perproces.getLoggingId());
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("{entiteitNummer}")
	public List<PerProcesWithAbbreviatedMiddelProjection> getCompliancePerProces(@PathVariable Long entiteitNummer) {
		return klantsessieCompliancePerProcesService.getPerProces(entiteitNummer);
	}
}
