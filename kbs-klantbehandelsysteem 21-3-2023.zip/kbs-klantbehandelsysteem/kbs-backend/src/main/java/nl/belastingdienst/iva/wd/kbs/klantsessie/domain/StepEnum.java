package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

public enum StepEnum {
	ZOOEF, COMPLIANCE, STRATEGIE, VOORBEREIDING_AFRONDEN
}
