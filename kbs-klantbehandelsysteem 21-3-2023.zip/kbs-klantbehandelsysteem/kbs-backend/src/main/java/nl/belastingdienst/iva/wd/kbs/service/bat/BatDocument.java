package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

@Data
public class BatDocument {
    private String bron;
    private String docId;
    private Long subject;
    private String uuid;
}
