package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KenmerkChild {
    private Kenmerk kenmerk;
    private Integer score;
    private String toelichting;
}
