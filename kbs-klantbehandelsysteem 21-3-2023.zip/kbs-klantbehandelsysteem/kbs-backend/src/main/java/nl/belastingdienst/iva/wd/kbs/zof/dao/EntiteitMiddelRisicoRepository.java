package nl.belastingdienst.iva.wd.kbs.zof.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;

@Repository
public interface EntiteitMiddelRisicoRepository extends JpaRepository<EntiteitMiddelRisico, Long> {
    List<EntiteitMiddelRisico> findEntiteitMiddelRisicosByEntiteitNummerOrderByRank(Long entiteitNummer);
    List<EntiteitMiddelRisico> findEntiteitMiddelRisicosByEntiteitNummer(Long entiteitNummer);

    Optional<EntiteitMiddelRisico> findByEntiteitNummerAndId(Long entiteitNummer, Long id);

    Optional<EntiteitMiddelRisico> getTopByEntiteitNummerAndRankIsNotNullOrderByRankAsc(Long entiteitNummer);

    private Long getNewLowestRank(Long entiteitNummer){
        long newLowestRank = 0L;
        var previousEntiteitMiddelRisicoWithRankOptional = getTopByEntiteitNummerAndRankIsNotNullOrderByRankAsc(entiteitNummer);

        if(previousEntiteitMiddelRisicoWithRankOptional.isPresent()){
            newLowestRank = previousEntiteitMiddelRisicoWithRankOptional.get().getRank() - 1L;
        }

        return newLowestRank;
    }

    default EntiteitMiddelRisico saveWithLowestRank(EntiteitMiddelRisico entiteitMiddelRisico){
        entiteitMiddelRisico.setRank(getNewLowestRank(entiteitMiddelRisico.getEntiteitNummer()));
        return save(entiteitMiddelRisico);
    }

    List<EntiteitMiddelRisico> findAllByEntiteitMiddelKenmerkId(Long entiteitMiddelKenmerkid);
}
