package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStatus;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieStatusService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RequiredArgsConstructor
@RestController
@RequestMapping("/api/klantsessie/status")
@Slf4j
public class KlantsessieStatusRestController {
    private final KlantsessieStatusService klantsessieStatusService;

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/{entiteitNummer}/{middelId}")
    public KlantsessieStatus getCurrentKlantsessieStatus(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
        return klantsessieStatusService.getCurrentKlantsessieStatus(entiteitNummer, middelId);
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @PostMapping("/{entiteitNummer}/{middelId}/voorbereidingAfgerond")
    public void updateVoorbereidingAfgerond(@PathVariable Long entiteitNummer, @PathVariable Integer middelId, @RequestBody LoggingWrapper<Void> loggingWrapper) {
        klantsessieStatusService.updateVoorbereidingAfgerond(entiteitNummer, middelId, loggingWrapper.getLoggingId());
    }
}
