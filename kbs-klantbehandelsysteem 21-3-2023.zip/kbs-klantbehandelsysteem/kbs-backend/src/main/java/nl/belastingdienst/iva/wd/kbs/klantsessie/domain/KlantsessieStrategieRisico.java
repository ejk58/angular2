/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KlantsessieStrategieRisicos.java
 *             Auteur: duisr01
 *    Creatietijdstip: 11-8-2022 10:11
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "KLANTSESSIE_STRATEGIE_RISICOS")
@IdClass(KlantsessieStrategieRisico.PrimaryKey.class)
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
public class KlantsessieStrategieRisico {

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class PrimaryKey implements Serializable {
		private static final long serialVersionUID = -2771765166399327786L;
		private Long klantsessieId;
		private Integer middelId;
		private Long risicoId;
	}

	@Id
	@Column(name = "KLANTSESSIE_ID", nullable = false)
	private Long klantsessieId;
	@Id
	@Column(name = "MIDDEL_ID", nullable = false)
	private Integer middelId;
	@Id
	@Column(name = "RISICO_ID", nullable = false)
	private Long risicoId;
	@OneToOne
	@JoinColumn(name = "RISICO_ID", referencedColumnName = "ID", insertable = false, updatable = false)
	private MiddelRisico middelRisico;
}
