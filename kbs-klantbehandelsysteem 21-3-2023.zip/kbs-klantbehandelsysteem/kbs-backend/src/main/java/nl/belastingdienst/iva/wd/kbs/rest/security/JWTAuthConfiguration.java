/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: JWTAuthConfiguration.java
 *             Auteur: schop13
 *    Creatietijdstip: 6-1-2021 13:17
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.rest.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import nl.belastingdienst.iva.common.springboot.security.JWTAuthorizationFilter;
import nl.belastingdienst.iva.common.springboot.security.JWTLoginFilter;
import nl.belastingdienst.iva.common.springboot.security.RoleMapping;

/**
 * Configuratie voor authenticatie middels JWT.
 *
 * @author schop13
 */
@Configuration
@EnableWebSecurity
public class JWTAuthConfiguration extends WebSecurityConfigurerAdapter {

	private final LdapTemplate ldapTemplate;
	private final Environment env;

	public JWTAuthConfiguration(LdapTemplate ldapTemplate, Environment env) {
		this.ldapTemplate = ldapTemplate;
		this.env = env;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		List<RoleMapping> roleMappings = new ArrayList<>();
		roleMappings.add(new RoleMapping("AUG_KBS_BEHANDELAAR", "AUG_KBS_BEHANDELAAR"));
//		roleMappings.add(new RoleMapping("AUG_IVA_MAATWERK_OPS", "AUG_IVA_MAATWERK_OPS"));
		roleMappings.add(new RoleMapping("AUG_KBS_RAADPLEGER", "AUG_KBS_RAADPLEGER"));

		http.cors().and().csrf().disable()
				.authorizeRequests()
				.antMatchers("/api/scheduler/logging").permitAll() // TODO: implement authentication using API key (interceptor)
				.antMatchers("/api/**").authenticated()
				.anyRequest().permitAll()
				.and()
				.addFilterBefore(new JWTLoginFilter(env, ldapTemplate, roleMappings), UsernamePasswordAuthenticationFilter.class)
				.addFilterAfter(new JWTAuthorizationFilter(env), JWTLoginFilter.class)
				// this disables session creation on Spring Security
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
	}
}
