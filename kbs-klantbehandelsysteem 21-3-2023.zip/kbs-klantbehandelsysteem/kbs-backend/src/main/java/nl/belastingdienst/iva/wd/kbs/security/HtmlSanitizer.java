/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: HtmlSanitizer.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 23-12-2021 16:01
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.security;

import java.util.regex.Pattern;

import org.apache.commons.lang3.Range;
import org.apache.commons.lang3.StringUtils;
import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.owasp.html.Sanitizers;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class HtmlSanitizer {

	public static final String ANCHOR = "a";
	public static final String HREF = "href";

	public static final String IMAGE = "img";
	public static final String SRC = "src";

	public static final String DATA = "data";

	private static final String PARENTHESISOPEN_CODE = "%28";
	private static final String PARENTHESISCLOSE_CODE = "%29";
	private static final String EQUALSIGN_CODE = "&#61;";

	/**
	 * Matches values of the src attribute of image elements where the src is a Base-64 encoded (embedded) image (case-insensitive).
	 */
	public static final Pattern EMBEDDED_IMAGE = Pattern.compile("^" + DATA + ":image/.*;base64,.*$", Pattern.CASE_INSENSITIVE);
	private static final PolicyFactory EMBEDDED_IMAGES_ONLY_POLICY = new HtmlPolicyBuilder()
			.allowUrlProtocols(DATA)
			.allowElements(IMAGE)
			// Only allow embedded images in src attribute of img elements, no URLs:
			.allowAttributes(SRC).matching(EMBEDDED_IMAGE).onElements(IMAGE)
			.toFactory();

	private static final PolicyFactory CUSTOM_ANCHOR_ELEMENTS_POLICY = new HtmlPolicyBuilder()
			.allowStandardUrlProtocols()
			// Allow anchor elements and set target="_blank"
			.allowElements(AnchorElementSanitizer::addOrSetTargetToBlank, ANCHOR)
			// Also allow href attribute on anchor elements
			.allowAttributes(HREF).onElements(ANCHOR)
			.requireRelsOnLinks("noopener", "noreferrer", "nofollow")
			.toFactory();

	private static final PolicyFactory ALLOW_ATTRIBUTE_CLASS_POLICY = new HtmlPolicyBuilder()
			.allowAttributes("class").globally()
			.toFactory();

	public static final PolicyFactory DEFAULT_POLICY = Sanitizers.BLOCKS.and(Sanitizers.FORMATTING)
			.and(CUSTOM_ANCHOR_ELEMENTS_POLICY).and(EMBEDDED_IMAGES_ONLY_POLICY).and(ALLOW_ATTRIBUTE_CLASS_POLICY);

	public static String sanitizeHtml(@NonNull String html) {
		String fixedHtml = AnchorElementSanitizer.sanitizeHrefAttributeIfAnchorElementsPresent(html);
		String sanitizedHtml = DEFAULT_POLICY.sanitize(fixedHtml);
		return decodeHrefsForInzicht(sanitizedHtml);
	}

	private static String decodeHrefsForInzicht(String html) {
		String newHtml = html;
		Range<Integer> urlRange = findUrlRange(newHtml, 0);

		while (urlRange != null) {
			int maximumIndexDelta = 0;

			if (detectInzichtUrlInHtml(newHtml, urlRange)) {
				String oldHtml = newHtml;
				newHtml = decodeInzichtUrlInHtml(oldHtml, urlRange);
				maximumIndexDelta = newHtml.length() - oldHtml.length();
			}

			urlRange = findUrlRange(newHtml, urlRange.getMaximum() + maximumIndexDelta);
		}

		return newHtml;
	}

	private static Range<Integer> findUrlRange(String html, int startIndex) {
		int anchorElementIndex = html.indexOf("<a", startIndex);
		int hrefAttributeIndex = anchorElementIndex < 0 ? -1 : html.indexOf("href=\"", anchorElementIndex);
		int urlStartIndex = hrefAttributeIndex < 0 ? -1 : (hrefAttributeIndex + 6);
		int urlEndIndex = hrefAttributeIndex < 0 ? -1 : html.indexOf("\"", urlStartIndex);
		return (urlStartIndex < startIndex || urlEndIndex < urlStartIndex) ? null : Range.between(urlStartIndex, urlEndIndex);
	}

	private static boolean detectInzichtUrlInHtml(String html, Range<Integer> urlRange) {
		String url = html.substring(urlRange.getMinimum(), urlRange.getMaximum());
		int inzichtIndex = url.indexOf("https://inzicht.");
		int domainIndex = url.indexOf(".belastingdienst.nl/");
		int hashIndex = url.indexOf("/#/");
		int parenthesisOpenIndex = url.indexOf(PARENTHESISOPEN_CODE);
		int parenthesisCloseIndex = url.indexOf(PARENTHESISCLOSE_CODE);
		int firstEqualSignIndex = url.indexOf(EQUALSIGN_CODE);

		boolean isInzichtUrl = inzichtIndex == 0 && domainIndex > 0;
		boolean isHashBeforeParentheses = hashIndex > 0 && hashIndex < parenthesisOpenIndex;
		boolean isHashBeforeEqualSign = hashIndex > 0 && (hashIndex < firstEqualSignIndex || firstEqualSignIndex == -1);
		boolean isMatchingParentheses = parenthesisOpenIndex < parenthesisCloseIndex
				&& countMatchesInUrl(url, PARENTHESISOPEN_CODE) == 1
				&& countMatchesInUrl(url, PARENTHESISCLOSE_CODE) == 1;

		return isInzichtUrl && isHashBeforeParentheses && isHashBeforeEqualSign && isMatchingParentheses;
	}

	private static String decodeInzichtUrlInHtml(String html, Range<Integer> urlRange) {
		String url = html.substring(urlRange.getMinimum(), urlRange.getMaximum());

		url = url
				.replace(PARENTHESISOPEN_CODE, "(")
				.replace(PARENTHESISCLOSE_CODE, ")")
				.replace(EQUALSIGN_CODE, "=");

		return html.substring(0, urlRange.getMinimum()) + url + html.substring(urlRange.getMaximum());
	}

	private static int countMatchesInUrl(String url, String element) {
		return StringUtils.countMatches(url, element);
	}
}
