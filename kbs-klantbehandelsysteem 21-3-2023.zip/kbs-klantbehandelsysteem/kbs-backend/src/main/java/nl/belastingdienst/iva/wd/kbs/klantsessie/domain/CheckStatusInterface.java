package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

public interface CheckStatusInterface {
	StepStatusEnum check(Long klantsessieId, Integer middelId);
	StepEnum getStepEnum();
}
