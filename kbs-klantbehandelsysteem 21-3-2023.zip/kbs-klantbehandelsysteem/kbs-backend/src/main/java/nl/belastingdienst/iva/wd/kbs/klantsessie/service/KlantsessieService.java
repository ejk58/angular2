package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class KlantsessieService {

    private final KlantsessieRepository repo;
    private final Logging2Service logging2Service;

    public Klantsessie getCurrentKlantsessie(Long entiteitNummer) {
        @SuppressWarnings("java:S1874")
        Optional<Klantsessie> kOpt = this.repo.findByEntiteitNummerAndEinddatumIsNull(entiteitNummer);
        return kOpt.orElseGet(() -> getOrCreateCurrentKlantsessie(entiteitNummer));

    }

    private synchronized Klantsessie getOrCreateCurrentKlantsessie(Long entiteitnummer) {
        @SuppressWarnings("java:S1874")
        Optional<Klantsessie> kOpt = this.repo.findByEntiteitNummerAndEinddatumIsNull(entiteitnummer);
        if (kOpt.isPresent()) {
            return kOpt.get();
        }

        var k = new Klantsessie(entiteitnummer);
        return save(k);
    }

    public Optional<Klantsessie> getPreviousKlantsessie(Long entiteitNummer) {
        return repo.findFirstByEntiteitNummerAndEinddatumIsNotNullOrderByStartdatumDesc(entiteitNummer);
    }

    private Klantsessie save(Klantsessie ks) {
        return repo.save(ks);
    }

    public Klantsessie save(Klantsessie ks, String loggingid) {
        this.logging2Service.save(loggingid, ks.getEntiteitNummer(), Logging2.Bewerking.UPDATE);
        return repo.save(ks);
    }

    public Klantsessie updateControlePlaatsgevondenOfCurrentKlantsessie(Long entiteitNummer, boolean controlePlaatsgevonden, String loggingId) {
        var ks = getCurrentKlantsessie(entiteitNummer);
        ks.setControlePlaatsgevonden(controlePlaatsgevonden);
        this.logging2Service.save(loggingId, entiteitNummer, Logging2.Bewerking.UPDATE);
        return save(ks);
    }

    public List<Klantsessie> getLastThreePreviousKlantsessie(Long entiteitNummer) {
        return repo.findFirst3ByEntiteitNummerAndEinddatumIsNotNullOrderByEinddatumDesc(entiteitNummer);
    }
}
