package nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieStrategieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStrategieRisicosRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.mappings.KlantsessieStrategieMapper;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieStatusService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.status.CheckStrategieService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class KlantsessieStrategieService {
    private final CheckStrategieService checkStrategieService;
    private final KlantsessieStatusService klantsessieStatusService;

    private final KlantsessieService klantsessieService;
    private final KlantSessieStrategieRepository klantSessieStrategieRepository;
    private final Logging2Service loggingService;
    private final KlantsessieStrategieMapper klantsessieStrategieMapper;
    private final KlantsessieStrategieRisicosRepository klantsessieStrategieRisicosRepository;

    private KlantsessieStrategie saveAndSetStatus(Long entiteitnummer, KlantsessieStrategie klantsessieStrategie){
        klantSessieStrategieRepository.save(klantsessieStrategie);
        klantsessieStatusService.setStepStatus(entiteitnummer, klantsessieStrategie.getMiddelId(),
                checkStrategieService.getStepEnum(), checkStrategieService.check(klantsessieStrategie.getKlantsessieId(), klantsessieStrategie.getMiddelId()));
        return klantsessieStrategie;
    }

    private void setStepStatusOnRisicoAction(Long entiteitNummer, Integer middelId) {
        Long klantsessieId = klantsessieService.getCurrentKlantsessie(entiteitNummer).getId();
        klantsessieStatusService.setStepStatus(entiteitNummer, middelId, checkStrategieService.getStepEnum(), checkStrategieService.check(klantsessieId, middelId));
    }

    public KlantsessieStrategieDto getPreviousKlantsessieStrategie(Long entiteitNummer, Integer middelId) {
        Optional<Klantsessie> lastklantsessie = klantsessieService.getPreviousKlantsessie(entiteitNummer);
        if (lastklantsessie.isEmpty()) {
            return null;
        }
        KlantsessieStrategie previous =  klantSessieStrategieRepository.findById(new KlantsessieStrategie.PrimaryKey(lastklantsessie.get().getId(), middelId)).orElse(null);
        return klantsessieStrategieMapper.map(previous);
    }

    public KlantsessieStrategieDto getCurrentKlantsessieStrategie(Long entiteitNummer, Integer middelId) {
        var currentKlantsessie = klantsessieService.getCurrentKlantsessie(entiteitNummer);
        KlantsessieStrategie current =  klantSessieStrategieRepository.findById(
                        new KlantsessieStrategie.PrimaryKey(currentKlantsessie.getId(), middelId))
                .orElse(new KlantsessieStrategie(
                        currentKlantsessie.getId(),
                        middelId,
                        null,
                        null
                ));
        return klantsessieStrategieMapper.map(current);
    }

    public KlantsessieStrategieDto saveKlantsessieStrategieKorteTermijn(KlantsessieStrategieDto klantsessieStrategieDto,
            Long entiteitNummer, Integer middelId, String logginId) {
        KlantsessieStrategieDto currentDto = getCurrentKlantsessieStrategie(entiteitNummer, middelId);
        currentDto.setKorteTermijn(klantsessieStrategieDto.getKorteTermijn());
        var toSave = klantsessieStrategieMapper.map(currentDto);
        loggingService.save(logginId, entiteitNummer, Logging2.Bewerking.UPDATE);
        return klantsessieStrategieMapper.map(saveAndSetStatus(entiteitNummer, toSave));
    }

    public KlantsessieStrategieDto saveKlantsessieStrategieMiddelLangeTermijn(KlantsessieStrategieDto klantsessieStrategieDto,
            Long entiteitNummer, Integer middelId, String loggingId) {
        KlantsessieStrategieDto currentDto = getCurrentKlantsessieStrategie(entiteitNummer, middelId);
        currentDto.setMiddellangeTermijn(klantsessieStrategieDto.getMiddellangeTermijn());

        var toSave = klantsessieStrategieMapper.map(currentDto);
        loggingService.save(loggingId, entiteitNummer, Logging2.Bewerking.UPDATE);
        return klantsessieStrategieMapper.map(saveAndSetStatus(entiteitNummer, toSave));
    }

    public void saveSelectedRisicos(Long entiteitNummer, List<KlantsessieStrategieRisico> klantsessieStrategieRisicos, String loggingId) {
        klantsessieStrategieRisicos.forEach(risico -> {
            klantsessieStrategieRisicosRepository.save(risico);
            setStepStatusOnRisicoAction(entiteitNummer, risico.getMiddelId());
            loggingService.save(loggingId, entiteitNummer, Logging2.Bewerking.INSERT);
        });
    }

    public void deleteKlantsessieStrategieRisico(Long entiteitNummer, Long klantsessieId, Integer middelId, Long riscoId, String logginId) {
        klantsessieStrategieRisicosRepository
                .findById(new KlantsessieStrategieRisico.PrimaryKey(klantsessieId, middelId, riscoId))
                .ifPresent(klantsessieStrategieRisico -> {
                    klantsessieStrategieRisicosRepository.delete(klantsessieStrategieRisico);
                    setStepStatusOnRisicoAction(entiteitNummer, klantsessieStrategieRisico.getMiddelId());
                    loggingService.save(logginId, entiteitNummer, Logging2.Bewerking.DELETE);
                });
    }
}
