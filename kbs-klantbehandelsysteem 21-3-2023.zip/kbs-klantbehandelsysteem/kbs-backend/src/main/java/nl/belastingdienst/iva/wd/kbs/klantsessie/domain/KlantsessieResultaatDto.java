package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class KlantsessieResultaatDto {
    private List<KenmerkParent> kenmerken;
    private List<KlantsessieResultaatEntryDto> previousEntries;
    private List<KlantsessieResultaatEntryDto> currentEntries;
}
