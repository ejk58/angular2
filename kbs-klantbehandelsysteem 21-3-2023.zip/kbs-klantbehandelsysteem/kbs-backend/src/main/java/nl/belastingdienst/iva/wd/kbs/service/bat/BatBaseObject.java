package nl.belastingdienst.iva.wd.kbs.service.bat;

import java.util.List;

public abstract class BatBaseObject {

    private String aantekening;
    private String behandelVoorstelReference;
    private String created;
    private String createdBy;
    private List<BatDocument> documenten;
    private Long entiteitNummer;
    private String inOpdrachtDoor;
    private List<BatPersoon> personen;
    private Long recVersion;
    private String status;
    private String subjectId;
    private String subjectType;
    private List<BatTeam> team;
    private List<BatToelichting> toelichtingen;
    private String voorstelType;
    private String zaakId;
}
