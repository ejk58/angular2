package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

@Data
public class BatTeam {
    private String rol;
    private String userid;
}
