package nl.belastingdienst.iva.wd.kbs.zof.domain;

public enum EntiteitMiddelKenmerkEnum {
    HK, SK1, SK2, SK3, UNKNOWN;

    @SuppressWarnings("java:S1541")
    static EntiteitMiddelKenmerkEnum valueOf(Long hoofdKenmerkId, Long subKenmerk1Id, Long subKenmerk2Id, Long subKenmerk3Id) {
        if(hoofdKenmerkId == null){ return EntiteitMiddelKenmerkEnum.UNKNOWN;}

        if(subKenmerk3Id != null && subKenmerk2Id != null && subKenmerk1Id != null){ return EntiteitMiddelKenmerkEnum.SK3;}
        if(subKenmerk3Id == null && subKenmerk2Id != null && subKenmerk1Id != null){ return EntiteitMiddelKenmerkEnum.SK2;}
        if(subKenmerk3Id == null && subKenmerk2Id == null && subKenmerk1Id != null){ return EntiteitMiddelKenmerkEnum.SK1;}
        if(subKenmerk3Id == null && subKenmerk2Id == null){ return EntiteitMiddelKenmerkEnum.HK;}

        return EntiteitMiddelKenmerkEnum.UNKNOWN;
    }
}
