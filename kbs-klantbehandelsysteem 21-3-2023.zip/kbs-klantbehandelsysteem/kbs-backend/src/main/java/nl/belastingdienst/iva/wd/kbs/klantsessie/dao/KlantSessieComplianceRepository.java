package nl.belastingdienst.iva.wd.kbs.klantsessie.dao;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KlantSessieComplianceRepository extends JpaRepository<KlantsessieCompliance, KlantsessieCompliance.PrimaryKey> {

    List<KlantsessieCompliance> findAllByKlantsessieIdAndMiddelId(Long klantSessieId, Integer middelId);
    int countAllByKlantsessieIdAndMiddelIdAndScoreNotNullAndToelichtingNotNull(Long klantSessieId, Integer middelId);
    int countAllByKlantsessieIdAndMiddelId(Long klantSessieId, Integer middelId);
    List<KlantsessieCompliance> findAllByKlantsessieId(Long klantSessieId);
}
