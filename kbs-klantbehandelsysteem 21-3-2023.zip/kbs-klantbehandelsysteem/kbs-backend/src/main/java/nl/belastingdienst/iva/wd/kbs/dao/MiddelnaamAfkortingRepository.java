package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelnaamAfkorting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MiddelnaamAfkortingRepository extends JpaRepository<MiddelnaamAfkorting, Integer> {

}
