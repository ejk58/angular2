/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: EntiteitConvenantindicatieService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 30-8-2021 10:29
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.ApiServiceApplicationProperties;
import nl.belastingdienst.iva.wd.kbs.domain.Behandelteam;
import nl.belastingdienst.iva.wd.kbs.domain.OrgBehandelteamGegevens;
import nl.belastingdienst.iva.wd.kbs.domain.OrgKantoorTeam;
import nl.belastingdienst.iva.wd.kbs.domain.OrgKlantGroep;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class OrgGegevensService {
    private final ApiServiceApplicationProperties apiServiceApplicationProperties;
    private final RestTemplateClient restTemplateClient;

    public OrgKantoorTeam getOrgKantoorTeamGegevens(Long entiteitnummer) {
        URI uri = URI.create(apiServiceApplicationProperties.getOrgGegevensBaseUrl() + entiteitnummer + "/competent-kantoor-team");
        String apiKeyKantoorteam = apiServiceApplicationProperties.getOrgApiKeyKantoorteam();

        ResponseEntity<OrgKantoorTeam> responseEntity = restTemplateClient.doRequest(HttpMethod.GET, uri, null, OrgKantoorTeam.class, apiKeyKantoorteam, false);
        return responseEntity.getBody();
    }

    public OrgKlantGroep getOrgKlantGroepGegevens(Long entiteitnummer) {
        URI uri = URI.create(apiServiceApplicationProperties.getOrgGegevensBaseUrl() + entiteitnummer + "/klantgroep");
        String apiKeyKlantgroep = apiServiceApplicationProperties.getOrgApiKeyKantoorteam();
        ResponseEntity<OrgKlantGroep> responseEntity = restTemplateClient.doRequest(HttpMethod.GET, uri, null, OrgKlantGroep.class, apiKeyKlantgroep, false);
        return responseEntity.getBody();
    }

    public List<Behandelteam> getOrgBehandelteam(Long entiteitnummer) {
        URI uri = URI.create(apiServiceApplicationProperties.getOrgGegevensBaseUrl() + entiteitnummer + "/behandelteam");
        String apiKeyBehandelteam = apiServiceApplicationProperties.getOrgApiKeyKantoorteam();
        ResponseEntity<OrgBehandelteamGegevens> responseEntity = restTemplateClient.doRequest(HttpMethod.GET, uri, null, OrgBehandelteamGegevens.class, apiKeyBehandelteam, false);
        OrgBehandelteamGegevens orgBehandelteamGegevens = responseEntity.getBody();
        return orgBehandelteamGegevens != null ? orgBehandelteamGegevens.getBehandelteam() : List.of();
    }

}
