package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStatusRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.CheckStatusInterface;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStatus;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.exceptions.FailedToInitializeCheckServicesMapException;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class KlantsessieStatusService {

	private final KlantsessieService ksService;
	private final KlantsessieStatusRepository klantsessieStatusRepository;

	private final Logging2Service logging2Service;

	private final List<CheckStatusInterface> checkStatusInterfaceList;
	private final Map<StepEnum, CheckStatusInterface> checkServiceMap = new EnumMap<>(StepEnum.class);

	@PostConstruct
	private void initCheckServicesMap() {
		this.checkStatusInterfaceList.forEach(checkService -> checkServiceMap.put(checkService.getStepEnum(), checkService));
		if (this.checkStatusInterfaceList.size() != this.checkServiceMap.size()) {
			throw new FailedToInitializeCheckServicesMapException("Error could be due to duplicate use of StepEnum.");
		}
	}

	public KlantsessieStatus getCurrentKlantsessieStatus(Long entiteitnummer, Integer middelId) {
		Long currentKsId = ksService.getCurrentKlantsessie(entiteitnummer).getId();
		Optional<KlantsessieStatus> current = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(currentKsId, middelId);
		return current.orElseGet(() -> klantsessieStatusRepository.save(new KlantsessieStatus(currentKsId, middelId)));
	}

	public void updateVoorbereidingAfgerond(Long entiteitnummer, Integer middelId, String loggingId) {
		var current = getCurrentKlantsessieStatus(entiteitnummer, middelId);
		current.setVoorbereidingAfgerond(true);
		setAllStepsToDone(current);
		this.logging2Service.save(loggingId, entiteitnummer, Logging2.Bewerking.UPDATE);
	}

	public void updateStatussenWhenControlePlaatsgevonden(Long entiteitnummer, Boolean controlePlaatsgevonden) {
		var current = getCurrentKlantsessieStatus(entiteitnummer, Klantsessie.CONTROLE_MIDDEL_ID);
		if (Boolean.TRUE.equals(controlePlaatsgevonden)) {
			checkServiceMap.forEach((key, value) -> {
				StepStatusEnum stepStatus = value.check(current.getKlantsessieId(), current.getMiddelId());
				setStepStatus(entiteitnummer, current.getMiddelId(), key, stepStatus);
			});
		} else {
			setStepsToDisabled(current);
		}
	}

	public void setStepStatus(Long entiteitnummer, Integer middelId, StepEnum step, StepStatusEnum status) {
		var kss = getCurrentKlantsessieStatus(entiteitnummer, middelId);
		switch (step) {
		case ZOOEF:
			kss.setZooefStatus(status);
			break;
		case COMPLIANCE:
			kss.setComplianceStatus(status);
			break;
		case STRATEGIE:
			kss.setStrategieStatus(status);
			break;
		default:
			break;
		}

		//business rule: if voorbereiding was previously afgerond, the last step status is always TOUCHED, otherwise INITIAL
		if (Boolean.TRUE.equals(kss.getVoorbereidingAfgerond())) {
			kss.setVoorbereidingAfrondenStatus(StepStatusEnum.TOUCHED);
		} else {
			kss.setVoorbereidingAfrondenStatus(StepStatusEnum.INITIAL);
		}

		klantsessieStatusRepository.save(kss);
	}

	private void setAllStepsToDone(KlantsessieStatus current) {
		current.setZooefStatus(StepStatusEnum.DONE);
		current.setStrategieStatus(StepStatusEnum.DONE);
		current.setComplianceStatus(StepStatusEnum.DONE);
		current.setVoorbereidingAfrondenStatus(StepStatusEnum.DONE);
		klantsessieStatusRepository.save(current);
	}

	private void setStepsToDisabled(KlantsessieStatus current) {
		current.setZooefStatus(StepStatusEnum.INITIAL);
		current.setStrategieStatus(StepStatusEnum.DISABLED);
		current.setComplianceStatus(StepStatusEnum.DISABLED);
		current.setVoorbereidingAfrondenStatus(StepStatusEnum.DISABLED);
		klantsessieStatusRepository.save(current);
	}
}
