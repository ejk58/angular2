package nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico;

import java.util.List;

import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelection;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BusinessRuleMiddelSpecifiekeRisicoDto {
    MiddelSpecifiekeRisicoSelection selection;
    List<EntiteitMiddelRisico> collection;
}
