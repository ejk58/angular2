package nl.belastingdienst.iva.wd.kbs.tablefiltering.utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.Path;

import org.springframework.data.jpa.domain.Specification;

import nl.belastingdienst.iva.wd.kbs.tablefiltering.domain.LazyLoadEvent;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class FilterSpecificationCreator {

    public static <T> Specification<T> createSpecification(
            Specification<T> fullSpec,
            Map<String, List<LazyLoadEvent.Filter>> lazyLoadEventFilters,
            Class<T> tClass) {

        if (lazyLoadEventFilters == null) return fullSpec;

        for (var entry : lazyLoadEventFilters.entrySet()) {
            String fieldName = entry.getKey();
            if (!FilterableFieldsRetriever.getFilterableFields(tClass).contains(fieldName)) {
                continue;
            }

            Specification<T> columnFilters = null;
            columnFilters = getSpecificationForColumns(entry, fieldName, columnFilters);
            if (columnFilters != null) {
                fullSpec = fullSpec == null ? columnFilters : fullSpec.and(columnFilters);
            }
        }
        return fullSpec;
    }

    private static <T> Specification<T> getSpecificationForColumns(Map.Entry<String, List<LazyLoadEvent.Filter>> entry,
            String fieldName, Specification<T> columnFilters) {
        for (LazyLoadEvent.Filter filter : entry.getValue()) {
            if (isFilterValueEntered(filter)) {
                continue;
            }

            Specification<T> newSpecification =
                    FilterSpecificationCreator.createSpecificationForFilter(fieldName, filter.getMatchMode(), filter.getValue());

            if (columnFilters == null) {
                columnFilters = newSpecification;
            } else if (filter.getOperator() == null || filter.getOperator().equalsIgnoreCase("and")) {
                columnFilters = columnFilters.and(newSpecification);
            } else {
                columnFilters = columnFilters.or(newSpecification);
            }
        }
        return columnFilters;
    }

    private static boolean isFilterValueEntered(LazyLoadEvent.Filter filter) {
        return filter == null || filter.getValue() == null || (filter.getValue() instanceof String &&
                ((String) filter.getValue()).isBlank()) || (filter.getValue() instanceof List && ((List<?>) filter.getValue()).isEmpty());
    }

    private static <T> Specification<T> createSpecificationForFilter(String key, String matchMode, Object value) {
        log.info("filter {}: {} {}", matchMode, key, value);
        switch (matchMode) {
            case "startsWith": {
                return startsWith(key, value.toString().toUpperCase() + "%");
            }
            case "contains": {
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.like(criteriaBuilder.upper(root.get(key).as(String.class)), "%" + value.toString().toUpperCase() + "%");
            }
            case "in":
                return (root, query, criteriaBuilder) -> {
                    Path<Object> expression = root.get(key);
                    var inClause = criteriaBuilder.in(expression);
                    @SuppressWarnings("unchecked") Iterable<Object> objects = (Iterable<Object>) value;
                    for (var v : objects) {
                        inClause.value(v);
                    }
                    return inClause;
                };
            case "notContains": {
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.notLike(criteriaBuilder.upper(root.get(key).as(String.class)), "%" + value.toString().toUpperCase() + "%");
            }
            case "endsWith": {
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.like(criteriaBuilder.upper(root.get(key).as(String.class)), "%" + value.toString().toUpperCase());
            }
            case "notEquals": {
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.notEqual(criteriaBuilder.upper(root.get(key).as(String.class)), value.toString().toUpperCase());
            }
            case "dateIs": {
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.equal(root.get(key), parseDate("" + value));
            }
            case "dateBefore": {
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.lessThan(root.get(key), parseDate("" + value));
            }
            case "dateAfter": {
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.greaterThan(root.get(key), parseDate("" + value));
            }
            case "dateIsNot": {
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.notEqual(root.get(key), parseDate("" + value));
            }
            case "equals":
            default:
                return (root, query, criteriaBuilder) ->
                        criteriaBuilder.equal(criteriaBuilder.upper(root.get(key).as(String.class)), value.toString().toUpperCase());
        }
    }

    private static <T> Specification<T> startsWith(String key, String value) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(criteriaBuilder.upper(root.get(key).as(String.class)), value);
    }

    private static LocalDate parseDate(String value) {
        var temporalAccessor = DateTimeFormatter.ISO_INSTANT.parse(value);
        return Instant.from(temporalAccessor).atZone(ZoneId.systemDefault()).toLocalDate();
    }

}

