package nl.belastingdienst.iva.wd.kbs.krr;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.exception.FailedToRetrieveSuccessfulResponseException;
import nl.belastingdienst.iva.wd.kbs.krr.domain.BepaalCategorieGo;
import nl.belastingdienst.iva.wd.kbs.service.RestTemplateClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.net.URI;

@Service
@RequiredArgsConstructor
@Slf4j
public class KrrService {
    @Value("${krr.api.base.url}")
    private String baseUrl;
    @Value("${krr.api.key}")
    private String apiKey;

    private final RestTemplateClient restTemplateClient;

    public BepaalCategorieGo[] getCategorieGo(Long entiteitnummer) {
        var uri = URI.create(baseUrl + "bepaalCategorieGO?entnr=" + entiteitnummer);
        ResponseEntity<BepaalCategorieGo[]> responseEntity =
                restTemplateClient.doKrrRequest(HttpMethod.GET, uri, null, BepaalCategorieGo[].class, apiKey);
        if (responseEntity == null) {
            throw new FailedToRetrieveSuccessfulResponseException("Could no retrieve data from krr api for entinteinummer " + entiteitnummer);
        }
        return responseEntity.getBody();
    }
}
