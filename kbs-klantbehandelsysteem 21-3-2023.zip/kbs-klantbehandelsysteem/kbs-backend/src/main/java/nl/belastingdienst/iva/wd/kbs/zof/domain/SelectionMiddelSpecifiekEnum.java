package nl.belastingdienst.iva.wd.kbs.zof.domain;

/*
* HR = Hoofdrisco
* SR = Subrisico
* K = Kenmerk
* */
public enum SelectionMiddelSpecifiekEnum {
    HR, // Only Hoofdrisico is selected
    HRSR, // Hoofdrisico + subrisico
    HRSRK, // Hoofdrisico + subrisico + kenmerk
    HRK, // Hoofdrisico + kenmerk
    UNKNOWN;

    static SelectionMiddelSpecifiekEnum valueOf(Long hoofdRisicoId, Long subRisicoId, Long kenmerkId) {
        if (hoofdRisicoId != null && subRisicoId != null && kenmerkId == null) {return SelectionMiddelSpecifiekEnum.HRSR;}
        if (hoofdRisicoId != null && subRisicoId == null && kenmerkId == null) {return SelectionMiddelSpecifiekEnum.HR;}
        if (hoofdRisicoId != null && subRisicoId != null) {return SelectionMiddelSpecifiekEnum.HRSRK;}
        if (hoofdRisicoId != null) {return SelectionMiddelSpecifiekEnum.HRK;}
        return SelectionMiddelSpecifiekEnum.UNKNOWN;
    }
}
