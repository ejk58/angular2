package nl.belastingdienst.iva.wd.kbs.zof.mappings;

import org.mapstruct.Mapper;

import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelKenmerk;

@Mapper(componentModel = "spring")
public interface EntiteitMiddelKenmerkMapper {
	EntiteitMiddelKenmerk map(EntiteitMiddelKenmerkDto entiteitMiddelKenmerkDto);
	EntiteitMiddelKenmerkDto map(LowestEntiteitMiddelKenmerk lowestEntiteitMiddelKenmerk);
}
