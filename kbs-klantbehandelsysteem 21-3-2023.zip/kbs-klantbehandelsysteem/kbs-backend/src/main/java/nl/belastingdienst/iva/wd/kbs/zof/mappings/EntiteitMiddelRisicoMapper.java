package nl.belastingdienst.iva.wd.kbs.zof.mappings;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisicoDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelection;

@Mapper(componentModel = "spring")
public interface EntiteitMiddelRisicoMapper {
	EntiteitMiddelRisico map(EntiteitMiddelRisicoDto entiteitMiddelRisicoDto);
	List<EntiteitMiddelRisico> mapFromDto(List<EntiteitMiddelRisicoDto> entiteitMiddelRisicoDtos);
	EntiteitMiddelRisico map(MiddelSpecifiekeRisicoSelection middelSpecifiekeRisicoSelection);
	List<EntiteitMiddelRisico> map(List<MiddelSpecifiekeRisicoSelection> middelSpecifiekeRisicoSelection);
	@Mapping(target = "entiteitMiddelKenmerkId", source = "lowestEntiteitMiddelKenmerk.id")
	EntiteitMiddelRisicoDto mapToDto(LowestEntiteitMiddelRisico lowestEntiteitMiddelRisico);
	List<MiddelSpecifiekeRisicoSelection> mapToSelection(List<EntiteitMiddelRisico> entiteitMiddelRisicoList);
}
