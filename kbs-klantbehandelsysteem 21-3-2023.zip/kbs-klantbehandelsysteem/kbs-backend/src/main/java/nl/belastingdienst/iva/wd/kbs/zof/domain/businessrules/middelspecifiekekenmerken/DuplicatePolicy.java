/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: DuplicatePolicy.java
 *             Auteur: duisr01
 *    Creatietijdstip: 14-4-2022 14:10
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken;

import java.util.Objects;
import java.util.function.Predicate;

import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkSelection;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRulePolicy;

public class DuplicatePolicy implements BusinessRulePolicy<EntiteitMiddelKenmerkSelection, EntiteitMiddelKenmerk> {
	@Override
	public Predicate<EntiteitMiddelKenmerk> getPredicates(EntiteitMiddelKenmerkSelection businessRuleDto) {
		return (emk -> Objects.equals(emk.getHoofdKenmerkId(), businessRuleDto.getHoofdKenmerkId())
				&& Objects.equals(emk.getSubKenmerk1Id(), businessRuleDto.getSubKenmerk1Id())
				&& Objects.equals(emk.getSubKenmerk2Id(), businessRuleDto.getSubKenmerk2Id())
				&& Objects.equals(emk.getSubKenmerk3Id(), businessRuleDto.getSubKenmerk3Id()));
	}

	@Override
	public String getErrorMessage() {
		return "Deze combinatie bestaat al.";
	}

	@Override
	public Class<? extends BusinessRulePolicy<EntiteitMiddelKenmerkSelection, EntiteitMiddelKenmerk>> getPolicyClass() {
		return DuplicatePolicy.class;
	}
}
