package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@IdClass(KlantsessieStatus.PrimaryKey.class)
@Table(name = "KLANTSESSIE_STATUS")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class KlantsessieStatus {

	@Data
	public static class PrimaryKey implements Serializable {
		private static final long serialVersionUID = -3221780016766274704L;

		private Long klantsessieId;
		private Integer middelId;
	}

	@Id
	@Column(name = "KLANTSESSIE_ID", nullable = false)
	private Long klantsessieId;

	@Id
	@Column(name = "MIDDEL_ID", nullable = false)
	private Integer middelId;

	@Enumerated(EnumType.STRING)
	@Column(name = "ZOOEF_STATUS")
	private StepStatusEnum zooefStatus;

	@Enumerated(EnumType.STRING)
	@Column(name = "COMPLIANCE_STATUS")
	private StepStatusEnum complianceStatus;

	@Enumerated(EnumType.STRING)
	@Column(name = "STRATEGIE_STATUS")
	private StepStatusEnum strategieStatus;

	@Enumerated(EnumType.STRING)
	@Column(name = "VOORBEREIDING_AFRONDEN_STATUS")
	private StepStatusEnum voorbereidingAfrondenStatus;

	@Column(name = "VOORBEREIDING_AFGEROND")
	private Boolean voorbereidingAfgerond;

	public KlantsessieStatus(Long klantsessieId, Integer middelId) {
		setKlantsessieId(klantsessieId);
		setMiddelId(middelId);
		setZooefStatus(StepStatusEnum.INITIAL);
		if(middelId.equals(Klantsessie.CONTROLE_MIDDEL_ID)) {
			setComplianceStatus(StepStatusEnum.DISABLED);
			setStrategieStatus(StepStatusEnum.DISABLED);
			setVoorbereidingAfrondenStatus(StepStatusEnum.DISABLED);
		} else {
			setComplianceStatus(StepStatusEnum.INITIAL);
			setStrategieStatus(StepStatusEnum.INITIAL);
			setVoorbereidingAfrondenStatus(StepStatusEnum.INITIAL);
		}
		setVoorbereidingAfgerond(Boolean.FALSE);
	}
}
