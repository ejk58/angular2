package nl.belastingdienst.iva.wd.kbs.dao;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import lombok.RequiredArgsConstructor;

/**
 * Based on https://www.baeldung.com/rest-api-search-language-spring-data-specifications
 */
@RequiredArgsConstructor
public class CustomSpecification<T> implements Specification<T> {

	private static final long serialVersionUID = -3482989765565332598L;

	private final SearchCriteria criteria;

	@Override
	public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
		Path<String> column = root.get(criteria.getKey());
		switch (criteria.getOperation()) {
		case GREATER_THAN:
			return builder.greaterThan(column, criteria.getValue().toString());
		case GREATER_THAN_OR_EQUALS:
			return builder.greaterThanOrEqualTo(column, criteria.getValue().toString());
		case LESS_THAN:
			return builder.lessThan(column, criteria.getValue().toString());
		case LESS_THAN_OR_EQUALS:
			return builder.lessThanOrEqualTo(column, criteria.getValue().toString());
		case LIKE:
			return builder.like(column.as(String.class), String.format("%%%s%%", criteria.getValue()));
		case IN:
			Path<Object> expression = root.get(criteria.getKey());
			var inClause = builder.in(expression);
			@SuppressWarnings("unchecked") Iterable<Object> objects = (Iterable<Object>) criteria.getValue();
			for (var v : objects) {
				inClause.value(v);
			}
			return inClause;
		case EQUALS:
		default:
			return builder.equal(column, criteria.getValue());
		}
	}
}

