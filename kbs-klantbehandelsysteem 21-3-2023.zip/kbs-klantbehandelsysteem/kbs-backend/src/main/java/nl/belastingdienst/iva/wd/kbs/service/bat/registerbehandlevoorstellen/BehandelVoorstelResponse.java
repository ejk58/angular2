package nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class BehandelVoorstelResponse {
    private String id;
    private String token;
}
