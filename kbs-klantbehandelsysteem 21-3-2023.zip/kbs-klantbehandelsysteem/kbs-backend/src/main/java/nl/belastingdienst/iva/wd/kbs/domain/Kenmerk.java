package nl.belastingdienst.iva.wd.kbs.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "KENMERK")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Kenmerk {

	@Id
	private Integer id;
	private String groep;
	private String kenmerk;
	@Column(name = "KENMERK_PARENT_ID")
	private Integer kenmerkParentId;
}
