package nl.belastingdienst.iva.wd.kbs.kta.domain;

import lombok.Data;

@Data
public class LdapPerson {
	private String userId;
	private String name;
	private String email;
	private String role;
}
