/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.kta.domain;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import nl.belastingdienst.iva.wd.kbs.tablefiltering.domain.Filterable;

import lombok.Data;

@Entity
@Immutable
@Table(name = "VW156_KZB_ZICHT_OP_ORGANISATIE_ENTITEIT")
@Data
public class KtaSubEntiteit {

	public static final String ATTR_BSN_RSIN = "bsnRsin";
    public static final String ATTR_ENTITEIT_NUMMER = "entiteitNummer";

    @Id
    @Column(name = "BSN_RSIN")
    @Filterable
    private Long bsnRsin;
    @Column(name = "BEGINDATUM")
    @Filterable
    private LocalDate beginDatum;
    @Column(name = "EINDDATUM")
    @Filterable
    private LocalDate eindDatum;
    @Filterable
    private String plaats;
    @Filterable
    private String naam;
    @Column(name = "SOORT_PERSOON")
    @Filterable
    private String soortPersoon;
    @Column(name = "ENTITEITNUMMER")
    @Filterable
    private Long entiteitNummer;
}
