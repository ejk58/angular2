package nl.belastingdienst.iva.wd.kbs.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppelingCompositeId;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppelingEntiteitMiddelKenmerkIdDto;

@Repository
public interface KenmerkRisicoKoppelingRepository extends JpaRepository<KenmerkRisicosKoppeling, KenmerkRisicosKoppelingCompositeId> {
    List<KenmerkRisicosKoppeling> findAllByMiddelKenmerkId(Long middelKenmerkId);
    @SuppressWarnings("java:S100")
    boolean existsByMiddelKenmerk_IdAndMiddelRisico_Id(Long middelKenmerkId, Long middelRisicoId);
    List<KenmerkRisicosKoppeling> findAllByMiddelRisicoId(Long middelRisicoId);

    @Query(value = "SELECT new nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppelingEntiteitMiddelKenmerkIdDto(krk.middelKenmerk, krk.middelRisico, lowestEmk.id) "
            + "FROM KenmerkRisicosKoppeling krk "
            + "LEFT JOIN LowestEntiteitMiddelKenmerk as lowestEmk ON krk.middelKenmerk=lowestEmk.lowest "
            + "WHERE lowestEmk.entiteitNummer = :entiteitnummer "
            + "AND krk.middelRisico.id = :risicoId "
            + "ORDER BY lowestEmk.rank ")
    List<KenmerkRisicosKoppelingEntiteitMiddelKenmerkIdDto> findAllLinkableMiddelKenmerkByEntiteitnummerAndRisicoId(Long entiteitnummer, Long risicoId);
}
