package nl.belastingdienst.iva.wd.kbs.zof.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.kta.dao.ReadOnlyJpaRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisicoDto;

@Repository
public interface ViewLowestRisicoRepository extends ReadOnlyJpaRepository<LowestEntiteitMiddelRisico, Long> {
	@SuppressWarnings("java:S100")
	List<LowestEntiteitMiddelRisico> findAllByEntiteitNummerAndLowest_MiddelId(Long entiteitnummer, Integer middelId);
	@SuppressWarnings("java:S100")
	List<LowestEntiteitMiddelRisico> findAllByEntiteitNummerAndLowest_MiddelIdOrderByRank(Long entiteitnummer, Integer middelId);
	@Query(value = "SELECT new nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisicoDto(lr.lowest.risico, lr.keyRisk, ks.kenmerk, kb.kenmerk, ma.afkorting) "
			+ "FROM LowestEntiteitMiddelRisico lr "
			+ "LEFT JOIN Kenmerk as ks ON lr.statusId=ks.id "
			+ "LEFT JOIN Kenmerk as kb ON lr.beheersing=kb.id "
			+ "LEFT JOIN MiddelnaamAfkorting as ma ON lr.lowest.middelId=ma.middelId "
			+ "WHERE lr.entiteitNummer = :entiteitnummer "
			+ "ORDER BY ma.rank, lr.rank ")
	List<LowestEntiteitMiddelRisicoDto> getOverviewByEntiteitnummer(Long entiteitnummer);
}
