package nl.belastingdienst.iva.wd.kbs.zof.service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class FiscaliteitService {

    private final MiddelKenmerkRepository middelKenmerkRepository;
    private final EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;
    private final MiddelRisicoRepository middelRisicoRepository;
    private final EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;
    private final KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;
    private final Logging2Service logging2Service;

    public List<MiddelKenmerk> getMiddelKenmerken() {
        return middelKenmerkRepository.findAll();
    }

    public List<MiddelKenmerk> getKenmerkenByMiddelId(Integer middelId) {
        return middelKenmerkRepository.findAllByMiddelId(middelId);
    }

    public void updateRanksOfSelectedEntiteitMiddelKenmerken(Map<Long, Long> emkIdWithRankMap, String loggingId, Long entiteitnummer) {
        List<EntiteitMiddelKenmerk> updatedEmks = emkIdWithRankMap.entrySet().parallelStream()
                .map(entry -> {
                    Long emkId = entry.getKey();
                    Optional<EntiteitMiddelKenmerk> emkOpt = entiteitMiddelKenmerkRepository.findById(emkId);
                    if (emkOpt.isEmpty()) {
                        log.warn("EntiteitMiddelKenmerk with ID " + emkId + " not found; rank not updated! Continuing...");
                        return null;
                    }

                    EntiteitMiddelKenmerk emk = emkOpt.get();
                    emk.setRank(entry.getValue());
                    return emk;
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toUnmodifiableList());
        logging2Service.save(loggingId, entiteitnummer, Logging2.Bewerking.UPDATE);
        entiteitMiddelKenmerkRepository.saveAll(updatedEmks);

    }

    public void updateRanksOfSelectedEntiteitMiddelRisicos(Map<Long, Long> emrIdWithRankMap, String loggingId, Long entiteitnummer) {
        List<EntiteitMiddelRisico> updatedEmrs = emrIdWithRankMap.entrySet().parallelStream()
                .map(entry -> {
                    Long emrId = entry.getKey();
                    Optional<EntiteitMiddelRisico> emrOpt = entiteitMiddelRisicoRepository.findById(emrId);
                    if (emrOpt.isEmpty()) {
                        log.warn("EntiteitMiddelRisico with ID " + emrId + " not found; rank not updated! Continuing...");
                        return null;
                    }

                    EntiteitMiddelRisico emr = emrOpt.get();
                    emr.setRank(entry.getValue());
                    return emr;
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toUnmodifiableList());
        logging2Service.save(loggingId, entiteitnummer, Logging2.Bewerking.UPDATE);
        entiteitMiddelRisicoRepository.saveAll(updatedEmrs);
    }

    public List<MiddelRisico> getMiddelRisicos() {
        return middelRisicoRepository.findAll();
    }

    public List<MiddelRisico> getRisicosByMiddelId(Integer middelId) {
        return middelRisicoRepository.findAllByMiddelIdOrderByRank(middelId);
    }

    public List<KenmerkRisicosKoppeling> findAllPossibleKenmerkenForMiddelRisicoById(Long risicoId){
        return kenmerkRisicoKoppelingRepository.findAllByMiddelRisicoId(risicoId);
    }
}
