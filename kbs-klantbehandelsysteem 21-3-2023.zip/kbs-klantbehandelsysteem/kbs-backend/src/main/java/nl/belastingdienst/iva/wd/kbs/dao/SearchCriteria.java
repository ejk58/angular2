/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: SearchCriteria.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 24-2-2022 13:36
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.dao;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class SearchCriteria {
	private final String key;
	private final Operator operation;
	private final Object value;

	public enum Operator {
		EQUALS,
		LESS_THAN,
		LESS_THAN_OR_EQUALS,
		GREATER_THAN,
		GREATER_THAN_OR_EQUALS,
		LIKE,
		IN
	}
}

