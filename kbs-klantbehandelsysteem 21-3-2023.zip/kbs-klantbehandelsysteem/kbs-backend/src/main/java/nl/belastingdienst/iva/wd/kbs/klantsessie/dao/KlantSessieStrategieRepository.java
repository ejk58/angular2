package nl.belastingdienst.iva.wd.kbs.klantsessie.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategie;

@Repository
public interface KlantSessieStrategieRepository extends JpaRepository<KlantsessieStrategie, KlantsessieStrategie.PrimaryKey> {
		int countAllByKlantsessieIdAndMiddelIdAndMiddellangeTermijnNotNullAndKorteTermijnNotNull(Long klantsessieId, Integer middelId);
		int countAllByKlantsessieIdAndMiddelId(Long klantsessieId, Integer middelId);
}