/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KlantsessieComplianceRestController.java
 *             Auteur: duisr01
 *    Creatietijdstip: 30-6-2022 16:21
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ChartLabel;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkChild;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieComplianceDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.mappings.KlantsessieComplianceMapper;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieComplianceService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieComplianceUpdateService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.security.HtmlSanitizer;

import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@RestController
@RequestMapping("/api/klantsessie/compliance")
public class KlantsessieComplianceRestController {
	private final KlantsessieComplianceService klantsessieComplianceService;
	private final KlantsessieComplianceUpdateService klantsessieComplianceUpdateService;
	private final KlantsessieComplianceMapper klantsessieComplianceMapper;

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/previous/{entiteitNummer}/{middelId}")
	public KlantsessieComplianceDto getPreviousKlantsessieCompliance(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
		return klantsessieComplianceService.getPreviousKlantsessieCompliance(entiteitNummer, middelId);
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/{middelId}")
	public KlantsessieComplianceDto getCurrentKlantsessieCompliance(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
		return klantsessieComplianceService.getCurrentKlantsessieCompliance(entiteitNummer, middelId);
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
	@GetMapping("/chart-labels")
	public List<ChartLabel> getKlantsessieComplianceChartLabels() {
		return klantsessieComplianceService.getChartLabels();
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/score/{entiteitNummer}/{middelId}")
	public KenmerkChild updateKlantsessieComplianceScore(@PathVariable Long entiteitNummer,
														 @PathVariable Integer middelId,
														 @RequestBody LoggingWrapper<KenmerkChild> kenmerkChildDto) {

		var kenmerkChild = kenmerkChildDto.getWrappedObject();

		if(kenmerkChild.getScore() < 0 || kenmerkChild.getScore() > 5){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
		}

		return this.klantsessieComplianceMapper.map(
				klantsessieComplianceUpdateService.updateScore(entiteitNummer, middelId, kenmerkChild,
						kenmerkChildDto.getLoggingId())
		);
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/toelichting/{entiteitNummer}/{middelId}")
	public KenmerkChild updateKlantsessieComplianceToelichting(@PathVariable Long entiteitNummer,
															   @PathVariable Integer middelId,
															   @RequestBody LoggingWrapper<KenmerkChild> kenmerkChildDto) {

		var kenmerkChild = kenmerkChildDto.getWrappedObject();

		if(kenmerkChild.getToelichting() != null){
			kenmerkChild.setToelichting(
					HtmlSanitizer.sanitizeHtml(kenmerkChild.getToelichting())
			);
		}


		return this.klantsessieComplianceMapper.map(
				klantsessieComplianceUpdateService.updateToelichting(entiteitNummer, middelId, kenmerkChild, kenmerkChildDto.getLoggingId())
		);
	}
}
