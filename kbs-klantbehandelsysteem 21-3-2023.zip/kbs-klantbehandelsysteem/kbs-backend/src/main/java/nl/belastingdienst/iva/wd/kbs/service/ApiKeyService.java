package nl.belastingdienst.iva.wd.kbs.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.ApiKeyRepository;
import nl.belastingdienst.iva.wd.kbs.domain.ApiKey;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Deprecated
@Service
@Slf4j
@RequiredArgsConstructor
public class ApiKeyService {

    private final ApiKeyRepository repo;

    private Map<String, ApiKey> cache = new HashMap<>();

    public boolean checkApiKeyForMethod(String key, String method) {
        return getApiKey(key).isMethodAuthorized(method);
    }

    private ApiKey getApiKey(String key) {
        ApiKey apiKey = cache.get(key);
        if (apiKey == null) {
            throw new BadCredentialsException("Unknown apikey");
        }
        return apiKey;
    }

    @PostConstruct
    @Scheduled(initialDelay = 1000 * 3600, fixedRate = 1000 * 3600)
    public void refresh() {
        log.debug("ApiKeys Refreshing....");
        Map<String, ApiKey> newApiKeys = new HashMap<>();
        for (ApiKey apiKey : this.repo.findAll()) {
            newApiKeys.put(apiKey.getKey(), apiKey);
        }
        this.cache = newApiKeys;
    }
}
