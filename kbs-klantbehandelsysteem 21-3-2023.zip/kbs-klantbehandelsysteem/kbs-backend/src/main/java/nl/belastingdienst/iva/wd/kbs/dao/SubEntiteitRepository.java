package nl.belastingdienst.iva.wd.kbs.dao;

import java.util.SortedSet;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteit;

@Repository
public interface SubEntiteitRepository extends JpaRepository<SubEntiteit, SubEntiteit.PrimaryKey> {

	@Transactional
	void deleteAllByEntiteitNummer(Long entiteitNummer);

	@Query("select s.subEntiteitBsnRsin from SubEntiteit s where s.entiteitNummer = :entiteitNummer order by s.subEntiteitBsnRsin")
	SortedSet<Long> findAllSubEntiteitBsnRsinByEntiteitNummerOrderBySubEntiteitBsnRsin(Long entiteitNummer);
}
