package nl.belastingdienst.iva.wd.kbs.zof.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;

@Repository
public interface EntiteitMiddelKenmerkRepository extends JpaRepository<EntiteitMiddelKenmerk, Long> {

    Optional<EntiteitMiddelKenmerk> findByEntiteitNummerAndId(Long entiteitNummer, Long id);

    List<EntiteitMiddelKenmerk> findEntiteitMiddelKenmerkByEntiteitNummer(Long entiteitNummer);
    List<EntiteitMiddelKenmerk> findEntiteitMiddelKenmerkByEntiteitNummerAndIdIsNot(Long entiteitNummer, Long id);

    Optional<EntiteitMiddelKenmerk> getTopByEntiteitNummerAndRankIsNotNullOrderByRankAsc(Long entiteitNummer);
    private Long getNewLowestRank(Long entiteitNummer){
        long newLowestRank = 0L;
        var previousEntiteitMiddelKenmerkWithRankOptional = getTopByEntiteitNummerAndRankIsNotNullOrderByRankAsc(entiteitNummer);

        if(previousEntiteitMiddelKenmerkWithRankOptional.isPresent()){
            newLowestRank = previousEntiteitMiddelKenmerkWithRankOptional.get().getRank() - 1L;
        }

        return newLowestRank;
    }

    default EntiteitMiddelKenmerk saveWithLowestRank(EntiteitMiddelKenmerk entiteitMiddelKenmerk){
        entiteitMiddelKenmerk.setRank(getNewLowestRank(entiteitMiddelKenmerk.getEntiteitNummer()));
        return save(entiteitMiddelKenmerk);
    }

}
