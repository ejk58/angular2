package nl.belastingdienst.iva.wd.kbs.zof.rest;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisicoDto;
import nl.belastingdienst.iva.wd.kbs.zof.mappings.EntiteitMiddelKenmerkMapper;
import nl.belastingdienst.iva.wd.kbs.zof.mappings.EntiteitMiddelRisicoMapper;
import nl.belastingdienst.iva.wd.kbs.zof.service.FindAllEntiteitMiddelKenmerkenForRisicoService;
import nl.belastingdienst.iva.wd.kbs.zof.service.FiscaliteitService;
import nl.belastingdienst.iva.wd.kbs.zof.service.GetRisicoListByMiddelkenmerkIdService;
import nl.belastingdienst.iva.wd.kbs.zof.service.algemenekenmerkenattentiepunten.GetAlgemeneKenmerkenAttentiepuntenService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk.DeleteEntiteitMiddelKenmerkService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk.GetEntiteitMiddelKenmerkenService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk.SaveEntiteitMiddelKenmerkService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.DeleteEntiteitMiddelRisicoService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.GetEntiteitMiddelRisicoService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.SaveEntiteitMiddelRisicoService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/fiscaliteit")
public class FiscaliteitController {

    private final FiscaliteitService fiscaliteitService;
    private final SaveEntiteitMiddelKenmerkService saveEntiteitMiddelKenmerkService;
    private final DeleteEntiteitMiddelKenmerkService deleteEntiteitMiddelKenmerkService;
    private final SaveEntiteitMiddelRisicoService saveEntiteitMiddelRisicoService;
    private final DeleteEntiteitMiddelRisicoService deleteEntiteitMiddelRisicoService;
    private final GetAlgemeneKenmerkenAttentiepuntenService getAlgemeneKenmerkenAttentiepuntenService;
    private final GetRisicoListByMiddelkenmerkIdService getRisicoListByMiddelkenmerkIdService;
    private final EntiteitMiddelKenmerkMapper entiteitMiddelKenmerkMapper;
    private final EntiteitMiddelRisicoMapper entiteitMiddelRisicoMapper;
    private final GetEntiteitMiddelKenmerkenService getEntiteitMiddelKenmerkenService;
    private final GetEntiteitMiddelRisicoService getEntiteitMiddelRisicoService;
    private final FindAllEntiteitMiddelKenmerkenForRisicoService findAllEntiteitMiddelKenmerkenForRisico;

    //kenmerken
    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/middelKenmerken")
    public List<MiddelKenmerk> getMiddelKenmerken() {
        return fiscaliteitService.getMiddelKenmerken();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/{middelId}/middelKenmerken")
    public List<MiddelKenmerk> getKenmerkenByMiddelId(@PathVariable Integer middelId) {
        return fiscaliteitService.getKenmerkenByMiddelId(middelId);
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/{entiteitNummer}/{middelId}/entiteitMiddelKenmerken")
    public List<EntiteitMiddelKenmerkDto> getSelectedEntiteitMiddelKenmerken(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
        return getEntiteitMiddelKenmerkenService.getEntiteitMiddelKenmerken(entiteitNummer, middelId);
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @PostMapping("/{entiteitNummer}/entiteitMiddelKenmerken/rank")
    public void updateRanksOfSelectedEntiteitMiddelKenmerken(@PathVariable Long entiteitNummer, @RequestBody LoggingWrapper<List<EntiteitMiddelKenmerk>> emkList) {
        Map<Long, Long> emkIdWithRankMap = emkList.getWrappedObject().stream()
                .collect(Collectors.toMap(EntiteitMiddelKenmerk::getId, EntiteitMiddelKenmerk::getRank, (a, b) -> b));
        fiscaliteitService.updateRanksOfSelectedEntiteitMiddelKenmerken(emkIdWithRankMap, emkList.getLoggingId(), entiteitNummer);
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @DeleteMapping("/{entiteitNummer}/{id}/deleteEntiteitMiddelKenmerk")
    public void deleteEntiteitMiddelKenmerk(@PathVariable Long entiteitNummer, @PathVariable Long id, @RequestBody LoggingWrapper<Void> loggingWrapper) {
        deleteEntiteitMiddelKenmerkService.delete(entiteitNummer, id, loggingWrapper.getLoggingId());
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitMiddelKenmerkDto.wrappedObject.entiteitNummer)")
    @PostMapping("/addEntiteitMiddelKenmerk")
    public void addEntiteitMiddelKenmerk(@RequestBody LoggingWrapper<EntiteitMiddelKenmerkDto> entiteitMiddelKenmerkDto) {
        saveEntiteitMiddelKenmerkService.save(
                entiteitMiddelKenmerkMapper.map(entiteitMiddelKenmerkDto.getWrappedObject()),
                entiteitMiddelKenmerkDto.getLoggingId()
        );
    }

    //risicos
    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/{middelId}/middelRisicos")
    public List<MiddelRisico> getRisicosByMiddelId(@PathVariable Integer middelId) {
        return fiscaliteitService.getRisicosByMiddelId(middelId);
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/middelRisicos/{middelKenmerkId}")
    public List<MiddelRisico> getRisicosByMiddelIdAndMiddelkenmerkId(@PathVariable Long middelKenmerkId) {
        return getRisicoListByMiddelkenmerkIdService.getByMiddelkenmerkId(middelKenmerkId);
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @DeleteMapping("/{entiteitNummer}/{id}/deleteEntiteitMiddelRisico")
    public void deleteEntiteitMiddelRisico(@PathVariable Long entiteitNummer, @PathVariable Long id, @RequestBody LoggingWrapper<Void> loggingWrapper) {
        deleteEntiteitMiddelRisicoService.delete(entiteitNummer, id, loggingWrapper.getLoggingId());
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/middelRisicos")
    public List<MiddelRisico> getMiddelRisicos() {
        return fiscaliteitService.getMiddelRisicos();
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/{entiteitNummer}/{middelId}/selectedEntiteitMiddelRisicos")
    public List<EntiteitMiddelRisicoDto> getSelectedEntiteitMiddelRisicos(@PathVariable Long entiteitNummer, @PathVariable Integer middelId) {
        return getEntiteitMiddelRisicoService.getEntiteitMiddelRisicosForEntiteitEnMiddel(entiteitNummer, middelId);
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @PostMapping("/{entiteitNummer}/selectedEntiteitMiddelRisicos/rank")
    public void updateRanksOfSelectedEntiteitMiddelRisicos(@PathVariable Long entiteitNummer,
            @RequestBody LoggingWrapper<List<EntiteitMiddelRisico>> emrList) {
        Map<Long, Long> emrIdWithRankMap = emrList.getWrappedObject().stream()
                .collect(Collectors.toMap(EntiteitMiddelRisico::getId, EntiteitMiddelRisico::getRank, (a, b) -> b));
        fiscaliteitService.updateRanksOfSelectedEntiteitMiddelRisicos(emrIdWithRankMap, emrList.getLoggingId(), entiteitNummer);
    }

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitMiddelRisicoDto.wrappedObject.entiteitNummer)")
    @PostMapping("/addEntiteitMiddelRisico")
    public void addEntiteitMiddelRisico(@RequestBody LoggingWrapper<EntiteitMiddelRisicoDto> entiteitMiddelRisicoDto) {
        saveEntiteitMiddelRisicoService.save(
                entiteitMiddelRisicoMapper.map(entiteitMiddelRisicoDto.getWrappedObject()),
                entiteitMiddelRisicoDto.getLoggingId()
        );
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/getKenmerkenForRisico/{middelRisicoId}")
    public List<KenmerkRisicosKoppeling> getKenmerkenForRisico(@PathVariable Long middelRisicoId){
        return fiscaliteitService.findAllPossibleKenmerkenForMiddelRisicoById(middelRisicoId);
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/{entiteitNummer}/getEntiteitMiddelKenmerkenForRisico/{middelRisicoId}")
    public Map<Long, MiddelKenmerk> getEntiteitMiddelKenmerkenForRisico(@PathVariable Long entiteitNummer, @PathVariable Long middelRisicoId){
        return findAllEntiteitMiddelKenmerkenForRisico.findAllEntiteitMiddelKenmerkenForRisico(entiteitNummer, middelRisicoId);
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
    @GetMapping("/{entiteitNummer}/{middelId}/getAlgemeneKenmerkenEnAttentiepunten")
    public List<Kenmerk> getAlgemeneKenmerkenEnAttentiepunten(@PathVariable Long entiteitNummer, @PathVariable Integer middelId){
        return getAlgemeneKenmerkenAttentiepuntenService.getAlgemeneKenmerkenEnAttentiepunten(entiteitNummer, middelId);
    }
}
