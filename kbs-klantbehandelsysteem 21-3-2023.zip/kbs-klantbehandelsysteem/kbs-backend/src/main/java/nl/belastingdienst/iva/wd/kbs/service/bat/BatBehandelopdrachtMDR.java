package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

import java.util.List;

@Data
public class BatBehandelopdrachtMDR extends BatBehandelplanvoorstel{

    private String arrangementId;
    private String disclosureId;
    private List<String> hallmarks;
    private String implementatieDatum;
    private String indienDatum;
    private String meldingId;
    private String samenvatting;
    private String toedeling;
    private String toelichting;
}
