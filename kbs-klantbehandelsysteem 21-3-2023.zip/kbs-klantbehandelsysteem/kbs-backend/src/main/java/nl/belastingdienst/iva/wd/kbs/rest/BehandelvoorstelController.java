package nl.belastingdienst.iva.wd.kbs.rest;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import nl.belastingdienst.iva.wd.kbs.ApiServiceApplicationProperties;
import nl.belastingdienst.iva.wd.kbs.domain.BehandelActiviteit;
import nl.belastingdienst.iva.wd.kbs.mappings.BehandelActiviteitMapper;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatBehandelvoorstelResponse;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatGegevensService;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.BatRegisterBehandelvoorstelService;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.BehandelVoorstelRequestDto;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.BehandelVoorstelResponse;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.BehandelvoorstelOption;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.RegisterBehandelvoorstelUrl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/behandelvoorstel")
public class BehandelvoorstelController {

    private final BatGegevensService batGegevensService;
    private final BatRegisterBehandelvoorstelService batRegisterBehandelvoorstelService;
    private final ApiServiceApplicationProperties apiServiceApplicationProperties;

    @PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#request.subject)")
    @PostMapping("/create")
    public BehandelVoorstelResponse createBehandelVoorstel(@RequestBody BehandelVoorstelRequestDto request) {
        return batRegisterBehandelvoorstelService.createBehandelVoorstel(request);
    }

    @GetMapping("/options")
    public List<BehandelvoorstelOption> getBehandelvoorstelOptions() {
        return batRegisterBehandelvoorstelService.getBehandelvoorstelOptions();
    }

    @GetMapping("/register-behandelvoorstel-url")
    public RegisterBehandelvoorstelUrl getRegisterBehandelvoorstelUrl() {
        return new RegisterBehandelvoorstelUrl(apiServiceApplicationProperties.getRegisterBehandelvoorstelUrl());
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitId)")
    @GetMapping("/{entiteitId}/{entiteitNaam}")
    public List<BehandelActiviteit> getBehandelVoorstellen(@PathVariable Long entiteitId, @PathVariable String entiteitNaam) {
        var stopWatch = new StopWatch();
        stopWatch.start("Fetching behandel voorstellen");
        BatBehandelvoorstelResponse behandelVoorstellen = batGegevensService.getBehandelVoorstellen(entiteitId);
        stopWatch.stop();
        stopWatch.start("Fetching activiteiten codes en status codes");
        Map<String,String> behandelActiviteitCodes = batGegevensService.getBehandelActiviteitCodes();
        Map<String,String> statusCodes = batGegevensService.getStatusCodes();
        stopWatch.stop();
        stopWatch.start("Mapping behandel activiteiten");
        var batRegisterbehandelActiviteitcodes = batRegisterBehandelvoorstelService.getBehandelActiviteitcodes();
        List<BehandelActiviteit> behandelActiviteitList = BehandelActiviteitMapper.map(behandelVoorstellen, behandelActiviteitCodes,
                statusCodes, entiteitNaam,batRegisterbehandelActiviteitcodes);
        stopWatch.stop();
        return behandelActiviteitList;
    }

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#request.subject)")
    @PostMapping("/view-or-delete-token")
    public BehandelVoorstelResponse getEditToken(@RequestBody BehandelVoorstelRequestDto request) {
        var authentication = SecurityContextHolder.getContext().getAuthentication();
        String loggedInUser = authentication.getName();

        boolean isBehandelaar = authentication.getAuthorities().stream().anyMatch(ga -> ga.getAuthority().equals("AUG_KBS_BEHANDELAAR"));

        if(request.getVoorstelAction().equals(BehandelVoorstelRequestDto.VOORSTEL_ACTION_DELETE) && !isBehandelaar){
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Gebruiker heeft geen rechten om behandelvoorstel te verwijderen.");
        }

        if (StringUtils.isBlank(loggedInUser))
            throw new NullPointerException("Aanmaken van een behandelactiviteit is mislukt: gebruiker is niet ingelogd!");

        request.setUserId(loggedInUser);

        return new BehandelVoorstelResponse(null, batRegisterBehandelvoorstelService.getToken(request));
    }
}
