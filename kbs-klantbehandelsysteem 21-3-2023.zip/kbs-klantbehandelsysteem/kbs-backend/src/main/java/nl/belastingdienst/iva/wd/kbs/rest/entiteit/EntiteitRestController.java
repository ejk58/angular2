/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: EntiteitController.java
 *             Auteur: schop13
 *    Creatietijdstip: 7-4-2021 11:38
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.rest.entiteit;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.SortedSet;
import java.util.stream.Stream;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.ApiServiceApplicationProperties;
import nl.belastingdienst.iva.wd.kbs.domain.Behandelteam;
import nl.belastingdienst.iva.wd.kbs.domain.Behandelvoorstel;
import nl.belastingdienst.iva.wd.kbs.domain.Convenantindicatie;
import nl.belastingdienst.iva.wd.kbs.domain.Entiteit;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKzbGegevens;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerken;
import nl.belastingdienst.iva.wd.kbs.domain.Opdracht;
import nl.belastingdienst.iva.wd.kbs.domain.OrgKantoorTeam;
import nl.belastingdienst.iva.wd.kbs.domain.OrgKlantGroep;
import nl.belastingdienst.iva.wd.kbs.domain.OrgUrls;
import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteitTestData;
import nl.belastingdienst.iva.wd.kbs.domain.ZooOmvang;
import nl.belastingdienst.iva.wd.kbs.domain.ZooSubEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteit;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.rest.FakeResponseTime;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitConvenantindicatieService;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitKzbGegevensService;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitService;
import nl.belastingdienst.iva.wd.kbs.service.OrgGegevensService;
import nl.belastingdienst.iva.wd.kbs.service.SubEntiteitService;
import nl.belastingdienst.iva.wd.kbs.tablefiltering.domain.LazyLoadEvent;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/entiteiten")
public class EntiteitRestController {

	private final EntiteitService entiteitService;
	private final SubEntiteitService subEntiteitService;
	private final EntiteitConvenantindicatieService entiteitConvenantindicatieService;
	private final FakeResponseTime fakeResponseTime;
	private final EntiteitKzbGegevensService entiteitKzbGegevensService;
	private final OrgGegevensService orgGegevensService;
	private final ApiServiceApplicationProperties apiServiceApplicationProperties;
	private static final ObjectMapper mapper = new ObjectMapper();

	public static final int NUMMBER_ROWS_PER_PAGE = 10;

	@GetMapping("/search")
	public List<Entiteit> searchEntiteiten(@RequestParam Optional<String> entiteitNumber, @RequestParam Optional<String> entiteitName,
			@RequestParam Optional<String> klantpakket) {
		var searchParams = Stream.of(entiteitNumber, entiteitName, klantpakket);
		if (searchParams.allMatch(strOpt -> strOpt.isEmpty() || strOpt.get().isBlank())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No search parameters specified!");
		}

		var querySearchParams = new KtaEntiteit();
		entiteitNumber.ifPresent(querySearchParams::setDosnr);
		entiteitName.ifPresent(querySearchParams::setDosnaam);
		//klantpakket.ifPresent(querySearchParams::setKlantPakket); // TODO IVAKBS-32: not supported by KtaEntiteit yet!
		List<Entiteit> mappedResults = entiteitService.search(querySearchParams);

		// TODO IVAKBS-32: Replace dummy data with the real deal.
		mappedResults.parallelStream().forEach(e -> {
			e.setAdres("!!! Juweelstraat 12, 5643FG  Eindhoven");
			e.setKlantpakket("!!! Onbekend");
		});

		return mappedResults;
	}

	@GetMapping("/{entiteitNummer}")
	public Entiteit getEntiteit(@PathVariable Long entiteitNummer) {
		Optional<Entiteit> result = entiteitService.findByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown entiteitNummer!");
		}
		return result.get();
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/dashboard/kenmerken")
	public String[][][] getEntiteitKenmerken(@PathVariable Long entiteitNummer) {
		Optional<String[][][]> result = entiteitService.findDashboardKenmerkenByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown entiteitNummer!");
		}
		return result.get();
	}

	//TODO checken of deze met entiteitnummer opgehaald kunnen worden uit DB
	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/algemeneGegevens/kenmerken")
	public Kenmerken getAlgemeneGegevensKenmerken(@PathVariable Long entiteitNummer) {
		Optional<Kenmerken> result = entiteitService.findAlgemeneGegevensKenmerkenByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No kenmerken found for entiteitNummer!");
		}
		return result.get();
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/algemeneGegevens/samenstelling")
	public List<SubEntiteitTestData> getAlgemeneGegevensSamenstelling(@PathVariable Long entiteitNummer) {
		Optional<List<SubEntiteitTestData>> result = entiteitService.findSamenstellingByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No samenstelling found for entiteitNummer!");
		}
		return result.get();
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/dashboard/behandelvoorstellen")
	public List<Behandelvoorstel> getDashboardBehandelvoorstellen(@PathVariable Long entiteitNummer) {
		Optional<List<Behandelvoorstel>> result = entiteitService.findBehandelvoorstellenByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No behandelvoorstellen found for entiteitNummer!");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/dashboard/opdrachten")
	public List<Opdracht> getDashboardOpdrachten(@PathVariable Long entiteitNummer) {
		Optional<List<Opdracht>> result = entiteitService.findOpdrachtenByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No opdrachten found for entiteitNummer!");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/zoo/omvang")
	public ZooOmvang getZooOmvang(@PathVariable Long entiteitNummer) {
		Optional<ZooOmvang> result = entiteitService.findZooEntiteitOmvang(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No omvang found for entiteitNummer!");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PutMapping("/{entiteitNummer}/zoo/omvang")
	public ZooOmvang saveZooOmvang(@PathVariable Long entiteitNummer, @RequestBody LoggingWrapper<ZooOmvang> zooOmvangDto) {
		var zooOmvang = entiteitService.saveZooOmvang(entiteitNummer, zooOmvangDto.getWrappedObject(), zooOmvangDto.getLoggingId());

		fakeResponseTime.fakeResponseTime();
		// TODO remove fake response delay:
		return zooOmvang;
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/{entiteitNummer}/subEntiteitSelections/save")
	public void saveSubEntiteitSelections(@PathVariable Long entiteitNummer, @RequestBody LoggingWrapper<SortedSet<Long>> selectedSubentiteitBsnRsins) {
		subEntiteitService.saveSubEntiteiten(entiteitNummer, selectedSubentiteitBsnRsins.getWrappedObject(), selectedSubentiteitBsnRsins.getLoggingId());
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/subEntiteiten")
	public Page<ZooSubEntiteit> getZooSubEntiteiten(@PathVariable Long entiteitNummer, @RequestParam String pageRequest) {
		LazyLoadEvent lazyLoadEvent;
		try {
			lazyLoadEvent = mapper.readValue(pageRequest, LazyLoadEvent.class);
		} catch (JsonProcessingException e) {
			log.error("Invalid JSON encountered in ZooSubentiteiten pageRequest!", e);
			lazyLoadEvent = new LazyLoadEvent();
			lazyLoadEvent.setFirst(0);
			lazyLoadEvent.setRows(NUMMBER_ROWS_PER_PAGE);
		}
		return subEntiteitService.getZooSubEntiteitenByEntiteitNummer(entiteitNummer, lazyLoadEvent);
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/subEntiteiten/distinct/soort")
	public List<String> getDistinctSoort(@PathVariable Long entiteitNummer) {
		return this.subEntiteitService.distinctSoort(entiteitNummer);
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/subEntiteiten/selected")
	public Set<Long> getSubEntiteitSelections(@PathVariable Long entiteitNummer) {
		return subEntiteitService.getBsnRsinsOfSelectedZooSubEntiteitenByEntiteitNummer(entiteitNummer);
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/convenantindicatie")
	public Convenantindicatie getConvenantindicatie(@PathVariable Long entiteitNummer) {
		var result = this.entiteitConvenantindicatieService.findByNummer(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No convenantindicatie found for entiteitNummer!");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/missing-entiteit-org-gegevens")
	public EntiteitKzbGegevens getMissingEntiteitOrgGegevens(@PathVariable Long entiteitNummer) {
		return entiteitKzbGegevensService.findEntiteitKzbGegevensByNummer(entiteitNummer);
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/kantoorteam-org-gegevens")
	public OrgKantoorTeam getOrgKantoorTeamGegevens(@PathVariable Long entiteitNummer) {
		return  orgGegevensService.getOrgKantoorTeamGegevens(entiteitNummer);
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/klantgroep-org-gegevens")
	public OrgKlantGroep getOrgKlantGroepGegevens(@PathVariable Long entiteitNummer) {
		return  orgGegevensService.getOrgKlantGroepGegevens(entiteitNummer);
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/behandelteam-org-gegevens")
	public List<Behandelteam> getOrgBehandelteam(@PathVariable Long entiteitNummer) {
		return  orgGegevensService.getOrgBehandelteam(entiteitNummer);
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR')")
	@GetMapping("/org-gegevens-url")
	public OrgUrls getOrggevegensUrl() {
		var toSend = new OrgUrls();
		toSend.setWijzigBehandelteamUrl(apiServiceApplicationProperties.getOrgWijzenBehandelteamUrl());
		return toSend;
	}

}
