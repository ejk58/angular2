package nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BehandelVoorstelRequestDto {

    public static final String VOORSTEL_ACTION_DELETE = "DEL";

    private String voorstelAction;
    private String voorstelType;
    private String behandelActiviteitCode;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String behandelVoorstelReference;
    private String subject;
    private String subjectType;
    private String userId;
}
