package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BatCodeOmschrijving {
    private String code;
    private String omschrijving;
}
