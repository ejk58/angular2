package nl.belastingdienst.iva.wd.kbs.domain;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Kenmerken {
	// TODO VW048 moet nog worden uitgebreid in een volgende sprint, aldus Jeroen Thoonen op 3 mei: "Voor de overige gegevens (rood) moeten wij wijzigingen doen om te kunnen leveren.
	//  Die zijn gepland in een van de volgende sprints en daar zijn we nog niet aan begonnen."
	private String aandachtsCategorie;
	private String vipIndicatie;
	private String zwaarteCategorie;
	private String goCategorie;
	private String convenantDeelname;
	// TODO: gegeven 'convenant deelname Individueel HT' ontbreekt hier nog?
	private BigDecimal wolbSom;
}
