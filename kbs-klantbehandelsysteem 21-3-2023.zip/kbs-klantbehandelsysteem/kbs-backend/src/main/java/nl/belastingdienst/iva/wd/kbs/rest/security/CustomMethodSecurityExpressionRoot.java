package nl.belastingdienst.iva.wd.kbs.rest.security;

import org.springframework.context.ApplicationContext;
import org.springframework.security.access.expression.SecurityExpressionRoot;
import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
import org.springframework.security.core.Authentication;

import nl.belastingdienst.iva.wd.kbs.gkv.service.EntiteitNummerAccessCheckService;

public class CustomMethodSecurityExpressionRoot extends SecurityExpressionRoot implements MethodSecurityExpressionOperations {

	private final ApplicationContext applicationContext;
	private Object filterObject;
	private Object returnObject;
	private Object target;

	public CustomMethodSecurityExpressionRoot(Authentication authentication, ApplicationContext applicationContext) {
		super(authentication);
		this.applicationContext = applicationContext;
	}

	public boolean hasPermissionForEntiteitNummer(Long entiteitNummer) {
		var entiteitNummerAccessCheckService = this.applicationContext.getBean(EntiteitNummerAccessCheckService.class);
		return entiteitNummerAccessCheckService.check(entiteitNummer);
	}

	@Override
	public void setFilterObject(Object filterObject) {
		this.filterObject = filterObject;
	}

	@Override
	public Object getFilterObject() {
		return filterObject;
	}

	@Override
	public void setReturnObject(Object returnObject) {
		this.returnObject = returnObject;
	}

	@Override
	public Object getReturnObject() {
		return returnObject;
	}

	@Override
	public Object getThis() {
		return target;
	}
}