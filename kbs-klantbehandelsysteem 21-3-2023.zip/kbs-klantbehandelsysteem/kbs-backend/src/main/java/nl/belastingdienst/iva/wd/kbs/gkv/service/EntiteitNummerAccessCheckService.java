/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: EntiteitNummerCheckService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 27-2-2023 14:42
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.gkv.service;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.exception.FailedToRetrieveSuccessfulResponseException;
import nl.belastingdienst.iva.wd.kbs.gkv.component.GkvApiClient;
import nl.belastingdienst.iva.wd.kbs.gkv.domain.AutorisatieRapport;
import nl.belastingdienst.iva.wd.kbs.gkv.domain.Toegang;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EntiteitNummerAccessCheckService {

	private final GkvApiClient gkvApiClient;

	public boolean check(Long entiteitnummer){
		var toegang = getAutorisatieRapportToegang(entiteitnummer);
		return toegang.isToegestaan();
	}

	public Toegang getAutorisatieRapportToegang(Long entiteitnummer) {
		var userName = SecurityContextHolder.getContext().getAuthentication().getName();

		ResponseEntity<AutorisatieRapport> autorisatieRapportResponseEntity = this.gkvApiClient.doRequest(
				HttpMethod.GET,
				"toegang?subjectidentificatie=" + entiteitnummer + "&subjecttype=ENTITEIT&userid=" + userName, null,
				AutorisatieRapport.class
		);

		var body = autorisatieRapportResponseEntity.getBody();
		if(body == null || body.getToegang() == null){
			throw new FailedToRetrieveSuccessfulResponseException("[GKV-api] Body or Toegang empty: {"
					+ "entiteitNummer: " + entiteitnummer
					+ "userName: " + userName
					+ "autorisatieRapportResponseEntity: " + autorisatieRapportResponseEntity
					+ "}");
		}

		return body.getToegang();
	}
}
