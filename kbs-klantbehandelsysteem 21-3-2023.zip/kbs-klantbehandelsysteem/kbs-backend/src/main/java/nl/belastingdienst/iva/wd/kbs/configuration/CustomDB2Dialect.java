package nl.belastingdienst.iva.wd.kbs.configuration;

import org.hibernate.dialect.DB2Dialect;
import org.hibernate.dialect.pagination.AbstractLimitHandler;
import org.hibernate.dialect.pagination.LimitHandler;
import org.hibernate.dialect.pagination.LimitHelper;
import org.hibernate.engine.spi.RowSelection;

/**
 * Used to implement support for pagination in Spring Data JPA connection to Db2 database. Referenced in application.properties
 * Source: https://bitbucket.belastingdienst.nl/projects/ESSENTIALS/repos/okr-iossdr-rest-api/browse/src/main/java/nl/belastingdienst/commons/dialect/CustomDB2Dialect.java
 * More info: https://stackoverflow.com/a/48083721 and https://stackoverflow.com/a/41375114
 */
@SuppressWarnings("unused")
public class CustomDB2Dialect extends DB2Dialect {

	/**
	 * Exact copy of {@link DB2Dialect#LIMIT_HANDLER}, with the following adjustment:
	 * Contents between parentheses of keyword 'over(...)' have been removed.
	 */
	private static final AbstractLimitHandler LIMIT_HANDLER = new AbstractLimitHandler() {
		@Override
		public String processSql(String sql, RowSelection selection) {
			if (LimitHelper.hasFirstRow( selection )) {
				//nest the main query in an outer select
				return "select * from ( select inner2_.*, rownumber() over() as rownumber_ from ( "
						+ sql + " fetch first " + getMaxOrLimit( selection ) + " rows only ) as inner2_ ) as inner1_ where rownumber_ > "
						+ selection.getFirstRow() + " order by rownumber_";
			}
			return sql + " fetch first " + getMaxOrLimit( selection ) +  " rows only";
		}

		@Override
		public boolean supportsLimit() {
			return true;
		}

		@Override
		public boolean useMaxForLimit() {
			return true;
		}

		@Override
		public boolean supportsVariableLimit() {
			return false;
		}
	};

	@Override
	public LimitHandler getLimitHandler() {
		return LIMIT_HANDLER;
	}

	@Override
	public String getQuerySequencesString() {
		return "SELECT * FROM SYSIBM.SYSSEQUENCES";
	}
}
