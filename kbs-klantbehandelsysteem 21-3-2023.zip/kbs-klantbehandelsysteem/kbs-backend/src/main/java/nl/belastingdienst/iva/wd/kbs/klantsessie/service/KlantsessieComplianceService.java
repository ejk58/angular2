package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieComplianceRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ChartLabel;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkChild;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkParent;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieComplianceDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.mappings.ChartLabelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class KlantsessieComplianceService {

    private final KlantsessieService klantsessieService;
    private final KlantSessieComplianceRepository klantSessieComplianceRepository;
    private final KenmerkRepository kenmerkRepository;
    private final ChartLabelMapper chartLabelMapper;

    public KlantsessieComplianceDto getPreviousKlantsessieCompliance(Long entiteitNummer, Integer middelId) {
        Optional<Klantsessie> lastklantsessie = klantsessieService.getPreviousKlantsessie(entiteitNummer);
        if (lastklantsessie.isEmpty()) {
            return null;
        }
        var klantsessieComplianceList = klantSessieComplianceRepository.findAllByKlantsessieIdAndMiddelId(lastklantsessie.get().getId(), middelId);
        if(klantsessieComplianceList.isEmpty()){
            return null;
        }

        var klantsessieComplianceDto = getKlantsessieComplianceDto(lastklantsessie.get().getId(), klantsessieComplianceList);
        klantsessieComplianceDto.setLastKlantSessieDate(lastklantsessie.get().getEinddatum().toLocalDate());

        return klantsessieComplianceDto;
    }

    public KlantsessieComplianceDto getCurrentKlantsessieCompliance(Long entiteitNummer, Integer middelId) {
        var currentKlantsessie = klantsessieService.getCurrentKlantsessie(entiteitNummer);
        var klantsessieComplianceList = klantSessieComplianceRepository.findAllByKlantsessieIdAndMiddelId(currentKlantsessie.getId(), middelId);
        return getKlantsessieComplianceDto(currentKlantsessie.getId(), klantsessieComplianceList);
    }

    public KlantsessieComplianceDto getKlantsessieComplianceDto(Long klantsessieId, List<KlantsessieCompliance> klantsessieComplianceList){
        var klantsessieComplianceDto = new KlantsessieComplianceDto();
        klantsessieComplianceDto.setKlantsessieId(klantsessieId);

        var kenmerkenKsCat = kenmerkRepository.findByGroepOrderById("KS_CAT");
        var parentsDtoList = createParentsDtoList(kenmerkenKsCat, klantsessieComplianceList);
        klantsessieComplianceDto.setKenmerkParents(parentsDtoList);
        return klantsessieComplianceDto;
    }

    public List<KlantsessieCompliance> findAllByKlantsessieId(Long klantSessieId){
        return klantSessieComplianceRepository.findAllByKlantsessieId(klantSessieId);
    }

    private List<KenmerkParent> createParentsDtoList(List<Kenmerk> kenmerkenKsCat, List<KlantsessieCompliance> klantsessieComplianceList) {

        List<Kenmerk> parents = kenmerkenKsCat.stream()
                                              .filter(k -> k.getKenmerkParentId() == null)
                                              .collect(Collectors.toList());

        var parentsDtoList = new ArrayList<KenmerkParent>();
        for (Kenmerk parent : parents) {
            var childrenDtoList = createChildrenDtolist(kenmerkenKsCat, klantsessieComplianceList, parent);
            parentsDtoList.add(new KenmerkParent(parent, childrenDtoList));
        }
        return parentsDtoList;
    }

    private ArrayList<KenmerkChild> createChildrenDtolist(
            List<Kenmerk> kenmerkenKsCat,
            List<KlantsessieCompliance> klantsessieComplianceList,
            Kenmerk parent
    ) {
        var childrenDtoList = new ArrayList<KenmerkChild>();
        List<Kenmerk> children = kenmerkenKsCat.stream()
                                               .filter(k -> k.getKenmerkParentId() != null)
                                               .filter(k -> k.getKenmerkParentId().equals(parent.getId())).collect(Collectors.toList());
        for (Kenmerk child : children) {
            Integer score = null;
            String toelichting = null;

            Optional<KlantsessieCompliance> correspondingKlantsessieCompliance = klantsessieComplianceList.stream()
                                                                                                          .filter(kc -> kc.getKenmerkId().equals(child.getId()))
                                                                                                          .findFirst();

            if(correspondingKlantsessieCompliance.isPresent()){
                score = correspondingKlantsessieCompliance.get().getScore();
                toelichting = correspondingKlantsessieCompliance.get().getToelichting();
            }

            childrenDtoList.add(new KenmerkChild(
                    child,
                    score,
                    toelichting
            ));
        }
        return childrenDtoList;
    }

    public List<ChartLabel> getChartLabels() {
        return chartLabelMapper.map(this.kenmerkRepository.findAllByGroepAndKenmerkParentIdIsNotNullOrderById("KS_CAT"));
    }
}
