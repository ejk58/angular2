package nl.belastingdienst.iva.wd.kbs.krr;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.krr.domain.BepaalCategorieGo;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/krr")
@Slf4j
public class KrrRestController {
    private final KrrService krrService;

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitnummer)")
    @GetMapping("/categorie-go/{entiteitnummer}")
    public BepaalCategorieGo[] getCategorieGo(@PathVariable Long entiteitnummer) {
        try {
            return krrService.getCategorieGo(entiteitnummer);
        } catch (Exception exception) {
            log.error(exception.getMessage(), exception);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Het ophalen van de GO categorie tot entiteitnummer is mislukt.");
        }
    }
}
