/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: BusinessRulesMiddelSpecifiekeKenmerkenService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 14-4-2022 10:15
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkSelection;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRulePolicies;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.DuplicatePolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.HigherLevelExistsCheckPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.LowerLevelExistsCheckPolicy;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BusinessRulesMiddelSpecifiekeKenmerkenService {

	private final EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;

	private static final BusinessRulePolicies<EntiteitMiddelKenmerkSelection, EntiteitMiddelKenmerk> BUSINESS_RULE_MIDDEL_SPECIFIEKE_KENMERKEN_POLICIES =
			new BusinessRulePolicies<EntiteitMiddelKenmerkSelection, EntiteitMiddelKenmerk>()
															.policy(new DuplicatePolicy())
															.policy(new LowerLevelExistsCheckPolicy())
															.policy(new HigherLevelExistsCheckPolicy())
			;

	/* Using optional of BusinessRuleError instead of an exception because exceptions are expensive
	 *  and the violation of business rules will not be an exception in the program flow
	 * */
	Optional<BusinessRuleError> validToBusinessRules(List<EntiteitMiddelKenmerk> collection, EntiteitMiddelKenmerkSelection selection) {

		for (var businessRulePolicy : BUSINESS_RULE_MIDDEL_SPECIFIEKE_KENMERKEN_POLICIES.getBusinessRulePolicyList()) {
			boolean b = collection.stream()
								  .anyMatch(businessRulePolicy.getPredicates(selection));
			if (b) {
				return Optional.of(
						new BusinessRuleError(businessRulePolicy.getErrorMessage(), businessRulePolicy.getPolicyClass()));
			}
		}

		return Optional.empty();
	}

	public Optional<BusinessRuleError> validate(Long entiteitNummer, EntiteitMiddelKenmerkSelection selectie) {
		List<EntiteitMiddelKenmerk> collectie = entiteitMiddelKenmerkRepository.findEntiteitMiddelKenmerkByEntiteitNummer(
				entiteitNummer);

		return this.validToBusinessRules(collectie, selectie);
	}

	public Optional<BusinessRuleError> validateExcludingCurrentId(Long entiteitNummer, EntiteitMiddelKenmerkSelection selectie, Long currentId) {
		List<EntiteitMiddelKenmerk> collectie = entiteitMiddelKenmerkRepository.findEntiteitMiddelKenmerkByEntiteitNummerAndIdIsNot(
																					   entiteitNummer, currentId);

		return this.validToBusinessRules(collectie, selectie);
	}

}
