package nl.belastingdienst.iva.wd.kbs.klantsessie.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieZooef;

public interface KlantsessieZooefRepository extends JpaRepository<KlantsessieZooef, KlantsessieZooef.PrimaryKey> {

    Optional<KlantsessieZooef> findByKlantsessieIdAndMiddelId(Long klantsessieId, Integer middelId);
    int countByKlantsessieIdAndMiddelIdAndObservatiesNotNull(Long klantsessieId, Integer middelId);
}
