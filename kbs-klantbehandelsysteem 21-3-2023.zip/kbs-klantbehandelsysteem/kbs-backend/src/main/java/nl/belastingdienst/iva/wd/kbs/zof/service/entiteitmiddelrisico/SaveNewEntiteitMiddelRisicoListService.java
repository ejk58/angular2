/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: SaveEntiteitMiddelRisicoListService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 18-7-2022 10:22
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.mappings.EntiteitMiddelRisicoMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SaveNewEntiteitMiddelRisicoListService {
	private final BusinessRulesMiddelSpecifiekeRisicosService businessRulesMiddelSpecifiekeRisicosService;
	private final EntiteitMiddelRisicoMapper entiteitMiddelRisicoMapper;
	private final SaveEntiteitMiddelRisicoService saveEntiteitMiddelRisicoService;

	public void save(List<EntiteitMiddelRisico> entiteitMiddelRisicoList, Long entiteitNummer, String loggingId){
		Optional<BusinessRuleError> validationError = this.businessRulesMiddelSpecifiekeRisicosService.validateList(
				entiteitNummer,
				entiteitMiddelRisicoMapper.mapToSelection(entiteitMiddelRisicoList)
				);
		if(validationError.isPresent()){
			throw new BusinessRuleException(
					"EntiteitMiddelRisicoList to be saved did not pass validation: "
							+ validationError.get().getPolicyClass().getSimpleName()
			);
		}
		entiteitMiddelRisicoList.forEach(emr -> {
			emr.setId(null);
			saveEntiteitMiddelRisicoService.save(emr, loggingId);
		});
	}
}
