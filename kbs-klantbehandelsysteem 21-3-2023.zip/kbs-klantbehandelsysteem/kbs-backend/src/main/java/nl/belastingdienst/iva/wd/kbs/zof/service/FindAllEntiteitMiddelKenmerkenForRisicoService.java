/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: FindAllEntiteitMiddelKenmerkenForRisicoService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 3-1-2023 09:54
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppelingEntiteitMiddelKenmerkIdDto;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FindAllEntiteitMiddelKenmerkenForRisicoService {
	private final KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;

	//find all possible kenmerken to be koppeld to risico and checks if there is an EntiteitMiddelKenmerk with that kenmerk
	//returns EntiteitMiddelKenmerk ID and MiddelKenmerk KENMERK
	public Map<Long, MiddelKenmerk> findAllEntiteitMiddelKenmerkenForRisico(Long entiteitNummer, Long risicoId){
		var kenmerkRisicosKoppelingen = kenmerkRisicoKoppelingRepository.findAllLinkableMiddelKenmerkByEntiteitnummerAndRisicoId(entiteitNummer, risicoId);

		return kenmerkRisicosKoppelingen.stream().collect(Collectors.toMap(
				KenmerkRisicosKoppelingEntiteitMiddelKenmerkIdDto::getEntiteitMiddelKenmerkId,
				KenmerkRisicosKoppelingEntiteitMiddelKenmerkIdDto::getMiddelKenmerk)
		);
	}
}
