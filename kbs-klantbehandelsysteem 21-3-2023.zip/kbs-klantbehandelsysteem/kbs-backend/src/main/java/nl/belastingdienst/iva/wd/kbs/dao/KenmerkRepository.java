package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface KenmerkRepository extends JpaRepository<Kenmerk, Integer> {
    List<Kenmerk> findByGroepOrderById(String groupname);

	Optional<Kenmerk> findByGroepInAndKenmerk(List<String> groep, String kenmerk);

    List<Kenmerk> findByGroepAndKenmerkParentIdIsNullOrderById(String groupname);

	List<Kenmerk> findAllByGroepAndKenmerkParentIdIsNotNullOrderById(String groep);

	int countAllByGroepAndKenmerkParentIdIsNotNullOrderById(String groep);

    List<Kenmerk> findAllByKenmerkParentId(Integer id);

    Optional<Kenmerk> findByGroepInAndId(List<String> groep, Integer id);

}
