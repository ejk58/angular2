package nl.belastingdienst.iva.wd.kbs.kta.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaSubEntiteit;

@Repository
public interface KtaSubEntiteitRepository extends ReadOnlyJpaRepository<KtaSubEntiteit, Long>, JpaSpecificationExecutor<KtaSubEntiteit> {
	Page<KtaSubEntiteit> findByEntiteitNummer(Pageable pageable, Long entiteitNummer);

	@Query("SELECT DISTINCT k.soortPersoon FROM KtaSubEntiteit k WHERE k.entiteitNummer = :entiteitNummer")
	List<String> findDistinctSoortByEntiteitNummer(Long entiteitNummer);
}
