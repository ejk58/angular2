package nl.belastingdienst.iva.wd.kbs.logging.service;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import nl.belastingdienst.iva.wd.kbs.logging.dao.Logging2Repository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
@RequiredArgsConstructor
public class RemoveOldLoggingInfoService {

    public static final int REMOVAL_AFTER_5_YEARS = 5;

    private final Logging2Repository logging2Repository;

    @Transactional
    @Scheduled(cron = "${logging.cleanup.cron.expression}")
    public void removeOldLogs() {
        var beforeCount = logging2Repository.count();
        var beforeDate = LocalDate.now()
                                     .minusYears(REMOVAL_AFTER_5_YEARS)
                                     .toString();
        logging2Repository.deleteOldLoggingWithoutMostRecent(beforeDate);
        var deletedCount = beforeCount - logging2Repository.count();
        log.info("Executed LOGGING cleanup at " + LocalDateTime.now() + " - total log records deleted: " + deletedCount);
    }
}
