/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: ComplianceAnnkomendeKlantsessieService.java
 *             Auteur: hubeh00
 *    Creatietijdstip: 15-9-2022 15:22
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieUitkomstRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ComplianceAankomendeKlantsessieDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ComplianceAankomendeKlantsessieProjection;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieUitkomst;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComplianceAankomendeKlantsessieService {

	private final KlantsessieService klantsessieService;
	private final Logging2Service logging2Service;

	private final KlantSessieUitkomstRepository klantsessieUitkomstRepository;

	public List<ComplianceAankomendeKlantsessieDto> getCurrentKlantsessie(Long entiteitNummer) {
		var result = new ArrayList<ComplianceAankomendeKlantsessieDto>();
		var currentKlantsessie = klantsessieService.getCurrentKlantsessie(entiteitNummer);
		var totaalList = klantsessieUitkomstRepository.getUitkomstenFor(currentKlantsessie.getId());
		var parents = totaalList.stream().filter(ku -> ku.getKenmerkParentId() == null).collect(Collectors.toList());

		for (ComplianceAankomendeKlantsessieProjection parent : parents) {
			var complianceAankomendeKlantsessieDto = new ComplianceAankomendeKlantsessieDto();
			complianceAankomendeKlantsessieDto.setKenmerk(parent.getKenmerk());

			var children = new ArrayList<ComplianceAankomendeKlantsessieDto.ComplianceUitkomst>();
			totaalList.stream().filter(uk -> uk.getKenmerkParentId() != null).filter(uk -> uk.getKenmerkParentId().equals(parent.getId())).forEach(child -> {
				var newChild = new ComplianceAankomendeKlantsessieDto.ComplianceUitkomst(child.getId(), child.getKenmerk(), child.getScore(), child.getStrategieGerichtOp(), child.getToelichting());
				children.add(newChild);
			});


			complianceAankomendeKlantsessieDto.setUitkomsten(children);
			result.add(complianceAankomendeKlantsessieDto);
		}
		return result;
	}

	public KlantsessieUitkomst updateResultaat(Long entiteitNummer, ComplianceAankomendeKlantsessieDto.ComplianceUitkomst resultaat, String loggingId) {
		var currentKlantsessie = klantsessieService.getCurrentKlantsessie(entiteitNummer);

		var klantsessieUitkomst = new KlantsessieUitkomst(currentKlantsessie.getId(), resultaat.getKenmerkId(), resultaat.getScore(),
				resultaat.getStrategie(), resultaat.getToelichting());
		this.logging2Service.save(loggingId, entiteitNummer, Logging2.Bewerking.UPDATE);
		return klantsessieUitkomstRepository.save(klantsessieUitkomst);
	}

}
