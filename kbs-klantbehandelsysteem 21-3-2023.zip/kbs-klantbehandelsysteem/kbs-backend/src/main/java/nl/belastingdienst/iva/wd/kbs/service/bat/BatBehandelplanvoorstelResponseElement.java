package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

import java.util.List;

@Data
public class BatBehandelplanvoorstelResponseElement {

    private String behandelVoorstelReference;
    private String createdBy;
    private String created;
    private String voorstelType;
    private Long subjectId;
    private Long entiteitNummer;
    private String subjectType;
    private String status;
    private String aantekening;
    private String zaakId;
    private String inOpdrachtDoor;
    private Long recVersion;
    private List<String> personen;
    private List<String> team;
    private List<String> toelichtingen;
}
