package nl.belastingdienst.iva.wd.kbs.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerkId;

@Repository
public interface EntiteitKenmerkRepository extends JpaRepository<EntiteitKenmerk, EntiteitKenmerkId> {
	@SuppressWarnings("java:S100")
	Optional<EntiteitKenmerk> findFirstByEntiteitKenmerkId_BsnRsinAndEntiteitKenmerkId_KenmerkType(Long bsnRsin, String kenmerkType);

	@SuppressWarnings("java:S100")
	List<EntiteitKenmerk> findAllByEntiteitKenmerkId_BsnRsinAndEntiteitKenmerkId_KenmerkType(Long bsnRsin, String kenmerkType);

	@SuppressWarnings("java:S100")
	Optional<EntiteitKenmerk> findByEntiteitKenmerkId_BsnRsinAndEntiteitKenmerkId_KenmerkId(Long bsnRsin, Integer kenmerkId);

	@SuppressWarnings("java:S100")
	int countAllByEntiteitKenmerkId_BsnRsinAndEntiteitKenmerkId_KenmerkType(Long bsnRsin, String kenmerkType);
}
