/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: ComplianceAankomendeKlantsessie.java
 *             Auteur: hubeh00
 *    Creatietijdstip: 15-9-2022 15:14
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ComplianceAankomendeKlantSessieToelichtingDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ComplianceAankomendeKlantsessieDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieUitkomst;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.ComplianceAankomendeKlantsessieService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.security.HtmlSanitizer;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/klantsessie/compliance-aankomende")
public class ComplianceAankomendeKlantsessieRestController {

	private final ComplianceAankomendeKlantsessieService complianceAankomendeKlantsessieService;
	private final KlantsessieService klantsessieService;

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}")
	public List<ComplianceAankomendeKlantsessieDto> getKlantsessie(@PathVariable Long entiteitNummer) {
		return complianceAankomendeKlantsessieService.getCurrentKlantsessie(entiteitNummer);
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/{entiteitNummer}")
	public KlantsessieUitkomst updateControlePlaatsgevonden(@PathVariable Long entiteitNummer,
			@RequestBody LoggingWrapper<ComplianceAankomendeKlantsessieDto.ComplianceUitkomst> uitkomstDto) {
		var uitkomst = uitkomstDto.getWrappedObject();
		if (uitkomst.getToelichting() != null) {
			uitkomst.setToelichting(HtmlSanitizer.sanitizeHtml(uitkomst.getToelichting()));
		}
		return complianceAankomendeKlantsessieService.updateResultaat(entiteitNummer, uitkomst, uitkomstDto.getLoggingId());
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/act-gebaseerd-gehouden-klantsessie/{entiteitNummer}")
	public Boolean getActGebaseerdGehoudenKlantsessie(@PathVariable Long entiteitNummer) {
		return klantsessieService.getCurrentKlantsessie(entiteitNummer).getActGebaseerdGehoudenKlantsessie();
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PutMapping("/act-gebaseerd-gehouden-klantsessie/{entiteitNummer}")
	public Boolean updateActGebaseerdGehoudenKlantsessie(@PathVariable Long entiteitNummer, @RequestBody LoggingWrapper<Void> loggingWrapper) {
		var ks = klantsessieService.getCurrentKlantsessie(entiteitNummer);
		var newUitkomst = !ks.getActGebaseerdGehoudenKlantsessie();
		ks.setActGebaseerdGehoudenKlantsessie(newUitkomst);
		klantsessieService.save(ks, loggingWrapper.getLoggingId());
		return ks.getActGebaseerdGehoudenKlantsessie();
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/toelichting-gehouden-klantsessie/{entiteitNummer}")
	public ComplianceAankomendeKlantSessieToelichtingDto getToelichtingGehoudenKlantsessie(@PathVariable Long entiteitNummer) {
		var ks = klantsessieService.getCurrentKlantsessie(entiteitNummer);
		String toelichting = ks.getToelichtingGehoudenKlantsessie();
		return new ComplianceAankomendeKlantSessieToelichtingDto(toelichting);
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/toelichting-gehouden-klantsessie/{entiteitNummer}")
	public ComplianceAankomendeKlantSessieToelichtingDto updateToelichtingGehoudenKlantsessie(@PathVariable Long entiteitNummer,
			@RequestBody LoggingWrapper<ComplianceAankomendeKlantSessieToelichtingDto> textDto) {
		var text = textDto.getWrappedObject();
		var ks = klantsessieService.getCurrentKlantsessie(entiteitNummer);
		if (text.getToelichting() != null) {
			ks.setToelichtingGehoudenKlantsessie(HtmlSanitizer.sanitizeHtml(text.getToelichting()));
		} else {
			ks.setToelichtingGehoudenKlantsessie(null);
		}
		klantsessieService.save(ks, textDto.getLoggingId());
		return new ComplianceAankomendeKlantSessieToelichtingDto(ks.getToelichtingGehoudenKlantsessie());
	}
}
