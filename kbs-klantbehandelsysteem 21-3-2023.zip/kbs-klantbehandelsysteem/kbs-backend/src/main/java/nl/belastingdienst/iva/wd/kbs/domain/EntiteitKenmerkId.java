package nl.belastingdienst.iva.wd.kbs.domain;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Getter
public class EntiteitKenmerkId implements Serializable {

    private static final long serialVersionUID = -9133814247530621390L;

    @Column(name="BSN_RSIN")
    private Long bsnRsin;

    @Column(name="KENMERK_TYPE")
    private String kenmerkType;

    @Column(name="KENMERK_ID")
    private Integer kenmerkId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EntiteitKenmerkId)) return false;
        EntiteitKenmerkId that = (EntiteitKenmerkId) o;
        return bsnRsin.equals(that.bsnRsin) && kenmerkType.equals(that.kenmerkType) && kenmerkId.equals(that.kenmerkId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(bsnRsin, kenmerkType, kenmerkId);
    }
}
