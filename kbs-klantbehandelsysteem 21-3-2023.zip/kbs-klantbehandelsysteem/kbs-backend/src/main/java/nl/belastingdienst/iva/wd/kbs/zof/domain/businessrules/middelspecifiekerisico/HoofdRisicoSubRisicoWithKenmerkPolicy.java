package nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico;

import java.util.Objects;
import java.util.function.Predicate;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRulePolicy;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;

public class HoofdRisicoSubRisicoWithKenmerkPolicy
		implements BusinessRulePolicy<BusinessRuleMiddelSpecifiekeRisicoDto, EntiteitMiddelRisico> {
	/* Example in db: Hoofdrisico-1 Subrisico-10 Kenmerk-20 */
	private static final Predicate<EntiteitMiddelRisico> DEFAULT_PREDICATE = (emr -> emr.getSubRisicoId() != null && emr.getEntiteitMiddelKenmerkId() != null);
	@Override
	public Predicate<EntiteitMiddelRisico> getPredicates(BusinessRuleMiddelSpecifiekeRisicoDto businessRuleDto) {
		Predicate<EntiteitMiddelRisico> entiteitMiddelRisicoPredicate;
		switch (businessRuleDto.getSelection().getSelectionMiddelSpecifiekEnum()) {
			case HRK:
			case HR:
				entiteitMiddelRisicoPredicate = emr -> emr.getHoofdRisicoId()
						.equals(businessRuleDto.getSelection().getHoofdRisicoId());
				break;
			case HRSR:
				entiteitMiddelRisicoPredicate = emr ->
						emr.getHoofdRisicoId().equals(businessRuleDto.getSelection().getHoofdRisicoId()) && Objects.equals(
								emr.getSubRisicoId(), businessRuleDto.getSelection().getSubRisicoId());
				break;
			case HRSRK:
				entiteitMiddelRisicoPredicate = emr ->
						emr.getHoofdRisicoId().equals(businessRuleDto.getSelection().getHoofdRisicoId()) && Objects.equals(
								emr.getSubRisicoId(), businessRuleDto.getSelection().getSubRisicoId()) && Objects.equals(
								emr.getEntiteitMiddelKenmerkId(), businessRuleDto.getSelection().getEntiteitMiddelKenmerkId());
				break;
			case UNKNOWN:
			default:
				throw new BusinessRuleException("unknown input");
		}
		return entiteitMiddelRisicoPredicate.and(DEFAULT_PREDICATE);
	}

	@Override
	public String getErrorMessage() {
		return "Het gekozen hoofdrisico, subrisico en/of kenmerk bestaat al.";
	}

	@Override
	public Class<? extends BusinessRulePolicy<BusinessRuleMiddelSpecifiekeRisicoDto, EntiteitMiddelRisico>> getPolicyClass() {
		return HoofdRisicoSubRisicoWithKenmerkPolicy.class;
	}
}
