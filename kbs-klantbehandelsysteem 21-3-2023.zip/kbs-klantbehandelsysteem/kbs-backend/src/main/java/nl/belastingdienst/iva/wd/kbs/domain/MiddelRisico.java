package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MIDDEL_RISICOS")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MiddelRisico {
    @Id
    @Column(name = "ID")
    private Long id;
    @Column(name = "MIDDEL_ID")
    private Integer middelId;
    @Column(name = "RISICO")
    private String risico;
    @Column(name = "PARENT_ID")
    private Long parentId;
    @Column(name = "RANK")
    private Long rank;
}
