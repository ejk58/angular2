package nl.belastingdienst.iva.wd.kbs.maintenancemessage.mappings;

import java.util.List;

import org.mapstruct.Mapper;

import nl.belastingdienst.iva.wd.kbs.maintenancemessage.domain.Message;
import nl.belastingdienst.iva.wd.kbs.maintenancemessage.domain.MessageDto;

@Mapper(componentModel = "spring")
public interface MessageMapper {

	MessageDto map(Message message);
	List<MessageDto> map(List<Message> message);
}
