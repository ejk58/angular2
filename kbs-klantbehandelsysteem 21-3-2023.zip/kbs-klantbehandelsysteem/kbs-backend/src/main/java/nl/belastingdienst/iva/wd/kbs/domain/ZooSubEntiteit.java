package nl.belastingdienst.iva.wd.kbs.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ZooSubEntiteit implements Comparable<ZooSubEntiteit> {
	private Long bsnRsin;
	private String soortPersoon;
	private String naam;
	private String plaats;
	private String beginDatum;
	private String eindDatum;
	private String brancheCode;
	private List<Kenmerk> aanvullingen;

	@Override
	public int compareTo(ZooSubEntiteit e) {
		return Long.compare(getBsnRsin(), e.getBsnRsin());
	}
}
