package nl.belastingdienst.iva.wd.kbs.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelnaamAfkortingRepository;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelnaamAfkorting;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class MiddelnaamAfkortingService {

    private final MiddelnaamAfkortingRepository middelnaamAfkortingRepository;

    public List<MiddelnaamAfkorting> getMiddelnaamAfkortingen() {
        return middelnaamAfkortingRepository.findAll();
    }
}
