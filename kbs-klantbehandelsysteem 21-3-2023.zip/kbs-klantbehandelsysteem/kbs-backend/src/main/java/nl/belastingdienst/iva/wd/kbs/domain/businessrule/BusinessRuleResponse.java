package nl.belastingdienst.iva.wd.kbs.domain.businessrule;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@EqualsAndHashCode
public class BusinessRuleResponse {
	String errorMessage;
}
