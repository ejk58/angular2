/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KtaDataSourceConfiguration.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 17-5-2021 11:20
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.configuration;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;

import nl.belastingdienst.iva.wd.kbs.kta.dao.KtaEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteit;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackageClasses = {
		// Specify the package(s) with the Repository interfaces that this data source will be assigned to
		KtaEntiteitRepository.class }, entityManagerFactoryRef = KtaDataSourceConfiguration.ENTITY_MANAGER_FACTORY, transactionManagerRef = KtaDataSourceConfiguration.TRANSACTION_MANAGER)
public class KtaDataSourceConfiguration {

	public static final String DATA_SOURCE_PROPERTIES = "ktaDataSourceProperties";
	public static final String DATA_SOURCE = "ktaDataSource";
	public static final String ENTITY_MANAGER_FACTORY = "ktaEntityManagerFactory";
	public static final String TRANSACTION_MANAGER = "ktaTransactionManager";
	public static final String DATA_SOURCE_PREFIX = "kta.datasource";

	@Bean(DATA_SOURCE_PROPERTIES)
	@ConfigurationProperties(DATA_SOURCE_PREFIX)
	public DataSourceProperties ktaDataSourceProperties() {
		var dataSourceProperties = new DataSourceProperties();
		//dataSourceProperties.setPassword(new EncryptionService().decrypt(dataSourceProperties.getPassword()));
		return dataSourceProperties;
	}

	@Bean(DATA_SOURCE)
	@ConfigurationProperties(DATA_SOURCE_PREFIX + ".configuration")
	public DataSource ktaDataSource(@Qualifier(DATA_SOURCE_PROPERTIES) DataSourceProperties ktaDataSourceProperties) {
		var dataSource = ktaDataSourceProperties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
		dataSource.setReadOnly(true);
		return dataSource;
	}

	/**
	 * Create a link between this data source and the KTA domain entities.
	 */
	@Bean(ENTITY_MANAGER_FACTORY)
	public LocalContainerEntityManagerFactoryBean ktaEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier(DATA_SOURCE) DataSource ktaDataSource) {
		return builder.dataSource(ktaDataSource).packages(KtaEntiteit.class).persistenceUnit("kta").build();
	}

	@Bean(TRANSACTION_MANAGER)
	public PlatformTransactionManager ktaTransactionManager(
			@Qualifier(ENTITY_MANAGER_FACTORY) EntityManagerFactory ktaEntityManagerFactory) {
		return new JpaTransactionManager(ktaEntityManagerFactory);
	}
}