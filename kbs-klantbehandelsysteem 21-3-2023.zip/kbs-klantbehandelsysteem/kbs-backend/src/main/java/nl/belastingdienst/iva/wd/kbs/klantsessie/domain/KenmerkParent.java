package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;

import java.util.List;

@Data
@AllArgsConstructor
public class KenmerkParent {
    private Kenmerk kenmerk;
    private List<KenmerkChild> kenmerkChildren;
}
