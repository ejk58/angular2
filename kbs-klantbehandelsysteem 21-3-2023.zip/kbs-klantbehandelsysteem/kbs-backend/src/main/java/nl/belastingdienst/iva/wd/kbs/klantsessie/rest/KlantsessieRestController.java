package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieZooef;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieAfrondenService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieStatusService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieZooefService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.rest.FakeResponseTime;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/klantsessie")
public class KlantsessieRestController {

	private final FakeResponseTime fakeResponseTime;
	private final KlantsessieService klantsessieService;
	private final KlantsessieStatusService klantsessieStatusService;
	private final KlantsessieZooefService klantsessieZooefService;
	private final KlantsessieAfrondenService klantsessieAfrondenService;

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}")
	public Klantsessie getCurrentKlantsessie(@PathVariable Long entiteitNummer) {
		var result = klantsessieService.getCurrentKlantsessie(entiteitNummer);
		fakeResponseTime.fakeResponseTime();
		return result;
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/previous")
	public Klantsessie getPreviousKlantsessie(@PathVariable Long entiteitNummer) {
		var result = klantsessieService.getPreviousKlantsessie(entiteitNummer);
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NO_CONTENT, "No previous klantsessie found for entiteitNummer");
		}
		fakeResponseTime.fakeResponseTime();
		return result.get();
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/{entiteitNummer}/controlePlaatsgevonden")
	public Klantsessie updateControlePlaatsgevonden(@PathVariable Long entiteitNummer,
													@RequestBody LoggingWrapper<Boolean> controlePlaatsgevondenBody) {
		var controlePlaatsgevonden = controlePlaatsgevondenBody.getWrappedObject();
		var ks = klantsessieService.updateControlePlaatsgevondenOfCurrentKlantsessie(entiteitNummer, controlePlaatsgevonden,
				controlePlaatsgevondenBody.getLoggingId());
		klantsessieStatusService.updateStatussenWhenControlePlaatsgevonden(entiteitNummer, controlePlaatsgevonden);
		return ks;
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/{entiteitNummer}/{middelId}/observatiesActueel")
	public KlantsessieZooef updateZooefVorigeObservatiesNogActueel(@PathVariable Long entiteitNummer, @PathVariable Integer middelId,
			@RequestBody LoggingWrapper<Boolean> observatiesActueel) {
		return klantsessieZooefService.updateObservatiesActueel(entiteitNummer, middelId, observatiesActueel.getWrappedObject(),
				observatiesActueel.getLoggingId());
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/{entiteitNummer}/{middelId}/nieuweInzichtenEnObservaties")
	public KlantsessieZooef updateZooefObservaties(@PathVariable Long entiteitNummer, @PathVariable Integer middelId,
											  @RequestBody LoggingWrapper<String> observatie){
		return klantsessieZooefService.updateNieuweInzichtenEnObservaties(entiteitNummer, middelId, observatie.getWrappedObject(),
				observatie.getLoggingId());
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/{middelId}/huidigeKlantsessieObservaties")
	public KlantsessieZooef getHuidigeKlantsessieObservaties(@PathVariable Long entiteitNummer, @PathVariable Integer middelId){
		return klantsessieZooefService.getHuidigeKlantsessieZooefObservatie(entiteitNummer, middelId);
	}

	@PreAuthorize("hasAuthority('AUG_KBS_BEHANDELAAR') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@PostMapping("/{entiteitNummer}/klantsessie-afronden")
	public Klantsessie updateKlantsessieAfgerond(@PathVariable Long entiteitNummer, @RequestBody LoggingWrapper<Void> loggingWrapper){
		return klantsessieAfrondenService.updateKlantsessieAfgerond(entiteitNummer, loggingWrapper.getLoggingId());
	}

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER') && hasPermissionForEntiteitNummer(#entiteitNummer)")
	@GetMapping("/{entiteitNummer}/klantsessie-afronden-enabled")
	public boolean checkKlantsessieAfrondenEnabled(@PathVariable Long entiteitNummer){
		return klantsessieAfrondenService.checkKlantsessieAfrondenEnabled(entiteitNummer);
	}
}
