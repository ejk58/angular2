/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: SecurityContextHolderConfig.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 15-2-2022 11:45
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.context.SecurityContextHolder;

@Configuration
public class SecurityContextHolderConfig {

	/**
	 * "By default the SecurityContextHolder uses a ThreadLocal to store these details, which means that the SecurityContext is
	 * always available to methods in the same thread, even if the SecurityContext is not explicitly passed around as an argument
	 * to those methods.
	 *
	 * We want to have threads spawned by the secure thread to also assume the same security identity [in order to support
	 * multi-threading using parallel streams etc.]. This is achieved by using SecurityContextHolder.MODE_INHERITABLETHREADLOCAL."
	 * (From the last paragraphs of: https://docs.spring.io/spring-security/reference/servlet/authentication/architecture.html#servlet-authentication-securitycontextholder )
	 *
	 * More info: https://docs.spring.io/spring-security/site/docs/current/api/org/springframework/security/core/context/SecurityContextHolder.html
	 */
	public SecurityContextHolderConfig() {
		SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);
	}
}
