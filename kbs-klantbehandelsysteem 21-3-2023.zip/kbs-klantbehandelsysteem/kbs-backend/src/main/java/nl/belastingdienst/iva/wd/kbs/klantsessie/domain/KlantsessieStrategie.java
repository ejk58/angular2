/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: KlantsessieZooef.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 13-5-2022 14:28
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "KLANTSESSIE_STRATEGIE")
@IdClass(KlantsessieStrategie.PrimaryKey.class)
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class KlantsessieStrategie {
	public static final String NON_PRIMARY_COLUMN_NAME_KORTETERMIJN = "korteTermijn";
	public static final String NON_PRIMARY_COLUMN_NAME_MIDDELLANGETERMIJN = "middellangeTermijn";

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PrimaryKey implements Serializable {
        private static final long serialVersionUID = -9033625430937003553L;

        private Long klantsessieId;
        private Integer middelId;
    }

    @Id
    @Column(name = "KLANTSESSIE_ID", nullable = false)
    private Long klantsessieId;
    @Id
    @Column(name = "MIDDEL_ID", nullable = false)
    private Integer middelId;
    @Column(name = "KORTE_TERMIJN")
    private String korteTermijn;
    @Column(name = "MIDDELLANGE_TERMIJN")
    private String middellangeTermijn;
}
