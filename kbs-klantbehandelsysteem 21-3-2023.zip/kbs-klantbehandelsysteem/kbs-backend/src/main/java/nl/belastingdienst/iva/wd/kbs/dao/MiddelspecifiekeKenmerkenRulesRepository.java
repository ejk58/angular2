package nl.belastingdienst.iva.wd.kbs.dao;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelspecifiekeKenmerkenCompositeId;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelspecifiekeKenmerkenRules;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MiddelspecifiekeKenmerkenRulesRepository extends JpaRepository<MiddelspecifiekeKenmerkenRules, MiddelspecifiekeKenmerkenCompositeId> {
    List<MiddelspecifiekeKenmerkenRules> findAllByCompositeId_MiddelId(Integer middelId);
}
