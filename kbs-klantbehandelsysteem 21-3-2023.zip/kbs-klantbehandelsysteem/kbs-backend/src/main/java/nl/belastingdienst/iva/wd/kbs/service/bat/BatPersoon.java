package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

import java.util.List;

@Data
public class BatPersoon {
    private List<BatActiviteit> activiteiten;
    private String afwijkendePeriodeEinde;
    private String afwijkendePeriodeStart;
    private Long subject;

}
