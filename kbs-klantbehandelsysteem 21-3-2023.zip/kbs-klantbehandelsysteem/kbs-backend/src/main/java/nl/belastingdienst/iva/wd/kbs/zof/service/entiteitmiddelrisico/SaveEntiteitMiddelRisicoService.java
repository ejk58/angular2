/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: SaveEntiteitMiddelRisico.java
 *             Auteur: duisr01
 *    Creatietijdstip: 8-6-2022 13:10
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelection;
import nl.belastingdienst.iva.wd.kbs.zof.event.ChangedHoofdOrSubrisicoEventPublisher;
import nl.belastingdienst.iva.wd.kbs.zof.util.FindLowestRisicoUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaveEntiteitMiddelRisicoService {

	private final BusinessRulesMiddelSpecifiekeRisicosService businessRulesMiddelSpecifiekeRisicosService;
	private final Logging2Service logging2Service;
	private final EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;
	private final ChangedHoofdOrSubrisicoEventPublisher changedHoofdOrSubrisicoEventPublisher;

	public void save(EntiteitMiddelRisico entiteitMiddelRisico, String loggingId) {
		var update = entiteitMiddelRisico.getId() != null;

		Optional<BusinessRuleError> validationError = validateEntiteitMiddelRisico(entiteitMiddelRisico);
		if(validationError.isPresent()){
			throw new BusinessRuleException(
					"EntiteitMiddelRisico to be saved did not pass validation: "
							+ validationError.get().getPolicyClass().getSimpleName()
							+ " " + entiteitMiddelRisico
			);
		}

		if(update) {
			changedRisico(entiteitMiddelRisico).ifPresent(this.changedHoofdOrSubrisicoEventPublisher::publish);
		}

		if (entiteitMiddelRisico.getRank() == null) {
			entiteitMiddelRisicoRepository.saveWithLowestRank(entiteitMiddelRisico);
		} else {
			entiteitMiddelRisicoRepository.save(entiteitMiddelRisico);
		}

		Logging2.Bewerking bewerking = update ? Logging2.Bewerking.UPDATE : Logging2.Bewerking.INSERT;
		this.logging2Service.save(loggingId, entiteitMiddelRisico.getEntiteitNummer(), bewerking);
	}

	private Optional<EntiteitMiddelRisico> changedRisico(EntiteitMiddelRisico entiteitMiddelRisico) {
		var beforeEntiteitMiddelRisicoOpt = this.entiteitMiddelRisicoRepository.findById(entiteitMiddelRisico.getId());
		if (beforeEntiteitMiddelRisicoOpt.isEmpty()) {
			return Optional.empty();
		}

		var entiteitMiddelRisicoBefore = beforeEntiteitMiddelRisicoOpt.get();

		var lowestRisicoIdNew = FindLowestRisicoUtil.findLowestRisicoId(entiteitMiddelRisico);
		var lowestRisicoIdBefore = FindLowestRisicoUtil.findLowestRisicoId(entiteitMiddelRisicoBefore);
		if(lowestRisicoIdNew.equals(lowestRisicoIdBefore)){
			return Optional.empty();
		}

		return Optional.of(entiteitMiddelRisicoBefore);
	}

	private Optional<BusinessRuleError> validateEntiteitMiddelRisico(EntiteitMiddelRisico entiteitMiddelRisico) {

		var middelSpecifiekeRisicoSelection = new MiddelSpecifiekeRisicoSelection(
				entiteitMiddelRisico.getHoofdRisicoId(),
				entiteitMiddelRisico.getSubRisicoId(),
				entiteitMiddelRisico.getEntiteitMiddelKenmerkId(),
				entiteitMiddelRisico.getKeyRisk(),
				entiteitMiddelRisico.getStatusId(),
				entiteitMiddelRisico.getBeheersing()
		);

		if(entiteitMiddelRisico.getId() != null){
			return businessRulesMiddelSpecifiekeRisicosService.validateWithCurrentId(entiteitMiddelRisico.getEntiteitNummer(), middelSpecifiekeRisicoSelection, entiteitMiddelRisico.getId());
		}

		return businessRulesMiddelSpecifiekeRisicosService.validate(entiteitMiddelRisico.getEntiteitNummer(), middelSpecifiekeRisicoSelection);
	}
}
