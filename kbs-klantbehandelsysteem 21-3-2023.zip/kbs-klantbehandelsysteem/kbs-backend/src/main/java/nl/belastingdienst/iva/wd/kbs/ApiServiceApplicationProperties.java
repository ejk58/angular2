package nl.belastingdienst.iva.wd.kbs;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:application.properties")
@RequiredArgsConstructor
public class ApiServiceApplicationProperties {

    private final Environment env;

    public String getOrgGegevensBaseUrl() { return env.getProperty("org.gegevens.base.url"); }

    public String getOrgWijzenBehandelteamUrl() { return env.getProperty("org.wijzen.behandelteam.gegevens.url"); }

    public String getOrgApiKeyKantoorteam() {
        return env.getProperty("org.api.key");
    }

    public String getBatExternalUrl() { return env.getProperty("bat.base.url.external"); }

    public String getBatApiKeyBehandelvoorstel() {
        return env.getProperty("bat.api.key");
    }

    public String getRegisterBehandelvoorstelUrl() {
        return env.getProperty("bat.register.behandelvoorstel.url"); }


    public String getGkvBaseUrl() {
        return env.getProperty("gkv.base.ur");
    }

}
