package nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RegisterBehandelvoorstelUrl {
    private final String url;
}
