package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

@Data
public class BatBoekenOnderzoekOverig extends  BatBoekenOnderzoek {

}
