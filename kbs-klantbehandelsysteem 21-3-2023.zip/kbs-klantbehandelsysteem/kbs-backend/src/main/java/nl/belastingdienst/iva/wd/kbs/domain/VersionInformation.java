package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.Data;

@Data
public class VersionInformation {
	private String application;
	private String version;
	private String buildNumber;
	private String buildTime;

	public String getVersionInformation() {
		return String.format("Appl: %s; version: %s; build: %s; time: %s", application, version, buildNumber, buildTime);
	}
}
