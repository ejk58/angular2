package nl.belastingdienst.iva.wd.kbs.klantsessie.dao;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ComplianceAankomendeKlantsessieProjection;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieUitkomst;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KlantSessieUitkomstRepository extends JpaRepository<KlantsessieUitkomst, KlantsessieUitkomst.PrimaryKey> {
    List<KlantsessieUitkomst> findAllByKlantsessieId(Long klantSessieId);
    int countAllByKlantsessieIdAndScoreNotNullAndStrategieGerichtOpNotNullAndToelichtingNotNull(Long klantsessieId);

    @Query(value = "Select k.ID as id, K.KENMERK as kenmerk, k.KENMERK_PARENT_ID as kenmerkParentId, ku.SCORE as score, ku.STRATEGIE_GERICHT_OP as strategieGerichtOp, ku.TOELICHTING as toelichting "
                    + "from KENMERK as k "
                    + "left JOIN KLANTSESSIE_UITKOMST as ku on k.ID=ku.KENMERK_ID and KLANTSESSIE_ID=?1 "
                    + "WHERE k.GROEP='KS_CAT'", nativeQuery = true)
    List<ComplianceAankomendeKlantsessieProjection> getUitkomstenFor(Long klantsessieId);

}
