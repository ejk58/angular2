package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

@Data
public class BatActiviteit {
    private String afwijkendePeriodeEinde;
    private String afwijkendePeriodeStart;
    private String middel;
    private Long subnummer;
}
