package nl.belastingdienst.iva.wd.kbs.service.bat;

import java.util.List;

import lombok.Data;

@Data
public class BatHeffing extends BatBehandelplanvoorstel {
    private String shortIdZaak;
    private String behandelActiviteit;
    private String startTijdvak;
    private String eindeTijdvak;
    private String aanpak;
    private String aanleiding;
    private String uitvoeringToezicht;
    private String gewensteDiepgang;
    private String bepalendVoorDiepgang;
    private List<String> prioriteitJaarplan;
    private Object inschattingBelang;
    private Object fiscaalRisico;
    private List<String> algemeneRisico;
    private List<String> weglekBalans;
    private String benodigdeCapaciteit;
    private Object functieniveau;
    private Object voorgesteldeBehandelaar;
    private String risicoGemeldDoorKlant;
    private String toelichting;
}
