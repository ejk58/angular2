/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GetRisicoListByMiddelkenmerkIdService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 13-7-2022 11:16
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class GetRisicoListByMiddelkenmerkIdService {
	private final KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;
	private final MiddelRisicoRepository middelRisicoRepository;

	public List<MiddelRisico> getByMiddelkenmerkId(Long middelkenmerkid){
		List<KenmerkRisicosKoppeling> allByMiddelKenmerkId = kenmerkRisicoKoppelingRepository.findAllByMiddelKenmerkId(
				middelkenmerkid);

		Set<Long> risicoIds = new HashSet<>();

		allByMiddelKenmerkId.forEach(emr -> {
					risicoIds.add(emr.getMiddelRisico().getId());
					risicoIds.add(emr.getMiddelRisico().getParentId());
				}
		);

		return middelRisicoRepository.findAllByIdIn(risicoIds);
	}

	public boolean hasLinkableRisicos(Long middelKenmerkId){
		return !kenmerkRisicoKoppelingRepository.findAllByMiddelKenmerkId(middelKenmerkId).isEmpty();
	}
}
