package nl.belastingdienst.iva.wd.kbs.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelnaamAfkorting;
import nl.belastingdienst.iva.wd.kbs.service.MiddelnaamAfkortingService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RequiredArgsConstructor
@RestController
@Slf4j
@RequestMapping("/api/middelnaamAfkorting")
public class MiddelnaamAfkortingController {

    private final MiddelnaamAfkortingService middelnaamAfkortingService;

    @PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
    @GetMapping("/list")
    public List<MiddelnaamAfkorting> getMiddelnaamAfkortingen() {
        return middelnaamAfkortingService.getMiddelnaamAfkortingen();
    }
}
