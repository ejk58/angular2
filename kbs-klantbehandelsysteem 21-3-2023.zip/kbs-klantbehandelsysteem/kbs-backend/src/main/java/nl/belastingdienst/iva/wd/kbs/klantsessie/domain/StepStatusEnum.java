package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

public enum StepStatusEnum {
	DISABLED, INITIAL, TOUCHED, COMPLETED, DONE
}
