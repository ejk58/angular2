/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: ValidateKenmerkLinkableService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 20-7-2022 14:09
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.zof.dao.ViewLowestKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelection;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.LinkableKenmerkPolicy;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ValidateRisicoLinkableToKenmerkService {
	private final KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;
	private final ViewLowestKenmerkRepository viewLowestKenmerkRepository;

	public Optional<BusinessRuleError> validate(MiddelSpecifiekeRisicoSelection middelSpecifiekeRisicoSelection){

		var lowestEntiteitMiddelKenmerk = this.viewLowestKenmerkRepository.findById(
				middelSpecifiekeRisicoSelection.getEntiteitMiddelKenmerkId()).orElseThrow();
		var middelKenmerk = lowestEntiteitMiddelKenmerk.getLowest();

		var lowestRisicoId = middelSpecifiekeRisicoSelection.getSubRisicoId() == null ?
				middelSpecifiekeRisicoSelection.getHoofdRisicoId() :
				middelSpecifiekeRisicoSelection.getSubRisicoId();

		boolean b = this.kenmerkRisicoKoppelingRepository.existsByMiddelKenmerk_IdAndMiddelRisico_Id(middelKenmerk.getId(), lowestRisicoId);
		if(!b){
			return Optional.of(new BusinessRuleError(new LinkableKenmerkPolicy().getErrorMessage(), LinkableKenmerkPolicy.class));
		}

		return Optional.empty();
	}
}
