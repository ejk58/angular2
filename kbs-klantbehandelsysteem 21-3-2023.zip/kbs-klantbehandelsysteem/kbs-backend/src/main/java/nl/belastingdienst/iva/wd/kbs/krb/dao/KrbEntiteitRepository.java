package nl.belastingdienst.iva.wd.kbs.krb.dao;

import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.krb.domain.KrbEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.dao.ReadOnlyJpaRepository;

@Repository
public interface KrbEntiteitRepository extends ReadOnlyJpaRepository<KrbEntiteit, Long> {
}
