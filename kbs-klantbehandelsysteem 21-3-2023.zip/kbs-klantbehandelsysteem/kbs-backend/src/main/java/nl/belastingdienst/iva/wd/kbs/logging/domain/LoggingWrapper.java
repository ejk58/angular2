/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: LoggingWrapper.java
 *             Auteur: duisr01
 *    Creatietijdstip: 27-9-2022 10:27
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.logging.domain;

import javax.validation.ValidationException;

import lombok.Data;

@Data
public class LoggingWrapper<T> {

	private String loggingId;
	private T wrappedObject;

	public LoggingWrapper(String loggingId, T wrappedObject) {
		setLoggingId(loggingId);
		this.wrappedObject = wrappedObject;
	}

	public void setLoggingId(String loggingId) {
		if(loggingId == null){
			throw new ValidationException();
		}
		this.loggingId = loggingId;
	}
}
