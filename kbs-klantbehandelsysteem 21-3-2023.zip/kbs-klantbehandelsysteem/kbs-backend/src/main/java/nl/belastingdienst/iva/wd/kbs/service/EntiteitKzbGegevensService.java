/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: EntiteitConvenantindicatieService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 30-8-2021 10:29
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.service;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKzbGegevens;
import nl.belastingdienst.iva.wd.kbs.kta.dao.KzbAlgemeneGegevensEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.mappings.KzbAlgemeneGegevensEntiteitMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class EntiteitKzbGegevensService {
    private final KzbAlgemeneGegevensEntiteitRepository kzbAlgemeneGegevensEntiteitRepository;
    private final KzbAlgemeneGegevensEntiteitMapper kzbAlgemeneGegevensEntiteitMapper;

    public EntiteitKzbGegevens findEntiteitKzbGegevensByNummer(long entiteitnummer){
        return  this.kzbAlgemeneGegevensEntiteitMapper.mapToEntiteitKzbGegevens(this.kzbAlgemeneGegevensEntiteitRepository.findById(entiteitnummer).orElse(null));
    }


}
