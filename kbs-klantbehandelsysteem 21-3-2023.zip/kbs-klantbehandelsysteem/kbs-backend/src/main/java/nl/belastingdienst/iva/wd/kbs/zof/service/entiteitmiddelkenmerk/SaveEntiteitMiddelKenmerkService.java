/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: SaveEntiteitMiddelKenmerk.java
 *             Auteur: duisr01
 *    Creatietijdstip: 8-6-2022 10:36
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk;

import java.util.Optional;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkSelection;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.UnlinkEntiteitMiddelRisicoService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SaveEntiteitMiddelKenmerkService {

	private final UnlinkEntiteitMiddelRisicoService unlinkEntiteitMiddelRisicoService;
	private final EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;
	private final Logging2Service logging2Service;
	private final BusinessRulesMiddelSpecifiekeKenmerkenService businessRulesMiddelSpecifiekeKenmerkenService;

	public void save(EntiteitMiddelKenmerk entiteitMiddelKenmerk, String loggingid) {
		var update = entiteitMiddelKenmerk.getId() != null;

		Optional<BusinessRuleError> validationError = validate(entiteitMiddelKenmerk);
		if(validationError.isPresent()){
			throw new BusinessRuleException(
					"EntiteitMiddelKenmerk to be saved did not pass validation: "
							+ validationError.get().getPolicyClass().getSimpleName()
							+ " " + entiteitMiddelKenmerk
			);
		}

		if(update){
			this.unlinkEntiteitMiddelRisicoService.unlinkRisicosForEntiteitMiddelKenmerkId(entiteitMiddelKenmerk.getId());
		}

		entiteitMiddelKenmerk = entiteitMiddelKenmerk.getRank() == null ?
				entiteitMiddelKenmerkRepository.saveWithLowestRank(entiteitMiddelKenmerk) :
				entiteitMiddelKenmerkRepository.save(entiteitMiddelKenmerk);

		Logging2.Bewerking bewerking = update ? Logging2.Bewerking.UPDATE : Logging2.Bewerking.INSERT;

		logging2Service.save(loggingid, entiteitMiddelKenmerk.getEntiteitNummer(), bewerking);
	}

	private Optional<BusinessRuleError> validate(EntiteitMiddelKenmerk entiteitMiddelKenmerk) {
		var entiteitMiddelKenmerkSelection = EntiteitMiddelKenmerkSelection.fromEntiteitMiddelKenmerk(entiteitMiddelKenmerk);

		if(entiteitMiddelKenmerk.getId() != null){
			return businessRulesMiddelSpecifiekeKenmerkenService.validateExcludingCurrentId(entiteitMiddelKenmerk.getEntiteitNummer(), entiteitMiddelKenmerkSelection, entiteitMiddelKenmerk.getId());
		}

		return businessRulesMiddelSpecifiekeKenmerkenService.validate(entiteitMiddelKenmerk.getEntiteitNummer(), entiteitMiddelKenmerkSelection);
	}
}
