package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkType;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieUitkomstRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkChild;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkParent;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieComplianceDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieResultaatDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieResultaatEntryDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieUitkomst;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitKenmerkService;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class KlantsessieResultaatService {
    private final KlantsessieService klantsessieService;
    private final KlantsessieComplianceService klantsessieComplianceService;
    private final KlantSessieUitkomstRepository klantSessieUitkomstRepository;
    private final KenmerkRepository kenmerkRepository;
    private final EntiteitKenmerkService entiteitKenmerkService;
    private static final String MIDDEL_KS_CAT = "KS_CAT" ;

    public KlantsessieResultaatDto getKlantsessieResultaat(Long entiteitNummer) {
        var klantsessieResultaat = new KlantsessieResultaatDto();
        klantsessieResultaat.setKenmerken(getKenmerkenParentChildHierarchy());

        List<KlantsessieResultaatEntryDto> uitkomstForPreviousKlantsessies = getKlantsessieUitkomstForPreviousKlantsessies(entiteitNummer);
        klantsessieResultaat.setPreviousEntries(uitkomstForPreviousKlantsessies);

        List<KlantsessieResultaatEntryDto> currentCompliances = getCurrentKlantsessieCompliancesPerMiddel(entiteitNummer);
        klantsessieResultaat.setCurrentEntries(currentCompliances);

        return klantsessieResultaat;
    }

    private List<KenmerkParent> getKenmerkenParentChildHierarchy() {
        List<Kenmerk> allKenmerken = kenmerkRepository.findByGroepOrderById(MIDDEL_KS_CAT);
        return allKenmerken.stream()
                .filter(kenmerk -> kenmerk.getKenmerkParentId() == null)
                .map(parentKenmerk -> new KenmerkParent(
                        parentKenmerk,
                        allKenmerken.stream()
                                .filter(kenmerk -> parentKenmerk.getId().equals(kenmerk.getKenmerkParentId()))
                                .map(childKenmerk -> new KenmerkChild(childKenmerk, null, null))
                                .collect(Collectors.toList())))
                .collect(Collectors.toList());
    }

    private List<KlantsessieCompliance> createDefaultKlantsessieCompliance(Long klantsessieId, Integer middelId) {
       return  kenmerkRepository.findByGroepOrderById(MIDDEL_KS_CAT)
                .stream()
                .filter(kenmerk -> kenmerk.getKenmerkParentId() != null)
                .map(childKenmerk -> {
                    var defaultKlantsessieCompliance = new KlantsessieCompliance();
                    defaultKlantsessieCompliance.setKlantsessieId(klantsessieId);
                    defaultKlantsessieCompliance.setMiddelId(middelId);
                    defaultKlantsessieCompliance.setKenmerkId(childKenmerk.getId());
                    return defaultKlantsessieCompliance;
                })
                .collect(Collectors.toList());
    }

    private List<KlantsessieResultaatEntryDto> getCurrentKlantsessieCompliancesPerMiddel(Long entiteitNummer) {
        var currentKlantsessie = klantsessieService.getCurrentKlantsessie(entiteitNummer);
        var currentComplianceAllMiddels = klantsessieComplianceService
                .findAllByKlantsessieId(currentKlantsessie.getId());

        List<Integer> middelIdsToshowInTable = entiteitKenmerkService.getSelectedMiddelen(entiteitNummer)
                .stream().map(EntiteitKenmerk::getKenmerkId).collect(Collectors.toList());
        // Only show Controle (141) if ControlePlaatsgevonden == true.
        if (Boolean.TRUE.equals(currentKlantsessie.getControlePlaatsgevonden())) {
            middelIdsToshowInTable.add(Klantsessie.CONTROLE_MIDDEL_ID);
        }
        // Always show Klantsessie Coordinator (142)
        middelIdsToshowInTable.add(Klantsessie.KLANTCOORDINATOR_MIDDEL_ID);

        List<Integer> middelIdsWithCompliances = currentComplianceAllMiddels.stream()
                .map(KlantsessieCompliance::getMiddelId).collect(Collectors.toList());

        List<Integer> middelIdsWithoutCompliances = middelIdsToshowInTable.stream()
                .filter(Predicate.not(middelIdsWithCompliances::contains)).collect(Collectors.toList());

        middelIdsWithoutCompliances
                .forEach( middelId ->
                        currentComplianceAllMiddels.addAll(createDefaultKlantsessieCompliance(currentKlantsessie.getId(), middelId)));

        Map<Integer, List<KlantsessieCompliance>> perMiddel = currentComplianceAllMiddels.stream()
                .filter(klantsessieCompliance -> middelIdsToshowInTable.contains(klantsessieCompliance.getMiddelId()))
                .collect(Collectors.groupingBy(KlantsessieCompliance::getMiddelId));

        return perMiddel.entrySet().stream()
                .map(entry -> {
                    Kenmerk middel = getKlantsessieMiddelById(entry.getKey());
                    var klantsessieComplianceDto = klantsessieComplianceService
                            .getKlantsessieComplianceDto(currentKlantsessie.getId(),
                                    entry.getValue());

                    return mapToKlantsessieResultaatEntryDto(middel, klantsessieComplianceDto);
                }).sorted(Comparator.comparing(klantsessieResultaatEntryDto -> klantsessieResultaatEntryDto.getMiddel().getId()))
                .collect(Collectors.toList());
    }

    private KlantsessieResultaatEntryDto mapToKlantsessieResultaatEntryDto(Kenmerk middel, KlantsessieComplianceDto klantsessieComplianceDto) {
        var entriesCurrentKlantsessie = new KlantsessieResultaatEntryDto();
        entriesCurrentKlantsessie.setKlantsessieId(klantsessieComplianceDto.getKlantsessieId());
        entriesCurrentKlantsessie.setMiddel(middel);
        Map<Integer, KenmerkChild> resultaatByKenmerkId = klantsessieComplianceDto.getKenmerkParents().stream()
                .flatMap(kenmerkParent -> kenmerkParent.getKenmerkChildren().stream())
                .collect(Collectors.toMap(
                        kenmerkChild -> kenmerkChild.getKenmerk().getId(),
                        kenmerkChild -> kenmerkChild));
        entriesCurrentKlantsessie.setResultaatByKenmerkId(resultaatByKenmerkId);
        return entriesCurrentKlantsessie;
    }

    private List<KlantsessieResultaatEntryDto> getKlantsessieUitkomstForPreviousKlantsessies(Long entiteitNummer) {
        return klantsessieService.getLastThreePreviousKlantsessie(entiteitNummer).stream()
                .map(this::getKlantsessieUitkomstDto)
                .sorted(Comparator.comparing(KlantsessieResultaatEntryDto::getLastKlantSessieDate))
                .collect(Collectors.toList());
    }

    private KlantsessieResultaatEntryDto getKlantsessieUitkomstDto(Klantsessie klantsessie) {
        var klantsessieResultaatEntryDto = new KlantsessieResultaatEntryDto();
        klantsessieResultaatEntryDto.setKlantsessieId(klantsessie.getId());
        klantsessieResultaatEntryDto.setLastKlantSessieDate(klantsessie.getEinddatum());
        klantsessieResultaatEntryDto.setResultaatByKenmerkId(getResultaatByKenmerkId(klantsessie));
        return klantsessieResultaatEntryDto;
    }

    private Map<Integer,KenmerkChild> getResultaatByKenmerkId(Klantsessie klantsessie) {
        var kenmerkenKsCat = kenmerkRepository.findByGroepOrderById(MIDDEL_KS_CAT);
        List<KlantsessieUitkomst> klantsessieUitkomstList = klantSessieUitkomstRepository.findAllByKlantsessieId(klantsessie.getId());
        var childrenDtoList = new HashMap<Integer,KenmerkChild>();
        List<Kenmerk> children = kenmerkenKsCat.stream()
                .filter(k -> k.getKenmerkParentId() != null)
                .collect(Collectors.toList());
        for (Kenmerk child : children) {
            Optional<KlantsessieUitkomst> correspondingKlantsessieUitkomst = klantsessieUitkomstList.stream()
                    .filter(kc -> Objects.equals(kc.getKenmerkId(), child.getId()))
                    .findFirst();
            Integer score = correspondingKlantsessieUitkomst.map(KlantsessieUitkomst::getScore).orElse(null);
            String toelichting = correspondingKlantsessieUitkomst.map(KlantsessieUitkomst::getToelichting).orElse(null);
            childrenDtoList.put(child.getId(), new KenmerkChild(child, score, toelichting));
        }
        return childrenDtoList;
    }

    private Kenmerk getKlantsessieMiddelById(Integer middelId) {
        var groepen = List.of(KenmerkType.MID.getValue(), KenmerkType.KS_MID.getValue());
        return kenmerkRepository.findByGroepInAndId(groepen, middelId).orElse(null);
    }
}
