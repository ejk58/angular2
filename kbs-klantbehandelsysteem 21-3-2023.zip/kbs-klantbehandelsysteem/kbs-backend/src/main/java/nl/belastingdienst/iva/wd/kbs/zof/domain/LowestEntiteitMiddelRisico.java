/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: LowestEntiteitMiddelRisico.java
 *             Auteur: duisr01
 *    Creatietijdstip: 10-8-2022 08:51
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.zof.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "V_LOWESTRISICO")
@Immutable
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LowestEntiteitMiddelRisico {
	@Id
	@Column(name = "ID")
	private Long id;
	@Column(name = "ENTITEITNUMMER")
	private Long entiteitNummer;
	//https://thorben-janssen.com/hibernates-notfound/
	@NotFound(action= NotFoundAction.IGNORE)
	@OneToOne
	@JoinColumn(name = "ENTITEIT_MIDDEL_KENMERK_ID", referencedColumnName = "ID", insertable = false, updatable = false)
	private LowestEntiteitMiddelKenmerk lowestEntiteitMiddelKenmerk;
	@Column(name = "HOOFDRISICO_ID")
	private Long hoofdRisicoId;
	@Column(name = "SUBRISICO_ID")
	private Long subRisicoId;
	@Column(name = "KEY_RISK")
	private Short keyRisk;
	@Column(name = "STATUS_ID")
	private Long statusId;
	@Column(name = "RANK")
	private Long rank;
	@Column(name = "BEHEERSING")
	private Long beheersing;
	@OneToOne
	@JoinColumn(name = "LOWEST", referencedColumnName = "ID", insertable = false, updatable = false)
	private MiddelRisico lowest;
}
