package nl.belastingdienst.iva.wd.kbs.mappings;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.domain.BehandelActiviteit;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatBehandelplanvoorstel;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatBehandelvoorstelResponse;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatBoekenOnderzoek;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatTeam;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.Activiteit;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class BehandelActiviteitMapper {

	public static final String ONBEKEND = "Onbekend";

	public static List<BehandelActiviteit> map(BatBehandelvoorstelResponse behandelVoorstellen, Map<String,
			String> behandelActiviteitCodes, Map<String, String> statusCodes, String entiteitNaam, Activiteit batRegisterbehandelActiviteitcodes) {
		List<String> ids = new ArrayList<>();
		List<BehandelActiviteit> activiteiten = new LinkedList<>();
		activiteiten.addAll(map(behandelVoorstellen.getBehandelopdrachtenMDR(), behandelActiviteitCodes, statusCodes, entiteitNaam, ids, batRegisterbehandelActiviteitcodes));
		activiteiten.addAll(map(behandelVoorstellen.getBehandelplanVoorstellen(), behandelActiviteitCodes, statusCodes, entiteitNaam, ids, batRegisterbehandelActiviteitcodes));
		activiteiten.addAll(map(behandelVoorstellen.getBoekenOnderzoeken(), behandelActiviteitCodes, statusCodes, entiteitNaam, ids, batRegisterbehandelActiviteitcodes));
		activiteiten.addAll(map(behandelVoorstellen.getBoekenOnderzoekenInvordering(), behandelActiviteitCodes, statusCodes, entiteitNaam, ids, batRegisterbehandelActiviteitcodes));
		activiteiten.addAll(map(behandelVoorstellen.getBoekenOnderzoekenOverig(), behandelActiviteitCodes, statusCodes, entiteitNaam, ids, batRegisterbehandelActiviteitcodes));
		activiteiten.addAll(map(behandelVoorstellen.getBoekenOnderzoekenOverigGo(), behandelActiviteitCodes, statusCodes, entiteitNaam, ids, batRegisterbehandelActiviteitcodes));
		activiteiten.addAll(map(behandelVoorstellen.getBoekenOnderzoekenOverigMkb(), behandelActiviteitCodes, statusCodes, entiteitNaam, ids, batRegisterbehandelActiviteitcodes));
		activiteiten.addAll(map(behandelVoorstellen.getHeffingen(), behandelActiviteitCodes, statusCodes, entiteitNaam, ids, batRegisterbehandelActiviteitcodes));
		return activiteiten;
	}

	private static List<BehandelActiviteit> map(List<? extends BatBehandelplanvoorstel> behandelOpdrachten, Map<String,
			String> behandelActiviteitCodes, Map<String, String> statusCodes, String entiteitNaam, List<String> ids,
			Activiteit batRegisterbehandelActiviteitcodes) {
		List<BehandelActiviteit> baList = new ArrayList<>();
		for (BatBehandelplanvoorstel bv: behandelOpdrachten) {
			if (ids.contains(bv.getBehandelVoorstelReference())) continue;
			baList.add(map(bv, behandelActiviteitCodes, statusCodes, entiteitNaam, batRegisterbehandelActiviteitcodes));
			ids.add(bv.getBehandelVoorstelReference());
		}
		return baList;
	}

	private static BehandelActiviteit map(BatBehandelplanvoorstel bbv, Map<String, String> behandelActiviteitCodes,
										   Map<String, String> statusCodes, String entiteitNaam,
											Activiteit batRegisterbehandelActiviteitcodes) {

		String behandelActiviteitcode = null;
		for ( Map.Entry<String, Activiteit.ActiviteitenVanVoorstel> entry : batRegisterbehandelActiviteitcodes.getActiviteitenPerVoorstelCode().entrySet()) {
			for(Map.Entry<String, String> codeObj:  entry.getValue().getActiviteiten().entrySet()) {
				if (bbv.getVoorstelType().equals(entry.getKey())) {
					behandelActiviteitcode = codeObj.getKey();
				}
			}
		}
		var ba = new BehandelActiviteit();
		ba.setId(bbv.getBehandelVoorstelReference());
		ba.setBsnRsin(bbv.getSubjectId());
		ba.setNaam(entiteitNaam);
		ba.setBehandelactiviteit(behandelActiviteitCodes.get(bbv.getVoorstelType()));
		ba.setVoorstelType(bbv.getVoorstelType());
		ba.setSubjectType(bbv.getSubjectType());
		ba.setBehandelActiviteitCode(behandelActiviteitcode);
		List<String> behandelaars = CollectionUtils.isEmpty(bbv.getTeam()) ? Collections.singletonList(ONBEKEND) :
				bbv.getTeam().stream().map(BatTeam::getUserid).collect(Collectors.toList());
		ba.setBehandelaars(behandelaars);
		ba.setStatus(statusCodes.get(bbv.getStatus()));
		ba.setPersonen(bbv.getPersonen() != null && !bbv.getPersonen().isEmpty() ? bbv.getPersonen() : null);
		ba.setMiddel(ONBEKEND);

		if (bbv instanceof BatBoekenOnderzoek) {
			map(ba, (BatBoekenOnderzoek) bbv);
		}
		return ba;
	}

	private static void map(BehandelActiviteit ba, BatBoekenOnderzoek bbo) {
		if (CollectionUtils.isNotEmpty(bbo.getMiddelen())) {
			ba.setMiddel(String.join(",", bbo.getMiddelen()));
		}
	}
}
