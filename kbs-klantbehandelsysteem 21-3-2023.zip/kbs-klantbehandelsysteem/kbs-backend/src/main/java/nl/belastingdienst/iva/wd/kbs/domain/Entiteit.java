package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.Data;

import java.sql.Date;

@Data
public class Entiteit {

	private String naam;
	private Long nummer;
	private String adres; // TODO Geen idee waar dit gegeven vandaan moet komen.
	private String klantpakket; // TODO Geen idee of dit gegeven overeenkomt met BasisGegevens.klantGroep. KBS prototype.pptx bevat ook geen voorbeelddata.

	// Basisgegevens
	private Long brancheCode;
	private String brancheNaam;
	private String bestuurlijkVerband; // TODO Moet uit ORG komen
	private String kantoorCode;
	private String kantoorNaam;
	private String teamCode;
	private String teamNaam;
	private String klantCoordinator; // TODO Moet uit ORG komen
	private String klantGroep; // TODO Moet uit ORG komen

	// extra fields from view VW154_KZB_ALGEMENE_GEGEVENS_ENTITEIT
	private String convenantIndicatie;
	private Date formatiedat;
	private Date ontbinddat;

}
