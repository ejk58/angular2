/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: FeedbackController.java
 *             Auteur: schop13
 *    Creatietijdstip: 15-4-2021 11:31
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.rest.feedback;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.domain.Feedback;
import nl.belastingdienst.iva.wd.kbs.rest.security.JsonWebToken;
import nl.belastingdienst.iva.wd.kbs.service.FeedbackService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.ConstraintViolationException;
import java.time.LocalDateTime;

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/feedback")
public class FeedbackRestController {

	private final ObjectMapper mapper;
	private final FeedbackService feedbackService;

	@PreAuthorize("hasAnyAuthority('AUG_KBS_BEHANDELAAR','AUG_KBS_RAADPLEGER')")
	@PostMapping
	public ResponseEntity<Feedback> addFeedback(@RequestHeader(name = JsonWebToken.HEADER_AUTHORIZATION) String token,
			@RequestBody Feedback feedback) {
		JsonWebToken jsonWebToken = JsonWebToken.fromTokenString(mapper, token);

		//note: if feedback formulier is reset to using name and email, this can be used to get username
		//feedback.setUserId(jsonWebToken.getSub());

		var roles = String.join(" ", jsonWebToken.getAuthorities());
		feedback.setRollen(roles);
		feedback.setCreated(LocalDateTime.now());
		feedback.setVersionInfo(feedback.getVersionInformation().getVersionInformation());
		var result = feedbackService.saveFeedback(feedback);
		return ResponseEntity.ok(result);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	ResponseEntity<String> handleConstraintViolationException(ConstraintViolationException e) {
		var message = "Validation failed!";
		log.error(message, e);
		return ResponseEntity.badRequest().body(message);
	}
}
