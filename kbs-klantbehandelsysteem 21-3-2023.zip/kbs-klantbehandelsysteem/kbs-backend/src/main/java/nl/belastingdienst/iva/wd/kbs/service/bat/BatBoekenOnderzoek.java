package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

import java.util.List;

@Data
public class BatBoekenOnderzoek extends BatBehandelplanvoorstel{

    private String afhandeldatum;
    private String behandelActiviteit;
    private Long behandeltijd;
    private Long betrokkenOmzet;
    private String controleLeider;
    private List<String> fiscaalMaterieel;
    private String functieniveau;
    private Long inschattingBelang;
    private List<String> middelen;
    private String periodeEinde;
    private String periodeStart;
    private String prioriteit;
    private Long projectCode;
    private String toelichting;
    private List<String> weglekBalans;
}
