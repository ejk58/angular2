/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: PerProcesDto.java
 *             Auteur: hubeh00
 *    Creatietijdstip: 5-7-2022 10:42
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
@NotNull
public class PerProcesDto {
	@NotNull(message= "Klantsessie cannot be null.")
	@Min(value = 1, message = "Klant sessie should be more than 0.")
	private Long klantsessieId;
	@Min(value = 1, message= "MiddelId should be more than 0.")
	@NotNull(message= "MiddelId cannot be null.")
	private Integer middelId;

	@Min(value = 0, message = "The value should be greater than -1.")
	private Integer vooroverleg;

	@Min(value = 0, message = "The value should be greater than -1.")
	private Integer heffing;

	@Min(value = 0, message = "The value should be greater than -1.")
	private Integer bezwaren;
}
