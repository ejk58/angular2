package nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.kbs.ApiServiceApplicationProperties;
import nl.belastingdienst.iva.wd.kbs.service.RestTemplateClient;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatGegevensService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class BatRegisterBehandelvoorstelService {
    private final ApiServiceApplicationProperties apiServiceApplicationProperties;
    private final RestTemplateClient restTemplateClient;
    private final BatGegevensService batGegevensService;

    static final List<String> KBS_BEHANDLEVOORSTEL_TYPES = List.of(KBSBehandelVoorstelType.BPV01.getType(), KBSBehandelVoorstelType.HEF01.getType());

    public List<VoorstelType> getBehandelvoorstelTypes() {
        var uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/lookuptabel?tabel=OMSCHRIJVING_VOORSTELTYPE");
        var responseEntity = restTemplateClient.doRequest(
                HttpMethod.GET, uri, null,
                new ParameterizedTypeReference<List<VoorstelType>>() {
                },
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel(), false);
        return responseEntity.getBody() != null ? responseEntity.getBody() : List.of();
    }

    private List<VoorstelType> filterKbsBehandelvoorstelTypes() {
        return getBehandelvoorstelTypes().stream()
                .filter(v -> KBS_BEHANDLEVOORSTEL_TYPES.contains(v.getCode()))
                .collect(Collectors.toList());
    }

    public Activiteit getBehandelActiviteitcodes() {
        var uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/behandelvoorstel/behandelactiviteitcodes");
        var responseEntity = restTemplateClient.doRequest(
                HttpMethod.GET, uri, null, Activiteit.class,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel(), false);
        return responseEntity.getBody() != null ? responseEntity.getBody() : null;
    }

    public List<BehandelvoorstelOption> getBehandelvoorstelOptions() {
        List<BehandelvoorstelOption> behandelvoorstelOptions = new ArrayList<>();
        List<VoorstelType> voorstelTypes = filterKbsBehandelvoorstelTypes();
        var behandelActiviteitCodes = getBehandelActiviteitcodes();

        for (VoorstelType voorstelType : voorstelTypes) {
            var behandelvoorstelOption = new BehandelvoorstelOption();
            behandelvoorstelOption.setVoorstelType(voorstelType);
            var activiteitenVanVoorstel =
                    behandelActiviteitCodes.getActiviteitenPerVoorstelCode().get(voorstelType.getCode());
            if (activiteitenVanVoorstel == null) {
                continue;
            }
            behandelvoorstelOption.setActiviteitCodes(activiteitenVanVoorstel.getActiviteiten());
            behandelvoorstelOptions.add(behandelvoorstelOption);
        }
        return behandelvoorstelOptions;
    }

    public BehandelVoorstelResponse createBehandelVoorstel(BehandelVoorstelRequestDto request) {
        var authentication = SecurityContextHolder.getContext().getAuthentication();
        String loggedInUser = authentication.getName();
        if (StringUtils.isBlank(loggedInUser))
            throw new NullPointerException("Aanmaken van een behandelactiviteit is mislukt: gebruiker is niet ingelogd!");

        request.setUserId(loggedInUser);

        if (KBSBehandelVoorstelType.BPV01.getType().equals(request.getVoorstelType())) {
            String id = batGegevensService.createBehandelVoorstel(
                    Long.valueOf(request.getSubject()),
                    request.getVoorstelType());

            return new BehandelVoorstelResponse(id, null);
        } else {
            //Business rule: The rest of the voorsteltypes are to be created outside kbs application using the received token from Bat api.  HEF01 + Enige ander voorsteltype
            return new BehandelVoorstelResponse(null, getToken(request));
        }
    }

    public String getToken(BehandelVoorstelRequestDto body) {
        var uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/start");
        ResponseEntity<CreateBehandelVoorstelToken> responseEntity = restTemplateClient.doRequest(
                HttpMethod.POST, uri, body, CreateBehandelVoorstelToken.class,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel(), false);

        return Objects.requireNonNull(responseEntity.getBody()).getToken();
    }

}
