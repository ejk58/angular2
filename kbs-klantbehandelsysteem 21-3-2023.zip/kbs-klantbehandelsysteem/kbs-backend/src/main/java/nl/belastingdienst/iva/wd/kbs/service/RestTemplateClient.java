package nl.belastingdienst.iva.wd.kbs.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@Component
@RequiredArgsConstructor
@Slf4j
public class RestTemplateClient {

    private final RestTemplate restTemplate;

    public <T, U> ResponseEntity<U> doRequest(HttpMethod httpMethod, URI uri, T body,
                                              Class<U> responseClass, String xAPIKey, boolean needsLoggedUser) {

        ParameterizedTypeReference<U> responseType = ParameterizedTypeReference.forType(responseClass);
        return doRequest(httpMethod, uri, body, responseType, xAPIKey, needsLoggedUser);
    }

    public <T, U> ResponseEntity<U> doRequest(HttpMethod httpMethod, URI uri, T body,
                                              ParameterizedTypeReference<U> responseType, String xAPIKey, boolean needsLoggedUser) {
        HttpHeaders headers = getHeaders(xAPIKey, needsLoggedUser);
        return getResponseEntity(httpMethod, uri, body, responseType, headers);
    }

    public <T, U> ResponseEntity<U> doKrrRequest(HttpMethod httpMethod, URI uri, T body,
                                                 Class<U> responseClass, String xAPIKey) {
        HttpHeaders headers = getKrrHeaders(xAPIKey);
        ParameterizedTypeReference<U> responseType = ParameterizedTypeReference.forType(responseClass);
        return getResponseEntity(httpMethod, uri, body, responseType, headers);
    }

    private  <T, U> ResponseEntity<U> getResponseEntity(HttpMethod httpMethod, URI uri, T body,
                                              ParameterizedTypeReference<U> responseType, HttpHeaders headers) {
        HttpEntity<T> request = new HttpEntity<>(body, headers);
        ResponseEntity<U> response;
        try {
            response = restTemplate.exchange(uri, httpMethod, request, responseType);

        } catch (RestClientException e) {
            log.error("RestClientException exception:", e);
            throw e;
        }
        return response;
    }

    private HttpHeaders getHeaders(String xAPIKey, boolean needsLoggedUser) {
        var headers = new HttpHeaders();
        headers.set("X-APIKEY", xAPIKey);
        headers.set("Accept", "application/json");
        if (needsLoggedUser) {
            var authentication = SecurityContextHolder.getContext().getAuthentication();
            String loggedInUser = authentication.getName();
            if (StringUtils.isBlank(loggedInUser))
                throw new NullPointerException("Aanmaken van een behandelactiviteit is mislukt: gebruiker is niet ingelogd!");
            headers.set("X-USERID", loggedInUser);
        }
        return headers;
    }

    private HttpHeaders getKrrHeaders(String xAPIKey) {
        var headers = new HttpHeaders();
        headers.set("X-API-KEY", xAPIKey);
        headers.set("Accept", "application/json");
        return headers;
    }

}
