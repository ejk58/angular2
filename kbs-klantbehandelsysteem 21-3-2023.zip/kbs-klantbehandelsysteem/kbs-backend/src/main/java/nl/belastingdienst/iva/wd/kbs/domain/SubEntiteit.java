package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@IdClass(SubEntiteit.PrimaryKey.class)
@Table(name = "SUB_ENTITEITEN")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubEntiteit {
	@Id
	@Column(name = "ENTITEIT_BSN")
	private Long entiteitNummer;
	@Id
	@Column(name = "SUB_ENTITEIT_BSN")
	private Long subEntiteitBsnRsin;
		@Data
	public static class PrimaryKey implements Serializable {

	private static final long serialVersionUID = 3826512463034005824L;

		private Long entiteitNummer;
		private Long subEntiteitBsnRsin;
	}
}
