package nl.belastingdienst.iva.wd.kbs.klantsessie.mappings;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ChartLabel;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;

@Mapper(componentModel = "spring")
public interface ChartLabelMapper {

	@Mapping(target = "label", source = "kenmerk")
	ChartLabel map(Kenmerk kenmerk);

	List<ChartLabel> map(List<Kenmerk> kenmerk);
}
