package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import lombok.RequiredArgsConstructor;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkType;
import nl.belastingdienst.iva.wd.kbs.service.KenmerkService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GetRisicoDropdownOptionsService {

    private final KenmerkService kenmerkService;

    public List<Kenmerk> getZoFMiddelRisicoStatussen() {
        return kenmerkService.findKenmerkenByType(KenmerkType.RSTAT);
    }

    public List<Kenmerk> getZoFMiddelRisicoBeheersingOptions() {
        return kenmerkService.findKenmerkenByType(KenmerkType.RBEH);

    }
}
