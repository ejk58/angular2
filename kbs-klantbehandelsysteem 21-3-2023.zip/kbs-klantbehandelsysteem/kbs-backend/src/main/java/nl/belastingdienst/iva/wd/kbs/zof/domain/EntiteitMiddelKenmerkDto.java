package nl.belastingdienst.iva.wd.kbs.zof.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EntiteitMiddelKenmerkDto {
    private Long id;
    private Long hoofdKenmerkId;
    private Long subKenmerk1Id;
    private Long subKenmerk2Id;
    private Long subKenmerk3Id;
    private Long rank;
    private Long entiteitNummer;
    private Boolean hasLinkableRisicos;
}
