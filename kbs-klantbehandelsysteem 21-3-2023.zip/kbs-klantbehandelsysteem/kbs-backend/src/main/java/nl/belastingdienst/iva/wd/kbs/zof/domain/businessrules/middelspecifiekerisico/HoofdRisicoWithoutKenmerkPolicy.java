package nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico;

import java.util.function.Predicate;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRulePolicy;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;

public class HoofdRisicoWithoutKenmerkPolicy implements BusinessRulePolicy<BusinessRuleMiddelSpecifiekeRisicoDto, EntiteitMiddelRisico> {
    /* Example in db: Hoofdrisico-1 Subrisico-null Kenmerk-null */
    private static final Predicate<EntiteitMiddelRisico> DEFAULT_PREDICATE = (emr -> emr.getSubRisicoId() == null && emr.getEntiteitMiddelKenmerkId() == null);
    @Override
    public Predicate<EntiteitMiddelRisico> getPredicates(BusinessRuleMiddelSpecifiekeRisicoDto businessRuleDto) {
        Predicate<EntiteitMiddelRisico> entiteitMiddelRisicoPredicate;
        switch (businessRuleDto.getSelection().getSelectionMiddelSpecifiekEnum()) {
            case HRSRK:
            case HRSR:
            case HRK:
            case HR:
               entiteitMiddelRisicoPredicate = emr -> emr.getHoofdRisicoId()
                        .equals(businessRuleDto.getSelection().getHoofdRisicoId());
                break;
            case UNKNOWN:
            default:
                throw new BusinessRuleException("unknown input");
        }
        return entiteitMiddelRisicoPredicate.and(DEFAULT_PREDICATE);
    }

    @Override
    public String getErrorMessage() {
        return "Dit hoofdrisico wordt al gebruikt.";
    }

    @Override
    public Class<? extends BusinessRulePolicy<BusinessRuleMiddelSpecifiekeRisicoDto, EntiteitMiddelRisico>> getPolicyClass() {
        return HoofdRisicoWithoutKenmerkPolicy.class;
    }
}

