package nl.belastingdienst.iva.wd.kbs.configuration;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;

import nl.belastingdienst.iva.wd.kbs.krb.dao.KrbEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.krb.domain.KrbEntiteit;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackageClasses = {
		// Specify the package(s) with the Repository interfaces that this data source will be assigned to
		KrbEntiteitRepository.class }, entityManagerFactoryRef = KrbDataSourceConfiguration.ENTITY_MANAGER_FACTORY, transactionManagerRef = KrbDataSourceConfiguration.TRANSACTION_MANAGER)
public class KrbDataSourceConfiguration {

	public static final String DATA_SOURCE_PROPERTIES = "krbDataSourceProperties";
	public static final String DATA_SOURCE = "krbDataSource";
	public static final String ENTITY_MANAGER_FACTORY = "krbEntityManagerFactory";
	public static final String TRANSACTION_MANAGER = "krbTransactionManager";
	public static final String DATA_SOURCE_PREFIX = "krb.datasource";

	@Bean(DATA_SOURCE_PROPERTIES)
	@ConfigurationProperties(DATA_SOURCE_PREFIX)
	public DataSourceProperties krbDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean(DATA_SOURCE)
	@ConfigurationProperties(DATA_SOURCE_PREFIX + ".configuration")
	public DataSource krbDataSource(@Qualifier(DATA_SOURCE_PROPERTIES) DataSourceProperties krbDataSourceProperties) {
		var dataSource = krbDataSourceProperties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
		dataSource.setReadOnly(true);
		return dataSource;
	}

	/**
	 * Create a link between this data source and the KRB domain entities.
	 */
	@Bean(ENTITY_MANAGER_FACTORY)
	public LocalContainerEntityManagerFactoryBean krbEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier(DATA_SOURCE) DataSource krbDataSource) {
		return builder.dataSource(krbDataSource).packages(KrbEntiteit.class).persistenceUnit("krb").build();
	}

	@Bean(TRANSACTION_MANAGER)
	public PlatformTransactionManager krbTransactionManager(
			@Qualifier(ENTITY_MANAGER_FACTORY) EntityManagerFactory krbEntityManagerFactory) {
		return new JpaTransactionManager(krbEntityManagerFactory);
	}
}