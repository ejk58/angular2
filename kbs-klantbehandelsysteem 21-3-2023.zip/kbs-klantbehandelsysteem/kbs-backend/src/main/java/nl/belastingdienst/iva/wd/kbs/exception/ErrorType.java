package nl.belastingdienst.iva.wd.kbs.exception;


@Deprecated
public enum ErrorType {
	JSON_FORMAT("/errors/json_format", "The provided json has a wrong format"), ARGUMENT_FORMAT("/errors/argument_format", "A parameter has the wrong format"), SYSTEM_CONFIG("/errors/system_config", "The system has a wrong configuration"), FORBIDDEN("/errors/forbidden", "This operation is not allowed"), UPSTREAM_UNAVAILABLE("/errors/upstream_unavailable", "No connection possible to another system"), UPSTREAM_ERROR("/errors/upstream_error", "Another system gave an error"), NOT_FOUND("/errors/not_found", "The requested resource is not found"), NOT_POSSIBLE("/errors/not_possible", "The requested action is not possible"), VALIDATION("/errors/validation", "The validation for this request failed"), UNAUTHORIZED("/errors/unauthorized", "You are not authorized for this operation"), BAD_TOKEN("/errors/bad_token", "The provided token is not valid"), UNCLASSIFIED("/errors/unclassified", "Unclassified error"), NOT_ANTICIPATED("/errors/not_anticipated", "Unexpected error");

	private final String type;
	private final String title;

	ErrorType(String type, String title) {
		this.title = title;
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public String getTitle() {
		return title;
	}
}
