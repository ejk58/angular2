package nl.belastingdienst.iva.wd.kbs.service;

import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.CustomSpecification;
import nl.belastingdienst.iva.wd.kbs.dao.SearchCriteria;
import nl.belastingdienst.iva.wd.kbs.dao.SearchCriteria.Operator;
import nl.belastingdienst.iva.wd.kbs.dao.SubEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteit;
import nl.belastingdienst.iva.wd.kbs.domain.ZooSubEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.dao.KtaEntiteitBrancheRepository;
import nl.belastingdienst.iva.wd.kbs.kta.dao.KtaSubEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaSubEntiteit;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.mappings.SubEntiteitMapper;
import nl.belastingdienst.iva.wd.kbs.tablefiltering.domain.LazyLoadEvent;
import nl.belastingdienst.iva.wd.kbs.tablefiltering.utils.FilterSpecificationCreator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class SubEntiteitService {

    /** Identical to kbs-frontend/src/app/entiteit/entiteit-zicht-op-organisatie/zoo-aardvanorganisatie/subentiteiten-table/subentiteiten-table.component.ts */
    public static final int MAX_SELECTED_SUBENTITEITEN_PER_ENTITEIT = 100;
    public static final Sort SORT_BY_BSN_RSIN = Sort.by(KtaSubEntiteit.ATTR_BSN_RSIN);

    private final SubEntiteitRepository subEntiteitRepository;
    private final KtaSubEntiteitRepository ktaSubEntiteitRepository;
    private final KtaEntiteitBrancheRepository ktaEntiteitBrancheRepository;
    private final SubEntiteitMapper subEntiteitMapper;
    private final Logging2Service loggingService;

    public void saveSubEntiteiten(Long entiteitNummer, SortedSet<Long> selectedSubentiteitBsnRsins, String loggingId) {
        List<SubEntiteit> newSelection = selectedSubentiteitBsnRsins.stream()
                .limit(MAX_SELECTED_SUBENTITEITEN_PER_ENTITEIT)
                .map(bsnRsin -> new SubEntiteit(entiteitNummer, bsnRsin))
                .collect(Collectors.toList());

        loggingService.save(loggingId, entiteitNummer, Logging2.Bewerking.UPDATE);
        subEntiteitRepository.deleteAllByEntiteitNummer(entiteitNummer);
        subEntiteitRepository.saveAll(newSelection);
    }

    public Set<Long> getBsnRsinsOfSelectedZooSubEntiteitenByEntiteitNummer(Long entiteitNummer) {
        return subEntiteitRepository.findAllSubEntiteitBsnRsinByEntiteitNummerOrderBySubEntiteitBsnRsin(entiteitNummer);
    }

    public Page<ZooSubEntiteit> getZooSubEntiteitenByEntiteitNummer(Long entiteitNummer, LazyLoadEvent lazyLoadEvent) {
        return determinePage(entiteitNummer, lazyLoadEvent)
                .map(subEntiteitMapper::map)
                .map(subEntiteit -> {
                    var brancheOpt = ktaEntiteitBrancheRepository.findByBsnRsin(subEntiteit.getBsnRsin());
                    if (brancheOpt.isPresent()) {
                        subEntiteit = subEntiteitMapper.update(brancheOpt.get(), subEntiteit);
                    }
                    return subEntiteit;
                });
    }

    private Page<KtaSubEntiteit> determinePage(Long entiteitNummer, LazyLoadEvent lazyLoadEvent) {
        if (lazyLoadEvent.isUnpaged()) {
            // User is in selection mode and requests list of all known subentiteiten, no filtering required:
            return ktaSubEntiteitRepository.findByEntiteitNummer(Pageable.unpaged(), entiteitNummer);
        }
        Pageable pageable = PageRequest.of(lazyLoadEvent.getFirst(), lazyLoadEvent.getRows(), SORT_BY_BSN_RSIN);

        Specification<KtaSubEntiteit> fullSpec = createSpecificationforEntiteitNummer(entiteitNummer);
        fullSpec = addBsnRsinFilterIfUserSelectionIsPresent(fullSpec, entiteitNummer);

        fullSpec = FilterSpecificationCreator.createSpecification(fullSpec, lazyLoadEvent.getFilters(), KtaSubEntiteit.class);
        return ktaSubEntiteitRepository.findAll(fullSpec, pageable);
    }

    private Specification<KtaSubEntiteit> createSpecificationforEntiteitNummer(Long entiteitNummer) {
        Specification<KtaSubEntiteit> entiteitNummerEquals = new CustomSpecification<>(
                new SearchCriteria(KtaSubEntiteit.ATTR_ENTITEIT_NUMMER, Operator.EQUALS, entiteitNummer));
        return Specification.where(entiteitNummerEquals);
    }

    private Specification<KtaSubEntiteit> addBsnRsinFilterIfUserSelectionIsPresent(Specification<KtaSubEntiteit> fullSpec,
            Long entiteitNummer) {
        SortedSet<Long> selectedSubentiteitenBsnRsins = subEntiteitRepository.findAllSubEntiteitBsnRsinByEntiteitNummerOrderBySubEntiteitBsnRsin(
                entiteitNummer);
        if (!selectedSubentiteitenBsnRsins.isEmpty()) {
            // A custom selection of subentiteiten is present, filter accordingly:
            Specification<KtaSubEntiteit> bsnRsinIn = new CustomSpecification<>(
                    new SearchCriteria(KtaSubEntiteit.ATTR_BSN_RSIN, Operator.IN, selectedSubentiteitenBsnRsins));
            fullSpec = fullSpec.and(bsnRsinIn);
        }
        return fullSpec;
    }

    public List<String> distinctSoort(Long entiteitNummer) {
        return ktaSubEntiteitRepository.findDistinctSoortByEntiteitNummer(entiteitNummer);
    }
}
