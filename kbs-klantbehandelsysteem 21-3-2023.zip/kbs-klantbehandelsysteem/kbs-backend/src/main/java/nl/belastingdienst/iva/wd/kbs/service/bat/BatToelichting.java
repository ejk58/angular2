package nl.belastingdienst.iva.wd.kbs.service.bat;

import lombok.Data;

@Data
public class BatToelichting {
    private String fieldName;
    private String toelichting;
}
