package nl.belastingdienst.iva.wd.kbs.kta.dao;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteitBranche;

@Repository
public interface KtaEntiteitBrancheRepository extends ReadOnlyJpaRepository<KtaEntiteitBranche, Long> {
    Optional<KtaEntiteitBranche> findByBsnRsin(Long bsnRsin);
}
