package nl.belastingdienst.iva.wd.kbs.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.ZooOmvangRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Behandelvoorstel;
import nl.belastingdienst.iva.wd.kbs.domain.Entiteit;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerken;
import nl.belastingdienst.iva.wd.kbs.domain.Opdracht;
import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteitTestData;
import nl.belastingdienst.iva.wd.kbs.domain.ZooOmvang;
import nl.belastingdienst.iva.wd.kbs.krb.dao.KrbEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.kta.dao.KtaEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.krb.domain.KrbEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KtaEntiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.OrgEntiteit;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.mappings.EntiteitMapper;
import nl.belastingdienst.iva.wd.kbs.mappings.KenmerkenMapper;
import nl.belastingdienst.iva.wd.kbs.mappings.ZooOmvangMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class EntiteitService {

    private final KtaEntiteitRepository ktaRepo;
    private final KrbEntiteitRepository krbRepo;
    private final ZooOmvangRepository zooOmvangRepo;
    private final EntiteitMapper mapper;
    private final ZooOmvangMapper omvangMapper;
    private final KenmerkenMapper kenmerkenMapper;
    private final Logging2Service logging2Service;

    public List<Entiteit> search(KtaEntiteit querySearchParams) {
        ExampleMatcher matchCaseInsensitiveStringsContaining = ExampleMatcher.matchingAll().withIgnoreCase()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        Example<KtaEntiteit> queryByExample = Example.of(querySearchParams, matchCaseInsensitiveStringsContaining);
        List<KtaEntiteit> searchResults = ktaRepo.findAll(queryByExample);
        return mapper.map(searchResults);
    }

    public Optional<Entiteit> findByNummer(Long entiteitNummer) {
        Optional<KtaEntiteit> ktaResult = ktaRepo.findById(entiteitNummer);
        if (ktaResult.isEmpty()) {
            return Optional.empty();
        }
        Entiteit e = mapper.map(ktaResult.get());

        Optional<OrgEntiteit> orgResult = Optional.of(new OrgEntiteit());
        // TODO Implement when ORG data structure has been defined by solution architects:
        //   Optional<OrgEntiteit> orgResult = orgRepo.findById(entiteitNummer);
        if (orgResult.isPresent()) {
            e = mapper.update(orgResult.get(), e);
        }

        // TODO IVAKBS-32: Replace dummy data with the real deal.
        e.setAdres("!!! Juweelstraat 12, 5643FG  Eindhoven");
        e.setKlantpakket("!!! Onbekend");

        return Optional.of(e);
    }

    public Optional<Kenmerken> findAlgemeneGegevensKenmerkenByNummer(Long entiteitNummer) {
        // TODO IVAKBS-32: Replace dummy data with the real deal.
        var dummy = Kenmerken.builder().aandachtsCategorie("Volgt later in een aparte feature").vipIndicatie("Volgt later in een aparte feature").zwaarteCategorie("Volgt later in een aparte feature")
                .goCategorie("Volgt later in een aparte feature").convenantDeelname("Volgt later in een aparte feature").build(); // skip wolbSom
        Optional<Kenmerken> kenmerkenResult = Optional.of(dummy);
        // TODO Implement when Kenmerken data structure has been defined by solution architects:
        //   Optional<?> kenmerkenResult = kenmerkenRepo.findById(entiteitNummer);
        if (kenmerkenResult.isEmpty()) {
            return Optional.empty();
        }
        Kenmerken k = kenmerkenResult.get(); // mapper.map(kenmerkenResult.get());

        // Retrieve WOLB-som from KRB
        Optional<KrbEntiteit> krbOpt = krbRepo.findById(entiteitNummer);
        if (krbOpt.isPresent()) {
            k = kenmerkenMapper.update(k, krbOpt.get());
        }

        return Optional.of(k);
    }

    public Optional<List<SubEntiteitTestData>> findSamenstellingByNummer(Long entiteitNummer) {
        return Optional.of(Arrays.asList(new SubEntiteitTestData[]{
                        SubEntiteitTestData.builder().nummer("!!! 46547868").subject("!!! Jansen").type("!!! Natuurlijk persoon").build(),
                        SubEntiteitTestData.builder().nummer("!!! 565654").subject("!!! Philips estate").type("!!! Niet-natuurlijk persoon").build(),
                        SubEntiteitTestData.builder().nummer("!!! 8587920").subject("!!! ricsen").type("!!! Natuurlijk persoon").build()
                })
        );
    }

    public Optional<List<Behandelvoorstel>> findBehandelvoorstellenByNummer(Long entiteitNummer) {
        return getFakeBehandelvoorstellen();
    }

    public Optional<List<Opdracht>> findOpdrachtenByNummer(Long entiteitNummer) {
        return getFakeOpdrachten();
    }

    public Optional<String[][][]> findDashboardKenmerkenByNummer(Long entiteitNummer) {
        // TODO IVAKBS-132: Implement retrieval of WOLB-som using KrbEntiteitRepository!
        return Optional.of(new String[][][]{
                {
                        {"WOLB-SOM", "!!! 62100"},
                        {"Omzet OB", "!!! 500000"},
                        {"Vrijgestelde omzet", "!!! 50000"}
                }, {
                {"Loonsommen", "!!! 56000"},
                {"Aantal loongerechtigen OB", "!!! 10000"}
        }, {
                {"FD-Convenant", "!!! 123456"},
                {"Individueek convenent", "!!! 654321"},
                {"Totale belastingschuld", "!!! 40000"}
        }});
    }

    public Optional<ZooOmvang> findZooEntiteitOmvang(Long entiteitNummer) {
        return zooOmvangRepo.findById(entiteitNummer)
                .or(() -> Optional.of(new ZooOmvang(entiteitNummer))) // TODO IVAKBS-84: remove this dummy data
                .map(o -> {
                    Optional<KrbEntiteit> krbOpt = krbRepo.findById(entiteitNummer);
                    if (krbOpt.isPresent()) {
                        o = omvangMapper.update(o, krbOpt.get());
                    }
                    return o;
                })
                .map(o -> {
                    // TODO: remove this dummy data and remove '!!!' placeholders in frontend html template
                    o.setAantalBsnRsinsInEntiteit(3);
                    o.setAantalBezwarenVerzoekenEnBeroepen(4);
                    o.setBelastingschuld(BigInteger.valueOf(5));
                    o.setTotalenPerJaarOb(BigInteger.valueOf(6));
                    o.setTotalenPerJaarLhAantalLoongerechtigden(BigInteger.valueOf(7));
                    o.setTotalenPerJaarLhTotaalLoonsom(BigInteger.valueOf(8));
                    o.setTotalenAanslagenPerJaarVpb(BigInteger.valueOf(9));
                    o.setTotaalBetalingenJaarX(BigInteger.valueOf(10));
                    o.setTotaalBetalingenJaarXMin1(BigInteger.valueOf(11));
                    o.setTotaalBetalingenJaarXMin2(BigInteger.valueOf(2_430_000_000_000L));
                    return o;
                });
    }

    public ZooOmvang saveZooOmvang(Long entiteitNummer, ZooOmvang o, String loggingId) {
        // TODO IVAKBS-84: Do something with checking authentication and roles?

        Logging2.Bewerking bewerking = zooOmvangRepo.existsById(entiteitNummer) ? Logging2.Bewerking.UPDATE : Logging2.Bewerking.INSERT;

        var toSave = findZooEntiteitOmvang(entiteitNummer)
                .map(existing -> {
                    existing.setAantalBuitenlandseDeelnemingen(o.getAantalBuitenlandseDeelnemingen());
                    existing.setAantalVasteInrichtingen(o.getAantalVasteInrichtingen());
                    existing.setTotaleVrijgesteldeOmzet(o.getTotaleVrijgesteldeOmzet());
                    return existing;
                })
                .orElse(o);

        toSave.setLastUpdated(LocalDateTime.now());
        toSave.setLastUpdatedByUserId(SecurityContextHolder.getContext().getAuthentication().getName());

        zooOmvangRepo.save(toSave);

        var zooOmvang = findZooEntiteitOmvang(entiteitNummer).orElseThrow();
        this.logging2Service.save(loggingId, zooOmvang.getEntiteitNummer(), bewerking );
        return zooOmvang;
    }


    private Optional<List<Behandelvoorstel>> getFakeBehandelvoorstellen() {
        List<Behandelvoorstel> behandelvoorstellen = new LinkedList<>();
        behandelvoorstellen.add(Behandelvoorstel.builder().middel("!!! VPB").heffing("!!! 37").bezwaar("!!! 15").beroep("!!! 0")
                .controle("!!! 0").vooroverleg("!!! 6").invordering("!!! 6").overig("!!! 14").totalen("!!! 72").build());
        behandelvoorstellen.add(Behandelvoorstel.builder().middel("!!! OB").heffing("!!! 12").bezwaar("!!! 5").beroep("!!! 0")
                .controle("!!! 0").vooroverleg("!!! 0").invordering("!!! 0").overig("!!! 6").totalen("!!! 23").build());
        behandelvoorstellen.add(Behandelvoorstel.builder().middel("!!! LH").heffing("!!! 9").bezwaar("!!! 0").beroep("!!! 0")
                .controle("!!! 0").vooroverleg("!!! 4").invordering("!!! 4").overig("!!! 4").totalen("!!! 19").build());
        behandelvoorstellen.add(Behandelvoorstel.builder().middel("!!! IH").heffing("!!! 14").bezwaar("!!! 10").beroep("!!! 0")
                .controle("!!! 0").vooroverleg("!!! 2").invordering("!!! 2").overig("!!! 2").totalen("!!! 28").build());
        behandelvoorstellen.add(Behandelvoorstel.builder().middel("!!! Overig").heffing("!!! 1").bezwaar("!!! 0").beroep("!!! 0")
                .controle("!!! 0").vooroverleg("!!! 0").invordering("!!! 0").overig("!!! 32").totalen("!!! 33").build());
        behandelvoorstellen.add(Behandelvoorstel.builder().middel("!!! Totalen").heffing("!!! 73").bezwaar("!!! 30").beroep("!!! 0")
                .controle("!!! 0").vooroverleg("!!! 12").invordering("!!! 12").overig("!!! 60").totalen("!!! 175").build());
        return Optional.of(behandelvoorstellen);
    }

    private Optional<List<Opdracht>> getFakeOpdrachten() {
        List<Opdracht> opdrachten = new LinkedList<>();
        opdrachten.add(Opdracht.builder().naam("Afgedane activiteiten").aantal("!!! 123").build());
        opdrachten.add(Opdracht.builder().naam("Onderhanden activiteiten").aantal("!!! 58").build());
        opdrachten.add(Opdracht.builder().naam("Voorstel").aantal("!!! 45").build());
        return Optional.of(opdrachten);
    }

}

