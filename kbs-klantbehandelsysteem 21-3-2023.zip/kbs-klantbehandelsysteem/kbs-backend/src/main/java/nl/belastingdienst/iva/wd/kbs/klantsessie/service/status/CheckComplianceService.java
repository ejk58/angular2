/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: CheckComplianceService.java
 *             Auteur: duisr01
 *    Creatietijdstip: 27-7-2022 10:27
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.service.status;

import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieComplianceRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieCompliancePerProcesRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.CheckStatusInterface;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliancePerProces;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CheckComplianceService implements CheckStatusInterface {

	public static final int PER_PROCES_EXPECTED_COUNT = 1;

	private final KenmerkRepository kenmerkRepository;
	private final KlantSessieComplianceRepository klantSessieComplianceRepository;
	private final KlantsessieCompliancePerProcesRepository klantsessieCompliancePerProcesRepository;

	@Override
	public StepStatusEnum check(Long klantsessieId, Integer middelId) {
		//compliance
		int complianceTotalRecordCount = klantSessieComplianceRepository.countAllByKlantsessieIdAndMiddelId(klantsessieId, middelId);
		int complianceCompletedRecordCount = klantSessieComplianceRepository.countAllByKlantsessieIdAndMiddelIdAndScoreNotNullAndToelichtingNotNull(klantsessieId, middelId);

		//compliance per process
		KlantsessieCompliancePerProces compliancePerProcess = klantsessieCompliancePerProcesRepository.findByKlantsessieIdAndMiddelId(klantsessieId, middelId).orElse(null);
		int compliancePerProcessTotalRecordCount = compliancePerProcess == null ? 0 : 1;
		int compliancePerProcessCompletedCount = (compliancePerProcess != null && compliancePerProcessCompleted(compliancePerProcess)) ? 1 : 0;

		//business rule: no compliance per process for Controle AND Klantcoordinator
		boolean middelenWithBusinessRule = middelId.equals(Klantsessie.CONTROLE_MIDDEL_ID) || middelId.equals(Klantsessie.KLANTCOORDINATOR_MIDDEL_ID);

		//actual
		int recordCountTotal = complianceTotalRecordCount + compliancePerProcessTotalRecordCount;
		int recordCountCompleted = complianceCompletedRecordCount + compliancePerProcessCompletedCount;

		//expected
		int aspectExpectedCount = kenmerkRepository.countAllByGroepAndKenmerkParentIdIsNotNullOrderById("KS_CAT");
		int totalRecordCountExpected = aspectExpectedCount + PER_PROCES_EXPECTED_COUNT;

		if(middelenWithBusinessRule){
			recordCountTotal = complianceTotalRecordCount;
			recordCountCompleted = complianceCompletedRecordCount;
			totalRecordCountExpected = aspectExpectedCount;
		}

		if(recordCountTotal == 0){
			return StepStatusEnum.INITIAL;
		}

		if(recordCountCompleted == totalRecordCountExpected){
			return StepStatusEnum.COMPLETED;
		}

		return StepStatusEnum.TOUCHED;
	}

	@Override
	public StepEnum getStepEnum() {
		return StepEnum.COMPLIANCE;
	}

	private boolean compliancePerProcessCompleted(KlantsessieCompliancePerProces compliancePerProces){
		return !compliancePerProces.getVooroverleg().equals(0) && !compliancePerProces.getHeffing().equals(0) && !compliancePerProces.getBezwaren().equals(0);
	}
}
