/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: LazyLoadEvent.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 17-2-2022 14:51
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.tablefiltering.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * Based on https://github.com/primefaces/primeng/blob/master/src/app/components/api/lazyloadevent.ts
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
public class LazyLoadEvent {
	private Integer first;
	private Integer rows;
	private Object sortField;
	private Long sortOrder;
	private Map<String, List<Filter>> filters;
	private String globalFilter;
	private boolean unpaged = false;

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class Filter {
		private Object value;
		private String matchMode;
		private String operator;
	}
}
