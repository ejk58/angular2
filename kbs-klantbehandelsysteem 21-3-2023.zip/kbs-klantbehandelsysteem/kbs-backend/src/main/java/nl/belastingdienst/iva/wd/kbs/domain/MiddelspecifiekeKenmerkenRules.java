package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "MIDDELSPECIFIEKE_KENMERKEN_BUSINESS_RULES")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MiddelspecifiekeKenmerkenRules {
    @EmbeddedId
    private MiddelspecifiekeKenmerkenCompositeId compositeId;

    @OneToOne
    @JoinColumn(name = "KENMERK_ID", referencedColumnName = "ID", insertable = false, updatable = false)
    private Kenmerk kenmerk;
}
