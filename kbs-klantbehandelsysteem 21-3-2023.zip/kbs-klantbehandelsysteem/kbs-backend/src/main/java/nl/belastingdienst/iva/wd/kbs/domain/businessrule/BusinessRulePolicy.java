package nl.belastingdienst.iva.wd.kbs.domain.businessrule;

import java.util.function.Predicate;

public interface BusinessRulePolicy<T, R> {
	Predicate<R> getPredicates(T businessRuleDto);
	String getErrorMessage();
	Class<? extends BusinessRulePolicy<T,R>> getPolicyClass();
}
