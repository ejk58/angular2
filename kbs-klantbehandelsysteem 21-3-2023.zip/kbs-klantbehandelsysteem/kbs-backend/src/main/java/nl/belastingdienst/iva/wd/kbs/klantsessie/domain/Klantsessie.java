/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: Klantsessie.java
 *             Auteur: dekkj15
 *    Creatietijdstip: 13-5-2022 14:28
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Entity
@Table(name = "KLANTSESSIE")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Klantsessie {

	//kenmerken with specific business rules
	public static final Integer CONTROLE_MIDDEL_ID = 141;
	public static final Integer KLANTCOORDINATOR_MIDDEL_ID = 142;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	@Column(name = "ENTITEIT_NUMMER")
	private Long entiteitNummer;
	@Column(name = "STARTDATUM")
	private LocalDateTime startdatum;
	@Column(name = "EINDDATUM")
	private LocalDateTime einddatum;
	@Column(name = "CONTROLE_PLAATSGEVONDEN", columnDefinition = "default true")
	private Boolean controlePlaatsgevonden;
	@Column(name = "ACT_GEBASEERD_GEHOUDEN_KLANTSESSIE")
	private Boolean actGebaseerdGehoudenKlantsessie;
	@Column(name = "TOELICHTING_GEHOUDEN_KLANTSESSIE", nullable = true)
	private String toelichtingGehoudenKlantsessie;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "KLANTSESSIE_ID", referencedColumnName = "ID")
	@MapKey(name = "middelId")
	private Map<Integer, KlantsessieZooef> zichtOpOrganisatieEnFiscaliteitPerMiddel;

	public Klantsessie(Long entiteitNummer) {
		setEntiteitNummer(entiteitNummer);
		setStartdatum(LocalDateTime.now());
		setEinddatum(null);
		setControlePlaatsgevonden(Boolean.FALSE);
		setActGebaseerdGehoudenKlantsessie(Boolean.TRUE);
		setToelichtingGehoudenKlantsessie(null);
		setZichtOpOrganisatieEnFiscaliteitPerMiddel(new HashMap<>());
	}

	public KlantsessieZooef getZichtOpOrganisatieEnFiscaliteitForMiddel(@NonNull Integer middelId) {
		var middelMap = getZichtOpOrganisatieEnFiscaliteitPerMiddel();
		if (middelMap.containsKey(middelId)) {
			return middelMap.get(middelId);
		}

		var z = new KlantsessieZooef(id, middelId);
		middelMap.put(middelId, z);
		return z;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Klantsessie that = (Klantsessie) o;
		return id.equals(that.id) && entiteitNummer.equals(that.entiteitNummer) && startdatum.equals(that.startdatum) && Objects.equals(einddatum, that.einddatum) && controlePlaatsgevonden.equals(that.controlePlaatsgevonden) && actGebaseerdGehoudenKlantsessie.equals(that.actGebaseerdGehoudenKlantsessie) && Objects.equals(toelichtingGehoudenKlantsessie, that.toelichtingGehoudenKlantsessie);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, entiteitNummer, startdatum, einddatum, controlePlaatsgevonden, actGebaseerdGehoudenKlantsessie, toelichtingGehoudenKlantsessie);
	}
}
