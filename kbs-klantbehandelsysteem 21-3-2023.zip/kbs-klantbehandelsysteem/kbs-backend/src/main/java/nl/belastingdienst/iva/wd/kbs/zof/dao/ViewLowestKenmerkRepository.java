package nl.belastingdienst.iva.wd.kbs.zof.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.kta.dao.ReadOnlyJpaRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelKenmerk;

@Repository
public interface ViewLowestKenmerkRepository extends ReadOnlyJpaRepository<LowestEntiteitMiddelKenmerk, Long> {
	@SuppressWarnings("java:S100")
	List<LowestEntiteitMiddelKenmerk> findAllByEntiteitNummerAndLowest_MiddelIdOrderByRank(Long entiteitnummer, Integer middelId);
}
