/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: EntiteitNummerAccessCheckController.java
 *             Auteur: duisr01
 *    Creatietijdstip: 6-3-2023 14:13
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.gkv.rest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import nl.belastingdienst.iva.wd.kbs.gkv.domain.Toegang;
import nl.belastingdienst.iva.wd.kbs.gkv.service.EntiteitNummerAccessCheckService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/gkv")
@Slf4j
public class EntiteitNummerAccessCheckController {
	private final EntiteitNummerAccessCheckService entiteitNummerAccessCheckService;

	@GetMapping("/toegang/{entiteitNummer}")
	public Toegang getAutorisatieRapportToegang(@PathVariable Long entiteitNummer) {
		try {
			return entiteitNummerAccessCheckService.getAutorisatieRapportToegang(entiteitNummer);
		} catch (Exception exception) {
			log.error(exception.getMessage(), exception);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Het ophalen van de toegang tot entiteitnummer is mislukt.");
		}
	}

}
