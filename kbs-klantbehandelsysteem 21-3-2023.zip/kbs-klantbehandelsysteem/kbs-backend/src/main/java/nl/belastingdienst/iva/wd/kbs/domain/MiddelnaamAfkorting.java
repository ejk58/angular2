package nl.belastingdienst.iva.wd.kbs.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MIDDELNAAM_AFKORTING")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MiddelnaamAfkorting {

	@Id
	@Column(name = "MIDDEL_ID")
	private Integer middelId;
	@Column(name = "NAAM")
	private String naam;
	@Column(name = "AFKORTING")
	private String afkorting;
	@Column(name = "RANK")
	private Long rank;
}
