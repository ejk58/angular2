package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieCompliancePerProcesRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliancePerProces;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesWithAbbreviatedMiddelProjection;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.status.CheckComplianceService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.service.KenmerkService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class KlantsessieCompliancePerProcesService {
	private final CheckComplianceService checkComplianceService;
	private final KlantsessieStatusService klantsessieStatusService;

	private final KlantsessieService klantsessieService;
	private final KlantsessieCompliancePerProcesRepository klantSessieCompliancePerProcesRepository;
	private final KenmerkService kenmerkService;
	private final Logging2Service logging2Service;

	@Autowired
	private Validator validator;

	private KlantsessieCompliancePerProces saveAndSetStatus(Long entiteitnummer, KlantsessieCompliancePerProces klantsessieCompliancePerProces){
		klantSessieCompliancePerProcesRepository.save(klantsessieCompliancePerProces);
		klantsessieStatusService.setStepStatus(entiteitnummer, klantsessieCompliancePerProces.getMiddelId(),
				checkComplianceService.getStepEnum(), checkComplianceService.check(klantsessieCompliancePerProces.getKlantsessieId(), klantsessieCompliancePerProces.getMiddelId()));
		return klantsessieCompliancePerProces;
	}

	public KlantsessieCompliancePerProces getPerProces(Long entiteitnummer, Integer middelId) {
		var currentKlantsessie = klantsessieService.getCurrentKlantsessie(entiteitnummer);

		return klantSessieCompliancePerProcesRepository.findById(
					new KlantsessieCompliancePerProces.PrimaryKey(
							currentKlantsessie.getId(),
							middelId
					)
				).orElse(
						new KlantsessieCompliancePerProces(currentKlantsessie.getId(), middelId, 0, 0, 0)
				);
	}

	public List<PerProcesWithAbbreviatedMiddelProjection> getPerProces(Long entiteitnummer) {
		var previousKlantsessie = klantsessieService.getPreviousKlantsessie(entiteitnummer);
		if(previousKlantsessie.isEmpty()){
			return Collections.emptyList();
		}

		return this.klantSessieCompliancePerProcesRepository.findByKlantsessieIdWithAbbreviatedMiddel(
				previousKlantsessie.get()
								   .getId());
	}

	public KlantsessieCompliancePerProces update(PerProcesDto perProcesFrontend, Long entiteitnummer, String loggingId) {
		Set<ConstraintViolation<PerProcesDto>> violations = validator.validate(perProcesFrontend);
		if(!violations.isEmpty()) {
			var sb = new StringBuilder();
			for (ConstraintViolation<PerProcesDto> constraintViolation : violations) {
				sb.append(constraintViolation.getMessage());
			}
			throw new ConstraintViolationException("Error occurred: " + sb, violations);
		}

		var currentKlantsessie = klantsessieService.getCurrentKlantsessie(entiteitnummer);
		if(!currentKlantsessie.getId().equals(perProcesFrontend.getKlantsessieId())) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No klantsessie id found.");
		}

		var middel = kenmerkService.getKenmerk(perProcesFrontend.getMiddelId());

		if (middel.isEmpty() || !middel.get().getGroep().equals("MID")){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid middel provided for compliance per proces.");
		}

		var proces = klantSessieCompliancePerProcesRepository.findById(
				new KlantsessieCompliancePerProces.PrimaryKey(
						perProcesFrontend.getKlantsessieId(),
						perProcesFrontend.getMiddelId()
				)
		)
				.orElse(
						new KlantsessieCompliancePerProces(perProcesFrontend.getKlantsessieId(), perProcesFrontend.getMiddelId(),
								null, null, null)
				);

		proces.setBezwaren(perProcesFrontend.getBezwaren());
		proces.setHeffing(perProcesFrontend.getHeffing());
		proces.setVooroverleg(perProcesFrontend.getVooroverleg());

		this.logging2Service.save(loggingId, entiteitnummer, Logging2.Bewerking.UPDATE);
		return saveAndSetStatus(entiteitnummer, proces);
	}

}
