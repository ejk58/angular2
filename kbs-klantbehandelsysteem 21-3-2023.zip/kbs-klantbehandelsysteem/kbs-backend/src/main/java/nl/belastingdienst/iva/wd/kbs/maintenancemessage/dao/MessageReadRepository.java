package nl.belastingdienst.iva.wd.kbs.maintenancemessage.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.kta.dao.ReadOnlyJpaRepository;
import nl.belastingdienst.iva.wd.kbs.maintenancemessage.domain.Message;

@Repository
public interface MessageReadRepository extends ReadOnlyJpaRepository<Message, Long> {
	List<Message> findAllByStartLessThanEqualAndEndGreaterThanEqualOrderByStartDesc(LocalDateTime start, LocalDateTime end);

	default List<Message> findCurrentMessages(){
		var currentDate = LocalDateTime.now();
		return this.findAllByStartLessThanEqualAndEndGreaterThanEqualOrderByStartDesc(currentDate, currentDate);
	}
}
