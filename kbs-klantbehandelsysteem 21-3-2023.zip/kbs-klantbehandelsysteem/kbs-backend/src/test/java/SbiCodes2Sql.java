import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class SbiCodes2Sql {
	//starts with a letter
	static final Pattern HOOFD_CATEGORIE_PATTERN = Pattern.compile("^[A-Z]");
	//starts with any number of digits NOT followed by a dot
	static final Pattern SUB_CATEGORIE_PATTERN = Pattern.compile("^(\\d++)[^.]");
	//starts with any number of digits, followed by a dot and exactly ONE digit
	static final Pattern SPECIFICATIE_VAN_SUB_CATEGORIE_PATTERN = Pattern.compile("^(\\d++).\\d[^0-9]");

	@Test
	@Disabled
	public void convertSbiCodesToSqlWithIds() throws IOException {
		int startNumber = 1000;
		int index = 0;
		int maxStrLength = 0;
		int nrOfHoofdKenmerken = 0;
		int hoofdcategorieId = 0;
		int subcategorieId = 0;
		int specificatieId = 0;

		BufferedReader reader = new BufferedReader(new FileReader("../SBI-codes.txt", Charset.forName("windows-1252")));
		FileWriter fileWriter = new FileWriter("../Kenmerken_SBI-codes.sql");
		System.out.println("Encoding: " + fileWriter.getEncoding());
		BufferedWriter writer = new BufferedWriter(fileWriter);
		writer.write("-- Deze file is gegenereerd met test-class SbiCodes2Sql (methode: convertSbiCodesToSqlWithIds()) in het kbs project.\n");
		writer.write("MERGE INTO KENMERK AS k USING (VALUES\n");
		String line;
		while ((line = reader.readLine()) != null) {
			line = line.trim();
			maxStrLength = Math.max(maxStrLength, line.length());
			if (index > 0) 		writer.write(", \n");
			if (line.contains("'")) line = line.replaceAll("'", "''");

			Matcher m = HOOFD_CATEGORIE_PATTERN.matcher(line);
			if (m.find()) {
				nrOfHoofdKenmerken ++;
				hoofdcategorieId = startNumber + index++;
				writer.write(String.format("(%d,  'BCAV', '%s', null)", hoofdcategorieId, line));
			} else {
				m = SUB_CATEGORIE_PATTERN.matcher(line);
				if (m.find()){
					subcategorieId = startNumber + index++;
					writer.write(String.format("(%d,  'BCAV', '%s', %d)", subcategorieId, line, hoofdcategorieId));
				} else {
					m = SPECIFICATIE_VAN_SUB_CATEGORIE_PATTERN.matcher(line);
					if (m.find()) {
						specificatieId = startNumber + index++;
						writer.write(String.format("(%d,  'BCAV', '%s', %d)", specificatieId, line, subcategorieId));
					} else {
						writer.write(String.format("(%d,  'BCAV', '%s', %d)", startNumber + index++, line, specificatieId));
					}
				}
			}
		}
		writer.write("\n) AS X(ID, GROEP, KENMERK, KENMERK_PARENT_ID)\n"
				+ "ON k.ID = X.ID\n"
				+ "WHEN NOT MATCHED THEN\n"
				+ "    INSERT (ID, GROEP, KENMERK, KENMERK_PARENT_ID) VALUES (X.ID, X.GROEP, X.KENMERK, X.KENMERK_PARENT_ID)\n"
				+ "WHEN MATCHED THEN\n"
				+ "    UPDATE SET GROEP = X.GROEP, KENMERK = X.KENMERK, KENMERK_PARENT_ID = X.KENMERK_PARENT_ID;\n"
				+ "COMMIT;\n");
		writer.flush();
		writer.close();
		reader.close();
		System.out.println("Generated " + (index + 1) + " branchcode kenmerk records. The longest string is " + maxStrLength + " characters long. Number of hoofdkenmerken is " + nrOfHoofdKenmerken +".");
	}
	@Test
	@Disabled
	public void accentedCharactersInSqlfile() throws IOException {
		FileWriter fileWriter = new FileWriter("../AccentedCharacters.sql");
		System.out.println("Encoding: " + fileWriter.getEncoding());
		BufferedWriter writer = new BufferedWriter(fileWriter);
		writer.write("-- Dit is een test file om characters met accenten mbv. Liquibase in de database te zetten.\n");
		writer.write("-- Deze file is gegenereerd met test-class SbiCodes2Sql (methode: accentedCharactersInSqlfile()) in het kbs project.\n");

		writer.write("MERGE INTO KENMERK AS k USING (VALUES\n");
		String line = "Umlaut: e-ëË, a-äÄ, o-öÖ, i-ïÏ u-üÜ";
		writer.write(String.format("(%d,  'TEST', '%s', null)", -1, line));
		writer.write("\n) AS X(ID, GROEP, KENMERK, KENMERK_PARENT_ID)\n"
				+ "ON k.ID = X.ID\n"
				+ "WHEN NOT MATCHED THEN\n"
				+ "    INSERT (ID, GROEP, KENMERK, KENMERK_PARENT_ID) VALUES (X.ID, X.GROEP, X.KENMERK, KENMERK_PARENT_ID)\n"
				+ "WHEN MATCHED THEN\n"
				+ "    UPDATE SET GROEP = X.GROEP, KENMERK = X.KENMERK, KENMERK_PARENT_ID = X.KENMERK_PARENT_ID;\n"
				+ "COMMIT;\n");
		writer.flush();
		writer.close();
	}

	@Test
	@Disabled
	public void regexTester(){
		String hoofdcategorie = "A\tLandbouw, bosbouw en visserij";
		String subCat = "1 \tLandbouw, jacht en dienstverlening voor de landbouw en jacht";
		String subCat1 = "01 \tLandbouw, jacht en dienstverlening voor de landbouw en jacht";
		String subCat2 = "012\tLandbouw, jacht en dienstverlening voor de landbouw en jacht";
		String specificatie = "01.1\tTeelt van eenjarige gewassen";
		String specificatie1 = "1.1\tTeelt van eenjarige gewassen";
		String child = "01.11\tTeelt van granen, peulvruchten en oliehoudende zaden";
		String child1 = "01.11.14\tTeelt van granen, peulvruchten en oliehoudende zaden";

		Matcher m = HOOFD_CATEGORIE_PATTERN.matcher(hoofdcategorie);
		Assertions.assertTrue(m.find());
		m = HOOFD_CATEGORIE_PATTERN.matcher(subCat);
		Assertions.assertFalse(m.find());
		m = HOOFD_CATEGORIE_PATTERN.matcher(specificatie);
		Assertions.assertFalse(m.find());
		m = HOOFD_CATEGORIE_PATTERN.matcher(child);
		Assertions.assertFalse(m.find());

		m = SUB_CATEGORIE_PATTERN.matcher(subCat);
		Assertions.assertTrue(m.find());
		m = SUB_CATEGORIE_PATTERN.matcher(subCat1);
		Assertions.assertTrue(m.find());
		m = SUB_CATEGORIE_PATTERN.matcher(subCat2);
		Assertions.assertTrue(m.find());
		m = SUB_CATEGORIE_PATTERN.matcher(specificatie);
		Assertions.assertFalse(m.find());
		m = SUB_CATEGORIE_PATTERN.matcher(child);
		Assertions.assertFalse(m.find());
		m = SUB_CATEGORIE_PATTERN.matcher(child1);
		Assertions.assertFalse(m.find());

		m = SPECIFICATIE_VAN_SUB_CATEGORIE_PATTERN.matcher(subCat);
		Assertions.assertFalse(m.find());
		m = SPECIFICATIE_VAN_SUB_CATEGORIE_PATTERN.matcher(specificatie);
		Assertions.assertTrue(m.find());
		m = SPECIFICATIE_VAN_SUB_CATEGORIE_PATTERN.matcher(specificatie1);
		Assertions.assertTrue(m.find());
		m = SPECIFICATIE_VAN_SUB_CATEGORIE_PATTERN.matcher(child);
		Assertions.assertFalse(m.find());
		m = SPECIFICATIE_VAN_SUB_CATEGORIE_PATTERN.matcher(child1);
		Assertions.assertFalse(m.find());
	}
}
