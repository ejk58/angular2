import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class properties2CM {

    @Test
    @Disabled
    public void propsInCM() throws IOException {
        Properties props = new Properties();
        props.load(new FileInputStream("src/main/resources/application.properties"));
        replacePlaceholders(props);
        printPrefix();
        props.stringPropertyNames().stream().sorted().forEach(key -> {
                System.out.print("  \"");
                System.out.print(key);
                System.out.print("\": \"");
                System.out.print(props.getProperty(key));
                System.out.println("\"");
        });
        printPostfix();
    }

    void replacePlaceholders(Properties props) {
        props.stringPropertyNames().parallelStream().forEach(key -> {
            String value = props.getProperty(key);
            int index = value.indexOf("${");
            if (index >= 0) {
                int indexRight = value.indexOf("}", index);
                String replaceKey = value.substring(index + 2, indexRight);
                String newValue = props.getProperty(replaceKey);
                if (newValue != null) {
                    props.setProperty(key, value.substring(0, index) + newValue + value.substring(indexRight + 1));
                }
            }
        });
    }

    private void printPrefix() {
        System.out.println("apiVersion: v1\ndata:");
    }
    private void printPostfix() {
        System.out.println("kind: ConfigMap\nmetadata:\n  annotations:\n  name: ont-config");
    }

    @Test
    @Disabled
    public void testReplacePlaceholders() {
        Properties props = new Properties();
        props.setProperty("key1", "Value1");
        props.setProperty("BlaBla", "SomeValueWith${key5}");
        props.setProperty("key5", "Value5");
        replacePlaceholders(props);
        Assertions.assertNotNull(props);
        Assertions.assertEquals(3, props.size());
        Assertions.assertEquals("Value1", props.getProperty("key1"));
        Assertions.assertEquals("Value5", props.getProperty("key5"));
        Assertions.assertEquals("SomeValueWithValue5", props.getProperty("BlaBla"));

    }
}
