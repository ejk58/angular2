package nl.belastingdienst.iva.wd.kbs.klantsessie.service.status;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieComplianceRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieCompliancePerProcesRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliancePerProces;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class CheckComplianceServiceTest {

	private static final Kenmerk PARENT_KENMERK_1 = new Kenmerk(1, "KS_CAT", "Parent 1", null);
	private static final Kenmerk PARENT_KENMERK_2 = new Kenmerk(2, "KS_CAT", "Parent 2", null);
	private static final Kenmerk CHILD_KENMERK_1_A = new Kenmerk(10, "KS_CAT", "Child parent 1a", 1);
	private static final Kenmerk CHILD_KENMERK_1_B = new Kenmerk(11, "KS_CAT", "Child parent 1b", 1);
	private static final Kenmerk CHILD_KENMERK_2_A = new Kenmerk(20, "KS_CAT", "Child parent 2a", 2);
	private static final Kenmerk CHILD_KENMERK_2_B = new Kenmerk(21, "KS_CAT", "Child parent 2b", 2);
	private static final Kenmerk NON_RELATING_KENMERK = new Kenmerk(999, "OTHER", "Should not be included", 998);
	private static final List<Kenmerk> KENMERK_LIST = List.of(PARENT_KENMERK_1, PARENT_KENMERK_2, CHILD_KENMERK_1_A, CHILD_KENMERK_1_B, CHILD_KENMERK_2_A, CHILD_KENMERK_2_B, NON_RELATING_KENMERK);

	public static final long KLANTSESSIE_ID_COMPLETE = 111L;
	public static final long KLANTSESSIE_ID_ONLY_COMPLETE_COMPLIANCE = 222L;
	public static final long KLANTSESSIE_ID_ONLY_COMPLETE_PROCES = 333L;
	public static final long KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE = 444L;
	public static final long KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_445 = 445L;
	public static final long KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_2 = 555L;
	public static final long KLANTSESSIE_ID_ONLY_PARTIAL_PROCES = 666L;
	public static final long KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_2 = 667L;
	private static final Long KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_3 = 668L;
	private static final Long KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_4 = 669L;
	private static final Long KLANTSESSIE_ID_CONTROLE_ONLY_PARTIAL_COMPLIANCE = 700L;
	private static final Long KLANTSESSIE_ID_CONTROLE_COMPLETE = 701L;
	public static final int CONTROLE_MIDDEL_ID = 141;

	@Autowired
	CheckComplianceService sut;

	@Autowired
	private KenmerkRepository kenmerkRepository;

	@Autowired
	private KlantSessieComplianceRepository klantSessieComplianceRepository;

	@Autowired
	KlantsessieCompliancePerProcesRepository klantSessieCompliancePerProcesRepository;

	@BeforeEach
	void setUp() {
		this.kenmerkRepository.saveAll(KENMERK_LIST);
		this.setupRepositories();
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void check(String testCaseName, Long klantsessieId, Integer middelId, StepStatusEnum expectedStatusEnum) {
		StepStatusEnum actualStepStatusEnum = this.sut.check(klantsessieId, middelId);
		Assertions.assertEquals(expectedStatusEnum, actualStepStatusEnum);
	}

	@Test
	void getStepEnum() {
		Assertions.assertEquals(StepEnum.COMPLIANCE, this.sut.getStepEnum());
	}

	private static Stream<Arguments> provideInput() {
		return Stream.of(
				Arguments.of(
						"givenNotStarted_whenCheck_ThenReturnInitial",
						999L,
						12,
						StepStatusEnum.INITIAL
				),
				Arguments.of(
						"givenNotStarted_2_whenCheck_ThenReturnInitial",
						KLANTSESSIE_ID_ONLY_COMPLETE_COMPLIANCE,
						24,
						StepStatusEnum.INITIAL
				),
				Arguments.of(
						"givenOnlyCompliance_whenCheck_ThenReturnTouched",
						KLANTSESSIE_ID_ONLY_COMPLETE_COMPLIANCE,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenOnlyPerProces_whenCheck_ThenReturnTouched",
						KLANTSESSIE_ID_ONLY_COMPLETE_PROCES,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenCompleteRecords_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_COMPLETE,
						12,
						StepStatusEnum.COMPLETED
				),
				Arguments.of(
						"givenPartialCompleteCompliance_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenPartialCompleteCompliance_445_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_445,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenPartialCompleteCompliance_2_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_2,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenPartialCompletePerProces_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_ONLY_PARTIAL_PROCES,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenPartialCompletePerProces_2_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_2,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenPartialCompletePerProces_3_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_3,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenPartialCompletePerProces_4_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_4,
						12,
						StepStatusEnum.TOUCHED
				),
				/* Controle middel */
				Arguments.of(
						"givenControlePartialCompliance_whenCheck_ThenReturnTouched",
						KLANTSESSIE_ID_CONTROLE_ONLY_PARTIAL_COMPLIANCE,
						CONTROLE_MIDDEL_ID,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenControleComplete_whenCheck_ThenReturnCompleted",
						KLANTSESSIE_ID_CONTROLE_COMPLETE,
						CONTROLE_MIDDEL_ID,
						StepStatusEnum.COMPLETED
				)
		);
	}

	private void setupRepositories() {
		this.klantSessieComplianceRepository.saveAll(
			List.of(
					/* 111 - complete */
					new KlantsessieCompliance(KLANTSESSIE_ID_COMPLETE, 12, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_COMPLETE, 12, 11, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_COMPLETE, 12, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_COMPLETE, 12, 21, 5, "toelichting", null),
					/* 222 - only complete compliance */
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_COMPLETE_COMPLIANCE, 12, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_COMPLETE_COMPLIANCE, 12, 11, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_COMPLETE_COMPLIANCE, 12, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_COMPLETE_COMPLIANCE, 12, 21, 5, "toelichting", null),
					/* 444 - partial complete compliance */
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE, 12, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE, 12, 11, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE, 12, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE, 12, 21, 5, null, null),
					/* 445 - partial complete compliance */
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_445, 12, 21, 5, null, null),
					/* 555 - partial complete compliance */
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_2, 12, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_2, 12, 11, null, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_2, 12, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_2, 12, 21, 5, "toelichting", null),
					/* 666 - partial complete proces */
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES, 12, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES, 12, 11, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES, 12, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES, 12, 21, 5, "toelichting", null),
					/* 667 - partial complete proces 2 */
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_2, 12, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_2, 12, 11, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_2, 12, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_2, 12, 21, 5, "toelichting", null),
					/* 668 - partial complete proces 3 */
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_3, 12, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_3, 12, 11, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_3, 12, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_3, 12, 21, 5, "toelichting", null),
					/* 669 - partial complete proces 4 */
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_4, 12, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_4, 12, 11, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_4, 12, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_4, 12, 21, 5, "toelichting", null),
					/* 700 - Controle - partial compliance */
					new KlantsessieCompliance(KLANTSESSIE_ID_CONTROLE_ONLY_PARTIAL_COMPLIANCE, CONTROLE_MIDDEL_ID, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_CONTROLE_ONLY_PARTIAL_COMPLIANCE, CONTROLE_MIDDEL_ID, 11, null, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_CONTROLE_ONLY_PARTIAL_COMPLIANCE, CONTROLE_MIDDEL_ID, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_CONTROLE_ONLY_PARTIAL_COMPLIANCE, CONTROLE_MIDDEL_ID, 21, 5, "toelichting", null),
					/* 701 - Controle - complete */
					new KlantsessieCompliance(KLANTSESSIE_ID_CONTROLE_COMPLETE, CONTROLE_MIDDEL_ID, 10, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_CONTROLE_COMPLETE, CONTROLE_MIDDEL_ID, 11, 4, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_CONTROLE_COMPLETE, CONTROLE_MIDDEL_ID, 20, 5, "toelichting", null),
					new KlantsessieCompliance(KLANTSESSIE_ID_CONTROLE_COMPLETE, CONTROLE_MIDDEL_ID, 21, 5, "toelichting", null)
			)
		);

		this.klantSessieCompliancePerProcesRepository.saveAll(
			List.of(
					/* 111 - complete */
					new KlantsessieCompliancePerProces(KLANTSESSIE_ID_COMPLETE, 12, 1, 1, 1),
					/* 333 - only complete proces */
					new KlantsessieCompliancePerProces(KLANTSESSIE_ID_ONLY_COMPLETE_PROCES, 12, 1, 1, 1),
					/* 444 - partial complete compliance */
					new KlantsessieCompliancePerProces(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE, 12, 1, 1, 1),
					/* 555 - partial complete compliance */
					new KlantsessieCompliancePerProces(KLANTSESSIE_ID_ONLY_PARTIAL_COMPLIANCE_2, 12, 1, 1, 1),
					/* 666 - partial complete proces */
					new KlantsessieCompliancePerProces(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES, 12, 0, 1, 1),
					/* 667 - partial complete proces 2 */
					new KlantsessieCompliancePerProces(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_2, 12, 1, 0, 1),
					/* 668 - partial complete proces 3 */
					new KlantsessieCompliancePerProces(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_3, 12, 1, 1, 0),
					/* 669 - partial complete proces 4 */
					new KlantsessieCompliancePerProces(KLANTSESSIE_ID_ONLY_PARTIAL_PROCES_4, 12, 0, 0, 0)
			)
		);
	}
}