package nl.belastingdienst.iva.wd.kbs.krr;

import nl.belastingdienst.iva.wd.kbs.exception.FailedToRetrieveSuccessfulResponseException;
import nl.belastingdienst.iva.wd.kbs.krr.domain.BepaalCategorieGo;
import nl.belastingdienst.iva.wd.kbs.service.RestTemplateClient;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.net.URI;
import java.util.stream.Stream;

import static org.mockito.Mockito.when;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@TestPropertySource(properties = {
        "krr.api.base.url=api/test/",
        "krr.api.key=KRR-APIKey-Test"
})
class KrrServiceTest {
    @MockBean
    private RestTemplateClient restTemplateClient;

    @Autowired
    private KrrService cut;

    @Value("${krr.api.base.url}")
    private String baseUrl;
    @Value("${krr.api.key}")
    private String apiKey;


    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideInput")
    void getAutorisatieRapportToegang(String testCaseName, ResponseEntity<BepaalCategorieGo[]> responseEntity,
                                      BepaalCategorieGo[] expected, Class<Throwable> exception) {

        var uri = URI.create(baseUrl + "bepaalCategorieGO?entnr=" + 888L);
        if (exception != null) {
            Assertions.assertThrows(exception, () -> {
                cut.getCategorieGo(888L);
            });
        } else {
            when(restTemplateClient.doKrrRequest(HttpMethod.GET, uri, null, BepaalCategorieGo[].class, apiKey))
                    .thenReturn(responseEntity);
            BepaalCategorieGo[] actual = cut.getCategorieGo(888L);
            Assertions.assertEquals(expected, actual);
        }
    }

    private static Stream<Arguments> provideInput() {
        BepaalCategorieGo[] response = new BepaalCategorieGo[]{new BepaalCategorieGo("Test middel", 888L)};
        return Stream.of(
                Arguments.of(
                        "givenResponseIsCorrect_ThenReturnCategorieGo",
                        new ResponseEntity<>(response, HttpStatus.OK),
                        response,
                        null
                ),
                Arguments.of(
                        "givenResponseIsEmpty_ThenThrowException",
                        new ResponseEntity<>(HttpStatus.OK),
                        null,
                        FailedToRetrieveSuccessfulResponseException.class
                )
        );
    }
}