package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import static nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers.responseBody;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieZooefRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieZooef;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieAfrondenService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieStatusService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieZooefService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.rest.FakeResponseTime;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;

@WebMvcTest(controllers = KlantsessieRestController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class KlantsessieRestControllerTest {

	private static final long ENTITEIT_NUMMER = 1234L;
	private static final String JSON = MediaType.APPLICATION_JSON.toString();
	private static final String NIEUWEINZICHTENOBSERVATIES = "nieuweInzichtenEnObservaties";
	private static final Integer EXISTINGMIDDELID = 12;
	public static final String TEST_LOGGING_ID = "testLoggingId";

	private final ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private FakeResponseTime fakeResponseTime;
	@MockBean
	private KlantsessieService klantsessieServiceMock;
	@MockBean
	private KlantsessieStatusService klantsessieStatusService;
	@MockBean
    private KlantsessieZooefService klantsessieZooefService;
	@MockBean
	private KlantsessieZooefRepository klantsessieZooefRepository;
	@MockBean
	private KlantsessieAfrondenService klantsessieAfrondenService;

	@Test
	void getPreviousKlantsessie_WhenAPreviousKlantsessieExists_ReturnsHttp200Ok() throws Exception {
		Klantsessie expectedKlantsessie = new Klantsessie(ENTITEIT_NUMMER);
		when(klantsessieServiceMock.getPreviousKlantsessie(anyLong())).thenReturn(Optional.of(expectedKlantsessie));
		mockMvc.perform(get("/api/klantsessie/{entiteitNummer}/previous", ENTITEIT_NUMMER).contentType(JSON))
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(expectedKlantsessie, Klantsessie.class));
	}

	@Test
	void getPreviousKlantsessie_WhenNoPreviousKlantsessieExists_ReturnsHttp204NoContent() throws Exception {
		when(klantsessieServiceMock.getPreviousKlantsessie(anyLong())).thenReturn(Optional.empty());
		mockMvc.perform(get("/api/klantsessie/{entiteitNummer}/previous", ENTITEIT_NUMMER).contentType(JSON))
				.andExpect(status().isNoContent());
	}

	@Test
	void updateControlePlaatsgevonden_WhenCurrentKlantsessieUpdates_ReturnsHttp200Ok() throws Exception {
			Klantsessie ks = new Klantsessie(ENTITEIT_NUMMER);
		when(klantsessieServiceMock.updateControlePlaatsgevondenOfCurrentKlantsessie(ENTITEIT_NUMMER, true, "logId"))
				.thenReturn(ks);
		mockMvc.perform(post("/api/klantsessie/{entiteitNummer}/controlePlaatsgevonden", ENTITEIT_NUMMER)
						.contentType(JSON)
						.content(objectMapper.writeValueAsString( new LoggingWrapper<>("logId", true))))
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(ks, Klantsessie.class));
	}

	@Test
	void updateNieuweInzichtenEnObservaties_WithExistingMiddel_ReturnsHttp200Ok() throws Exception {
		when(klantsessieZooefService.updateNieuweInzichtenEnObservaties(eq(ENTITEIT_NUMMER), eq(EXISTINGMIDDELID), eq(NIEUWEINZICHTENOBSERVATIES), any()))
				.thenReturn(new KlantsessieZooef(1L, EXISTINGMIDDELID));
		var loggingWrapper = new LoggingWrapper<>(TEST_LOGGING_ID, NIEUWEINZICHTENOBSERVATIES);
		mockMvc.perform(post("/api/klantsessie/{entiteitNummer}/{middelId}/nieuweInzichtenEnObservaties", ENTITEIT_NUMMER, EXISTINGMIDDELID)
						.contentType(JSON)
						.content(objectMapper.writeValueAsString(loggingWrapper)))
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(new KlantsessieZooef(1L, EXISTINGMIDDELID), KlantsessieZooef.class));
	}

	@Test
	void updateZooefVorigeObservatiesNogActueel_WhenRequestBodyWasNotProvided_ThenReturnsHttp400BadRequest() throws Exception {
        when(klantsessieZooefService.updateObservatiesActueel(eq(ENTITEIT_NUMMER), eq(EXISTINGMIDDELID), eq(true) , any()))
				.thenReturn(new KlantsessieZooef(1L, EXISTINGMIDDELID));
        mockMvc.perform(post("/api/klantsessie/{entiteitNummer}/{middelId}/observatiesActueel", ENTITEIT_NUMMER, EXISTINGMIDDELID)
						.contentType(JSON))
                .andExpect(status().isBadRequest());
	}

	@Test
	void updateZooefVorigeObservatiesNogActueel_WhenRequestBodyWasProvided_ThenReturnsHttp200OkWithUpdatedKlantsessieZooef() throws Exception {
		when(klantsessieZooefService.updateObservatiesActueel(eq(ENTITEIT_NUMMER), eq(EXISTINGMIDDELID), eq(true), any() ))
				.thenReturn(new KlantsessieZooef(1L, EXISTINGMIDDELID));
		var loggingWrapper = new LoggingWrapper<>(TEST_LOGGING_ID, true);
		mockMvc.perform(post("/api/klantsessie/{entiteitNummer}/{middelId}/observatiesActueel", ENTITEIT_NUMMER, EXISTINGMIDDELID)
						.contentType(JSON)
						.content(objectMapper.writeValueAsString(loggingWrapper)))
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(new KlantsessieZooef(1L, EXISTINGMIDDELID), KlantsessieZooef.class));
	}

	@Test
	void getHuidigeKlantsessieObservaties_WhenExists_ThenReturnsHttp200OkWithKlantsessieZooef() throws Exception {
		when(klantsessieZooefService.getHuidigeKlantsessieZooefObservatie(ENTITEIT_NUMMER, EXISTINGMIDDELID))
				.thenReturn(new KlantsessieZooef(1L, EXISTINGMIDDELID));
		mockMvc.perform(get("/api/klantsessie/{entiteitNummer}/{middelId}/huidigeKlantsessieObservaties", ENTITEIT_NUMMER, EXISTINGMIDDELID)
						.contentType(JSON))
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(new KlantsessieZooef(1L, EXISTINGMIDDELID), KlantsessieZooef.class));
	}

	@Test
	void updateKlantsessieAfgerond_ThenReturnsHttp200OkWithUpdatedKlantsessie() throws Exception {
		Klantsessie ks = new Klantsessie(ENTITEIT_NUMMER);
		when(klantsessieAfrondenService.updateKlantsessieAfgerond(ENTITEIT_NUMMER, TEST_LOGGING_ID)).thenReturn(ks);
		mockMvc.perform(post("/api/klantsessie/{entiteitNummer}/klantsessie-afronden", ENTITEIT_NUMMER)
						.contentType(JSON)
					   .content(objectMapper.writeValueAsString(new LoggingWrapper<>(TEST_LOGGING_ID, null)))
			   )
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(ks, Klantsessie.class));
	}

	@Test
	void getCheckKlantsessieAfrondenEnabled_ThenReturnsHttp200OkWithBoolean() throws Exception {
		when(klantsessieAfrondenService.checkKlantsessieAfrondenEnabled(ENTITEIT_NUMMER)).thenReturn(true);
		mockMvc.perform(get("/api/klantsessie/{entiteitNummer}/klantsessie-afronden-enabled", ENTITEIT_NUMMER)
						.contentType(JSON))
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(true, Boolean.class));
	}
}
