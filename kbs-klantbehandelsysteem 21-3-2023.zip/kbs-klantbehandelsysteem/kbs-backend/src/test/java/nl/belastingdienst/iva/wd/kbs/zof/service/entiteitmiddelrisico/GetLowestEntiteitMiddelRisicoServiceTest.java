package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisico;

@SpringBootKbsTest
class GetLowestEntiteitMiddelRisicoServiceTest {

	@Autowired
	GetLowestEntiteitMiddelRisicoService sut;

	@Autowired
	EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;

	@Autowired
	MiddelRisicoRepository middelRisicoRepository;

	@BeforeEach
	void setUp() {
		this.middelRisicoRepository.saveAll(List.of(
				new MiddelRisico(1L, 12, "risco 1", null, null),
				new MiddelRisico(2L, 12, "risco 2", 1L, null),
				new MiddelRisico(3L, 24, "risco 3", 28L, null)
		));

		this.entiteitMiddelRisicoRepository.saveAll(List.of(
				new EntiteitMiddelRisico(1L, 999L, null, 1L, null, (short) 1, 97L, 1,null),
				new EntiteitMiddelRisico(2L, 999L, null, 1L, 2L, (short) 0, 96L, 1,null),
				new EntiteitMiddelRisico(3L, 999L, null, 1L, 3L, (short) 1, 97L, 1,null)
		));
	}

	@Test
	void getEntiteitMiddelRisicoWithLowestByEntiteitnummerAndMiddelId() {
		MiddelRisico lowestAsHoofdRisicoId = new MiddelRisico(1L, 12, "risco 1", null, null);
		MiddelRisico lowestAsSubRisicoId = new MiddelRisico(2L, 12, "risco 2",  1L, null);

		List<LowestEntiteitMiddelRisico> lowestList = List.of(
				new LowestEntiteitMiddelRisico(1L, 999L, null, 1L, null, (short)1, 97L, null, 1L, lowestAsHoofdRisicoId),
				new LowestEntiteitMiddelRisico(2L, 999L, null, 1L, 2L, (short)0, 96L, null, 1L, lowestAsSubRisicoId)
		);
		List<LowestEntiteitMiddelRisico> actual = sut.getEntiteitMiddelRisicoWithLowestByEntiteitnummerAndMiddelId(999L, 12);
		Assertions.assertEquals(lowestList, actual);
	}
}