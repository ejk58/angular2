package nl.belastingdienst.iva.wd.kbs.rest;

import static nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers.responseBody;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.ApiServiceApplicationProperties;
import nl.belastingdienst.iva.wd.kbs.domain.BehandelActiviteit;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatBehandelplanvoorstel;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatBehandelvoorstelResponse;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatDocument;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatGegevensService;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatHeffing;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatPersoon;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatTeam;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatToelichting;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.Activiteit;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.BatRegisterBehandelvoorstelService;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.BehandelVoorstelRequestDto;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.BehandelVoorstelResponse;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.BehandelvoorstelOption;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.RegisterBehandelvoorstelUrl;
import nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen.VoorstelType;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;

@WebMvcTest(controllers = BehandelvoorstelController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR"})
@RestControllerTestConfiguration
class BehandelvoorstelControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    BatGegevensService batGegevensServiceMock;
    @MockBean
    BatRegisterBehandelvoorstelService batRegisterBehandelvoorstelServiceMock;
    @MockBean
    ApiServiceApplicationProperties apiServiceApplicationPropertiesMock;

    @Mock
    private Authentication authentication;

    @Autowired
    BehandelvoorstelController cut;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private static final String CREATED_BEHANDELVOORSTEL_BPV01 = "BPV01-TEST-ID";

    private final String CREATED_TOKEN = "token.123.asd";
    private static final VoorstelType VOORSTEL_TYPE_HEF01_TEST = new VoorstelType("HEF01", "test omschrijving");
    private static final Map<String, String> ACTIVITEIT_CODES = Map.of("AB-TEST", "Aangiftebehandeling");
    private static final Map<String, String> STATUS_CODES = Map.of("CODE1", "Staus test1 ");

    private static final String JSON = MediaType.APPLICATION_JSON.toString();

    private BehandelVoorstelRequestDto getCreateBehandelVoorstelRequest() {
        BehandelVoorstelRequestDto testRequest = new BehandelVoorstelRequestDto();
        testRequest.setSubject("111");
        testRequest.setVoorstelType("BPV01");
        testRequest.setBehandelActiviteitCode("AB TEST");
        testRequest.setVoorstelAction("NEW");
        return testRequest;
    }

    @Test
    void createBehandelVoorstel() throws Exception {
        var expected = new BehandelVoorstelResponse(CREATED_BEHANDELVOORSTEL_BPV01, null);

        var body = getCreateBehandelVoorstelRequest();
        when(batRegisterBehandelvoorstelServiceMock.createBehandelVoorstel(body))
                .thenReturn(expected);
        mockMvc.perform(post("/api/behandelvoorstel/create")
                        .content(objectMapper.writeValueAsString(body))
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(expected, BehandelVoorstelResponse.class));
    }

    @Test
    void getBehandelvoorstelOptions() throws Exception {
        List<BehandelvoorstelOption> expected = List.of(
                new BehandelvoorstelOption(VOORSTEL_TYPE_HEF01_TEST, STATUS_CODES));
        when(batRegisterBehandelvoorstelServiceMock.getBehandelvoorstelOptions()).thenReturn(expected);
        mockMvc.perform(get("/api/behandelvoorstel/options"))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(expected, BehandelvoorstelOption.class));
    }

    @Test
    void getRegisterBehandelvoorstelUrl() throws Exception {
        RegisterBehandelvoorstelUrl mockedUrl = new RegisterBehandelvoorstelUrl("https://test/bat/url");
        var expected = objectMapper.convertValue(mockedUrl, Map.class);
        when(apiServiceApplicationPropertiesMock.getRegisterBehandelvoorstelUrl()).thenReturn(mockedUrl.getUrl());
        mockMvc.perform(get("/api/behandelvoorstel/register-behandelvoorstel-url"))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(expected, Object.class));
    }

    @Test
    void getEditToken() throws Exception {
        var expected = new BehandelVoorstelResponse(null, CREATED_TOKEN);

        var body = getCreateBehandelVoorstelRequest();
        when(batRegisterBehandelvoorstelServiceMock.getToken(any())).thenReturn(CREATED_TOKEN);
        mockMvc.perform(post("/api/behandelvoorstel/view-or-delete-token")
                .content(objectMapper.writeValueAsString(body))
                .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(expected, BehandelVoorstelResponse.class));
    }

    @Test
    void getEditTokenWithNotLoggedInUser() throws Exception {
        var body = getCreateBehandelVoorstelRequest();
        when(authentication.getName()).thenThrow(new NullPointerException("User is not found"));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        body.setUserId(null);

        this.mockMvc.perform(
                        post("/api/behandelvoorstel/view-or-delete-token")
                                .content(objectMapper.writeValueAsString(body))
                                .contentType(JSON))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(username = "ivatest2", authorities = { "AUG_KBS_RAADPLEGER", "AUG_KBS_BEHANDELAAR"})
    void getTokenWhenHasBothGroupsAndActionTypeDelete() throws Exception {
        var expected = new BehandelVoorstelResponse(null, CREATED_TOKEN);

        var body = getCreateBehandelVoorstelRequest();
        body.setVoorstelAction(BehandelVoorstelRequestDto.VOORSTEL_ACTION_DELETE);

        when(batRegisterBehandelvoorstelServiceMock.getToken(any())).thenReturn(CREATED_TOKEN);

        this.mockMvc.perform(post("/api/behandelvoorstel/view-or-delete-token")
                                .content(objectMapper.writeValueAsString(body))
                                .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(expected, BehandelVoorstelResponse.class));
    }

    @Test
    @WithMockUser(username = "ivatest2", authorities = { "AUG_KBS_RAADPLEGER"})
    void getTokenWhenRaadplegerAndActionTypeDelete() throws Exception {
        var body = getCreateBehandelVoorstelRequest();
        body.setVoorstelAction(BehandelVoorstelRequestDto.VOORSTEL_ACTION_DELETE);

        this.mockMvc.perform(post("/api/behandelvoorstel/view-or-delete-token")
                                .content(objectMapper.writeValueAsString(body))
                                .contentType(JSON))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void getBandelVoorstellen() throws Exception {
        var behandelVoorstellen = getBehandelVoorstellen();
        List<BehandelActiviteit> expected = createResultList();
        Activiteit batRegisterbehandelActiviteitcodes = getActiviteit();

        when(batGegevensServiceMock.getBehandelVoorstellen(1234L)).thenReturn(behandelVoorstellen);
        when(batGegevensServiceMock.getBehandelActiviteitCodes()).thenReturn(ACTIVITEIT_CODES);
        when(batGegevensServiceMock.getStatusCodes()).thenReturn(STATUS_CODES);
        when(batRegisterBehandelvoorstelServiceMock.getBehandelActiviteitcodes()).thenReturn(batRegisterbehandelActiviteitcodes);

        mockMvc.perform(get("/api/behandelvoorstel/{entiteitId}/{entiteitNaam}", 1234, "testnaam"))
                .andExpect(status().isOk())
                .andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(expected, BehandelActiviteit.class));
    }

    private List<BehandelActiviteit> createResultList() {
        BehandelActiviteit a1 = new BehandelActiviteit("a6a932e1-62b3-42a8-b997-f12c1082f8d6","1000081",
                "testnaam", null, List.of("Onbekend"), "Onbekend", null,
                null, "BPV01", "ENT", null);
        BehandelActiviteit a2 = new BehandelActiviteit("695588de-8929-42c2-a61c-b14b04257f92",
                "1000081",
                "testnaam", null, List.of("Onbekend"), "Onbekend",
                null,
                null, "BPV01", "ENT", null);
        return List.of(a1,a2);
    }

    private BatBehandelvoorstelResponse getBehandelVoorstellen() {
        BatBehandelplanvoorstel b1 = getBatBatBehandelplanvoorstel("a6a932e1-62b3-42a8-b997-f12c1082f8d6",
                "2023-01-31T08:17:08.647488","behandelopdracht1","5f07746d-4abf-471c-a371-d664f073b93a");
        BatBehandelplanvoorstel b2 = getBatBatBehandelplanvoorstel("695588de-8929-42c2-a61c-b14b04257f92",
                "2023-01-30T16:47:09.101159","behandelopdract2","04547474-d903-43b5-9562-f02d357b203b");

        BatHeffing h1= new BatHeffing();

        h1.setBehandelVoorstelReference(b1.getBehandelVoorstelReference());
        h1.setCreated(b1.getCreated());
        h1.setCreatedBy(b1.getCreatedBy());
        h1.setSubjectId(b1.getSubjectId());
        h1.setStatus(b1.getStatus());
        h1.setSubjectType(b1.getSubjectType());
        h1.setVoorstelType(b1.getVoorstelType());
        h1.setPersonen(b1.getPersonen());
        h1.setInOpdrachtDoor(b1.getInOpdrachtDoor());
        h1.setShortIdZaak("078133541");
        h1.setBehandelActiviteit("AB");
        h1.setStartTijdvak("2023-01-01");
        h1.setEindeTijdvak("2023-01-19");
        h1.setAanpak("T");
        h1.setAanleiding("UCS");
        h1.setUitvoeringToezicht("TOEZICHT");
        h1.setGewensteDiepgang("M");
        h1.setPrioriteitJaarplan(List.of());
        h1.setInschattingBelang(null);
        h1.setFiscaalRisico(null);
        h1.setAlgemeneRisico(List.of());
        h1.setWeglekBalans(List.of());
        h1.setBenodigdeCapaciteit("#TM8");
        h1.setFunctieniveau(null);
        h1.setVoorgesteldeBehandelaar(null);
        h1.setRisicoGemeldDoorKlant("false");
        h1.setToelichting("Ipsum Lorem Sic Hora Est!");

        BatBehandelvoorstelResponse behandelVoorstellen = new BatBehandelvoorstelResponse();
        behandelVoorstellen.setBehandelopdrachtenMDR(List.of());
        behandelVoorstellen.setBoekenOnderzoeken(List.of());
        behandelVoorstellen.setBoekenOnderzoekenOverig(List.of());
        behandelVoorstellen.setBoekenOnderzoekenInvordering(List.of());
        behandelVoorstellen.setBoekenOnderzoekenOverigGo(List.of());
        behandelVoorstellen.setBoekenOnderzoeken(List.of());
        behandelVoorstellen.setBoekenOnderzoekenOverigMkb(List.of());
        behandelVoorstellen.setBehandelplanVoorstellen(List.of(b1,b2));
        behandelVoorstellen.setHeffingen(List.of(h1));
        return behandelVoorstellen;
    }

    private Activiteit getActiviteit() {
        Activiteit activiteit = new Activiteit();
        Activiteit.ActiviteitenVanVoorstel testCodes = new Activiteit.ActiviteitenVanVoorstel();
        testCodes.setActiviteiten(ACTIVITEIT_CODES);
        Map<String, Activiteit.ActiviteitenVanVoorstel> activiteitenPerVoorstelCode =  Map.of("HEF01", testCodes);
        activiteit.setActiviteitenPerVoorstelCode(activiteitenPerVoorstelCode);
        return activiteit;
    }

    private BatBehandelplanvoorstel getBatBatBehandelplanvoorstel(String behandelVoorstelRef,
            String created, String inOpdrachtDoor,String ZoekId) {
        return new BatBehandelplanvoorstel(
                "",
                behandelVoorstelRef,
                created,
                "ivatest1",
                new ArrayList<BatDocument>(),
                null,
                inOpdrachtDoor,
                new ArrayList<BatPersoon>(),
                2L,
                "INPROGRESS",
                "1000081",
                "ENT",
                new ArrayList<BatTeam>(),
                new ArrayList<BatToelichting>(),
                "BPV01",
                ZoekId
        );
    }
}
