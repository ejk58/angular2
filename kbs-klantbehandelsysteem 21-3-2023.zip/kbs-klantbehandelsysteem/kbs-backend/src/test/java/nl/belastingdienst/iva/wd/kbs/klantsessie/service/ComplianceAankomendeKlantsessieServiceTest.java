package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieUitkomstRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ComplianceAankomendeKlantsessieDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieUitkomst;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

/**
 * @author hubeh00
 */
@SpringBootKbsTest
class ComplianceAankomendeKlantsessieServiceTest {
	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";
	@MockBean
	KlantsessieService klantsessieServiceMock;
	@Autowired
	ComplianceAankomendeKlantsessieService sutService;
	@Autowired
	KlantSessieUitkomstRepository klantsessieUitkomstRepository;
	@MockBean
	Logging2Service logging2ServiceMock;

	@Autowired
	KenmerkRepository kenmerkRepository;
	private static final Long KLANTSESSIE_ID = 1L;
	private static final Kenmerk PARENT_KENMERK_1 = new Kenmerk(1, "KS_CAT", "Parent 1", null);
	private static final Kenmerk PARENT_KENMERK_2 = new Kenmerk(2, "KS_CAT", "Parent 2", null);
	private static final Kenmerk CHILD_KENMERK_1_A = new Kenmerk(10, "KS_CAT", "Child parent 1a", 1);
	private static final Kenmerk CHILD_KENMERK_1_B = new Kenmerk(11, "KS_CAT", "Child parent 1b", 1);
	private static final Kenmerk CHILD_KENMERK_2_A = new Kenmerk(20, "KS_CAT", "Child parent 2a", 2);
	private static final Kenmerk CHILD_KENMERK_2_B = new Kenmerk(21, "KS_CAT", "Child parent 2b", 2);
	private static final Kenmerk NON_RELATING_KENMERK = new Kenmerk(999, "OTHER", "Should not be included", 998);
	private static final List<Kenmerk> KENMERK_LIST = List.of(PARENT_KENMERK_1, PARENT_KENMERK_2, CHILD_KENMERK_1_A,
			CHILD_KENMERK_1_B, CHILD_KENMERK_2_A, CHILD_KENMERK_2_B, NON_RELATING_KENMERK);

	@BeforeEach
	void setUp() {

		kenmerkRepository.saveAll(KENMERK_LIST);

		this.klantsessieUitkomstRepository.saveAll(
				List.of(new KlantsessieUitkomst(KLANTSESSIE_ID, CHILD_KENMERK_1_A.getId(), 2, 3, null),
						new KlantsessieUitkomst(KLANTSESSIE_ID, CHILD_KENMERK_2_A.getId(), 2, 3, "wel toelichting")

				));

	}

	@Test
	void getCurrentKlantsessie() {
		var ks = new Klantsessie(KLANTSESSIE_ID);
		ks.setId(KLANTSESSIE_ID);

		when(klantsessieServiceMock.getCurrentKlantsessie(anyLong())).thenReturn(ks);

		List<ComplianceAankomendeKlantsessieDto> result = sutService
				.getCurrentKlantsessie(KLANTSESSIE_ID);
		assertEquals(2, result.size());
		assertEquals(2, result.get(0).getUitkomsten().size());
		assertEquals(2, result.get(1).getUitkomsten().size());

		assertEquals(List.of(
				new ComplianceAankomendeKlantsessieDto(
						PARENT_KENMERK_1.getKenmerk(),
						List.of(
								new ComplianceAankomendeKlantsessieDto.ComplianceUitkomst(CHILD_KENMERK_1_A.getId(),
										CHILD_KENMERK_1_A.getKenmerk(), 2,3, null),
								new ComplianceAankomendeKlantsessieDto.ComplianceUitkomst(CHILD_KENMERK_1_B.getId(),
										CHILD_KENMERK_1_B.getKenmerk(), null,null, null)
						)
				),
				new ComplianceAankomendeKlantsessieDto(
						PARENT_KENMERK_2.getKenmerk(),
						List.of(
								new ComplianceAankomendeKlantsessieDto.ComplianceUitkomst(CHILD_KENMERK_2_A.getId(),
										CHILD_KENMERK_2_A.getKenmerk(), 2,3, "wel toelichting"),
								new ComplianceAankomendeKlantsessieDto.ComplianceUitkomst(CHILD_KENMERK_2_B.getId(),
										CHILD_KENMERK_2_B.getKenmerk(), null,null, null)
						)
				)
		), result);
	}

	@Test
	void updateResultaat() {
		var ks = new Klantsessie(KLANTSESSIE_ID);
		ks.setId(KLANTSESSIE_ID);
		when(klantsessieServiceMock.getCurrentKlantsessie(anyLong())).thenReturn(ks);

		List<ComplianceAankomendeKlantsessieDto> result = sutService.getCurrentKlantsessie(
				KLANTSESSIE_ID);
		Integer oldScore = result.get(0).getUitkomsten().get(0).getScore();
		assertEquals(2, oldScore);

		ComplianceAankomendeKlantsessieDto.ComplianceUitkomst complianceUitkomst = result.get(0).getUitkomsten().get(0);
		complianceUitkomst.setScore(oldScore + 1);
		KlantsessieUitkomst updatedResult = sutService.updateResultaat(ks.getEntiteitNummer(),
				complianceUitkomst, TEST_LOGGING_ID_1);

		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, ks.getEntiteitNummer(), Logging2.Bewerking.UPDATE);

		Integer newScore = updatedResult.getScore();
		assertEquals(3, newScore);
	}
}
