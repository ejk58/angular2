package nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie;

import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStrategieRisicosRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class DeleteSelectedRisicoServiceTest {


	public static final MiddelRisico MIDDEL_RISICO_1 = new MiddelRisico(1L, 12, "risico 1", null, null);
	public static final MiddelRisico MIDDEL_RISICO_2 = new MiddelRisico(2L, 12, "risico 2", null, null);
	public static final MiddelRisico MIDDEL_RISICO_3 = new MiddelRisico(3L, 24, "risico 3", null, null);
	public static final MiddelRisico MIDDEL_RISICO_4 = new MiddelRisico(4L, 12, "risico 4", null, null);
	public static final List<KlantsessieStrategieRisico> KLANTSESSIE_STRATEGIE_RISICO_LIST = List.of(
			new KlantsessieStrategieRisico(1L, 12, MIDDEL_RISICO_1.getId(), MIDDEL_RISICO_1),
			new KlantsessieStrategieRisico(1L, 12, MIDDEL_RISICO_4.getId(), MIDDEL_RISICO_4),
			new KlantsessieStrategieRisico(1L, 24, MIDDEL_RISICO_3.getId(), MIDDEL_RISICO_3),
			new KlantsessieStrategieRisico(2L, 12, MIDDEL_RISICO_2.getId(), MIDDEL_RISICO_2));

	@Autowired
	DeleteSelectedRisicoService sut;

	@Autowired
	KlantsessieStrategieRisicosRepository klantsessieStrategieRisicosRepository;

	@MockBean
	KlantsessieService klantsessieService;

	@Autowired
	MiddelRisicoRepository middelRisicoRepository;

	@BeforeEach
	void setUp() {
		this.middelRisicoRepository.saveAll(
				List.of(MIDDEL_RISICO_1, MIDDEL_RISICO_2, MIDDEL_RISICO_3, MIDDEL_RISICO_4)
		);

		this.klantsessieStrategieRisicosRepository.saveAll(KLANTSESSIE_STRATEGIE_RISICO_LIST);
	}

	@Test
	void deleteBy() {
		this.stubKlantsessieService();
		this.sut.deleteBy(999L, 4L);

		Assertions.assertEquals(
				KLANTSESSIE_STRATEGIE_RISICO_LIST.stream()
												 .filter(ksr -> !ksr.getRisicoId().equals(4L))
												 .collect(Collectors.toList()),
				this.klantsessieStrategieRisicosRepository.findAll()
		);


	}

	private void stubKlantsessieService() {
		when(klantsessieService.getCurrentKlantsessie(999L)).thenReturn(new Klantsessie(1L, null, null,null,null,null,null,null));
	}
}