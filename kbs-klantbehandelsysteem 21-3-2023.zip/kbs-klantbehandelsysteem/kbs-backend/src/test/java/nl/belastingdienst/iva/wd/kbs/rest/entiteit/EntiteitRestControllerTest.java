package nl.belastingdienst.iva.wd.kbs.rest.entiteit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import nl.belastingdienst.iva.wd.kbs.domain.Convenantindicatie;
import nl.belastingdienst.iva.wd.kbs.domain.Entiteit;
import nl.belastingdienst.iva.wd.kbs.kta.domain.KzbAlgemeneGegevensEntiteit;
import nl.belastingdienst.iva.wd.kbs.mappings.EntiteitConvenantindicatieMapper;
import nl.belastingdienst.iva.wd.kbs.rest.FakeResponseTime;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitConvenantindicatieService;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitService;

@ExtendWith(MockitoExtension.class)
class EntiteitRestControllerTest {

	@Mock
	private EntiteitService mockService;

	@Mock
	private EntiteitConvenantindicatieService mockEntiteitConvenantindicatieService;

	@Spy
	private EntiteitConvenantindicatieMapper entiteitConvenantindicatieMapper = Mappers.getMapper(EntiteitConvenantindicatieMapper.class);

	@Mock
	private FakeResponseTime fakeResponseTime;

	@InjectMocks
	private EntiteitRestController sut;

	@Test
	void testGetEntiteit_ShouldThrowHttp404NotFound_WhenEntiteitNummerIsUnknown() {
		assertHttpStatusNotFound(() -> sut.getEntiteit(1L), "Unknown entiteitNummer!");
	}

	@Test
	void testGetEntiteit_ShouldReturnMatchingEntiteit_WhenEntiteitNummerIsValid() {
		var e = new Entiteit();
		e.setNummer(1L);
		e.setNaam("DummyEntiteit1");
		when(mockService.findByNummer(any())).thenReturn(Optional.of(e));

		var result = sut.getEntiteit(1L);
		assertNotNull(result);
		assertEquals(1L, result.getNummer());
		assertEquals("DummyEntiteit1", result.getNaam());
	}

	@Test
	void testGetConvenantindicatie_ShouldReturnConvenantindicatie_WhenConvenantindicatieJ() {
		createAndAssertConvenantindicatie(1000L, "J");
	}

	@Test
	void testGetConvenantindicatie_ShouldReturnConvenantindicatie_WhenConvenantindicatieN() {
		createAndAssertConvenantindicatie(2000L, "N");
	}

	@Test
	void testGetConvenantindicatie_ShouldReturnConvenantindicatie_WhenEntiteitnummerNotFound() {
		assertHttpStatusNotFound(() -> sut.getConvenantindicatie(1L), "No convenantindicatie found for entiteitNummer!");
	}

	private void createAndAssertConvenantindicatie(long entiteitnummer, String convenantindicatieValue) {
		KzbAlgemeneGegevensEntiteit algemeneGegevensEntiteit = new KzbAlgemeneGegevensEntiteit();
		algemeneGegevensEntiteit.setEntiteitnummer(entiteitnummer);
		algemeneGegevensEntiteit.setConvenantindicatie(convenantindicatieValue);

		Convenantindicatie convenantindicatieMapped = this.entiteitConvenantindicatieMapper.map(algemeneGegevensEntiteit);

		Optional<Convenantindicatie> convenantindicatie = Optional.of(convenantindicatieMapped);

		when(mockEntiteitConvenantindicatieService.findByNummer(entiteitnummer)).thenReturn(convenantindicatie);

		assertEquals(convenantindicatieValue, sut.getConvenantindicatie(entiteitnummer)
												 .getValue());
	}

	private void assertHttpStatusNotFound(Executable executable, String reason) {
		var t = assertThrows(ResponseStatusException.class, executable);
		assertEquals(HttpStatus.NOT_FOUND, t.getStatus());
		assertEquals(reason, t.getReason());
	}
}