package nl.belastingdienst.iva.wd.kbs.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;

import nl.belastingdienst.iva.wd.kbs.domain.Helptext;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.service.HelptextService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;

@WebMvcTest(controllers = HelptextController.class)
@ExtendWith(MockitoExtension.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class HelptextControllerTest {

	@MockBean
	private HelptextService serviceMock;

	@Autowired
	private HelptextController sut;

	@ParameterizedTest
	@MethodSource("provideStoreHelptext_SanitizesHtmlFully_Input_Expected")
	void storeHelptext_SanitizesHtmlFully_BeforeSavingHelptext(String input, String expectedHtml) {
		when(serviceMock.getHelptextForEntiteit(any(), any())).thenReturn(Optional.empty());

		Helptext h = new Helptext();
		h.setTxt(input);
		sut.storeHelptext(new LoggingWrapper<>("testid1", h));

		ArgumentCaptor<Helptext> argument = ArgumentCaptor.forClass(Helptext.class);
		verify(serviceMock).saveHelptext(argument.capture(), any());
		String actualHtml = argument.getValue().getTxt();
		assertEquals(expectedHtml, actualHtml);
	}

	private static Stream<Arguments> provideStoreHelptext_SanitizesHtmlFully_Input_Expected() {
		return Stream.of(
				Arguments.of(
						// Rearrange/add/overwrite target and rel atribute values, missing HTTPS scheme should be added
						"<p><a rel=\"noopener noreferrer\" href=\"mailto:jm_dekker@belastingdienst.nl\" target=\"_blank\">jm_dekker@belastingdienst.nl</a></p>\n"
								+ "<p><a href=\"https://intranet.belastingdienst.nl/\" rel=\"noopener noreferrer\" target=\"_blank\">https://intranet.belastingdienst.nl/</a></p>\n"
								+ "<p><a href=\"www.example.org\" rel=\"noopener noreferrer\" target=\"_blank\">www.example.org</a></p>\n"
								+ "<p><a href=\"example.org\" rel=\"noopener noreferrer\" target=\"_blank\">example.org</a></p>\n"
								+ "<p><a href=\"//example.org\" rel=\"noopener noreferrer\" target=\"_blank\">example.org</a></p>\n"
								+ "<p><ahref=\"//example.org\" rel=\"noopener noreferrer\" target=\"_blank\">example.org</a></p>\n"
								+ "<p>Nog geen toelichting aangemaakt.</p>\n" + "<p>jm_dekker@belastingdienst.nl</p>\n"
								+ "<p><a rel=\"noopener noreferrer\" href=\"jm_dekker@belastingdienst.nl\" target=\"_blank\">jm_dekker@belastingdienst.nl</a></p>\n"
								// Href should point to https://Belastingtelefoon because tel: scheme is not allowed
								+ "<p><a href=\"tel:0031613245678\" >Belastingtelefoon</a>,</p>\n" + "<p><br></p>\n"
								+ "<p>Klantbeeld (KTA), Company.info,&nbsp;<a href=\"http://INTERNETSERVICE4U.belastingdienst.nl/\" rel=\"noopener noreferrer\" target=\"_blank\">http://INTERNETSERVICE4U.belastingdienst.nl/</a></p>\n"
								// Href should point to connectpeople.belastingdienst.nl
								+ "<p><a href=\"https://evil-corp.example.org\" rel=\"noopener noreferrer\" target=\"_blank\">https://connectpeople.belastingdienst.nl/</a></p>\n"
								+ "<p><br></p>\n"
								+ "<p>In het tekstveld dient een screenshot opgenomen te worden van “<a href=\"intranet.belastingdienst.nl\" rel=\"noopener noreferrer\" target=\"_blank\">Totalen aanslagen per jaar VPB</a>” in KTA, op het niveau van de gehele entiteit</p>\n"
								+ "<p><br></p>\n"
								+ "<p><a href=\"https://jira.belastingdienst.nl/secure/RapidBoard.jspa?rapidView=1977&amp;view=detail&amp;selectedIssue=IVAKBS-141\" rel=\"noopener noreferrer\" target=\"_blank\">https://jira.belastingdienst.nl/secure/RapidBoard.jspa?rapidView=1977&amp;view=detail&amp;selectedIssue=IVAKBS-141</a></p>\n"
								// Script elements are not allowed
								+ "<p><script>alert('XSS_VULNERABILITY_FROM_DB')</script></p>\n"
								+ "<p><script type=\"text/javascript\">alert('XSS_VULNERABILITY_FROM_DB')</script></p><p>SANITIZATION_SUCCESSFUL</p>'\n"
								// Invalid images
								+ "<p><img></p>\n" + "<p><img /></p>\n" + "<p><img src=\"\"></p>\n" + "<p><img src=\"a.jpg\"></p>\n"
								+ "<p><img src=\"//example.org/a.jpg\"></p>\n" + "<p><img src=\"http://example.org/a.jpg\"></p>\n"
								+ "<p><img src=\"https://example.org/a.jpg\"></p>\n"
								+ "<p><img src=\"data:image/jpg;base63,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n"
								// Valid images
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n"
								+ "<p><img src=\"data:image/JPG;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n" // Case-insensitive
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" ></p>\n"
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"\\></p>\n"
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" \\></p>\n"
								// Alt should be stripped
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" alt=\"Afbeelding\"></p>\n"
								// Support various common image formats
								+ "<p><img src=\"data:image/gif;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n"
								+ "<p><img src=\"data:image/png;base64,iVBO_LONG-BASE64-STRING-HERE_CC\"></p>\n"
								// Various xss tests
								+ "<img src=x onerror=\"&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000088&#0000083&#0000083&#0000039&#0000041\">\n"
								+ "\\<a onmouseover=\"alert(document.cookie)\"\\>xxs link\\</a\\>\n"
								+ "<a aa aaa aaaa aaaaa aaaaaa aaaaaaa aaaaaaaa aaaaaaaaa aaaaaaaaaa href=j&#97v&#97script:&#97lert(1)>ClickMe\n",
						// Rearranged/added/overwrote target and rel atribute values, href has HTTPS scheme where missing
						"<p><a href=\"mailto:jm_dekker&#64;belastingdienst.nl\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">jm_dekker&#64;belastingdienst.nl</a></p>\n"
								+ "<p><a href=\"https://intranet.belastingdienst.nl/\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">https://intranet.belastingdienst.nl/</a></p>\n"
								+ "<p><a href=\"https://www.example.org\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">www.example.org</a></p>\n"
								+ "<p><a href=\"https://example.org\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">example.org</a></p>\n"
								+ "<p><a href=\"https://example.org\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">example.org</a></p>\n"
								+ "<p>example.org</p>\n" + "<p>Nog geen toelichting aangemaakt.</p>\n"
								+ "<p>jm_dekker&#64;belastingdienst.nl</p>\n"
								+ "<p><a href=\"mailto:jm_dekker&#64;belastingdienst.nl\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">jm_dekker&#64;belastingdienst.nl</a></p>\n"
								// Href points to Belastingtelefoon with HTTPS scheme
								+ "<p><a href=\"https://Belastingtelefoon\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">Belastingtelefoon</a>,</p>\n"
								+ "<p><br /></p>\n"
								+ "<p>Klantbeeld (KTA), Company.info, <a href=\"http://INTERNETSERVICE4U.belastingdienst.nl/\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">http://INTERNETSERVICE4U.belastingdienst.nl/</a></p>\n"
								// Href points to connectpeople.belastingdienst.nl
								+ "<p><a href=\"https://connectpeople.belastingdienst.nl/\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">https://connectpeople.belastingdienst.nl/</a></p>\n"
								+ "<p><br /></p>\n"
								+ "<p>In het tekstveld dient een screenshot opgenomen te worden van “<a href=\"https://Totalen%20aanslagen%20per%20jaar%20VPB\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">Totalen aanslagen per jaar VPB</a>” in KTA, op het niveau van de gehele entiteit</p>\n"
								+ "<p><br /></p>\n"
								+ "<p><a href=\"https://jira.belastingdienst.nl/secure/RapidBoard.jspa?rapidView&#61;1977&amp;view&#61;detail&amp;selectedIssue&#61;IVAKBS-141\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">https://jira.belastingdienst.nl/secure/RapidBoard.jspa?rapidView&#61;1977&amp;view&#61;detail&amp;selectedIssue&#61;IVAKBS-141</a></p>\n"
								// Script elements have been stripped
								+ "<p></p>\n" + "<p></p><p>SANITIZATION_SUCCESSFUL</p>&#39;\n"
								// Invalid images have been stripped
								+ "<p></p>\n" + "<p></p>\n" + "<p></p>\n" + "<p></p>\n" + "<p></p>\n" + "<p></p>\n" + "<p></p>\n"
								+ "<p></p>\n"
								// Valid images
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
								+ "<p><img src=\"data:image/JPG;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n" // Case-insensitive
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
								// Alt has been stripped
								+ "<p><img src=\"data:image/jpg;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
								// Support various common image formats
								+ "<p><img src=\"data:image/gif;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
								+ "<p><img src=\"data:image/png;base64,iVBO_LONG-BASE64-STRING-HERE_CC\" /></p>\n"
								// Various xss test
								+ "\n" + "\\<a target=\"_blank\">xxs link\\\n" + "</a>"
								+ "<a href=\"j&amp;#97v&amp;#97script:&amp;#97lert%281%29\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">ClickMe\n"
								+ "</a>"
				),
				Arguments.of(
						"<p>Toelichting <em>robot</em> <u>test </u><strong>text</strong> "
								+ "<s>2021</s>-12-28 13:18:37</p><ol><li>test</li><li>inspring</li><li>meerdere</li><li class=\"ql-indent-1\">en erin"
								+ "</li></ol><p><br></p><blockquote>quote</blockquote><p><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABg"
								+ "AAAAKICAIAAAA5IKaaAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv/++T+PFXM4SwG5wwAAAABJRU5ErkJggg==\"></p>"
								+ "<h1>heading1</h1><h2>h2</h2><p><br></p><h3>h3</h3><ul><li>testing</li></ul>",
						"<p>Toelichting <em>robot</em> <u>test </u><strong>text</strong> "
								+ "<s>2021</s>-12-28 13:18:37</p><ol><li>test</li><li>inspring</li><li>meerdere</li><li class=\"ql-indent-1\">en erin"
								+ "</li></ol><p><br /></p><blockquote>quote</blockquote><p><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABg"
								+ "AAAAKICAIAAAA5IKaaAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv/&#43;&#43;T&#43;PFXM4SwG5wwAAAABJRU5ErkJggg&#61;&#61;\" /></p>"
								+ "<h1>heading1</h1><h2>h2</h2><p><br /></p><h3>h3</h3><ul><li>testing</li></ul>"
				),
				Arguments.of(
						"<p>Normal</p><p class=\"ql-indent-1\">Inspringing</p><h1>H1</h1><h2>H2</h2><h3>H3</h3>"
								+ "<p><strong>Bold</strong></p><p><em>Italic</em></p><p><u>Underlined</u></p>"
								+ "<p><s>Strikethrough</s></p><p><strong><em><s><u>Combinatie</u></s></em></strong></p>"
								+ "<h1 class=\"ql-indent-1\"><strong><em><s><u>Combinatie 1</u></s></em></strong></h1>"
								+ "<blockquote><strong><em><s><u>Combinatie 2</u></s></em></strong></blockquote>"
								+ "<ol><li><strong><em><s><u>Combinatie 3</u></s></em></strong></li></ol>"
								+ "<ul><li><strong><em><s><u>Combinatie 4</u></s></em></strong></li></ul>"
								+ "<blockquote>Quote Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusus "
								+ "viverra accumsan in nisl. Urna neque viverra justo nec ultrices dui sapien eget. Urna id "
								+ "volutpat lacus laoreet non curabitur gravida arcu ac. Sagittis vitae et leo duis ut. Sed "
								+ "risus pretium quam vulputate dignissim. Nisl purus in mollis nunc sed id semper risus in."
								+ "</blockquote><blockquote class=\"ql-indent-1\">Augue lacus viverra vitae congue eu consequat "
								+ "ac felis. Orci eu lobortis</blockquote><ol><li>Numbered list</li><li>a</li>"
								+ "<li class=\"ql-indent-1\">d</li><li class=\"ql-indent-2\">d</li><li class=\"ql-indent-2\">d</li>"
								+ "<li class=\"ql-indent-3\">d</li><li class=\"ql-indent-3\">d</li><li class=\"ql-indent-2\">d</li>"
								+ "<li class=\"ql-indent-1\">d</li><li>d</li></ol><ul><li>Bullet points</li><li>d</li>"
								+ "<li class=\"ql-indent-1\">d</li><li class=\"ql-indent-2\">d</li><li class=\"ql-indent-4\">d</li>"
								+ "<li class=\"ql-indent-7\">d</li><li class=\"ql-indent-5\">d</li><li class=\"ql-indent-3\">d</li>"
								+ "<li>daa</li></ul><p><br></p><p>Links:</p>"
								+ "<p><a href=\"mailto:test@example.org\" rel=\"noopener noreferrer\" target=\"_blank\">"
								+ "test@example.org</a></p><p><a href=\"https://www.belastingdienst.nl\" rel=\"noopener noreferrer\" "
								+ "target=\"_blank\">www.belastingdienst.nl</a></p>"
								+ "<p><a href=\"https://ont-wd-kbs.apps.cn01.chp.belastingdienst.nl/#/authenticated/zicht-op-organisatie/bedrijfsactiviteiten\" "
								+ "rel=\"noopener noreferrer\" target=\"_blank\">https://ont-wd-kbs.apps.cn01.chp.belastingdienst.nl/#/authenticated/zicht-op-organisatie/bedrijfsactiviteiten</a></p>"
								+ "<p><br></p><p>Plaatje:</p>"
								+ "<p><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAmCAYAAAA820BcAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAT2SURBVFhH7VdLbxtVFD4znnH8jF1KSZYEKFIjQYuSIsGSPpZURSReoEplBaxQBUIgNqwRqELiUX4CLRuKsimULugqUtQgQVjRTUofbBzb8Tge2zOc79w5zszUTipAZAFfdHMf53nPOffesXX02edD2iPYUb8n+O8aH5nzMAzJsqxoRtTr+uT3fer1ejQYDCgIAlm3bZsymQy5rkuuk6XsRFbWgbSOUbjPuAqh97tdanttGvT7sARixJUC+Nkhx3GoUCxRbmJClndzIBF2ZcYOG40NaraaslMxyTTQRzX+J/LgbTYaLFsXHbqJcRgaBxOYt3i3MNzn3SK8cWHdBfr4WGF4AzbcZx0N6rIu0Mc5IMbVsO93abPVkDkacqrKVQFyjPCiYQwoDbyWZUfyAbU4cjs5YGMRRHgLZvAoY1xAnWi1WnTv3h/SMAaUBsRl0TY3m6J7lAPW/NHneC2kxgaHGvlljxUqgB4pQB5PnXqRjh17QehXv79K31z+VqodUVLeuBFEwuEIVapVoaEppNo7HY893EwcoTiwjvbxRx/S4uJCtGpw8eIleuvtd0RmlByA9VKpTPl8XuYKGxXa8Tpmwkz3e26R1+nQmTOviGHwoxjRMMZarbYgPPFdaRTUIWxQnVHYfVwcAcIdChECcSU6f+n0aaGDTwtOZWq1xbFyKjPoDyRtcdh6HgH0YIxD58ViUXrlQVO5MocUGCWrPGSjqH0zjiDGVQiMQ+YIamx5eVlCiFArMMbaj9evJw1FSOhjuu+njEOBGtc+DoQty9X86Wef0/r6OmWz2aFSjLF24cKXwgPeNOK6g0GSnqlUH/pAvRt6GUF3AyP1ep1+uHZNKnZ6apo8vvMv8zF797336dat3ymXywm/yijSujV9gPXozBPiWloIc9xgA97NFlcyIuRziqanpmhmZkZoN2/+Rrdv3xXnHCcjDmhq0rp0fuDAI9ID1mOPPxnG8wgmNdxut+UCmZ+foxPHj9Phw0/RFBuH97adkbvhzt07tHrjJ1paWqKff1mTigZdHYAuBXTu3/9wNGNbBw8eCnt9U3TKDO89z6Nnjhyhc+fepJMnT0TsO+PKle/o/PlP6MbqKhUKBakB1YnedVyq7tsXcbPx2dmnQ2+rI+8xAMN4DGZnD9HXl76iSqWSqHAAioD4rrAGWbxmLy/UaG3tV5rgd12LELR8Lk/FUknmgO1wWCnYrkgwIZyvnj0rhuEI1hAy7WEITdeQAszBCxnIQgdo6iB8cF1HxgpbbqtIIZh5DyKAqtY7ADvX61T75Nj04IUMZI1Ro1McdfiBcbc/swAb3ucK5sI3OTJ9sViQYkMF63W6WwMvZCAb1wUU2CGzuW0Mn9QNflLhvc3XIPL2xuuv0dzcHAtjzXw07AblXVlZoS/44kEKAk7p2CcVxrGAB7/ZrPO55rzzHB8KyCFCx9UgzLvD8KLQyuUylxIfWd5tpVKVyGCTCeN4z3XR727xR2NrKJQO04MCoTbhtmhysszOmNsvbhgYfjorEbs1n0fmuVSoYFxJemyAE8MFzH/YfZajMMowMNwaiGBCyKocJlwIAFKgUAPo42OF4bXlB8Qk69jJMJCIqzrg8HlEgaBg+CwqUeijGv+TbPPRYZlJlq3Imd7JMPBAP5d8/rnUG/NzCQbxnGZ5t+7f/bn0b+KvlfM/hP+N7wn20DjRn1XGOZWBTG0tAAAAAElFTkSuQmCC\"></p></div>",
						"<p>Normal</p><p class=\"ql-indent-1\">Inspringing</p><h1>H1</h1><h2>H2</h2><h3>H3</h3>"
								+ "<p><strong>Bold</strong></p><p><em>Italic</em></p><p><u>Underlined</u></p>"
								+ "<p><s>Strikethrough</s></p><p><strong><em><s><u>Combinatie</u></s></em></strong></p>"
								+ "<h1 class=\"ql-indent-1\"><strong><em><s><u>Combinatie 1</u></s></em></strong></h1>"
								+ "<blockquote><strong><em><s><u>Combinatie 2</u></s></em></strong></blockquote>"
								+ "<ol><li><strong><em><s><u>Combinatie 3</u></s></em></strong></li></ol>"
								+ "<ul><li><strong><em><s><u>Combinatie 4</u></s></em></strong></li></ul>"
								+ "<blockquote>Quote Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusus "
								+ "viverra accumsan in nisl. Urna neque viverra justo nec ultrices dui sapien eget. Urna id "
								+ "volutpat lacus laoreet non curabitur gravida arcu ac. Sagittis vitae et leo duis ut. Sed "
								+ "risus pretium quam vulputate dignissim. Nisl purus in mollis nunc sed id semper risus in."
								+ "</blockquote><blockquote class=\"ql-indent-1\">Augue lacus viverra vitae congue eu consequat "
								+ "ac felis. Orci eu lobortis</blockquote><ol><li>Numbered list</li><li>a</li>"
								+ "<li class=\"ql-indent-1\">d</li><li class=\"ql-indent-2\">d</li><li class=\"ql-indent-2\">d</li>"
								+ "<li class=\"ql-indent-3\">d</li><li class=\"ql-indent-3\">d</li><li class=\"ql-indent-2\">d</li>"
								+ "<li class=\"ql-indent-1\">d</li><li>d</li></ol><ul><li>Bullet points</li><li>d</li>"
								+ "<li class=\"ql-indent-1\">d</li><li class=\"ql-indent-2\">d</li><li class=\"ql-indent-4\">d</li>"
								+ "<li class=\"ql-indent-7\">d</li><li class=\"ql-indent-5\">d</li><li class=\"ql-indent-3\">d</li>"
								+ "<li>daa</li></ul><p><br /></p><p>Links:</p>"
								+ "<p><a href=\"mailto:test&#64;example.org\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">"
								+ "test&#64;example.org</a></p><p><a href=\"https://www.belastingdienst.nl\" target=\"_blank\" "
								+ "rel=\"noopener noreferrer nofollow\">www.belastingdienst.nl</a></p>"
								+ "<p><a href=\"https://ont-wd-kbs.apps.cn01.chp.belastingdienst.nl/#/authenticated/zicht-op-organisatie/bedrijfsactiviteiten\" "
								+ "target=\"_blank\" rel=\"noopener noreferrer nofollow\">https://ont-wd-kbs.apps.cn01.chp.belastingdienst.nl/#/authenticated/zicht-op-organisatie/bedrijfsactiviteiten</a></p>"
								+ "<p><br /></p><p>Plaatje:</p>"
								+ "<p><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAmCAYAAAA820BcAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAT2SURBVFhH7VdLbxtVFD4znnH8jF1KSZYEKFIjQYuSIsGSPpZURSReoEplBaxQBUIgNqwRqELiUX4CLRuKsimULugqUtQgQVjRTUofbBzb8Tge2zOc79w5zszUTipAZAFfdHMf53nPOffesXX02edD2iPYUb8n&#43;O8aH5nzMAzJsqxoRtTr&#43;uT3fer1ejQYDCgIAlm3bZsymQy5rkuuk6XsRFbWgbSOUbjPuAqh97tdanttGvT7sARixJUC&#43;Nkhx3GoUCxRbmJClndzIBF2ZcYOG40NaraaslMxyTTQRzX&#43;J/LgbTYaLFsXHbqJcRgaBxOYt3i3MNzn3SK8cWHdBfr4WGF4AzbcZx0N6rIu0Mc5IMbVsO93abPVkDkacqrKVQFyjPCiYQwoDbyWZUfyAbU4cjs5YGMRRHgLZvAoY1xAnWi1WnTv3h/SMAaUBsRl0TY3m6J7lAPW/NHneC2kxgaHGvlljxUqgB4pQB5PnXqRjh17QehXv79K31z&#43;VqodUVLeuBFEwuEIVapVoaEppNo7HY893EwcoTiwjvbxRx/S4uJCtGpw8eIleuvtd0RmlByA9VKpTPl8XuYKGxXa8Tpmwkz3e26R1&#43;nQmTOviGHwoxjRMMZarbYgPPFdaRTUIWxQnVHYfVwcAcIdChECcSU6f&#43;n0aaGDTwtOZWq1xbFyKjPoDyRtcdh6HgH0YIxD58ViUXrlQVO5MocUGCWrPGSjqH0zjiDGVQiMQ&#43;YIamx5eVlCiFArMMbaj9evJw1FSOhjuu&#43;njEOBGtc&#43;DoQty9X86Wef0/r6OmWz2aFSjLF24cKXwgPeNOK6g0GSnqlUH/pAvRt6GUF3AyP1ep1&#43;uHZNKnZ6apo8vvMv8zF797336dat3ymXywm/yijSujV9gPXozBPiWloIc9xgA97NFlcyIuRziqanpmhmZkZoN2/&#43;Rrdv3xXnHCcjDmhq0rp0fuDAI9ID1mOPPxnG8wgmNdxut&#43;UCmZ&#43;foxPHj9Phw0/RFBuH97adkbvhzt07tHrjJ1paWqKff1mTigZdHYAuBXTu3/9wNGNbBw8eCnt9U3TKDO89z6Nnjhyhc&#43;fepJMnT0TsO&#43;PKle/o/PlP6MbqKhUKBakB1YnedVyq7tsXcbPx2dmnQ2&#43;rI&#43;8xAMN4DGZnD9HXl76iSqWSqHAAioD4rrAGWbxmLy/UaG3tV5rgd12LELR8Lk/FUknmgO1wWCnYrkgwIZyvnj0rhuEI1hAy7WEITdeQAszBCxnIQgdo6iB8cF1HxgpbbqtIIZh5DyKAqtY7ADvX61T75Nj04IUMZI1Ro1McdfiBcbc/swAb3ucK5sI3OTJ9sViQYkMF63W6WwMvZCAb1wUU2CGzuW0Mn9QNflLhvc3XIPL2xuuv0dzcHAtjzXw07AblXVlZoS/44kEKAk7p2CcVxrGAB7/ZrPO55rzzHB8KyCFCx9UgzLvD8KLQyuUylxIfWd5tpVKVyGCTCeN4z3XR727xR2NrKJQO04MCoTbhtmhysszOmNsvbhgYfjorEbs1n0fmuVSoYFxJemyAE8MFzH/YfZajMMowMNwaiGBCyKocJlwIAFKgUAPo42OF4bXlB8Qk69jJMJCIqzrg8HlEgaBg&#43;CwqUeijGv&#43;TbPPRYZlJlq3Imd7JMPBAP5d8/rnUG/NzCQbxnGZ5t&#43;7f/bn0b&#43;KvlfM/hP&#43;N7wn20DjRn1XGOZWBTG0tAAAAAElFTkSuQmCC\" /></p>"
				)
		);
	}
}
