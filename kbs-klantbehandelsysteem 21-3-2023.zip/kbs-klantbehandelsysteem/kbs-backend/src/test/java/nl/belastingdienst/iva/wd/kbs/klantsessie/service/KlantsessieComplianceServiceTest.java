/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieComplianceRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ChartLabel;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkChild;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkParent;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieComplianceDto;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.mockito.Mockito.when;

@SpringBootKbsTest
@ExtendWith(MockitoExtension.class)
class KlantsessieComplianceServiceTest {

    @MockBean
    private KlantsessieService klantsessieServiceMock;

    private static final Kenmerk PARENT_KENMERK_1 = new Kenmerk(1, "KS_CAT", "Parent 1", null);
    private static final Kenmerk PARENT_KENMERK_2 = new Kenmerk(2, "KS_CAT", "Parent 2", null);
    private static final Kenmerk CHILD_KENMERK_1_A = new Kenmerk(10, "KS_CAT", "Child parent 1a", 1);
    private static final Kenmerk CHILD_KENMERK_1_B = new Kenmerk(11, "KS_CAT", "Child parent 1b", 1);
    private static final Kenmerk CHILD_KENMERK_2_A = new Kenmerk(20, "KS_CAT", "Child parent 2a", 2);
    private static final Kenmerk CHILD_KENMERK_2_B = new Kenmerk(21, "KS_CAT", "Child parent 2b", 2);
    private static final Kenmerk NON_RELATING_KENMERK = new Kenmerk(999, "OTHER", "Should not be included", 998);
    private static final List<Kenmerk> KENMERK_LIST = List.of(PARENT_KENMERK_1, PARENT_KENMERK_2, CHILD_KENMERK_1_A, CHILD_KENMERK_1_B, CHILD_KENMERK_2_A, CHILD_KENMERK_2_B, NON_RELATING_KENMERK);

    @Autowired
    private KlantSessieComplianceRepository klantSessieComplianceRepository;

    @Autowired
    private KenmerkRepository kenmerkRepository;

    @Autowired
    private KlantsessieComplianceService sut;

    @BeforeEach
    void setUp() {
        this.kenmerkRepository.saveAll(KENMERK_LIST);
        this.setupKlantSessieCompliances();
    }

    private void setupKlantSessieCompliances() {
        this.klantSessieComplianceRepository.saveAll(
                List.of(
                        /* 888L only has records for middel 12 */
                        new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_A.getId(), 1, "Toelichting 1", CHILD_KENMERK_1_A),
                        new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_B.getId(), 2, "Toelichting 2", CHILD_KENMERK_1_B),
                        new KlantsessieCompliance(888L, 12, CHILD_KENMERK_2_A.getId(), 3, "Toelichting 3", CHILD_KENMERK_2_A),
                        new KlantsessieCompliance(888L, 12, CHILD_KENMERK_2_B.getId(), 4, "Toelichting 4", CHILD_KENMERK_2_B),
                        /* 999L has records for middel 12 and 24 */
                        new KlantsessieCompliance(999L, 12, CHILD_KENMERK_1_A.getId(), 4, "Toelichting a", CHILD_KENMERK_1_A),
                        new KlantsessieCompliance(999L, 12, CHILD_KENMERK_1_B.getId(), 3, "Toelichting b", CHILD_KENMERK_1_B),
                        new KlantsessieCompliance(999L, 12, CHILD_KENMERK_2_A.getId(), 2, "Toelichting c", CHILD_KENMERK_2_A),
                        new KlantsessieCompliance(999L, 12, CHILD_KENMERK_2_B.getId(), 1, "Toelichting d", CHILD_KENMERK_2_B),
                        new KlantsessieCompliance(999L, 24, CHILD_KENMERK_1_A.getId(), 5, "Toelichting aa", CHILD_KENMERK_1_A),
                        new KlantsessieCompliance(999L, 24, CHILD_KENMERK_1_B.getId(), 4, "Toelichting bb", CHILD_KENMERK_1_B),
                        new KlantsessieCompliance(999L, 24, CHILD_KENMERK_2_A.getId(), 3, "Toelichting cc", CHILD_KENMERK_2_A),
                        new KlantsessieCompliance(999L, 24, CHILD_KENMERK_2_B.getId(), 2, "Toelichting dd", CHILD_KENMERK_2_B)
                )
        );
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideCurrentKsInput")
    void getCurrentKlantsessieCompliance(String testCaseName, Long entiteitnummer, Integer middelId, KlantsessieComplianceDto expectedOutput) {
        stubCurrentKlantSessies();

        KlantsessieComplianceDto klantsessieCompliance = this.sut.getCurrentKlantsessieCompliance(entiteitnummer, middelId);
        Assertions.assertEquals(expectedOutput, klantsessieCompliance);
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("providePreviousKsInput")
    void getPreviousKlantsessieCompliance(String testCaseName, Long entiteitnummer, Integer middelId, KlantsessieComplianceDto expectedOutput) {
        stubPreviousKlantSessies();

        KlantsessieComplianceDto klantsessieCompliance = this.sut.getPreviousKlantsessieCompliance(entiteitnummer, middelId);
        Assertions.assertEquals(expectedOutput, klantsessieCompliance);
    }

    public static Stream<Arguments> provideCurrentKsInput() {
        return Stream.of(
                Arguments.of(
                        "GivenCurrentKlantsessieIsEmptyThenReturnNull",
                        887L,
                        12,
                        new KlantsessieComplianceDto(
                                887L,
                                null,
                                List.of(
                                        new KenmerkParent(
                                                PARENT_KENMERK_1,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(887L, 12, CHILD_KENMERK_1_A.getId(), null, null, CHILD_KENMERK_1_A),
                                                                new KlantsessieCompliance(887L, 12, CHILD_KENMERK_1_B.getId(), null, null, CHILD_KENMERK_1_B)
                                                        )
                                                )
                                        ),
                                        new KenmerkParent(
                                                PARENT_KENMERK_2,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(887L, 12, CHILD_KENMERK_2_A.getId(), null, null, CHILD_KENMERK_2_A),
                                                                new KlantsessieCompliance(887L, 12, CHILD_KENMERK_2_B.getId(), null, null, CHILD_KENMERK_2_B)
                                                        )
                                                )
                                        )
                                )
                        )
                ),
                Arguments.of(
                        "GivenCurrentKlantsessieIsOnlyFilledForMiddel12WhenRequestedMiddel24ThenReturnNull",
                        888L,
                        24,
                        new KlantsessieComplianceDto(
                                888L,
                                null,
                                List.of(
                                        new KenmerkParent(
                                                PARENT_KENMERK_1,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(888L, 24, CHILD_KENMERK_1_A.getId(), null, null, CHILD_KENMERK_1_A),
                                                                new KlantsessieCompliance(888L, 24, CHILD_KENMERK_1_B.getId(), null, null, CHILD_KENMERK_1_B)
                                                        )
                                                )
                                        ),
                                        new KenmerkParent(
                                                PARENT_KENMERK_2,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(888L, 24, CHILD_KENMERK_2_A.getId(), null, null, CHILD_KENMERK_2_A),
                                                                new KlantsessieCompliance(888L, 24, CHILD_KENMERK_2_B.getId(), null, null, CHILD_KENMERK_2_B)
                                                        )
                                                )
                                        )
                                )
                        )
                ),
                Arguments.of(
                        "GivenCurrentKlantsessieIsOnlyFilledForMiddel12WhenRequestedMiddel12ThenReturnFilledDto",
                        888L,
                        12,
                        new KlantsessieComplianceDto(
                                888L,
                                null,
                                List.of(
                                        new KenmerkParent(
                                                PARENT_KENMERK_1,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_A.getId(), 1, "Toelichting 1", CHILD_KENMERK_1_A),
                                                                new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_B.getId(), 2, "Toelichting 2", CHILD_KENMERK_1_B)
                                                        )
                                                )
                                        ),
                                        new KenmerkParent(
                                                PARENT_KENMERK_2,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(888L, 12, CHILD_KENMERK_2_A.getId(), 3, "Toelichting 3", CHILD_KENMERK_2_A),
                                                                new KlantsessieCompliance(888L, 12, CHILD_KENMERK_2_B.getId(), 4, "Toelichting 4", CHILD_KENMERK_2_B)
                                                        )
                                                )
                                        )
                                )
                        )
                ),
                Arguments.of(
                        "GivenCurrentKlantsessieIsFilledForMiddel12And24WhenRequestMiddelId24ThenReturnOnlyMiddelId24",
                        999L,
                        24,
                        new KlantsessieComplianceDto(
                                999L,
                                null,
                                List.of(
                                        new KenmerkParent(
                                                PARENT_KENMERK_1,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(999L, 24, CHILD_KENMERK_1_A.getId(), 5, "Toelichting aa", CHILD_KENMERK_1_A),
                                                                new KlantsessieCompliance(999L, 24, CHILD_KENMERK_1_B.getId(), 4, "Toelichting bb", CHILD_KENMERK_1_B)
                                                        )
                                                )
                                        ),
                                        new KenmerkParent(
                                                PARENT_KENMERK_2,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(999L, 24, CHILD_KENMERK_2_A.getId(), 3, "Toelichting cc", CHILD_KENMERK_2_A),
                                                                new KlantsessieCompliance(999L, 24, CHILD_KENMERK_2_B.getId(), 2, "Toelichting dd", CHILD_KENMERK_2_B)
                                                        )
                                                )
                                        )
                                )
                        )
                )
        );
    }

    public static Stream<Arguments> providePreviousKsInput() {
        return Stream.of(
                Arguments.of(
                        "GivenNoPreviousKlantsessieThenReturnNull", 777L, 12, null
                ),
                Arguments.of(
                        "GivenPreviousKlantsessieIsEmptyThenReturnNull", 887L, 12, null
                ),
                Arguments.of(
                        "GivenPreviousKlantsessieIsOnlyFilledForMiddel12WhenRequestedMiddel24ThenReturnNull",
                        888L,
                        24,
                        null
                ),
                Arguments.of(
                        "GivenPreviousKlantsessieIsOnlyFilledForMiddel12WhenRequestedMiddel12ThenReturnFilledDto",
                        888L,
                        12,
                        new KlantsessieComplianceDto(
                                888L,
                                LocalDate.of(2022, 1, 1),
                                List.of(
                                        new KenmerkParent(
                                                PARENT_KENMERK_1,
                                                mapToComplianceChildren(
                                                        List.of(
                                                            new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_A.getId(), 1, "Toelichting 1", CHILD_KENMERK_1_A),
                                                            new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_B.getId(), 2, "Toelichting 2", CHILD_KENMERK_1_B)
                                                        )
                                                )
                                        ),
                                        new KenmerkParent(
                                                PARENT_KENMERK_2,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(888L, 12, CHILD_KENMERK_2_A.getId(), 3, "Toelichting 3", CHILD_KENMERK_2_A),
                                                                new KlantsessieCompliance(888L, 12, CHILD_KENMERK_2_B.getId(), 4, "Toelichting 4", CHILD_KENMERK_2_B)
                                                        )
                                                )
                                        )
                                )
                        )
                ),
                Arguments.of(
                        "GivenPreviousKlantsessieIsFilledForMiddel12And24WhenRequestMiddelId24ThenReturnOnlyMiddelId24",
                        999L,
                        24,
                        new KlantsessieComplianceDto(
                                999L,
                                LocalDate.of(2022, 2, 2),
                                List.of(
                                        new KenmerkParent(
                                                PARENT_KENMERK_1,
                                                mapToComplianceChildren(
                                                        List.of(
                                                                new KlantsessieCompliance(999L, 24, CHILD_KENMERK_1_A.getId(), 5, "Toelichting aa", CHILD_KENMERK_1_A),
                                                                new KlantsessieCompliance(999L, 24, CHILD_KENMERK_1_B.getId(), 4, "Toelichting bb", CHILD_KENMERK_1_B)
                                                        )
                                                )
                                        ),
                                        new KenmerkParent(
                                                PARENT_KENMERK_2,
                                                mapToComplianceChildren(
                                                        List.of(
                                                            new KlantsessieCompliance(999L, 24, CHILD_KENMERK_2_A.getId(), 3, "Toelichting cc", CHILD_KENMERK_2_A),
                                                            new KlantsessieCompliance(999L, 24, CHILD_KENMERK_2_B.getId(), 2, "Toelichting dd", CHILD_KENMERK_2_B)
                                                        )
                                                )
                                        )
                                )
                        )
                )
        );
    }

    private static List<KenmerkChild> mapToComplianceChildren(List<KlantsessieCompliance> klantsessieComplianceList){
        return klantsessieComplianceList.stream().map(klantsessieCompliance -> new KenmerkChild(
                klantsessieCompliance.getKenmerk(),
                klantsessieCompliance.getScore(),
                klantsessieCompliance.getToelichting()
        )).collect(Collectors.toList());
    }

    private void stubPreviousKlantSessies() {
        Klantsessie klantsessie887 = new Klantsessie(887L);
        klantsessie887.setId(887L);
        klantsessie887.setEinddatum(LocalDateTime.of(2022, 1, 1, 1, 1));
        Klantsessie klantsessie888 = new Klantsessie(888L);
        klantsessie888.setId(888L);
        klantsessie888.setEinddatum(LocalDateTime.of(2022, 1, 1, 1, 1));
        Klantsessie klantsessie999 = new Klantsessie(999L);
        klantsessie999.setId(999L);
        klantsessie999.setEinddatum(LocalDateTime.of(2022, 2, 2, 2, 2));
        when(klantsessieServiceMock.getPreviousKlantsessie(777L)).thenReturn(Optional.empty());
        when(klantsessieServiceMock.getPreviousKlantsessie(887L)).thenReturn(Optional.of(klantsessie887));
        when(klantsessieServiceMock.getPreviousKlantsessie(888L)).thenReturn(Optional.of(klantsessie888));
        when(klantsessieServiceMock.getPreviousKlantsessie(999L)).thenReturn(Optional.of(klantsessie999));
    }

    private void stubCurrentKlantSessies() {
        Klantsessie klantsessie887 = new Klantsessie(887L);
        klantsessie887.setId(887L);
        klantsessie887.setEinddatum(LocalDateTime.of(2022, 1, 1, 1, 1));
        Klantsessie klantsessie888 = new Klantsessie(888L);
        klantsessie888.setId(888L);
        klantsessie888.setEinddatum(LocalDateTime.of(2022, 1, 1, 1, 1));
        Klantsessie klantsessie999 = new Klantsessie(999L);
        klantsessie999.setId(999L);
        klantsessie999.setEinddatum(LocalDateTime.of(2022, 2, 2, 2, 2));

        when(klantsessieServiceMock.getCurrentKlantsessie(887L)).thenReturn(klantsessie887);
        when(klantsessieServiceMock.getCurrentKlantsessie(888L)).thenReturn(klantsessie888);
        when(klantsessieServiceMock.getCurrentKlantsessie(999L)).thenReturn(klantsessie999);
    }

	@Test
	void getChartLabels() {
        List<ChartLabel> chartLabels = this.sut.getChartLabels();
        var expectedLabels = List.of(
                new ChartLabel(CHILD_KENMERK_1_A.getId(), CHILD_KENMERK_1_A.getKenmerk()),
                new ChartLabel(CHILD_KENMERK_1_B.getId(), CHILD_KENMERK_1_B.getKenmerk()),
                new ChartLabel(CHILD_KENMERK_2_A.getId(), CHILD_KENMERK_2_A.getKenmerk()),
                new ChartLabel(CHILD_KENMERK_2_B.getId(), CHILD_KENMERK_2_B.getKenmerk())
        );
        Assertions.assertEquals(expectedLabels, chartLabels);
    }

    @Test
    void findAllByKlantsessieId() {
        //Given
        Klantsessie klantsessie887 = new Klantsessie(887L);
        klantsessie887.setId(887L);
        klantsessie887.setStartdatum(LocalDateTime.of(2022, 1, 1, 1, 1));
        when(klantsessieServiceMock.getCurrentKlantsessie(887L)).thenReturn(klantsessie887);

        List<KlantsessieCompliance> expected = klantSessieComplianceRepository.findAllByKlantsessieId(klantsessie887.getId());

        //When
        List<KlantsessieCompliance> actual = sut.findAllByKlantsessieId(klantsessie887.getId());

        //Then
        Assertions.assertEquals(expected, actual);
        Assertions.assertEquals(expected.size(), actual.size());

    }
}