package nl.belastingdienst.iva.wd.kbs.maintenancemessage.rest;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import nl.belastingdienst.iva.wd.kbs.maintenancemessage.dao.MessageCreateUpdateDeleteRepository;
import nl.belastingdienst.iva.wd.kbs.maintenancemessage.domain.Message;
import nl.belastingdienst.iva.wd.kbs.maintenancemessage.domain.MessageDto;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class MessageControllerTest {

	@Autowired
	private MessageCreateUpdateDeleteRepository messageCreateUpdateDeleteRepository;

	@Autowired
	private MessageController sut;

	@BeforeEach
	void setUp() {
		var startActive = LocalDateTime.now().minusDays(2);
		var endActive = LocalDateTime.now().plusHours(1);
		var startNonActive = LocalDateTime.now().plusMinutes(15);
		var endNonActive = LocalDateTime.now().minusHours(2);

		this.messageCreateUpdateDeleteRepository.saveAll(
				List.of(
						new Message(1L, "Oude niet-actieve melding", startActive, endNonActive),
						new Message(2L, "Actieve melding", startActive.minusSeconds(1), endActive),
						new Message(3L, "Actieve melding nieuwer", startActive, endActive),
						new Message(4L, "Nog niet-actieve melding", startNonActive, endActive),
						new Message(5L, "Onmogelijke melding (einddatum ligt voor startdatum)", startNonActive, endNonActive)
				)
		);
	}

	@Test
	void getCurrentMessages() {
		var expectedResponse = List.of(
				new MessageDto("Actieve melding nieuwer"),
				new MessageDto("Actieve melding")
		);

		List<MessageDto> currentMessages = this.sut.getCurrentMessages();

		/* assertEquals using implementation of equals/hash method */
		Assertions.assertEquals(expectedResponse, currentMessages);

		/* manual assertion */
		Assertions.assertEquals(2, currentMessages.size());
		Assertions.assertEquals("Actieve melding nieuwer", currentMessages.get(0).getValue());
		Assertions.assertEquals("Actieve melding", currentMessages.get(1).getValue());
	}
}