package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppelingCompositeId;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelection;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.LinkableKenmerkPolicy;

@SpringBootKbsTest
class ValidateRisicoLinkableToKenmerkServiceTest {

	public static final MiddelKenmerk MIDDEL_KENMERK_20 = new MiddelKenmerk(20L, 12, "kenmerk 20", null);
	public static final MiddelKenmerk MIDDEL_KENMERK_999 = new MiddelKenmerk(999L, 12, "kenmerk 999", null);
	public static final MiddelRisico MIDDEL_RISICO_10 = new MiddelRisico(10L, 12, "risico 10", null, null);
	@Autowired
	ValidateRisicoLinkableToKenmerkService sut;

	@Autowired
	EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;

	@Autowired
	KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;

	@Autowired
	MiddelKenmerkRepository middelKenmerkRepository;

	@Autowired
	MiddelRisicoRepository middelRisicoRepository;

	@BeforeEach
	void setUp(){
		setupEntiteitMiddelKenmerkRepository();
		setupMiddelRepositories();
		setupKenmerkRisicoKoppelingRepository();
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void validate(String testCaseName, MiddelSpecifiekeRisicoSelection middelSpecifiekeRisicoSelection, Optional<BusinessRuleError> expectedOptionalBusinessRuleError) {
		var actual = this.sut.validate(middelSpecifiekeRisicoSelection);
		assertEquals(expectedOptionalBusinessRuleError, actual);
	}

	private static Stream<Arguments> provideInput() {
		return Stream.of(
				Arguments.of(
					"whenNonLinkable_ThenReturnBusinessRuleError",
					new MiddelSpecifiekeRisicoSelection(
							1L,
							10L,
							2L,
							(short) 1,
							96L,
							1
					),
					Optional.of(
							new BusinessRuleError("Het gekozen risico kan niet gekoppeld worden aan dit kenmerk.", LinkableKenmerkPolicy.class)
					)
				),
				Arguments.of(
						"whenLinkable_ThenReturnEmptyOptional",
						new MiddelSpecifiekeRisicoSelection(
								1L,
								10L,
								1L,
								(short) 1,
								96L,
								1
						),
						Optional.empty()
				)
		);
	}


	private void setupEntiteitMiddelKenmerkRepository() {
		this.entiteitMiddelKenmerkRepository.saveAll(
				List.of(
					new EntiteitMiddelKenmerk(
							1L, 20L, null, null, null, null, 999L
					),
					new EntiteitMiddelKenmerk(
							2L, 999L, null, null, null, null, 999L
					)
				)
		);

		List<EntiteitMiddelKenmerk> all = this.entiteitMiddelKenmerkRepository.findAll();
		System.out.println();
	}

	private void setupKenmerkRisicoKoppelingRepository() {
		this.kenmerkRisicoKoppelingRepository.saveAll(
				List.of(
						new KenmerkRisicosKoppeling(
								new KenmerkRisicosKoppelingCompositeId(
										20L, 10L
								), MIDDEL_KENMERK_20, MIDDEL_RISICO_10
						)
				)
		);
		List<KenmerkRisicosKoppeling> all = this.kenmerkRisicoKoppelingRepository.findAll();
		System.out.println();
	}


	private void setupMiddelRepositories() {
		this.middelKenmerkRepository.saveAll(
				List.of(
						MIDDEL_KENMERK_20,MIDDEL_KENMERK_999

				)
		);
		this.middelRisicoRepository.saveAll(
			List.of(
					MIDDEL_RISICO_10
			)
		);
	}
}