package nl.belastingdienst.iva.wd.kbs.zof.rest;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.test.context.support.WithMockUser;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleResponse;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkDto;

@SpringBootKbsTest
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
class MiddelSpecifiekeKenmerkenControllerTest {

	@Autowired
	private EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;

	@Autowired
	private MiddelSpecifiekeKenmerkenController sut;

	public static final String DUPLICATE_MESSAGE = "Deze combinatie bestaat al.";
	public static final String LOWER_LEVEL_EXISTS_MESSAGE = "Één van de kenmerken wordt al op een lager niveau gebruikt.";
	public static final String HIGHER_LEVEL_EXISTS_MESSAGE = "Één van de kenmerken wordt al op een hoger niveau gebruikt.";

	@BeforeEach
	void setUp() {
		this.entiteitMiddelKenmerkRepository.saveAll(List.of(
				new EntiteitMiddelKenmerk(1L, 1L, null, null, null,null, 999L),
				new EntiteitMiddelKenmerk(2L, 2L, 10L, null, null, null, 999L),
				new EntiteitMiddelKenmerk(3L, 3L, 11L, 20L, null,null, 999L),
				new EntiteitMiddelKenmerk(4L, 4L, 12L, 21L, 30L, null, 999L)
		));
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void checkValidToBusinessRules(EntiteitMiddelKenmerkDto entiteitMiddelKenmerkDto, BusinessRuleResponse expectedBusinessRuleResponse) {
		BusinessRuleResponse businessRuleResponse = this.sut.checkValidToBusinessRules(entiteitMiddelKenmerkDto,
				entiteitMiddelKenmerkDto.getEntiteitNummer());

		Assertions.assertEquals(expectedBusinessRuleResponse, businessRuleResponse);
	}

	private static Stream<Arguments> provideInput() {

		return Stream.of(
				/* test different error messages */
				Arguments.of(
						new EntiteitMiddelKenmerkDto(
								null, 1L, null, null, null, null, 999L, true
						), new BusinessRuleResponse(DUPLICATE_MESSAGE)
				),
				Arguments.of(
						new EntiteitMiddelKenmerkDto(
								null, 1L, null, null, null, null, 999L, true
						), new BusinessRuleResponse(DUPLICATE_MESSAGE)
				),
				Arguments.of(
						new EntiteitMiddelKenmerkDto(null, 2L, null, null, null, null, 999L, true),
						new BusinessRuleResponse(LOWER_LEVEL_EXISTS_MESSAGE)
				),
				Arguments.of(
						new EntiteitMiddelKenmerkDto(null, 4L, 12L, 21L, null, null, 999L, true),
						new BusinessRuleResponse(HIGHER_LEVEL_EXISTS_MESSAGE)
				),

				// test duplicate but same id
				Arguments.of(
						new EntiteitMiddelKenmerkDto(
								1L, 1L, null, null, null, null, 999L, true
						), new BusinessRuleResponse()
				),
				// test duplicate on edit
				Arguments.of(
						new EntiteitMiddelKenmerkDto(
								2L, 1L, null, null, null, null, 999L, true
						), new BusinessRuleResponse(DUPLICATE_MESSAGE)
				)
		);
	}

}