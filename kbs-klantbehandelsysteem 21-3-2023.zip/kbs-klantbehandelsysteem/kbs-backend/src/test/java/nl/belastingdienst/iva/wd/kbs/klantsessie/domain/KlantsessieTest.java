package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class KlantsessieTest {

	private static final Long KLANTSESSIE_ID = 1L;
	private static final Integer MIDDEL_ID = 12;

	private Klantsessie sut;

	@BeforeEach
	void setUp() {
		sut = new Klantsessie(1234L);
		sut.setId(KLANTSESSIE_ID);
	}

	@Test
	void initWithTrueValueForActGebaseerdGehoudenKlantsessie() {
		assertTrue(sut.getActGebaseerdGehoudenKlantsessie());
	}

	@Test
	void getZichtOpOrganisatieEnFiscaliteitForMiddel_WhenMiddelIdIsNotPresent_StoresAndReturnsNewKlantsessieZooef() {
		assertTrue(sut.getZichtOpOrganisatieEnFiscaliteitPerMiddel().isEmpty());

		final var ksZooef = sut.getZichtOpOrganisatieEnFiscaliteitForMiddel(MIDDEL_ID);

		assertNotNull(ksZooef);
		assertEquals(KLANTSESSIE_ID, ksZooef.getKlantsessieId());
		assertEquals(MIDDEL_ID, ksZooef.getMiddelId());
		assertEquals(1, sut.getZichtOpOrganisatieEnFiscaliteitPerMiddel().size());
		assertEquals(ksZooef, sut.getZichtOpOrganisatieEnFiscaliteitForMiddel(MIDDEL_ID));
	}
}
