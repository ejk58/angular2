package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRulePolicy;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelection;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.BusinessRuleMiddelSpecifiekeRisicoDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.DuplicatePolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.HoofdRisicoSubRisicoWithKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.HoofdRisicoSubRisicoWithoutKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.HoofdRisicoWithKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.HoofdRisicoWithoutKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekerisico.LinkableKenmerkPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.mappings.EntiteitMiddelRisicoMapper;

@ExtendWith(MockitoExtension.class)
@Nested
@SpringBootKbsTest
@ComponentScan(basePackageClasses = { EntiteitMiddelRisicoMapper.class})
@DisplayName("Business Rules voor middel specifiek risico.")
class BusinessRulesMiddelSpecifiekeRisicosServiceTest {

    public static final String DEZE_COMBINATIE_VAN_HOOFDRISICO_SUBRISICO_EN_KENMERK_BESTAAT_AL =
            "Deze combinatie van hoofdrisico, subrisico en kenmerk bestaat al.";
    public static final String DIT_HOOFDRISICO_WORDT_AL_GEBRUIKT =
            "Dit hoofdrisico wordt al gebruikt.";
    public static final String DEZE_COMBINATIE_VAN_HOOFDRISICO_EN_SUBRISICO_BESTAAT_AL =
            "Deze combinatie van hoofdrisico en subrisico bestaat al.";
    public static final String HET_GEKOZEN_HOOFDRISICO_SUBRISICO_EN_OF_KENMERK_BESTAAT_AL =
            "Het gekozen hoofdrisico, subrisico en/of kenmerk bestaat al.";
    public static final String WRONGLY_FORMATTED = "Wrongly formatted.";
    public static final MiddelSpecifiekeRisicoSelection MIDDEL_SPECIFIEKE_RISICO_SELECTION_UNLINKABLE = new MiddelSpecifiekeRisicoSelection(
            3L, 12L, 999L, (short) 1, 96L, 1);
    static List<EntiteitMiddelRisico> collectie;

    @MockBean
    private EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepositoryMock;

    @MockBean
    private ValidateRisicoLinkableToKenmerkService validateRisicoLinkableToKenmerkServiceMock;

    @Autowired
	BusinessRulesMiddelSpecifiekeRisicosService sut;

    @Autowired
    KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;

    @Test
    @DisplayName("Check for wrong combination in selection")
    void checkForWrongCombinationInSelection() {
        Assertions.assertThrows(BusinessRuleException.class, () -> new MiddelSpecifiekeRisicoSelection(null, 10L, 21L, (short) 1, 96L,1), WRONGLY_FORMATTED);
        Assertions.assertThrows(BusinessRuleException.class, () -> new MiddelSpecifiekeRisicoSelection(null, null, 21L, (short) 1, 96L,1), WRONGLY_FORMATTED);
        Assertions.assertThrows(BusinessRuleException.class, () -> new MiddelSpecifiekeRisicoSelection(1L, 10L, 21L, (short) 1, null,1), WRONGLY_FORMATTED);
        Assertions.assertThrows(BusinessRuleException.class, () -> new MiddelSpecifiekeRisicoSelection(1L, 10L, 21L, null, 96L,1), WRONGLY_FORMATTED);
        Assertions.assertThrows(BusinessRuleException.class, () -> new MiddelSpecifiekeRisicoSelection(1L, 10L, 21L, (short) 1, 96L,null), WRONGLY_FORMATTED);
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideInput")
    @DisplayName("Check duplicates, and hierarchy rules.")
    void checkSelection(String testName, List<EntiteitMiddelRisico> entiteitMiddelRisicos, MiddelSpecifiekeRisicoSelection middelSpecifiekeRisicoSelection,
            boolean expectedValidation, String message, Class<BusinessRulePolicy<BusinessRuleMiddelSpecifiekeRisicoDto, EntiteitMiddelRisico>> policyClass) {

        stubValidateKenmerkLinkableService();
        /* debug tool*/
//        if(testName.equals("GivenHSr-WhenDifferentK-ThenPass")){
//            System.out.println();
//        }

        BusinessRuleMiddelSpecifiekeRisicoDto businessRuleMiddelSpecifiekeRisicoDto =
                new BusinessRuleMiddelSpecifiekeRisicoDto(middelSpecifiekeRisicoSelection, entiteitMiddelRisicos);

        Optional<BusinessRuleError> businessRuleError = sut.validToBusinessRules(businessRuleMiddelSpecifiekeRisicoDto);

        Assertions.assertEquals(expectedValidation, businessRuleError.isPresent());
        if (!message.isEmpty()) {
            Assertions.assertEquals(message,  businessRuleError.isPresent() ? businessRuleError.get().getMessage(): "");
        }

        if(policyClass != null){
            Assertions.assertEquals(policyClass, businessRuleError.<Object>map(BusinessRuleError::getPolicyClass)
                                                                  .orElse(null));
        }
    }

    private static Stream<Arguments> provideInput() {

        return Stream.of(
                /* duplicate tests */
                Arguments.of("check for duplicates HrOnly policy", collectie,
                        new MiddelSpecifiekeRisicoSelection(1L, null, null, (short) 1, 96L,1), true,
                        DEZE_COMBINATIE_VAN_HOOFDRISICO_SUBRISICO_EN_KENMERK_BESTAAT_AL, DuplicatePolicy.class),
                Arguments.of("check for duplicates HrSrPo picy", collectie,
                        new MiddelSpecifiekeRisicoSelection(2L, 10L, null, (short) 1, 96L,1), true,
                        DEZE_COMBINATIE_VAN_HOOFDRISICO_SUBRISICO_EN_KENMERK_BESTAAT_AL, DuplicatePolicy.class),
                Arguments.of("check for duplicates HrOnly policy", collectie,
                        new MiddelSpecifiekeRisicoSelection(3L, 11L, 20L, (short) 1, 96L,1), true,
                        DEZE_COMBINATIE_VAN_HOOFDRISICO_SUBRISICO_EN_KENMERK_BESTAAT_AL, DuplicatePolicy.class),
                Arguments.of("check for duplicates HrSr policy", collectie,
                        new MiddelSpecifiekeRisicoSelection(4L, null, 21L, (short) 1, 96L,1), true,
                        DEZE_COMBINATIE_VAN_HOOFDRISICO_SUBRISICO_EN_KENMERK_BESTAAT_AL, DuplicatePolicy.class),
                Arguments.of("check for duplicates HrSr policy", collectie,
                        new MiddelSpecifiekeRisicoSelection(10L, null, 21L, (short) 1, 96L,1), false, "", null),
                Arguments.of("checkDuplicateHrSrPolicyThenPass", collectie,
                        new MiddelSpecifiekeRisicoSelection(11L, 30L, null, (short) 1, 96L,1), false, "", null),
                /* hierarchy test */
                /* tests HrAlreadyExists */
                Arguments.of("GivenHrK-WhenHAlreadyExists", collectie, new MiddelSpecifiekeRisicoSelection(1L, null, 30L, (short) 1, 96L,1),
                        true, DIT_HOOFDRISICO_WORDT_AL_GEBRUIKT, HoofdRisicoWithoutKenmerkPolicy.class),
                Arguments.of("GivenHrSr-WhenHAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(1L, 11L, null, (short) 1, 96L,1), true,
                        DIT_HOOFDRISICO_WORDT_AL_GEBRUIKT, HoofdRisicoWithoutKenmerkPolicy.class),
                Arguments.of("GivenHrSrK-WhenHAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(1L, 11L, 30L, (short) 1, 96L,1), true,
                        DIT_HOOFDRISICO_WORDT_AL_GEBRUIKT, HoofdRisicoWithoutKenmerkPolicy.class),
                Arguments.of("GivenHrSrK-WhenHAlreadyExistsThenPass", collectie,
                        new MiddelSpecifiekeRisicoSelection(4L, null, 30L, (short) 1, 96L,1), false, "", null),
                /* tests HSrAlreadyExists */
                Arguments.of("GivenHOnly-WhenHSrAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(2L, null, null, (short) 1, 96L,1), true,
                        DEZE_COMBINATIE_VAN_HOOFDRISICO_EN_SUBRISICO_BESTAAT_AL, HoofdRisicoSubRisicoWithoutKenmerkPolicy.class),
                Arguments.of("GivenHK-WhenHSrAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(2L, null, 30L, (short) 1, 96L,1), true,
                        DEZE_COMBINATIE_VAN_HOOFDRISICO_EN_SUBRISICO_BESTAAT_AL, HoofdRisicoSubRisicoWithoutKenmerkPolicy.class),
                Arguments.of("GivenHK-WhenHSrAlreadyExists-ThenPass", collectie,
                        new MiddelSpecifiekeRisicoSelection(2L, 12L, 30L, (short) 1, 96L,1), false, "", null),
                /* tests HK */
                Arguments.of("GivenHOnly-WhenHKAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(4L, null, null, (short) 1, 96L,1), true,
                        "Deze combinatie van hoofdrisico en kenmerk bestaat al.", HoofdRisicoWithKenmerkPolicy.class),
                Arguments.of("GivenHSrOnly-WhenHKAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(4L, 12L, null, (short) 1, 96L,1), true,
                        "Deze combinatie van hoofdrisico en kenmerk bestaat al.", HoofdRisicoWithKenmerkPolicy.class),
                Arguments.of("GivenHSrOnly-WhenHKAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(4L, 13L, 21L, (short) 1, 96L,1), true,
                        "Deze combinatie van hoofdrisico en kenmerk bestaat al.", HoofdRisicoWithKenmerkPolicy.class),
                Arguments.of("GivenHOnly-WhenHrSrKAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(3L, null, null, (short) 1, 96L,1), true,
                        "Het gekozen hoofdrisico, subrisico en/of kenmerk bestaat al.", HoofdRisicoSubRisicoWithKenmerkPolicy.class),
                Arguments.of("GivenHK-WhenSameHDifferentKAdded-ThenPass", collectie,
                        new MiddelSpecifiekeRisicoSelection(4L, null, 30L, (short) 1, 96L,1), false, "", null),
                /* tests HSrK */
                Arguments.of("GivenHK-WhenHrSrKAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(3L, null, 22L, (short) 1, 96L,1), true,
                        HET_GEKOZEN_HOOFDRISICO_SUBRISICO_EN_OF_KENMERK_BESTAAT_AL, HoofdRisicoSubRisicoWithKenmerkPolicy.class),
                Arguments.of("GivenHSr-WhenHrSrKAlreadyExists", collectie,
                        new MiddelSpecifiekeRisicoSelection(3L, 11L, null, (short) 1, 96L,1), true,
                        HET_GEKOZEN_HOOFDRISICO_SUBRISICO_EN_OF_KENMERK_BESTAAT_AL, HoofdRisicoSubRisicoWithKenmerkPolicy.class),
                Arguments.of("GivenHSr-WhenDifferentK-ThenPass", collectie,
                        new MiddelSpecifiekeRisicoSelection(3L, 11L, 22L, (short) 1, 96L,1), false, "", null),
                /* divers */
                Arguments.of("GivenHSrK-WhenSameHrDifferentSrSameK-ThenPass", collectie,
                        new MiddelSpecifiekeRisicoSelection(3L, 12L, 20L, (short) 1, 96L,1), false, "", null),
                Arguments.of("GivenHs-WhenUnlinkableKenmerk-ThenBusinessError", collectie,
                        MIDDEL_SPECIFIEKE_RISICO_SELECTION_UNLINKABLE, true, "Het gekozen kenmerk kan niet gekoppeld worden aan het gekozen risico.", null)
                );
    }

    @BeforeAll
    static void beforeAll() {
        // creation:
        // kleine collectie om de verschillende rules tegen te houden.
        // h-hoofdrisico, sr - subrisico, K - kenmerkId
        // collectie: [
        // h1
        // h2 s10
        // h3 s11 K20
        // h4 - K21
        // ]

        collectie = List.of(
                new EntiteitMiddelRisico(1L, 999L, null, 1L, null, (short) 1, 1L, 1, null ),
                new EntiteitMiddelRisico(2L, 999L, null, 2L, 10L, (short) 1, 1L, 1,null),
                new EntiteitMiddelRisico(3L, 999L, 20L, 3L, 11L, (short) 1, 1L, 1,null),
                new EntiteitMiddelRisico(4L, 999L, 21L, 4L, null, (short) 1, 1L, 1,null)
        );
    }

    @Test
    void testValidateMethod() {
        stubEntiteitMiddelRisicoRepository();

        var alreadyExists = sut.validate(999L, new MiddelSpecifiekeRisicoSelection(1L, null, null, (short) 1, 96L,1));
        Assertions.assertTrue(alreadyExists.isPresent());

        var doesNotAlreadyExist = sut.validate(999L, new MiddelSpecifiekeRisicoSelection(4L, null, null, (short) 1, 96L,1));
        Assertions.assertFalse(doesNotAlreadyExist.isPresent());

    }

    @Test
    void testValidateWithCurrentIdMethod() {
        stubEntiteitMiddelRisicoRepository();

        var alreadyExists = sut.validateWithCurrentId(999L, new MiddelSpecifiekeRisicoSelection(1L, null, null, (short) 1, 96L,1), 2L);
        Assertions.assertTrue(alreadyExists.isPresent());

        var doesNotAlreadyExist = sut.validateWithCurrentId(999L, new MiddelSpecifiekeRisicoSelection(4L, null, null, (short) 1, 96L,1), 2L);
        Assertions.assertFalse(doesNotAlreadyExist.isPresent());
    }

    private void stubEntiteitMiddelRisicoRepository(){
        when(entiteitMiddelRisicoRepositoryMock.findEntiteitMiddelRisicosByEntiteitNummer(999L)).thenReturn(
                List.of(
                        new EntiteitMiddelRisico(1L, 999L, 20L, 1L, 10L, (short) 1, 96L, 1,null),
                        new EntiteitMiddelRisico(2L, 999L, 21L, 2L, 11L, (short) 1, 96L, 1,null),
                        new EntiteitMiddelRisico(3L, 999L, 22L, 3L, 12L, (short) 1, 96L, 1,null)
                )
        );
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideInputValidateWithList")
	void validateWithList(
            String testCaseName,
            Long entiteitNummer,
            MiddelSpecifiekeRisicoSelection selection,
            List<MiddelSpecifiekeRisicoSelection> middelSpecifiekeRisicoSelectionList,
            boolean expectedPresenceBusinessRuleError
    ) {
        stubEntiteitMiddelRisicoRepository();

        var actual = this.sut.validateWithList(
                entiteitNummer,
                selection,
                middelSpecifiekeRisicoSelectionList
        );

        Assertions.assertEquals(expectedPresenceBusinessRuleError, actual.isPresent());
    }

    private static Stream<Arguments> provideInputValidateWithList() {
        return Stream.of(
                Arguments.of(
                    "givenSetup_WhenListWithDuplicate_ThenReturnBusinesRuleError",
                        999L,
                        new MiddelSpecifiekeRisicoSelection(10L, 2L, 10L, (short) 1, 96L,1),
                        List.of(
                                new MiddelSpecifiekeRisicoSelection(10L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(30L, null, 10L, (short) 1, 96L,1)
                        ),
                        true
                ),
                Arguments.of(
                        "givenSetup_WhenListWithDuplicateInDb_ThenReturnBusinesRuleError",
                        999L,
                        new MiddelSpecifiekeRisicoSelection(1L, null, 10L, (short) 1, 96L,1),
                        List.of(
                                new MiddelSpecifiekeRisicoSelection(10L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(30L, null, 10L, (short) 1, 96L,1)
                        ),
                        true
                ),
                Arguments.of(
                        "givenSetup_WhenListWithoutDuplicate_ThenReturnEmptyOptional",
                        999L,
                        new MiddelSpecifiekeRisicoSelection(1L, 2L, 10L, (short) 1, 96L,1),
                        List.of(
                                new MiddelSpecifiekeRisicoSelection(2L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(3L, null, 10L, (short) 1, 96L,1)
                        ),
                        false
                ),
                Arguments.of(
                        "givenSameRisicoDifferentKenmerk_ThenReturnEmptyOptional",
                        999L,
                        new MiddelSpecifiekeRisicoSelection(12L, null, 11L, (short) 1, 96L,1),
                        List.of(
                                new MiddelSpecifiekeRisicoSelection(2L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(3L, null, 10L, (short) 1, 96L,1)
                        ),
                        false
                )
        );
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideInputValidateList")
    void validateList(
            String testCaseName,
            Long entiteitNummer,
            List<MiddelSpecifiekeRisicoSelection> middelSpecifiekeRisicoSelectionList,
            boolean expectedPresenceBusinessRuleError
    ) {
        stubEntiteitMiddelRisicoRepository();

        var actual = this.sut.validateList(999L,
                middelSpecifiekeRisicoSelectionList);

        Assertions.assertEquals(expectedPresenceBusinessRuleError, actual.isPresent());

    }

    private static Stream<Arguments> provideInputValidateList() {
        return Stream.of(
                Arguments.of(
                        "givenSetup_WhenListWithDuplicate_ThenReturnBusinesRuleError",
                        999L,
                        List.of(
                                new MiddelSpecifiekeRisicoSelection(10L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(30L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(10L, null, 10L, (short) 1, 96L,1)
                        ),
                        true
                ),
                Arguments.of(
                        "givenSetup_WhenListWithDuplicateInDb_ThenReturnBusinesRuleError",
                        999L,
                        List.of(
                                new MiddelSpecifiekeRisicoSelection(10L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(30L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(1L, null, 10L, (short) 1, 96L,1)
                        ),
                        true
                ),
                Arguments.of(
                        "givenSetup_WhenListWithoutDuplicate_ThenReturnEmptyOptional",
                        999L,
                        List.of(
                                new MiddelSpecifiekeRisicoSelection(10L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(30L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(20L, null, 10L, (short) 1, 96L,1)
                        ),
                        false
                ),
                Arguments.of(
                        "givenDuplicateRisicoDifferentKenmerk_ThenReturnEmptyOptional",
                        999L,
                        List.of(
                                new MiddelSpecifiekeRisicoSelection(10L, null, 10L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(10L, null, 11L, (short) 1, 96L,1),
                                new MiddelSpecifiekeRisicoSelection(20L, null, 10L, (short) 1, 96L,1)
                        ),
                        false
                )
        );
    }


    private void stubValidateKenmerkLinkableService() {
        when(this.validateRisicoLinkableToKenmerkServiceMock.validate(any())).thenReturn(
                Optional.empty()
        );
        when(this.validateRisicoLinkableToKenmerkServiceMock.validate(MIDDEL_SPECIFIEKE_RISICO_SELECTION_UNLINKABLE)).thenReturn(
                Optional.of(
                        new BusinessRuleError("Het gekozen kenmerk kan niet gekoppeld worden aan het gekozen risico.", LinkableKenmerkPolicy.class)
                )
        );
    }

}

