package nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie;

import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStrategieRisicosRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
@ExtendWith(MockitoExtension.class)
class GetSelectedRisicoServiceTest {

	public static final MiddelRisico MIDDEL_RISICO_1 = new MiddelRisico(1L, 12, "risico 1", null, null);
	public static final MiddelRisico MIDDEL_RISICO_2 = new MiddelRisico(2L, 12, "risico 2", null, null);
	public static final MiddelRisico MIDDEL_RISICO_3 = new MiddelRisico(3L, 24, "risico 3", null, null);
	public static final MiddelRisico MIDDEL_RISICO_4 = new MiddelRisico(4L, 12, "risico 4", null, null);

	@Autowired
	GetSelectedRisicoService sut;
	@Autowired
	KlantsessieStrategieRisicosRepository klantsessieStrategieRisicosRepository;

	@MockBean
	KlantsessieService klantsessieService;

	@Autowired
	MiddelRisicoRepository middelRisicoRepository;

	@BeforeEach
	void setUp() {


		this.middelRisicoRepository.saveAll(
				List.of(MIDDEL_RISICO_1, MIDDEL_RISICO_2, MIDDEL_RISICO_3, MIDDEL_RISICO_4)
		);

		this.klantsessieStrategieRisicosRepository.saveAll(
			List.of(
					new KlantsessieStrategieRisico(1L, 12, MIDDEL_RISICO_1.getId(), null),
					new KlantsessieStrategieRisico(1L, 12, MIDDEL_RISICO_4.getId(), null),
					new KlantsessieStrategieRisico(1L, 24, MIDDEL_RISICO_3.getId(), null),
					new KlantsessieStrategieRisico(2L, 12, MIDDEL_RISICO_2.getId(), null)
			)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void getSelectedList(String testCaseName, Long entiteitnummer, Integer middelId, List<KlantsessieStrategieRisico> expectedList) {
		this.stubKlantsessieService();
		List<KlantsessieStrategieRisico> actualList = this.sut.getSelectedList(entiteitnummer, middelId);
		Assertions.assertEquals(expectedList, actualList);
	}

	private static Stream<Arguments> provideInput() {
		return Stream.of(
				Arguments.of(
						"whenKlantsessieId1MiddelId12_ThenReturnListOf2",
						999L,
						12,
						List.of(
								new KlantsessieStrategieRisico(1L, 12, MIDDEL_RISICO_1.getId(), MIDDEL_RISICO_1),
								new KlantsessieStrategieRisico(1L, 12, MIDDEL_RISICO_4.getId(), MIDDEL_RISICO_4)
						)
				),
				Arguments.of(
						"whenKlantsessieId1MiddelIdUnknown_ThenReturnEmptyList",
						999L,
						555,
						List.of()
				)
		);
	}

	private void stubKlantsessieService() {
		when(klantsessieService.getCurrentKlantsessie(999L)).thenReturn(new Klantsessie(1L, null, null,null,null,null,null,null));
	}

}