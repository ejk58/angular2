package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import javax.validation.ConstraintViolationException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.server.ResponseStatusException;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelnaamAfkortingRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelnaamAfkorting;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieCompliancePerProcesRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliancePerProces;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesWithAbbreviatedMiddelProjection;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.status.CheckComplianceService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.service.KenmerkService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.shared.util.AssertEqualsInterfaceObject;

@SpringBootKbsTest
@ExtendWith(MockitoExtension.class)
class KlantsessieCompliancePerProcesServiceTest {
	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";
	@Autowired
	private KenmerkRepository kenmerkRepository;

	@Autowired
	private KenmerkService kenmerkService;

	@Autowired
	private KlantsessieCompliancePerProcesRepository klantSessieCompliancePerProcesRepository;

	@Autowired
	private MiddelnaamAfkortingRepository middelnaamAfkortingRepository;

	@MockBean
	private KlantsessieService klantsessieServiceMock;

	@MockBean
	private CheckComplianceService checkComplianceService;
	@MockBean
	private KlantsessieStatusService klantsessieStatusService;
	@MockBean Logging2Service logging2Service;

	@Autowired
	private KlantsessieCompliancePerProcesService cut;

	private static final Integer MIDDEL_ID_WITH_RECORD = 12;
	private static final Integer MIDDEL_ID_WITHOUT_RECORD = 114;

	@BeforeEach
	void setUp() {
		setupKlantsessieCompliancePerProces();
		kenmerkRepository.saveAll(List.of(
				new Kenmerk(12, "MID", "Vennootschapsbelasting", null),
				new Kenmerk(141, "KS_MID", "Controle", null),
				new Kenmerk(143, "-", "Hoog comfort", null),
				new Kenmerk(144, "-", "Middel comfort", null),
				new Kenmerk(145, "-", "Laag comfort", null)
		));
		middelnaamAfkortingRepository.saveAll(
				List.of(
						new MiddelnaamAfkorting(24, "Inkomstenbelasting", "IH", 2L),
						new MiddelnaamAfkorting(12, "Vennootschapsbelasting", "VPB", 1L)
				)
		);
	}

	private void setupKlantsessieCompliancePerProces() {
		klantSessieCompliancePerProcesRepository.saveAll(
				List.of(new KlantsessieCompliancePerProces(1L, MIDDEL_ID_WITH_RECORD, 145, 144, 143),
						new KlantsessieCompliancePerProces(2L, MIDDEL_ID_WITH_RECORD, 143, 143, 143),
						new KlantsessieCompliancePerProces(3L, 24, 143, 144, 143),
						new KlantsessieCompliancePerProces(3L, 12, 144, 145, 143)
						)
		);
	}

	public static Stream<Arguments> provideInputForGetKlantsessieCompliancePerProces() {
		return Stream.of(
				Arguments.of("GivenEntiteitNummerAndMiddelIdThenReturnKlantsessieCompliancePerProces", 888L, MIDDEL_ID_WITH_RECORD,
						new KlantsessieCompliancePerProces(1L, MIDDEL_ID_WITH_RECORD, 145, 144, 143)),
				Arguments.of("GivenEntiteitNummerThenReturnNewKlantsessieCompliancePerProces", 888L, MIDDEL_ID_WITH_RECORD,
						new KlantsessieCompliancePerProces(2L, MIDDEL_ID_WITH_RECORD, 143, 143, 143)));
	}

	public static Stream<Arguments> provideInputForUpdateKlantsessieCompliancePerProces() {
		PerProcesDto dataWithKnownMiddel = new PerProcesDto(1L, MIDDEL_ID_WITH_RECORD, 143, 144, 145);
		PerProcesDto dataWithUnKnownMiddel = new PerProcesDto(2L, MIDDEL_ID_WITH_RECORD, 0, 0, 0);

		return Stream.of(Arguments.of("GivenDataThenReturnUpdatedKlantsessieCompliancePerProces", 888L, dataWithKnownMiddel,
						new KlantsessieCompliancePerProces(1L, MIDDEL_ID_WITH_RECORD, 143, 144, 145)),
				Arguments.of("GivenDataWithUnKnownMiddelThenReturnNewKlantsessieCompliancePerProces", 888L, dataWithUnKnownMiddel,
						new KlantsessieCompliancePerProces(2L, MIDDEL_ID_WITH_RECORD, 0, 0, 0)));
	}

	private static Stream<Arguments> updateWithPerProcesConstraintsValidations() {
		return Stream.of(
				Arguments.of("klantsessie id is null", 888L,
						new PerProcesDto(null, MIDDEL_ID_WITHOUT_RECORD,
								123, 123, 123),
						123L),
				Arguments.of("klantsessie id is -1", 888L, new PerProcesDto(-1L, MIDDEL_ID_WITH_RECORD,
						123, 123, 123), 123L),
				Arguments.of("middelId is null", 888L, new PerProcesDto(1L, null,
						123, 123, 123), 123L),
				Arguments.of("middelId is -1", 888L, new PerProcesDto(1L, -1,
						123, 123, 123), 123L),
				Arguments.of("perprpoces fields zijn allemaal -1", 888L, new PerProcesDto(1L, MIDDEL_ID_WITH_RECORD,
								-1, -1, -1),
						123L));
	}

	private static Stream<Arguments> updateWithNotMatchingKlantsessieId() {
		return  Stream.of(
				Arguments.of("Niet bestaand klantsessie Id in een perProces", 888L,
						new PerProcesDto(223456L, MIDDEL_ID_WITHOUT_RECORD,
								123, 123, 123), 123L),
				Arguments.of("Niet bestaand klantsessie Id in een perProces-2", 888L,
						new PerProcesDto(223456L, MIDDEL_ID_WITH_RECORD,
								123, 123, 123), 123L)
		);
	}

	private static Stream<Arguments> updateWithWrongKenmerkId() {
		return  Stream.of(
				Arguments.of("notAllowed: Kenmerk is KS_MID", 888L,
						new PerProcesDto(1L, 141,
								123, 123, 123), 123L),
				Arguments.of("notAllowed: Kenmerk is not existing", 888L,
						new PerProcesDto(1L, 99999,
								123, 123, 123), 123L)
		);
	}

	private static Stream<Arguments> updateKlantsessieCompliancePerProcesConstraintsNullinFields() {
		PerProcesDto kspp1 = new PerProcesDto(1L, MIDDEL_ID_WITH_RECORD, 123, 123, 0);
		KlantsessieCompliancePerProces ekspp1 = new KlantsessieCompliancePerProces(1L,
				MIDDEL_ID_WITH_RECORD, 123, 123, 0);
		PerProcesDto kspp2 = new PerProcesDto(2L, MIDDEL_ID_WITH_RECORD, 123, 0, 123);
		KlantsessieCompliancePerProces ekspp2 = new KlantsessieCompliancePerProces(2L,
				MIDDEL_ID_WITH_RECORD, 123, 0, 123);
		PerProcesDto kspp3 = new PerProcesDto(1L, MIDDEL_ID_WITH_RECORD, 0, 123, 123);
		KlantsessieCompliancePerProces ekspp3 = new KlantsessieCompliancePerProces(1L,
				MIDDEL_ID_WITH_RECORD, 0, 123, 123);
		PerProcesDto kspp4 = new PerProcesDto(2L, MIDDEL_ID_WITH_RECORD, 0, 0, 0);
		KlantsessieCompliancePerProces ekspp4 = new KlantsessieCompliancePerProces(2L,
				MIDDEL_ID_WITH_RECORD, 0, 0, 0);

		return Stream.of(
				Arguments.of("klantsessie per proces met null bezwaren", 					888L, kspp1 , ekspp1, 123L),
				Arguments.of("klantsessie per proces met null heffing", 					888L, kspp2 , ekspp2, 123L),
				Arguments.of("klantsessie per proces met null vooroverleg", 				888L, kspp3 , ekspp3, 123L),
				Arguments.of("klantsessie per proces met null voor alle proces fields", 	888L, kspp4 , ekspp4, 123L)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInputForGetKlantsessieCompliancePerProces")
	void getPerProces(String testCaseName, Long entiteitnummer, Integer middelId, KlantsessieCompliancePerProces expected) {
		var klantsessie = new Klantsessie(entiteitnummer);
		klantsessie.setId(expected.getKlantsessieId());
		when(klantsessieServiceMock.getCurrentKlantsessie(entiteitnummer)).thenReturn(klantsessie);
		KlantsessieCompliancePerProces actual = cut.getPerProces(entiteitnummer, middelId);
		Assertions.assertEquals(expected, actual);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInputForUpdateKlantsessieCompliancePerProces")
	void updateKlantsessieCompliancePerProces(String testCaseName, Long entiteitnummer, PerProcesDto data,
			KlantsessieCompliancePerProces expected) {
		var klantsessie = new Klantsessie(entiteitnummer);
		klantsessie.setId(data.getKlantsessieId());
		when(klantsessieServiceMock.getCurrentKlantsessie(entiteitnummer)).thenReturn(klantsessie);

		KlantsessieCompliancePerProces actual = cut.update(data, entiteitnummer, TEST_LOGGING_ID_1);
		Assertions.assertEquals(expected, actual);
		LoggingArgumentAssertion.check(logging2Service, TEST_LOGGING_ID_1, entiteitnummer, Logging2.Bewerking.UPDATE);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("updateWithPerProcesConstraintsValidations")
	void updateWithPerProcesConstraintsValidations(String testCaseName, Long entiteitnummer, PerProcesDto data) {
		var klantsessie = new Klantsessie(entiteitnummer);
		klantsessie.setId(data.getKlantsessieId());
		when(klantsessieServiceMock.getCurrentKlantsessie(entiteitnummer)).thenReturn(klantsessie);
		Assertions.assertThrows(ConstraintViolationException.class, () -> {
			cut.update(data, entiteitnummer, TEST_LOGGING_ID_1);
		});
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("updateWithNotMatchingKlantsessieId")
	void updateWithNotMatchingKlantsessieId(String testCaseName, Long entiteitnummer, PerProcesDto data) {
		var klantsessie = new Klantsessie(entiteitnummer);
		klantsessie.setId(data.getKlantsessieId()+1);
		when(klantsessieServiceMock.getCurrentKlantsessie(entiteitnummer)).thenReturn(klantsessie);
		Assertions.assertThrows(ResponseStatusException.class, () -> {
			cut.update(data, entiteitnummer, TEST_LOGGING_ID_1);
		});
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("updateWithWrongKenmerkId")
	void updateWithWrongKenmerkId(String testCaseName, Long entiteitnummer, PerProcesDto data) {
		var klantsessie = new Klantsessie(entiteitnummer);
		klantsessie.setId(data.getKlantsessieId());
		when(klantsessieServiceMock.getCurrentKlantsessie(entiteitnummer)).thenReturn(klantsessie);
		Assertions.assertThrows(ResponseStatusException.class, () -> {
			cut.update(data, entiteitnummer, TEST_LOGGING_ID_1);
		});
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("updateKlantsessieCompliancePerProcesConstraintsNullinFields")
	void updateKlantsessieCompliancePerProcesConstraintsNullinFields(String testCaseName, Long entiteitnummer, PerProcesDto data,
			KlantsessieCompliancePerProces expected) {
		var klantsessie = new Klantsessie(entiteitnummer);
		klantsessie.setId(expected.getKlantsessieId());
		when(klantsessieServiceMock.getCurrentKlantsessie(entiteitnummer)).thenReturn(klantsessie);
		KlantsessieCompliancePerProces actual = cut.update(data, entiteitnummer, TEST_LOGGING_ID_1);
		Assertions.assertEquals(expected, actual);
		LoggingArgumentAssertion.check(logging2Service, TEST_LOGGING_ID_1, entiteitnummer, Logging2.Bewerking.UPDATE);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInputGetPerProcesByEntiteitnummer")
	void testGetPerProces(String testCaseName, Long entiteitnummer, List<PerProcesWithAbbreviatedMiddelProjection> expected) {
		var klantsessie = new Klantsessie();
		klantsessie.setId(3L);
		when(klantsessieServiceMock.getPreviousKlantsessie(999L)).thenReturn(Optional.empty());
		when(klantsessieServiceMock.getPreviousKlantsessie(111L)).thenReturn(Optional.of(klantsessie));
		List<PerProcesWithAbbreviatedMiddelProjection> actual = cut.getPerProces(entiteitnummer);
		AssertEqualsInterfaceObject.assertEquals(expected, actual);
	}

	private static Stream<Arguments> provideInputGetPerProcesByEntiteitnummer() {
		return Stream.of(Arguments.of("GivenPreviousKlantsessieDoesNotExist_ThenReturnEmptyList", 999L, Collections.emptyList()),
				Arguments.of("GivenEntiteitNummerPreviousKlantsessieExist_ThenReturnListKlantsessieCompliancePerProces", 111L,
						List.of(createPerProcesWithAbbreviatedMiddelProjection("VPB", "Middel comfort", "Laag comfort",
										"Hoog comfort"),
								createPerProcesWithAbbreviatedMiddelProjection("IH", "Hoog comfort", "Middel comfort",
										"Hoog comfort")
						)));
	}

	private static PerProcesWithAbbreviatedMiddelProjection createPerProcesWithAbbreviatedMiddelProjection(String afkorting, String vooroverleg, String heffing, String bezwaren){
		return new PerProcesWithAbbreviatedMiddelProjection() {
			@Override
			public String getAfkorting() {
				return afkorting;
			}

			@Override
			public String getVooroverleg() {
				return vooroverleg;
			}

			@Override
			public String getHeffing() {
				return heffing;
			}

			@Override
			public String getBezwaren() {
				return bezwaren;
			}
		};
	}


}
