package nl.belastingdienst.iva.wd.kbs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.EntiteitKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerkId;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkType;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkWithValuesDto;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class EntiteitKenmerkServiceTest {
    public static final EntiteitKenmerkId ENTITEIT_KENMERK_ID_1 = new EntiteitKenmerkId(111L, "TESTGRP", 1);
    public static final EntiteitKenmerkId ENTITEIT_KENMERK_ID_2 = new EntiteitKenmerkId(112L, "TESTGRP", 2);
    public static final String TEST_LOGGING_ID_1 = "testLoggingId1";

    @MockBean
    private Logging2Service logging2ServiceMock;
    @Autowired
    EntiteitKenmerkRepository entiteitKenmerkRepository;
    @Autowired
    private EntiteitKenmerkService cut;

    @BeforeEach
    void setUp() {
        EntiteitKenmerkId id = new EntiteitKenmerkId(999L, KenmerkType.SECTR.getValue(), -1);
        EntiteitKenmerk alreadySaved = new EntiteitKenmerk(id, String.valueOf(4));
        entiteitKenmerkRepository.save(alreadySaved);

        entiteitKenmerkRepository.saveAll(
                List.of(
                        new EntiteitKenmerk(ENTITEIT_KENMERK_ID_1,
                                "value 1, value 2"
                        )
                )
        );
    }


    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideSectorInput")
    void saveSelectedSector(String testCaseName, Long bsnRsin, int sector, EntiteitKenmerkId entiteitKenmerkId, Logging2.Bewerking bewerking) {

        String loggingId = "loggingTestId_" + bsnRsin;
        cut.saveSelectedSector(bsnRsin, sector, loggingId);
        LoggingArgumentAssertion.check(logging2ServiceMock, loggingId, bsnRsin, bewerking);
        if (sector == -1) {
            Optional<EntiteitKenmerk> actual = entiteitKenmerkRepository.findById(entiteitKenmerkId);

            Assertions.assertEquals(Optional.empty(), actual);

        } else {
            Optional<EntiteitKenmerk> actual = entiteitKenmerkRepository.findById(entiteitKenmerkId);
            EntiteitKenmerk expected = new EntiteitKenmerk(entiteitKenmerkId, String.valueOf(sector));

            Assertions.assertEquals(Optional.of(expected), actual);
        }
    }


    public static Stream<Arguments> provideSectorInput() {
        return Stream.of(
                Arguments.of(
                        "GivenSectorIsNegative",
                        999L,
                        -1,
                        new EntiteitKenmerkId(999L, KenmerkType.SECTR.getValue(), -1),
                        Logging2.Bewerking.DELETE
                ),
                Arguments.of(
                        "GivenSectorForEntiteit999IsOne",
                        999L,
                        1,
                        new EntiteitKenmerkId(999L, KenmerkType.SECTR.getValue(), -1),
                        Logging2.Bewerking.UPDATE
                ),
                Arguments.of(
                        "GivenSectorForEntiteit888IsThree",
                        888L,
                        3,
                        new EntiteitKenmerkId(888L, KenmerkType.SECTR.getValue(), -1),
                        Logging2.Bewerking.INSERT
                )
        );
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideSaveEntiteitKenmerkIdsInput")
	void saveEntiteitKenmerkIds(String testCase, Long bsnRsin, String kenmerkType, Integer kenmerkId, EntiteitKenmerk expectedEntiteitKenmerk, Logging2.Bewerking bewerking) {
        cut.saveEntiteitKenmerkIds(bsnRsin, kenmerkType, kenmerkId, TEST_LOGGING_ID_1);
        Optional<EntiteitKenmerk> entiteitKenmerkOpt = entiteitKenmerkRepository.findById(new EntiteitKenmerkId(bsnRsin, kenmerkType, kenmerkId));
        Assertions.assertTrue(entiteitKenmerkOpt.isPresent());
        Assertions.assertEquals(expectedEntiteitKenmerk, entiteitKenmerkOpt.get());
        LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, bsnRsin, bewerking);
    }

    private static Stream<Arguments> provideSaveEntiteitKenmerkIdsInput() {
        return Stream.of(
                Arguments.of(
                        "givenExistingEntiteitKenmerkWithDifferentValues_whenCreate_ThenUpdateValues",
                        111L,
                        "TESTGRP",
                        1,
                        new EntiteitKenmerk(
                                ENTITEIT_KENMERK_ID_1,
                                "false"
                        ),
                        Logging2.Bewerking.UPDATE
                ),
                Arguments.of(
                        "givenNonExistingEntiteitKenmerk_whenCreate_ThenNewWithValues",
                        112L,
                        "TESTGRP",
                        2,
                        new EntiteitKenmerk(
                                ENTITEIT_KENMERK_ID_2,
                                "false"
                        ),
                        Logging2.Bewerking.INSERT
                )
        );
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideSaveEntiteitKenmerkenInput")
	void saveEntiteitKenmerken(String testCase, Long bsnRsin, String kenmerkType, List<KenmerkWithValuesDto> kenmerkenList, List<EntiteitKenmerk> expectedKenmerkenList) {
        setupSaveEntiteitKenmerken();
        cut.saveEntiteitKenmerken(bsnRsin, kenmerkType, kenmerkenList, TEST_LOGGING_ID_1);
        var actualList = new ArrayList<EntiteitKenmerk>();
        for (KenmerkWithValuesDto withValuesDto : kenmerkenList) {
            var entiteitKenmerkId = new EntiteitKenmerkId(bsnRsin, kenmerkType, withValuesDto.getId());
            Optional<EntiteitKenmerk> entiteitKenmerkOpt = entiteitKenmerkRepository.findById(entiteitKenmerkId);
            Assertions.assertTrue(entiteitKenmerkOpt.isPresent());
            actualList.add(entiteitKenmerkOpt.get());
        }
        Assertions.assertEquals(expectedKenmerkenList, actualList);
        LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, bsnRsin, Logging2.Bewerking.INSERT, 2);
	}

    private void setupSaveEntiteitKenmerken() {
        this.entiteitKenmerkRepository.saveAll(
                List.of(
                        new EntiteitKenmerk(
                                new EntiteitKenmerkId(
                                        113L, "TESTGRP", 1
                                ),
                                "true"
                        ),
                        new EntiteitKenmerk(
                                new EntiteitKenmerkId(
                                        113L, "TESTGRP", 2
                                ),
                                "false"
                        ),
                        new EntiteitKenmerk(
                                new EntiteitKenmerkId(
                                        113L, "TESTGRP", 3
                                ),
                                "true"
                        )
                )
        );
    }

    private static Stream<Arguments> provideSaveEntiteitKenmerkenInput() {
        return Stream.of(
                Arguments.of(
                        "givenPartlyNewEntiteitKenmerkenAndPartlyWithValues_WhenProcessed_ThenExpectedList",
                        113L,
                        "TESTGRP",
                        List.of(
                                new KenmerkWithValuesDto(1, "TESTGRP", "test", true, null),
                                new KenmerkWithValuesDto(2, "TESTGRP", "test 2", false, null),
                                new KenmerkWithValuesDto(3, "TESTGRP", "test 3", true, null),
                                new KenmerkWithValuesDto(4, "TESTGRP", "test 4", false, null),
                                new KenmerkWithValuesDto(5, "TESTGRP", "test 5", true, null)
                        ),
                        List.of(
                                new EntiteitKenmerk(
                                        new EntiteitKenmerkId(
                                                113L, "TESTGRP", 1
                                        ),
                                        "true"
                                ),
                                new EntiteitKenmerk(
                                        new EntiteitKenmerkId(
                                                113L, "TESTGRP", 2
                                        ),
                                        "false"
                                ),
                                new EntiteitKenmerk(
                                        new EntiteitKenmerkId(
                                                113L, "TESTGRP", 3
                                        ),
                                        "true"
                                ),
                                new EntiteitKenmerk(
                                        new EntiteitKenmerkId(
                                                113L, "TESTGRP", 4
                                        ),
                                        "false"
                                ),
                                new EntiteitKenmerk(
                                        new EntiteitKenmerkId(
                                                113L, "TESTGRP", 5
                                        ),
                                        "true"
                                )
                        )
                )
        );
    }
}
