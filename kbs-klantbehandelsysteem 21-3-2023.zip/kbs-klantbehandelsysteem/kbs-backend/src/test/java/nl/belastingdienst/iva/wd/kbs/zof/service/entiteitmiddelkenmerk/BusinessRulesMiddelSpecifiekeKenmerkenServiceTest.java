package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk;

import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkSelection;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.DuplicatePolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.HigherLevelExistsCheckPolicy;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.LowerLevelExistsCheckPolicy;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;

@ExtendWith(MockitoExtension.class)
class BusinessRulesMiddelSpecifiekeKenmerkenServiceTest {

	public static final String DUPLICATE_MESSAGE = "Deze combinatie bestaat al.";
	public static final String LOWER_LEVEL_EXISTS_MESSAGE = "Één van de kenmerken wordt al op een lager niveau gebruikt.";
	public static final String HIGHER_LEVEL_EXISTS_MESSAGE = "Één van de kenmerken wordt al op een hoger niveau gebruikt.";
	private static final String WRONGLY_FORMATTED = "Wrongly formatted";
	public static final List<EntiteitMiddelKenmerk> ENTITEIT_MIDDEL_KENMERK_LIST = List.of(
			new EntiteitMiddelKenmerk(1L, 1L, 10L, 20L, 30L, null, 999L),
			new EntiteitMiddelKenmerk(2L, 2L, 11L, 21L, 31L, null, 999L),
			new EntiteitMiddelKenmerk(3L, 3L, 12L, 22L, 32L, null, 999L));

	@Mock
	private EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepositoryMock;

	@InjectMocks
	BusinessRulesMiddelSpecifiekeKenmerkenService businessRulesService;

	static List<EntiteitMiddelKenmerk> collectie;

	@Test
	@DisplayName("Check for wrong combination in selection")
	void checkForWrongCombinationInSelection() {
		Assertions.assertThrows(BusinessRuleException.class, () -> new EntiteitMiddelKenmerkSelection(null, 10L, 21L, 10L), WRONGLY_FORMATTED);
		Assertions.assertThrows(BusinessRuleException.class, () -> new EntiteitMiddelKenmerkSelection(null, null, 21L, 96L), WRONGLY_FORMATTED);
		Assertions.assertThrows(BusinessRuleException.class, () -> new EntiteitMiddelKenmerkSelection(1L, 10L, null, 20L), WRONGLY_FORMATTED);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	@DisplayName("Check hierarchy rules.")
	void checkSelection(String testName, List<EntiteitMiddelKenmerk> collectie, EntiteitMiddelKenmerkSelection entiteitMiddelKenmerk,
			boolean expectRuleViolation, String message, Class<?> policyClass) {

		Optional<BusinessRuleError> businessRuleError = businessRulesService.validToBusinessRules(collectie, entiteitMiddelKenmerk);

		boolean errorIsPresent = businessRuleError.isPresent();
		Assertions.assertEquals(expectRuleViolation, errorIsPresent);
		if (!message.isEmpty()) {
			Assertions.assertEquals(message,  errorIsPresent ? businessRuleError.get().getMessage(): "");
		}

		if(policyClass != null){
			Assertions.assertEquals(policyClass, businessRuleError.<Object>map(BusinessRuleError::getPolicyClass)
																  .orElse(null));
		}
	}

	private static Stream<Arguments> provideInput() {

		return Stream.of(

				/* givenCollectie */
				Arguments.of("WhenH1-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(1L, null, null, null), true, DUPLICATE_MESSAGE, DuplicatePolicy.class),
				Arguments.of("WhenH2-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(2L, null, null, null), true, LOWER_LEVEL_EXISTS_MESSAGE, LowerLevelExistsCheckPolicy.class),
				Arguments.of("WhenH5-ThenPass", collectie,
						new EntiteitMiddelKenmerkSelection(5L, null, null, null), false,
						"", null),
				Arguments.of("WhenH1Sre10-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(1L, 10L, null, null), true, LOWER_LEVEL_EXISTS_MESSAGE, LowerLevelExistsCheckPolicy.class),
				Arguments.of("WhenH2Sre10-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(2L, 10L, null, null), true,
						DUPLICATE_MESSAGE, DuplicatePolicy.class),
				Arguments.of("WhenH2Sre15-ThenPass", collectie,
						new EntiteitMiddelKenmerkSelection(2L, 15L, null, null), false,
						"", null),
				Arguments.of("WhenH3Sre11Srt20-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(3L, 11L, 20L, null), true,
						DUPLICATE_MESSAGE, DuplicatePolicy.class),
				Arguments.of("WhenH2Sre10Srt21-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(2L, 10L, 21L, null), true, LOWER_LEVEL_EXISTS_MESSAGE, LowerLevelExistsCheckPolicy.class),
				Arguments.of("WhenH2Sre10Srt25-ThenPass", collectie,
						new EntiteitMiddelKenmerkSelection(2L, 11L, 25L, null), false,
						"", null),
				Arguments.of("WhenH3Sre11Srt20-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(3L, 11L, 20L, null), true,
						DUPLICATE_MESSAGE, DuplicatePolicy.class),
				Arguments.of("WhenH3Sre11Srt20Srd30-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(3L, 11L, 20L, 30L), true, LOWER_LEVEL_EXISTS_MESSAGE, LowerLevelExistsCheckPolicy.class),
				Arguments.of("WhenH3Sre11Srt25Srd35-ThenPass", collectie,
						new EntiteitMiddelKenmerkSelection(3L, 11L, 25L, 35L), false,
						"", null),
				Arguments.of("WhenH4Sre12Srt21Srd30-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(4L, 12L, 21L, 30L), true,
						DUPLICATE_MESSAGE, DuplicatePolicy.class),
				Arguments.of("WhenH4Sre12Srt21-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(4L, 12L, 21L, null), true, HIGHER_LEVEL_EXISTS_MESSAGE, HigherLevelExistsCheckPolicy.class),
				Arguments.of("WhenH3Sre11-ThenAlreadyExists", collectie,
						new EntiteitMiddelKenmerkSelection(3L, 11L, null, null), true, HIGHER_LEVEL_EXISTS_MESSAGE, HigherLevelExistsCheckPolicy.class)
		);
	}

	@BeforeAll
	static void beforeAll() {
		// creation:
		// kleine collectie om de verschillende rules tegen te houden.
		// h-hoofdkenmerk, sre - subkenmerk1, srt - subkenmerk2, srd - subkenmerk3
		// collectie: [
		// h1
		// h2 sre10
		// h3 sre11 srt20
		// h4 sre12 srt21 srd30
		// ]

		collectie = List.of(
				new EntiteitMiddelKenmerk(1L, 1L, null, null, null,null, 999L),
				new EntiteitMiddelKenmerk(2L, 2L, 10L, null, null, null, 999L),
				new EntiteitMiddelKenmerk(3L, 3L, 11L, 20L, null,null, 999L),
				new EntiteitMiddelKenmerk(4L, 4L, 12L, 21L, 30L, null, 999L)
		);
	}

	@Test
	void testValidateMethod() {
		when(entiteitMiddelKenmerkRepositoryMock.findEntiteitMiddelKenmerkByEntiteitNummer(999L)).thenReturn(
				ENTITEIT_MIDDEL_KENMERK_LIST
		);

		var alreadyExists = businessRulesService.validate(999L, new EntiteitMiddelKenmerkSelection(1L, null, null, null));
		Assertions.assertTrue(alreadyExists.isPresent());

		var doesNotAlreadyExist = businessRulesService.validate(999L, new EntiteitMiddelKenmerkSelection(5L, null, null, null));
		Assertions.assertFalse(doesNotAlreadyExist.isPresent());

	}

	@Test
	void testValidateWithCurrentIdMethod() {
		when(entiteitMiddelKenmerkRepositoryMock.findEntiteitMiddelKenmerkByEntiteitNummerAndIdIsNot(999L, 1L)).thenReturn(
				ENTITEIT_MIDDEL_KENMERK_LIST
		);

		var alreadyExists = businessRulesService.validateExcludingCurrentId(999L, new EntiteitMiddelKenmerkSelection(2L, null, null, null), 1L);
		Assertions.assertTrue(alreadyExists.isPresent());

		var doesNotAlreadyExist = businessRulesService.validateExcludingCurrentId(999L, new EntiteitMiddelKenmerkSelection(5L, null, null, null), 1L);
		Assertions.assertFalse(doesNotAlreadyExist.isPresent());
	}

}
