/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieStrategieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStrategieRisicosRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieStatusService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.status.CheckStrategieService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
@ExtendWith(MockitoExtension.class)
class KlantsessieStrategieServiceTest {
    private final String TEST_LOGGING_ID_1 = "0ok22ul8s0q5b";

    @MockBean
    private KlantsessieService klantsessieService;
    @MockBean
    private Logging2Service logging2ServiceMock;
    @Autowired
    private KlantSessieStrategieRepository klantSessieStrategieRepository;
    @MockBean
    private KlantsessieStrategieRisicosRepository klantsessieStrategieRisicosRepository;
    @MockBean
    private CheckStrategieService checkStrategieService;
    @MockBean
    private KlantsessieStatusService klantsessieStatusService;

    @Autowired
    MiddelRisicoRepository middelRisicoRepository;
    @Autowired
    private KlantsessieStrategieService cut;


    @BeforeEach
    void setUp() {
        setupKlantsessieStrategie();
        middelRisicoRepository.saveAll(List.of(
                new MiddelRisico(1L, 12, "risco 1", null, 6L),
                new MiddelRisico(2L, 12, "risco 2", 1L, 2L),
                new MiddelRisico(3L, 24, "Vermindering ivm. dooruitdeling (art. 11)", 28L, 1L)
        ));
        stubCurrentKlantSessies();
    }

    private void setupKlantsessieStrategie() {
        this.klantSessieStrategieRepository.saveAll(
                List.of(
                        new KlantsessieStrategie(888L, 12, "korteTermijn 1 VPB", "middellangeTermijn 1 VPB"),
                        new KlantsessieStrategie(999L, 12, "korteTermijn 1 VPB", "middellangeTermijn 1 VPB"),
                        new KlantsessieStrategie(999L, 12, "korteTermijn 2 VPB", "middellangeTermijn 2 VPB"),
                        new KlantsessieStrategie(999L, 24, "korteTermijn 1 Dividendbelasting", "middellangeTermijn Dividendbelasting Dividendbelasting")
                ));
    }

    private void stubCurrentKlantSessies() {
        Klantsessie klantsessie887 = new Klantsessie(887L);
        klantsessie887.setId(887L);
        klantsessie887.setEinddatum(LocalDateTime.of(2022, 1, 1, 1, 1));
        Klantsessie klantsessie888 = new Klantsessie(123L);
        klantsessie888.setId(888L);
        klantsessie888.setEinddatum(LocalDateTime.of(2022, 1, 1, 1, 1));
        Klantsessie klantsessie999 = new Klantsessie(111L);
        klantsessie999.setId(999L);
        klantsessie999.setEinddatum(LocalDateTime.of(2022, 2, 2, 2, 2));
        when(klantsessieService.getCurrentKlantsessie(887L)).thenReturn(klantsessie887);
        when(klantsessieService.getCurrentKlantsessie(888L)).thenReturn(klantsessie888);
        when(klantsessieService.getCurrentKlantsessie(999L)).thenReturn(klantsessie999);
    }

    private void stubPreviousKlantSessies() {
        Klantsessie klantsessie888 = new Klantsessie(123L);
        klantsessie888.setId(888L);
        klantsessie888.setEinddatum(LocalDateTime.of(2022, 1, 1, 1, 1));
        Klantsessie klantsessie999 = new Klantsessie(999L);
        klantsessie999.setId(999L);
        klantsessie999.setEinddatum(LocalDateTime.of(2022, 2, 2, 2, 2));
        when(klantsessieService.getPreviousKlantsessie(555L)).thenReturn(Optional.empty());
        when(klantsessieService.getPreviousKlantsessie(888L)).thenReturn(Optional.of(klantsessie888));
        when(klantsessieService.getPreviousKlantsessie(999L)).thenReturn(Optional.of(klantsessie999));

    }


    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideCurrentKsInput")
    void getCurrentKlantsessieStrategie(String testCaseName, Long entiteitnummer, Integer middelId, KlantsessieStrategieDto expectedOutput) {
        KlantsessieStrategieDto KlantsessieStrategieDto = this.cut.getCurrentKlantsessieStrategie(entiteitnummer, middelId);
        Assertions.assertEquals(expectedOutput, KlantsessieStrategieDto);
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("providePreviousKsInput")
    void getPreviousKlantsessieStrategie(String testCaseName, Long entiteitnummer, Integer middelId, KlantsessieStrategieDto expectedOutput) {
        stubPreviousKlantSessies();
        KlantsessieStrategieDto KlantsessieStrategieDto = this.cut.getPreviousKlantsessieStrategie(entiteitnummer, middelId);
        Assertions.assertEquals(expectedOutput, KlantsessieStrategieDto);
    }

    @Test
    @DisplayName("saveKlantsessieStrategieKorteTermijn")
    void saveKlantsessieStrategieKorteTermijn() {
        //Given
        when(klantsessieService.getCurrentKlantsessie(123L)).thenReturn(
                new Klantsessie(888L, 123L, null, null,false,false,null, null)
        );
        KlantsessieStrategieDto test = new KlantsessieStrategieDto (888L, 12, "saving KorteTermijn", null);
        //When
        KlantsessieStrategieDto actual = cut.saveKlantsessieStrategieKorteTermijn(test, 123L, 12, TEST_LOGGING_ID_1);
        LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, 123L, Logging2.Bewerking.UPDATE);
        //Then
        Assertions.assertEquals(test.getKorteTermijn(),  actual.getKorteTermijn());
        //step enum and status are tested in other class -> verify with null
        verify(klantsessieStatusService, times(1)).setStepStatus(123L, 12, null, null);
    }

    @Test
    @DisplayName("saveKlantsessieStrategieMiddelLangeTermijn")
    void saveKlantsessieStrategieMiddelLangeTermijn() {
        //Given
        when(klantsessieService.getCurrentKlantsessie(123L)).thenReturn(
                new Klantsessie(888L, 123L, null, null,false,false,null, null)
        );
        KlantsessieStrategieDto test = new KlantsessieStrategieDto (888L, 12, null, "saving MiddellangeTermijn");
        //When
        KlantsessieStrategieDto actual = cut.saveKlantsessieStrategieMiddelLangeTermijn(test, 123L, 12, TEST_LOGGING_ID_1);
        LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, 123L, Logging2.Bewerking.UPDATE);
        //Then
        Assertions.assertEquals(test.getMiddellangeTermijn(),  actual.getMiddellangeTermijn());
        //step enum and status are tested in other class -> verify with null
        verify(klantsessieStatusService, times(1)).setStepStatus(123L, 12, null, null);
    }


    @Test
    @DisplayName("saveSelectedRisicos")
    void saveSelectedRisicos() {
        MiddelRisico lowestAsHoofdRisicoId = new MiddelRisico(1L, 12, "risco 1", null, 6L);
        MiddelRisico lowestAsSubRisicoId = new MiddelRisico(2L, 12, "risco 2", 3L, 2L);

        List<KlantsessieStrategieRisico> toSave = List.of(
                new KlantsessieStrategieRisico(1L, 12, 1L, lowestAsHoofdRisicoId),
                new KlantsessieStrategieRisico(1L, 12, 2L, lowestAsSubRisicoId));

        when(checkStrategieService.getStepEnum()).thenReturn(StepEnum.STRATEGIE);
        when(checkStrategieService.check(887L, 12)).thenReturn(StepStatusEnum.TOUCHED);

        cut.saveSelectedRisicos(887L, toSave, TEST_LOGGING_ID_1);
        LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, 887L, Logging2.Bewerking.INSERT, toSave.size());
        Mockito.verify(klantsessieStrategieRisicosRepository, times(1)).save(toSave.get(0));
        Mockito.verify(klantsessieStatusService, times(2)).setStepStatus(887L, 12, StepEnum.STRATEGIE, StepStatusEnum.TOUCHED);
    }

    @Test
    @DisplayName("deleteKlantsessieStrategieRisico")
    void deleteKlantsessieStrategieRisico() {
        MiddelRisico lowestAsHoofdRisicoId = new MiddelRisico(1L, 12, "risco 1", null, 6L);
        MiddelRisico lowestAsSubRisicoId = new MiddelRisico(2L, 12, "risco 2", 3L, 2L);

        List<KlantsessieStrategieRisico> toSave = List.of(
                new KlantsessieStrategieRisico(1L, 12, 1L, lowestAsHoofdRisicoId),
                new KlantsessieStrategieRisico(1L, 12, 2L, lowestAsSubRisicoId));

        when(klantsessieStrategieRisicosRepository.findById(new KlantsessieStrategieRisico.PrimaryKey(1L, 12, 1L)))
                .thenReturn(Optional.of(toSave.get(0)));

        when(checkStrategieService.getStepEnum()).thenReturn(StepEnum.STRATEGIE);
        when(checkStrategieService.check(887L, 12)).thenReturn(StepStatusEnum.INITIAL);

        cut.deleteKlantsessieStrategieRisico(887L, 1L, 12, 1L, TEST_LOGGING_ID_1);
        LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, 887L, Logging2.Bewerking.DELETE);

        Mockito.verify(klantsessieStrategieRisicosRepository, times(1)).delete(toSave.get(0));
        Mockito.verify(klantsessieStatusService, times(1)).setStepStatus(887L, 12, StepEnum.STRATEGIE, StepStatusEnum.INITIAL);
    }

    public static Stream<Arguments> provideCurrentKsInput() {
        return Stream.of(
                Arguments.of(
                        "GivenCurrentKlantsessieIsEmptyThenReturnNullTermijnen", 887L, 12,
                        new KlantsessieStrategieDto(887L, 12, null, null)),
                Arguments.of(
                        "GivenCurrentKlantsessieIsOnlyFilledForMiddel12WhenRequestedMiddel24ThenReturnNullTermijnen", 888L, 24,
                        new KlantsessieStrategieDto(888L, 24, null, null)
                        ),
                Arguments.of(
                        "GivenCurrentKlantsessieExistsForMiddel12WhenRequestedMiddel12ThenReturnFilledDto", 888L, 12,
                        new KlantsessieStrategieDto(888L, 12, "korteTermijn 1 VPB", "middellangeTermijn 1 VPB")
                        ),
                Arguments.of(
                        "GivenCurrentKlantsessieIsFilledForMiddel12And24WhenRequestMiddelId24ThenReturnOnlyMiddelId24", 999L, 24,
                        new KlantsessieStrategieDto(999L, 24, "korteTermijn 1 Dividendbelasting", "middellangeTermijn Dividendbelasting Dividendbelasting")
                ));
    }

    public static Stream<Arguments> providePreviousKsInput() {
        return Stream.of(
                Arguments.of(
                        "GivenPreviousKlantsessieDoesNotExistThenReturnNull", 555L, 12, null),
                Arguments.of(
                        "GivenPreviousKlantsessieIsOnlyFilledForMiddel12WhenRequestedMiddel24ThenReturnNull", 888L, 24, null),
                Arguments.of(
                        "GivenPreviousKlantsessieIsOnlyFilledForMiddel12WhenRequestedMiddel12ThenReturnFilledDto", 888L, 12,
                        new KlantsessieStrategieDto(888L, 12, "korteTermijn 1 VPB", "middellangeTermijn 1 VPB") ),
                Arguments.of(
                        "GivenPreviousKlantsessieIsFilledForMiddel12And24WhenRequestMiddelId24ThenReturnOnlyMiddelId24", 999L, 24,
                        new KlantsessieStrategieDto(999L, 24, "korteTermijn 1 Dividendbelasting", "middellangeTermijn Dividendbelasting Dividendbelasting")
                )
        );
    }

}
