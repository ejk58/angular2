package nl.belastingdienst.iva.wd.kbs.shared.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Import;

import nl.belastingdienst.iva.wd.kbs.rest.security.MethodSecurityConfigTestVersion;

@Import(MethodSecurityConfigTestVersion.class)
@EnableCaching
@Retention(RetentionPolicy.RUNTIME)
public @interface RestControllerTestConfiguration {
}
