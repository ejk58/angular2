package nl.belastingdienst.iva.wd.kbs.maintenancemessage.service;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.maintenancemessage.dao.MessageCreateUpdateDeleteRepository;
import nl.belastingdienst.iva.wd.kbs.maintenancemessage.domain.Message;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class GetCurrentMessagesServiceTest {

	@Autowired
	private MessageCreateUpdateDeleteRepository messageCreateUpdateDeleteRepository;

	@Autowired
	private GetCurrentMessagesService sut;

	@BeforeEach
	void setUp() {
		var startActive = LocalDateTime.now().minusDays(2);
		var endActive = LocalDateTime.now().plusHours(1);
		var startNonActive = LocalDateTime.now().plusMinutes(15);
		var endNonActive = LocalDateTime.now().minusHours(2);

		// One way of prepping testdata in in-memory H2 database
		this.messageCreateUpdateDeleteRepository.saveAll(
				List.of(
						new Message(1L, "Oude niet-actieve melding", startActive, endNonActive),
						new Message(2L, "Actieve melding", startActive.minusSeconds(1), endActive),
						new Message(3L, "Actieve melding nieuwer", startActive, endActive),
						new Message(4L, "Nog niet-actieve melding", startNonActive, endActive),
						new Message(5L, "Onmogelijke melding (einddatum ligt voor startdatum)", startNonActive, endNonActive)
				)
		);
	}

	// Helpful articles:
	// https://howtodoinjava.com/spring-boot2/testing/spring-boot-2-junit-5/
	// https://www.vincenzoracca.com/en/blog/framework/spring/integration-test/
	@Test
	// Another way of prepping testdata, although keep in mind that the compiler can't assist you here.
//	@Sql(executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD,
//			statements = "INSERT INTO message (id, value, start, end) VALUES "
//					+ " (1, 'Actieve melding', '2022-05-13 12:37:00.000', '2022-05-17 12:37:00.000'), "
//					+ " (2, 'Niet-actieve melding', '2022-05-23 12:37:00.000', '2022-05-27 12:37:00.000'), ")
//	@Sql(executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD, statements = "DELETE FROM message")
	void getAll_WhenRetrievedSuccessfully_ThenReturnsActiveMessagesSortedByNewestStartingDate() {
		List<Message> all = this.sut.getAll();
		Assertions.assertEquals(2, all.size());
		Assertions.assertEquals("Actieve melding nieuwer", all.get(0).getValue());
		Assertions.assertEquals("Actieve melding", all.get(1).getValue());
	}
}
