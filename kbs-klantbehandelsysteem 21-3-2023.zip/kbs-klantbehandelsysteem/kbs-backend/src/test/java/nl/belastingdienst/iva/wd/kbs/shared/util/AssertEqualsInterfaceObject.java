/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: AssertEqualInterfaceObject.java
 *             Auteur: duisr01
 *    Creatietijdstip: 17-11-2022 16:00
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.shared.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.opentest4j.AssertionFailedError;

import nl.belastingdienst.iva.wd.kbs.shared.exceptions.AssertEqualsInterfaceException;

public class AssertEqualsInterfaceObject {

	public static void assertEquals(Object expected, Object actual) {
		var expectedInterface = expected.getClass().getInterfaces()[0];
		var actualInterface = actual.getClass().getInterfaces()[0];
		Assertions.assertEquals(expectedInterface, actualInterface);
		var declaredMethods = expectedInterface.getDeclaredMethods();
		for (Method declaredMethod : declaredMethods) {
			if(!declaredMethod.getName().startsWith("get")){
				continue;
			}

			try {
				Assertions.assertEquals(declaredMethod.invoke(expected), declaredMethod.invoke(actual));
			} catch (AssertionFailedError exception){
				throw new AssertEqualsInterfaceException(declaredMethod, exception);
			} catch (IllegalAccessException | InvocationTargetException e) {
				throw new AssertionFailedError("Failed to invoke method "+ declaredMethod.getName());
			}
		}
	}

	public static void assertEquals(List<?> expected, List<?> actual) {
		Assertions.assertEquals(expected.size(), actual.size());
		for (int i = 0; i < expected.size(); i++) {
			try {
				assertEquals(expected.get(i), actual.get(i));
			} catch (AssertEqualsInterfaceException exception){
				throw new AssertionFailedError(
						"List item #"+i+", field: "+ exception.getDeclaredMethod().getName(),
						exception.getAssertionFailedError().getExpected(),
						exception.getAssertionFailedError().getActual());
			}
		}
	}

}
