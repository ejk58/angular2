package nl.belastingdienst.iva.wd.kbs.krr;

import nl.belastingdienst.iva.wd.kbs.krr.domain.BepaalCategorieGo;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = KrrRestController.class)
@ExtendWith(MockitoExtension.class)
@WithMockUser(username = "ivatest1", authorities = {"AUG_KBS_BEHANDELAAR"})
@RestControllerTestConfiguration
class KrrRestControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private KrrService krrServiceMock;

    private static final String JSON = MediaType.APPLICATION_JSON.toString();
    private final BepaalCategorieGo[] TEST_RESPONSE = new BepaalCategorieGo[]{new BepaalCategorieGo("Test middel", 888L)};

    @Test
    void givenEntiteitnummer_ThenReturnCategorieGoResponse() throws Exception {
        when(krrServiceMock.getCategorieGo(888L))
                .thenReturn(new BepaalCategorieGo[]{new BepaalCategorieGo("Test middel", 888L)});

        mockMvc.perform(MockMvcRequestBuilders.get("/api/krr/categorie-go/{entiteitnummer}", 888)
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(TEST_RESPONSE, BepaalCategorieGo[].class))
        ;
    }

    @Test
    void givenInaccessibleEntiteitNummer_ThenReturnBadRequest() throws Exception {
        when(krrServiceMock.getCategorieGo(111L))
                .thenThrow(new ResponseStatusException(HttpStatus.BAD_REQUEST, "Testing exception"));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/krr/categorie-go/{entiteitnummer}", 111)
                        .contentType(JSON))
                .andExpect(status().isBadRequest())
        ;
    }
}