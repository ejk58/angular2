package nl.belastingdienst.iva.wd.kbs.service;

import nl.belastingdienst.iva.wd.kbs.dao.MiddelnaamAfkortingRepository;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelnaamAfkorting;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@SpringBootKbsTest
class MiddelnaamAfkortingServiceTest {

    @Autowired
    private MiddelnaamAfkortingRepository middelnaamAfkortingRepository;
    @Autowired
    private MiddelnaamAfkortingService cut;

    private static final List<MiddelnaamAfkorting> TEST_LIST =  List.of(
            new MiddelnaamAfkorting(12, "naam 1", "afk 1", 1L),
            new MiddelnaamAfkorting(13, "naam 1", "afk 2", 2L),
            new MiddelnaamAfkorting(14, "naam 1", "afk 3", 3L),
            new MiddelnaamAfkorting(24, "naam 1", "afk 4", 4L));

    @BeforeEach
    void setUp() {
        this.middelnaamAfkortingRepository.saveAll(TEST_LIST);
    }

    @Test
    void getMiddelnaamAfkortingen() {
        List<MiddelnaamAfkorting> actual = cut.getMiddelnaamAfkortingen();
        Assertions.assertEquals(TEST_LIST.size(), actual.size());
        Assertions.assertEquals(TEST_LIST.get(0), actual.get(0));
    }

}