/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: AfterEachTestHook.java
 *             Auteur: duisr01
 *    Creatietijdstip: 19-5-2022 15:54
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.shared.dao;

import org.junit.jupiter.api.extension.AfterEachCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

import nl.belastingdienst.iva.wd.kbs.shared.util.EmptyTestTablesUtil;

public class AfterEachTestHook implements AfterEachCallback {

	@Override
	public void afterEach(ExtensionContext extensionContext) throws Exception {
		EmptyTestTablesUtil.emptyTables();
	}
}
