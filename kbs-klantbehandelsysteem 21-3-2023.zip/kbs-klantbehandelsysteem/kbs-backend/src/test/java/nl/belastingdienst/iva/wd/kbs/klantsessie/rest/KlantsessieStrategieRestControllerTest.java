/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import static nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers.responseBody;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategieRisico;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie.GetSelectedRisicoService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie.KlantsessieStrategieService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.GetLowestEntiteitMiddelRisicoService;

@WebMvcTest(controllers = KlantsessieStrategieRestController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class KlantsessieStrategieRestControllerTest {

    private static final String JSON = MediaType.APPLICATION_JSON.toString();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockBean
    private KlantsessieStrategieService klantsessieStrategieService;

    @MockBean
    private GetLowestEntiteitMiddelRisicoService getLowestEntiteitMiddelRisicoService;

    @MockBean
    private GetSelectedRisicoService getSelectedRisicoService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("getPreviousKlantsessieStrategie_WhenAPreviousKlantsessieExists_ReturnsHttp200Ok")
    void getPreviousKlantsessieStrategie() throws Exception {
        KlantsessieStrategieDto expected = new KlantsessieStrategieDto(888L, 12, "korteTermijn 1 VPB", "middellangeTermijn 1 VPB");

        when(klantsessieStrategieService.getPreviousKlantsessieStrategie(888L, 12)).thenReturn(expected);
        mockMvc.perform(get("/api/klantsessie/strategie/previous/{entiteitNummer}/{middelId}", 888L, 12)
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(expected, KlantsessieStrategieDto.class));
    }

    @Test
    @DisplayName("getCurrentKlantsessieStrategie_WhenAPreviousKlantsessieExists_ReturnsHttp200Ok")
    void getCurrentKlantsessieStrategie() throws Exception {
        KlantsessieStrategieDto expected = new KlantsessieStrategieDto(888L, 12, "korteTermijn 1 VPB", "middellangeTermijn 1 VPB");

        when(klantsessieStrategieService.getCurrentKlantsessieStrategie(888L, 12)).thenReturn(expected);
        mockMvc.perform(get("/api/klantsessie/strategie/current/{entiteitNummer}/{middelId}", 888L, 12)
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(expected, KlantsessieStrategieDto.class));
    }

    @Test
    @DisplayName("RestCallForSaveKorteTermijnKlantsessieStrategie")
    void saveKorteTermijnKlantsessieStrategie() throws Exception {
        KlantsessieStrategieDto toSave = new KlantsessieStrategieDto(888L, 12, "korteTermijn 1 VPB", null);
        when(klantsessieStrategieService.saveKlantsessieStrategieKorteTermijn(toSave, 888L, 12, "loggingId")).thenReturn(toSave);

        mockMvc.perform(post("/api/klantsessie/strategie/save/korteTermijn/{entiteitNummer}", 888L)
                        .contentType(JSON)
                        .content(objectMapper.writeValueAsString(
                                new LoggingWrapper<>("loggingId", toSave)
                        )))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(toSave, KlantsessieStrategieDto.class));
    }



    @Test
    @DisplayName("RestCallForSaveMiddellangeTermijnKlantsessieStrategie")
    void saveMiddellangeTermijnKlantsessieStrategie() throws Exception {
        KlantsessieStrategieDto toSave = new KlantsessieStrategieDto(888L, 12, null, "middellangeTermijn 1 VPB");
        when(klantsessieStrategieService.saveKlantsessieStrategieMiddelLangeTermijn(toSave, 888L, 12, "logId")).thenReturn(toSave);
        mockMvc.perform(post("/api/klantsessie/strategie/save/middellangeTermijn/{entiteitNummer}", 888L)
                        .contentType(JSON)
                        .content(objectMapper.writeValueAsString( new LoggingWrapper<>("logId",toSave))))
                .andExpect(status().isOk())
                .andExpect(responseBody().containsObjectAsJson(toSave, KlantsessieStrategieDto.class));
    }


    @Test
    void getRisicoOptions() throws Exception {
        MiddelRisico lowestAsHoofdRisicoId = new MiddelRisico(1L, 12, "risco 1", null, 6L);
        MiddelRisico lowestAsSubRisicoId = new MiddelRisico(2L, 12, "risco 2", 1L, 2L);
        List<LowestEntiteitMiddelRisico> lowestList = List.of(
                new LowestEntiteitMiddelRisico(1L, 888L, null, 1L, null, (short) 1, 96L, null, null, lowestAsHoofdRisicoId),
                new LowestEntiteitMiddelRisico(2L, 888L, null, 1L, 2L, (short) 0, 97L, 0L,null, lowestAsSubRisicoId)
        );
        when(getLowestEntiteitMiddelRisicoService.getEntiteitMiddelRisicoWithLowestByEntiteitnummerAndMiddelId(888L, 12))
                .thenReturn(lowestList);

        List<MiddelRisico> expected = List.of(lowestAsHoofdRisicoId, lowestAsSubRisicoId);

        mockMvc.perform(get("/api/klantsessie/strategie/risico/options/{entiteitNummer}/{middelId}", 888L, 12)
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(expected, MiddelRisico.class));
    }

    @Test
    void getSelectedRisicos() throws Exception {
        MiddelRisico lowestAsHoofdRisicoId = new MiddelRisico(1L, 12, "risco 1", null, 6L);
        MiddelRisico lowestAsSubRisicoId = new MiddelRisico(2L, 12, "risco 2",  3L, 2L);
        List<KlantsessieStrategieRisico> selectedList = List.of(
                new KlantsessieStrategieRisico(1L, 12, 1L, lowestAsHoofdRisicoId),
                new KlantsessieStrategieRisico(1L, 12, 2L, lowestAsSubRisicoId));
        when(getSelectedRisicoService.getSelectedList(888L, 12)).thenReturn(selectedList);

        List<MiddelRisico> expected =  List.of(lowestAsHoofdRisicoId, lowestAsSubRisicoId);

        mockMvc.perform(get("/api/klantsessie/strategie/risico/selected/{entiteitNummer}/{middelId}", 888L, 12)
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(expected, MiddelRisico.class));
    }

    @Test
    void saveSelectedRisicos() throws Exception {
        MiddelRisico lowestAsHoofdRisicoId = new MiddelRisico(1L, 12, "risco 1", null, 6L);
        MiddelRisico lowestAsSubRisicoId = new MiddelRisico(2L, 12, "risco 2",  3L, 2L);

        List<KlantsessieStrategieRisico> toSave = List.of(
                new KlantsessieStrategieRisico(1L, 12, 1L, lowestAsHoofdRisicoId),
                new KlantsessieStrategieRisico(1L, 12, 2L, lowestAsSubRisicoId)
        );
        mockMvc.perform(post("/api/klantsessie/strategie/risico/selections/save/{entiteitNummer}", 888L)
                        .contentType(JSON)
                        .content(objectMapper.writeValueAsString( new LoggingWrapper<>("logId", toSave)) ))
                .andExpect(status().isOk());
    }

    @Test
    void deleteKlantsessieStrategieRisico() throws Exception {
        mockMvc.perform(delete("/api/klantsessie/strategie/risico/delete/{entiteitNummer}/{klantsessieId}/{middelId}/{riscoId}", 888L, 1L, 12, 1L)
                        .contentType(JSON)
                        .content(objectMapper.writeValueAsString( new LoggingWrapper<>("logId", null)))
                )
                .andExpect(status().isOk());
    }

}
