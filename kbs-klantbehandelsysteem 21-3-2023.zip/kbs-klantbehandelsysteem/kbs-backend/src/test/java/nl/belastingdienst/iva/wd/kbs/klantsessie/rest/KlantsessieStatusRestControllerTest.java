package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import static nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers.responseBody;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStatus;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieStatusService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;

@WebMvcTest(controllers = KlantsessieStatusRestController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class KlantsessieStatusRestControllerTest {
	private static final long ENTITEIT_NUMMER = 888L;
	private static final String JSON = MediaType.APPLICATION_JSON.toString();
	private static final Integer EXISTING_MIDDEL_ID = 12;

	private final ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private KlantsessieStatusService klantsessieStatusServiceMock;


	@Test
	void getCurrentKlantsessieStatus_ReturnsHttp200Ok() throws Exception {
		KlantsessieStatus expectedKlantsessieStatus = new KlantsessieStatus(ENTITEIT_NUMMER, EXISTING_MIDDEL_ID);
		when(klantsessieStatusServiceMock.getCurrentKlantsessieStatus(ENTITEIT_NUMMER, EXISTING_MIDDEL_ID)).thenReturn(expectedKlantsessieStatus);
		mockMvc.perform(get("/api/klantsessie/status/{entiteitNummer}/{middelId}", ENTITEIT_NUMMER, EXISTING_MIDDEL_ID).contentType(JSON))
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(expectedKlantsessieStatus, KlantsessieStatus.class));
	}

	@Test
	void updateVoorbereidingAfgerond_ReturnsHttp200Ok() throws Exception {
		mockMvc.perform(post("/api/klantsessie/status/{entiteitNummer}/{middelId}/voorbereidingAfgerond", ENTITEIT_NUMMER, EXISTING_MIDDEL_ID)
						.contentType(JSON)
						.content(objectMapper.writeValueAsString( new LoggingWrapper<>("logId", null))))
				.andExpect(status().isOk());
		verify(klantsessieStatusServiceMock, times(1)).updateVoorbereidingAfgerond(ENTITEIT_NUMMER, EXISTING_MIDDEL_ID, "logId");
	}
}
