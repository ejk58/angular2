package nl.belastingdienst.iva.wd.kbs.maintenancemessage.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.maintenancemessage.domain.Message;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class MessageReadRepositoryTest {

	@Autowired
	private MessageCreateUpdateDeleteRepository messageCreateUpdateDeleteRepository;

	@Autowired
	private MessageReadRepository sut;

	@BeforeEach
	void setUp() {
		var startActive = LocalDateTime.now()
									   .minusDays(2);
		var endActive = LocalDateTime.now()
									 .plusHours(1);
		var startNonActive = LocalDateTime.now()
										  .plusMinutes(15);
		var endNonActive = LocalDateTime.now()
										.minusHours(2);

		this.messageCreateUpdateDeleteRepository.saveAll(
				List.of(new Message(null, "Oude niet-actieve melding", startActive, endNonActive),
						new Message(null, "Actieve melding", startActive.minusSeconds(1), endActive),
						new Message(null, "Actieve melding nieuwer", startActive, endActive),
						new Message(null, "Nog niet-actieve melding", startNonActive, endActive),
						new Message(null, "Onmogelijke melding (einddatum ligt voor startdatum)", startNonActive, endNonActive)));

	}

	@Test
	void whenFindCurrentMessagesThenReturnActiveMessagesOrderStartDesc() {
		List<Message> all = this.sut.findCurrentMessages();
		Assertions.assertEquals(2, all.size());
		Assertions.assertEquals("Actieve melding nieuwer", all.get(0).getValue());
		Assertions.assertEquals("Actieve melding", all.get(1).getValue());
	}
}