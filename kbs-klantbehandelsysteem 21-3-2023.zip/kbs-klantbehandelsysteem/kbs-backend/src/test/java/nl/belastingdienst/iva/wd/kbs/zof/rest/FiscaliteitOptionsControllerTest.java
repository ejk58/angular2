package nl.belastingdienst.iva.wd.kbs.zof.rest;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.GetRisicoDropdownOptionsService;

@WebMvcTest(controllers = FiscaliteitOptionsController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class FiscaliteitOptionsControllerTest {

    @MockBean
    GetRisicoDropdownOptionsService getRisicoDropdownOptionsService;
    @Autowired
    private MockMvc mockMvc;

    private static final String JSON = MediaType.APPLICATION_JSON.toString();

    @Test
    void getMiddelRisicoStatussen() throws Exception {
        List<Kenmerk> expected = List.of(
                new Kenmerk(1, "RSTAT", "RSTAT 1", null),
                new Kenmerk(2, "RSTAT", "RSTAT 2", null),
                new Kenmerk(3, "RSTAT", "RSTAT 3", null)
        );
        when(getRisicoDropdownOptionsService.getZoFMiddelRisicoStatussen()).thenReturn(expected);

        mockMvc.perform(get("/api/fiscaliteit/options/middel-risico-status")
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(expected, Kenmerk.class));
    }

    @Test
    void getZoFMiddelRisicoBeheersingOptions() throws Exception {
        List<Kenmerk> expected = List.of(
                new Kenmerk(4, "RBEH", "RBEH 1", null),
                new Kenmerk(5, "RBEH", "RBEH 2", null)
        );
        when(getRisicoDropdownOptionsService.getZoFMiddelRisicoBeheersingOptions()).thenReturn(expected);

        mockMvc.perform(get("/api/fiscaliteit/options/middel-risico-beheersing")
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(expected, Kenmerk.class));
    }
}