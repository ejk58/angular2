package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.dao.MiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisicoDto;

@SpringBootKbsTest
class GetEntiteitMiddelRisicoServiceTest {

	public static final MiddelKenmerk MIDDEL_KENMERK_1 = new MiddelKenmerk(1L, 12, "vpb 1", null);
	@Autowired
	GetEntiteitMiddelRisicoService sut;

	@Autowired
	EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;

	@Autowired
	EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;

	@Autowired
	MiddelRisicoRepository middelRisicoRepository;

	@Autowired
	MiddelKenmerkRepository middelKenmerkRepository;

	@BeforeEach
	void setUp() {
		this.middelKenmerkRepository.saveAll(
				List.of(MIDDEL_KENMERK_1,
						new MiddelKenmerk(2L, 12, "vpb 2", null),
						new MiddelKenmerk(3L, 24, "div 1", null),
						new MiddelKenmerk(4L, 24, "div 2", null)
				)
		);

		this.entiteitMiddelKenmerkRepository.saveAll(
				List.of(
						new EntiteitMiddelKenmerk(1L, 1L, null, null, null, 2L, 111L),
						new EntiteitMiddelKenmerk(2L, 2L, null, null, null, 3L, 111L),
						new EntiteitMiddelKenmerk(3L, 3L, null, null, null, 3L, 999L),
						new EntiteitMiddelKenmerk(4L, 4L, null, null, null, 1L, 111L)
				)
		);

		this.middelRisicoRepository.saveAll(
			List.of(
					new MiddelRisico(1L, 12, "risico vpb", null, null),
					new MiddelRisico(2L, 12, "risico vpb", null, null),
					new MiddelRisico(3L, 24, "risico div", null, null)
			)
		);

		this.entiteitMiddelRisicoRepository.saveAll(
			List.of(
					new EntiteitMiddelRisico(1L, 111L, 1L, 1L, null, (short) 1, 1L, 1, 2L),
					new EntiteitMiddelRisico(2L, 111L, null, 2L, null, (short) 1, 1L, 1, 1L),
					new EntiteitMiddelRisico(3L, 111L, 4L, 3L, null, (short) 1, 1L, 1, 1L)
			)
		);
	}

	@Test
	void givenEntiteitWithEntiteitMiddelRisico_ThenOnlyEntiteitMiddelRisicoFromMiddelReturned() {
		var actualList = this.sut.getEntiteitMiddelRisicosForEntiteitEnMiddel(
				111L, 12);
		var expectedList = List.of(
				new EntiteitMiddelRisicoDto(
						2L, 111L, null, 2L, null, (short) 1, 1L, 1, 1L, null
				),
				new EntiteitMiddelRisicoDto(
						1L, 111L, 1L, 1L, null, (short) 1, 1L, 1, 2L, MIDDEL_KENMERK_1
				)
		);

		Assertions.assertEquals(expectedList, actualList);
	}

	@Test
	void givenEntiteitWithoutEntiteitMiddelRisico_ThenReturnEmptyList() {
		var actualList = this.sut.getEntiteitMiddelRisicosForEntiteitEnMiddel(
				999L, 12);
		var expectedList = List.of();

		Assertions.assertEquals(expectedList, actualList);
	}
}