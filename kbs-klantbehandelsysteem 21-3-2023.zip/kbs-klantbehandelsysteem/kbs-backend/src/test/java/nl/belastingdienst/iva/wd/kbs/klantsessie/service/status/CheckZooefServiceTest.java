package nl.belastingdienst.iva.wd.kbs.klantsessie.service.status;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieZooefRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieZooef;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class CheckZooefServiceTest {

	private static final LocalDateTime TEST_DATE_TIME = LocalDateTime.of(2022, 6, 1, 12, 55);

	@Autowired
	CheckZooefService sut;

	@Autowired
	private KlantsessieZooefRepository klantsessieZooefRepository;

	@Autowired
	private KlantsessieRepository klantsessieRepository;

	@Test
	void check() {
		this.setupKlantsessieZooefRepository();

		StepStatusEnum completeZooef = this.sut.check(1L, 12);
		StepStatusEnum initialZooef1 = this.sut.check(1L, 24);
		StepStatusEnum initialZooef2 = this.sut.check(2L, 12);

		Assertions.assertEquals(StepStatusEnum.COMPLETED, completeZooef);
		Assertions.assertEquals(StepStatusEnum.INITIAL, initialZooef1);
		Assertions.assertEquals(StepStatusEnum.INITIAL, initialZooef2);
	}

	private void setupKlantsessieZooefRepository() {
		klantsessieRepository.saveAll(
				List.of(
						new Klantsessie(1L, 1L, TEST_DATE_TIME.minusHours(2), TEST_DATE_TIME.minusHours(1),false,false,null, null								),
						new Klantsessie(2L, 2L, TEST_DATE_TIME, null,false,false,null, null)
				)
		);

		this.klantsessieZooefRepository.saveAll(
			List.of(
					new KlantsessieZooef(1L, 12, "test", false),
					new KlantsessieZooef(2L, 12, null, false)
			)
		);
	}

	@Test
	void getStepEnum() {
		Assertions.assertEquals(StepEnum.ZOOEF, this.sut.getStepEnum());
	}
}