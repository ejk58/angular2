package nl.belastingdienst.iva.wd.kbs.logging.service;

import nl.belastingdienst.iva.wd.kbs.logging.dao.Logging2Repository;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.exception.FailedToRetrieveLoggingDataException;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.internal.matchers.apachecommons.ReflectionEquals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.test.context.support.WithMockUser;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

@SpringBootKbsTest
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
class Logging2ServiceTest {

	public static final Logging2 NEWEST_TEST_LOGGING_ID_1 = new Logging2(2L, "ivatest1", LocalDateTime.of(2022, 2, 2, 9, 10, 20),
			111L, "testLoggingId1", "UPDATE", "codeSource1");
	@Autowired
	Logging2Service sut;

	@Autowired
	Logging2Repository logging2Repository;

	@BeforeEach
	void setUp() {
		this.logging2Repository.saveAll(
			List.of(
				new Logging2(
					1L,
					"ivatest1",
					LocalDateTime.of(2022, 2, 2, 9, 10, 15),
					111L,
					"testLoggingId1",
					"INSERT",
					"codeSource1"
				),
				NEWEST_TEST_LOGGING_ID_1,
				new Logging2(
						3L,
						"ivatest1",
						LocalDateTime.of(2022, 2, 2, 9, 10, 21),
						111L,
						"testLoggingId2",
						"UPDATE",
						"codeSource2"
				)
			)
		);
	}

	@Test
	void getLatestLoggingWithEntiteitNummer() {
		Logging2 actual = this.sut.getLatestLogging("testLoggingId1", 111L)
										  .orElseThrow();
		Assertions.assertEquals(NEWEST_TEST_LOGGING_ID_1, actual);

		Assertions.assertTrue(this.sut.getLatestLogging("testLoggingId_unknown", 111L).isEmpty());
		Assertions.assertTrue(this.sut.getLatestLogging("testLoggingId1", 999L).isEmpty());
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInputForSave")
	void save(String testCaseName, String loggingId, Long entiteitnummer, Logging2.Bewerking bewerking, Class<Exception> expectedException, Logging2 expectedSave) {
		if(expectedException != null){
			Assertions.assertThrows(expectedException, () -> sut.save(loggingId, entiteitnummer, bewerking));
		} else {
			sut.save(loggingId, entiteitnummer, bewerking);
			var latestLoggingOpt = this.logging2Repository.findAll()
													   .stream()
													   .max(Comparator.comparing(Logging2::getId));
			Assertions.assertTrue(latestLoggingOpt.isPresent());
			var latestLoggingActual = latestLoggingOpt.get();
			Assertions.assertTrue(new ReflectionEquals(expectedSave, "id", "changedAt").matches(latestLoggingActual));
		}
	}

	private static Stream<Arguments> provideInputForSave() {
		return Stream.of(
				Arguments.of(
						"givenLoggingIdNull_ThenThrowException",
						null,
						111L,
						Logging2.Bewerking.INSERT,
						FailedToRetrieveLoggingDataException.class,
						null
				),
				Arguments.of(
						"givenEntiteitnummerNull_ThenThrowException",
						"testLoggingId1",
						null,
						Logging2.Bewerking.INSERT,
						FailedToRetrieveLoggingDataException.class,
						null
				),
				Arguments.of(
						"givenBewerkingNull_ThenThrowException",
						"testLoggingId1",
						111L,
						null,
						FailedToRetrieveLoggingDataException.class,
						null
				),
				Arguments.of(
						"givenCompleteParams_ThenSaveLog",
						"b395aeaf-ed22-4301-b6af-e718c3828c61_testLoggingId1",
						111L,
						Logging2.Bewerking.INSERT,
						null,
						new Logging2(
								null,
								"ivatest1",
								null,
								111L,
								"b395aeaf-ed22-4301-b6af-e718c3828c61_testLoggingId1",
								Logging2.Bewerking.INSERT.name(),
								Logging2ServiceTest.class.getName()+".save"
						)
				)

		);
	}
}