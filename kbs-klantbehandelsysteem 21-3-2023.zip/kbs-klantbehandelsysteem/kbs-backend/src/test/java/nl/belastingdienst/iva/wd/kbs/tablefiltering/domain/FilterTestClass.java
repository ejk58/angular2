package nl.belastingdienst.iva.wd.kbs.tablefiltering.domain;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "TEST_FILTER")
@AllArgsConstructor
@NoArgsConstructor
public class FilterTestClass {

    @Id
    private Long id;

    @Filterable
    private Long entiteitnummer;

    @Filterable
    private String entiteitnaam;

    private String password;

    @Filterable
    private LocalDate beginDatum;

    @Filterable
    private String soort;

}
