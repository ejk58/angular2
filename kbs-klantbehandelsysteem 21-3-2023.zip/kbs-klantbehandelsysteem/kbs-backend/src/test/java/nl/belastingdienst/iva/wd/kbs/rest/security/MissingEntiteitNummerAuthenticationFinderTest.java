/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: MissingAuthenticationFinderTest.java
 *             Auteur: duisr01
 *    Creatietijdstip: 1-3-2023 14:27
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.rest.security;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;

import nl.belastingdienst.iva.wd.kbs.klantsessie.rest.KlantsessieComplianceRestController;
import nl.belastingdienst.iva.wd.kbs.rest.HelptextController;
import nl.belastingdienst.iva.wd.kbs.rest.KenmerkController;
import nl.belastingdienst.iva.wd.kbs.rest.MiddelnaamAfkortingController;
import nl.belastingdienst.iva.wd.kbs.rest.entiteit.EntiteitRestController;
import nl.belastingdienst.iva.wd.kbs.rest.feedback.FeedbackRestController;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.rest.FiscaliteitController;
import nl.belastingdienst.iva.wd.kbs.zof.rest.FiscaliteitOptionsController;

@SpringBootKbsTest
class MissingEntiteitNummerAuthenticationFinderTest {

	private static final List<Object> EXCLUDE_METHODS = List.of(
			getMethodLocation(KlantsessieComplianceRestController.class, "getKlantsessieComplianceChartLabels"),
			getMethodLocation(HelptextController.class, "getHelptext"),
			getMethodLocation(KenmerkController.class, "getRisicomanagement"),
			getMethodLocation(KenmerkController.class, "getKlantsessieComplianceComfort"),
			getMethodLocation(KenmerkController.class, "getZooAttentiepuntenLoonheffing"),
			getMethodLocation(KenmerkController.class, "getComplexiteitKenmerken"),
			getMethodLocation(KenmerkController.class, "getZooBranchecodeAanvullingen"),
			getMethodLocation(KenmerkController.class, "getActiepuntenKenmerken"),
			getMethodLocation(KenmerkController.class, "getStrategieenGebaseerdOp"),
			getMethodLocation(KenmerkController.class, "getActiepuntenBalansKenmerken"),
			getMethodLocation(KenmerkController.class, "getBedrijfsstrategien"),
			getMethodLocation(KenmerkController.class, "getGovernanceStructuur"),
			getMethodLocation(KenmerkController.class, "getZooAandachtsgebieden"),
			getMethodLocation(KenmerkController.class, "getZooAttentiepunten"),
			getMethodLocation(KenmerkController.class, "getMiddelByName"),
			getMethodLocation(KenmerkController.class, "getZooMiddelen"),
			getMethodLocation(KenmerkController.class, "getExterneOmgeving"),
			getMethodLocation(KenmerkController.class, "getTestKenmerken"),
			getMethodLocation(KenmerkController.class, "getZooAttentiepuntenInkomstenBelasting"),
			getMethodLocation(KenmerkController.class, "getActiepuntenWinstEnVerliesKenmerken"),
			getMethodLocation(MiddelnaamAfkortingController.class, "getMiddelnaamAfkortingen"),
			getMethodLocation(EntiteitRestController.class, "getOrggevegensUrl"),
			getMethodLocation(FeedbackRestController.class, "addFeedback"),
			getMethodLocation(FiscaliteitController.class, "getMiddelRisicos"),
			getMethodLocation(FiscaliteitController.class, "getMiddelKenmerken"),
			getMethodLocation(FiscaliteitController.class, "getRisicosByMiddelIdAndMiddelkenmerkId"),
			getMethodLocation(FiscaliteitController.class, "getRisicosByMiddelId"),
			getMethodLocation(FiscaliteitController.class, "getKenmerkenByMiddelId"),
			getMethodLocation(FiscaliteitController.class, "getKenmerkenForRisico"),
			getMethodLocation(FiscaliteitOptionsController.class, "getZoFMiddelRisicoBeheersingOptions"),
			getMethodLocation(FiscaliteitOptionsController.class, "getMiddelRisicoStatussen")
	);

	@Autowired
	private WebApplicationContext appContext;

	@Test
	void findMissingEntiteitNummerAuthentication() throws ClassNotFoundException {
		Map<String, Object> controllers = appContext.getBeansWithAnnotation(Controller.class);

		ArrayList<String> controllerLocations = new ArrayList<>();

		controllers.forEach((key, value) -> controllerLocations.add(value.getClass().getPackageName() + "." + StringUtils.capitalize(key)));

		ArrayList<String> controllerMethodsMissingEntiteitNummerAuthentication = new ArrayList<>();
		for (String controllerLocation : controllerLocations) {
			for (Method declaredMethod : Class.forName(controllerLocation).getDeclaredMethods()) {
				PreAuthorize annotation = declaredMethod.getAnnotation(PreAuthorize.class);
				if (annotation == null) {
					continue;
				}
				boolean hasPermissionForEntiteitNummer = annotation.value().contains("hasPermissionForEntiteitNummer");
				if (!hasPermissionForEntiteitNummer) {
					controllerMethodsMissingEntiteitNummerAuthentication.add(controllerLocation + "." + declaredMethod.getName());
				}
			}
		}

		controllerMethodsMissingEntiteitNummerAuthentication.removeIf(EXCLUDE_METHODS::contains);

		Assertions.assertTrue(controllerMethodsMissingEntiteitNummerAuthentication.isEmpty(),
				"\nThe following controller methods are missing hasPermissionForEntiteitNummer: \n" + String.join("\n",
						controllerMethodsMissingEntiteitNummerAuthentication));
	}

	private static String getMethodLocation(Class<?> controllerClass, String methodName) {
		return controllerClass.getName() + "." + methodName;
	}
}
