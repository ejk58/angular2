/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GenericRepository.java
 *             Auteur: duisr01
 *    Creatietijdstip: 18-5-2022 16:17
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.shared.util;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class EmptyTestTablesUtil {

	private static JdbcTemplate JDBC_TEMPLATE;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initStaticDependencies(){
		JDBC_TEMPLATE = this.jdbcTemplate;
	}

	public static void emptyTables(){
		var tables = JDBC_TEMPLATE.queryForList("SELECT table_name FROM information_schema.tables WHERE table_type = 'TABLE'", String.class);
		JDBC_TEMPLATE.execute("SET REFERENTIAL_INTEGRITY FALSE;");
		for (String table : tables) {
			JDBC_TEMPLATE.execute("TRUNCATE TABLE "+table+ " RESTART IDENTITY;");
		}
		JDBC_TEMPLATE.execute("SET REFERENTIAL_INTEGRITY TRUE;");
	}
}
