/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: MissingLoggingFinderTest.java
 *             Auteur: duisr01
 *    Creatietijdstip: 24-10-2022 16:44
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.logging.utils;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;

import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.service.FeedbackService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.UnlinkEntiteitMiddelRisicoService;

@SpringBootKbsTest
class MissingLoggingFinderTest {

	private static final List<String> METHODS_TO_SEARCH = List.of("save", "saveAll", "saveAndFlush", "delete", "deleteById", "deleteAll", "deleteInBatch", "deleteAllInBatch");
	private static final List<Object> EXCLUDE_CLASSES = List.of(
			Logging2Service.class,
			FeedbackService.class,
			UnlinkEntiteitMiddelRisicoService.class
	);

	@Autowired
	private WebApplicationContext appContext;

	@Test
	void findMissingLogging() throws IOException {
		Map<String, Object> services = appContext.getBeansWithAnnotation(Service.class);
		Map<String, Object> repositories = appContext.getBeansWithAnnotation(Repository.class);

		var servicesToExclude = services.entrySet()
														  .stream()
														  .filter(stringObjectEntry -> EXCLUDE_CLASSES.contains(
																  stringObjectEntry.getValue()
																				   .getClass()))
														  .collect(Collectors.toList());

		servicesToExclude.forEach(stex -> services.remove(stex.getKey()));

		var repositoryList = repositories.keySet().stream().map(StringUtils::capitalize).collect(Collectors.toList());
		var serviceListWithFieldNames = retrieveRepositoryNameAndLoggingServiceName(services,
				repositoryList);

		var serviceMapPaths = findServiceMapPaths(serviceListWithFieldNames);

		List<PathDto> pathDtos = searchAndCountMethods(serviceMapPaths);

		var missingLogging = pathDtos.stream()
									   .filter(pathDto -> pathDto.getCountRepoMethods() > pathDto.getCountLogMethods())
									   .map(p -> p.getFileName()
											   + " - count repo methods: " + p.getCountRepoMethods() + " - count logging save: "
											   + p.getCountLogMethods())
									   .collect(Collectors.toList());

		Assertions.assertTrue(missingLogging.isEmpty(), "\nThe following services might be missing some logging: \n"+String.join("\n", missingLogging));

	}

	private List<PathDto> searchAndCountMethods(List<PathDto> serviceMapPaths) throws IOException {

		for (PathDto serviceMapPath : serviceMapPaths) {
			var path = serviceMapPath.getPath();

			Path path1 = path.toAbsolutePath();
			try(var lines = Files.lines(path1)){

				lines.forEach(line -> {
							   var repoList = serviceMapPath.getRepoNameList();
							   var countRepoMethods = 0;
							   for (String repo : repoList) {
								   for (String method : METHODS_TO_SEARCH) {
									   int i = StringUtils.countOccurrencesOf(line, repo + "."+method+"(");
									   countRepoMethods = countRepoMethods + i;
								   }
							   }
							   serviceMapPath.setCountRepoMethods(serviceMapPath.getCountRepoMethods()+countRepoMethods);

							   if(serviceMapPath.getLoggingFieldName() == null){
								   return;
							   }

								serviceMapPath.setCountLogMethods(
										serviceMapPath.getCountLogMethods()
												+
												StringUtils.countOccurrencesOf(line, serviceMapPath.getLoggingFieldName() + ".save("));
									   });

			}
			
		}
		return serviceMapPaths;
	}

	private List<PathDto> findServiceMapPaths(List<PathDto> pathDtoList) throws IOException {

		try (var findFile = Files.find(Paths.get("src/main/java/"),
				20,
				(p, a) ->
						a.isRegularFile() && p.toString().endsWith(".java"))
		){
			var javaPathList = findFile.collect(Collectors.toList());
			for (Path path : javaPathList) {
				var pathFileName = path.getFileName().toString();
				var serviceFileFoundOpt = pathDtoList
										.stream()
									  .filter(dto -> dto.getFileName().equals(pathFileName)).findFirst();
				serviceFileFoundOpt.ifPresent(pathDto -> pathDto.setPath(path));
			}

			return pathDtoList;
		}
	}

	private static List<PathDto> retrieveRepositoryNameAndLoggingServiceName(Map<String, Object> services, List<String> repositoryList) {
		var serviceRepoList = new ArrayList<PathDto>();

		for (String serviceName : services.keySet()) {
			Object serviceObject = services.get(serviceName);

			String loggingServiceName = null;
			var repoList = new ArrayList<String>();

			for (Field declaredField : serviceObject.getClass()
													.getDeclaredFields()) {
				if(repositoryList.contains(declaredField.getType().getSimpleName())){
					repoList.add(declaredField.getName());
				}

				if(declaredField.getType().equals(Logging2Service.class)){
					loggingServiceName = declaredField.getName();
				}
			}

			if(repoList.isEmpty()){
				continue;
			}
			PathDto pathDto = new PathDto();
			pathDto.setFileName(serviceObject.getClass().getSimpleName()+".java");
			pathDto.setRepoNameList(repoList);
			pathDto.setLoggingFieldName(loggingServiceName);

			serviceRepoList.add(
				pathDto
			);

		}
		return serviceRepoList;
	}
}
