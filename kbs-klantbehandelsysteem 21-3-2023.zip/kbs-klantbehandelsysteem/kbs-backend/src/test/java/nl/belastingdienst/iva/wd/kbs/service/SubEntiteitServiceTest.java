package nl.belastingdienst.iva.wd.kbs.service;

import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.SubEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.domain.SubEntiteit;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class SubEntiteitServiceTest {

	public static final String TEST_LOGGING_ID_1 = "testLoggingId_1";
	@Autowired
	SubEntiteitService sut;

	@MockBean
	Logging2Service logging2ServiceMock;

	@Autowired
	SubEntiteitRepository subEntiteitRepository;

	@BeforeEach
	void setUp() {
		this.subEntiteitRepository.saveAll(
			List.of(
				new SubEntiteit(111L, 1000L),
				new SubEntiteit(111L, 1001L),
				new SubEntiteit(111L, 1002L),
				new SubEntiteit(111L, 1003L),
				new SubEntiteit(111L, 1004L),
				new SubEntiteit(222L, 1000L),
				new SubEntiteit(222L, 1001L),
				new SubEntiteit(222L, 1002L),
				new SubEntiteit(222L, 1003L),
				new SubEntiteit(222L, 1004L)
			)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void saveSubEntiteiten(String testCaseName, Long entiteitNummer, SortedSet<Long> subentiteitNummerSet, List<SubEntiteit> expectedRepoList) {
		this.sut.saveSubEntiteiten(entiteitNummer, subentiteitNummerSet, TEST_LOGGING_ID_1);
		List<SubEntiteit> actualSavedInRepo = this.subEntiteitRepository.findAll();
		Assertions.assertEquals(actualSavedInRepo, expectedRepoList);
		LoggingArgumentAssertion.check(this.logging2ServiceMock, TEST_LOGGING_ID_1, entiteitNummer, Logging2.Bewerking.UPDATE);
	}

	private static Stream<Arguments> provideInput() {
		return Stream.of(
				Arguments.of(
					"givenEntiteitWithSubentiteitenSaved_WhenNewList_ThenExpectList",
						111L,
						new TreeSet<>(Set.of(1000L, 1001L, 1002L, 1004L)),
						List.of(
								new SubEntiteit(111L, 1000L),
								new SubEntiteit(111L, 1001L),
								new SubEntiteit(111L, 1002L),
								new SubEntiteit(111L, 1004L),
								new SubEntiteit(222L, 1000L),
								new SubEntiteit(222L, 1001L),
								new SubEntiteit(222L, 1002L),
								new SubEntiteit(222L, 1003L),
								new SubEntiteit(222L, 1004L)
						)
				),
				Arguments.of(
						"givenEntiteitWithSubentiteitenSaved_WhenNewList_ThenExpectEmptyList",
						222L,
						new TreeSet<>(Set.of()),
						List.of(
								new SubEntiteit(111L, 1000L),
								new SubEntiteit(111L, 1001L),
								new SubEntiteit(111L, 1002L),
								new SubEntiteit(111L, 1003L),
								new SubEntiteit(111L, 1004L)
						)
				),
				Arguments.of(
						"givenEntiteitWithoutSubentiteitenSaved_WhenNewList_ThenExpectList",
						333L,
						new TreeSet<>(Set.of(1001L, 1004L, 1002L)),
						List.of(
								new SubEntiteit(111L, 1000L),
								new SubEntiteit(111L, 1001L),
								new SubEntiteit(111L, 1002L),
								new SubEntiteit(111L, 1003L),
								new SubEntiteit(111L, 1004L),
								new SubEntiteit(222L, 1000L),
								new SubEntiteit(222L, 1001L),
								new SubEntiteit(222L, 1002L),
								new SubEntiteit(222L, 1003L),
								new SubEntiteit(222L, 1004L),
								new SubEntiteit(333L, 1001L),
								new SubEntiteit(333L, 1002L),
								new SubEntiteit(333L, 1004L)
						)
				)
		);
	}
}