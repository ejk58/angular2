/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: H2TestProfileJPAConfig.java
 *             Auteur: duisr01
 *    Creatietijdstip: 9-1-2023 13:01
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.tablefiltering;

import nl.belastingdienst.iva.wd.kbs.tablefiltering.dao.FilterRepository;
import nl.belastingdienst.iva.wd.kbs.tablefiltering.domain.FilterTestClass;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@Configuration
@EnableJpaRepositories(basePackageClasses = { FilterRepository.class}, entityManagerFactoryRef = "testEntityManagerFactory", transactionManagerRef = "testTransactionManager")
@EnableTransactionManagement
public class H2TestProfileJPAConfig {

	@Bean("testDataSourceProperties")
	@ConfigurationProperties("spring.datasource")
	public DataSourceProperties testDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean("testDataSource")
	public DataSource testDataSource(@Qualifier("testDataSourceProperties") DataSourceProperties testDataSourceProperties) {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(testDataSourceProperties.getDriverClassName());
		dataSource.setUrl(testDataSourceProperties.getUrl());
		dataSource.setUsername(testDataSourceProperties.getUsername());
		dataSource.setPassword(testDataSourceProperties.getPassword());

		return dataSource;
	}

	@Bean("testEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("testDataSource") DataSource testDataSource) {
		return builder.dataSource(testDataSource).packages(FilterTestClass.class).persistenceUnit("test").build();
	}


	@Bean("testTransactionManager")
	public PlatformTransactionManager testTransactionManager(
			@Qualifier("testEntityManagerFactory") EntityManagerFactory testEntityManagerFactory) {
		return new JpaTransactionManager(testEntityManagerFactory);
	}

}