package nl.belastingdienst.iva.wd.kbs.zof.service;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppelingCompositeId;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class GetRisicoListByMiddelkenmerkIdServiceTest {

	public static final MiddelKenmerk MIDDEL_KENMERK_1 = new MiddelKenmerk(1L, 12, "Hoofdkenmerk 1", null);
	public static final MiddelKenmerk MIDDEL_KENMERK_2 = new MiddelKenmerk(2L, 12, "Subkenmerk 1a", 1L);
	public static final MiddelKenmerk MIDDEL_KENMERK_3 = new MiddelKenmerk(3L, 12, "Hoofdkenmerk 2", null);
	public static final MiddelKenmerk MIDDEL_KENMERK_4 = new MiddelKenmerk(4L, 12, "Hoofdkenmerk 3", null);
	public static final MiddelRisico MIDDEL_RISICO_10 = new MiddelRisico(10L, 12, "Hoofdrisico 1", null, null);
	public static final MiddelRisico MIDDEL_RISICO_11 = new MiddelRisico(11L, 12, "Subrisico 1a", 1L, null);
	public static final MiddelRisico MIDDEL_RISICO_12 = new MiddelRisico(12L, 12, "Hoofdrisico 2", null, null);
	public static final MiddelRisico MIDDEL_RISICO_13 = new MiddelRisico(13L, 13, "Hoofdrisico 2", MIDDEL_RISICO_12.getId(), null);

	@Autowired
	private GetRisicoListByMiddelkenmerkIdService sut;

	@Autowired
	private MiddelKenmerkRepository middelKenmerkRepository;

	@Autowired
	private MiddelRisicoRepository middelRisicoRepository;

	@Autowired
	private KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;

	@BeforeEach
	void setUp() {
		setupMiddelkenmerken();
		setupMiddelRisicos();
		setupKoppeling();
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void getByMiddelkenmerkId(String testCaseName, Long middelKenmerkId, List<MiddelRisico> expectedReturn) {
		Assertions.assertEquals(expectedReturn, this.sut.getByMiddelkenmerkId(middelKenmerkId));
	}

	public static Stream<Arguments> provideInput() {
		return Stream.of(
				Arguments.of(
						"whenMiddelkenmerk1_ThenReturnCorrect2Risicos",
						1L,
						List.of(
								MIDDEL_RISICO_10,
								MIDDEL_RISICO_12
						)
				),
				Arguments.of(
						"whenMiddelkenmerk3_ThenReturnCorrect1Risicos",
						3L,
						List.of(
								MIDDEL_RISICO_12
						)
				),
				Arguments.of(
						"whenMiddelkenmerk2_ThenReturnEmptyList",
						2L,
						List.of()
				),
				Arguments.of(
						"whenMiddelkenmerk4WithExtraParentToBeAdded_ThenReturnCorrect1Risicos",
						4L,
						List.of(
								MIDDEL_RISICO_12,
								MIDDEL_RISICO_13
						)
				)
		);
	}

	private void setupKoppeling() {
		this.kenmerkRisicoKoppelingRepository.saveAll(
				List.of(
						new KenmerkRisicosKoppeling(
								new KenmerkRisicosKoppelingCompositeId(1L, 10L),
								MIDDEL_KENMERK_1,
								MIDDEL_RISICO_10
						),
						new KenmerkRisicosKoppeling(
								new KenmerkRisicosKoppelingCompositeId(1L, 12L),
								MIDDEL_KENMERK_1,
								MIDDEL_RISICO_12
						),
						new KenmerkRisicosKoppeling(
								new KenmerkRisicosKoppelingCompositeId(3L, 12L),
								MIDDEL_KENMERK_2,
								MIDDEL_RISICO_12
						),
						new KenmerkRisicosKoppeling(
								new KenmerkRisicosKoppelingCompositeId(4L, 13L),
								MIDDEL_KENMERK_4,
								MIDDEL_RISICO_13
						)
				)
		);
	}

	private void setupMiddelRisicos() {
		this.middelRisicoRepository.saveAll(
				List.of(MIDDEL_RISICO_10, MIDDEL_RISICO_11, MIDDEL_RISICO_12, MIDDEL_RISICO_13
				)
		);
	}

	private void setupMiddelkenmerken() {
		this.middelKenmerkRepository.saveAll(
				List.of(MIDDEL_KENMERK_1, MIDDEL_KENMERK_2, MIDDEL_KENMERK_3, MIDDEL_KENMERK_4)
		);
	}


}