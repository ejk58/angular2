package nl.belastingdienst.iva.wd.kbs.tablefiltering.utils;

import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.shared.util.CreateTestTablesUtil;
import nl.belastingdienst.iva.wd.kbs.tablefiltering.dao.FilterRepository;
import nl.belastingdienst.iva.wd.kbs.tablefiltering.domain.FilterTestClass;
import nl.belastingdienst.iva.wd.kbs.tablefiltering.domain.LazyLoadEvent;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

@SpringBootKbsTest
class FilterSpecificationCreatorTest {

    public static final FilterTestClass FILTER_TEST_CLASS_1 = new FilterTestClass(1L, 111L, "testNaam 1a", "pass", LocalDate.of(2023, 1, 11),
            "NNP");
    public static final FilterTestClass FILTER_TEST_CLASS_2 = new FilterTestClass(2L, 111L, "testNaam 1b", "pass2", LocalDate.of(2023, 2, 11),
            "NP");
    public static final FilterTestClass FILTER_TEST_CLASS_3 = new FilterTestClass(3L, 333L, "testNaam 3", "pass2",
            LocalDate.of(2023, 1, 10), "NP");
    public static final FilterTestClass FILTER_TEST_CLASS_4 = new FilterTestClass(4L, 444L, "testNaam 4", "pass2",
            LocalDate.of(2023, 1, 1), "NP");
    @Autowired
    FilterRepository filterRepository;

    @BeforeEach
    void setUp() {
        CreateTestTablesUtil.createTableForEntity(FilterTestClass.class);
        filterRepository.saveAll(List.of(FILTER_TEST_CLASS_1, FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_3, FILTER_TEST_CLASS_4
        ));
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideInput")
    <T> void createSpecification(String testCaseName,
                                 Map<String, List<LazyLoadEvent.Filter>> lazyLoadEventFilters,
                                 List<FilterTestClass> expected) {

        var fullspec = FilterSpecificationCreator.createSpecification(null, lazyLoadEventFilters, FilterTestClass.class);

        List<FilterTestClass> actual = this.filterRepository.findAll(fullspec);

        Assertions.assertEquals(expected, actual);
    }

    public static Stream<Arguments> provideInput() {
        return Stream.of(
                Arguments.of(
                        "whenStartsWithOnLong",
                        Map.of(
                                "entiteitnummer",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "1", "startsWith", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_1, FILTER_TEST_CLASS_2)
                ),
                Arguments.of(
                        "whenStartsWithOnString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "testNaam 1", "startsWith", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_1, FILTER_TEST_CLASS_2)
                ),
                Arguments.of(
                        "whenStartsWithOnString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "unknown", "startsWith", "and")

                                )
                        ),
                        List.of()
                ),
                Arguments.of(
                        "whenContainsOnString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "b", "contains", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2)
                ),
                Arguments.of(
                        "whenInArrayOfStrings",
                        Map.of(
                                "soort",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                List.of("NP"), "in", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_3, FILTER_TEST_CLASS_4)
                ),
                Arguments.of(
                        "whenInArrayOfStrings",
                        Map.of(
                                "soort",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                List.of("NP", "FBOE"), "in", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_3, FILTER_TEST_CLASS_4)
                ),
                Arguments.of(
                        "whenNotContainsString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "testNaam 3", "notContains", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_1, FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_4)
                ),
                Arguments.of(
                        "whenEndsWithString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "1a", "endsWith", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_1)
                ),
                Arguments.of(
                        "whenNotEqualsString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "testNaam 1b", "notEquals", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_1, FILTER_TEST_CLASS_3, FILTER_TEST_CLASS_4)
                ),
                Arguments.of(
                        "whenEqualsString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "testNaam 1b", "equals", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2)
                ),
                Arguments.of(
                        "whenDateIs",
                        Map.of(
                                "beginDatum",
                                List.of(
                                        new LazyLoadEvent.Filter("2023-01-10T23:00:00.000Z", "dateIs", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_1)
                ),
                Arguments.of(
                        "whenDateBefore",
                        Map.of(
                                "beginDatum",
                                List.of(
                                        new LazyLoadEvent.Filter("2023-01-10T23:00:00.000Z", "dateBefore", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_3, FILTER_TEST_CLASS_4)
                ),
                Arguments.of(
                        "whenDateAfter",
                        Map.of(
                                "beginDatum",
                                List.of(
                                        new LazyLoadEvent.Filter("2023-01-10T23:00:00.000Z", "dateAfter", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2)
                ),
                Arguments.of(
                        "whenDateIsNot",
                        Map.of(
                                "beginDatum",
                                List.of(
                                        new LazyLoadEvent.Filter("2023-01-10T23:00:00.000Z", "dateIsNot", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_3, FILTER_TEST_CLASS_4)
                ),
                Arguments.of(
                        "whenStartsWithAndContainsString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "testNaam 1", "startsWith", "and"),
                                        new LazyLoadEvent.Filter(
                                                "b", "contains", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2)
                ),
                Arguments.of(
                        "whenStartsWithOrContainsString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "testNaam 3", "startsWith", "or"),
                                        new LazyLoadEvent.Filter(
                                                "b", "contains", "or")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_3)
                ),
                Arguments.of(
                        "whenStartsWithOrEndsWithString",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "testNaam 3", "startsWith", "or"),
                                        new LazyLoadEvent.Filter(
                                                "b", "endsWith", "or")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_3)
                ),
                Arguments.of(
                        "whenCombinationOfFilters",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "testNaam 3", "startsWith", "or"),
                                        new LazyLoadEvent.Filter(
                                                "1", "contains", "or"),
                                        new LazyLoadEvent.Filter(
                                                "4", "contains", "or")

                                ),
                                "soort",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                List.of("NP"), "in", "and")

                                ),
                                "beginDatum",
                                List.of(
                                        new LazyLoadEvent.Filter("2023-01-05T23:00:00.000Z", "dateBefore", "and")
                                )
                        ),
                        List.of(FILTER_TEST_CLASS_4)
                ),
                Arguments.of(
                        "whenNonFilterableString",
                        Map.of(
                                "password",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                "pass2", "equals", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_1, FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_3, FILTER_TEST_CLASS_4)
                ),
                Arguments.of(
                        "whenNullValue",
                        Map.of(
                                "entiteitnaam",
                                List.of(
                                        new LazyLoadEvent.Filter(
                                                null, "equals", "and")

                                )
                        ),
                        List.of(FILTER_TEST_CLASS_1, FILTER_TEST_CLASS_2, FILTER_TEST_CLASS_3, FILTER_TEST_CLASS_4)
                )
        );
    }
}