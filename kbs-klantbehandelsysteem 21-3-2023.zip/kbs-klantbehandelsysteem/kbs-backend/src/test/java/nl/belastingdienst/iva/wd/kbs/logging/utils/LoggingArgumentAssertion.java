/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: LoggingArgumentCaptorChecker.java
 *             Auteur: duisr01
 *    Creatietijdstip: 28-9-2022 14:14
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.logging.utils;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Assertions;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;

public class LoggingArgumentAssertion {
	public static void check(Logging2Service logging2ServiceMock, String loggingId, Long entiteitnummer, Logging2.Bewerking bewerking){
		LoggingArgumentAssertion.assertArguments(logging2ServiceMock, loggingId, entiteitnummer, bewerking, 1);
	}

	public static void check(Logging2Service logging2ServiceMock, String loggingId, Long entiteitnummer, Logging2.Bewerking bewerking, int times){
		LoggingArgumentAssertion.assertArguments(logging2ServiceMock, loggingId, entiteitnummer, bewerking, times);
	}

	private static void assertArguments(Logging2Service logging2ServiceMock, String loggingId, Long entiteitnummer, Logging2.Bewerking bewerking, int times){
		ArgumentCaptor<String> argumentLoggingId = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<Long> argumentEntiteitnummer = ArgumentCaptor.forClass(Long.class);
		ArgumentCaptor<Logging2.Bewerking> argumentBewerking = ArgumentCaptor.forClass(Logging2.Bewerking.class);
		verify(logging2ServiceMock, Mockito.times(times)).save(argumentLoggingId.capture(), argumentEntiteitnummer.capture(), argumentBewerking.capture());
		Assertions.assertEquals(loggingId, argumentLoggingId.getValue());
		Assertions.assertEquals(entiteitnummer, argumentEntiteitnummer.getValue());
		Assertions.assertEquals(bewerking, argumentBewerking.getValue());
	}
}
