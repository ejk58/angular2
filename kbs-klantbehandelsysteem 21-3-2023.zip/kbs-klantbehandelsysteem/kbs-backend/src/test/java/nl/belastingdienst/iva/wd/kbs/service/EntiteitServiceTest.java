package nl.belastingdienst.iva.wd.kbs.service;

import nl.belastingdienst.iva.wd.kbs.dao.ZooOmvangRepository;
import nl.belastingdienst.iva.wd.kbs.domain.ZooOmvang;
import nl.belastingdienst.iva.wd.kbs.krb.dao.KrbEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.kta.dao.KtaEntiteitRepository;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.mappings.EntiteitMapper;
import nl.belastingdienst.iva.wd.kbs.mappings.KenmerkenMapper;
import nl.belastingdienst.iva.wd.kbs.mappings.ZooOmvangMapper;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

@SpringBootKbsTest
class EntiteitServiceTest {
    @MockBean
    KtaEntiteitRepository ktaRepoMock;
    @MockBean
    KrbEntiteitRepository krbRepoMock;
    @Autowired
    ZooOmvangRepository zooOmvangRepoMock;
    @MockBean
    EntiteitMapper mapperMock;
    @MockBean
    ZooOmvangMapper omvangMapperMock;
    @MockBean
    KenmerkenMapper kenmerkenMapperMock;
    @MockBean
    Logging2Service logging2ServiceMock;
    @Autowired
    EntiteitService cut;

    private static final String TEST_LOGGING_ID = "Test-LoggingId";
    private static final ZooOmvang EXISTING_ZOOOMVANG = new ZooOmvang(112L);

    @BeforeEach
    void setUp() {
        EXISTING_ZOOOMVANG.setLastUpdated(LocalDateTime.now());
        EXISTING_ZOOOMVANG.setLastUpdatedByUserId("User2");
        zooOmvangRepoMock.saveAll(List.of(EXISTING_ZOOOMVANG));
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideSaveZooOmvangInput")
    @WithMockUser("User1")
    void saveZooOmvang(String testName, Long entiteitNummer, ZooOmvang zooOmvang, Logging2.Bewerking bewerking) {
        ZooOmvang actual = cut.saveZooOmvang(entiteitNummer, zooOmvang, TEST_LOGGING_ID);

        Assertions.assertEquals(zooOmvang.getAantalBuitenlandseDeelnemingen(), actual.getAantalBuitenlandseDeelnemingen());
        Assertions.assertEquals(zooOmvang.getAantalVasteInrichtingen(), actual.getAantalVasteInrichtingen());
        Assertions.assertEquals(zooOmvang.getTotaleVrijgesteldeOmzet(), actual.getTotaleVrijgesteldeOmzet());
        LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID, entiteitNummer, bewerking);
    }

    private static Stream<Arguments> provideSaveZooOmvangInput() {
        EXISTING_ZOOOMVANG.setAantalBuitenlandseDeelnemingen(300);
        return Stream.of(
                Arguments.of(
                        "givenNonExistingZooOmvang_ThenCreateZooOmvangNewWithValues",
                        111L,
                        new ZooOmvang(111L, 3, 4, 100, null, BigInteger.valueOf(5), BigInteger.valueOf(6), null, BigInteger.valueOf(7), BigInteger.valueOf(8), BigInteger.valueOf(9), BigInteger.valueOf(10), BigInteger.valueOf(11), (BigInteger.valueOf(2_430_000_000_000L)), null, null, null),
                        Logging2.Bewerking.INSERT
                ),
                Arguments.of(
                        "givenExistingZooOmvang_ThenUpdateZooOmvangValues",
                        EXISTING_ZOOOMVANG.getEntiteitNummer(),
                        EXISTING_ZOOOMVANG,
                        Logging2.Bewerking.UPDATE)
        );
    }

}