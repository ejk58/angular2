package nl.belastingdienst.iva.wd.kbs.logging.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.logging.dao.Logging2Repository;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class RemoveOldLoggingInfoServiceTest {

	@Autowired
	RemoveOldLoggingInfoService sut;

	@Autowired
	Logging2Repository logging2Repository;

	@BeforeEach
	void setUp() {
		this.logging2Repository.saveAll(List.of(
						/* No deletion */
						new Logging2(1L, "ivatest1", LocalDateTime.now().minusYears(1), 111L, "loggingId1", "UPDATE", null),
						new Logging2(2L, "ivatest2", LocalDateTime.now().minusYears(1), 111L, "loggingId1", "UPDATE", null),
						new Logging2(3L, "ivatest1", LocalDateTime.now().minusYears(2), 111L, "loggingId1", "INSERT", null),
						/* Delete the oldest one */
						new Logging2(4L, "ivatest1", LocalDateTime.now().minusYears(1), 111L, "loggingId2", "UPDATE", null),
						new Logging2(5L, "ivatest1", LocalDateTime.now().minusYears(2), 111L, "loggingId2", "UPDATE", null),
						new Logging2(6L, "ivatest1", LocalDateTime.now().minusYears(5), 111L, "loggingId2", "UPDATE", null),
						new Logging2(7L, "ivatest1", LocalDateTime.now().minusYears(6), 111L, "loggingId2", "UPDATE", null),
						/* same loggingId as above but only one for other entity */
						new Logging2(8L, "ivatest1", LocalDateTime.now().minusYears(7), 333L, "loggingId2", "UPDATE", null),
						/* most recent logging */
						new Logging2(9L, "ivatest1", LocalDateTime.now().minusYears(7), 111L, "loggingId3", "UPDATE", null)
				)
		);
	}

	@Test
	void removeOldLogs() {
		this.sut.removeOldLogs();
		var actualRemainingLogging = this.logging2Repository.findAll();
		Assertions.assertEquals(8, actualRemainingLogging.size());
		var expectedIds = List.of(1L, 2L, 3L, 4L, 5L, 6L, 8L, 9L);
		Assertions.assertEquals(expectedIds, actualRemainingLogging.stream()
																   .map(Logging2::getId)
																   .collect(Collectors.toList()));
	}
}