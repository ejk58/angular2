package nl.belastingdienst.iva.wd.kbs.klantsessie.service.status;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieStrategieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStrategie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class CheckStrategieServiceTest {

	@Autowired
	CheckStrategieService sut;

	@Autowired
	KlantSessieStrategieRepository klantSessieStrategieRepository;

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void check(String testCaseName, Long klantsessieId, Integer middelId, StepStatusEnum expectedStepStatusEnum) {
		StepStatusEnum actual = this.sut.check(klantsessieId, middelId);
		Assertions.assertEquals(expectedStepStatusEnum, actual);
	}

	@Test
	void getStepEnum() {
		Assertions.assertEquals(StepEnum.STRATEGIE, this.sut.getStepEnum());
	}

	public static Stream<Arguments> provideInput() {
		return Stream.of(
				Arguments.of(
						"givenNonNullStrategieRecord_WhenCheck_ThenReturnCompleted",
						999L,
						12,
						StepStatusEnum.COMPLETED
				),
				Arguments.of(
						"givenPartialNullStrategieRecord_WhenCheck_ThenReturnTouched",
						888L,
						12,
						StepStatusEnum.TOUCHED
				),
				Arguments.of(
						"givenNoStrategieRecord_WhenCheck_ThenReturnInitial",
						999L,
						13,
						StepStatusEnum.INITIAL
				)
		);
	}

	@BeforeEach
	void setUp() {
		this.klantSessieStrategieRepository.saveAll(
				List.of(
					new KlantsessieStrategie(
							999L, 12, "testing", "testing 2"
					),
					new KlantsessieStrategie(
							888L, 12, null, "testing 2"
					)
				)
		);
	}
}