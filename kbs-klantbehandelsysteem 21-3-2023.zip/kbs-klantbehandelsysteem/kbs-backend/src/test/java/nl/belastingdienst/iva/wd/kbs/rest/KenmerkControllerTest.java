package nl.belastingdienst.iva.wd.kbs.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MultiSelectKenmerk;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.service.EntiteitKenmerkService;
import nl.belastingdienst.iva.wd.kbs.service.KenmerkService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = KenmerkController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class KenmerkControllerTest {

	@MockBean
	private EntiteitKenmerkService serviceMock;

	@MockBean private KenmerkService kenmerkService;


	private static final String JSON = MediaType.APPLICATION_JSON.toString();

	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";

	private final ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private MockMvc mockMvc;

	@Test
	void removeSelectedKenmerken() throws Exception {
		var ids = Arrays.asList(1,2,3,4,5);
		var loggingWrapper = new LoggingWrapper<>(TEST_LOGGING_ID_1, ids);

		mockMvc.perform(MockMvcRequestBuilders.post("/api/kenmerken/{entiteit_nummer}/{kenmerkType}/selections/remove", 123, "CBIBV")
						.contentType(JSON)
						.content(objectMapper.writeValueAsString(loggingWrapper)))
				.andExpect(status().isOk());
		for(Integer i: ids) {
			verify(serviceMock, times(1)).deleteEntiteitKenmerk(
					123L,
					"CBIBV",
					i,
					TEST_LOGGING_ID_1);
		}
	}


	@Test
	void getZooAttentiepuntenInkomstenBelasting() throws Exception {
		List<Kenmerk>  kenmerken = List.of(
				new Kenmerk(1, "CBIBV_TEST", "Box 1", null),
				new Kenmerk(2, "CBIBV_TEST", "Box 2", null),
				new Kenmerk(3, "CBIBV_TEST", "Box 3", null),
				new Kenmerk(4, "CBIBV_TEST", "child1_for_Box1", 1),
				new Kenmerk(5, "CBIBV_TEST", "child1_for_Box2", 2),
				new Kenmerk(6, "CBIBV_TEST", "child2_for_Box2", 2),
				new Kenmerk(7, "CBIBV_TEST", "child1_for_Box3", 3),
				new Kenmerk(8, "CBIBV_TEST", "child2_for_Box3", 3)
		);

		when(kenmerkService.findZooEntiteitAttentiepuntenInkomstenBelasting()).thenReturn(kenmerken);

		List<MultiSelectKenmerk> expected = List.of(
				new MultiSelectKenmerk(1, "Box 1", List.of(new Kenmerk(4, "CBIBV_TEST", "child1_for_Box1", 1))),
				new MultiSelectKenmerk(2, "Box 2", List.of(
								new Kenmerk(5, "CBIBV_TEST", "child1_for_Box2", 2),
								new Kenmerk(6, "CBIBV_TEST", "child2_for_Box2", 2))),
				new MultiSelectKenmerk(3, "Box 3", List.of(
						new Kenmerk(7, "CBIBV_TEST", "child1_for_Box3", 3),
						new Kenmerk(8, "CBIBV_TEST", "child2_for_Box3", 3)))
				);

		mockMvc.perform(get("/api/kenmerken/attentiepunten-inkomstenbelasting")
						.contentType(JSON))
				.andExpect(status().isOk())
				.andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(expected, MultiSelectKenmerk.class));
	}
}
