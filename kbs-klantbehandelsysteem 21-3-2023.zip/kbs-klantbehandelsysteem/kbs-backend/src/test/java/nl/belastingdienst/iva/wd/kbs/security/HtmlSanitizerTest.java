package nl.belastingdienst.iva.wd.kbs.security;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class HtmlSanitizerTest {

    @Test
    public void testHtmlSanitizerWithInzichtUrlKeepsOriginalUrl() {
        String input = "<p><a href=\"-url-goes-here-\" target=\"_blank\">"
                + "https://inzicht.str11.ont.belastingdienst.nl/inzicht/#/main/(right:reflection/reflection-global//left:di/di-klantprofiel;subjectNr=7777777;entityNr=7)"
                + "</a></p>";
        String result = HtmlSanitizer.sanitizeHtml(input);

        Assertions.assertTrue(result.contains("href=\"https://inzicht.str11.ont.belastingdienst.nl/inzicht/#/main/(right:reflection/reflection-global//left:di/di-klantprofiel;subjectNr=7777777;entityNr=7)\""));
        Assertions.assertTrue(result.contains("rel=\"noopener noreferrer nofollow\""));
        Assertions.assertTrue(result.contains(">https://inzicht.str11.ont.belastingdienst.nl/inzicht/#/main/(right:reflection/reflection-global//left:di/di-klantprofiel;subjectNr&#61;7777777;entityNr&#61;7)<"));
    }

    @Test
    public void testHtmlSanitizerWithNoInzichtUrlSanitizesOutput() {
        String input = "<p><a href=\"-url-goes-here-\" target=\"_blank\">"
                + "https://uitzicht.str11.ont.belastingdienst.nl/uitzicht/#/main/(left:di/di-klantprofiel;subjectNr=7777777;entityNr=7)"
                + "</a></p>";
        String result = HtmlSanitizer.sanitizeHtml(input);

        Assertions.assertTrue(result.contains("href=\"https://uitzicht.str11.ont.belastingdienst.nl/uitzicht/#/main/%28left:di/di-klantprofiel;subjectNr&#61;7777777;entityNr&#61;7%29\""));
    }

    @Test
    public void testHtmlSanitizerWithJavascriptSanitizesOutput() {
        String input = "<p><a href=\"-url-goes-here-\" target=\"_blank\">"
                + "alert('https://inzicht.str11.ont.belastingdienst.nl/uitzicht/#/main/(left:di/di-klantprofiel;subjectNr=7777777;entityNr=7)');"
                + "</a></p>";
        String result = HtmlSanitizer.sanitizeHtml(input);

        Assertions.assertTrue(result.contains("alert%28&#39;https"));
        Assertions.assertTrue(result.contains("%28left:di/di-klantprofiel;subjectNr&#61;7777777;entityNr&#61;7%29"));
    }

    @Test
    public void testHtmlSanitizerWithDifferentUrlSanitizesOutput() {
        String input = "<p><a href=\"-url-goes-here-\" target=\"_blank\">"
                + "https://nu.nl/inzicht.str11.ont.belastingdienst.nl/uitzicht/#/main/(left:di/di-klantprofiel;subjectNr=7777777;entityNr=7)"
                + "</a></p>";
        String result = HtmlSanitizer.sanitizeHtml(input);

        Assertions.assertTrue(result.contains("https://nu.nl/"));
        Assertions.assertTrue(result.contains("%28left:di/di-klantprofiel;subjectNr&#61;7777777;entityNr&#61;7%29"));
    }
    @Test

    public void testHtmlSanitizerWithUnmatchedParenthesesSanitizesOutput() {
        String input = "<p><a href=\"-url-goes-here-\" target=\"_blank\">"
                + "https://inzicht.str11.ont.belastingdienst.nl/inzicht/#/main/((left:di/di-klantprofiel;subjectNr=7777777;entityNr=7)"
                + "</a></p>";
        String result = HtmlSanitizer.sanitizeHtml(input);

        Assertions.assertTrue(result.contains("%28%28left:di/di-klantprofiel;subjectNr&#61;7777777;entityNr&#61;7%29"));
    }

    @Test
    public void testHtmlSanitizerWithMultipleUrlsSanitizesOutputAndKeepsInzichtUrl() {
        String input = "<p><a href=\"-url-goes-here-\" target=\"_blank\">"
                + "http://localhost:4200/(param=value)"
                + "</a><br><a href=\"-url-goes-here-\" target=\"_blank\" onerror=alert(document.cookie);>"
                + "https://google.com"
                + "</a><a href=\"-url-goes-here-\" target=\"_blank\">"
                + "https://inzicht.str11.ont.belastingdienst.nl/inzicht/#/main/(left:niet_winst/nw-klantprofiel;subjectNr=7777777)"
                + "</a></p>";
        String result = HtmlSanitizer.sanitizeHtml(input);

        Assertions.assertTrue(result.contains("href=\"http://localhost:4200/%28param&#61;value%29\""));
        Assertions.assertTrue(result.contains("href=\"https://google.com\""));
        Assertions.assertTrue(result.contains("href=\"https://inzicht.str11.ont.belastingdienst.nl/inzicht/#/main/(left:niet_winst/nw-klantprofiel;subjectNr=7777777)\""));
    }

    @Test
    public void testHtmlSanitizerWithBoldOnMouseOverXssAttackSanitizesOutput() {
        String input = "<b onmouseover=alert('Wufff!')>click me!</b>";
        String result = HtmlSanitizer.sanitizeHtml(input);

        Assertions.assertFalse(result.contains("onmouseover=alert('Wufff!')"));
        Assertions.assertTrue(result.equals("<b>click me!</b>"));
    }

    @Test
    public void testHtmlSanitizerWithImageOnErrorXssAttackSanitizesOutput() {
        String input = "<img src=\"http://url.to.file.which/not.exist\" onerror=alert(document.cookie);>";
        String result = HtmlSanitizer.sanitizeHtml(input);

        Assertions.assertFalse(result.contains("onerror=alert(document.cookie);"));
        Assertions.assertTrue(result.equals(""));
    }
}
