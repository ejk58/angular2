package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import static nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers.responseBody;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkChild;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import nl.belastingdienst.iva.wd.kbs.klantsessie.mappings.KlantsessieComplianceMapper;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieComplianceService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieComplianceUpdateService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;

@WebMvcTest(controllers = KlantsessieComplianceRestController.class)
@ComponentScan(basePackageClasses = {KlantsessieComplianceMapper.class})
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@ExtendWith(MockitoExtension.class)
@RestControllerTestConfiguration
class KlantsessieComplianceRestControllerTest {

	private static final long ENTITEIT_NUMMER = 999L;
	private static final long MIDDEL_ID = 12;
	private static final String JSON = MediaType.APPLICATION_JSON.toString();
	private static final Kenmerk CHILD_KENMERK_1_A = new Kenmerk(10, "KS_CAT", "Child parent 1a", 1);
	public static final Kenmerk KENMERK_1 = new Kenmerk(1, "TEST", "kenmerk 1", null);
	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private KlantsessieComplianceMapper klantsessieComplianceMapper;

	private final ObjectMapper objectMapper = new ObjectMapper();

	@MockBean
	private KlantsessieComplianceService klantsessieComplianceService;

	@MockBean
	private KlantsessieComplianceUpdateService klantsessieComplianceUpdateServiceMock;


	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideScoreInput")
	void updateKlantsessieComplianceScore(String testCaseName, KenmerkChild kenmerkChildRequest, KlantsessieCompliance klantsessieCompliance, ResultMatcher expectedStatus, ResultMatcher expectedBody) throws Exception {
		when(klantsessieComplianceUpdateServiceMock.updateScore(anyLong(), anyInt(), any(), any())).thenReturn(klantsessieCompliance);
		var loggingWrapper = new LoggingWrapper<>(TEST_LOGGING_ID_1, kenmerkChildRequest);
		ResultActions apiResult = mockMvc.perform(
						post("/api/klantsessie/compliance/score/{entiteitNummer}/{middelId}", ENTITEIT_NUMMER, MIDDEL_ID)
								.contentType(JSON)
								.content(objectMapper.writeValueAsString(loggingWrapper)
						)
								 ).andExpect(expectedStatus);

		if(expectedBody != null){
			apiResult.andExpect(expectedBody);
		}
	}

	private static Stream<Arguments> provideScoreInput() {
		return Stream.of(
				Arguments.of(
						"givenComplianceChild_WhenScore0_ThenReturnComplianceChild", new KenmerkChild(
								CHILD_KENMERK_1_A, 0, null
						),
						new KlantsessieCompliance(
								1L, 12, 1, 0, null, KENMERK_1
						),
						status().isOk(),
						responseBody().containsObjectAsJson(
								new KenmerkChild(
										KENMERK_1,
										0,
										null
								), KenmerkChild.class
						)
				),
				Arguments.of(
						"givenComplianceChild_WhenScore5_ThenReturnComplianceChild",
						new KenmerkChild(
								CHILD_KENMERK_1_A, 5, null
						),
						new KlantsessieCompliance(
								1L, 12, 1, 5, null, KENMERK_1
						),
						status().isOk(),
						responseBody().containsObjectAsJson(
								new KenmerkChild(
										KENMERK_1,
										5,
										null
								), KenmerkChild.class
						)
				),
				Arguments.of(
						"givenComplianceChild_WhenScoreMinus1_ThenReturnBadStatus",
						new KenmerkChild(
								CHILD_KENMERK_1_A, -1, null
						),
						null,
						status().isBadRequest(),
						null
				),
				Arguments.of(
						"givenComplianceChild_WhenScore6_ThenReturnBadStatus",
						new KenmerkChild(
								CHILD_KENMERK_1_A, 6, null
						),
						null,
						status().isBadRequest(),
						null
				)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideToelichtingInput")
	void updateKlantsessieComplianceToelichting(String testCaseName, KenmerkChild kenmerkChildRequest, KlantsessieCompliance klantsessieCompliance, ResultMatcher expectedStatus, ResultMatcher expectedBody)
			throws Exception {
		when(klantsessieComplianceUpdateServiceMock.updateToelichting(anyLong(), anyInt(), any(), any())).thenReturn(klantsessieCompliance);
		var loggingWrapper = new LoggingWrapper<>(TEST_LOGGING_ID_1, kenmerkChildRequest);
		ResultActions apiResult = mockMvc.perform(
				post("/api/klantsessie/compliance/toelichting/{entiteitNummer}/{middelId}", ENTITEIT_NUMMER, MIDDEL_ID)
						.contentType(JSON)
						.content(objectMapper.writeValueAsString(loggingWrapper)
						)
		).andExpect(expectedStatus);

		if(expectedBody != null){
			apiResult.andExpect(expectedBody);
		}
	}

	private static Stream<Arguments> provideToelichtingInput() {
		return Stream.of(
				Arguments.of(
						"givenComplianceChild_WhenToelichtingSent_ThenReturnComplianceChild",
						new KenmerkChild(
								CHILD_KENMERK_1_A, null, "test toelichting"
						),
						new KlantsessieCompliance(
								1L, 12, 1, null, "test toelichting", KENMERK_1
						),
						status().isOk(),
						responseBody().containsObjectAsJson(
								new KenmerkChild(
										KENMERK_1,
										null,
										"test toelichting"
								), KenmerkChild.class
						)
				),
				Arguments.of(
						"givenToBeSanitizedComplianceChild_WhenToelichtingSent_ThenReturnComplianceChild",
						new KenmerkChild(
								CHILD_KENMERK_1_A, null, "<script>alert();</script>test toelichting"
						),
						new KlantsessieCompliance(
								1L, 12, 1, null, "test toelichting", KENMERK_1
						),
						status().isOk(),
						responseBody().containsObjectAsJson(
								new KenmerkChild(
										KENMERK_1,
										null,
										"test toelichting"
								), KenmerkChild.class
						)
				),
				Arguments.of(
						"givenComplianceChild_WhenToelichtingSent_ThenReturnComplianceChild",
						new KenmerkChild(
								CHILD_KENMERK_1_A, null, null
						),
						new KlantsessieCompliance(
								1L, 12, 1, null, null, KENMERK_1
						),
						status().isOk(),
						responseBody().containsObjectAsJson(
								new KenmerkChild(
										KENMERK_1,
										null,
										null
								), KenmerkChild.class
						)
				)
		);
	}
}
