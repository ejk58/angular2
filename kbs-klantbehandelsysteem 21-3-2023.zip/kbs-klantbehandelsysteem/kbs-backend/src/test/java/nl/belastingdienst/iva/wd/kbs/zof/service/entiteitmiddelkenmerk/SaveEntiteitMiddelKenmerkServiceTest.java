package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.DuplicatePolicy;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.UnlinkEntiteitMiddelRisicoService;

@SpringBootKbsTest
class SaveEntiteitMiddelKenmerkServiceTest {
	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";

	@Autowired
	SaveEntiteitMiddelKenmerkService sut;
	@Autowired
	EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;

	@MockBean
	UnlinkEntiteitMiddelRisicoService unlinkEntiteitMiddelRisicoService;
	@MockBean
	Logging2Service logging2Service;
	@MockBean
	BusinessRulesMiddelSpecifiekeKenmerkenService businessRulesMiddelSpecifiekeKenmerkenService;

	EntiteitMiddelKenmerk ENTITEIT_MIDDEL_KENMERK_COMPLETE;
	EntiteitMiddelKenmerk ENTITEIT_MIDDEL_KENMERK_WITHOUT_ID;
	EntiteitMiddelKenmerk ENTITEIT_MIDDEL_KENMERK_WITHOUT_RANK;

	@BeforeEach
	public void	setup(){
		ENTITEIT_MIDDEL_KENMERK_COMPLETE = new EntiteitMiddelKenmerk(1L,2L,3L,4L,5L,1L,123L);
		ENTITEIT_MIDDEL_KENMERK_WITHOUT_ID = new EntiteitMiddelKenmerk(null,2L,3L,4L,5L,1L,1234L);
		ENTITEIT_MIDDEL_KENMERK_WITHOUT_RANK = new EntiteitMiddelKenmerk(2L,2L,3L,4L,5L,null,12345L);
	}

	@Test
	void givenEMKWithoutId_WhenOptionalBusinessRule_ThenExpectException() {
		when(businessRulesMiddelSpecifiekeKenmerkenService.validate(any(), any()))
				.thenReturn(
						Optional.of(new BusinessRuleError("test", DuplicatePolicy.class))
				);

		Assertions.assertThrows(BusinessRuleException.class, () -> sut.save(ENTITEIT_MIDDEL_KENMERK_WITHOUT_ID, TEST_LOGGING_ID_1));
		verify(businessRulesMiddelSpecifiekeKenmerkenService, times(1)).validate(any(), any());
	}

	@Test
	void givenEMK_WhenOptionalBusinessRule_ThenExpectException() {
		when(businessRulesMiddelSpecifiekeKenmerkenService.validateExcludingCurrentId(any(), any(), any()))
				.thenReturn(
						Optional.of(new BusinessRuleError("test", DuplicatePolicy.class))
				);

		Assertions.assertThrows(
				BusinessRuleException.class, () -> sut.save(ENTITEIT_MIDDEL_KENMERK_COMPLETE, TEST_LOGGING_ID_1)
		);
		verify(businessRulesMiddelSpecifiekeKenmerkenService, times(1)).validateExcludingCurrentId(any(), any(), any());
	}

	@Test
	void givenEMK_WhenOptionalEmpty_ThenSave() {
		when(businessRulesMiddelSpecifiekeKenmerkenService.validate(any(), any()))
				.thenReturn(
						Optional.empty()
				);

		sut.save(ENTITEIT_MIDDEL_KENMERK_COMPLETE, TEST_LOGGING_ID_1);
		verify(unlinkEntiteitMiddelRisicoService, times(1)).unlinkRisicosForEntiteitMiddelKenmerkId(ENTITEIT_MIDDEL_KENMERK_COMPLETE.getId());
		verify(logging2Service, times(1)).save(TEST_LOGGING_ID_1, ENTITEIT_MIDDEL_KENMERK_COMPLETE.getEntiteitNummer(), Logging2.Bewerking.UPDATE);

		sut.save(ENTITEIT_MIDDEL_KENMERK_WITHOUT_ID, TEST_LOGGING_ID_1);
		verify(unlinkEntiteitMiddelRisicoService, times(0)).unlinkRisicosForEntiteitMiddelKenmerkId(ENTITEIT_MIDDEL_KENMERK_WITHOUT_ID.getId());
		verify(logging2Service, times(1)).save(TEST_LOGGING_ID_1, ENTITEIT_MIDDEL_KENMERK_WITHOUT_ID.getEntiteitNummer(), Logging2.Bewerking.INSERT);

		sut.save(ENTITEIT_MIDDEL_KENMERK_WITHOUT_RANK, TEST_LOGGING_ID_1);
		verify(unlinkEntiteitMiddelRisicoService, times(1)).unlinkRisicosForEntiteitMiddelKenmerkId(ENTITEIT_MIDDEL_KENMERK_WITHOUT_RANK.getId());
		verify(logging2Service, times(1)).save(TEST_LOGGING_ID_1, ENTITEIT_MIDDEL_KENMERK_WITHOUT_RANK.getEntiteitNummer(), Logging2.Bewerking.UPDATE);
	}
}
