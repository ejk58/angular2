package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieComplianceRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkChild;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.status.CheckComplianceService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class KlantsessieComplianceUpdateServiceTest {

	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";
	@Autowired
	private KlantsessieComplianceUpdateService sut;

	@Autowired
	private KlantSessieComplianceRepository klantSessieComplianceRepository;

	@Autowired
	private KenmerkRepository kenmerkRepository;

	@MockBean
	private KlantsessieService klantsessieServiceMock;

	@MockBean
	private Logging2Service logging2Service;

	@MockBean
	private CheckComplianceService checkComplianceService;
	@MockBean
	private KlantsessieStatusService klantsessieStatusService;

	private static final Kenmerk CHILD_KENMERK_1_A = new Kenmerk(10, "KS_CAT", "Child parent 1a", 1);
	private static final Kenmerk CHILD_KENMERK_1_B = new Kenmerk(11, "KS_CAT", "Child parent 1b", 1);

	@BeforeEach
	void setUp() {
		this.kenmerkRepository.saveAll(
			List.of(
					CHILD_KENMERK_1_A,
					CHILD_KENMERK_1_B
			)
		);

		this.klantSessieComplianceRepository.saveAll(
				List.of(
					new KlantsessieCompliance(999L, 12, CHILD_KENMERK_1_A.getId(), 1, "test toelichting", CHILD_KENMERK_1_A),
					new KlantsessieCompliance(999L, 12, CHILD_KENMERK_1_B.getId(), 2, "test toelichting 2", CHILD_KENMERK_1_B)
				)
		);
		stubCurrentKlantSessies();
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideScoreInput")
	void updateScore(String testCaseName, Long entiteitNummer, KlantsessieCompliance expected) {
		var actual = this.sut.updateScore(entiteitNummer, expected.getMiddelId(), new KenmerkChild(expected.getKenmerk(), expected.getScore(), expected.getToelichting()),
				TEST_LOGGING_ID_1);
		Assertions.assertEquals(expected, actual);
		LoggingArgumentAssertion.check(logging2Service, TEST_LOGGING_ID_1, entiteitNummer, Logging2.Bewerking.UPDATE);
	}

	private static Stream<Arguments> provideScoreInput() {
		return Stream.of(
				Arguments.of(
						"givenRecordExists_WhenNewScore3_ThenReturnKlantsessieComplianceWithScore",
						999L,
						new KlantsessieCompliance(999L, 12, CHILD_KENMERK_1_A.getId(), 3, "test toelichting", CHILD_KENMERK_1_A)
				),
				Arguments.of(
						"givenRecordDoesNotExist_WhenNewScore5_ThenReturnKlantsessieComplianceWithScore",
						888L,
						new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_A.getId(), 5, null, CHILD_KENMERK_1_A)
				)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideToelichtingInput")
	void updateToelichting(String testCaseName, Long entiteitNummer, KlantsessieCompliance expected) {

		var actual = this.sut.updateToelichting(entiteitNummer, expected.getMiddelId(), new KenmerkChild(expected.getKenmerk(), expected.getScore(), expected.getToelichting()), TEST_LOGGING_ID_1);
		Assertions.assertEquals(expected, actual);
		LoggingArgumentAssertion.check(logging2Service, TEST_LOGGING_ID_1, entiteitNummer, Logging2.Bewerking.UPDATE);
	}

	private static Stream<Arguments> provideToelichtingInput() {
		return Stream.of(
				Arguments.of(
						"givenRecordExists_WhenNewToelichting_ThenReturnKlantsessieComplianceWithToelichting",
						999L,
						new KlantsessieCompliance(999L, 12, CHILD_KENMERK_1_A.getId(), 1, "test toelichting", CHILD_KENMERK_1_A)
				),
				Arguments.of(
						"givenRecordDoesNotExist_WhenNewToelichtingNull_ThenReturnKlantsessieComplianceWithToelichting",
						888L,
						new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_A.getId(), null, null, CHILD_KENMERK_1_A)
				),
				Arguments.of(
						"givenRecordDoesNotExist_WhenNewToelichting_ThenReturnKlantsessieComplianceWithToelichting",
						888L,
						new KlantsessieCompliance(888L, 12, CHILD_KENMERK_1_A.getId(), null, "test toelichting 2", CHILD_KENMERK_1_A)
				)
		);
	}

	private void stubCurrentKlantSessies() {
		Klantsessie klantsessie888 = new Klantsessie(888L);
		klantsessie888.setId(888L);
		Klantsessie klantsessie999 = new Klantsessie(999L);
		klantsessie999.setId(999L);

		when(klantsessieServiceMock.getCurrentKlantsessie(888L)).thenReturn(klantsessie888);
		when(klantsessieServiceMock.getCurrentKlantsessie(999L)).thenReturn(klantsessie999);
	}
}