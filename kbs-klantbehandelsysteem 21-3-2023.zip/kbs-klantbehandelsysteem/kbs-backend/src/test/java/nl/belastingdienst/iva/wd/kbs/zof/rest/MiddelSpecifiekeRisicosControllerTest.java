package nl.belastingdienst.iva.wd.kbs.zof.rest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleResponse;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisicoDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisicoDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisicoDtoWrapper;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoCheckListDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.MiddelSpecifiekeRisicoSelectionDto;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.DuplicatePolicy;
import nl.belastingdienst.iva.wd.kbs.zof.mappings.EntiteitMiddelRisicoMapper;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.BusinessRulesMiddelSpecifiekeRisicosService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.GetRisicoOverviewService;
import nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico.SaveNewEntiteitMiddelRisicoListService;

@WebMvcTest(controllers = MiddelSpecifiekeRisicosController.class)
@ExtendWith(MockitoExtension.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@ComponentScan(basePackageClasses = { EntiteitMiddelRisicoMapper.class })
@RestControllerTestConfiguration
class MiddelSpecifiekeRisicosControllerTest {

	private static final String JSON = MediaType.APPLICATION_JSON.toString();
	public static final Optional<BusinessRuleError> BUSINESS_RULE_ERROR = Optional.of(
			new BusinessRuleError("testmessage", DuplicatePolicy.class));
	public static final Optional<BusinessRuleError> BUSINESS_RULE_ERROR_2 = Optional.of(
			new BusinessRuleError("testmessage 2", DuplicatePolicy.class));
	public static final long INVALID_BUSINESS_RULE_ENTITTY = 999L;
	public static final long VALID_BUSINESS_RULE_ENTITY = 888L;
	public static final List<EntiteitMiddelRisicoDto> MIDDEL_SPECIFIEKE_RISICO_LIST_IN_MEMORY = List.of(
			new EntiteitMiddelRisicoDto(1L, 999L, null, 6L, null, (short) 1,  96L, 1,null, null),
			new EntiteitMiddelRisicoDto(2L, 999L, null, 6L, null, (short) 1,  96L, 1,null, null)
	);

	@Autowired
	private MiddelSpecifiekeRisicosController sut;

	@MockBean
	private BusinessRulesMiddelSpecifiekeRisicosService businessRulesMiddelSpecifiekeRisicosServiceMock;

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SaveNewEntiteitMiddelRisicoListService saveNewEntiteitMiddelRisicoListServiceMock;

	@MockBean
	private GetRisicoOverviewService getRisicoOverviewServiceMock;

	private void stubBusinessRulesMiddelSpecifiekeRisicosService() {
		when(businessRulesMiddelSpecifiekeRisicosServiceMock.validateWithCurrentId(eq(INVALID_BUSINESS_RULE_ENTITTY), any(), any())).thenReturn(BUSINESS_RULE_ERROR);
		when(businessRulesMiddelSpecifiekeRisicosServiceMock.validateWithCurrentId(eq(VALID_BUSINESS_RULE_ENTITY), any(), any())).thenReturn(Optional.empty());
		when(businessRulesMiddelSpecifiekeRisicosServiceMock.validate(eq(INVALID_BUSINESS_RULE_ENTITTY), any())).thenReturn(BUSINESS_RULE_ERROR_2);
		when(businessRulesMiddelSpecifiekeRisicosServiceMock.validate(eq(VALID_BUSINESS_RULE_ENTITY), any())).thenReturn(Optional.empty());
		when(businessRulesMiddelSpecifiekeRisicosServiceMock.validateWithList(eq(INVALID_BUSINESS_RULE_ENTITTY), any(), any())).thenReturn(BUSINESS_RULE_ERROR);
		when(businessRulesMiddelSpecifiekeRisicosServiceMock.validateWithList(eq(VALID_BUSINESS_RULE_ENTITY), any(), any())).thenReturn(Optional.empty());
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideCheckInput")
	void checkValidToBusinessRules(MiddelSpecifiekeRisicoSelectionDto selectieDto, Long entiteitNummer, BusinessRuleResponse expectedBusinessRuleResponse) {
		stubBusinessRulesMiddelSpecifiekeRisicosService();
		BusinessRuleResponse actualBusinessRuleResponse = this.sut.checkValidToBusinessRules(selectieDto, entiteitNummer);

		Assertions.assertEquals(expectedBusinessRuleResponse, actualBusinessRuleResponse);
	}

	private static Stream<Arguments> provideCheckInput() {
		return Stream.of(
				Arguments.of(
						new MiddelSpecifiekeRisicoSelectionDto(1L, null, null, (short) 1, 96L, null,1),
						INVALID_BUSINESS_RULE_ENTITTY,
						new BusinessRuleResponse("testmessage 2")
				),
				Arguments.of(
						new MiddelSpecifiekeRisicoSelectionDto(1L, null, 30L, (short) 1, 96L, null,1),
						INVALID_BUSINESS_RULE_ENTITTY,
						new BusinessRuleResponse("testmessage 2")
				),
				Arguments.of(
						new MiddelSpecifiekeRisicoSelectionDto(2L, null, null, (short) 1, 96L, null,1),
						INVALID_BUSINESS_RULE_ENTITTY,
						new BusinessRuleResponse("testmessage 2")
				),
				Arguments.of(
						new MiddelSpecifiekeRisicoSelectionDto(3L, null, 22L, (short) 1, 96L, null,1),
						INVALID_BUSINESS_RULE_ENTITTY,
						new BusinessRuleResponse("testmessage 2")
				),
				/* test duplicate but same id */
				Arguments.of(
						new MiddelSpecifiekeRisicoSelectionDto(1L, null, null, (short) 1, 96L, 1L,1),
						VALID_BUSINESS_RULE_ENTITY,
						new BusinessRuleResponse()
				),
				/* test duplicate on edit */
				Arguments.of(
						new MiddelSpecifiekeRisicoSelectionDto(1L, null, null, (short) 1, 96L, 2L,1),
						INVALID_BUSINESS_RULE_ENTITTY,
						new BusinessRuleResponse("testmessage")
				)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideCheckListInput")
	void checkListValidToBusinessRules(String testCaseName, MiddelSpecifiekeRisicoCheckListDto middelSpecifiekeRisicoCheckListDto, Long entiteitNummer, BusinessRuleResponse expectedBusinessRuleResponse) {
		stubBusinessRulesMiddelSpecifiekeRisicosService();
		BusinessRuleResponse businessRuleResponse = this.sut.checkListValidToBusinessRules(
				middelSpecifiekeRisicoCheckListDto,
				entiteitNummer
		);
		Assertions.assertEquals(expectedBusinessRuleResponse, businessRuleResponse);
	}

	private static Stream<Arguments> provideCheckListInput() {
		return Stream.of(
				Arguments.of(
						"whenNoDuplicate_ThenReturnBusinessRuleResponseNull",
						new MiddelSpecifiekeRisicoCheckListDto(
								new MiddelSpecifiekeRisicoSelectionDto(5L, null, null, (short) 1, 96L, null,1),
								MIDDEL_SPECIFIEKE_RISICO_LIST_IN_MEMORY
						),
						VALID_BUSINESS_RULE_ENTITY,
						new BusinessRuleResponse()
				),
				Arguments.of(
						"whenNoDuplicate_ThenReturnBusinessRuleResponseNull",
						new MiddelSpecifiekeRisicoCheckListDto(
								new MiddelSpecifiekeRisicoSelectionDto(5L, null, null, (short) 1, 96L, 1L,1),
								MIDDEL_SPECIFIEKE_RISICO_LIST_IN_MEMORY
						),
						VALID_BUSINESS_RULE_ENTITY,
						new BusinessRuleResponse()
				),
				Arguments.of(
						"whenWithDuplicateAlreadyInDb_ThenReturnBusinessRuleResponse",
						new MiddelSpecifiekeRisicoCheckListDto(
								new MiddelSpecifiekeRisicoSelectionDto(1L, null, null, (short) 1, 96L, null,1),
								MIDDEL_SPECIFIEKE_RISICO_LIST_IN_MEMORY
						),
						INVALID_BUSINESS_RULE_ENTITTY,
						new BusinessRuleResponse("testmessage")
				)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideSaveListInput")
	void saveListValidToBusinessRules(String testCaseName, LoggingWrapper<List<EntiteitMiddelRisicoDto>> entiteitMiddelRisicoDtoList, Long entiteitnummer, BusinessRuleResponse expectedResponse) {
		stubSaveNewEntiteitMiddelRisicoListService();
		var actual = this.sut.saveListValidToBusinessRules(entiteitMiddelRisicoDtoList, entiteitnummer);

		Assertions.assertEquals(expectedResponse, actual);
	}

	private static Stream<Arguments> provideSaveListInput() {
		List<EntiteitMiddelRisicoDto> entiteitMiddelRisicoDtos = List.of(
				new EntiteitMiddelRisicoDto(1L, INVALID_BUSINESS_RULE_ENTITTY, 1L, 1L, null, (short) 1, 96L, 1,null, null),
				new EntiteitMiddelRisicoDto(2L, INVALID_BUSINESS_RULE_ENTITTY, 1L, 2L, null, (short) 1, 96L, 1,null, null)
		);

		return Stream.of(
			Arguments.of(
					"whenListInputValid_ThenReturnNull",
					new LoggingWrapper<>("testid1", entiteitMiddelRisicoDtos),
					VALID_BUSINESS_RULE_ENTITY,
					null
			),
			Arguments.of(
					"whenListInputInvalid_ThenReturnErrorMessage",
					new LoggingWrapper<>("testid1", entiteitMiddelRisicoDtos),
					INVALID_BUSINESS_RULE_ENTITTY,
					new BusinessRuleResponse("test error message")
			)
		);
	}

	private void stubSaveNewEntiteitMiddelRisicoListService(){
		Mockito.doThrow(new BusinessRuleException("test error message")).when(this.saveNewEntiteitMiddelRisicoListServiceMock).save(any(), eq(INVALID_BUSINESS_RULE_ENTITTY), any());
	}

	@Test
	void getOverview() throws Exception {
		var lowestEntiteitMiddelRisicoDtoList = List.of(
				new LowestEntiteitMiddelRisicoDto("risico 1", (short) 0, "Nieuw", "Beheerst", "VPB"),
				new LowestEntiteitMiddelRisicoDto("risico 2", (short) 0, "Nieuw", "Beheerst", "IH"));
		when(this.getRisicoOverviewServiceMock.getRisicoOverview(111L)).thenReturn(lowestEntiteitMiddelRisicoDtoList
		);

		mockMvc.perform(get("/api/middel-specifieke-risicos/{entiteitNummer}", 111L)
						.contentType(JSON))
				.andExpect(status().isOk())
				.andExpect(ResponseBodyMatchers.responseBody()
						.containsObjectAsJson(
								LowestEntiteitMiddelRisicoDtoWrapper.map(lowestEntiteitMiddelRisicoDtoList),
								LowestEntiteitMiddelRisicoDtoWrapper.class)
				);

	}
}