package nl.belastingdienst.iva.wd.kbs.maintenancemessage.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.maintenancemessage.domain.Message;

@Repository
public interface MessageCreateUpdateDeleteRepository extends JpaRepository<Message, Long> {
}
