package nl.belastingdienst.iva.wd.kbs.gkv.rest;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import nl.belastingdienst.iva.wd.kbs.exception.FailedToRetrieveSuccessfulResponseException;
import nl.belastingdienst.iva.wd.kbs.gkv.domain.Toegang;
import nl.belastingdienst.iva.wd.kbs.gkv.service.EntiteitNummerAccessCheckService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;

@WebMvcTest(controllers = EntiteitNummerAccessCheckController.class)
@ExtendWith(MockitoExtension.class)
@WithMockUser("ivatest1")
@RestControllerTestConfiguration
class EntiteitNummerAccessCheckControllerTest {

	private static final String JSON = MediaType.APPLICATION_JSON.toString();
	public static final Toegang TOEGANG = new Toegang(true, List.of());

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	EntiteitNummerAccessCheckService entiteitNummerAccessCheckServiceMock;

	@Test
	void givenEntiteitNummer_ThenReturnCorrectToegang() throws Exception {
		when(entiteitNummerAccessCheckServiceMock.getAutorisatieRapportToegang(1234L)).thenReturn(TOEGANG);

		mockMvc.perform(MockMvcRequestBuilders.get("/api/gkv/toegang/{entiteit_nummer}", 1234)
						.contentType(JSON)
				)
				.andExpect(status().isOk())
				.andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(TOEGANG, Toegang.class))
		;
	}

	@Test
	void givenInaccessibleEntiteitNummer_ThenReturnBadRequest() throws Exception {
		when(entiteitNummerAccessCheckServiceMock.getAutorisatieRapportToegang(555L)).thenThrow(new FailedToRetrieveSuccessfulResponseException("test exception"));

		mockMvc.perform(MockMvcRequestBuilders.get("/api/gkv/toegang/{entiteit_nummer}", 555)
						.contentType(JSON)
				)
				.andExpect(status().isBadRequest())
		;
	}
}