/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: PerProcesWithAbbreviatedMiddelTestObject.java
 *             Auteur: duisr01
 *    Creatietijdstip: 14-11-2022 11:55
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.klantsessie.domain;

import java.util.List;
import java.util.stream.Collectors;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PerProcesWithAbbreviatedMiddelTestObject implements PerProcesWithAbbreviatedMiddelProjection {
	private String afkorting;
	private String vooroverleg;
	private String heffing;
	private String bezwaren;

	public static List<PerProcesWithAbbreviatedMiddelTestObject> map(List<PerProcesWithAbbreviatedMiddelProjection> perProcesWithAbbreviatedMiddelProjectionList){
		return perProcesWithAbbreviatedMiddelProjectionList.stream()
				.map(projection -> new PerProcesWithAbbreviatedMiddelTestObject(projection.getAfkorting(),
						projection.getVooroverleg(), projection.getHeffing(), projection.getBezwaren()))
				.collect(Collectors.toList());
	}
}
