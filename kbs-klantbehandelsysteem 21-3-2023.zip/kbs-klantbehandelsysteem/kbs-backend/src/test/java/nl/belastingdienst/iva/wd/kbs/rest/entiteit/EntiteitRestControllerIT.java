package nl.belastingdienst.iva.wd.kbs.rest.entiteit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class EntiteitRestControllerIT {

	@LocalServerPort
	private int port;
	private String url = "http://localhost:%d/";

	@Autowired
	private TestRestTemplate restTemplate;

	@BeforeEach
	public void setUp() {
		url = String.format(url, port);
	}

	@Test
	void testGetEntiteit_ShouldThrowHttp404NotFound_WhenEntiteitNummerIsUnknown() {
		int entiteitNummer = 1;
		var r = restTemplate.getForEntity(url + entiteitNummer, String.class);
		assertEquals(HttpStatus.NOT_FOUND, r.getStatusCode());
	}
}