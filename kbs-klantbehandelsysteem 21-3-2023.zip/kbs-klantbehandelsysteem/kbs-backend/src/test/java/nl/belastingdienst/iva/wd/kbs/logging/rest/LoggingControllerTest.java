package nl.belastingdienst.iva.wd.kbs.logging.rest;

import static nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers.responseBody;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import nl.belastingdienst.iva.wd.kbs.domain.LoggingInfoDto;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;

@WebMvcTest(controllers = LoggingController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class LoggingControllerTest {

	public static final String LOGGING_ID_1 = "loggingId1";
	private static final String JSON = MediaType.APPLICATION_JSON.toString();
	public static final long ENTITEITNUMMER_WITH_LOGGING = 111L;
	public static final Logging2 LOGGING_2 = new Logging2(1L, "ivatest1", LocalDateTime.of(2022, 10, 10, 10, 0),
			ENTITEITNUMMER_WITH_LOGGING, LOGGING_ID_1, "UPDATE", "codeSource1");
	public static final long ENTITEITNUMMER_WITHOUT_LOGGING = 999L;
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private Logging2Service logging2ServiceMock;

	@Test
	void givenLoggingInfoExistWithEntiteitnummer_ThenReturnLoggingInfo() throws Exception {
		when(logging2ServiceMock.getLatestLogging(LOGGING_ID_1, ENTITEITNUMMER_WITH_LOGGING)).thenReturn(
				Optional.of(LOGGING_2)
		);

		mockMvc.perform(get("/api/logging/{loggingId}/{entiteitnummer}", LOGGING_ID_1, ENTITEITNUMMER_WITH_LOGGING).contentType(JSON))
			   .andExpect(status().isOk())
			   .andExpect(responseBody().containsObjectAsJson(
					   new LoggingInfoDto(
							   LOGGING_2.getLoggingId(),
							   LOGGING_2.getUsername(),
							   LOGGING_2.getChangedAt()
					   ), LoggingInfoDto.class));
	}

	@Test
	void givenLoggingInfoDoesNotExist_ReturnNull() throws Exception {
		when(logging2ServiceMock.getLatestLogging(LOGGING_ID_1, ENTITEITNUMMER_WITHOUT_LOGGING)).thenReturn(
				Optional.empty()
		);

		mockMvc.perform(get("/api/logging/{loggingId}/{entiteitnummer}", LOGGING_ID_1, ENTITEITNUMMER_WITHOUT_LOGGING).contentType(JSON))
			   .andExpect(status().isOk())
			   .andExpect(mvcResult -> Assertions.assertEquals("", mvcResult.getResponse().getContentAsString()));
	}
}