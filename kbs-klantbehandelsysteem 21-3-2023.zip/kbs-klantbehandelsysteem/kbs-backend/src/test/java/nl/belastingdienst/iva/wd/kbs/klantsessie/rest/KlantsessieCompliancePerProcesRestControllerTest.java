package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import static nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers.responseBody;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliancePerProces;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesWithAbbreviatedMiddelProjection;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.PerProcesWithAbbreviatedMiddelTestObject;
import nl.belastingdienst.iva.wd.kbs.klantsessie.mappings.KlantsessieComplianceMapper;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieCompliancePerProcesService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;

@WebMvcTest(controllers = KlantsessieCompliancePerProcesRestController.class)
@ComponentScan(basePackageClasses = { KlantsessieComplianceMapper.class})
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class KlantsessieCompliancePerProcesRestControllerTest {

	private static final long ENTITEIT_NUMMER = 999L;
	private static final int MIDDEL_ID = 12;
	private static final String JSON = MediaType.APPLICATION_JSON.toString();

	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";

	private final ObjectMapper objectMapper = new ObjectMapper();
	@MockBean
	private KlantsessieCompliancePerProcesService klantsessieCompliancePerProcesServiceMock;

	@Autowired
	private MockMvc mockMvc;

	@Test
	void getPerProces_WithExistingMiddel__ReturnsHttp200Ok() throws Exception {
		KlantsessieCompliancePerProces expected = new KlantsessieCompliancePerProces(1L, MIDDEL_ID, 144, 144, 145);

		when(klantsessieCompliancePerProcesServiceMock.getPerProces(ENTITEIT_NUMMER, MIDDEL_ID)).thenReturn(expected);
		mockMvc.perform(get("/api/klantsessie/compliance/per-proces/{entiteitNummer}/{middelId}", ENTITEIT_NUMMER, MIDDEL_ID )
					   .contentType(JSON)
			   )
			   .andExpect(status().isOk())
			   .andExpect(responseBody().containsObjectAsJson(expected, KlantsessieCompliancePerProces.class));
	}

	@Test
	void updatePerProces_WithExistingMiddel__ReturnsHttp200Ok() throws Exception {
		KlantsessieCompliancePerProces perProces = new KlantsessieCompliancePerProces(2L, MIDDEL_ID, 0, 0, 0);
		PerProcesDto data = new PerProcesDto(2L, MIDDEL_ID, 143, 144, 0);
		when(klantsessieCompliancePerProcesServiceMock.update(eq(data), eq(ENTITEIT_NUMMER), any())).thenReturn(perProces);
		var loggingWrapper = new LoggingWrapper<>(TEST_LOGGING_ID_1, data);
		mockMvc.perform(post("/api/klantsessie/compliance/per-proces/{entiteitNummer}", ENTITEIT_NUMMER)
					   .contentType(JSON)
					   .content(objectMapper.writeValueAsString(loggingWrapper))
			   )
			   .andExpect(status().isOk())
			   .andExpect(responseBody().containsObjectAsJson(perProces, KlantsessieCompliancePerProces.class));
	}

	@Test
	void getCompliancePerProces() throws Exception {
		var expected = this.getExpectedPerProces();
		new KlantsessieCompliancePerProces(1L, MIDDEL_ID, 144, 144, 145);

		when(klantsessieCompliancePerProcesServiceMock.getPerProces(ENTITEIT_NUMMER)).thenReturn(expected);
		List<PerProcesWithAbbreviatedMiddelTestObject> map = PerProcesWithAbbreviatedMiddelTestObject.map(expected);
		mockMvc.perform(get("/api/klantsessie/compliance/per-proces/{entiteitNummer}", ENTITEIT_NUMMER, MIDDEL_ID )
						.contentType(JSON)
				)
				.andExpect(status().isOk())
				.andExpect(responseBody().containsObjectAsJson(map, PerProcesWithAbbreviatedMiddelTestObject.class));
	}

	private List<PerProcesWithAbbreviatedMiddelProjection> getExpectedPerProces() {
		return List.of(new PerProcesWithAbbreviatedMiddelProjection() {
			@Override
			public String getAfkorting() {
				return "VPB";
			}

			@Override
			public String getVooroverleg() {
				return "Vooroverleg hoog";
			}

			@Override
			public String getHeffing() {
				return "Vooroverleg hoog";
			}

			@Override
			public String getBezwaren() {
				return "Vooroverleg hoog";
			}
		}, new PerProcesWithAbbreviatedMiddelProjection() {
			@Override
			public String getAfkorting() {
				return "IH";
			}

			@Override
			public String getVooroverleg() {
				return "Vooroverleg middel";
			}

			@Override
			public String getHeffing() {
				return "Vooroverleg laag";
			}

			@Override
			public String getBezwaren() {
				return "Vooroverleg hoog";
			}
		});
	}


}