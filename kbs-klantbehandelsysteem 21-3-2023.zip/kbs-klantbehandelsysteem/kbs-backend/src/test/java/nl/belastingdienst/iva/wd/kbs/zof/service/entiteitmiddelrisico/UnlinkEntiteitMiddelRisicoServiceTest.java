package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@SpringBootKbsTest
class UnlinkEntiteitMiddelRisicoServiceTest {

	public static final long ENTITEIT_MIDDEL_KENMERK_ID_TO_UNLINK = 10L;
	@Autowired
	private EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;

	@Autowired
	private UnlinkEntiteitMiddelRisicoService sut;

	@BeforeEach
	void setUp() {
		this.entiteitMiddelRisicoRepository.saveAll(
				List.of(
						new EntiteitMiddelRisico(1L, 999L, 20L, 1L, null, (short) 1, 96L, 1, null),
						new EntiteitMiddelRisico(2L, 999L, ENTITEIT_MIDDEL_KENMERK_ID_TO_UNLINK, 2L, null, (short) 1, 96L, 1, null),
						new EntiteitMiddelRisico(3L, 999L, ENTITEIT_MIDDEL_KENMERK_ID_TO_UNLINK, 3L, null, (short) 1, 96L, 1, null),
						new EntiteitMiddelRisico(4L, 888L, 21L, 4L, null, (short) 1, 96L, 1,null),
						new EntiteitMiddelRisico(5L, 888L, 21L, 5L, null, (short) 1, 96L, 1,null)
				)
		);
	}

	@Test
	void whenUnlinkEntiteitMiddelKenmerkWithIdThenRisicosAreUnlinked() {

		var expected = List.of(
				new EntiteitMiddelRisico(1L, 999L, 20L, 1L, null, (short) 1, 96L, 1,null),
				new EntiteitMiddelRisico(2L, 999L, null, 2L, null, (short) 1, 96L, 1,null),
				new EntiteitMiddelRisico(3L, 999L, null, 3L, null, (short) 1, 96L, 1,null),
				new EntiteitMiddelRisico(4L, 888L, 21L, 4L, null, (short) 1, 96L, 1,null),
				new EntiteitMiddelRisico(5L, 888L, 21L, 5L, null, (short) 1, 96L, 1,null)
		);

		this.sut.unlinkRisicosForEntiteitMiddelKenmerkId(ENTITEIT_MIDDEL_KENMERK_ID_TO_UNLINK);
		List<EntiteitMiddelRisico> actualAll = this.entiteitMiddelRisicoRepository.findAll();

		Assertions.assertEquals(expected, actualAll);

	}
}