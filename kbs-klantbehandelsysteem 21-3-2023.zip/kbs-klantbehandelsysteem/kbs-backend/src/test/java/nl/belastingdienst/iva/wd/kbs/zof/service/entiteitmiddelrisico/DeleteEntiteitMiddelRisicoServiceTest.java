/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.event.DeleteRisicoEventPublisher;

@SpringBootKbsTest
class DeleteEntiteitMiddelRisicoServiceTest {
    public static final String TEST_LOGGING_ID_1 = "testLoggingId1";
    @MockBean
    private Logging2Service logging2ServiceMock;
    @MockBean
    private EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;
    @MockBean
    private DeleteRisicoEventPublisher deleteRisicoEventPublisher;
    @Autowired
    DeleteEntiteitMiddelRisicoService cut;

    @Test
    @DisplayName("delete_EntiteitMiddelRisico")
    void delete() {
        EntiteitMiddelRisico toDelete = new EntiteitMiddelRisico(1L, 999L, null, 1L, null, (short) 1, 1L, 1,null);

        when(entiteitMiddelRisicoRepository.findByEntiteitNummerAndId(toDelete.getEntiteitNummer(),toDelete.getId())).thenReturn(Optional.of(toDelete));

        cut.delete(toDelete.getEntiteitNummer(), toDelete.getId(), TEST_LOGGING_ID_1);

        Mockito.verify(entiteitMiddelRisicoRepository, times(1)).delete(toDelete);
        Mockito.verify(deleteRisicoEventPublisher, times(1)).publish(toDelete);
        LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, 999L, Logging2.Bewerking.DELETE);
    }
}