package nl.belastingdienst.iva.wd.kbs.klantsessie.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ComplianceAankomendeKlantSessieToelichtingDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.ComplianceAankomendeKlantsessieDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieUitkomst;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.ComplianceAankomendeKlantsessieService;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.KlantsessieService;
import nl.belastingdienst.iva.wd.kbs.logging.domain.LoggingWrapper;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;

@WebMvcTest(controllers = ComplianceAankomendeKlantsessieRestController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class ComplianceAankomendeKlantsessieRestControllerTest {
	private static final long ENTITEIT_NUMMER = 1234L;
	private static final String JSON = MediaType.APPLICATION_JSON.toString();
	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";

	private final ObjectMapper objectMapper = new ObjectMapper();
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	KlantsessieService klantsessieServiceMock;

	@MockBean
	ComplianceAankomendeKlantsessieService complianceAankomendeKlantsessieServiceMock;

	@Autowired private ComplianceAankomendeKlantsessieRestController sut;

	@ParameterizedTest
	@CsvSource({ "asdf, 1, sdfs, 123, 1, ASD" })
	void getKlantsessie(String toelichting, int score, String beschrijving, Integer kenmerkId, int strategie, String kenmerk)
			throws Exception {
		List<ComplianceAankomendeKlantsessieDto> expectedResult = getComplianceAankomendeKlantsessieDtos(toelichting, score,
				beschrijving, kenmerkId, strategie, kenmerk);

		when(complianceAankomendeKlantsessieServiceMock.getCurrentKlantsessie(anyLong())).thenReturn(expectedResult);

		sut = new ComplianceAankomendeKlantsessieRestController(complianceAankomendeKlantsessieServiceMock, klantsessieServiceMock);

		mockMvc.perform(get("/api/klantsessie/compliance-aankomende/{entiteitNummer}", ENTITEIT_NUMMER)
						.contentType(JSON))
				.andExpect(status().isOk())
				.andExpect(
						ResponseBodyMatchers.responseBody().containsObjectAsJson(
								expectedResult,
								ComplianceAankomendeKlantsessieDto.class)
				);
	}

	private static List<ComplianceAankomendeKlantsessieDto> getComplianceAankomendeKlantsessieDtos(
			String toelichting, Integer score,
			String beschrijving, Integer kenmerkId, Integer strategie, String kenmerk) {
		ComplianceAankomendeKlantsessieDto.ComplianceUitkomst ckDto = new ComplianceAankomendeKlantsessieDto.ComplianceUitkomst();
		ckDto.setToelichting(toelichting);
		ckDto.setScore(score);
		ckDto.setBeschrijving(beschrijving);
		ckDto.setKenmerkId(kenmerkId);
		ckDto.setStrategie(strategie);
		ComplianceAankomendeKlantsessieDto complianceAankomendeKlantsessieDto1 =
														new ComplianceAankomendeKlantsessieDto(kenmerk, List.of(ckDto));
		return List.of(complianceAankomendeKlantsessieDto1);
	}

	@ParameterizedTest
	@CsvSource({
			"asdf, 1, sdfs, 123, 1, ASD",
			"null, 1, sdfs, 123, 1, ASD"
	})
	void updateControlePlaatsgevonden(String toelichting, int score, String beschrijving, Integer kenmerkId, int strategie,
			String kenmerk) throws Exception {
		Klantsessie ks = new Klantsessie(123L);

		List<ComplianceAankomendeKlantsessieDto> expectedKlantsessies = getComplianceAankomendeKlantsessieDtos(toelichting, score,
				beschrijving, kenmerkId, strategie, kenmerk);
		String url = String.format("/api/klantsessie/compliance-aankomende/%s",ENTITEIT_NUMMER);
		ComplianceAankomendeKlantsessieDto.ComplianceUitkomst uitkomst = expectedKlantsessies.get(0).getUitkomsten().get(0);
		KlantsessieUitkomst ksUitkomst = new KlantsessieUitkomst(123L, kenmerkId, score, strategie, toelichting);

		when(klantsessieServiceMock.getCurrentKlantsessie(anyLong())).thenReturn(ks);
		when(complianceAankomendeKlantsessieServiceMock.updateResultaat(anyLong(),any(), any())).thenReturn(ksUitkomst);
		mockMvc.perform(post(url).contentType(JSON)
								 .content(objectMapper.writeValueAsString(new LoggingWrapper<>("logId1", uitkomst))))
				.andExpect(status().isOk())
				.andExpect(
						ResponseBodyMatchers
								.responseBody()
								.containsObjectAsJson(ksUitkomst, KlantsessieUitkomst.class));
	}

	@ParameterizedTest
	@ValueSource(longs = {123})
	void getActGebaseerdGehoudenKlantsessie(Long klantsessieId) {
		Klantsessie ks = new Klantsessie(klantsessieId);
		when(klantsessieServiceMock.getCurrentKlantsessie(anyLong())).thenReturn(ks);
		var ksc = sut.getActGebaseerdGehoudenKlantsessie(klantsessieId);
		assertTrue(ksc);
	}

	@ParameterizedTest
	@ValueSource(longs = {123})
	void updateActGebaseerdGehoudenKlantsessie(Long entiteitNummer) {
		Klantsessie ks = new Klantsessie(entiteitNummer);
		when(klantsessieServiceMock.getCurrentKlantsessie(anyLong())).thenReturn(ks);
		var ksc = sut.updateActGebaseerdGehoudenKlantsessie(entiteitNummer, new LoggingWrapper<>("testLoggingId1", null));
		assertFalse(ksc);
	}

	@ParameterizedTest
	@ValueSource(longs = {123})
	void getToelichtingGehoudenKlantsessie(Long entiteitNummer) {
		Klantsessie ks = new Klantsessie(entiteitNummer);
		when(klantsessieServiceMock.getCurrentKlantsessie(anyLong())).thenReturn(ks);
		var ksc = sut.getToelichtingGehoudenKlantsessie(entiteitNummer);
		assertNull(ksc.getToelichting());
	}

	@ParameterizedTest
	@MethodSource
	void testUpdateToelichtingKlantsessie(String toelichting) {
		Klantsessie ks = new Klantsessie(123L);
		when(klantsessieServiceMock.getCurrentKlantsessie(anyLong())).thenReturn(ks);
		assertNull(ks.getToelichtingGehoudenKlantsessie());
		ComplianceAankomendeKlantSessieToelichtingDto text = new ComplianceAankomendeKlantSessieToelichtingDto(toelichting);
		var ksc = sut.updateToelichtingGehoudenKlantsessie(123L, new LoggingWrapper<>("testLoggingId1", text));
		assertEquals(toelichting, ksc.getToelichting());
	}

	static Stream<String> testUpdateToelichtingKlantsessie(){
		return Stream.of("Dit is de toelichtingstekst", null);
	}
}
