package nl.belastingdienst.iva.wd.kbs.gkv.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;

import nl.belastingdienst.iva.wd.kbs.exception.FailedToRetrieveSuccessfulResponseException;
import nl.belastingdienst.iva.wd.kbs.gkv.component.GkvApiClient;
import nl.belastingdienst.iva.wd.kbs.gkv.domain.AutorisatieRapport;
import nl.belastingdienst.iva.wd.kbs.gkv.domain.Toegang;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
@WithMockUser("ivatest1")
class EntiteitNummerAccessCheckServiceTest {

	@MockBean
	GkvApiClient gkvApiClientMock;

	@Autowired
	EntiteitNummerAccessCheckService sut;


	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void getAutorisatieRapportToegang(String testCaseName, ResponseEntity<AutorisatieRapport> returnedResponse, Toegang expectedToegang, Class<Throwable> expectedException) {
		when(gkvApiClientMock.doRequest(any(),any(),any(),eq(AutorisatieRapport.class))).thenReturn(returnedResponse);
		if(expectedException != null){
			Assertions.assertThrows(expectedException, () -> {
				sut.getAutorisatieRapportToegang(111L);
			});
		} else {
			Toegang actualToegang = sut.getAutorisatieRapportToegang(111L);
			Assertions.assertEquals(expectedToegang, actualToegang);
		}

	}

	private static Stream<Arguments> provideInput() {
		return Stream.of(
				Arguments.of(
						"givenEmptyBody_ThenThrowException",
						new ResponseEntity<>(HttpStatus.OK),
						null,
						FailedToRetrieveSuccessfulResponseException.class
				),
				Arguments.of(
						"givenEmptyToegang_ThenThrowException",
						new ResponseEntity<>(new AutorisatieRapport(), HttpStatus.OK),
						null,
						FailedToRetrieveSuccessfulResponseException.class
				),
				Arguments.of(
						"givenCorrectResponse_ThenReturnToegang",
						new ResponseEntity<>(new AutorisatieRapport(
								null,
								null,
								new Toegang(false, List.of("VIP", "UNIT"))
						), HttpStatus.OK),
						new Toegang(false, List.of("VIP", "UNIT")),
						null
				)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInputCheck")
	void check(String testCaseName, ResponseEntity<AutorisatieRapport> returnedResponse, boolean expectedToegang) {
		when(gkvApiClientMock.doRequest(any(),any(),any(),eq(AutorisatieRapport.class))).thenReturn(returnedResponse);
		var actualToegang = sut.check(111L);
		Assertions.assertEquals(expectedToegang, actualToegang);
	}

	private static Stream<Arguments> provideInputCheck() {
		return Stream.of(
				Arguments.of(
						"givenToegangFalse_ThenReturnToegangFalse",
						new ResponseEntity<>(new AutorisatieRapport(
								null,
								null,
								new Toegang(false, List.of("VIP", "UNIT"))
						), HttpStatus.OK),
						false
				)
		);
	}
}