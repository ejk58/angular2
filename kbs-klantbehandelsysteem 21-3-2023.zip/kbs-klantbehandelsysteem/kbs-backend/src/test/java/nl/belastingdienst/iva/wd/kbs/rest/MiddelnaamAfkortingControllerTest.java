package nl.belastingdienst.iva.wd.kbs.rest;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelnaamAfkorting;
import nl.belastingdienst.iva.wd.kbs.service.MiddelnaamAfkortingService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.RestControllerTestConfiguration;
import nl.belastingdienst.iva.wd.kbs.shared.util.ResponseBodyMatchers;

@WebMvcTest(controllers = MiddelnaamAfkortingController.class)
@WithMockUser(username = "ivatest1", authorities = { "AUG_KBS_BEHANDELAAR" })
@RestControllerTestConfiguration
class MiddelnaamAfkortingControllerTest {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private static final String JSON = MediaType.APPLICATION_JSON.toString();

    @MockBean
    private MiddelnaamAfkortingService middelnaamAfkortingService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getMiddelnaamAfkortingen() throws Exception {
        List<MiddelnaamAfkorting> expected = List.of(
                new MiddelnaamAfkorting(12, "naam 1", "afkorting 1", 1L),
                new MiddelnaamAfkorting(13, "naam 2", "afkorting 2", 2L),
                new MiddelnaamAfkorting(14, "naam 3", "afkorting 3", 3L),
                new MiddelnaamAfkorting(24, "naam 4", "afkorting 4", 4L)
        );

        when(middelnaamAfkortingService.getMiddelnaamAfkortingen()).thenReturn(expected);

        mockMvc.perform(get("/api/middelnaamAfkorting/list")
                        .contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(ResponseBodyMatchers.responseBody().containsObjectAsJson(expected, MiddelnaamAfkorting.class));
    }
}