package nl.belastingdienst.iva.wd.kbs.zof.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRisicoKoppelingRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppeling;
import nl.belastingdienst.iva.wd.kbs.domain.KenmerkRisicosKoppelingCompositeId;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;

@SpringBootKbsTest
class FindAllEntiteitMiddelKenmerkenForRisicoServiceTest {

	public static final MiddelKenmerk MIDDEL_KENMERK_1 = new MiddelKenmerk(1L, 12, "vpb 1", null);
	public static final MiddelRisico MIDDEL_RISICO_10 = new MiddelRisico(10L, 12, "Risico vpb 10", null, null);
	public static final MiddelKenmerk MIDDEL_KENMERK_4 = new MiddelKenmerk(4L, 24, "div 2", null);
	public static final MiddelRisico MIDDEL_RISICO_11 = new MiddelRisico(11L, 12, "Risico vpb 11", null, null);
	public static final MiddelRisico MIDDEL_RISICO_DIV_13 = new MiddelRisico(13L, 24, "Risico div 13", null, null);
	@Autowired
	FindAllEntiteitMiddelKenmerkenForRisicoService sut;

	@Autowired
	MiddelKenmerkRepository middelKenmerkRepository;

	@Autowired
	MiddelRisicoRepository middelRisicoRepository;

	@Autowired
	EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;

	@Autowired
	KenmerkRisicoKoppelingRepository kenmerkRisicoKoppelingRepository;

	@BeforeEach
	void setUp() {

		this.middelRisicoRepository.saveAll(
				List.of(
						MIDDEL_RISICO_10,
						MIDDEL_RISICO_11,
						new MiddelRisico(12L, 12, "Risico vpb 12", null, null),
						MIDDEL_RISICO_DIV_13
				)
		);

		this.middelKenmerkRepository.saveAll(
				List.of(
						MIDDEL_KENMERK_1,
						new MiddelKenmerk(2L, 12, "vpb 2", null),
						new MiddelKenmerk(3L, 24, "div 1", null),
						MIDDEL_KENMERK_4
				)
		);

		this.entiteitMiddelKenmerkRepository.saveAll(
				List.of(
						new EntiteitMiddelKenmerk(1L, 4L, null, null, null, 1L, 111L),
						new EntiteitMiddelKenmerk(2L, 3L, null, null, null, 3L, 999L),
						new EntiteitMiddelKenmerk(3L, 2L, null, null, null, 3L, 111L),
						new EntiteitMiddelKenmerk(4L, 1L, null, null, null, 2L, 111L)
				)
		);

		this.kenmerkRisicoKoppelingRepository.saveAll(
				List.of(
						new KenmerkRisicosKoppeling(
								new KenmerkRisicosKoppelingCompositeId(MIDDEL_KENMERK_1.getId(), MIDDEL_RISICO_10.getId()),
								MIDDEL_KENMERK_1,
								MIDDEL_RISICO_10
						),
						new KenmerkRisicosKoppeling(
								new KenmerkRisicosKoppelingCompositeId(MIDDEL_KENMERK_4.getId(), MIDDEL_RISICO_DIV_13.getId()),
								MIDDEL_KENMERK_1,
								MIDDEL_RISICO_DIV_13
						),
						new KenmerkRisicosKoppeling(
								new KenmerkRisicosKoppelingCompositeId(MIDDEL_KENMERK_1.getId(), MIDDEL_RISICO_11.getId()),
								MIDDEL_KENMERK_1,
								MIDDEL_RISICO_11
						)
				)
		);
	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInput")
	void findAllEntiteitMiddelKenmerkenForRisico(String testCaseName, Long entiteitnummer, Long risicoId, Map<Long, MiddelKenmerk> expected) {
		var actual = this.sut.findAllEntiteitMiddelKenmerkenForRisico(entiteitnummer, risicoId);
		Assertions.assertEquals(expected, actual);
	}

	private static Stream<Arguments> provideInput() {
		return Stream.of(
			Arguments.of(
					"givenSetup_WhenEntiteitWithEntiteitMiddelKenmerkToBeLinkedForRisicoId_ThenReturnList",
					111L,
					10L,
					Map.of(4L, MIDDEL_KENMERK_1)
			),
			Arguments.of(
					"givenSetup_WhenEntiteitNoEntiteitMiddelKenmerkToBeLinkedToRisicoId_ThenReturnList",
					111L,
					999L,
					Map.of()
			),
			Arguments.of(
					"givenSetup_WhenEntiteitNoEntiteitMiddelKenmerkToBeLinkedToRisicoId_ThenReturnList",
					555L,
					10L,
					Map.of()
			)
		);
	}
}