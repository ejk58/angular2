package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
@ExtendWith(MockitoExtension.class)
class KlantsessieServiceTest {
	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";
	@MockBean
	Logging2Service logging2ServiceMock;

	@Autowired
	KlantsessieRepository klantsessieRepository;
	@Autowired
	KlantsessieService klantsessieService;

	private static final LocalDateTime testDateTime = LocalDateTime.of(2022, 6, 1, 12, 55);
	public static final Klantsessie KLANTSESSIE_1 = new Klantsessie(1L, 888L, testDateTime.minusHours(3), testDateTime.minusHours(2),
			false, true, null, null);

	@BeforeEach
	void setUp() {
		setupKlantSessie();
	}

	private void setupKlantSessie() {
		klantsessieRepository.saveAll(
				List.of(
						KLANTSESSIE_1,
						new Klantsessie(2L, 888L, testDateTime.minusHours(2), testDateTime.minusHours(1),false,true,null, null),
						new Klantsessie(3L, 888L, testDateTime, null,false,true,null, null)
				)
		);
	}


	public static Stream<Arguments> provideInputForCurrentKlantsessie() {
		return Stream.of(
				Arguments.of(
						"GivenEntiteitNummerThenReturnExistingCurrentKlantsessie", 888L,
						new Klantsessie(3L, 888L, testDateTime, null,false,true,null, null),
						false
						),
				Arguments.of(
						"GivenEntiteitNummerThenReturnNewCurrentKlantsessie", 777L,
						new Klantsessie(4L, 777L, LocalDateTime.now(), null,false,true,null, null),
						true
				)
		);
	}

	public static Stream<Arguments> provideInputForPreviousKlantsessie() {
		return Stream.of(
				Arguments.of(
						"GivenEntiteitNummerThenReturnPreviousKlantsessieMostRecent", 888L,
						new Klantsessie(2L, 888L, testDateTime.minusHours(2), testDateTime.minusHours(1),false,true,null, null)
				),
				Arguments.of(
						"GivenEntiteitNummerThenReturnNullWhenNoPreviousKlantsessie", 777L, null)
		);
	}



	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInputForCurrentKlantsessie")
	void getCurrentKlantsessie(String testCaseName, Long entiteitnummer, Klantsessie expectedOutput, boolean setStartdatum) throws InterruptedException {
		int numberOfThreads = 2;
		var executorService = Executors.newFixedThreadPool(numberOfThreads);
		var latch = new CountDownLatch(numberOfThreads);
		for (int i = 0; i < numberOfThreads; i++) {
			executorService.submit(() -> {
				this.klantsessieService.getCurrentKlantsessie(entiteitnummer);
				latch.countDown();
			});
		}

		latch.await();
		Klantsessie actual = this.klantsessieService.getCurrentKlantsessie(entiteitnummer);

		if(setStartdatum){
			var currentTime = LocalDateTime.now();
			Assertions.assertTrue(currentTime.plusMinutes(1).isAfter(actual.getStartdatum()));
			Assertions.assertTrue(currentTime.minusMinutes(1).isBefore(actual.getStartdatum()));
			actual.setStartdatum(expectedOutput.getStartdatum());
		}

		Assertions.assertEquals(expectedOutput, actual);

	}

	@ParameterizedTest(name = "[{index}] {0}")
	@MethodSource("provideInputForPreviousKlantsessie")
	void getPreviousKlantsessie(String testCaseName, Long entiteitnummer, Klantsessie expectedOutput) {
		Klantsessie actual = this.klantsessieService.getPreviousKlantsessie(entiteitnummer).orElse(null);
		Assertions.assertEquals(expectedOutput, actual);
	}

	@Test
	void updateControlePlaatsgevondenOfCurrentKlantsessie() {
		//Given
		Long entiteitNummer= 888L;
		boolean controlePlaatsgevonden = true;

		//When
		Klantsessie actual = klantsessieService.updateControlePlaatsgevondenOfCurrentKlantsessie(entiteitNummer, controlePlaatsgevonden, TEST_LOGGING_ID_1);

		//Then
		Assertions.assertEquals(controlePlaatsgevonden, actual.getControlePlaatsgevonden());
		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, entiteitNummer, Logging2.Bewerking.UPDATE);

	}

	@Test
	void getLastThreePreviousKlantsessie() {
		//Given
		List<Klantsessie> expected = klantsessieRepository.
				findFirst3ByEntiteitNummerAndEinddatumIsNotNullOrderByEinddatumDesc(888L);

		//When
		List<Klantsessie> actual = klantsessieService.getLastThreePreviousKlantsessie(888L);

		//Then
		Assertions.assertEquals(expected, actual);
		Assertions.assertEquals(2, actual.size());

	}

	@Test
	void saveWithLogging() {
		var klantsessie = this.klantsessieService.save(KLANTSESSIE_1, TEST_LOGGING_ID_1);
		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, klantsessie.getEntiteitNummer(), Logging2.Bewerking.UPDATE);
	}
}
