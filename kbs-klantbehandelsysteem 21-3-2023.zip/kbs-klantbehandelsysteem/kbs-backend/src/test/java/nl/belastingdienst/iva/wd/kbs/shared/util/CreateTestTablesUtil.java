/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: GenericRepository.java
 *             Auteur: duisr01
 *    Creatietijdstip: 18-5-2022 16:17
 *          Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Proprietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.shared.util;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class CreateTestTablesUtil {

	private static JdbcTemplate JDBC_TEMPLATE;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initStaticDependencies(){
		JDBC_TEMPLATE = this.jdbcTemplate;
	}

	public  static <T> void createTableForEntity(Class<T> tClass){
		String name = tClass.getAnnotation(Table.class).name();
		String createTableSql = "CREATE TABLE IF NOT EXISTS " + name + " ";
		var fields = new ArrayList<String>();
		for (Field declaredField : tClass.getDeclaredFields()) {
			var field = new StringBuilder(declaredField.getName()+" ");

			if(declaredField.getType() == String.class){
				field.append("VARCHAR(255)");
			}
			if(declaredField.getType() == Long.class){
				field.append("INT");
			}
			if(declaredField.getType() == LocalDate.class){
				field.append("TIMESTAMP(6)");
			}

			fields.add(field.toString());
		}

		String join = String.join(",", fields);
		var sql = createTableSql +"("+join+");";

		JDBC_TEMPLATE.execute(sql);
	}
}
