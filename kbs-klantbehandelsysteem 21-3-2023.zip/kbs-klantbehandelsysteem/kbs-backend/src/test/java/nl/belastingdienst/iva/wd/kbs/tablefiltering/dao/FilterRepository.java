/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: FilterRepository.java
 *             Auteur: duisr01
 *    Creatietijdstip: 5-1-2023 16:31
 *          Copyright: (c) 2023 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.kbs.tablefiltering.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.wd.kbs.tablefiltering.domain.FilterTestClass;

@Repository
public interface FilterRepository extends JpaRepository<FilterTestClass, Long>, JpaSpecificationExecutor<FilterTestClass> {
}
