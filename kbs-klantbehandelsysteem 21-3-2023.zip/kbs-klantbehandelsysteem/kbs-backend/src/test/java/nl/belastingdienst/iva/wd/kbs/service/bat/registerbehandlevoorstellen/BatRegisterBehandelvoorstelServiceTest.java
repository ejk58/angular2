package nl.belastingdienst.iva.wd.kbs.service.bat.registerbehandlevoorstellen;

import nl.belastingdienst.iva.wd.kbs.ApiServiceApplicationProperties;
import nl.belastingdienst.iva.wd.kbs.service.RestTemplateClient;
import nl.belastingdienst.iva.wd.kbs.service.bat.BatGegevensService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class BatRegisterBehandelvoorstelServiceTest {
    @MockBean
    private ApiServiceApplicationProperties apiServiceApplicationProperties;
    @MockBean
    private RestTemplateClient restTemplateClient;
    @MockBean
    BatGegevensService batGegevensService;
    @Mock
    private ResponseEntity<List<VoorstelType>> voorstelTypeResponseEntity;
    @Mock
    private ResponseEntity<Activiteit> activiteitResponseEntity;
    @Mock
    private ResponseEntity<CreateBehandelVoorstelToken> createBehandelVoorstelTokenResponseEntity;
    @Mock
    private Authentication authentication;

    @Autowired
    private BatRegisterBehandelvoorstelService cut;

    private static final VoorstelType VOORSTEL_TYPE_HEF01_TEST = new VoorstelType("HEF01", "test omschrijving");
    private static final VoorstelType VOORSTEL_TYPE_BPV01_TEST = new VoorstelType("BPV01", "test omschrijving");
    private final Map<String, String>  ACTIVITEIT_CODES = Map.of("AB-TEST", "Aangiftebehandeling");
    private final String VOORSTEL_URL = "/lookuptabel?tabel=OMSCHRIJVING_VOORSTELTYPE";
    private final String BEHANDELACTIVITEITCODES_URL = "/behandelvoorstel/behandelactiviteitcodes";
    private final CreateBehandelVoorstelToken BEHANDEL_VOORSTEL_TOKEN = new CreateBehandelVoorstelToken("TEST-TOKEN-XXXX");

    private Activiteit getActiviteit() {
        Activiteit activiteit = new Activiteit();
        Activiteit.ActiviteitenVanVoorstel testCodes = new Activiteit.ActiviteitenVanVoorstel();
        testCodes.setActiviteiten(ACTIVITEIT_CODES);
        Map<String, Activiteit.ActiviteitenVanVoorstel> activiteitenPerVoorstelCode =  Map.of("HEF01", testCodes);
        activiteit.setActiviteitenPerVoorstelCode(activiteitenPerVoorstelCode);
        return activiteit;
    }

    private Activiteit getActiviteitWithNotExistVoorstelCode() {
        Activiteit activiteit = new Activiteit();
        Activiteit.ActiviteitenVanVoorstel testCodes = new Activiteit.ActiviteitenVanVoorstel();
        testCodes.setActiviteiten(ACTIVITEIT_CODES);
        Map<String, Activiteit.ActiviteitenVanVoorstel> activiteitenPerVoorstelCode =  Map.of("NOT-EXIST", testCodes);
        activiteit.setActiviteitenPerVoorstelCode(activiteitenPerVoorstelCode);
        return activiteit;
    }

    private BehandelVoorstelRequestDto getCreateBehandelVoorstelRequest(VoorstelType voorstelType, String entiteitNummer) {
        BehandelVoorstelRequestDto testRequest = new BehandelVoorstelRequestDto();
        testRequest.setVoorstelAction("NEW");
        testRequest.setSubject(entiteitNummer);
        testRequest.setSubjectType("ENT");
        testRequest.setVoorstelType(voorstelType.getCode());
        return testRequest;
    }

    @BeforeEach
    void setup(){
        when(apiServiceApplicationProperties.getBatExternalUrl()).thenReturn("test/bat/url");
        when(apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel()).thenReturn("BAT-APIKey-Test");
    }

    @Test
    @DisplayName("when getBehandelvoorstelTypes then returns List of VoorstelTypes")
    void getBehandelvoorstelTypes() {
        //Given
        ParameterizedTypeReference<List<VoorstelType>> responseType = new ParameterizedTypeReference<>(){};
        List<VoorstelType> expected = List.of(VOORSTEL_TYPE_HEF01_TEST);

        var uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + VOORSTEL_URL);

        when(restTemplateClient.doRequest(HttpMethod.GET, uri,  null, responseType,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel() , false
        )).thenReturn(voorstelTypeResponseEntity);

        when(voorstelTypeResponseEntity.getBody()).thenReturn(expected);

        //When
        List<VoorstelType> actual = cut.getBehandelvoorstelTypes();

        //Then
        Assertions.assertNotNull(actual);
        Assertions.assertEquals(expected, actual);
        Assertions.assertEquals(expected.size(), actual.size());
    }

    @Test
    @DisplayName("when getBehandelActiviteitcodes returns Activiteit values")
    void getBehandelActiviteitcodes() {
        //Given
        var uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/behandelvoorstel/behandelactiviteitcodes");

        when(restTemplateClient.doRequest(HttpMethod.GET, uri,  null, Activiteit.class,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel() , false
        )).thenReturn(activiteitResponseEntity);

        when(activiteitResponseEntity.getBody()).thenReturn(getActiviteit());

        //When
        Activiteit actual = cut.getBehandelActiviteitcodes();

        //Then
        Assertions.assertNotNull(actual);
        Assertions.assertEquals(getActiviteit(), actual);
    }

    @Test
    @DisplayName("when getBehandelActiviteitcodes returns null")
    void getBehandelActiviteitcodesReturnsNull() {
        //Given
        var uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + BEHANDELACTIVITEITCODES_URL);

        when(restTemplateClient.doRequest(HttpMethod.GET, uri,  null, Activiteit.class,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel() , false
        )).thenReturn(activiteitResponseEntity);

        when(activiteitResponseEntity.getBody()).thenReturn(null);

        //When
        Activiteit actual = cut.getBehandelActiviteitcodes();

        //Then
        Assertions.assertNull(actual);
    }

    @Test
    void getBehandelvoorstelOptions() {
        //Given
        List<BehandelvoorstelOption> expected = List.of(
                new BehandelvoorstelOption(VOORSTEL_TYPE_HEF01_TEST,  ACTIVITEIT_CODES));

        var voorstellenUri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + VOORSTEL_URL);
        when(restTemplateClient.doRequest(HttpMethod.GET,
                voorstellenUri,
                null,
                 new ParameterizedTypeReference<List<VoorstelType>>(){},
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel() ,
                false
        )).thenReturn(voorstelTypeResponseEntity);
        when(voorstelTypeResponseEntity.getBody()).thenReturn(List.of(VOORSTEL_TYPE_HEF01_TEST));


        var activiteitUri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + BEHANDELACTIVITEITCODES_URL);
        when(restTemplateClient.doRequest(HttpMethod.GET, activiteitUri,  null, Activiteit.class,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel() , false
        )).thenReturn(activiteitResponseEntity);
        when(activiteitResponseEntity.getBody()).thenReturn(getActiviteit());

        //When
        List<BehandelvoorstelOption>  actual = cut.getBehandelvoorstelOptions();

        //Then
        Assertions.assertEquals(expected, actual);
    }

    @Test
    @DisplayName("when the matching voorstel code does not exist for the getBehandelvoorstelOptions then return empty list")
    void getBehandelvoorstelOptionsEmpty() {
        //Given
        var voorstellenUri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + VOORSTEL_URL);
        when(restTemplateClient.doRequest(HttpMethod.GET,
                voorstellenUri,
                null,
                new ParameterizedTypeReference<List<VoorstelType>>(){},
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel() ,
                false
        )).thenReturn(voorstelTypeResponseEntity);
        when(voorstelTypeResponseEntity.getBody()).thenReturn(List.of(VOORSTEL_TYPE_HEF01_TEST));


        var activiteitUri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + BEHANDELACTIVITEITCODES_URL);
        when(restTemplateClient.doRequest(HttpMethod.GET, activiteitUri,  null, Activiteit.class,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel() , false
        )).thenReturn(activiteitResponseEntity);
        when(activiteitResponseEntity.getBody()).thenReturn(getActiviteitWithNotExistVoorstelCode());

        //When
        List<BehandelvoorstelOption>  actual = cut.getBehandelvoorstelOptions();

        //Then
        Assertions.assertEquals(List.of(), actual);
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("providecreateBehandelVoorstelInput")
    void createBehandelVoorstel(String testCaseName, String entiteitnummer, VoorstelType voorstelType) {
        when(authentication.getName()).thenReturn("Test-UserId");
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String mockedUserId = SecurityContextHolder.getContext().getAuthentication().getName();

        if ("BPV01".equals(voorstelType.getCode())) {
            reset(apiServiceApplicationProperties);
            var request = getCreateBehandelVoorstelRequest(VOORSTEL_TYPE_BPV01_TEST, entiteitnummer);
            when(batGegevensService.createBehandelVoorstel(Long.valueOf(entiteitnummer), request.getVoorstelType()))
                    .thenReturn("BPV01-TEST-ID");
            var actual = cut.createBehandelVoorstel(request);
            var expected = new BehandelVoorstelResponse("BPV01-TEST-ID", null);
            Assertions.assertEquals(expected, actual);

        } else {
            var uri = URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/start");
            var body = getCreateBehandelVoorstelRequest(VOORSTEL_TYPE_HEF01_TEST, entiteitnummer);
            body.setBehandelActiviteitCode("AB-TEST");
            body.setUserId(mockedUserId);
            var xAPIKey = apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel();

            when(restTemplateClient.doRequest(HttpMethod.POST, uri,
                    body, CreateBehandelVoorstelToken.class,
                    xAPIKey, false
            )).thenReturn(createBehandelVoorstelTokenResponseEntity);
            when(createBehandelVoorstelTokenResponseEntity.getBody()).thenReturn(BEHANDEL_VOORSTEL_TOKEN);

            var actual = cut.createBehandelVoorstel(body);
            var expected = new BehandelVoorstelResponse(null, BEHANDEL_VOORSTEL_TOKEN.getToken());
            Assertions.assertEquals(expected, actual);
        }
    }

    public static Stream<Arguments> providecreateBehandelVoorstelInput() {
        return Stream.of(
                Arguments.of(
                        "when createBehandelVoorstel returns a BehandelVoorstel id",
                        "999",
                        VOORSTEL_TYPE_BPV01_TEST
                ),
                Arguments.of(
                        "when createBehandelVoorstel returns a token",
                        "222",
                        VOORSTEL_TYPE_HEF01_TEST
                )
        );
    }

    @Test
    @DisplayName("when createBehandelVoorstel with null User Id then throw exception" )
    void createBehandelVoorstelWithUnkownUser(){
        //given
        when(authentication.getName()).thenReturn(null);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String emptyUserId = SecurityContextHolder.getContext().getAuthentication().getName();

        BehandelVoorstelRequestDto body = new BehandelVoorstelRequestDto("NEW", VOORSTEL_TYPE_BPV01_TEST.getCode(),
                "AB TEST", null,  "111", "ENT", emptyUserId);

        BehandelVoorstelRequestDto request = getCreateBehandelVoorstelRequest(VOORSTEL_TYPE_HEF01_TEST, "111");

        when(restTemplateClient.doRequest(HttpMethod.POST, URI.create(apiServiceApplicationProperties.getBatExternalUrl() + "/start"),
                body, CreateBehandelVoorstelToken.class,
                apiServiceApplicationProperties.getBatApiKeyBehandelvoorstel(), false
        )).thenReturn(createBehandelVoorstelTokenResponseEntity);

        //when & then
        assertThrows(NullPointerException.class,  () -> cut.createBehandelVoorstel(request));

    }

}
