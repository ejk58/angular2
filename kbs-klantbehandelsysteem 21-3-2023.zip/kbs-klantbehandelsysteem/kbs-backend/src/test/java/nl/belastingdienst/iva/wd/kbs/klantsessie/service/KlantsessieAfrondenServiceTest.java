package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.EntiteitKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerkId;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieUitkomstRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStatusRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStatus;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieUitkomst;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class KlantsessieAfrondenServiceTest {

    public static final String TEST_LOGGING_ID_1 = "testLoggingId1";
    @MockBean
    private KlantsessieService klantsessieServiceMock;
    @Autowired
    private KenmerkRepository kenmerkRepository;
    @Autowired
    private EntiteitKenmerkRepository entiteitKenmerkRepository;
    @Autowired
    private KlantSessieUitkomstRepository klantSessieUitkomstRepository;
    @Autowired
    private KlantsessieStatusRepository klantsessieStatusRepository;

    @Autowired
    KlantsessieAfrondenService cut;

    private static final Kenmerk PARENT_KENMERK_1 = new Kenmerk(1, "KS_CAT", "Parent 1", null);
    private static final Kenmerk PARENT_KENMERK_2 = new Kenmerk(2, "KS_CAT", "Parent 2", null);
    private static final Kenmerk CHILD_KENMERK_1_A = new Kenmerk(10, "KS_CAT", "Child parent 1a", 1);
    private static final Kenmerk CHILD_KENMERK_1_B = new Kenmerk(11, "KS_CAT", "Child parent 1b", 1);
    private static final Kenmerk CHILD_KENMERK_2_A = new Kenmerk(20, "KS_CAT", "Child parent 2a", 2);
    private static final Kenmerk CHILD_KENMERK_2_B = new Kenmerk(21, "KS_CAT", "Child parent 2b", 2);
    private static final List<Kenmerk> KENMERK_LIST = List.of(PARENT_KENMERK_1, PARENT_KENMERK_2, CHILD_KENMERK_1_A, CHILD_KENMERK_1_B, CHILD_KENMERK_2_A, CHILD_KENMERK_2_B);

    private static final List<KlantsessieUitkomst> KLANTSESSIE_UITKOMST = List.of(
            new KlantsessieUitkomst(1L, CHILD_KENMERK_1_A.getId(), 3, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(1L, CHILD_KENMERK_1_B.getId(), 4, 2, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(1L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId()),
            new KlantsessieUitkomst(1L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(2L, CHILD_KENMERK_1_A.getId(), 3, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(2L, CHILD_KENMERK_1_B.getId(), 4, 2, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(2L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId()),
            new KlantsessieUitkomst(2L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(3L, CHILD_KENMERK_1_A.getId(), 3, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(3L, CHILD_KENMERK_1_B.getId(), 4, 2, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(3L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId()),
            new KlantsessieUitkomst(3L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(4L, CHILD_KENMERK_1_A.getId(), null, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(4L, CHILD_KENMERK_1_B.getId(), 4, 4, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(4L, CHILD_KENMERK_2_A.getId(), 5, 2, "test"),
            new KlantsessieUitkomst(4L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(5L, CHILD_KENMERK_1_A.getId(), 2, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(5L, CHILD_KENMERK_1_B.getId(), 4, null, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(5L, CHILD_KENMERK_2_A.getId(), 5, 2, "test"),
            new KlantsessieUitkomst(5L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(6L, CHILD_KENMERK_1_A.getId(), 0, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(6L, CHILD_KENMERK_1_B.getId(), 4, 4, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(6L, CHILD_KENMERK_2_A.getId(), 5, 2, null),
            new KlantsessieUitkomst(6L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(7L, CHILD_KENMERK_1_A.getId(), 0, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),

            new KlantsessieUitkomst(8L, CHILD_KENMERK_1_A.getId(), 0, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(8L, CHILD_KENMERK_1_B.getId(), 4, 4, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(8L, CHILD_KENMERK_2_A.getId(), 5, 2, "test"),
            new KlantsessieUitkomst(8L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(9L, CHILD_KENMERK_1_A.getId(), 0, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(9L, CHILD_KENMERK_1_B.getId(), 4, 4, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(9L, CHILD_KENMERK_2_A.getId(), 5, 2, "test"),
            new KlantsessieUitkomst(9L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId())

    );

    private static final List<EntiteitKenmerk> SELECTED_MIDDELEN_PER_ENTITEIT = List.of(
            //Entiteitnummer 111L with 2 selected middelen 12,13
            new EntiteitKenmerk(new EntiteitKenmerkId(111L, "MID", 12), null),
            new EntiteitKenmerk(new EntiteitKenmerkId(111L, "MID", 13), null),

            new EntiteitKenmerk(new EntiteitKenmerkId(333L, "MID", 12), null),

            new EntiteitKenmerk(new EntiteitKenmerkId(777L, "MID", 12), null),

            new EntiteitKenmerk(new EntiteitKenmerkId(888L, "MID", 12), null)
    );

    private static final List<KlantsessieStatus> SELECTED_MIDDELEN_STATUS = List.of(
            new KlantsessieStatus(1L, 12, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true),
            new KlantsessieStatus(1L, 13, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true),
            new KlantsessieStatus(1L, 141, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true),
            new KlantsessieStatus(1L, 142, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true),

            new KlantsessieStatus(2L, 142, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true),

            new KlantsessieStatus(223L, 142, StepStatusEnum.INITIAL, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.TOUCHED, true),

            new KlantsessieStatus(3L, 12, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, false),
            new KlantsessieStatus(3L, 141, StepStatusEnum.INITIAL, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, false),
            new KlantsessieStatus(3L, 142, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true),

            new KlantsessieStatus(8L, 12, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true),
            new KlantsessieStatus(8L, 141, StepStatusEnum.INITIAL, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, false),
            new KlantsessieStatus(8L, 142, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true)

    );

    private void stubCurrentKlantSessie() {
        //--------------
        //Entiteitnummer_222L has Klantsessie with ActGebaseerdGehoudenKlantsessie niet aan but with Toelichting and and alle scores and toelichtingen KLANTSESSIE_UITKOMST are filled
        Klantsessie klantsessie_222L = new Klantsessie(222L);
        klantsessie_222L.setId(2L);
        klantsessie_222L.setActGebaseerdGehoudenKlantsessie(false);
        klantsessie_222L.setToelichtingGehoudenKlantsessie("ToelichtingGehoudenKlantsessie aan");
        when(klantsessieServiceMock.getCurrentKlantsessie(222L)).thenReturn(klantsessie_222L);

        /* middelen steps with 1 initial, rest compelete  */
        Klantsessie klantsessie_223L = new Klantsessie(223L);
        klantsessie_223L.setId(223L);
        klantsessie_223L.setActGebaseerdGehoudenKlantsessie(false);
        klantsessie_223L.setToelichtingGehoudenKlantsessie("ToelichtingGehoudenKlantsessie aan");
        when(klantsessieServiceMock.getCurrentKlantsessie(223L)).thenReturn(klantsessie_223L);

        Klantsessie klantsessie_999L = new Klantsessie(999L);
        klantsessie_999L.setId(9L);
        klantsessie_999L.setActGebaseerdGehoudenKlantsessie(false);
        when(klantsessieServiceMock.getCurrentKlantsessie(999L)).thenReturn(klantsessie_999L);

        //--------------
        //Entiteitnummer_111L has Klantsessie with ActGebaseerdGehoudenKlantsessie aan and with 2selected middlen with all staTus DONE  and alle scores and toelichtingen KLANTSESSIE_UITKOMST are filled
        Klantsessie klantsessie_111L = new Klantsessie(111L);
        klantsessie_111L.setId(1L);
        klantsessie_111L.setControlePlaatsgevonden(true);
        klantsessie_111L.setActGebaseerdGehoudenKlantsessie(true);
        when(klantsessieServiceMock.getCurrentKlantsessie(111L)).thenReturn(klantsessie_111L);

        //Entiteitnummer_333L has Klantsessie with ActGebaseerdGehoudenKlantsessie aan and alle scores and toelichtingen KLANTSESSIE_UITKOMST are filled but with not all staTus DONE
        Klantsessie klantsessie_333L = new Klantsessie(333L);
        klantsessie_333L.setId(3L);
        klantsessie_333L.setActGebaseerdGehoudenKlantsessie(true);
        when(klantsessieServiceMock.getCurrentKlantsessie(333L)).thenReturn(klantsessie_333L);

        //special behaviour: if controle is niet plaatsgevonden, when checking that all steps are DONE, should not count controle
        Klantsessie klantsessie_888L = new Klantsessie(888L);
        klantsessie_888L.setId(8L);
        klantsessie_888L.setControlePlaatsgevonden(false);
        klantsessie_888L.setActGebaseerdGehoudenKlantsessie(true);
        when(klantsessieServiceMock.getCurrentKlantsessie(888L)).thenReturn(klantsessie_888L);

        //Niet volledig
        //test completeness of uitkomst score + strategie + toelichtning
        Klantsessie klantsessie_444L = new Klantsessie(444L);
        klantsessie_444L.setId(4L);
        klantsessie_444L.setActGebaseerdGehoudenKlantsessie(false);
        klantsessie_444L.setToelichtingGehoudenKlantsessie("ToelichtingGehoudenKlantsessie aan");
        when(klantsessieServiceMock.getCurrentKlantsessie(444L)).thenReturn(klantsessie_444L);

        Klantsessie klantsessie_555L = new Klantsessie(555L);
        klantsessie_555L.setId(5L);
        klantsessie_555L.setActGebaseerdGehoudenKlantsessie(false);
        klantsessie_555L.setToelichtingGehoudenKlantsessie("ToelichtingGehoudenKlantsessie aan");
        when(klantsessieServiceMock.getCurrentKlantsessie(555L)).thenReturn(klantsessie_555L);

        Klantsessie klantsessie_666L = new Klantsessie(666L);
        klantsessie_666L.setId(6L);
        klantsessie_666L.setActGebaseerdGehoudenKlantsessie(false);
        klantsessie_666L.setToelichtingGehoudenKlantsessie("ToelichtingGehoudenKlantsessie aan");
        when(klantsessieServiceMock.getCurrentKlantsessie(666L)).thenReturn(klantsessie_666L);

        //Entiteitnummer_777L has Klantsessie with ActGebaseerdGehoudenKlantsessie aan and all steps are done but not all scores and toelichtingen KLANTSESSIE_UITKOMST are filled
        //Afgerond			Ja		Niet volledig	Nee
        Klantsessie klantsessie_777L = new Klantsessie(777L);
        klantsessie_777L.setId(7L);
        klantsessie_777L.setActGebaseerdGehoudenKlantsessie(true);
        when(klantsessieServiceMock.getCurrentKlantsessie(777L)).thenReturn(klantsessie_777L);
    }

    @BeforeEach
    void setUp() {
        stubCurrentKlantSessie();
        kenmerkRepository.saveAll(KENMERK_LIST);
        klantSessieUitkomstRepository.saveAll(KLANTSESSIE_UITKOMST);
        entiteitKenmerkRepository.saveAll(SELECTED_MIDDELEN_PER_ENTITEIT);
        klantsessieStatusRepository.saveAll(SELECTED_MIDDELEN_STATUS);
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideInputs")
    void checkKlantsessieAfrondenEnabled(String testCaseName, Long entiteitnummer, Boolean expected) {
        Boolean actual = cut.checkKlantsessieAfrondenEnabled(entiteitnummer);

        Assertions.assertEquals(expected, actual);
    }
    public static Stream<Arguments> provideInputs() {
        return Stream.of(
                Arguments.of(
                        "Given_Klantsessie_111L_With_ScoresStrategieEnToelichtingenVolledig_And_ActGebaseerdGehoudenKlantsessieOpJa_And_AllStepsAfgerond_ThenReturn_true",
                        111L,
                        true
                ),
                Arguments.of(
                        "Given_Klantsessie_333L_With_ScoresStrategieEnToelichtingenVolledig_And_ActGebaseerdGehoudenKlantsessieOpJa_And_NotAllStepsAfgerond_ThenReturn_false",
                        333L,
                        false
                ),
                Arguments.of(
                        "Given_Klantsessie_888L_With_ScoresStrategieEnToelichtingenVolledig_And_ActGebaseerdGehoudenKlantsessieOpJa_And_AllStepsAfgerondExceptControleWhenControleNietPlaatsgevonden_ThenReturn_true",
                        888L,
                        true
                ),
                //volledig uitkomst en gebaseerd op UIT
                Arguments.of(
                        "Given_Klantsessie_222L_With_ScoresStrategieEnToelichtingenVolledig_And_ActGebaseerdGehoudenKlantsessieOpNee_WellToelichtingGehoudenKlantsessie_ThenReturn_true",
                        222L,
                        true
                ),
                Arguments.of(
                        "Given_Klantsessie_223L_With_ScoresStrategieEnToelichtingenVolledig_And_ActGebaseerdGehoudenKlantsessieOpNee_WellToelichtingGehoudenKlantsessie_ButMiddelStepInitialThenReturn_false",
                        223L,
                        false
                ),
                Arguments.of(
                        "Given_Klantsessie_999L_With_ScoresStrategieEnToelichtingenVolledig_And_ActGebaseerdGehoudenKlantsessieOpNee_GeenToelichtingGehoudenKlantsessie_ThenReturn_false",
                        999L,
                        false
                ),
                //check volledig score toelichting strategie
                Arguments.of(
                        "Given_Klantsessie_444L_ActGebaseerdGehoudenKlantsessieOpNee_WellToelichtingGehoudenKlantsessie_With_ScoresStrategieEnToelichtingenNietVolledig_HasOneScoreIsNull_ThenReturn_false",
                        444L,
                        false
                ),
                Arguments.of(
                        "Given_Klantsessie_555L_ActGebaseerdGehoudenKlantsessieOpNee_WellToelichtingGehoudenKlantsessie_With_ScoresStrategieEnToelichtingenNietVolledig_HasOneStrategieGerichtOpIsNull_ThenReturn_false",
                        555L,
                        false
                ),

                Arguments.of(
                        "Given_Klantsessie_666L_ActGebaseerdGehoudenKlantsessieOpNee_WellToelichtingGehoudenKlantsessie_With_ScoresStrategieEnToelichtingenNietVolledig_HasOneToelichtingIsNull_ThenReturn_false",
                        666L,
                        false
                ),
                Arguments.of(
                        "Given_Klantsessie_777L_ActGebaseerdGehoudenKlantsessieOpJa_With_ScoresStrategieEnToelichtingenNietVolledig_HasMissingUitkomstEntries_ThenReturn_false",
                        777L,
                        false
                )
        );
    }

	@Test
	void updateKlantsessieAfgerond() {
        when(klantsessieServiceMock.getCurrentKlantsessie(any())).thenReturn(new Klantsessie(999L));
        var stubbedKs = new Klantsessie(999L);
        stubbedKs.setEinddatum(LocalDateTime.now());
        when(klantsessieServiceMock.save(any(), any())).thenReturn(stubbedKs);

        var klantsessie = cut.updateKlantsessieAfgerond(999L, TEST_LOGGING_ID_1);

        ArgumentCaptor<Klantsessie> argumentKs = ArgumentCaptor.forClass(Klantsessie.class);
        ArgumentCaptor<String> argumentLoggingId = ArgumentCaptor.forClass(String.class);
        verify(klantsessieServiceMock).save(argumentKs.capture(), argumentLoggingId.capture());

        Assertions.assertEquals(TEST_LOGGING_ID_1, argumentLoggingId.getValue());
        Assertions.assertNotNull(argumentKs.getValue().getEinddatum());
        Assertions.assertEquals(stubbedKs, klantsessie);
    }
}