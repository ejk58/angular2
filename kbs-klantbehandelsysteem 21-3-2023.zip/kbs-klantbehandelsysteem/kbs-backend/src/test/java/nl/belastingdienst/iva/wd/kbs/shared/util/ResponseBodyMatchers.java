package nl.belastingdienst.iva.wd.kbs.shared.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.springframework.test.web.servlet.ResultMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * Source: https://reflectoring.io/spring-boot-web-controller-test/#matching-json-output
 */
public class ResponseBodyMatchers {

	private final ObjectMapper objectMapper = new ObjectMapper();

	public ResponseBodyMatchers() {
		objectMapper.registerModule(new JavaTimeModule());
	}

	public <T> ResultMatcher containsObjectAsJson(Object expectedObject, Class<T> targetClass) {
		return mvcResult -> {
			String json = mvcResult.getResponse().getContentAsString();
			T actualObject;
			if(expectedObject instanceof List){
				actualObject = objectMapper.readerForListOf(targetClass).readValue(json);
			} else {
				actualObject = objectMapper.readValue(json, targetClass);
			}

			assertThat(actualObject).usingRecursiveComparison().isEqualTo(expectedObject);
		};
	}

	public static ResponseBodyMatchers responseBody() {
		return new ResponseBodyMatchers();
	}
}
