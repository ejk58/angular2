package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieZooefRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieZooef;
import nl.belastingdienst.iva.wd.kbs.klantsessie.service.status.CheckZooefService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieZooefRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieZooef;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
@ExtendWith(MockitoExtension.class)
class KlantsessieZooefServiceTest {

	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";
	@MockBean
	Logging2Service logging2ServiceMock;
	@MockBean
	KlantsessieService klantsessieService;
	@Autowired
	KlantsessieRepository klantsessieRepository;

	@Autowired
	KlantsessieZooefRepository klantsessieZooefRepository;
	@Autowired
	KlantsessieZooefService klantsessieZooefService;

	@MockBean
	CheckZooefService checkZooefService;
	@MockBean
	KlantsessieStatusService klantsessieStatusService;

	private static final LocalDateTime TEST_DATE_TIME = LocalDateTime.of(2022, 6, 1, 12, 55);
	private static final Long ENTITEITNUMMER= 888L;
	private static final String NIEUWE_INZICHTEN_OBSERVATIES = "nieuweInzichtenEnObservaties";
	private static final String VORIGE_NIEUWE_INZICHTEN_OBSERVATIES = "Vorige nieuweInzichtenEnObservaties";
	private static final String HUIDIGE_NIEUWE_INZICHTEN_OBSERVATIES = "Huidige nieuweInzichtenEnObservaties";
	private static final Integer MIDDEL_ID_12_WITH_RECORD = 12;
	private static final Integer MIDDEL_ID_13_WITH_RECORD = 13;
	private static final Integer MIDDEL_ID_114_WITHOUT_RECORD = 114;

	@BeforeEach
	void setUp() {
		setupKlantSessieZooef();
	}

	private void setupKlantSessieZooef() {
		klantsessieRepository.saveAll(
				List.of(
						new Klantsessie(1L, 888L, TEST_DATE_TIME.minusHours(2), TEST_DATE_TIME.minusHours(1),false,false,null, null								),
						new Klantsessie(2L, 888L, TEST_DATE_TIME, null,false,false,null, null)
						)
		);
		klantsessieZooefRepository.saveAll(
				List.of(
						new KlantsessieZooef(1L, 12, "Vorige nieuweInzichtenEnObservaties", false),
						new KlantsessieZooef(2L, 12, "Huidige nieuweInzichtenEnObservaties", false),
						new KlantsessieZooef(2L, 13, "Huidige nieuweInzichtenEnObservaties", true)
				)
		);
	}

	@Test
	void getHuidigeKlantsessieZooefObservatie() {
		when(klantsessieService.getCurrentKlantsessie(ENTITEITNUMMER)).thenReturn(
				new Klantsessie(2L, ENTITEITNUMMER, TEST_DATE_TIME, null,false,false,null, null)
		);

		KlantsessieZooef expectedOutput= new KlantsessieZooef(2L, MIDDEL_ID_114_WITHOUT_RECORD, null, false);
		KlantsessieZooef actual = this.klantsessieZooefService.getHuidigeKlantsessieZooefObservatie(ENTITEITNUMMER, MIDDEL_ID_114_WITHOUT_RECORD);
		Assertions.assertEquals(expectedOutput, actual);

		expectedOutput = new KlantsessieZooef(2L, MIDDEL_ID_12_WITH_RECORD, "Huidige nieuweInzichtenEnObservaties", false);
		actual = this.klantsessieZooefService.getHuidigeKlantsessieZooefObservatie(ENTITEITNUMMER, MIDDEL_ID_12_WITH_RECORD);
		Assertions.assertEquals(expectedOutput, actual);
	}

	@Test
	void updateNieuweInzichtenEnObservatiesWithExistingZooefRecord() {
		//Given
		when(klantsessieService.getCurrentKlantsessie(ENTITEITNUMMER)).thenReturn(
				new Klantsessie(2L, ENTITEITNUMMER, TEST_DATE_TIME, null,false,false,null, null)
		);
		//When
		KlantsessieZooef actual = klantsessieZooefService.updateNieuweInzichtenEnObservaties(ENTITEITNUMMER, MIDDEL_ID_12_WITH_RECORD, NIEUWE_INZICHTEN_OBSERVATIES,
				TEST_LOGGING_ID_1);
		//Then
		KlantsessieZooef expectedOutput = klantsessieZooefRepository.findByKlantsessieIdAndMiddelId(2L, MIDDEL_ID_12_WITH_RECORD)
				.orElseThrow(() -> new NoSuchElementException("Error"));
		Assertions.assertDoesNotThrow(() -> new NoSuchElementException("Error"));
		Assertions.assertEquals(expectedOutput.getObservaties(), actual.getObservaties());
		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, ENTITEITNUMMER, Logging2.Bewerking.UPDATE);
	}

	@Test
	void updateNieuweInzichtenEnObservatiesWithNonExistingZooefRecord() {
		//Given
		when(klantsessieService.getCurrentKlantsessie(ENTITEITNUMMER)).thenReturn(
				new Klantsessie(2L, ENTITEITNUMMER, TEST_DATE_TIME, null,false,false,null, null)
		);
		//When
		KlantsessieZooef actual = klantsessieZooefService.updateNieuweInzichtenEnObservaties(ENTITEITNUMMER,
				MIDDEL_ID_114_WITHOUT_RECORD, NIEUWE_INZICHTEN_OBSERVATIES, TEST_LOGGING_ID_1);
		//Then
		KlantsessieZooef expectedOutput = klantsessieZooefRepository.findByKlantsessieIdAndMiddelId(2L,
						MIDDEL_ID_114_WITHOUT_RECORD)
				.orElseThrow(() -> new NoSuchElementException("Error"));
		Assertions.assertDoesNotThrow(() -> new NoSuchElementException("Error"));
		Assertions.assertEquals(expectedOutput.getObservaties(), actual.getObservaties());
		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, ENTITEITNUMMER, Logging2.Bewerking.UPDATE);
	}

	@Test
	void updateObservatiesActueelTrue() {
		//Given
		when(klantsessieService.getCurrentKlantsessie(ENTITEITNUMMER)).thenReturn(
				new Klantsessie(2L, ENTITEITNUMMER, TEST_DATE_TIME, null,false,false,null, null)
		);
		Optional<Klantsessie> ks = Optional.of(
				new Klantsessie(1L, ENTITEITNUMMER, TEST_DATE_TIME.minusHours(2), TEST_DATE_TIME.minusHours(1),false,false,null,
						Map.of(MIDDEL_ID_12_WITH_RECORD,
								new KlantsessieZooef(1L, MIDDEL_ID_12_WITH_RECORD, VORIGE_NIEUWE_INZICHTEN_OBSERVATIES, false)
						)
				)
		);
		when(klantsessieService.getPreviousKlantsessie(ENTITEITNUMMER)).thenReturn(ks);

		//this is an extra check to make sure zooef has sertain values at the start of the test
		KlantsessieZooef zooef = klantsessieZooefRepository.findByKlantsessieIdAndMiddelId(2L, MIDDEL_ID_12_WITH_RECORD)
				.orElseThrow(() -> new NoSuchElementException("When Error"));
		Assertions.assertEquals(HUIDIGE_NIEUWE_INZICHTEN_OBSERVATIES, zooef.getObservaties());

		//When
		KlantsessieZooef actual = klantsessieZooefService.updateObservatiesActueel(ENTITEITNUMMER, MIDDEL_ID_12_WITH_RECORD, true, TEST_LOGGING_ID_1);

		//Then
		KlantsessieZooef expectedOutput = klantsessieZooefRepository.findByKlantsessieIdAndMiddelId(2L, MIDDEL_ID_12_WITH_RECORD)
				.orElseThrow(() -> new NoSuchElementException("Then Error"));
		Assertions.assertDoesNotThrow(() -> new NoSuchElementException("Then Error"));
		Assertions.assertEquals(expectedOutput.getVorigeObservatiesNogActueel(), actual.getVorigeObservatiesNogActueel());
		Assertions.assertEquals(true, actual.getVorigeObservatiesNogActueel());
		Assertions.assertEquals(expectedOutput.getObservaties(), actual.getObservaties());
		Assertions.assertEquals(VORIGE_NIEUWE_INZICHTEN_OBSERVATIES, actual.getObservaties());
		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, ENTITEITNUMMER, Logging2.Bewerking.UPDATE);
	}

	@Test
	void updateObservatiesActueelFalse(){
		//Given
		when(klantsessieService.getCurrentKlantsessie(ENTITEITNUMMER)).thenReturn(
				new Klantsessie(2L, ENTITEITNUMMER, TEST_DATE_TIME, null,false,false,null, null)
		);
		when(klantsessieService.getPreviousKlantsessie(ENTITEITNUMMER)).thenReturn(
				Optional.of(
						new Klantsessie(1L, ENTITEITNUMMER, TEST_DATE_TIME.minusHours(2), TEST_DATE_TIME.minusHours(1),false,false,null, null)
				)
		);

		//this is an extra check to make sure zooef has sertain values at the start of the test
		KlantsessieZooef zooef = klantsessieZooefRepository.findByKlantsessieIdAndMiddelId(2L, MIDDEL_ID_13_WITH_RECORD)
				.orElseThrow(() -> new NoSuchElementException("When Error"));
		Assertions.assertEquals(HUIDIGE_NIEUWE_INZICHTEN_OBSERVATIES, zooef.getObservaties());

		//When
		KlantsessieZooef actual = klantsessieZooefService.updateObservatiesActueel(ENTITEITNUMMER, MIDDEL_ID_13_WITH_RECORD, false, TEST_LOGGING_ID_1);

		//Then
		KlantsessieZooef expectedOutput = klantsessieZooefRepository.findByKlantsessieIdAndMiddelId(2L, MIDDEL_ID_13_WITH_RECORD)
				.orElseThrow(() -> new NoSuchElementException("Then Error"));
		Assertions.assertDoesNotThrow(() -> new NoSuchElementException("Then Error"));
		Assertions.assertEquals(expectedOutput.getVorigeObservatiesNogActueel(), actual.getVorigeObservatiesNogActueel());
		Assertions.assertEquals(false, actual.getVorigeObservatiesNogActueel());
		Assertions.assertEquals(expectedOutput.getObservaties(), actual.getObservaties());
		Assertions.assertNull(actual.getObservaties());
		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, ENTITEITNUMMER, Logging2.Bewerking.UPDATE);
	}
}
