package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import nl.belastingdienst.iva.wd.kbs.domain.businessrule.BusinessRuleError;
import nl.belastingdienst.iva.wd.kbs.exception.BusinessRuleException;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.businessrules.middelspecifiekekenmerken.DuplicatePolicy;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootKbsTest
class SaveNewEntiteitMiddelRisicoListServiceTest {

	public static final List<EntiteitMiddelRisico> ENTITEIT_MIDDEL_RISICO_LIST = List.of(
			new EntiteitMiddelRisico(1L, 999L, 10L, 1L, null, (short) 1, 96L, 1, null),
			new EntiteitMiddelRisico(2L, 999L, 11L, 1L, null, (short) 1, 96L, 1,null)
	);
	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";

	@Autowired
	SaveNewEntiteitMiddelRisicoListService sut;

	@Autowired
	EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;
	@MockBean
	Logging2Service logging2ServiceMock;
	@MockBean
	BusinessRulesMiddelSpecifiekeRisicosService businessRulesMiddelSpecifiekeRisicosServiceMock;

	@Test
	void whenOptionalBusinessRule_ThenExpectException() {
		when(businessRulesMiddelSpecifiekeRisicosServiceMock.validateList(any(), any()))
				.thenReturn(
						Optional.of(new BusinessRuleError("test", DuplicatePolicy.class))
		);

		Assertions.assertThrows(
				BusinessRuleException.class, () -> this.sut.save(ENTITEIT_MIDDEL_RISICO_LIST,
						999L,
						"loggingId1"
				)
		);
	}

	@Test
	void whenOptionalEmpty_ThenSave() {
		when(businessRulesMiddelSpecifiekeRisicosServiceMock.validateList(any(), any()))
				.thenReturn(
						Optional.empty()
				);

		this.sut.save(ENTITEIT_MIDDEL_RISICO_LIST,999L, TEST_LOGGING_ID_1);
		List<EntiteitMiddelRisico> actual = this.entiteitMiddelRisicoRepository.findAll();
		Assertions.assertEquals(ENTITEIT_MIDDEL_RISICO_LIST, actual);
		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, 999L, Logging2.Bewerking.INSERT, ENTITEIT_MIDDEL_RISICO_LIST.size());
	}

}
