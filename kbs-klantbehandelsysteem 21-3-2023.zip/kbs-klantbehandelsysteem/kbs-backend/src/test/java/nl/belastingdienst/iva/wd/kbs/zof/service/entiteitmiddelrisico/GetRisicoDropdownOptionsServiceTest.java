package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.service.KenmerkService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
@SpringBootKbsTest
class GetRisicoDropdownOptionsServiceTest {
    @Autowired
    KenmerkService kenmerkService;
    @Autowired
    KenmerkRepository kenmerkRepository;
    @Autowired
    GetRisicoDropdownOptionsService cut;

    @BeforeEach
    void setUp() {
        this.kenmerkRepository.saveAll(List.of(
                new Kenmerk(1, "RSTAT", "RSTAT 1", null),
                new Kenmerk(2, "RSTAT", "RSTAT 2", null),
                new Kenmerk(3, "RSTAT", "RSTAT 3", null),
                new Kenmerk(4, "RBEH", "RBEH 1", null),
                new Kenmerk(5, "RBEH", "RBEH 2", null)
        ));
    }

    @Test
    void getZoFMiddelRisicoStatussen() {
        List<Kenmerk> expected = List.of(
                new Kenmerk(1, "RSTAT", "RSTAT 1", null),
                new Kenmerk(2, "RSTAT", "RSTAT 2", null),
                new Kenmerk(3, "RSTAT", "RSTAT 3", null)
        );
        List<Kenmerk> actual = cut.getZoFMiddelRisicoStatussen();
        Assertions.assertEquals(expected, actual);
        Assertions.assertEquals(expected.size(), actual.size());
    }

    @Test
    void getZoFMiddelRisicoBeheersingOptions() {
        List<Kenmerk> expected = List.of(
                new Kenmerk(4, "RBEH", "RBEH 1", null),
                new Kenmerk(5, "RBEH", "RBEH 2", null)
        );
        List<Kenmerk> actual = cut.getZoFMiddelRisicoBeheersingOptions();
        Assertions.assertEquals(expected, actual);
        Assertions.assertEquals(expected.size(), actual.size());
    }
}