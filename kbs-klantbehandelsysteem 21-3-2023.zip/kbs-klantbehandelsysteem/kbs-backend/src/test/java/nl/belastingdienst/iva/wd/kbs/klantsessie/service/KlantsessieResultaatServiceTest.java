package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import nl.belastingdienst.iva.wd.kbs.dao.EntiteitKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.EntiteitKenmerkId;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieComplianceRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantSessieUitkomstRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkChild;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KenmerkParent;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieCompliance;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieResultaatDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieResultaatEntryDto;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieUitkomst;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
class KlantsessieResultaatServiceTest {
    @MockBean
    private KlantsessieService klantsessieService;
    @Autowired
    private KlantSessieComplianceRepository klantSessieComplianceRepository;
    @Autowired
    private KlantsessieRepository klantsessieRepository;
    @Autowired
    private KlantSessieUitkomstRepository klantSessieUitkomstRepository;
    @Autowired
    private KenmerkRepository kenmerkRepository;
    @Autowired
    EntiteitKenmerkRepository entiteitKenmerkRepository;
    @Autowired
    KlantsessieResultaatService cut;

    private static final LocalDateTime testDateTime = LocalDateTime.of(2022, 6, 1, 12, 55);
    private static final Kenmerk PARENT_KENMERK_1 = new Kenmerk(1, "KS_CAT", "Parent 1", null);
    private static final Kenmerk PARENT_KENMERK_2 = new Kenmerk(2, "KS_CAT", "Parent 2", null);
    private static final Kenmerk CHILD_KENMERK_1_A = new Kenmerk(10, "KS_CAT", "Child parent 1a", 1);
    private static final Kenmerk CHILD_KENMERK_1_B = new Kenmerk(11, "KS_CAT", "Child parent 1b", 1);
    private static final Kenmerk CHILD_KENMERK_2_A = new Kenmerk(20, "KS_CAT", "Child parent 2a", 2);
    private static final Kenmerk CHILD_KENMERK_2_B = new Kenmerk(21, "KS_CAT", "Child parent 2b", 2);
    private static final List<Kenmerk> KENMERK_LIST = List.of(PARENT_KENMERK_1, PARENT_KENMERK_2, CHILD_KENMERK_1_A, CHILD_KENMERK_1_B, CHILD_KENMERK_2_A, CHILD_KENMERK_2_B);

    private static final Kenmerk MIDDEL_12 = new Kenmerk(12, "MID", "selectedMiddel_12", null);
    private static final Kenmerk MIDDEL_13 = new Kenmerk(13, "MID", "selectedMiddel_13", null);
    private static final Kenmerk MIDDEL_24 = new Kenmerk(24, "MID", "selectedMiddel_24_without_compliances", null);
    private static final Kenmerk MIDDEL_141 = new Kenmerk(141, "KS_MID", "controle", null);
    private static final Kenmerk MIDDEL_142 = new Kenmerk(142, "KS_MID", "klantsessieCoodinator", null);
    private static final List<Kenmerk> MIDDELEN_LIST = List.of(MIDDEL_12, MIDDEL_13, MIDDEL_24, MIDDEL_141, MIDDEL_142);

    private static final List<KenmerkParent> HIERARCHY_PARENTS_CHILD_KENMERKEN = List.of(
            new KenmerkParent(
                    PARENT_KENMERK_1,
                    List.of(
                            new KenmerkChild(CHILD_KENMERK_1_A, null, null),
                            new KenmerkChild(CHILD_KENMERK_1_B, null, null)
                    )),
            new KenmerkParent(
                    PARENT_KENMERK_2,
                    List.of(
                            new KenmerkChild(CHILD_KENMERK_2_A, null, null),
                            new KenmerkChild(CHILD_KENMERK_2_B, null, null)
                    ))
    );

    private static final List<Klantsessie> KLANTSESSIE_LIST = List.of(
            //Entiteitnummer 111L with 4 vorige Klantsessies and has selected middelen and huidige klantsessie
            new Klantsessie(1L, 111L, testDateTime.minusMinutes(19), testDateTime.minusMinutes(10), false, false, null, null),
            new Klantsessie(2L, 111L, testDateTime.minusHours(1), testDateTime.minusMinutes(20), false, false, null, null),
            new Klantsessie(3L, 111L, testDateTime.minusHours(2), testDateTime.minusHours(1), false, false, null, null),
            new Klantsessie(4L, 111L, testDateTime.minusHours(3), testDateTime.minusHours(2), false, false, null, null),
            new Klantsessie(5L, 111L, testDateTime, null, false, false, null, null),

            //Entiteitnummer 222L with 1 vorige Klantsessie and 1 selected middel and huidige klantsessie has ControlePlaatsgevonden == false but has compliances
            new Klantsessie(6L, 222L, testDateTime.minusMinutes(19), testDateTime.minusMinutes(10), false, false, null, null),
            new Klantsessie(7L, 222L, testDateTime, null, false, false, null, null),

            //Entiteitnummer 333L with no vorige Klantsessie and and no selected  middelen and huidige klantsessie has ControlePlaatsgevonden == false and kscoordinator has compliances(should show only kscoordinator data)
            new Klantsessie(8L, 333L, testDateTime, null, false, false, null, null),

            //Entiteitnummer 444L with 1 vorige Klantsessie and no selected middelen and huidige klantsessie has ControlePlaatsgevonden == true but controle and kscoordinator have no compliances(should show empty controle and empty kscoordinator)
            new Klantsessie(9L, 444L, testDateTime.minusMinutes(19), testDateTime.minusMinutes(10), false, false, null, null),
            new Klantsessie(10L, 444L, testDateTime, null, true, false, null, null),

            //Entiteitnummer 555L with no vorige Klantsessie and no selected  middelen and huidige klantsessie has ControlePlaatsgevonden == true and controle has compliances
            new Klantsessie(11L, 555L, testDateTime, null, true, false, null, null)
    );

    private static final List<KlantsessieCompliance> KLANTSESSIE_COMPLIANCES = List.of(
            //klantsessie 5 with selected middelen 12, 13, klantsessiecoordinator
            new KlantsessieCompliance(5L, 12, CHILD_KENMERK_1_A.getId(), 1, "Toelichting 1 " + CHILD_KENMERK_1_A, CHILD_KENMERK_1_A),
            new KlantsessieCompliance(5L, 12, CHILD_KENMERK_1_B.getId(), 2, "Toelichting 2 " + CHILD_KENMERK_1_B, CHILD_KENMERK_1_B),
            new KlantsessieCompliance(5L, 12, CHILD_KENMERK_2_A.getId(), 3, "Toelichting 3 " + CHILD_KENMERK_2_A, CHILD_KENMERK_2_A),
            new KlantsessieCompliance(5L, 13, CHILD_KENMERK_2_B.getId(), 0, "Toelichting 4 " + CHILD_KENMERK_2_B, CHILD_KENMERK_2_B),
            new KlantsessieCompliance(5L, 13, CHILD_KENMERK_1_A.getId(), 4, "Toelichting a " + CHILD_KENMERK_1_A, CHILD_KENMERK_1_A),
            new KlantsessieCompliance(5L, 142, CHILD_KENMERK_1_B.getId(), 4, "Toelichting bb " + CHILD_KENMERK_1_B, CHILD_KENMERK_1_B),
            new KlantsessieCompliance(5L, 142, CHILD_KENMERK_2_A.getId(), 3, "Toelichting cc " + CHILD_KENMERK_2_A, CHILD_KENMERK_2_A),
            //klantsessie 7 with 1 selected middel 12, controle with false and klantsessiecoordinator
            new KlantsessieCompliance(7L, 12, CHILD_KENMERK_1_A.getId(), 1, "Toelichting 1 " + CHILD_KENMERK_1_A, CHILD_KENMERK_1_A),
            new KlantsessieCompliance(7L, 141, CHILD_KENMERK_2_B.getId(), 2, "Toelichting dd " + CHILD_KENMERK_2_B, CHILD_KENMERK_2_B),
            new KlantsessieCompliance(7L, 142, CHILD_KENMERK_1_B.getId(), 4, "Toelichting bb " + CHILD_KENMERK_1_B, CHILD_KENMERK_1_B),
            //klantsessie 8 with klantsessiecoordinator and no selected middellen, no compliances for controle
            new KlantsessieCompliance(8L, 142, CHILD_KENMERK_1_B.getId(), 4, "Toelichting bb " + CHILD_KENMERK_1_B, CHILD_KENMERK_1_B),
            new KlantsessieCompliance(8L, 142, CHILD_KENMERK_2_A.getId(), 3, "Toelichting cc " + CHILD_KENMERK_2_A, CHILD_KENMERK_2_A),
            //klantsessie 11 with controller that has compliances and no selected middellen
            new KlantsessieCompliance(11L, 141, CHILD_KENMERK_1_B.getId(), 3, "Toelichting b " + CHILD_KENMERK_1_B, CHILD_KENMERK_1_B),
            new KlantsessieCompliance(11L, 141, CHILD_KENMERK_2_A.getId(), 2, "Toelichting c " + CHILD_KENMERK_2_A, CHILD_KENMERK_2_A)
    );

    private static final List<KlantsessieUitkomst> KLANTSESSIE_UITKOMST = List.of(
            // Entiteitnummer 111L with 4 Klantsessies
            new KlantsessieUitkomst(1L, CHILD_KENMERK_1_A.getId(), 3, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(1L, CHILD_KENMERK_1_B.getId(), 4, 2, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(1L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId()),
            new KlantsessieUitkomst(1L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(2L, CHILD_KENMERK_1_A.getId(), 3, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(2L, CHILD_KENMERK_1_B.getId(), 4, 2, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(2L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId()),
            new KlantsessieUitkomst(2L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(3L, CHILD_KENMERK_1_A.getId(), 3, 1, "toelichting_" + CHILD_KENMERK_1_A.getId()),
            new KlantsessieUitkomst(3L, CHILD_KENMERK_1_B.getId(), 4, 2, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(3L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId()),
            new KlantsessieUitkomst(3L, CHILD_KENMERK_2_B.getId(), 0, 3, "toelichting_" + CHILD_KENMERK_2_B.getId()),

            new KlantsessieUitkomst(4L, CHILD_KENMERK_1_B.getId(), 4, 2, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(4L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId()),

            //Entiteitnummer 222L with 1 vorige Klantsessie
            new KlantsessieUitkomst(6L, CHILD_KENMERK_1_B.getId(), 4, 2, "toelichting_" + CHILD_KENMERK_1_B.getId()),
            new KlantsessieUitkomst(6L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId()),

            //Entiteitnummer 444L with 1 vorige Klantsessie
            new KlantsessieUitkomst(9L, CHILD_KENMERK_2_A.getId(), 5, 2, "toelichting_" + CHILD_KENMERK_2_A.getId())
    );

    private static final List<EntiteitKenmerk> SELECTED_MIDDELEN_PER_ENTITEIT = List.of(
            //Entiteitnummer 111L with 3 selected middelen 12,13,24 but middel 24 has no compliances
            new EntiteitKenmerk(new EntiteitKenmerkId(111L, "MID", 12), null),
            new EntiteitKenmerk(new EntiteitKenmerkId(111L, "MID", 13), null),

            //Entiteitnummer 222L with 1 selected middelen 12 that has compliances
            new EntiteitKenmerk(new EntiteitKenmerkId(222L, "MID", 12), null)
    );

    @BeforeEach
    void setUp() {
        kenmerkRepository.saveAll(KENMERK_LIST);
        kenmerkRepository.saveAll(MIDDELEN_LIST);
        klantsessieRepository.saveAll(KLANTSESSIE_LIST);
        klantSessieComplianceRepository.saveAll(KLANTSESSIE_COMPLIANCES);
        klantSessieUitkomstRepository.saveAll(KLANTSESSIE_UITKOMST);
        entiteitKenmerkRepository.saveAll(SELECTED_MIDDELEN_PER_ENTITEIT);
        stubCurrentKlantSessies();
    }

    private void stubCurrentKlantSessies() {
        Klantsessie currentKlantsessie_5L = klantsessieRepository.findById(5L).orElse(null);
        when(klantsessieService.getCurrentKlantsessie(111L)).thenReturn(currentKlantsessie_5L);

        Klantsessie currentKlantsessie_7L = klantsessieRepository.findById(7L).orElse(null);
        when(klantsessieService.getCurrentKlantsessie(222L)).thenReturn(currentKlantsessie_7L);

        Klantsessie currentKlantsessie_8L = klantsessieRepository.findById(8L).orElse(null);
        when(klantsessieService.getCurrentKlantsessie(333L)).thenReturn(currentKlantsessie_8L);

        Klantsessie currentKlantsessie_10L = klantsessieRepository.findById(10L).orElse(null);
        when(klantsessieService.getCurrentKlantsessie(444L)).thenReturn(currentKlantsessie_10L);

        Klantsessie currentKlantsessie_11L = klantsessieRepository.findById(11L).orElse(null);
        when(klantsessieService.getCurrentKlantsessie(555L)).thenReturn(currentKlantsessie_11L);

        when(klantsessieService.getLastThreePreviousKlantsessie(ArgumentMatchers.any()))
                .thenAnswer(invocationOnMock -> klantsessieRepository.findFirst3ByEntiteitNummerAndEinddatumIsNotNullOrderByEinddatumDesc(invocationOnMock.getArgument(0)));
    }

    @ParameterizedTest(name = "[{index}] {0}")
    @MethodSource("provideInputs")
    void getKlantsessieResultaat(String testCaseName, Long entiteitnummer, KlantsessieResultaatDto expectedOutput) {
        KlantsessieResultaatDto actual = this.cut.getKlantsessieResultaat(entiteitnummer);
        Assertions.assertEquals(expectedOutput, actual);
    }

    public static Stream<Arguments> provideInputs() {
        //Entiteitnummer 111L with 4 vorige Klantsessies and 2 selected middelen but KScoordinator shows by default
        List<KlantsessieResultaatEntryDto> expectedPreviousEntries_111L = List.of(
                new KlantsessieResultaatEntryDto(3L, testDateTime.minusHours(1), null,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, 3, "toelichting_" + CHILD_KENMERK_1_A.getId()),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 4, "toelichting_" + CHILD_KENMERK_1_B.getId()),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 5, "toelichting_" + CHILD_KENMERK_2_A.getId()),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, 0, "toelichting_" + CHILD_KENMERK_2_B.getId()))
                ),
                new KlantsessieResultaatEntryDto(2L, testDateTime.minusMinutes(20), null,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, 3, "toelichting_" + CHILD_KENMERK_1_A.getId()),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 4, "toelichting_" + CHILD_KENMERK_1_B.getId()),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 5, "toelichting_" + CHILD_KENMERK_2_A.getId()),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, 0, "toelichting_" + CHILD_KENMERK_2_B.getId()))
                ),
                new KlantsessieResultaatEntryDto(1L, testDateTime.minusMinutes(10), null,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, 3, "toelichting_" + CHILD_KENMERK_1_A.getId()),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 4, "toelichting_" + CHILD_KENMERK_1_B.getId()),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 5, "toelichting_" + CHILD_KENMERK_2_A.getId()),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, 0, "toelichting_" + CHILD_KENMERK_2_B.getId()))
                )
                );

        List<KlantsessieResultaatEntryDto> expectedCurrentEntries_111L = List.of(
                new KlantsessieResultaatEntryDto(5L, null, MIDDEL_12,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, 1, "Toelichting 1 " + CHILD_KENMERK_1_A),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 2, "Toelichting 2 " + CHILD_KENMERK_1_B),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 3, "Toelichting 3 " + CHILD_KENMERK_2_A),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                ),
                new KlantsessieResultaatEntryDto(5L, null, MIDDEL_13,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, 4, "Toelichting a " + CHILD_KENMERK_1_A),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, null, null),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, null, null),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, 0, "Toelichting 4 " + CHILD_KENMERK_2_B))
                ),
                new KlantsessieResultaatEntryDto(5L, null, MIDDEL_142,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 4, "Toelichting bb " + CHILD_KENMERK_1_B),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 3, "Toelichting cc " + CHILD_KENMERK_2_A),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                ));

        //Entiteitnummer 222L with 1 vorige Klantsessie and 1 selected middel and huidige klantsessie has controle with compliances but ControlePlaatsgevonden == false
        List<KlantsessieResultaatEntryDto> expectedPreviousEntries_222L = List.of(
                new KlantsessieResultaatEntryDto(6L, testDateTime.minusMinutes(10), null,
                        Map.of(CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 4, "toelichting_" + CHILD_KENMERK_1_B.getId()),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 5, "toelichting_" + CHILD_KENMERK_2_A.getId()),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null),
                                CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null))
                )
        );
        List<KlantsessieResultaatEntryDto> expectedCurrentEntries_222L = List.of(
                new KlantsessieResultaatEntryDto(7L, null, MIDDEL_12,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, 1, "Toelichting 1 " + CHILD_KENMERK_1_A),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, null, null),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, null, null),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                ),
                new KlantsessieResultaatEntryDto(7L, null, MIDDEL_142,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 4, "Toelichting bb " + CHILD_KENMERK_1_B),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, null, null),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                ));

        //Entiteitnummer 333L with no vorige Klantsessie and and no selected middelen and huidige klantsessie has ControlePlaatsgevonden == false and kscoordinator has compliances(should show only kscoordinator data)
        List<KlantsessieResultaatEntryDto> expectedCurrentEntries_333L = List.of(
                new KlantsessieResultaatEntryDto(8L, null, MIDDEL_142,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 4, "Toelichting bb " + CHILD_KENMERK_1_B),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 3, "Toelichting cc " + CHILD_KENMERK_2_A),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                )
        );
        //Entiteitnummer 444L with 1 vorige Klantsessie and no selected middelen and huidige klantsessie has ControlePlaatsgevonden == true but controle and kscoordinator have no compliances(should show empty controle and empty kscoordinator)
        List<KlantsessieResultaatEntryDto> expectedPreviousEntries_444L = List.of(
                new KlantsessieResultaatEntryDto(9L, testDateTime.minusMinutes(10), null,
                        Map.of(CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, null, null),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 5, "toelichting_" + CHILD_KENMERK_2_A.getId()),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null),
                                CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null))
                )
        );
        List<KlantsessieResultaatEntryDto> expectedCurrentEntries_444L = List.of(
                new KlantsessieResultaatEntryDto(10L, null, MIDDEL_141,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, null, null),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, null, null),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                ),
                new KlantsessieResultaatEntryDto(10L, null, MIDDEL_142,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, null, null),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, null, null),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                )
        );

        //Entiteitnummer 555L with no vorige Klantsessie and no selected  middelen and huidige klantsessie has ControlePlaatsgevonden == true and controle has compliances
        List<KlantsessieResultaatEntryDto> expectedCurrentEntries_555L = List.of(
                new KlantsessieResultaatEntryDto(11L, null, MIDDEL_141,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, 3, "Toelichting b " + CHILD_KENMERK_1_B),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, 2, "Toelichting c " + CHILD_KENMERK_2_A),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                ),
                new KlantsessieResultaatEntryDto(11L, null, MIDDEL_142,
                        Map.of(CHILD_KENMERK_1_A.getId(), new KenmerkChild(CHILD_KENMERK_1_A, null, null),
                                CHILD_KENMERK_1_B.getId(), new KenmerkChild(CHILD_KENMERK_1_B, null, null),
                                CHILD_KENMERK_2_A.getId(), new KenmerkChild(CHILD_KENMERK_2_A, null, null),
                                CHILD_KENMERK_2_B.getId(), new KenmerkChild(CHILD_KENMERK_2_B, null, null))
                )
        );

        return Stream.of(
                Arguments.of(
                        "Given_Entiteit-111L_With4PreviousKlantsessies_With2SelectedMid_ThenReturnDatafor_OnlyLast3KS_2SelectedMid_And_KScoordinator",
                        111L,
                        new KlantsessieResultaatDto(HIERARCHY_PARENTS_CHILD_KENMERKEN, expectedPreviousEntries_111L, expectedCurrentEntries_111L)
                ),
                Arguments.of(
                        "Given_Entiteit-222L_With1PreviousKS_With1SelectedMid_WithControleFalseButHasCompliances_ThenReturnDatafor_OnlyLast1KS_1Mid_And_KScoordinator",
                        222L,
                        new KlantsessieResultaatDto(HIERARCHY_PARENTS_CHILD_KENMERKEN, expectedPreviousEntries_222L, expectedCurrentEntries_222L)
                ),
                Arguments.of(
                        "Given_Entiteit-333L_WithNoPreviousKS_WithNoSelectedMid_WithControleFalse_ThenReturnDatafor_OnlyKScoordinator",
                        333L,
                        new KlantsessieResultaatDto(HIERARCHY_PARENTS_CHILD_KENMERKEN, List.of(), expectedCurrentEntries_333L)
                ),
                Arguments.of(
                        "Given_Entiteit-444L_With1PreviousKS_WithNoSelectedMid_WithControleTrue_ButControleAndKScoordinatorHaveNoCompliances_ThenReturnDatafor_OnlyLast1KS_And_EmptyControleAndKScoordinator",
                        444L,
                        new KlantsessieResultaatDto(HIERARCHY_PARENTS_CHILD_KENMERKEN, expectedPreviousEntries_444L, expectedCurrentEntries_444L)
                ),
                Arguments.of(
                        "Given_Entiteit-555L_WithNoPreviousKS_WithNoSelectedMid_WithControleTrue_AndControleHasCompliances_ThenReturnDatafor_Controle_And_EmptyKScoordinator",
                        555L,
                        new KlantsessieResultaatDto(HIERARCHY_PARENTS_CHILD_KENMERKEN, List.of(), expectedCurrentEntries_555L)
                )
        );
    }
}