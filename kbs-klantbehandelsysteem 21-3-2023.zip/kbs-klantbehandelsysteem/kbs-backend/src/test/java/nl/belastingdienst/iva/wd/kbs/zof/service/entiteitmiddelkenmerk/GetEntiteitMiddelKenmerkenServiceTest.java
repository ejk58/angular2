package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelkenmerk;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;

import nl.belastingdienst.iva.wd.kbs.dao.MiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelKenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerk;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelKenmerkDto;
import nl.belastingdienst.iva.wd.kbs.zof.mappings.EntiteitMiddelKenmerkMapper;

@SpringBootKbsTest
@ComponentScan(basePackageClasses = { EntiteitMiddelKenmerkMapper.class})
class GetEntiteitMiddelKenmerkenServiceTest {

	@Autowired
	GetEntiteitMiddelKenmerkenService sut;

	@Autowired
	EntiteitMiddelKenmerkRepository entiteitMiddelKenmerkRepository;
	@Autowired
	MiddelKenmerkRepository middelKenmerkRepository;

	@BeforeEach
	void setUp() {
		this.middelKenmerkRepository.saveAll(
			List.of(
				new MiddelKenmerk(1L, 12, "vpb 1", null),
				new MiddelKenmerk(2L, 12, "vpb 2", null),
				new MiddelKenmerk(3L, 24, "div 1", null),
				new MiddelKenmerk(4L, 24, "div 2", null)
			)
		);

		this.entiteitMiddelKenmerkRepository.saveAll(
			List.of(
				new EntiteitMiddelKenmerk(1L, 1L, null, null, null, 2L, 111L),
				new EntiteitMiddelKenmerk(2L, 2L, null, null, null, 3L, 111L),
				new EntiteitMiddelKenmerk(3L, 3L, null, null, null, 3L, 999L),
				new EntiteitMiddelKenmerk(4L, 4L, null, null, null, 1L, 111L)
			)
		);
	}

	@Test
	void givenEntiteitWithMultipleEntiteitMiddelKenmerkenMultipleMiddel_WhenGet_ThenOnlyReturnFromGivenMiddel() {
		var actualDtoList = this.sut.getEntiteitMiddelKenmerken(111L, 12);
		var expectedDtoList = List.of(
				new EntiteitMiddelKenmerkDto(
						1L, 1L, null, null, null, 2L, 111L, false
				),
				new EntiteitMiddelKenmerkDto(
						2L, 2L, null, null, null, 3L, 111L, false
				)
		);
		Assertions.assertEquals(expectedDtoList, actualDtoList);
	}

	@Test
	void givenEntiteitWithNoEntiteitMiddelKenmerkenForMiddel_WhenGet_ThenReturnEmptyList() {
		var actualDtoList = this.sut.getEntiteitMiddelKenmerken(999L, 12);
		var expectedDtoList = List.of();
		Assertions.assertEquals(expectedDtoList, actualDtoList);
	}
}