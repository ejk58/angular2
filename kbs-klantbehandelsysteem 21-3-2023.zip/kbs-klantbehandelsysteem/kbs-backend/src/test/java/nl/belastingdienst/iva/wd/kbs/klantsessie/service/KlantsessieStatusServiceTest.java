package nl.belastingdienst.iva.wd.kbs.klantsessie.service;

import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

import nl.belastingdienst.iva.wd.kbs.klantsessie.dao.KlantsessieStatusRepository;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.CheckStatusInterface;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.Klantsessie;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.KlantsessieStatus;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepEnum;
import nl.belastingdienst.iva.wd.kbs.klantsessie.domain.StepStatusEnum;
import nl.belastingdienst.iva.wd.kbs.logging.domain.Logging2;
import nl.belastingdienst.iva.wd.kbs.logging.service.Logging2Service;
import nl.belastingdienst.iva.wd.kbs.logging.utils.LoggingArgumentAssertion;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;

@SpringBootKbsTest
@ExtendWith(MockitoExtension.class)
class KlantsessieStatusServiceTest {
	public static final String TEST_LOGGING_ID_1 = "testLoggingId1";
	@MockBean
	Logging2Service logging2ServiceMock;

	@Autowired
	private KlantsessieStatusService klantsessieStatusService;
	@Autowired
	private KlantsessieStatusRepository klantsessieStatusRepository;
	@MockBean
	KlantsessieService klantsessieServiceMock;

	@BeforeEach
	void setUp() {
		prepareStatusRepository();
		stubCurrentKlantSessies();
	}

	private void stubCheckServiceMap() {
		Map<StepEnum, CheckStatusInterface> mockedMap = Map.of(
				StepEnum.ZOOEF,
				new CheckStatusInterface() {
					@Override
					public StepStatusEnum check(Long klantsessieId, Integer middelId) {
						if(klantsessieId == 1L){
							return StepStatusEnum.INITIAL;
						}
						return StepStatusEnum.COMPLETED;
					}

					@Override
					public StepEnum getStepEnum() {
						return StepEnum.ZOOEF;
					}
				},
				StepEnum.COMPLIANCE,
				new CheckStatusInterface() {
					@Override
					public StepStatusEnum check(Long klantsessieId, Integer middelId) {
						if(klantsessieId == 1L){
							return StepStatusEnum.INITIAL;
						}
						if(klantsessieId == 3L){
							return StepStatusEnum.COMPLETED;
						}
						return StepStatusEnum.TOUCHED;
					}

					@Override
					public StepEnum getStepEnum() {
						return StepEnum.COMPLIANCE;
					}
				},
				StepEnum.STRATEGIE,
				new CheckStatusInterface() {
					@Override
					public StepStatusEnum check(Long klantsessieId, Integer middelId) {
						if(klantsessieId == 1L){
							return StepStatusEnum.INITIAL;
						}
						if(klantsessieId == 3L){
							return StepStatusEnum.COMPLETED;
						}
						return StepStatusEnum.TOUCHED;
					}

					@Override
					public StepEnum getStepEnum() {
						return StepEnum.STRATEGIE;
					}
				}
		);
		ReflectionTestUtils.setField(klantsessieStatusService, "checkServiceMap", mockedMap);
	}

	private void prepareStatusRepository(){
		klantsessieStatusRepository.saveAll(
				List.of(
						new KlantsessieStatus(1L, 12, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, false),
						new KlantsessieStatus(1L, Klantsessie.CONTROLE_MIDDEL_ID, StepStatusEnum.INITIAL, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, false),
						new KlantsessieStatus(2L, 12, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, false),
						new KlantsessieStatus(2L, Klantsessie.CONTROLE_MIDDEL_ID, StepStatusEnum.COMPLETED, StepStatusEnum.TOUCHED, StepStatusEnum.TOUCHED, StepStatusEnum.INITIAL, false),
						new KlantsessieStatus(3L, 12, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true),
						new KlantsessieStatus(3L, Klantsessie.CONTROLE_MIDDEL_ID, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true)
				)
		);
	}

	private void stubCurrentKlantSessies() {
		Klantsessie klantsessie888 = new Klantsessie(888L);
		klantsessie888.setId(1L);
		Klantsessie klantsessie999 = new Klantsessie(999L);
		klantsessie999.setId(2L);
		Klantsessie klantsessie777 = new Klantsessie(777L);
		klantsessie777.setId(3L);
		Klantsessie klantsessie666 = new Klantsessie(666L);
		klantsessie666.setId(4L);

		when(klantsessieServiceMock.getCurrentKlantsessie(888L)).thenReturn(klantsessie888);
		when(klantsessieServiceMock.getCurrentKlantsessie(999L)).thenReturn(klantsessie999);
		when(klantsessieServiceMock.getCurrentKlantsessie(777L)).thenReturn(klantsessie777);
		when(klantsessieServiceMock.getCurrentKlantsessie(666L)).thenReturn(klantsessie666);
	}


	@Test
	void getCurrentKlantsessieStatus() {
		//exists in repo
		KlantsessieStatus expectedOutput = new KlantsessieStatus(1L, 12, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, false);
		KlantsessieStatus actual = klantsessieStatusService.getCurrentKlantsessieStatus(888L, 12);
		Assertions.assertEquals(expectedOutput, actual);

		//does not exist in repo
		expectedOutput = new KlantsessieStatus(2L, 24, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, false);
		actual = klantsessieStatusService.getCurrentKlantsessieStatus(999L, 24);
		Assertions.assertEquals(expectedOutput, actual);

		//does not exist in repo and controle -> step statussen should be disabled
		expectedOutput = new KlantsessieStatus(4L, Klantsessie.CONTROLE_MIDDEL_ID, StepStatusEnum.INITIAL, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, false);
		actual = klantsessieStatusService.getCurrentKlantsessieStatus(666L, Klantsessie.CONTROLE_MIDDEL_ID);
		Assertions.assertEquals(expectedOutput, actual);
	}

	@Test
	void updateVoorbereidingAfgerond() {
		KlantsessieStatus expectedOutput = new KlantsessieStatus(1L, 12, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, StepStatusEnum.DONE, true);
		klantsessieStatusService.updateVoorbereidingAfgerond(888L, 12, TEST_LOGGING_ID_1);
		KlantsessieStatus actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(1L, 12).orElse(null);
		Assertions.assertEquals(expectedOutput, actual);
		LoggingArgumentAssertion.check(logging2ServiceMock, TEST_LOGGING_ID_1, 888L, Logging2.Bewerking.UPDATE);
	}

	@Test
	void updateStatussenWhenControlePlaatsgevonden(){
		//steps are disabled -> set controle to true -> steps are initial
		KlantsessieStatus expectedOutput = new KlantsessieStatus(1L, Klantsessie.CONTROLE_MIDDEL_ID, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, StepStatusEnum.INITIAL, false);
		klantsessieStatusService.updateStatussenWhenControlePlaatsgevonden(888L, true);
		KlantsessieStatus actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(1L, Klantsessie.CONTROLE_MIDDEL_ID).orElse(null);
		Assertions.assertEquals(expectedOutput, actual);

		//steps are initial -> set controle to false -> steps are disabled
		expectedOutput = new KlantsessieStatus(1L, Klantsessie.CONTROLE_MIDDEL_ID, StepStatusEnum.INITIAL, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, StepStatusEnum.DISABLED, false);
		klantsessieStatusService.updateStatussenWhenControlePlaatsgevonden(888L, false);
		actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(1L, Klantsessie.CONTROLE_MIDDEL_ID).orElse(null);
		Assertions.assertEquals(expectedOutput, actual);
	}

	@Test
	void checkStatussenWhenControlePlaatsgevondenIsSetToFalseAndBackToTrue(){
		//steps had different statussen -> set controle to false and true -> statussen should be the same
		KlantsessieStatus expectedOutput = new KlantsessieStatus(2L, Klantsessie.CONTROLE_MIDDEL_ID, StepStatusEnum.COMPLETED, StepStatusEnum.TOUCHED, StepStatusEnum.TOUCHED, StepStatusEnum.INITIAL, false);
		klantsessieStatusService.updateStatussenWhenControlePlaatsgevonden(999L, false);
		stubCheckServiceMap();
		klantsessieStatusService.updateStatussenWhenControlePlaatsgevonden(999L, true);
		KlantsessieStatus actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(2L, Klantsessie.CONTROLE_MIDDEL_ID).orElse(null);
		Assertions.assertEquals(expectedOutput, actual);
	}

	@Test
	void checkStatussenAfterVoorbereidingWasAfgerondWhenControlePlaatsgevondenIsSetToFalseAndBackToTrue(){
		// steps were done -> set controle false and true -> steps should be completed, last step should be touched
		KlantsessieStatus expectedOutput = new KlantsessieStatus(3L, Klantsessie.CONTROLE_MIDDEL_ID, StepStatusEnum.COMPLETED, StepStatusEnum.COMPLETED, StepStatusEnum.COMPLETED, StepStatusEnum.TOUCHED, true);
		klantsessieStatusService.updateStatussenWhenControlePlaatsgevonden(777L, false);
		stubCheckServiceMap();
		klantsessieStatusService.updateStatussenWhenControlePlaatsgevonden(777L, true);
		KlantsessieStatus actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(3L, Klantsessie.CONTROLE_MIDDEL_ID).orElse(null);
		Assertions.assertEquals(expectedOutput, actual);
	}

	@Test
	void setStepStatus(){
		klantsessieStatusService.setStepStatus(999L, 12, StepEnum.ZOOEF, StepStatusEnum.COMPLETED);
		KlantsessieStatus actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(2L, 12).orElse(null);
		Assertions.assertEquals(StepStatusEnum.COMPLETED, actual.getZooefStatus());
		Assertions.assertEquals(StepStatusEnum.INITIAL, actual.getVoorbereidingAfrondenStatus());

		klantsessieStatusService.setStepStatus(999L, 12, StepEnum.COMPLIANCE, StepStatusEnum.TOUCHED);
		actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(2L, 12).orElse(null);
		Assertions.assertEquals(StepStatusEnum.TOUCHED, actual.getComplianceStatus());
		Assertions.assertEquals(StepStatusEnum.INITIAL, actual.getVoorbereidingAfrondenStatus());

		klantsessieStatusService.setStepStatus(999L, 12, StepEnum.STRATEGIE, StepStatusEnum.COMPLETED);
		actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(2L, 12).orElse(null);
		Assertions.assertEquals(StepStatusEnum.COMPLETED, actual.getStrategieStatus());
		Assertions.assertEquals(StepStatusEnum.INITIAL, actual.getVoorbereidingAfrondenStatus());

		klantsessieStatusService.setStepStatus(777L, 12, StepEnum.STRATEGIE, StepStatusEnum.COMPLETED);
		actual = klantsessieStatusRepository.findByKlantsessieIdAndMiddelId(3L, 12).orElse(null);
		Assertions.assertEquals(StepStatusEnum.COMPLETED, actual.getStrategieStatus());
		Assertions.assertEquals(StepStatusEnum.TOUCHED, actual.getVoorbereidingAfrondenStatus());
	}
}
