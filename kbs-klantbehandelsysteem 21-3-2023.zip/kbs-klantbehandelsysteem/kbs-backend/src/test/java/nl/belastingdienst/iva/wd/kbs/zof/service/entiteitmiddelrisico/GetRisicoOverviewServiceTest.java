package nl.belastingdienst.iva.wd.kbs.zof.service.entiteitmiddelrisico;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import nl.belastingdienst.iva.wd.kbs.dao.KenmerkRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.dao.MiddelnaamAfkortingRepository;
import nl.belastingdienst.iva.wd.kbs.domain.Kenmerk;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;
import nl.belastingdienst.iva.wd.kbs.domain.MiddelnaamAfkorting;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.dao.EntiteitMiddelRisicoRepository;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.domain.LowestEntiteitMiddelRisicoDto;

@SpringBootKbsTest
class GetRisicoOverviewServiceTest {

	@Autowired
	EntiteitMiddelRisicoRepository entiteitMiddelRisicoRepository;

	@Autowired
	KenmerkRepository kenmerkRepository;

	@Autowired
	MiddelRisicoRepository middelRisicoRepository;

	@Autowired
	MiddelnaamAfkortingRepository middelnaamAfkortingRepository;

	@Autowired
	GetRisicoOverviewService sut;

	@BeforeEach
	void setUp() {
		this.kenmerkRepository.saveAll(
				List.of(
						new Kenmerk(200, "-", "Onderhanden", null),
						new Kenmerk(201, "-", "Nieuw", null),
						new Kenmerk(300, "-", "Beheerst", null),
						new Kenmerk(301, "-", "Niet beheerst", null)
				)
		);

		middelnaamAfkortingRepository.saveAll(
				List.of(
						new MiddelnaamAfkorting(24, "Inkomstenbelasting", "IH", 2L),
						new MiddelnaamAfkorting(12, "Vennootschapsbelasting", "VPB", 1L)
				)
		);

		this.middelRisicoRepository.saveAll(List.of(
				new MiddelRisico(1L, 24, "risico 1", null, 2L),
				new MiddelRisico(2L, 12, "risico 2", null, null),
				new MiddelRisico(3L, 12, "risico 3", null, 1L)
		));

		this.entiteitMiddelRisicoRepository.saveAll(List.of(
				new EntiteitMiddelRisico(1L, 999L, null, 1L, null, (short) 1, 200L, 301,1L),
				new EntiteitMiddelRisico(2L, 999L, null, 2L, null, (short) 0, 201L, 300,3L),
				new EntiteitMiddelRisico(3L, 999L, null, 3L, null, (short) 1, 200L, 300,2L)
		));
	}

	@Test
	void getRisicoOverview() {
		var expected = List.of(
				new LowestEntiteitMiddelRisicoDto("risico 3", (short) 1, "Onderhanden", "Beheerst", "VPB"),
				new LowestEntiteitMiddelRisicoDto("risico 2", (short) 0, "Nieuw", "Beheerst", "VPB"),
				new LowestEntiteitMiddelRisicoDto("risico 1", (short) 1, "Onderhanden", "Niet beheerst", "IH")
		);

		var actual = this.sut.getRisicoOverview(999L);
		Assertions.assertEquals(expected, actual);
	}
}