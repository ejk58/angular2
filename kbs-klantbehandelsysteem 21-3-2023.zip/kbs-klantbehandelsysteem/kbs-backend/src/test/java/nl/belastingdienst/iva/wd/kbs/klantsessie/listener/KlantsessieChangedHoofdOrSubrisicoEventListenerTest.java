/*
 * ---------------------------------------------------------------------------------------------------------
 *         Copyright: (c) 2022 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                    All Rights Reserved.
 * ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 */

package nl.belastingdienst.iva.wd.kbs.klantsessie.listener;

import nl.belastingdienst.iva.wd.kbs.klantsessie.service.strategie.DeleteSelectedRisicoService;
import nl.belastingdienst.iva.wd.kbs.shared.annotation.SpringBootKbsTest;
import nl.belastingdienst.iva.wd.kbs.zof.domain.EntiteitMiddelRisico;
import nl.belastingdienst.iva.wd.kbs.zof.event.ChangedHoofdOrSubrisicoEvent;
import nl.belastingdienst.iva.wd.kbs.zof.util.FindLowestRisicoUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.mockito.Mockito.times;

@SpringBootKbsTest
class KlantsessieChangedHoofdOrSubrisicoEventListenerTest {
    @MockBean
    private DeleteSelectedRisicoService deleteSelectedRisicoService;
    @Autowired
    KlantsessieChangedHoofdOrSubrisicoEventListener cut;

    @DisplayName("Test the KlantsessieChangedHoofdOrSubrisicoEventListener")
    @Test
    void handle() {
        EntiteitMiddelRisico mock = new EntiteitMiddelRisico(1L, 999L, null, 1L, null, (short) 1, 1L, 1, null);
        ChangedHoofdOrSubrisicoEvent mockEvent = new ChangedHoofdOrSubrisicoEvent(mock);

        cut.handle(mockEvent);

        Mockito.verify(deleteSelectedRisicoService, times(1))
                .deleteBy(mockEvent.getEntiteitMiddelRisicoBefore().getEntiteitNummer(),
                        FindLowestRisicoUtil.findLowestRisicoId(mockEvent.getEntiteitMiddelRisicoBefore()));
    }
}