package nl.belastingdienst.iva.wd.kbs.shared.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;

import nl.belastingdienst.iva.wd.kbs.shared.dao.AfterEachTestHook;

@SpringBootTest
@ExtendWith(AfterEachTestHook.class)
@Retention(RetentionPolicy.RUNTIME)
public @interface SpringBootKbsTest {
}
