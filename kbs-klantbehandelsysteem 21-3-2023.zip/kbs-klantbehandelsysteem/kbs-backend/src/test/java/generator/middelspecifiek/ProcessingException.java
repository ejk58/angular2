package generator.middelspecifiek;

import java.io.IOException;

public class ProcessingException extends Throwable {
    public ProcessingException(String s, IOException e) {
        super(s,e);
    }
}
