package generator.middelspecifiek;

public class SheetIsEmptyException extends RuntimeException {
	private static final long serialVersionUID = 16798097339551764L;


	public SheetIsEmptyException(String sheetName) {
		super("The sheet " + sheetName + " is empty.");
	}
}
