package generator.middelspecifiek.domain;

import java.util.List;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelKenmerk;

public class MiddelKenmerkWrapper extends MiddelKenmerk {
	List<MiddelKenmerkWrapper> subkenmerken;

	public MiddelKenmerkWrapper(MiddelKenmerk kenmerk) {
		super(kenmerk.getId(), kenmerk.getMiddelId(), kenmerk.getKenmerk(), kenmerk.getParentId());
	}

	public void setSubkenmerken(List<MiddelKenmerkWrapper> subkenmerken) {
		this.subkenmerken = subkenmerken;
	}

	public List<MiddelKenmerkWrapper> getSubkenmerken() {
		return subkenmerken;
	}

	@Override
	public String toString() {
		return "MiddelKenmerkWrapper(id=" + getId() + ", middelId=" + getMiddelId() + ", kenmerk=" + getKenmerk() + ", parentId="
				+ getParentId() + ", children=" + getSubkenmerken() + "]";
	}
}
