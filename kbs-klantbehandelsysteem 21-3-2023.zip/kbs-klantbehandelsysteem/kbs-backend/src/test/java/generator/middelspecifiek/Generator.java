package generator.middelspecifiek;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidOperationException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.collect.Iterators;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;

/**
* Consult the README file in "src\test\java\generator\middelspecifiek" before compiling
**/
public class Generator {

    /** add new Excel in files/existing folder and excel file name here **/
    private static final String EXCEL_FILE_PATH = "./kbs-backend/src/test/files/excelSheets/Middel risico en kenmerken OB.xlsx";

    private final MiddelRisicosGenerator middelRisicosGenerator = new MiddelRisicosGenerator();
    private final MiddelKenmerkenGenerator middelKenmerkenGenerator = new MiddelKenmerkenGenerator();

    public static void main(String[] args) throws ProcessingException, IOException {
        new Generator().go();
    }

    private void go() throws ProcessingException, IOException {
        System.out.println("Please enter middel number: ");
        Scanner in = new Scanner(System.in);
        int middelId = in.nextInt();

        Workbook wb = openWorkbook();

        int numberOfSheets = Iterators.size(wb.sheetIterator());
        if(numberOfSheets != 2){
            throw new IllegalArgumentException("Unexpected number of sheets. Expected is 2, but got: "+ numberOfSheets);
        }

        Sheet sheet = wb.getSheetAt(1);
        List<MiddelRisico> newAndOldRisicosForMiddel = middelRisicosGenerator.generateRisicosListForMiddel(sheet, middelId);

        sheet = wb.getSheetAt(0);
        middelKenmerkenGenerator.readKenmerkenIntoList(sheet, middelId, newAndOldRisicosForMiddel);
    }

    private Workbook openWorkbook() throws ProcessingException {
        Workbook workbook;
        try {
            workbook = new XSSFWorkbook(EXCEL_FILE_PATH);
        } catch (IOException e) {
            throw new ProcessingException("Problem reading the workbook '" + EXCEL_FILE_PATH + "'.", e);
        } catch (InvalidOperationException | IllegalStateException ex) {
            try {
                workbook = new HSSFWorkbook(new FileInputStream(EXCEL_FILE_PATH));
            } catch (FileNotFoundException e1) {
                throw new ProcessingException("Workbook '" + EXCEL_FILE_PATH + "' not found.", e1);
            } catch (IOException e1) {
                throw new ProcessingException("Problem reading the workbook '" + EXCEL_FILE_PATH + "'.", e1);
            }
        }
        return workbook;
    }

}
