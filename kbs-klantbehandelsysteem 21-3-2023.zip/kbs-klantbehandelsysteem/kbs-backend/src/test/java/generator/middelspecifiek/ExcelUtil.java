package generator.middelspecifiek;

import java.nio.charset.StandardCharsets;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.junit.platform.commons.util.StringUtils;

public class ExcelUtil {
	public static boolean rowIsNotEmpty(Row row, int cellsToCheck){
		if(row == null) {
			return false;
		}
		if(row.getLastCellNum() <= 0) {
			return false;
		}
		for (int cellNum = row.getFirstCellNum(); cellNum < cellsToCheck; cellNum++) {
			Cell cell = row.getCell(cellNum);
			if (cellIsNotEmpty(cell)) {
				return true;
			}
		}
		return false;
	}

	public static boolean cellIsNotEmpty(Cell cell){
		return cell != null && cell.getCellType() != CellType.BLANK && StringUtils.isNotBlank(cell.toString());
	}

	public static String parseCell(Cell cell){
		return new String(cell.getStringCellValue().getBytes(), StandardCharsets.UTF_8)
				.replace("\u00a0"," ").trim()
				.replace("'", "''");
	}

}
