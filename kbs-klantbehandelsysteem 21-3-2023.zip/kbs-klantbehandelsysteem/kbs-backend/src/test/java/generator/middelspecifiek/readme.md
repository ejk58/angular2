
# Generator 

Generator class was made to read Excel file with new or existing middel kenmerken & risicos and convert it to the structure needed 
for MIDDEL_RISICOS, MIDDEL_KENMERKEN and KENMERK_RISICOS_KOPPELING databases. For more info check this
[Jira issue](https://jira.belastingdienst.nl/browse/IVAKBS-740).

### Prerequisites

1. Please check that the Excel file complies with format, which can be found here: 
[Confluence](https://confluence.belastingdienst.nl/display/CM/Fiscale+kenmerken+en+risico%27s+-+KBS+ZoF).
2. Add Excel file to **./kbs-backend/src/test/files/excelSheets**
3. The script needs access to database repository for reading sql with existing risicos, kenmerken and koppeling
   * Make sure your kbs-klantbehandelsysteem and kbs-database are in the same folder
   * Make sure your database repository is named **kbs-database**
   OR replace kbs-database with the name of your folder in 3 places:
     * MiddelKenmerkGenerator KENMERKEN_SQL_FILE_PATH
     * MiddelKenmerkGenerator KOPPELING_SQL_FILE_PATH
     * MiddelRisicosGenerator SQL_FILE_PATH
4. Look up **id** of the middel for which you want to add risicos and kenmerken (in KENMERKEN table where GROUP is MID)

### Compile

1. Navigate to **./kbs-backend/src/test/java/generator.middelspecifiek/Generator.java** 
2. Replace excel file name with the new excel file name in **EXCEL_FILE_PATH**
3. Run main()
4. In console, type the middel id (Prerequisites 4)
> Please enter middel number:
> *your_middel_id*

#### Log:

* Max existing id of middel risicos from SQL file
* Total of all risicos for this middel
* Max existing id of middel kenmerken from SQL file
* Total of all kenmerken for this middel
* (Optional) Cannot find risico ... to pair kenmerk to
  * Only if there is an error with risico
  * Check that risico text is correct and is a match to the risico in risico's sheet
* Amount of pairs between kenmerken and risicos

### Results

3 newly generated sql files are directly written to your database repository. Do not forget to commit the changes from database repo.

2 json files needed for robot tests can be found in **./kbs-backend/src/test/files/generator**

### Known errors

* IllegalArgumentException: Unexpected number of sheets...
  * check that your Excel has exctly 2 sheets: 1st with kenmerken and gekoppelde risicos, 2nd with risicos (**sheet order is important**)
* SheetIsEmptyException
  * check that your sheet contains data
* IllegalArgumentException: Unknown format of risico's/kenmerken sheet...
  * see Prerequisites 1 above
* FileNotFoundException
  * see Prerequisites and check that your structure is correct
  * check constants in Generator, MiddelKenmerkGenerator and MiddelRisicosGenerator to see if path for the file(s) matches