package generator.middelspecifiek.domain;

import java.util.List;

import nl.belastingdienst.iva.wd.kbs.domain.MiddelRisico;

public class MiddelRisicoWrapper extends MiddelRisico {
	List<MiddelRisico> children;

	public MiddelRisicoWrapper(MiddelRisico risico){
		super(risico.getId(), risico.getMiddelId(), risico.getRisico(), risico.getParentId(), risico.getRank());
	}

	public void setChildren(List<MiddelRisico> children) {
		this.children = children;
	}

	public List<MiddelRisico> getChildren() {
		return children;
	}

//	@Override
//	public String toString() {
//		return "MiddelRisicoWrapper(id=" + getId() + ", middelId=" + getMiddelId() + ", risico=" + getRisico() + ", parentId=" + getParentId() + ", rank=" + getRank() + ", children=" + getChildren() + "]";
//	}
}
