import {MenuItem} from 'iv-framework-lib';

export const zoekenKlantMenuItem = {
  text: 'Zoeken klant',
  route: 'authenticated/entiteit-zoeken',
  icon: 'fas fa-search'
};

export const algemeneGegevensMenuItem = {
  text: 'Algemene gegevens',
  route: 'authenticated/raadplegen-klant-gegevens/algemene-gegevens'
}

export const raadplegenKlantMenuItem = {
  text: 'Raadplegen klant',
  route: 'authenticated/raadplegen-klant-gegevens',
  submenu: [
    algemeneGegevensMenuItem,
    {
      text: 'Dashboard',
      route: 'authenticated/raadplegen-klant-gegevens/dashboard'
    },
    {
      text: `Let's go`,
      route: 'authenticated/raadplegen-klant-gegevens/lets-go'
    },
    {
      text: 'Logboek',
      route: 'authenticated/raadplegen-klant-gegevens/logboek'
    },
    {
      text: 'Klantdocumenten',
      route: 'authenticated/raadplegen-klant-gegevens/Klantdocumenten'
    }
  ]
};

export const zichtOpOrganisatieMenuItem = {
  text: 'Zicht op organisatie',
  route: 'authenticated/zicht-op-organisatie',
  submenu: [
    {
      text: 'Bedrijfsactiviteiten',
      route: 'authenticated/zicht-op-organisatie/bedrijfsactiviteiten'
    },
    {
      text: 'Cijferbeoordeling',
      route: 'authenticated/cijferbeoordeling'
    },
    {
      text: 'Concernstructuur',
      route: 'authenticated/concernstructuur'
    },
    {
      text: 'Bevindingen tbv klantbeeldanalyse',
      route: 'authenticated/zoo/klantbeeldanalyse'
    }]
};

export const zichtOpComplianceMenuItem = {
  text: 'Zicht op compliance',
  route: 'authenticated/zicht-op-compliance',
  submenu: [
    {
      text: 'Compliance',
      route: 'authenticated/zicht-op-compliance/compliance'
    },
    {
      text: 'Beheersmaatregelen',
      route: 'authenticated/zicht-op-compliance/beheersmaatregelen'
    },
    {
      text: 'Bevindingen tbv klantbeeldanalyse',
      route: 'authenticated/zicht-op-compliance/bevindingen-tbv-klantbeeldanalyse'
    }
  ]
};

export const klantbeeldanalyseMenuItem = {
  text: 'Klantbeeldanalyse',
  route: 'authenticated/klantbeeld-analyse',
  submenu: [
    {
      text: 'Overzicht klantbeeldanalyse',
      route: 'authenticated/klantbeeld-analyse/overzicht'
    },
    {
      text: 'Resultaten klantbeeldanalyse',
      route: 'authenticated/klantbeeld-analyse/resultaten'
    }
  ]
};

export const strategieMenuItem = {
  text: 'Strategie',
  route: 'authenticated/strategie'
};

export const behandelvoorstellenEnActiviteitenMenuItem = {
  text: 'Behandelvoorstellen en -activiteiten',
  route: 'authenticated/behandelvoorstellen'
};

export const verantwoordenMenuItem = {
  text: 'Verantwoorden',
  route: 'authenticated/verantwoorden'
};

export const behandelplangegevensMenuItem = {
  text: 'Behandelplangegevens',
  route: 'authenticated/behandelplangegevens'
};

export const KLANTSESSIE_CONTROLE = 'Controle';
export const KLANTSESSIE_KLANTCOORDINATOR = 'Klantcoördinator';
export const KLANTSESSIE_RESULTAAT = 'resultaat-klantsessie';

export const klantsessieStaticSubmenuItems: Array<MenuItem> = [
  {
    text: 'Controle',
    route: 'authenticated/klantsessie/' + KLANTSESSIE_CONTROLE
  },
  {
    text: 'Klantcoördinator',
    route: 'authenticated/klantsessie/' + KLANTSESSIE_KLANTCOORDINATOR
  },
  {
    text: 'Resultaat Klantsessie',
    route: 'authenticated/klantsessie/' + KLANTSESSIE_RESULTAAT
  }];

export const zofStaticSubmenuItems: Array<MenuItem> = [
  {
    text: 'Overige middelen',
    route: 'authenticated/zicht-op-fiscaliteit/overige-middelen'
  },
  {
    text: 'Bevindingen tbv klantbeeldanalyse',
    route: 'authenticated/zof-klantbeeldanalyse'
  }];
