import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';

@Component({
  selector: 'app-column-filter',
  templateUrl: './column-filter.component.html',
  styleUrls: ['./column-filter.component.scss']
})
export class ColumnFilterComponent implements OnChanges {

  @Input()
  field: string;
  @Input()
  tableRows: any[] = [];

  distinctValues: {name: string, value: string}[];

  static getDistinctSet(inputArray: any[], fieldName: string): {name: string, value: string}[] {
    return Array.from(new Set(inputArray.map(arr => arr[fieldName]))).map(o => { return {name: o,value: o}});
  }

  ngOnChanges(changes: SimpleChanges): void {
    if(changes.tableRows?.currentValue){
      this.distinctValues = ColumnFilterComponent.getDistinctSet(this.tableRows, this.field);
    }
  }

}
