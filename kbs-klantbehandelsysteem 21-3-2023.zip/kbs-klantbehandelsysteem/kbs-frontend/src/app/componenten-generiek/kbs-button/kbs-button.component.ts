import {Component, Input, OnInit} from '@angular/core';

// Demo component for Storybook
@Component({
  selector: 'app-kbs-button',
  templateUrl: './kbs-button.component.html',
  styleUrls: ['./kbs-button.component.scss']
})
export class KbsButtonComponent implements OnInit {
  @Input() label: string = "button-label";

  constructor() { }

  ngOnInit(): void {
  }

}
