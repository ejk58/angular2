import {KenmerkChild} from '../../entiteit/entiteit-klantseessie/klantsessie-kenmerk-parent';

export const GREY_SPINNENWEB_DATASET = '180,180,180';
export const BLUE_SPINNENWEB_DATASET = '1,104,155';
export const CURRENT_KLANTSESSIE_LABEL = 'Huidige klantsessie';

export interface KenmerkEnScore {
  kenmerkId: number,
  score: number
}

export interface RadarDatasetData {
  label: string,
  kenmerkMetScores: KenmerkEnScore[];
}

export function mapKenmerkChildToKenmerkEnScore(children: KenmerkChild[]) {
  const kenmerkenEnScores: KenmerkEnScore[] = [];
  children.forEach(child => {
    kenmerkenEnScores.push({
      kenmerkId: child.kenmerk.id,
      score: child.score
    });
  });
  return kenmerkenEnScores;
}
