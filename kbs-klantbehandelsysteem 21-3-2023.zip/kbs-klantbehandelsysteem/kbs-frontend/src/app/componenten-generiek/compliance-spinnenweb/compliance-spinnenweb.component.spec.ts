import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplianceSpinnenwebComponent } from './compliance-spinnenweb.component';

describe('ComplianceSpinnenwebComponent', () => {
  let component: ComplianceSpinnenwebComponent;
  let fixture: ComponentFixture<ComplianceSpinnenwebComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComplianceSpinnenwebComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplianceSpinnenwebComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
