import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {KlantsessieComplianceService} from "../../services/klantsessie-compliance.service";
import {ChartLabel} from "../radar-chart/chart-label";
import {
  BLUE_SPINNENWEB_DATASET,
  CURRENT_KLANTSESSIE_LABEL,
  GREY_SPINNENWEB_DATASET,
  KenmerkEnScore,
  RadarDatasetData
} from './compliance-spinnenweb-interfaces';
import {RadarDataset} from '../radar-chart/radar-dataset';

@Component({
  selector: 'app-compliance-spinnenweb',
  templateUrl: './compliance-spinnenweb.component.html',
  styleUrls: ['./compliance-spinnenweb.component.scss']
})
export class ComplianceSpinnenwebComponent implements OnInit, OnChanges {

  @Input() spinnenwebTitle: string;
  @Input() tooltipHelpTextId: string;
  @Input() dataset: RadarDatasetData[];
  @Input() updatedScore: KenmerkEnScore;

  radarCharDatasets: RadarDataset[] = [];
  labels: ChartLabel[] = [];

  constructor(private readonly klantsessieComplianceService: KlantsessieComplianceService) {
  }

  ngOnInit(): void {
    this.getSpinnenwebLabels();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.updatedScore) {
      this.fillDataOfRadarDataset(this.updatedScore.kenmerkId, this.updatedScore.score, CURRENT_KLANTSESSIE_LABEL);
    }

    if(changes?.dataset?.currentValue){
      this.createDatasetPerColor();
    }
  }

  getSpinnenwebLabels() {
    this.klantsessieComplianceService.getChartLabels().subscribe(labels => this.labels = labels);
  }

  private createDatasetPerColor() {
    let color = '';
    for(let i = 0; i < this.dataset.length; i++){
      color = (i === 0) ? BLUE_SPINNENWEB_DATASET : GREY_SPINNENWEB_DATASET;
      this.createRadarChart(this.dataset[i], color);
    }
  }

  private createRadarChart(dataSet: RadarDatasetData, color: string) {

    if(!dataSet){
      return;
    }

    let radarDataset = this.radarCharDatasets.find(ds => ds.dataSetLabel === dataSet?.label);
    if(!radarDataset){
      this.radarCharDatasets.push(
        {
          dataSetLabel: dataSet.label,
          data: [],
          colors: {
            backgroundColor: `rgba(${color},0.2)`,
            borderColor: `rgba(${color},1)`,
            pointBackgroundColor: `rgba(${color},1)`,
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: `rgba(${color},1)`,
          }
        }
      );
    }

    dataSet.kenmerkMetScores.forEach(kenmerkEnScore => {
      this.fillDataOfRadarDataset(kenmerkEnScore.kenmerkId, kenmerkEnScore.score, dataSet.label)
    });

  }

  fillDataOfRadarDataset(kenmerkId: number, score: number, dataSetLabel: string): void {
    let radarDataset = this.radarCharDatasets.find(ds => ds.dataSetLabel === dataSetLabel);
    let correspondingData = radarDataset?.data.find(d => d.id === kenmerkId);
    if (correspondingData) {
      correspondingData.value = score;
    } else {
      radarDataset?.data.push({id: kenmerkId, value: score});
    }
    /* force ngOnChange */
    this.radarCharDatasets = [...this.radarCharDatasets];
  }
}
