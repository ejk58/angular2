import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
    selector: 'app-checkbox',
    templateUrl: './checkbox.component.html',
    styleUrls: ['./checkbox.component.scss']
})
export class CheckboxComponent {
    @Input()
    options: any[];
    @Input()
    selectedElements: any[];
    @Input()
    hasProcessingRole: boolean;
    @Output()
    onSave = new EventEmitter<any>();
    @Output()
    onDelete = new EventEmitter<any>();

    isChecked(option: any): boolean {
        return this.selectedElements === undefined ? false :
            this.selectedElements.map(selected => selected.id).indexOf(option.id) > -1;
    }

    onSelectChange(event: any, element: any) {
        if (!this.selectedElements) {
            return;
        }
        if (event.checked) {
            this.selectedElements.push(element);
            this.onSave.emit(this.selectedElements);
        } else {
            const index = this.selectedElements.map(kenmerk => kenmerk.id).indexOf(element.id);
            if (index > -1) {
                const deleted = this.selectedElements.splice(index, 1)[0];
                this.onDelete.emit(deleted)
            }
        }
    }

}
