import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplianceKlantsessiesTableComponent } from './compliance-klantsessies-table.component';

describe('ComplianceKlantsessiesTableComponent', () => {
  let component: ComplianceKlantsessiesTableComponent;
  let fixture: ComponentFixture<ComplianceKlantsessiesTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComplianceKlantsessiesTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplianceKlantsessiesTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
