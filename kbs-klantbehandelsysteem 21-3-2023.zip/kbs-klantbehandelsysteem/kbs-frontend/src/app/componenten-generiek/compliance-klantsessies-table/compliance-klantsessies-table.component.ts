import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {
  KlantsessieResultaat,
  KlantsessieResultaatEntry,
  TableField,
  TableRow
} from '../../entiteit/entiteit-klantseessie/resultaat-klantsessie/klantsessie-resultaat';
import {KlantsessieResultaatService} from '../../services/klantsessie-resultaat.service';
import {CurrentComplianceToelichtingPopupComponent} from '../../entiteit/entiteit-klantseessie/resultaat-klantsessie/current-compliance-toelichting-popup/current-compliance-toelichting-popup.component';
import {KenmerkChild, KenmerkParent} from '../../entiteit/entiteit-klantseessie/klantsessie-kenmerk-parent';
import {AbbreviateMiddelPipe} from '../../pipes/abbreviate-middel.pipe';
import {DialogService} from 'primeng/dynamicdialog';
import {HelptextIds} from '../../shared/helptext-ids';
import {ComplianceKlantsessiePreviousEntry} from "./compliance-klantsessie-previous";
import {DateNLPipe} from "../../pipes/date-nl.pipe";

@Component({
  selector: 'app-compliance-klantsessies-table',
  templateUrl: './compliance-klantsessies-table.component.html',
  styleUrls: ['./compliance-klantsessies-table.component.scss']
})
export class ComplianceKlantsessiesTableComponent implements OnInit {

  @Input() showCurrentEntries: boolean = false;
  @Input() entiteitNummer: number;
  @Input() klantsessieResultaat: KlantsessieResultaat;
  @Output() complianceKlantsessiePreviousEntry = new EventEmitter<ComplianceKlantsessiePreviousEntry>();

  readonly HelptextIds = HelptextIds;
  tableRows: TableRow[];

  constructor(private readonly klantsessieResultaatService: KlantsessieResultaatService,
              private readonly dialogService: DialogService,
              private readonly abbreviateMiddelPipe: AbbreviateMiddelPipe,
              private readonly dateNlPipe: DateNLPipe,) {
  }

  ngOnInit(): void {
    this.loadTableContent();
  }

  loadTableContent(): void {
    this.generateSpinnenwebDatasetsFromResultaat();
    this.tableRows = this.createTableRows();
  }

  generateSpinnenwebDatasetsFromResultaat() {
    const complianceKlantsessiePreviousEntry: ComplianceKlantsessiePreviousEntry = {
      previousEntries: [...this.klantsessieResultaat.previousEntries].reverse().slice(0,2)
    };
    this.complianceKlantsessiePreviousEntry.emit(complianceKlantsessiePreviousEntry);
  }

  createTableRows(): TableRow[] {
    let tableRows: TableRow[] = [];
    for (const kenmerkParent of this.klantsessieResultaat.kenmerken) {
      let kenmerkParentRow: TableRow = new TableRow();
      kenmerkParentRow.isParentKenmerk = true;
      kenmerkParentRow.kenmerk = kenmerkParent.kenmerk;
      kenmerkParentRow.fields = []
      this.klantsessieResultaat.previousEntries.forEach(() => {
        let previousField: TableField = new TableField();
        previousField.isCurrentEntry = false;
        kenmerkParentRow.fields.push(previousField);
      });
      if (this.showCurrentEntries) {
        this.klantsessieResultaat.currentEntries.forEach(() => {
          let currentField: TableField = new TableField();
          currentField.isCurrentEntry = true;
          kenmerkParentRow.fields.push(currentField);
        });
      }
      tableRows.push(kenmerkParentRow);

      for (const kenmerkChild of kenmerkParent.kenmerkChildren) {
        let kenmerkChildRow: TableRow = new TableRow();
        kenmerkChildRow.isParentKenmerk = false;
        kenmerkChildRow.kenmerk = kenmerkChild.kenmerk;
        kenmerkChildRow.fields = [];
        for (const previousEntry of this.klantsessieResultaat.previousEntries) {
          let previousField: TableField = new TableField();
          previousField.isCurrentEntry = false;
          const resultaat = previousEntry.resultaatByKenmerkId[kenmerkChild.kenmerk.id];
          previousField.score = resultaat?.score;
          previousField.toelichting = resultaat?.toelichting;
          previousField.popupTitle = this.getToelichtingPopupTitle(kenmerkParent, kenmerkChild, previousEntry, false);
          kenmerkChildRow.fields.push(previousField);
        }

        if (this.showCurrentEntries) {
          for (const currentEntry of this.klantsessieResultaat.currentEntries) {
            let currentField: TableField = new TableField();
            currentField.isCurrentEntry = true;
            const resultaat = currentEntry.resultaatByKenmerkId[kenmerkChild.kenmerk.id];
            currentField.score = resultaat?.score;
            currentField.toelichting = resultaat?.toelichting;
            currentField.popupTitle = this.getToelichtingPopupTitle(kenmerkParent, kenmerkChild, currentEntry, true);
            kenmerkChildRow.fields.push(currentField);
          }
        }
        tableRows.push(kenmerkChildRow);
      }
    }
    return tableRows;
  }

  showToelichtingDialog(popupTitle: string, toelichting: string) {
    this.dialogService.open(CurrentComplianceToelichtingPopupComponent, {
      showHeader: false,
      data: {
        popupTitle: popupTitle,
        toelichting: toelichting,
      },
      styleClass: 'dialog-container',
    });
  }

  getToelichtingPopupTitle(kenmerkParent: KenmerkParent, kenmerkChild: KenmerkChild, dataEntry: KlantsessieResultaatEntry, isCurrentEntry: boolean) {
    let toelichtingPopupTitle: string;
    this.abbreviateMiddelPipe.transform(dataEntry.middel?.kenmerk, dataEntry.middel?.kenmerk).subscribe(afk => {
      const klantSessieColumnName: string = 'klantsessie ' + this.dateNlPipe.transform(dataEntry.lastKlantSessieDate, 'date');
      const columnName: string = isCurrentEntry ? afk : klantSessieColumnName;

      toelichtingPopupTitle = 'Toelichting ' + kenmerkParent.kenmerk?.kenmerk + ' - ' + kenmerkChild.kenmerk?.kenmerk + ' ' + columnName;
    });
    return toelichtingPopupTitle;
  }

}
