import {KlantsessieResultaatEntry} from "../../entiteit/entiteit-klantseessie/resultaat-klantsessie/klantsessie-resultaat";

export interface ComplianceKlantsessiePreviousEntry {
  previousEntries: KlantsessieResultaatEntry[];
}
