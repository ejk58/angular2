import {Component, EventEmitter, Input, Output} from '@angular/core';
import {TextEditorService} from '../../services/text-editor.service';
import {BoldNotification} from '../notification-message/bold-notification';

@Component({
  selector: 'app-field-toelichting',
  templateUrl: './field-toelichting.component.html',
  styleUrls: ['./field-toelichting.component.scss']
})
export class FieldToelichtingComponent {
  @Input()
  title: string;

  @Input()
  tooltipId?: string;

  @Input()
  allowImages: boolean = true;

  @Input()
  maxLength?: number;

  @Input()
  toelichtingText: string;

  @Input()
  robotToelichtingId?: string;

  @Input()
  isLoading: boolean = false;

  @Input()
  hasProcessingRole: boolean;

  @Input()
  notification: BoldNotification;

  @Input()
  readOnlyMode: boolean = false;

  @Output()
  onSave = new EventEmitter<string>();

  constructor(private readonly textEditorService: TextEditorService) { }

  openToelichtingDialog(toelichtingText: string) {
    let textDynamicDialogRef = this.textEditorService.openDialog(toelichtingText, this.title, this.allowImages, this.maxLength);
    textDynamicDialogRef.onSave.subscribe(text => {
      this.onSave.emit(text);
    });
  }
}
