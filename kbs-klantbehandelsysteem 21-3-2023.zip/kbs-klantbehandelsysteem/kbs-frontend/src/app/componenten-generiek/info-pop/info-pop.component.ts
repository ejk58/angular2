import {Component, Input} from '@angular/core';
import {Helptext} from "../helptext/helptext";
import {MatDialog} from "@angular/material/dialog";
import {TooltipEditorComponent} from "../tooltip-editor/tooltip-editor.component";
import {TextPopEditorConfig} from '../text-pop-editor/text-pop-editor-config';
import {Observable} from "rxjs";
import {HelptextService} from "../../services/helptext.service";

@Component({
  selector: 'app-info-pop',
  templateUrl: './info-pop.component.html',
  styleUrls: ['./info-pop.component.scss']
})
export class InfoPopComponent {

  @Input() tooltipHelpTextId: string;
  @Input() maxLength: number;
  @Input() editorTitle:string;

  helpText: Helptext;

  constructor(private readonly dialog: MatDialog,
              private readonly helptextService: HelptextService) {
  }

  showTooltipDetails() {
    if (this.tooltipHelpTextId !== null) {
      this.helptextService.getHelptextTooltip(this.tooltipHelpTextId).subscribe(helptext => {
        this.helpText = helptext;
        this.configurateAndOpenPopup();
      });
    }
  }

  private configurateAndOpenPopup() {
    const editorConfig: TextPopEditorConfig = {
      helptext: this.helpText,
      maxLength: this.maxLength,
      editorTitle: this.editorTitle,
      editorTitleTextType: `(i'tje)`
    };

    const dialogRef = this.dialog.open(TooltipEditorComponent, {
      data: editorConfig,
      width: '800px',
      position: {
        top: '20vh',
        left: '30vw'
      },
      autoFocus: false
    });
    dialogRef.beforeClosed().subscribe((result: Observable<Helptext> | undefined) => {
      if (result !== undefined) {
        result.subscribe(r => {
          r.txt = r.txt ?? '';
          this.helpText = r;
        });
      }
    });
  }
}
