import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';
import {HelptextService} from '../../services/helptext.service';
import {Observable} from 'rxjs';
import {Helptext} from '../helptext/helptext';
import {EntiteitService} from '../../services/entiteit.service';
import {LoggingService} from '../../services/logging.service';
import {UserService} from '../../services/user.service';
import {Role} from '../../shared/authenticated-user-roles';

@Component({
  selector: 'kbs-field-tooltip-help-text',
  templateUrl: './field-tooltip-help-text.component.html',
  styleUrls: ['./field-tooltip-help-text.component.scss']
})
export class FieldTooltipHelpTextComponent implements OnChanges {

  @Input()
  title: string;
  @Input()
  toelichtingHelpTextId: string;
  @Input()
  tooltipHelpTextId: string = null;
  @Input()
  loggingId: string;
  @Input()
  readOnlyMode: boolean = false;
  @Input()
  notificationTitle: string;
  @Input()
  notificationMessage: string;

  helptext: Helptext;
  isLoading: boolean = false;

  textToelichting$: Observable<Helptext>;

  private entiteitNummer: number;

  constructor(private readonly entiteitService: EntiteitService,
              private readonly helptextService: HelptextService,
              private readonly loggingService: LoggingService,
              private readonly userService: UserService,
              ) {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes?.toelichtingHelpTextId?.currentValue) {
      this.toelichtingHelpTextId = changes?.toelichtingHelpTextId?.currentValue;
      this.entiteitService.getSearchEntiteitNummer(nr => {
        this.entiteitNummer = nr;
        this.loadHelptext();
      })
    }
  }

  private getHelptextLogging() {
    this.loggingService.loadLoggingInfoFromBe(this.loggingId, this.entiteitNummer);
  }

  onSaveHelptext(newText: string) {
    this.isLoading = true;
    this.helptext.txt = newText;
    this.helptextService.saveHelptext(this.helptext, this.loggingId)
      .subscribe(edited => {
        this.helptext = edited;
        this.getHelptextLogging()
        this.isLoading = false;
      });
  }

  loadHelptext() {
    this.isLoading = true;
    this.helptextService.getHelptextForEntiteit(this.toelichtingHelpTextId, this.entiteitNummer)
      .subscribe(data => {
        this.helptext = data;
        this.isLoading = false;
      });
  }

  hasDefaultProcessingRole(): Observable<boolean> {
    return this.userService.isMemberOfAnyRole(Role.AUG_KBS_BEHANDELAAR);
  }
}
