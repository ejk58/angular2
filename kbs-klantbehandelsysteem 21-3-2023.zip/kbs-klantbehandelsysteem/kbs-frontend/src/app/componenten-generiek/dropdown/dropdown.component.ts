import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
    selector: 'app-dropdown',
    templateUrl: './dropdown.component.html',
    styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent {
    @Input()
    options: any[];
    @Input()
    selectedNgModel: any;
    @Output()
    selectedNgModelChange = new EventEmitter<any>();
    @Input()
    group: boolean = false;
    @Input()
    hasProcessingRole: boolean;
    @Input()
    optionLabel: string;
    @Input()
    optionValue: string;
    @Output()
    onChange = new EventEmitter<any>();

    findLabelForSelected(selected: any) {
        let flattenedOptions = this.options;
        if (this.group) {
          flattenedOptions = [].concat(...this.options.map(({items}) => items || []));
        }
        const find = flattenedOptions.find(option => option[this.optionValue ?? 'value'] === selected || option?.code === selected);
        return find[this.optionLabel ?? 'label'];
    }

}
