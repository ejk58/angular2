import {Component} from '@angular/core';
import {KbsMessagesService} from '../../services/kbs-messages.service';

@Component({
  selector: 'kbs-messages',
  templateUrl: './kbs-messages.component.html',
  styleUrls: ['./kbs-messages.component.scss']
})
export class KbsMessagesComponent   {

  constructor(public kbsMessagesService: KbsMessagesService) { }


}
