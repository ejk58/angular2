import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KbsMessagesComponent } from './kbs-messages.component';

describe('KbsMessagesComponent', () => {
  let component: KbsMessagesComponent;
  let fixture: ComponentFixture<KbsMessagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KbsMessagesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KbsMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
