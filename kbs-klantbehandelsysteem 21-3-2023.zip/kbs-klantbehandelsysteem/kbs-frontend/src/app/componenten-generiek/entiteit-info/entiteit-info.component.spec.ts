import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntiteitInfoComponent } from './entiteit-info.component';

describe('EntiteitInfoComponent', () => {
  let component: EntiteitInfoComponent;
  let fixture: ComponentFixture<EntiteitInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntiteitInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntiteitInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
