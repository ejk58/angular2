import {Component, OnInit,} from '@angular/core';
import {EntiteitService} from "../../services/entiteit.service";
import {Entiteit} from "../../entiteit/shared/entiteit";
import {Observable} from "rxjs";
import {EntiteitInfoHeaderService} from '../../services/entiteit-info-header.service';

@Component({
  selector: 'app-entiteit-info',
  templateUrl: './entiteit-info.component.html',
  styleUrls: ['./entiteit-info.component.scss']
})
export class EntiteitInfoComponent implements OnInit {

  entiteit$: Observable<Entiteit>;
  visibility: boolean;

  constructor(private readonly entiteitService: EntiteitService, private readonly entiteitInfoHeaderService: EntiteitInfoHeaderService) {
  }

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteit$ = this.entiteitService.getEntiteit(nr);
    });
    this.entiteitInfoHeaderService.getVisibility().subscribe(visibility => {
      this.visibility = visibility;
    })
  }

}
