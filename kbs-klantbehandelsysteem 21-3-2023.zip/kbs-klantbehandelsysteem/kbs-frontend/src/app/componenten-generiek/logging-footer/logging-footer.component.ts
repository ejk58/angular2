import {Component, OnInit} from '@angular/core';
import {LoggingVisibilityService} from '../../services/logging-visibility.service';
import {LoggingService} from '../../services/logging.service';
import {LoggingInfo} from '../../interfaces/logging-info';

@Component({
  selector: 'app-logging-footer',
  templateUrl: './logging-footer.component.html',
  styleUrls: ['./logging-footer.component.scss']
})
export class LoggingFooterComponent implements OnInit{

  visibility: boolean;
  loggingInfo: LoggingInfo;

  constructor(private readonly loggingVisibilityService: LoggingVisibilityService, private readonly loggingService: LoggingService) {
  }

  ngOnInit(): void {
    this.loggingVisibilityService.getVisibility().subscribe(visibility => {
      this.visibility = visibility;
    });
    this.loggingService.getLoggingInfo().subscribe(logInfo => this.loggingInfo = logInfo);
  }


}
