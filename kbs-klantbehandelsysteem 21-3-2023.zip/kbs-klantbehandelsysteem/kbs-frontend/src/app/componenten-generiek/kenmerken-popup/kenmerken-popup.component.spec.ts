import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KenmerkenPopupComponent } from './kenmerken-popup.component';

describe('KenmerkenPopupComponent', () => {
  let component: KenmerkenPopupComponent;
  let fixture: ComponentFixture<KenmerkenPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KenmerkenPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KenmerkenPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
