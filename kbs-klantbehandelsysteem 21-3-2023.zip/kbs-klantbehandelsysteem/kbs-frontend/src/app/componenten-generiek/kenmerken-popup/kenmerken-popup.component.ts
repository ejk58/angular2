import {Component, EventEmitter, Inject, OnInit, Output} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {ZooEntiteitBranchecodeAanvulling} from '../../interfaces/ZooEntiteitBranchecodeAanvulling';
import {KenmerkenService} from '../../services/kenmerken.service';
import {KenmerkType} from '../../services/kenmerkType';
import {Entiteit} from "../../entiteit/shared/entiteit";
import {LoggingService} from '../../services/logging.service';

@Component({
  selector: 'app-kenmerken-popup',
  templateUrl: './kenmerken-popup.component.html',
  styleUrls: ['./kenmerken-popup.component.scss']
})
export class KenmerkenPopupComponent implements OnInit {

  subEntiteitBsn: number;
  entiteitnummer: number;
  loggingId: string;
  allKenmerken: ZooEntiteitBranchecodeAanvulling[] = [];
  selectedChildKenmerken: ZooEntiteitBranchecodeAanvulling[] = [];

  @Output() onKenmerkenWillBeUpdated: EventEmitter<Entiteit> = new EventEmitter();
  @Output() onKenmerkenUpdated: EventEmitter<Entiteit> = new EventEmitter();


  KenmerkType = KenmerkType;

  constructor(@Inject(MAT_DIALOG_DATA) data: [number, number, string],
              private readonly dialogRef: MatDialogRef<KenmerkenPopupComponent>,
              private kenmerkenService: KenmerkenService,
              private readonly loggingService: LoggingService) {
      this.subEntiteitBsn = data[0];
      this.entiteitnummer = data[1];
      this.loggingId = data[2];
  }

  ngOnInit() {
    this.kenmerkenService.getZooBranchecodeAanvulling().subscribe((data) => {
      this.allKenmerken = data;
    });
    this.kenmerkenService.getZooBranchecodeAanvullingBy(this.subEntiteitBsn).subscribe(data => {
      this.selectedChildKenmerken = data;
    });
  }

  onCancel(dialogRef: MatDialogRef<KenmerkenPopupComponent>) {
    dialogRef.close();
  }

  saveKenmerken(selectedSubKenmerken: ZooEntiteitBranchecodeAanvulling[]) {
    const selectedIds = selectedSubKenmerken.map(bcav => bcav.id);
    const unselectedKenmerken = this.selectedChildKenmerken.filter(bcav => !selectedIds.includes(bcav.id));
    if (selectedSubKenmerken.map.length > 0 || unselectedKenmerken.length > 0) {
      this.onKenmerkenWillBeUpdated.emit();
      this.kenmerkenService.updateEntiteitKenmerkSelections(this.subEntiteitBsn, KenmerkType.BCAV, selectedSubKenmerken, unselectedKenmerken, this.getLoggingId(), this.entiteitnummer).subscribe( () => {
        this.onKenmerkenUpdated.emit();
      });
    }
    this.selectedChildKenmerken = selectedSubKenmerken;
    this.dialogRef.close();
  }

  getLoggingId(): string {
    return this.loggingId;
  }
}
