import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KbsStepperComponent } from './kbs-stepper.component';

describe('KbsStepperComponent', () => {
  let component: KbsStepperComponent;
  let fixture: ComponentFixture<KbsStepperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KbsStepperComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KbsStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
