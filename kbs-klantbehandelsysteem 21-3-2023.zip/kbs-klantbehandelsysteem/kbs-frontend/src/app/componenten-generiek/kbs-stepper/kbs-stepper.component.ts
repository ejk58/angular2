import {Component, Input, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {KbsStep, KbsStepId} from './kbs-step';
import {EntiteitService} from '../../services/entiteit.service';
import {KenmerkenService} from '../../services/kenmerken.service';
import {EntiteitKenmerk} from '../../interfaces/EntiteitKenmerk';
import {KlantsessieStatus} from '../../entiteit/entiteit-klantseessie/klantsessie-steps/klantsessie-status';
import {KlantsessieStatusService} from '../../services/klantsessie-status.service';
import {LoggingService} from '../../services/logging.service';

@Component({
  selector: 'app-kbs-stepper',
  templateUrl: './kbs-stepper.component.html',
  styleUrls: ['./kbs-stepper.component.scss']
})
export class KbsStepperComponent implements OnInit  {

  @Input() steps: KbsStep[] = [];
  @Input() hasProcessingRole : boolean;

  private readonly MIN_INDEX: number = 0;
  private MAX_INDEX: number = 0;

  activeStepId: KbsStepId;

  isVisiblePreviousButton: boolean;
  isVisibleNextButton: boolean;

  middel: EntiteitKenmerk;
  private entiteitnummer: number;
  middelStr: string;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private readonly klantsessieStatusService: KlantsessieStatusService,
    private readonly entiteitService: EntiteitService,
    private readonly kenmerkenService: KenmerkenService,
    private readonly loggingService: LoggingService,
  ) {}

  ngOnInit() {
    this.entiteitService.getSearchEntiteitNummer((nr) => {
      this.entiteitnummer = nr;
      this.activatedRoute.params.subscribe(params => {
        this.middelStr = params['middel'];
        this.kenmerkenService.getMiddelByName(this.middelStr).subscribe(middel => {
          this.middel = middel;
          this.stepperReset();
        });

      })
    });
  }

  navigateToStep(kbsStep: KbsStep) {
    if(kbsStep.status === 'DISABLED') return;
    if(kbsStep.stepId === this.activeStepId) return;
    this.loadStepsStatus();
    this.setActiveStepId(kbsStep.stepId);
  }

  private setActiveStepId(kbsStepId: KbsStepId): void {
    this.loggingService.setLoggingInfo(null);
    this.activeStepId = kbsStepId;
    this.updateVisibilityNavigationButtons();
  }

  private updateVisibilityNavigationButtons() {
    this.isVisiblePreviousButton = this.showPreviousButton();
    this.isVisibleNextButton = this.showNextButton();
  }

  private stepperReset() {
    this.loadStepsStatus();
    this.MAX_INDEX = this.steps.length - 1;
    this.setActiveStepId(this.steps[0].stepId);
  }

  navigateToPreviousStep() {
    this.loadStepsStatus();
    this.setActiveStepId(this.steps[this.getActiveIndex(this.activeStepId) - 1].stepId);
  }

  navigateToNextStep() {
    this.loadStepsStatus();
    this.setActiveStepId(this.steps[this.getActiveIndex(this.activeStepId) + 1].stepId);
  }

  private showPreviousButton(): boolean {
    if(this.steps[this.getActiveIndex(this.activeStepId) - 1]?.status === 'DISABLED'){
      return false;
    }
    return this.getActiveIndex(this.activeStepId) !== this.MIN_INDEX;
  }

  private showNextButton(): boolean {
    if(this.steps[this.getActiveIndex(this.activeStepId) + 1]?.status === 'DISABLED'){
      return false;
    }
    return this.getActiveIndex(this.activeStepId) !== this.MAX_INDEX;
  }

  loadStepsStatus(): void{
    this.klantsessieStatusService.getKlantsessieStatus(this.entiteitnummer, this.middel?.id).subscribe(klantsessieStatus => {
      this.klantsessieStatusToStepper(klantsessieStatus);
      this.updateVisibilityNavigationButtons();
    } )
  }

  private klantsessieStatusToStepper(klantsessieStatus: KlantsessieStatus){
    this.steps.forEach(step => {
      if(step.stepId == "ZOOEF"){
        step.status = klantsessieStatus.zooefStatus;
      } else if (step.stepId == "COMPLIANCE"){
        step.status = klantsessieStatus.complianceStatus;
      } else if (step.stepId == "STRATEGIE"){
        step.status = klantsessieStatus.strategieStatus;
      } else if (step.stepId == "VOORBEREIDING_AFRONDEN"){
        step.status = klantsessieStatus.voorbereidingAfrondenStatus;
      } else {
        return;
      }
    });
  }

  private getActiveIndex(kbsStepId: KbsStepId): number {
    return this.steps.findIndex(kbsStep => kbsStep.stepId === kbsStepId);
  }
}
