export type KbsStepId = 'ZOOEF' | 'COMPLIANCE' | 'STRATEGIE' | 'VOORBEREIDING_AFRONDEN';
export type KbsStepStatus = 'DISABLED' | 'INITIAL' | 'TOUCHED' | 'COMPLETED' | 'DONE';

export interface KbsStep {
  stepId: KbsStepId;
  label: string;
  status: KbsStepStatus;
  icon?: string;
}
