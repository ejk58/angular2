export const PATH_PARAM_NUMMER = 'nummer';

export const MSG_KEY_NO_ENTITY_SELECTED = 'noEntitySelected';

const TABLE_NUMBER_OF_ROWS_TO_DISPLAY_PER_PAGE_OPTIONS = [10, 25, 50, 100];

export const DEFAULT_TABLE_SETTINGS = {
  rowsPerPageOptions: TABLE_NUMBER_OF_ROWS_TO_DISPLAY_PER_PAGE_OPTIONS,
  rows: TABLE_NUMBER_OF_ROWS_TO_DISPLAY_PER_PAGE_OPTIONS[0],
  showCurrentPageReport: true,
  currentPageReportTemplate: "{first} tot {last} van {totalRecords} resultaten"
};
