import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import localeNL from '@angular/common/locales/nl';
import {AppComponent} from './app.component';
import {CurrencyPipe, DatePipe, HashLocationStrategy, LocationStrategy, registerLocaleData} from '@angular/common';
import {AuthenticatedUserComponent} from './authenticated-user/authenticated-user.component';
import {RouterModule} from '@angular/router';
import {HTTP_INTERCEPTORS} from '@angular/common/http';
import {UserService} from './services/user.service';
import {APP_ROUTES} from './app.routing';
import {DashboardComponent} from './dashboard/dashboard.component';
import {FeedbackApi, FrameworkModule, UserApi} from 'iv-framework-lib';
import {AuthGuard} from './services/auth-guard.service';
import {AuthInterceptor} from './services/auth-interceptor';
import {ZoekenEntiteitComponent} from './entiteiten/zoeken-entiteit/zoeken-entiteit.component';
import {ReactiveFormsModule} from '@angular/forms';
import {EntiteitListComponent} from './entiteiten/entiteit-list/entiteit-list.component';
import {BasisComponent} from './entiteit/entiteit-algemene-gegevens/basis/basis.component';
import {KenmerkenComponent} from './entiteit/entiteit-algemene-gegevens/kenmerken/kenmerken.component';
import {EntiteitenComponent} from './entiteiten/entiteiten.component';
import {FeedbackService} from './services/feedback.service';
import {BooleanStringPipe} from './pipes/boolean-string.pipe';
import {CurrencyNLPipe} from './pipes/currency-nl.pipe';
import {TabViewModule} from 'primeng/tabview';
import {CardModule} from 'primeng/card';
import {PanelModule} from 'primeng/panel';
import {SamenstellingComponent} from './entiteit/entiteit-algemene-gegevens/samenstelling/samenstelling.component';
import {EntiteitDashboardComponent} from './entiteit/entiteit-dashboard/entiteit-dashboard.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {InputTextModule} from 'primeng/inputtext';
import {DividerModule} from 'primeng/divider';
import {FieldsetModule} from 'primeng/fieldset';
import {BadgeModule} from 'primeng/badge';
import {BehandelvoorstellenActiviteitenComponent} from './entiteit/entiteit-dashboard/behandelvoorstellen-activiteiten/behandelvoorstellen-activiteiten.component';
import {OverigekenmerkenComponent} from './entiteit/entiteit-dashboard/overigekenmerken/overigekenmerken.component';
import {InfoGraphicComponent} from './entiteit/entiteit-dashboard/info-graphic/info-graphic.component';
import {EntiteitZichtOpOrganisatieComponent} from './entiteit/entiteit-zicht-op-organisatie/entiteit-zicht-op-organisatie.component';
import {EntiteitZichtOpFiscaliteitComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/entiteit-zicht-op-fiscaliteit.component';
import {EntiteitStrategieComponent} from './entiteit/entiteit-strategie/entiteit-strategie.component';
import {EntiteitVerantwoordenComponent} from './entiteit/entiteit-verantwoorden/entiteit-verantwoorden.component';
import {EntiteitAlgemeneGegevensComponent} from './entiteit/entiteit-algemene-gegevens/entiteit-algemene-gegevens.component';
import {ZofOverigeMiddelenComponent} from "./entiteit/entiteit-zicht-op-fiscaliteit/zof-overigemiddelen/zof-overigemiddelen.component";
import {ZooAardvanorganisatieComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-aardvanorganisatie/zoo-aardvanorganisatie.component';
import {ZooKenmerkenComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-kenmerken/zoo-kenmerken.component';
import {ZooHelptekstComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-helptekst/zoo-helptekst.component';
import {ZooOmvangComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-omvang/zoo-omvang.component';
import {ZooComplexiteitComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-complexiteit/zoo-complexiteit.component';
import {ZooTop100Component} from './entiteit/entiteit-zicht-op-organisatie/zoo-top100/zoo-top100.component';
import {ZooInenexterneKenmerkenComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-inenexterne-kenmerken/zoo-inenexterne-kenmerken.component';
import {MatDialogModule} from '@angular/material/dialog';
import {MatButtonModule} from '@angular/material/button';
import {TextPopEditorComponent} from './componenten-generiek/text-pop-editor/text-pop-editor.component';
import {InputCurrencyComponent} from './componenten-generiek/input-currency/input-currency.component';
import {MultiSelectModule} from 'primeng/multiselect';
import {InputNumberComponent} from './componenten-generiek/input-number/input-number.component';
import {InputNumberModule} from 'primeng/inputnumber';
import {TooltipEditorComponent} from './componenten-generiek/tooltip-editor/tooltip-editor.component';
import {MessagesModule} from 'primeng/messages';
import {ConfirmationService, MessageService} from 'primeng/api';
import {MatTooltipModule} from '@angular/material/tooltip';
import {BedrijfsactiviteitenComponent} from './entiteit/bedrijfsactiviteiten/bedrijfsactiviteiten.component';
import {CijferbeoordelingComponent} from './entiteit/cijferbeoordeling/cijferbeoordeling.component';
import {ConcernstructuurComponent} from './entiteit/concernstructuur/concernstructuur.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MultiselectToolComponent} from './entiteit/entiteit-zicht-op-organisatie/multiselect-tool/multiselect-tool.component';
import {CheckboxModule} from 'primeng/checkbox';
import {ZooCbOrganisatieomvangComponent} from './entiteit/cijferbeoordeling/zoo-cb-organisatieomvang/zoo-cb-organisatieomvang.component';
import {ZooCbVpbComponent} from './entiteit/cijferbeoordeling/zoo-cb-vpb/zoo-cb-vpb.component';
import {ZooCbOmzetbelastingComponent} from './entiteit/cijferbeoordeling/zoo-cb-omzetbelasting/zoo-cb-omzetbelasting.component';
import {ZooCbLoonheffingComponent} from './entiteit/cijferbeoordeling/zoo-cb-loonheffing/zoo-cb-loonheffing.component';
import {ZooCbInkomstenbelastingComponent} from './entiteit/cijferbeoordeling/zoo-cb-inkomstenbelasting/zoo-cb-inkomstenbelasting.component';
import {ZooCbInvorderingComponent} from './entiteit/cijferbeoordeling/zoo-cb-invordering/zoo-cb-invordering.component';
import {ZooCbOverigemiddelenComponent} from './entiteit/cijferbeoordeling/zoo-cb-overigemiddelen/zoo-cb-overigemiddelen.component';
import {ZooCbTabpanelComponent} from './entiteit/cijferbeoordeling/tabpanel/zoo-cb-tabpanel.component';
import {TabviewComponent} from './componenten-generiek/tabview/tabview.component';
import {ZooCbVennootschapsbelastingComponent} from './entiteit/cijferbeoordeling/zoo-cb-vennootschapsbelasting/zoo-cb-vennootschapsbelasting.component';
import {BranchecodeAanvullingComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-aardvanorganisatie/branchecode-aanvulling/branchecode-aanvulling.component';
import {KenmerkenPopupComponent} from './componenten-generiek/kenmerken-popup/kenmerken-popup.component';
import {MiddelspecifiekeKenmerkenComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifieke-kenmerken/middelspecifieke-kenmerken.component';
import {MiddelspecifiekeRiscosComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifieke-riscos/middelspecifieke-riscos.component';
import {MenuModule} from 'primeng/menu';
import {MiddelspecifiekTabsComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifiek-tabs/middelspecifiek-tabs.component';
import {ConfirmPopupModule} from 'primeng/confirmpopup';
import {KbsButtonComponent} from './componenten-generiek/kbs-button/kbs-button.component';
import {OperationsService} from './services/operations.service';
import {BranchecodeAanvullingTreeTableComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-aardvanorganisatie/branchecode-aanvulling-tree-table/branchecode-aanvulling-tree-table.component';
import {TreeTableModule} from 'primeng/treetable';
import {EntiteitLetsGoComponent} from './entiteit/entiteit-lets-go/entiteit-lets-go.component';
import {EntiteitLogboekComponent} from './entiteit/entiteit-logboek/entiteit-logboek.component';
import {EntiteitKlantdocumentenComponent} from './entiteit/entiteit-klantdocumenten/entiteit-klantdocumenten.component';
import {EntiteitBehandelteamComponent} from './entiteit/entiteit-algemene-gegevens/entiteit-behandelteam/entiteit-behandelteam.component';
import {EntiteitContactgegevensComponent} from './entiteit/entiteit-algemene-gegevens/entiteit-contactgegevens/entiteit-contactgegevens.component';
import {SubentiteitenTableComponent} from './entiteit/entiteit-zicht-op-organisatie/zoo-aardvanorganisatie/subentiteiten-table/subentiteiten-table.component';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {CalendarModule} from 'primeng/calendar';
import {AlgemeneKenmerkenEnAttentiepuntenComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifieke-kenmerken/algemene-kenmerken-en-attentiepunten/algemene-kenmerken-en-attentiepunten.component';
import {EntiteitKlantbeeldAnalyseComponent} from './entiteit/entiteit-klantbeeld-analyse/entiteit-klantbeeld-analyse.component';
import {EntiteitBehandelvoorstellenEnActiviteitenComponent} from './entiteit/entiteit-behandelvoorstellen-en-opdrachten/entiteit-behandelvoorstellen-en-activiteiten.component';
import {EntiteitOverzichtBehandelactiviteitenComponent} from './entiteit/entiteit-behandelvoorstellen-en-opdrachten/entiteit-overzicht-behandelactiviteiten/entiteit-overzicht-behandelactiviteiten.component';
import {BehandelactiviteitAanmakenPopupComponent} from './entiteit/entiteit-behandelvoorstellen-en-opdrachten/behandelactiviteit-aanmaken-popup/behandelactiviteit-aanmaken-popup.component';
import {EntiteitBehandelplangegevensComponent} from './entiteit/entiteit-behandelplangegevens/entiteit-behandelplangegevens.component';
import {EntiteitKlantseessieComponent} from './entiteit/entiteit-klantseessie/entiteit-klantseessie.component';
import {SharedModule} from './shared/shared.module';
import {MessagePollerComponent} from './maintenance-message/message-poller/message-poller.component';
import {EntiteitInfoComponent} from './componenten-generiek/entiteit-info/entiteit-info.component';
import {AddRiscosPopupComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifieke-kenmerken/add-riscos-popup/add-riscos-popup.component';
import {DialogService, DynamicDialogModule} from "primeng/dynamicdialog";
import {AbbreviateMiddelPipe} from "./pipes/abbreviate-middel.pipe";
import {MessageModule} from 'primeng/message';
import {KbsMessagesComponent} from './componenten-generiek/kbs-messages/kbs-messages.component';
import {MiddelspecifiekRisicosTableComponent} from './entiteit/entiteit-zicht-op-fiscaliteit/middelspecifiek-risicos-table/middelspecifiek-risicos-table.component';
import {AutoFocusDirective} from './directives/auto-focus.directive';
import {LoggingFooterComponent} from './componenten-generiek/logging-footer/logging-footer.component';
import {LoggingInfoComponent} from './componenten-generiek/logging-info/logging-info.component';
import {ZocComplianceComponent} from './entiteit/entiteit-zicht-op-compliance/zoc-compliance/zoc-compliance.component';
import {ZocCompliancePerProcesComponent} from './entiteit/entiteit-zicht-op-compliance/zoc-compliance/zoc-compliance-per-proces/zoc-compliance-per-proces.component';
import {PerProcesTableRowComponent} from './entiteit/entiteit-zicht-op-compliance/zoc-compliance/zoc-compliance-per-proces/per-proces-table-row/per-proces-table-row.component';
import {ZocBeheersmaatregelenComponent} from './entiteit/entiteit-zicht-op-compliance/zoc-beheersmaatregelen/zoc-beheersmaatregelen.component';
import {RisicoOverviewComponent} from "./entiteit/entiteit-zicht-op-compliance/zoc-beheersmaatregelen/risico-overview/risico-overview.component";
import {ColumnFilterComponent} from "./componenten-generiek/column-filter/column-filter.component";
import {VerdiepingFiscaleBeheersingComponent} from "./entiteit/entiteit-zicht-op-compliance/zoc-beheersmaatregelen/verdieping-fiscale-beheersing/verdieping-fiscale-beheersing.component";
import {DateNLPipe} from "./pipes/date-nl.pipe";
import {EntiteitZooKlantbeeldanalyseComponent} from './entiteit/entiteit-zoo-klantbeeldanalyse/entiteit-zoo-klantbeeldanalyse.component';
import {ZofKlantbeeldanalyseComponent} from './entiteit/entiteit-zof-klantbeeldanalyse/zof-klantbeeldanalyse.component';

import {ZooKlantbeeldanalyseBedrijfsactiviteitenComponent} from './entiteit/entiteit-zoo-klantbeeldanalyse/zoo-klantbeeldanalyse-bedrijfsactiviteiten/zoo-klantbeeldanalyse-bedrijfsactiviteiten.component';
import {ZooKlantbeeldanalyseCijferbeoordelingComponent} from './entiteit/entiteit-zoo-klantbeeldanalyse/zoo-klantbeeldanalyse-cijferbeoordeling/zoo-klantbeeldanalyse-cijferbeoordeling.component';
import {EntiteitKlantbeeldAnalyseResultatenComponent} from './entiteit/entiteit-klantbeeld-analyse/entiteit-klantbeeld-analyse-resultaten/entiteit-klantbeeld-analyse-resultaten.component';
import {EntiteitKlantbeeldAnalyseOverzichtZooComponent} from './entiteit/entiteit-klantbeeld-analyse/entiteit-klantbeeld-analyse-overzicht-zoo/entiteit-klantbeeld-analyse-overzicht-zoo.component';
import {EntiteitKlantbeeldAnalyseOverzichtZofComponent} from './entiteit/entiteit-klantbeeld-analyse/entiteit-klantbeeld-analyse-overzicht-zof/entiteit-klantbeeld-analyse-overzicht-zof.component';
import {EntiteitKlantbeeldAnalyseOverzichtZocComponent} from './entiteit/entiteit-klantbeeld-analyse/entiteit-klantbeeld-analyse-overzicht-zoc/entiteit-klantbeeld-analyse-overzicht-zoc.component';
import {EntiteitKlantbeeldAnalyseOverzichtBeheersmaatregelenComponent} from './entiteit/entiteit-klantbeeld-analyse/entiteit-klantbeeld-analyse-overzicht-beheersmaatregelen/entiteit-klantbeeld-analyse-overzicht-beheersmaatregelen.component';
import { DropdownComponent } from './componenten-generiek/dropdown/dropdown.component';
import { CheckboxComponent } from './componenten-generiek/checkbox/checkbox.component';
import {
  ZocBevindingenKlantbeeldanalyseComponent
} from './entiteit/entiteit-zicht-op-compliance/zoc-bevindingen-klantbeeldanalyse/zoc-bevindingen-klantbeeldanalyse.component';
import {
  BevindingenComplianceKlantbeeldanalyseComponent
} from './entiteit/entiteit-zicht-op-compliance/zoc-bevindingen-klantbeeldanalyse/bevindingen-compliance-klantbeeldanalyse/bevindingen-compliance-klantbeeldanalyse.component';
import {
  BevindingenBeheersmaatregelenKlantbeeldanalyseComponent
} from './entiteit/entiteit-zicht-op-compliance/zoc-bevindingen-klantbeeldanalyse/bevindingen-beheersmaatregelen-klantbeeldanalyse/bevindingen-beheersmaatregelen-klantbeeldanalyse.component';

registerLocaleData(localeNL, 'nl');

@NgModule({
    declarations: [
        AppComponent,
        DashboardComponent,
        AuthenticatedUserComponent,
        ZoekenEntiteitComponent,
        EntiteitListComponent,
        BasisComponent,
        KenmerkenComponent,
        EntiteitenComponent,
        BooleanStringPipe,
        CurrencyNLPipe,
        SamenstellingComponent,
        EntiteitZichtOpOrganisatieComponent,
        EntiteitZichtOpFiscaliteitComponent,
        EntiteitStrategieComponent,
        EntiteitVerantwoordenComponent,
        EntiteitBehandelplangegevensComponent,
        EntiteitDashboardComponent,
        BehandelvoorstellenActiviteitenComponent,
        OverigekenmerkenComponent,
        InfoGraphicComponent,
        EntiteitAlgemeneGegevensComponent,
        ZofOverigeMiddelenComponent,
        ZooHelptekstComponent,
        ZooAardvanorganisatieComponent,
        ZooKenmerkenComponent,
        ZooHelptekstComponent,
        ZooOmvangComponent,
        ZooComplexiteitComponent,
        ZooTop100Component,
        ZooInenexterneKenmerkenComponent,
        TextPopEditorComponent,
        InputNumberComponent,
        InputCurrencyComponent,
        TooltipEditorComponent,
        BedrijfsactiviteitenComponent,
        CijferbeoordelingComponent,
        ConcernstructuurComponent,
        MultiselectToolComponent,
        ZooCbOrganisatieomvangComponent,
        ZooCbVpbComponent,
        ZooCbOmzetbelastingComponent,
        ZooCbLoonheffingComponent,
        ZooCbInkomstenbelastingComponent,
        ZooCbInvorderingComponent,
        ZooCbOverigemiddelenComponent,
        ZooCbTabpanelComponent,
        TabviewComponent,
        ZooCbVennootschapsbelastingComponent,
        BranchecodeAanvullingComponent,
        KenmerkenPopupComponent,
        ZooCbVennootschapsbelastingComponent,
        MiddelspecifiekeKenmerkenComponent,
        MiddelspecifiekeRiscosComponent,
        MiddelspecifiekTabsComponent,
        KbsButtonComponent,
        BranchecodeAanvullingTreeTableComponent,
        EntiteitLetsGoComponent,
        EntiteitLogboekComponent,
        EntiteitKlantdocumentenComponent,
        EntiteitBehandelteamComponent,
        EntiteitContactgegevensComponent,
        SubentiteitenTableComponent,
        AlgemeneKenmerkenEnAttentiepuntenComponent,
        EntiteitKlantbeeldAnalyseComponent,
        EntiteitBehandelvoorstellenEnActiviteitenComponent,
        EntiteitOverzichtBehandelactiviteitenComponent,
        AlgemeneKenmerkenEnAttentiepuntenComponent,
        EntiteitOverzichtBehandelactiviteitenComponent,
        BehandelactiviteitAanmakenPopupComponent,
        MessagePollerComponent,
        EntiteitKlantseessieComponent,
        EntiteitInfoComponent,
        AddRiscosPopupComponent,
        MiddelspecifiekRisicosTableComponent,
        AutoFocusDirective,
        KbsMessagesComponent,
        AutoFocusDirective,
        LoggingFooterComponent,
        LoggingInfoComponent,
        ZocComplianceComponent,
        ZocCompliancePerProcesComponent,
        PerProcesTableRowComponent,
        ZocBeheersmaatregelenComponent,
        PerProcesTableRowComponent,
        RisicoOverviewComponent,
        ColumnFilterComponent,
        VerdiepingFiscaleBeheersingComponent,
        EntiteitZooKlantbeeldanalyseComponent,
        ZooKlantbeeldanalyseBedrijfsactiviteitenComponent,
        ZooKlantbeeldanalyseCijferbeoordelingComponent,
        ZofKlantbeeldanalyseComponent,
        EntiteitKlantbeeldAnalyseResultatenComponent,
        EntiteitKlantbeeldAnalyseOverzichtZooComponent,
        EntiteitKlantbeeldAnalyseOverzichtZofComponent,
        EntiteitKlantbeeldAnalyseOverzichtZocComponent,
        EntiteitKlantbeeldAnalyseOverzichtBeheersmaatregelenComponent,
        DropdownComponent,
        CheckboxComponent,
        ZocBevindingenKlantbeeldanalyseComponent,
        BevindingenComplianceKlantbeeldanalyseComponent,
        BevindingenBeheersmaatregelenKlantbeeldanalyseComponent

    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        FrameworkModule,
        RouterModule.forRoot(APP_ROUTES),
        TabViewModule,
        CardModule,
        PanelModule,
        InputTextModule,
        DividerModule,
        FieldsetModule,
        BadgeModule,
        MatDialogModule,
        MatButtonModule,
        ReactiveFormsModule,
        MultiSelectModule,
        InputNumberModule,
        MessagesModule,
        MatTooltipModule,
        MatCheckboxModule,
        CheckboxModule,
        MenuModule,
        ConfirmPopupModule,
        TreeTableModule,
        CalendarModule,
        DragDropModule,
        SharedModule,
        DynamicDialogModule,
        MessageModule
    ],
    entryComponents: [
        TextPopEditorComponent,
    ],
    providers: [
        {
            provide: LocationStrategy,
            useClass: HashLocationStrategy
        },
        UserService,
        {
            provide: UserApi,
            useExisting: UserService
        },
        FeedbackService,
        {
            provide: FeedbackApi,
            useExisting: FeedbackService
        },
        AuthGuard,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthInterceptor,
            multi: true
        },
        CurrencyPipe,
        DatePipe,
        MessageService,
        ConfirmationService,
        OperationsService,
        DialogService,
        AbbreviateMiddelPipe,
        DateNLPipe,
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
