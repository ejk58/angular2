import {DashboardComponent} from './dashboard/dashboard.component';
import {Routes} from '@angular/router';
import {AuthenticatedUserComponent} from './authenticated-user/authenticated-user.component';
import {AuthGuard} from './services/auth-guard.service';
import {SignInComponent} from 'iv-framework-lib';
import {EntiteitenComponent} from './entiteiten/entiteiten.component';
import {EntiteitZichtOpOrganisatieComponent} from "./entiteit/entiteit-zicht-op-organisatie/entiteit-zicht-op-organisatie.component";
import {EntiteitZichtOpFiscaliteitComponent} from "./entiteit/entiteit-zicht-op-fiscaliteit/entiteit-zicht-op-fiscaliteit.component";
import {EntiteitStrategieComponent} from "./entiteit/entiteit-strategie/entiteit-strategie.component";
import {EntiteitBehandelplangegevensComponent} from "./entiteit/entiteit-behandelplangegevens/entiteit-behandelplangegevens.component";
import {EntiteitVerantwoordenComponent} from "./entiteit/entiteit-verantwoorden/entiteit-verantwoorden.component";
import {BedrijfsactiviteitenComponent} from './entiteit/bedrijfsactiviteiten/bedrijfsactiviteiten.component';
import {CijferbeoordelingComponent} from './entiteit/cijferbeoordeling/cijferbeoordeling.component';
import {ConcernstructuurComponent} from './entiteit/concernstructuur/concernstructuur.component';
import {EntiteitAlgemeneGegevensComponent} from "./entiteit/entiteit-algemene-gegevens/entiteit-algemene-gegevens.component";
import {EntiteitDashboardComponent} from "./entiteit/entiteit-dashboard/entiteit-dashboard.component";
import {EntiteitLetsGoComponent} from "./entiteit/entiteit-lets-go/entiteit-lets-go.component";
import {EntiteitKlantdocumentenComponent} from "./entiteit/entiteit-klantdocumenten/entiteit-klantdocumenten.component";
import {EntiteitLogboekComponent} from "./entiteit/entiteit-logboek/entiteit-logboek.component";
import {EntiteitKlantbeeldAnalyseComponent} from "./entiteit/entiteit-klantbeeld-analyse/entiteit-klantbeeld-analyse.component";
import {EntiteitBehandelvoorstellenEnActiviteitenComponent} from "./entiteit/entiteit-behandelvoorstellen-en-opdrachten/entiteit-behandelvoorstellen-en-activiteiten.component";
import {EntiteitInfoHeaderResolver} from './resolvers/entiteit-info-header-resolver.service';
import {LoggingVisibilityResolver} from './resolvers/logging-visibility-resolver.service';
import {ZocComplianceComponent} from './entiteit/entiteit-zicht-op-compliance/zoc-compliance/zoc-compliance.component';
import {ZocBevindingenKlantbeeldanalyseComponent} from './entiteit/entiteit-zicht-op-compliance/zoc-bevindingen-klantbeeldanalyse/zoc-bevindingen-klantbeeldanalyse.component';
import {ZocBeheersmaatregelenComponent} from './entiteit/entiteit-zicht-op-compliance/zoc-beheersmaatregelen/zoc-beheersmaatregelen.component';
import {EntiteitZooKlantbeeldanalyseComponent} from './entiteit/entiteit-zoo-klantbeeldanalyse/entiteit-zoo-klantbeeldanalyse.component';
import {EntiteitKlantbeeldAnalyseResultatenComponent} from './entiteit/entiteit-klantbeeld-analyse/entiteit-klantbeeld-analyse-resultaten/entiteit-klantbeeld-analyse-resultaten.component';
import {ZofKlantbeeldanalyseComponent} from "./entiteit/entiteit-zof-klantbeeldanalyse/zof-klantbeeldanalyse.component";
import {ZofOverigeMiddelenComponent} from "./entiteit/entiteit-zicht-op-fiscaliteit/zof-overigemiddelen/zof-overigemiddelen.component";

export const APP_ROUTES: Routes = [
  { path: 'signin', component: SignInComponent },
  { path: 'authenticated', component: AuthenticatedUserComponent, canActivate: [AuthGuard],
    resolve: { entiteitInfoHeader: EntiteitInfoHeaderResolver, loggingVisibility: LoggingVisibilityResolver },
    runGuardsAndResolvers: 'always' ,
    children: [
      { path: '', redirectTo: 'entiteit-zoeken', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'entiteit-zoeken', component: EntiteitenComponent, data: {showEntiteitInfoHeader: false, showLoggingFooter: false} },
      { path: 'raadplegen-klant-gegevens',
        children: [
          { path: '', redirectTo: 'algemene-gegevens', pathMatch: 'full' },
          { path: 'algemene-gegevens', component: EntiteitAlgemeneGegevensComponent},
          { path: 'dashboard', component: EntiteitDashboardComponent},
          { path: 'lets-go', component: EntiteitLetsGoComponent},
          { path: 'logboek', component: EntiteitLogboekComponent},
          { path: 'Klantdocumenten', component: EntiteitKlantdocumentenComponent}
        ]
      },
      { path: 'zicht-op-organisatie/bedrijfsactiviteiten', component: EntiteitZichtOpOrganisatieComponent },
      { path: 'zoo/klantbeeldanalyse', component: EntiteitZooKlantbeeldanalyseComponent   },
      { path: 'zicht-op-fiscaliteit', children: [
          { path: 'overige-middelen', component: ZofOverigeMiddelenComponent},
          { path: '**', component: EntiteitZichtOpFiscaliteitComponent}
        ]
      },
      { path: 'zof-klantbeeldanalyse', component: ZofKlantbeeldanalyseComponent},
      { path: 'klantsessie', loadChildren: () => import('./entiteit/entiteit-klantseessie/klantsessie.module').then(m => m.KlantsessieModule)
      },
      { path: 'zicht-op-compliance',
        children: [
          { path: '', redirectTo: 'compliance', pathMatch: 'full' },
          { path: 'compliance', component: ZocComplianceComponent},
          { path: 'beheersmaatregelen',  component: ZocBeheersmaatregelenComponent},
          { path: 'bevindingen-tbv-klantbeeldanalyse', component: ZocBevindingenKlantbeeldanalyseComponent},
        ]
      },
      { path: 'klantbeeld-analyse', children:[
          { path: '', redirectTo: 'overzicht', pathMatch: 'full' },
          { path: 'overzicht', component: EntiteitKlantbeeldAnalyseComponent},
          { path: 'resultaten', component: EntiteitKlantbeeldAnalyseResultatenComponent }
        ]
      },
      { path: 'strategie', component: EntiteitStrategieComponent },
      { path: 'behandelvoorstellen', component: EntiteitBehandelvoorstellenEnActiviteitenComponent },
      { path: 'verantwoorden', component: EntiteitVerantwoordenComponent },
      { path: 'behandelplangegevens', component: EntiteitBehandelplangegevensComponent },
      { path: 'bedrijfsactiviteiten', component: BedrijfsactiviteitenComponent },
      { path: 'cijferbeoordeling', component: CijferbeoordelingComponent },
      { path: 'concernstructuur', component: ConcernstructuurComponent   },
    ]
  },
  { path: '', component: SignInComponent },
  { path: '**', component: SignInComponent },
]
