import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-authenticated-user',
  templateUrl: './authenticated-user.component.html',
  styleUrls: ['./authenticated-user.component.scss']
})
export class AuthenticatedUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
