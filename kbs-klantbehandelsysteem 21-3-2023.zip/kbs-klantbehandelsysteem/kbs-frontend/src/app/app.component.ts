import {Component, OnInit} from '@angular/core';
import {ConfigurationService, FrameworkConfigSettings, MenuItem, MenuService} from 'iv-framework-lib';
import {EntiteitService} from './services/entiteit.service';
import {KenmerkenService} from './services/kenmerken.service';
import {KenmerkType} from './services/kenmerkType';
import * as menu from './app.menu';
import {MSG_KEY_NO_ENTITY_SELECTED} from './app.constants';
import {EntiteitNummerAccessCheckService} from './services/entiteit-nummer-access-check.service';

export const urlZichtOpFiscaliteit: string = 'authenticated/zicht-op-fiscaliteit';
export const urlKlantsessie: string = 'authenticated/klantsessie';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  readonly MSG_KEY_NO_ENTITY_SELECTED = MSG_KEY_NO_ENTITY_SELECTED;

  zichtOpFiscaliteitMenuItem: MenuItem = {
    text: 'Zicht op fiscaliteit',
    route: urlZichtOpFiscaliteit
  };

  klantsessieMenuItem: MenuItem = {
    text: 'Klantsessie',
    route: urlKlantsessie
  };

  constructor(private readonly menuService: MenuService,
              private readonly configService: ConfigurationService,
              private readonly entiteitService: EntiteitService,
              private readonly kenmerkenService: KenmerkenService,
              private readonly entiteitNummerAccessCheckService: EntiteitNummerAccessCheckService
  ) {
    const config: FrameworkConfigSettings = {
      applicationName: 'Klantbehandelsysteem',
      useFeedback: true,
      //removing (or setting to false) feedbackFormUseGebruikersNaam will reset Feedback to name and email instead of userId
      feedbackFormUseGebruikersNaam: true,
      //default 999999
      feedbackFormMeldingCharLimit: 32672,
      hideLinkToBelastingdienst: true,
      hideButtonToSwitchVerticalMenuToTopStyle: true,
      showLeftIconForMenuItem: false
    }
    configService.configure(config);

    menuService.items = [menu.zoekenKlantMenuItem];
  }

  public ngOnInit(): void {
    this.loadMenuItems();

    this.kenmerkenService.updatedKenmerkType$.subscribe(savedKenmerkType => {
      if (savedKenmerkType === KenmerkType.MID) {
        this.loadMenuItems();
      }
    });
  }

  public loadMenuItems(): void {
    this.entiteitService.searchEntiteit.subscribe((entiteitNummer) => {
      this.updateMenuItems(entiteitNummer);
    });
  }

  public updateMenuItems(entiteitNummer: number): void {
    if (entiteitNummer > 0) {
      this.entiteitNummerAccessCheckService.getEntiteitNummerAccess(entiteitNummer).subscribe(toegang => {
        if (toegang.toegestaan) {
          this.menuService.items = [menu.zoekenKlantMenuItem,
            menu.raadplegenKlantMenuItem,
            menu.zichtOpOrganisatieMenuItem,
            this.zichtOpFiscaliteitMenuItem,
            this.klantsessieMenuItem,
            menu.zichtOpComplianceMenuItem,
            menu.klantbeeldanalyseMenuItem,
            menu.strategieMenuItem,
            menu.behandelvoorstellenEnActiviteitenMenuItem,
            menu.verantwoordenMenuItem,
            menu.behandelplangegevensMenuItem];

          this.kenmerkenService.getSelectedMiddelen(entiteitNummer).subscribe(data => {
            this.updateZichtOpFiscaliteitMenuItem(data);
            this.updateKlantsessieMenuItem(data);
          });
        } else {
          this.menuService.items = [menu.zoekenKlantMenuItem, menu.algemeneGegevensMenuItem];
        }
      });
    } else {
      this.menuService.items = [menu.zoekenKlantMenuItem];
    }
  }

  private updateZichtOpFiscaliteitMenuItem(data: any): void {
    const middelSubmenuZoF: MenuItem[] = data.map((middel) => ({
      text: middel.kenmerk,
      route: urlZichtOpFiscaliteit + "/" + middel.kenmerk
    }));

    this.zichtOpFiscaliteitMenuItem.submenu = [...middelSubmenuZoF, ...menu.zofStaticSubmenuItems];
  }

  private updateKlantsessieMenuItem(data: any): void {
    const middelSubmenuKlantsessie: MenuItem[] = data.map((middel) => ({
      text: middel.kenmerk,
      route: urlKlantsessie + "/" + middel.kenmerk
    }));
    this.klantsessieMenuItem.submenu = middelSubmenuKlantsessie.length === 0 ?
      menu.klantsessieStaticSubmenuItems : middelSubmenuKlantsessie.concat(menu.klantsessieStaticSubmenuItems);
  }
}
