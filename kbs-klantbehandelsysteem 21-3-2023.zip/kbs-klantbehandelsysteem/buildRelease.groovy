@Library("GENERIC") _
    pipelineRelease_openshift_v2 {
	deploymentId = "ivakbs"
	deployPipeline = "iva-kbs_deploy_release"
	integrationPipeline = "iva-kbs_test-Robot"
	environmentChoices = "tst\nacc"
	streetChoices = "1\n2\n3\n4\n5\n6"
	mvnVersion = "maven36-openjdk11"
	jdkImage= "openjdk-11-rhel7"
}
