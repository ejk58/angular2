#!groovy
def playwrightCmd = """
               cd $projectDir;
               export PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1;
               npm ci --registry=https://nexus.belastingdienst.nl/nexus/repository/npm/;
               cd src/tests/;
               SELENIUM_REMOTE_URL=http://selenium-hub-wd-selenium-grid-4.apps.cn01.chp.belastingdienst.nl/wd/hub SELENIUM_REMOTE_CAPABILITIES='{"browserName": "chrome", "goog:chromeOptions":{"w3c":"false","args":["--disable-gpu","--disable-infobars","--disable-extensions","--ignore-certificate-errors","--disable-dev-shm-usage"]}}' npx playwright test --config=playwright.config.ts --retries=3 --workers=9
               """
def appName = "brievenbus"
def version
def project = env.PROJECT_NAME

pipeline {
    agent {
        label "jos-agent-nodejs-10"
    }
    options {
        skipDefaultCheckout()
    }
    stages {
        stage('Check out') {
            steps {
                checkout scm
            }
        }
        stage('playwright') {
            steps {
                sh(script: "npm ci --ignore-scripts; ${playwrightCmd}")
            }
        }
    }
}
