package resttests;

import com.google.gson.JsonObject;
import org.springframework.http.HttpStatus;
import org.testng.annotations.*;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class LoginAuthenticationFilterRestTest {

    private static final String BASE_PATH = "/api/login";

    @BeforeMethod
    public void setup() {
        RestUtils.setBaseURI(RestConstants.BASE_ADP_URI);
        RestUtils.setBasePort(RestConstants.PORT);
        RestUtils.setBasePath(BASE_PATH);
        RestUtils.setContentType(RestConstants.HEADER);
        RestUtils.setRelaxedHTTPSValidation();
    }

    @AfterMethod
    public void afterTest (){
        RestUtils.resetBaseURI();
        RestUtils.resetBasePort();
        RestUtils.resetBasePath();
    }

    @Test
    @Ignore
    public void login_with_correct_credentials_test() {
        JsonObject loginCredentials = new JsonObject();
        loginCredentials.addProperty("username", "ivatest1");
        loginCredentials.addProperty("password", "Welkom01");

        given()
                .body(loginCredentials.toString())
                .post()
            .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value());
    }

    @Test
    @Ignore
    public void login_with_incorrect_credentials_test() {
        JsonObject loginCredentials = new JsonObject();
        loginCredentials.addProperty("username", "ivatest");
        loginCredentials.addProperty("password", "Welkom");

        given()
                .body(loginCredentials.toString())
                .post()
            .then()
                .assertThat()
                .statusCode(HttpStatus.UNAUTHORIZED.value())
                .body("status", equalTo(401))
                .body("error", equalTo("Unauthorized"))
                .body("message", equalTo("Unauthorized"))
                .body("path", equalTo("/api/login"));
    }

    @Ignore //Test aanzetten als bug IVAB-54 is opgelost
    @Test
    public void login_only_with_username_test() {
        JsonObject loginCredentials = new JsonObject();
        loginCredentials.addProperty("username", "ivatest1");
        loginCredentials.addProperty("password", "");

        given()
                .body(loginCredentials.toString())
                .post()
            .then()
                .assertThat()
                .statusCode(HttpStatus.UNAUTHORIZED.value())
                .body("status", equalTo(401))
                .body("error", equalTo("Unauthorized"))
                .body("message", equalTo("Unauthorized"))
                .body("path", equalTo("/api/login"));
    }

    @Test
    @Ignore
    public void login_only_with_password_test() {
        JsonObject loginCredentials = new JsonObject();
        loginCredentials.addProperty("username", "");
        loginCredentials.addProperty("password", "Welkom01");

        given()
                .body(loginCredentials.toString())
                .post()
            .then()
                .assertThat()
                .statusCode(HttpStatus.UNAUTHORIZED.value())
                .body("status", equalTo(401))
                .body("error", equalTo("Unauthorized"))
                .body("message", equalTo("Unauthorized"))
                .body("path", equalTo("/api/login"));
    }

}