package nl.belastingdienst.iva.wd.brievenbus.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapAdpClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.DeliveryBuilder;
import nl.belastingdienst.iva.wd.brievenbus.domain.LoggedInUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.Mailbox;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityUtils;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;
import nl.belastingdienst.iva.wd.brievenbus.service.FileService;
import nl.belastingdienst.iva.wd.brievenbus.utils.MailboxUtils;

@RunWith(SpringRunner.class)
@WebMvcTest(FileController.class)
public class FileControllerTest {

    private static final String API_DOWNLOAD = "/api/download/";
    private static final String INVALID_UUID = "uuid1";
    private static final String UUID1 = "db5582d9-444a-4451-957b-33a22168a094";
    private static final String UUID2 = "db5582d9-444a-4451-957b-33a22168a022";
    private static final String FILENAME = "Included.jpg";
    private static final String MAILBOX1 = "mailbox1";
    private static final String MAILBOX2 = "mailbox2";

    @MockBean
    LdapContextSource ldapContextSource;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private DeliveryRepository deliveryRepository;

    @MockBean
    FileService fileService;

    @MockBean
    private LdapAdpClient ldapAdpClient;

    @MockBean
    private LdapDwbClient ldapDwbClient;

    @MockBean
    private AuditService auditService;

    @MockBean
    private MailboxUtils mailboxUtils;

    @MockBean
    private SecurityUtils securityUtils;

    @Test
    @WithMockUser(username = "recei01")
    public void testInvalidUUID() throws Exception {
        mvc.perform(get(API_DOWNLOAD + INVALID_UUID)
                .with(user(createLoggedInUser("recei01")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"Failed to convert value of type 'java.lang.String' to required type 'java.util.UUID'; nested exception is java.lang.IllegalArgumentException: Invalid UUID string: uuid1\"}"))
                .andExpect(status().is(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    }

    @Test
    public void testNoPrincipal() throws Exception {
        stubDeliveryRepository(UUID1, true, false);
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.FORBIDDEN.value()));
    }

    @Test
    @WithMockUser(username = "recei01")
    public void testNoUserInActiveDirectory() throws Exception {
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .with(user(createLoggedInUser("recei01")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"Deze gebruiker komt niet voor in de Active Directory: recei01\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    @WithMockUser(username = "recei01")
    public void testNoDelivery() throws Exception {
        stubLdapDwbClient("recei01");
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .with(user(createLoggedInUser("recei01")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"Levering met dit uuid niet gevonden: db5582d9-444a-4451-957b-33a22168a094\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    @WithMockUser(username = "sende01")
    public void testSendingFileToYourself() throws Exception {
        stubDeliveryRepository(UUID1, true, false);
        stubLdapDwbClient("sende01");
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .with(user(createLoggedInUser("sende01")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"U mag geen bestand ophalen dat u zelf hebt verzonden\"}"))
                .andExpect(status().is(HttpStatus.PRECONDITION_FAILED.value()));
    }

    @Test
    @WithMockUser(username = "recei01")
    public void testCompleteDeliveryReceiver1() throws Exception {
        stubDeliveryRepository(UUID1, true, false);
        stubLdapDwbClient("recei01");
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .with(user(createLoggedInUser("recei01")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("Ik ben een interessante file!"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "recei02")
    public void testCompleteDeliveryReceiver2() throws Exception {
        stubDeliveryRepository(UUID1, true, false);
        stubLdapDwbClient("recei02");
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .with(user(createLoggedInUser("recei02")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("Ik ben een interessante file!"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "recei03")
    public void testCompleteDeliveryUnknownReceiver() throws Exception {
        stubDeliveryRepository(UUID1, true, false);
        stubLdapDwbClient("recei03");
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .with(user(createLoggedInUser("recei03")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"U bent niet geautoriseerd om dit bestand op te halen\"}"))
                .andExpect(status().is(HttpStatus.UNAUTHORIZED.value()));
    }

    @Test
    @WithMockUser(username = "recei03")
    public void testCompleteDeliveryReceiverNotAuthorizedForMailbox() throws Exception {
        stubDeliveryRepository(UUID1, true, true);
        stubLdapDwbClient("recei03");
        stubMailboxUtils(MAILBOX1);
        stubMailboxUtils(MAILBOX2);
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .with(user(createLoggedInUser("recei03")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"U bent niet geautoriseerd om dit bestand op te halen\"}"))
                .andExpect(status().is(HttpStatus.UNAUTHORIZED.value()));
    }

    @Test
    @WithMockUser(username = "recei01")
    public void testCompleteDeliveryExpired() throws Exception {
        stubDeliveryRepository(UUID2, true, false);
        stubLdapDwbClient("recei01");
        Delivery delivery = deliveryRepository.findFirstByUuid(UUID.fromString(UUID2));
        String dateAsString = delivery.getExpiration().format(FileController.DATE_TIME_FORMATTER);
        mvc.perform(get(API_DOWNLOAD + UUID2)
                .with(user(createLoggedInUser("recei01")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"De download periode is verstreken. Deze eindigde op: " + dateAsString + "\"}"))
                .andExpect(status().is(HttpStatus.PRECONDITION_FAILED.value()));
    }

    @Test
    @WithMockUser(username = "recei01")
    public void testCompleteDeliveryFileNotFound() throws Exception {
        stubDeliveryRepository(UUID1, false, false);
        stubLdapDwbClient("recei01");
        mvc.perform(get(API_DOWNLOAD + UUID1)
                .with(user(createLoggedInUser("recei01")))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string("{\"message\":\"File db5582d9-444a-4451-957b-33a22168a094/" + FILENAME + " niet gevonden\"}"))
                .andExpect(status().is(HttpStatus.NOT_FOUND.value()));
    }

    private void stubDeliveryRepository(String uuid, boolean filePresent, boolean hasAlsoMailboxReceivers) throws IOException {
        if (filePresent) {
            stubFileService(uuid);
        } else {
            stubFileNotExistsService(uuid);
        }

        if (uuid.equals(UUID1)) {
            if (hasAlsoMailboxReceivers) {
                when(deliveryRepository.findFirstByUuid(UUID.fromString(uuid))).thenReturn(DeliveryBuilder.buildCompleteDeliveryAlsoWithMailboxReceivers(uuid, FILENAME));
            } else {
                when(deliveryRepository.findFirstByUuid(UUID.fromString(uuid))).thenReturn(DeliveryBuilder.buildCompleteDelivery(uuid, FILENAME));
            }
        } else {
            when(deliveryRepository.findFirstByUuid(UUID.fromString(uuid))).thenReturn(DeliveryBuilder.buildExpiredDelivery(UUID.fromString(uuid)));
        }
    }

    private void stubFileService(String uuid) throws IOException {
        String mockFile = "Ik ben een interessante file!";
        InputStream is = new ByteArrayInputStream(mockFile.getBytes());
        FileSystemResource mockResource = Mockito.mock(FileSystemResource.class);

        when(mockResource.exists()).thenReturn(true);
        when(mockResource.getInputStream()).thenReturn(is);
        when(fileService.getFileResource(eq(uuid), any())).thenReturn(mockResource);
    }

    private void stubFileNotExistsService(String uuid) throws IOException {
        FileSystemResource mockResource = Mockito.mock(FileSystemResource.class);

        when(mockResource.exists()).thenReturn(false);
        when(fileService.getFileResource(eq(uuid), any())).thenReturn(mockResource);
    }

    private void stubLdapDwbClient(String userId) {
        LdapPerson ldapPerson = new LdapPerson();
        ldapPerson.setUserId(userId);
        ldapPerson.setTenant("TEST");
        ldapPerson.setGroups(Arrays.asList("group1", "group2", "group3"));

        when(ldapDwbClient.getPerson(eq(userId))).thenReturn(ldapPerson);
    }

    private void stubMailboxUtils(String mailboxId) {
        Mailbox mailbox = new Mailbox();
        mailbox.setAdGroup("group-" + mailboxId);
        when(mailboxUtils.isMailbox(eq(mailboxId))).thenReturn(true);
        when(mailboxUtils.getMailbox(eq(mailboxId))).thenReturn(mailbox);

    }

    private LoggedInUser createLoggedInUser(String username) {
        List<GrantedAuthority> authorities = new ArrayList<>();
        return new LoggedInUser(username, "pa@@word", authorities, "TEST");
    }
}
