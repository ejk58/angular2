package nl.belastingdienst.iva.wd.brievenbus.validator;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.domain.LdapPersonBuilder;
import nl.belastingdienst.iva.wd.brievenbus.domain.LoggedInUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.Mailbox;
import nl.belastingdienst.iva.wd.brievenbus.domain.MailboxBuilder;
import nl.belastingdienst.iva.wd.brievenbus.domain.ReceiverBuilder;
import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;
import nl.belastingdienst.iva.wd.brievenbus.utils.MailboxUtils;

@RunWith(SpringRunner.class)
public class UploadValidatorTest {

	@Mock
	private LdapDwbClient ldapDwbClient;

	@Mock
	private MailboxUtils mailboxUtils;

	@InjectMocks
	private UploadValidator uploadValidator;

	@Before
	public void setup() {
		ReflectionTestUtils.setField(uploadValidator, "maxReceivers", 5);
		ReflectionTestUtils.setField(uploadValidator, "sendingFileToYourselfIsNotAllowed", true);
		ReflectionTestUtils.setField(uploadValidator, "enterProductNumber", true);
	}

	@Test
	public void testValidateSender() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1", "ivatest2", "ivatest3");
		List<GrantedAuthority> authorities =new ArrayList<>();
		LoggedInUser loggedInUser = new LoggedInUser("ivatest2", "pa@@word", authorities, "TEST");

		ResponseEntity<String> response = uploadValidator.validateSender(loggedInUser, receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"U mag geen bestand naar uzelf sturen\"}"));

		response = uploadValidator.validateSender(loggedInUser, new ArrayList<>());
		assert (response == null);

		ReflectionTestUtils.setField(uploadValidator, "sendingFileToYourselfIsNotAllowed", false);
		response = uploadValidator.validateSender(loggedInUser, receivers);
		assert (response == null);
	}

	@Test
	public void testValidateReceiversWithNoReceivers() {
		ResponseEntity<String> response = uploadValidator.validateReceivers(new ArrayList<>());
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Er zijn geen receivers opgegeven\"}"));

		response = uploadValidator.validateReceivers(null);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Er zijn geen receivers opgegeven\"}"));
	}

	@Test
	public void testValidateReceiversWithNotEveryRequiredFieldEntered() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1", "ivatest2", "ivatest3");

		receivers.get(0).setName(null);
		ResponseEntity<String> response = uploadValidator.validateReceivers(receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Niet alle verplichte velden bij een receiver (id, name, email, type) zijn gevuld\"}"));

		receivers.get(1).setType("   ");
		response = uploadValidator.validateReceivers(receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Niet alle verplichte velden bij een receiver (id, name, email, type) zijn gevuld\"}"));

		receivers.get(1).setId(null);
		response = uploadValidator.validateReceivers(receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Niet alle verplichte velden bij een receiver (id, name, email, type) zijn gevuld\"}"));

		receivers.get(2).setEmail("");
		response = uploadValidator.validateReceivers(receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Niet alle verplichte velden bij een receiver (id, name, email, type) zijn gevuld\"}"));
	}

	@Test
	public void testValidateReceiversWithTooManyReceivers() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1", "ivatest2", "ivatest3", "ivatest4", "ivatest5", "ivatest6");
		ResponseEntity<String> response = uploadValidator.validateReceivers(receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Er mogen maximaal 5 receivers worden opgegeven\"}"));
	}

	@Test
	public void testValidateReceiversWithTypeNotCorrect() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1", "ivatest2", "ivatest3");
		receivers.get(0).setType("PERSONS");
		ResponseEntity<String> response = uploadValidator.validateReceivers(receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Er is een verkeerd type receiver opgegeven (alleen PERSON en MAILBOX zijn toegestaan)\"}"));
	}

	@Test
	public void testValidateReceiversWithReceiverNotRegistered() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1", "ivatest2", "ivatest3");
		LdapPerson ldapPerson1 = LdapPersonBuilder.buildLdapPersonFromReceiverJson(receivers.get(0));
		LdapPerson ldapPerson2 = LdapPersonBuilder.buildLdapPersonFromReceiverJson(receivers.get(1));
		when(ldapDwbClient.getPerson("ivatest1")).thenReturn(ldapPerson1);
		when(ldapDwbClient.getPerson("ivatest2")).thenReturn(ldapPerson2);

		ResponseEntity<String> response = uploadValidator.validateReceivers(receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Een opgegeven receiver is niet geregistreerd\"}"));
	}

	@Test
	public void testValidateReceiversWithEmailAddressNotRegistered() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1", "ivatest2", "ivatest3");
		LdapPerson ldapPerson1 = LdapPersonBuilder.buildLdapPersonFromReceiverJson(receivers.get(0));
		LdapPerson ldapPerson2 = LdapPersonBuilder.buildLdapPersonFromReceiverJson(receivers.get(1));
		Mailbox mailbox3 = MailboxBuilder.buildMailboxFromReceiverJson(receivers.get(2));
		when(ldapDwbClient.getPerson("ivatest1")).thenReturn(ldapPerson1);
		when(ldapDwbClient.getPerson("ivatest2")).thenReturn(ldapPerson2);
		when(mailboxUtils.getMailbox("ivatest3")).thenReturn(mailbox3);
		receivers.get(2).setType("MAILBOX");
		receivers.get(2).setEmail("unknown");

		ResponseEntity<String> response = uploadValidator.validateReceivers(receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Een opgegeven emailadres van een receiver klopt niet met het geregistreerde emailadres\"}"));
	}

	@Test
	public void testValidateReceiversWithEverythingOkForOneReceiver() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1");
		LdapPerson ldapPerson1 = LdapPersonBuilder.buildLdapPersonFromReceiverJson(receivers.get(0));
		when(ldapDwbClient.getPerson("ivatest1")).thenReturn(ldapPerson1);

		ResponseEntity<String> response = uploadValidator.validateReceivers(receivers);
		assert (response == null);
	}

	@Test
	public void testValidateReceiversWithEverythingOkForTwoReceivers() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1", "ivatest2");
		LdapPerson ldapPerson1 = LdapPersonBuilder.buildLdapPersonFromReceiverJson(receivers.get(0));
		LdapPerson ldapPerson2 = LdapPersonBuilder.buildLdapPersonFromReceiverJson(receivers.get(1));
		when(ldapDwbClient.getPerson("ivatest1")).thenReturn(ldapPerson1);
		when(ldapDwbClient.getPerson("ivatest2")).thenReturn(ldapPerson2);

		ResponseEntity<String> response = uploadValidator.validateReceivers(receivers);
		assert (response == null);
	}

	@Test
	public void testValidateProductNumberWithProductNumberNotEntered() {
		ResponseEntity<String> response = uploadValidator.validateProductNumber(null);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Het productnummer is niet ingevuld\"}"));

		response = uploadValidator.validateProductNumber("   ");
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Het productnummer is niet ingevuld\"}"));

		response = uploadValidator.validateProductNumber("null");
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Het productnummer is niet ingevuld\"}"));
	}

	@Test
	public void testValidateProductNumberWithProductNumberTooLong() {
		ResponseEntity<String> response = uploadValidator.validateProductNumber("123456789012345678901234567890123");
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Het productnummer is langer dan 32 posities\"}"));
	}

	@Test
	public void testValidateProductNumberWithEverythingOk() {
		ResponseEntity<String> response = uploadValidator.validateProductNumber("12345678901234567890123456789012");
		assert (response == null);

		ReflectionTestUtils.setField(uploadValidator, "enterProductNumber", false);
		response = uploadValidator.validateProductNumber("1234");
		assert (response == null);
	}

	@Test
	public void testValidateIsVerifyMailboxChecked() {
		List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1", "ivatest2", "ivatest3");
		when(mailboxUtils.isMailbox("ivatest1")).thenReturn(true);
		when(mailboxUtils.isMailbox("ivatest2")).thenReturn(false);
		when(mailboxUtils.isMailbox("ivatest3")).thenReturn(true);

		ResponseEntity<String> response = uploadValidator.validateIsVerifyMailboxChecked(false, receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Er is geen toestemming privacy officer opgegeven bij het versturen naar postbussen\"}"));

		response = uploadValidator.validateIsVerifyMailboxChecked(null, receivers);
		assert (response.getStatusCode().equals(HttpStatus.BAD_REQUEST));
		assert (Objects.equals(response.getBody(), "{\"error\": \"Er is geen toestemming privacy officer opgegeven bij het versturen naar postbussen\"}"));

		response = uploadValidator.validateIsVerifyMailboxChecked(true, receivers);
		assert (response == null);

		response = uploadValidator.validateIsVerifyMailboxChecked(true, new ArrayList<>());
		assert (response == null);
	}

}
