package nl.belastingdienst.iva.wd.brievenbus.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.PersistenceException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.FileRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.ReceiverRepository;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapAdpClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import nl.belastingdienst.iva.wd.brievenbus.domain.LoggedInUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;
import nl.belastingdienst.iva.wd.brievenbus.domain.ReceiverBuilder;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;
import nl.belastingdienst.iva.wd.brievenbus.service.FileService;
import nl.belastingdienst.iva.wd.brievenbus.service.MailService;
import nl.belastingdienst.iva.wd.brievenbus.validator.UploadValidator;

@RunWith(SpringRunner.class)
@WebMvcTest(UploadController.class)
public class UploadControllerTest {

    private static final String API_UPLOAD = "/api/upload/offer";
    private static final String RECEIVER1 = "ivatest1";

    @MockBean
    private LdapContextSource ldapContextSource;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private DeliveryRepository deliveryRepository;

    @MockBean
    private MailService mailService;

    @MockBean
    private FileRepository fileRepository;

    @MockBean
    private ReceiverRepository receiverRepository;

    @MockBean
    private FileService fileService;

    @MockBean
    private LdapAdpClient ldapAdpClient;

    @MockBean
    private LdapDwbClient ldapDwbClient;

    @MockBean
    private AuditService auditService;

    @MockBean
    private UploadValidator uploadValidator;

    private MockMultipartFile uploadFile;

    @Before
    public void setup() {
        uploadFile = new MockMultipartFile("file", "README.txt", "text/plain", "README.txt".getBytes());
    }

    @Test
    @WithMockUser
    public void testUploadWithMissingParameterReceivers() throws Exception {
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .with(user(createLoggedInUser())))
                .andExpect(content().string("{\"message\":\"Required request parameter 'receivers' for method parameter type List is not present\"}"))
                .andExpect(status().is(HttpStatus.INTERNAL_SERVER_ERROR.value()));

        verify(deliveryRepository, times(0)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq(null), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser(username = RECEIVER1)
    public void testUploadWithSenderError() throws Exception {
        List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1");
        when(uploadValidator.validateSender(any(LoggedInUser.class), eq(receivers))).thenReturn(ResponseEntity.badRequest().body(""));

        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1))
                .param("productNumber", "123456")
                .with(user(createLoggedInUser())))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value())).andReturn();

        verify(deliveryRepository, times(0)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithReceiversError() throws Exception {
        List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1");
        when(uploadValidator.validateReceivers(receivers)).thenReturn(ResponseEntity.badRequest().body(""));

        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1))
                .param("productNumber", "123456")
                .with(user(createLoggedInUser())))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value())).andReturn();

        verify(deliveryRepository, times(0)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithProductNumberError() throws Exception {
        when(uploadValidator.validateProductNumber("123456")).thenReturn(ResponseEntity.badRequest().body(""));

        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1))
                .param("productNumber", "123456")
                .with(user(createLoggedInUser())))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value())).andReturn();

        verify(deliveryRepository, times(0)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithIsVerifyMailboxCheckedError() throws Exception {
        List<ReceiverJson> receivers = ReceiverBuilder.buildReceiverJsonList("ivatest1");
        when(uploadValidator.validateIsVerifyMailboxChecked(true, receivers)).thenReturn(ResponseEntity.badRequest().body(""));

        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1))
                .param("productNumber", "123456")
                .param("isVerifyMailboxChecked", "true")
                .with(user(createLoggedInUser())))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value())).andReturn();

        verify(deliveryRepository, times(0)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser
    public void testWritingOfFileToFileSystemGoesWrong() throws Exception {
        Mockito.doThrow(new UnprocessableException("Er is iets misgegaan bij het schrijven van de file")).when(fileService).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", "{}")
                .param("productNumber", "123456")
                .with(user(createLoggedInUser())))
                .andExpect(content().string("{\"message\":\"Er is iets misgegaan bij het schrijven van de file\"}"))
                .andExpect(status().is(HttpStatus.UNPROCESSABLE_ENTITY.value()));
        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(1)).save(any(File.class));
        verify(receiverRepository, times(1)).save(any(Receiver.class));
        verify(fileService, times(1)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithErrorOnSavingDelivery() throws Exception {
        when(deliveryRepository.save(any(Delivery.class))).thenThrow(new PersistenceException());
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", "{}")
                .param("productNumber", "123456")
                .with(user(createLoggedInUser())))
                .andExpect(content().string("{\"message\":\"Opslaan van delivery is niet gelukt\"}"))
                .andExpect(status().is(HttpStatus.UNPROCESSABLE_ENTITY.value()));
        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(0)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithErrorOnSavingReceiver() throws Exception {
        when(receiverRepository.save(any(Receiver.class))).thenThrow(new PersistenceException());
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", "{}")
                .param("productNumber", "123456")
                .with(user(createLoggedInUser())))
                .andExpect(content().string("{\"message\":\"Opslaan van receiver is niet gelukt\"}"))
                .andExpect(status().is(HttpStatus.UNPROCESSABLE_ENTITY.value()));
        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(0)).save(any(File.class));
        verify(receiverRepository, times(1)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser
    public void testUploadWithErrorOnSavingFileMetadata() throws Exception {
        when(fileRepository.save(any(File.class))).thenThrow(new PersistenceException());
        mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", "{}")
                .param("productNumber", "123456")
                .with(user(createLoggedInUser())))
                .andExpect(content().string("{\"message\":\"Opslaan van file is niet gelukt\"}"))
                .andExpect(status().is(HttpStatus.UNPROCESSABLE_ENTITY.value()));
        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(1)).save(any(File.class));
        verify(receiverRepository, times(1)).save(any(Receiver.class));
        verify(fileService, times(0)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(0)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));
    }

    @Test
    @WithMockUser
    public void testValidUploadWith2Receivers() throws Exception {
        MvcResult result = mvc.perform(MockMvcRequestBuilders.multipart(API_UPLOAD)
                .file(uploadFile)
                .param("receivers", ReceiverBuilder.buildIvaTestReceiverJson(1), ReceiverBuilder.buildIvaTestReceiverJson(2))
                .param("productNumber", "123456")
                .with(user(createLoggedInUser())))
                .andExpect(status().isOk()).andReturn();

        verify(deliveryRepository, times(1)).save(any(Delivery.class));
        verify(fileRepository, times(1)).save(any(File.class));
        verify(receiverRepository, times(2)).save(any(Receiver.class));
        verify(fileService, times(1)).writeFileToDirectoryOnSystem(any(Delivery.class), any(MultipartFile.class), any(LoggedInUser.class));
        verify(mailService, times(1)).createAndSendMail(any(Delivery.class), any(List.class), eq("123456"), any(LoggedInUser.class));

        String content = result.getResponse().getContentAsString();
        Assert.assertTrue(content.contains("Bestand goed verwerkt!"));
    }

    private LoggedInUser createLoggedInUser() {
        List<GrantedAuthority> authorities = new ArrayList<>();
        return new LoggedInUser("sende01", "pa@@word", authorities, "TEST");
    }
}
