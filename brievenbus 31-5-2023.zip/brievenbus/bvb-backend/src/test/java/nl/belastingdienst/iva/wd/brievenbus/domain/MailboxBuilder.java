package nl.belastingdienst.iva.wd.brievenbus.domain;

import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;

public class MailboxBuilder {

	public static Mailbox buildMailboxFromReceiverJson(ReceiverJson receiverJson) {
		Mailbox mailbox = new Mailbox();
		mailbox.setId(receiverJson.getId());
		mailbox.setEmail(receiverJson.getEmail());
		return mailbox;
	}

}
