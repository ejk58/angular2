package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LdapPerson {

	private String userId;
	private String firstName;
	private String lastName;
	private String name;
	private String email;
	private List<String> groups;
	private String tenant;
}
