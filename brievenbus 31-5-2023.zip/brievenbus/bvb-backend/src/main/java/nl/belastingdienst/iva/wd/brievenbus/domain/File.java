package nl.belastingdienst.iva.wd.brievenbus.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "file")
public class File {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String hash;
    private String name;
    private Long bytes;

    @OneToOne
    @JoinColumn(name = "delivery_id", referencedColumnName = "id")
    private Delivery delivery;

    @Version
    private Integer version;

    @Override
    public String toString() {
        return "File{" +
                "hash='" + hash + '\'' +
                ", name='" + name + '\'' +
                ", bytes=" + bytes +
                ", delivery=" + delivery +
                '}';
    }
}