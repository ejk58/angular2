package nl.belastingdienst.iva.wd.brievenbus.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "delivery")
public class Delivery {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private UUID uuid;
    private String sender;
    private LocalDateTime created;
    private LocalDateTime expiration;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "delivery")
    @JsonIgnoreProperties({"delivery"})
    private List<Receiver> receivers;

    @OneToOne(fetch = FetchType.EAGER, mappedBy = "delivery")
    @JsonIgnoreProperties({"delivery"})
    private File file;

    @Version
    private Integer version;
    
    public void addReceiver(Receiver receiver) {
    	if (this.receivers == null) {
    		this.receivers = new ArrayList<>();
    	}
    	
    	this.receivers.add(receiver);
    }
}
