package nl.belastingdienst.iva.wd.brievenbus.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationUser {

	private String username;
	private String password;
}

