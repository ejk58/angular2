package nl.belastingdienst.iva.wd.brievenbus.domain;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import lombok.Getter;
import lombok.Setter;

/**
 * This class must extend {@link User} in order to use it as {@link java.security.Principal} in
 * {@link org.springframework.security.authentication.UsernamePasswordAuthenticationToken} and in controllers.
 */
@Getter
@Setter
public class LoggedInUser extends User {

	private static final long serialVersionUID = 8817986373614764403L;

	private String tenant;

	public LoggedInUser(String username, String password, Collection<? extends GrantedAuthority> authorities, String tenant) {
		super(username, password, authorities);
		this.tenant = tenant;
	}

}
