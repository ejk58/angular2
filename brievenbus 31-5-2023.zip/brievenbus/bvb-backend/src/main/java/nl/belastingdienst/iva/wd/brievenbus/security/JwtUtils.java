package nl.belastingdienst.iva.wd.brievenbus.security;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

import nl.belastingdienst.iva.wd.brievenbus.domain.LoggedInUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.JWTInvalidException;

public class JwtUtils {

    private final Environment env;

    public JwtUtils(Environment env) {
        this.env = env;
    }

    public String generateJwtToken(Authentication authentication) {
        LoggedInUser loggedInUser = (LoggedInUser) authentication.getPrincipal();
        String[] authorities = authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).toArray(String[]::new);
        long validityPeriod = Long.parseLong(env.getRequiredProperty("jwt.validity.period.in.hours")) * 60 * 60 * 1000;
        return JWT.create()
            .withSubject(loggedInUser.getUsername())
            .withClaim(SecurityConstants.TENANT, loggedInUser.getTenant())
            .withArrayClaim(SecurityConstants.AUTHORITIES, authorities)
            .withExpiresAt(new Date(System.currentTimeMillis() + validityPeriod))
            .sign(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes()));
    }

    public DecodedJWT validateJwtToken(String token) {
        try {
            return JWT.require(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes())).build().verify(token);
        } catch (JWTVerificationException e) {
            throw new JWTInvalidException(e.getMessage(), e);
        }
    }

    public UsernamePasswordAuthenticationToken createAuthenticationTokenFromJwtToken(DecodedJWT decodedJWT) {
        String user = decodedJWT.getSubject();
        String tenant = decodedJWT.getClaim(SecurityConstants.TENANT).asString();
        List<GrantedAuthority> authorities = getGrantedAuthoritiesFromJwtToken(decodedJWT);
        LoggedInUser loggedInUser = new LoggedInUser(user, SecurityConstants.DEFAULT_PASSWORD, authorities, tenant);
        return new UsernamePasswordAuthenticationToken(loggedInUser, SecurityConstants.DEFAULT_PASSWORD, authorities);
    }

    private List<GrantedAuthority> getGrantedAuthoritiesFromJwtToken(DecodedJWT decodedJWT) {
        Claim authoritiesClaim = decodedJWT.getClaim(SecurityConstants.AUTHORITIES);
        if (!authoritiesClaim.isNull()) {
            return authoritiesClaim.asList(String.class).stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

}
