package nl.belastingdienst.iva.wd.brievenbus.security;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import nl.belastingdienst.iva.common.springboot.security.RoleMapping;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapPerson;
import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationPlatform;
import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.LoggedInUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnauthorizedException;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

public class SecurityUtils {

	private static final String NOT_AUTHORIZED_SENDING_FILES_VIA_ADP_ERROR = "U bent niet geautoriseerd om bestanden via deze web-applicatie te versturen";
	private static final String NOT_AUTHORIZED_SENDING_FILES_AUTOMATIC_ERROR = "U bent niet geautoriseerd om bestanden automatisch te versturen";
	private static final String LOGIN_WITHOUT_VALID_ROLE = "Er is geprobeerd in te loggen zonder geldige rol";

	private final AuditService auditService;
	private final LdapClient ldapClient;
	private final String applicationPlatform;
	private final String groupUploaderAdp;
	private final String groupUploaderAutomatic;

	public SecurityUtils(Environment env, AuditService auditService, LdapClient ldapClient) {
		this.auditService = auditService;
		this.ldapClient = ldapClient;
		this.applicationPlatform = env.getRequiredProperty("application.platform", String.class).toLowerCase();
		this.groupUploaderAdp = env.getRequiredProperty("application.group.uploader.adp", String.class);
		this.groupUploaderAutomatic = env.getRequiredProperty("application.group.uploader.automatic", String.class);
	}

	public UsernamePasswordAuthenticationToken authenticateInLdapForApplicationLogin(ApplicationUser user) {
		LdapPerson ldapPerson = this.ldapClient.authenticateInLdap(user);
		List<GrantedAuthority> authorities = this.getGrantedAuthoritiesFromLdap(ldapPerson);
		LoggedInUser loggedInUser = new LoggedInUser(user.getUsername(), user.getPassword(), authorities, ldapPerson.getTenant());
		this.checkRoleForAdpDeliveries(authorities, loggedInUser);
		return new UsernamePasswordAuthenticationToken(loggedInUser, user.getPassword(), authorities);
	}

	public UsernamePasswordAuthenticationToken authenticateInLdapForAutomaticDeliveriesLogin(ApplicationUser user) {
		LdapPerson ldapPerson = this.ldapClient.authenticateInLdap(user);
		List<GrantedAuthority> authorities = this.getGrantedAuthoritiesFromLdap(ldapPerson);
		LoggedInUser loggedInUser = new LoggedInUser(user.getUsername(), user.getPassword(), authorities, ldapPerson.getTenant());
		this.checkRoleForAutomaticDeliveries(authorities, loggedInUser);
		return new UsernamePasswordAuthenticationToken(loggedInUser, user.getPassword(), authorities);
	}

	private void checkRoleForAdpDeliveries(List<GrantedAuthority> authorities, LoggedInUser loggedInUser) {
		if (ApplicationPlatform.ADP.getPlatform().equalsIgnoreCase(this.applicationPlatform)
				&& this.hasNotRole(authorities, SecurityConstants.ROLE_UPLOADER_ADP)) {
			this.auditService.logUserAction(LOGIN_WITHOUT_VALID_ROLE, loggedInUser);
			throw new UnauthorizedException(NOT_AUTHORIZED_SENDING_FILES_VIA_ADP_ERROR);
		}
	}

	private void checkRoleForAutomaticDeliveries(List<GrantedAuthority> authorities, LoggedInUser loggedInUser) {
		if (this.hasNotRole(authorities, SecurityConstants.ROLE_UPLOADER_AUTOMATIC)) {
			this.auditService.logUserAction(LOGIN_WITHOUT_VALID_ROLE, loggedInUser);
			throw new UnauthorizedException(NOT_AUTHORIZED_SENDING_FILES_AUTOMATIC_ERROR);
		}
	}

	private boolean hasNotRole(List<GrantedAuthority> authorities, String role) {
		return authorities.stream().noneMatch(authority -> authority.getAuthority().equalsIgnoreCase(role));
	}

	private List<GrantedAuthority> getGrantedAuthoritiesFromLdap(LdapPerson ldapPerson) {
		List<String> groups = this.getGroupsForPerson(ldapPerson);
		List<RoleMapping> roleMappings = this.getRoleMappings();
		return roleMappings.stream()
			.filter(roleMapping -> groups.contains(roleMapping.getLdapGroup()))
			.map(roleMapping -> new SimpleGrantedAuthority(roleMapping.getRole()))
			.collect(Collectors.toList());
	}

	private List<String> getGroupsForPerson(LdapPerson ldapPerson) {
		List<String> groups = new ArrayList<>();
		if (ldapPerson != null) {
			groups.addAll(ldapPerson.getGroups());
			groups.replaceAll(String::toUpperCase);
		}
		return groups;
	}

	private List<RoleMapping> getRoleMappings() {
		List<RoleMapping> roleMappings = new ArrayList<>();
		roleMappings.add(new RoleMapping(this.groupUploaderAdp, SecurityConstants.ROLE_UPLOADER_ADP));
		roleMappings.add(new RoleMapping(this.groupUploaderAutomatic, SecurityConstants.ROLE_UPLOADER_AUTOMATIC));
		return roleMappings;
	}

}
