package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnauthorizedException;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

public abstract class LdapClient {

	protected static final String LOGIN_CREDENTIALS_ERROR = "Gebruikersnaam en/of wachtwoord fout";
	protected static final String LOGIN_WITH_WRONG_CREDENTIALS = "Er is geprobeerd in te loggen met een verkeerd userid of password voor gebruiker: ";

	@Autowired
	protected AuditService auditService;

	@Autowired
	protected LdapTemplate ldapTemplate;

	public abstract LdapPerson authenticateInLdap(ApplicationUser user);

	protected LdapPerson getPersonByUserId(String userId, String partitionSuffix) {
		LdapQuery query = LdapQueryBuilder.query()
				.searchScope(SearchScope.SUBTREE)
				.timeLimit(3000)
				.base(partitionSuffix)
				.where("objectclass").is("person")
				.and("cn").is(userId);
		List<LdapPerson> persons = this.ldapTemplate.search(query, new LdapPersonAttributesMapper());
		return (persons == null || persons.isEmpty()) ? null : persons.get(0);
	}

	protected boolean authenticate(ApplicationUser user, String partitionSuffix) {
		return this.ldapTemplate.authenticate(partitionSuffix, "(cn=" + user.getUsername() + ")", user.getPassword());
	}

	protected void processNotAuthenticatedError(String username) {
		this.auditService.logUserAction(LOGIN_WITH_WRONG_CREDENTIALS + username);
		throw new UnauthorizedException(LOGIN_CREDENTIALS_ERROR);
	}

}
