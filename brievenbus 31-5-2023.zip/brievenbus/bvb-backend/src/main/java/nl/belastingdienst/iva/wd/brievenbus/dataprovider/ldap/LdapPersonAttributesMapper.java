package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import org.springframework.ldap.core.AttributesMapper;

public class LdapPersonAttributesMapper implements AttributesMapper<LdapPerson> {

    private static final Predicate<String> TENANT_GROUP_PREDICATE = Pattern.compile("^aug_dna_t\\d{3}$").asPredicate();
    private static final String NO_TENANT = "Onbekend";

    public LdapPerson mapFromAttributes(Attributes attributes) throws NamingException {
//        printAttributes(attributes);

        LdapPerson ldapPerson = new LdapPerson();
        ldapPerson.setUserId(getFromAttributes(attributes, "cn"));
        ldapPerson.setFirstName(getFromAttributes(attributes, "givenName"));
        ldapPerson.setLastName(getFromAttributes(attributes, "sn"));
        ldapPerson.setName(getFromAttributes(attributes, "displayName"));
        ldapPerson.setEmail(getFromAttributes(attributes, "mail"));
        ldapPerson.setGroups(getGroupsFromAttributes(attributes));
        ldapPerson.setTenant(getTenantFromGroups(ldapPerson.getGroups()));

        return ldapPerson;
    }

    private String getTenantFromGroups(List<String> groups) {
        groups.replaceAll(String::toLowerCase);
        List<String> tenantGroups = groups.stream().filter(TENANT_GROUP_PREDICATE).collect(Collectors.toList());
        return tenantGroups.isEmpty() ? NO_TENANT : tenantGroups.stream().map(group -> group.replace("aug_dna_", "")).collect(Collectors.joining(","));
    }

    private List<String> getGroupsFromAttributes(Attributes attributes) throws NamingException {
        Attribute memberOfAttribute = attributes.get("memberOf");
        List<String> groups = new ArrayList<>();

        if (memberOfAttribute != null) {
            NamingEnumeration<?> memberOfEnumeration = memberOfAttribute.getAll();
            while (memberOfEnumeration.hasMore()) {
                String memberOf = memberOfEnumeration.next().toString();
                int startIndex = memberOf.indexOf("CN=") + 3;
                int endIndex = memberOf.indexOf(',', startIndex);
                if (startIndex >= 3 && endIndex > startIndex) {
                    groups.add(memberOf.substring(startIndex, endIndex));
                }
            }
        }

        return groups;
    }

    private String getFromAttributes(Attributes attributes, String key) throws NamingException {
        Attribute attribute = attributes.get(key);
        return attribute == null ? null : attribute.get().toString();
    }

    private void printAttributes(Attributes attrs) {
        System.out.println(">>");

        if (attrs == null) {
            System.out.println("No attributes");
        } else {
            try {
                for (NamingEnumeration ae = attrs.getAll(); ae.hasMore();) {
                    Attribute attr = (Attribute) ae.next();
                    System.out.println("Attribute ID: " + attr.getID());

                    NamingEnumeration e = attr.getAll();
                    while (e.hasMore()) {
                        String value = e.next().toString();
                        System.out.println("Value: " + value);
                    }
                }
            } catch (NamingException e) {
                e.printStackTrace();
            }
        }

        System.out.println("<<");
    }
}
