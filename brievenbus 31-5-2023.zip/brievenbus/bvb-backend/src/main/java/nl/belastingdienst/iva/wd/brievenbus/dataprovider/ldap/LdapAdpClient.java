package nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;

@Component
public class LdapAdpClient extends LdapClient {

	@Value("${ldap.adp.partitionSuffix.human}")
	private String ldapAdpPartitionSuffixHuman;

	@Value("${ldap.adp.partitionSuffix.batch}")
	private String ldapAdpPartitionSuffixBatch;

	@Override
	public LdapPerson authenticateInLdap(ApplicationUser user) {
		if (super.authenticate(user, ldapAdpPartitionSuffixHuman)) {
			return super.getPersonByUserId(user.getUsername(), ldapAdpPartitionSuffixHuman);
		}
		if (super.authenticate(user, ldapAdpPartitionSuffixBatch)) {
			return super.getPersonByUserId(user.getUsername(), ldapAdpPartitionSuffixBatch);
		}
		super.processNotAuthenticatedError(user.getUsername());
		return null;
	}

}
