package nl.belastingdienst.iva.wd.brievenbus.security;

import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

import nl.belastingdienst.iva.wd.brievenbus.filter.AuthorizationFilter;
import nl.belastingdienst.iva.wd.brievenbus.filter.FilterExceptionHandlerFilter;
import nl.belastingdienst.iva.wd.brievenbus.filter.JWTAuthenticationFilter;
import nl.belastingdienst.iva.wd.brievenbus.filter.LoginAuthenticationFilter;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

/**
 * The @Order must be HIGHER than the one for {@link WebSecurityAutomaticDeliveries} because
 * checking the security for automatic deliveries must be done first.
 */
@EnableWebSecurity
@Order(2)
public class WebSecurity extends WebSecurityConfigurerAdapter {

    private final Environment env;
    private final JwtUtils jwtUtils;
    private final SecurityUtils securityUtils;
    private final HandlerExceptionResolver handlerExceptionResolver;
    private final AuditService auditService;

    public WebSecurity(Environment env, JwtUtils jwtUtils, SecurityUtils securityUtils,
            HandlerExceptionResolver handlerExceptionResolver, AuditService auditService) {
        this.env = env;
        this.jwtUtils = jwtUtils;
        this.securityUtils = securityUtils;
        this.handlerExceptionResolver = handlerExceptionResolver;
        this.auditService = auditService;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .cors().and().csrf().disable()
            .authorizeRequests()
            // "/actuator/health" is necessary for OpenShift checks (see template.yaml files)
            .antMatchers("/actuator/health", "/", "/api/login", "/api/application/configuration",
                "/assets/**", "/index.html", "/*.js", "/*.css", "/*.png", "/*.svg", "/*.ttf", "/*.eot", "/*.woff", "/favicon.ico").permitAll()
            .anyRequest().authenticated()
            .and()
            .addFilterBefore(new FilterExceptionHandlerFilter(handlerExceptionResolver), LogoutFilter.class)
            .addFilter(new LoginAuthenticationFilter(jwtUtils, securityUtils))
            .addFilter(new JWTAuthenticationFilter(jwtUtils, authenticationManager()))
            .addFilterAfter(new AuthorizationFilter(env, jwtUtils, auditService), BasicAuthenticationFilter.class)
            // this disables session creation on Spring Security
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        // This option is needed to enable the h2 console
        http.headers().frameOptions().sameOrigin();
    }
}
