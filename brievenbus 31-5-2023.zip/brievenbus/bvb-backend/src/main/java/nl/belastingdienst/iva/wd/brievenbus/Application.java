package nl.belastingdienst.iva.wd.brievenbus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapAdpClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapClient;
import nl.belastingdienst.iva.wd.brievenbus.dataprovider.ldap.LdapDwbClient;
import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationPlatform;
import nl.belastingdienst.iva.wd.brievenbus.security.JwtUtils;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityUtils;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;
import nl.belastingdienst.iva.wd.brievenbus.utils.MailboxUtils;

@SpringBootApplication
@EnableScheduling
public class Application {

	private static final String LDAP_PREFIX = "ldap.";
	private static final String LDAP_URL = ".url";
	private static final String LDAP_USER = ".user";
	private static final String LDAP_PASSWORD = ".password";

	@Autowired
	private Environment env;

	@Autowired
	private AuditService auditService;

	@Autowired
	private LdapAdpClient ldapAdpClient;

	@Autowired
	private LdapDwbClient ldapDwbClient;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public LdapContextSource contextSource() {
		String applicationPlatform = env.getRequiredProperty("application.platform", String.class).toLowerCase();
		LdapContextSource contextSource = new LdapContextSource();
		contextSource.setUrl(env.getRequiredProperty(LDAP_PREFIX + applicationPlatform + LDAP_URL));
		contextSource.setUserDn(env.getRequiredProperty(LDAP_PREFIX + applicationPlatform + LDAP_USER));
		contextSource.setPassword(env.getRequiredProperty(LDAP_PREFIX + applicationPlatform + LDAP_PASSWORD));
		contextSource.afterPropertiesSet();
		return contextSource;
	}

	@Bean
	public LdapTemplate ldapTemplate() {
		return new LdapTemplate(contextSource());
	}

	@Bean
	public JwtUtils jwtUtils() {
		return new JwtUtils(env);
	}

	@Bean
	public MailboxUtils mailboxUtils() {
		return new MailboxUtils();
	}

	@Bean
	public SecurityUtils securityUtils() {
		String applicationPlatform = env.getRequiredProperty("application.platform", String.class).toLowerCase();
		LdapClient ldapClient = ApplicationPlatform.ADP.getPlatform().equalsIgnoreCase(applicationPlatform) ? ldapAdpClient : ldapDwbClient;
		return new SecurityUtils(env, auditService, ldapClient);
	}
}
