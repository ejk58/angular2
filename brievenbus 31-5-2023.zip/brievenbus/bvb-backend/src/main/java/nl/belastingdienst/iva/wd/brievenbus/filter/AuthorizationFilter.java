package nl.belastingdienst.iva.wd.brievenbus.filter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.env.Environment;
import org.springframework.security.access.AuthorizationServiceException;
import org.springframework.web.filter.OncePerRequestFilter;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationPlatform;
import nl.belastingdienst.iva.wd.brievenbus.security.JwtUtils;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityConstants;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;

public class AuthorizationFilter extends OncePerRequestFilter {

    private static final List<String> ADP_ALLOWED_POST_REST_CALLS = Arrays.asList("/api/upload/offer", "/api/upload/offer/automatic");
    private static final String UNAUTHORIZED_POST = "Er is geprobeerd een ongeautoriseerde POST uit te voeren door ";
    private static final String RESTCALL_NOT_PERMITTED = "Restcall niet toegestaan";
    private static final String SPLIT_CHARACTER = ":";

    private final Environment env;
    private final JwtUtils jwtUtils;
    private final AuditService auditService;

    public AuthorizationFilter(Environment env, JwtUtils jwtUtils, AuditService auditService) {
        this.env = env;
        this.jwtUtils = jwtUtils;
        this.auditService = auditService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws IOException, ServletException {
        if (request.getMethod().equals("POST") && !isPostAllowed(request)) {
            this.auditService.logUserAction(UNAUTHORIZED_POST + getUserFromToken(request));
            throw new AuthorizationServiceException(RESTCALL_NOT_PERMITTED);
        }
        chain.doFilter(request, response);
    }

    private boolean isPostAllowed(HttpServletRequest request) {
        String applicationPlatform = env.getRequiredProperty("application.platform", String.class);
        String url = request.getRequestURL().toString();
        String postRestCall = url.substring(url.indexOf("/api"));
        return request.getMethod().equals("POST")
            && ADP_ALLOWED_POST_REST_CALLS.contains(postRestCall)
            && ApplicationPlatform.ADP.getPlatform().equals(applicationPlatform);
    }

    private String getUserFromToken(HttpServletRequest request) {
        String headerAuthorization = request.getHeader(SecurityConstants.HEADER_AUTHORIZATION);
        if (headerAuthorization != null) {
            if (headerAuthorization.startsWith(SecurityConstants.BEARER_PREFIX)) {
                // Using web-application
                String token = headerAuthorization.replace(SecurityConstants.BEARER_PREFIX, "");
                return jwtUtils.validateJwtToken(token).getSubject();
            } else if (headerAuthorization.startsWith(SecurityConstants.BASIC_PREFIX)) {
                // Using api
                String token = headerAuthorization.replace(SecurityConstants.BASIC_PREFIX, "");
                byte[] decodedToken = Base64.getDecoder().decode(token);
                String userPassword = new String(decodedToken, StandardCharsets.UTF_8);
                return userPassword.split(SPLIT_CHARACTER)[0];
            }
        }
        return null;
    }

}
