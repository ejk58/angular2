package nl.belastingdienst.iva.wd.brievenbus.controller;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import javax.annotation.security.RolesAllowed;
import javax.persistence.PersistenceException;
import javax.xml.bind.DatatypeConverter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import nl.belastingdienst.iva.wd.brievenbus.dao.DeliveryRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.FileRepository;
import nl.belastingdienst.iva.wd.brievenbus.dao.ReceiverRepository;
import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import nl.belastingdienst.iva.wd.brievenbus.domain.LoggedInUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;
import nl.belastingdienst.iva.wd.brievenbus.domain.exception.UnprocessableException;
import nl.belastingdienst.iva.wd.brievenbus.dto.ReceiverJson;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityConstants;
import nl.belastingdienst.iva.wd.brievenbus.service.AuditService;
import nl.belastingdienst.iva.wd.brievenbus.service.FileService;
import nl.belastingdienst.iva.wd.brievenbus.service.MailService;
import nl.belastingdienst.iva.wd.brievenbus.validator.UploadValidator;

@RestController
@RequestMapping("/api/upload")
@Transactional
public class UploadController {

    private static final String START_OFFER = "Starten opslaan delivery en verzenden email";
    private static final String END_OFFER = "Einde opslaan delivery en verzenden email";
    private static final String START_SAVING_DELIVERY = "Starten met opslaan van delivery";
    private static final String START_SAVING_RECEIVER = "Starten met opslaan van receiver";
    private static final String START_SAVING_FILE = "Starten met opslaan van file";
    private static final String DELIVERY_SAVED = "Opslaan van delivery is gelukt";
    private static final String RECEIVER_SAVED = "Opslaan van receiver is gelukt";
    private static final String FILE_SAVED = "Opslaan van file is gelukt";
    private static final String DELIVERY_SAVE_ERROR = "Opslaan van delivery is niet gelukt";
    private static final String RECEIVER_SAVE_ERROR = "Opslaan van receiver is niet gelukt";
    private static final String FILE_SAVE_ERROR = "Opslaan van file is niet gelukt";

    private static final Logger LOGGER = LogManager.getLogger(UploadController.class);

    @Value("${link.expiration.period.in.weeks}")
    private int linkExpirationPeriodInWeeks;

    @Autowired
    private DeliveryRepository deliveryRepository;

    @Autowired
    private FileRepository fileRepository;

    @Autowired
    private ReceiverRepository receiverRepository;

    @Autowired
    private MailService mailService;

    @Autowired
    private FileService fileService;

    @Autowired
    private AuditService auditService;

    @Autowired
    private UploadValidator uploadValidator;

    @RolesAllowed(SecurityConstants.ROLE_UPLOADER_ADP)
    @PostMapping(value = "/offer", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> offer(
            @RequestParam("file") MultipartFile file,
            @RequestParam(name = "productNumber", required = false) String productNumber,
            @RequestParam(name = "isVerifyMailboxChecked", required = false) Boolean isVerifyMailboxChecked,
            @RequestParam("receivers") List<ReceiverJson> receivers,
            @AuthenticationPrincipal LoggedInUser loggedInUser) {

        ResponseEntity<String> errorResponse = validateParameters(loggedInUser, receivers, productNumber, isVerifyMailboxChecked);
        if (errorResponse != null)
            return errorResponse;

        this.auditService.logUserAction(START_OFFER, loggedInUser, file.getOriginalFilename());
        Delivery deliveryEntity = new Delivery();
        deliveryEntity.setUuid(UUID.randomUUID());
        String productNumberForMailAndAuditing = productNumber != null ? productNumber.trim() : "";

        updateDatabase(deliveryEntity, loggedInUser, receivers, file);
        this.fileService.writeFileToDirectoryOnSystem(deliveryEntity, file, loggedInUser);
        this.mailService.createAndSendMail(deliveryEntity, receivers, productNumberForMailAndAuditing, loggedInUser);
        this.auditService.logUserAction(END_OFFER, loggedInUser, file.getOriginalFilename(), deliveryEntity.getUuid());

        this.auditService.logSendAction(loggedInUser, deliveryEntity, productNumberForMailAndAuditing, isVerifyMailboxChecked);
        return ResponseEntity.ok("{\"message\": \"Bestand goed verwerkt!\", \"deliveryUUID\": \"" + deliveryEntity.getUuid() + "\"}");
    }

    @RolesAllowed(SecurityConstants.ROLE_UPLOADER_AUTOMATIC)
    @PostMapping(value = "/offer/automatic", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> offerAutomatic(
            @RequestParam("file") MultipartFile file,
            @RequestParam(name = "productNumber", required = false) String productNumber,
            @RequestParam(name = "isVerifyMailboxChecked", required = false) Boolean isVerifyMailboxChecked,
            @RequestParam("receivers") List<ReceiverJson> receivers,
            @AuthenticationPrincipal LoggedInUser loggedInUser) {
        return this.offer(file, productNumber, isVerifyMailboxChecked, receivers, loggedInUser);
    }

    private ResponseEntity<String> validateParameters(LoggedInUser loggedInUser, List<ReceiverJson> receivers, String productNumber, Boolean isVerifyMailboxChecked) {
        ResponseEntity<String> errorResponse = uploadValidator.validateSender(loggedInUser, receivers);
        errorResponse = errorResponse == null ? uploadValidator.validateReceivers(receivers) : errorResponse;
        errorResponse = errorResponse == null ? uploadValidator.validateProductNumber(productNumber) : errorResponse;
        errorResponse = errorResponse == null ? uploadValidator.validateIsVerifyMailboxChecked(isVerifyMailboxChecked, receivers) : errorResponse;
        return errorResponse;
    }

    private void updateDatabase(Delivery deliveryEntity, LoggedInUser loggedInUser, List<ReceiverJson> receivers, MultipartFile file) {
        persistNewDeliveryEntity(deliveryEntity, loggedInUser);
        for(ReceiverJson receiver : receivers) {
            persistNewReceiverEntity(deliveryEntity, receiver, loggedInUser);
        }
        persistNewFileEntity(deliveryEntity, file,loggedInUser);
    }

    private void persistNewDeliveryEntity(Delivery deliveryEntity, LoggedInUser loggedInUser) {
        LocalDateTime created = LocalDateTime.now();
        LocalDateTime expiration = created.plusWeeks(linkExpirationPeriodInWeeks);

        deliveryEntity.setSender(loggedInUser.getUsername());
        deliveryEntity.setCreated(created);
        deliveryEntity.setExpiration(expiration);

        this.auditService.logUserAction(START_SAVING_DELIVERY, loggedInUser, deliveryEntity.getUuid());
        try {
            this.deliveryRepository.save(deliveryEntity);
            this.auditService.logUserAction(DELIVERY_SAVED, loggedInUser, deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            this.auditService.logUserAction(DELIVERY_SAVE_ERROR, loggedInUser, deliveryEntity.getUuid());
            throw new UnprocessableException(DELIVERY_SAVE_ERROR, e);
        }
    }

    private void persistNewReceiverEntity(Delivery deliveryEntity, ReceiverJson receiver, LoggedInUser loggedInUser) {
        Receiver receiverEntity = new Receiver();
        receiverEntity.setDelivery(deliveryEntity);
        receiverEntity.setUserid(receiver.getId());

        deliveryEntity.addReceiver(receiverEntity);

        this.auditService.logUserAction(START_SAVING_RECEIVER, loggedInUser, deliveryEntity.getUuid());
        try {
            this.receiverRepository.save(receiverEntity);
            this.auditService.logUserAction(RECEIVER_SAVED, loggedInUser, deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            this.auditService.logUserAction(RECEIVER_SAVE_ERROR, loggedInUser, deliveryEntity.getUuid());
            throw new UnprocessableException(RECEIVER_SAVE_ERROR, e);
        }
    }

    private void persistNewFileEntity(Delivery deliveryEntity, MultipartFile file, LoggedInUser loggedInUser) {
        File fileEntity = new File();
        fileEntity.setHash(getFileHash(file));
        fileEntity.setName(file.getOriginalFilename());
        fileEntity.setBytes(file.getSize());
        fileEntity.setDelivery(deliveryEntity);

        deliveryEntity.setFile(fileEntity);

        this.auditService.logUserAction(START_SAVING_FILE, loggedInUser, deliveryEntity.getUuid());
        try {
            this.fileRepository.save(fileEntity);
            this.auditService.logUserAction(FILE_SAVED, loggedInUser, deliveryEntity.getUuid());
        } catch (PersistenceException e) {
            this.auditService.logUserAction(FILE_SAVE_ERROR, loggedInUser, deliveryEntity.getUuid());
            throw new UnprocessableException(FILE_SAVE_ERROR, e);
        }
    }

    private String getFileHash(MultipartFile file) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(file.getBytes());
            byte[] digested = md.digest();
            return DatatypeConverter.printHexBinary(digested).toUpperCase();
        } catch (NoSuchAlgorithmException | IOException e) {
            LOGGER.error(e);
        }

        return "no-hash-generated-due-to-error";
    }
}
