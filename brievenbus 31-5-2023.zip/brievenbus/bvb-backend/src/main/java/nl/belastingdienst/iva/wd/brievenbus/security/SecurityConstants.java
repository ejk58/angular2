package nl.belastingdienst.iva.wd.brievenbus.security;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SecurityConstants {

	// Generated with command: openssl rand -base64 64
	public static final String SECRET = "n0slkM18TEgnxv/0HzAvHzhObkNWoIzSbOiv/3lCGF1uia9TgN4MZyHhAp0rbYwZDVhjC0eKwA4rr29s4GoDBf";
	public static final String BEARER_PREFIX = "Bearer ";
	public static final String BASIC_PREFIX = "Basic ";
	public static final String HEADER_AUTHORIZATION = "Authorization";
	public static final String TENANT = "tenant";
	public static final String AUTHORITIES = "authorities";
	public static final String ROLE_UPLOADER_ADP = "ROLE_UPLOADER_ADP";
	public static final String ROLE_UPLOADER_AUTOMATIC = "ROLE_UPLOADER_AUTOMATIC";
	public static final String DEFAULT_PASSWORD = "nvt";
}
