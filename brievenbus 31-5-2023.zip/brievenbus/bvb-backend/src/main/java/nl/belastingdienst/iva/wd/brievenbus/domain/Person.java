package nl.belastingdienst.iva.wd.brievenbus.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Person extends Recipient {

	public Person() {
		setType(RecipientType.PERSON);
	}
}
