package nl.belastingdienst.iva.wd.brievenbus.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.auth0.jwt.interfaces.DecodedJWT;

import nl.belastingdienst.iva.wd.brievenbus.security.JwtUtils;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityConstants;

public class JWTAuthenticationFilter extends BasicAuthenticationFilter {

	private final JwtUtils jwtUtils;

	public JWTAuthenticationFilter(JwtUtils jwtUtils, AuthenticationManager authenticationManager) {
		super(authenticationManager);
		this.jwtUtils = jwtUtils;
	}

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws IOException, ServletException {
		String headerAuthorization = request.getHeader(SecurityConstants.HEADER_AUTHORIZATION);
		if (headerAuthorization != null && headerAuthorization.startsWith(SecurityConstants.BEARER_PREFIX)) {
			String token = headerAuthorization.replace(SecurityConstants.BEARER_PREFIX, "");
			DecodedJWT decodedJWT = jwtUtils.validateJwtToken(token);
			UsernamePasswordAuthenticationToken authenticationToken = jwtUtils.createAuthenticationTokenFromJwtToken(decodedJWT);
			SecurityContextHolder.getContext().setAuthentication(authenticationToken);
		}
		chain.doFilter(request, response);
	}

}
