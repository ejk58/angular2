package nl.belastingdienst.iva.wd.brievenbus.filter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

import nl.belastingdienst.iva.wd.brievenbus.exception.GlobalExceptionHandler;
import nl.belastingdienst.iva.wd.brievenbus.security.WebSecurity;
import nl.belastingdienst.iva.wd.brievenbus.security.WebSecurityAutomaticDeliveries;

/**
 * Class with which errors that occur in a filter can still be handled by {@link GlobalExceptionHandler},
 * whereas that class normally only handles errors from controllers because it is annotated with '@ControllerAdvice'.
 * The class itself is also a filter that must be executed before any other filter (see {@link WebSecurity} and
 * {@link WebSecurityAutomaticDeliveries}).
 */
public class FilterExceptionHandlerFilter extends OncePerRequestFilter {

    private final HandlerExceptionResolver handlerExceptionResolver;

    public FilterExceptionHandlerFilter(HandlerExceptionResolver handlerExceptionResolver) {
        this.handlerExceptionResolver = handlerExceptionResolver;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
        try {
            filterChain.doFilter(request, response);
        } catch (Exception e) {
            handlerExceptionResolver.resolveException(request, response, null, e);
        }
    }
}
