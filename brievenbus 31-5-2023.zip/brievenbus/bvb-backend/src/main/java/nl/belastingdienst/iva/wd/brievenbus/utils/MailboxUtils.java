package nl.belastingdienst.iva.wd.brievenbus.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import nl.belastingdienst.iva.wd.brievenbus.domain.Mailbox;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class MailboxUtils {

    @Value("${application.mailboxes}")
    private String applicationMailboxes;

    private List<Mailbox> mailboxes;

    @PostConstruct
    public void readConfig() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mailboxes = Arrays.stream(mapper.readValue(applicationMailboxes, Mailbox[].class)).collect(Collectors.toList());
        mailboxes.sort(Comparator.comparing(Mailbox::getName, String::compareToIgnoreCase));
    }

    public List<Mailbox> getMailboxes(String userIdOrName) {
        return mailboxes.stream().filter(mailbox -> mailbox.getName().toLowerCase().startsWith(userIdOrName.toLowerCase()))
                .collect(Collectors.toList());
    }

    public Mailbox getMailbox(String id) {
        return mailboxes.stream().filter((mailbox -> mailbox.getId().equalsIgnoreCase(id))).findAny().orElse(null);
    }

    public boolean isMailbox(String id) {
        return mailboxes.stream().anyMatch(mailbox -> mailbox.getId().equalsIgnoreCase(id));
    }
}
