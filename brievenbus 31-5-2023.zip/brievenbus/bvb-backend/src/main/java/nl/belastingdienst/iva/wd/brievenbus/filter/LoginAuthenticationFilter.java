package nl.belastingdienst.iva.wd.brievenbus.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;
import nl.belastingdienst.iva.wd.brievenbus.security.JwtUtils;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityConstants;
import nl.belastingdienst.iva.wd.brievenbus.security.SecurityUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoginAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private final JwtUtils jwtUtils;
    private final SecurityUtils securityUtils;

    public LoginAuthenticationFilter(JwtUtils jwtUtils, SecurityUtils securityUtils) {
        this.jwtUtils = jwtUtils;
        this.securityUtils = securityUtils;
        setFilterProcessesUrl("/api/login");
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        try {
            ApplicationUser user = new ObjectMapper().readValue(request.getInputStream(), ApplicationUser.class);
            // ldap authentication accepts empty passwords!
            if (user.getPassword().isEmpty()) {
                user.setPassword(null);
            }
            return this.securityUtils.authenticateInLdapForApplicationLogin(user);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request,
                                            HttpServletResponse response,
                                            FilterChain chain,
                                            Authentication authentication) {
        String token = jwtUtils.generateJwtToken(authentication);
        response.addHeader(SecurityConstants.HEADER_AUTHORIZATION, SecurityConstants.BEARER_PREFIX + token);
    }
}