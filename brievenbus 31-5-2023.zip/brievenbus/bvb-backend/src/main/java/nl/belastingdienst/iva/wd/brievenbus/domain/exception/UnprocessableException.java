package nl.belastingdienst.iva.wd.brievenbus.domain.exception;

public class UnprocessableException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public UnprocessableException(String message) {
        super(message);
    }

    public UnprocessableException(String message, Throwable cause) {
        super(message, cause);
    }
}
