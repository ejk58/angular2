package nl.belastingdienst.iva.wd.brievenbus.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.brievenbus.domain.Delivery;
import nl.belastingdienst.iva.wd.brievenbus.domain.File;
import nl.belastingdienst.iva.wd.brievenbus.domain.LoggedInUser;
import nl.belastingdienst.iva.wd.brievenbus.domain.Receiver;

@Component
public class AuditService {

    private static final String ACTION_LABEL = " ACTION: ";
    private static final String USERID_LABEL = "USERNAME: ";
    private static final String TENANT_LABEL = "TENANT: ";
    private static final String FILE_LABEL = "FILE: ";
    private static final String DELIVERY_UUID_LABEL = "DELIVERY UUID: ";
    private static final String SENDER_LABEL = "SENDER: ";
    private static final String RECIPIENTS_LABEL = "RECIPIENTS: ";
    private static final String PRODUCT_NUMBER_LABEL = "PRODUCT NUMBER: ";
    private static final String VERIFY_MAILBOX_CHECKED = "VERIFY MAILBOX CHECKED: ";
    private static final String SEND_FILE_ACTION = "Verzenden bestand";
    private static final String DOWNLOAD_FILE_ACTION = "Downloaden bestand";
    private static final String CUSTOM_LEVEL = "AUDIT";
    private static final int CUSTOM_INT_VALUE = 250;
    private static final String EMPTY = "";
    private static final String SEPARATOR = "\t ";

    private static final Logger logger = LogManager.getLogger(AuditService.class);

    public void logSendAction(LoggedInUser loggedInUser, Delivery delivery, String productNumber, Boolean isVerifyMailboxChecked) {
        String userId = loggedInUser.getUsername();
        String tenant = loggedInUser.getTenant();
        String uuid = delivery.getUuid().toString();
        File file = delivery.getFile();
        String filename = file.getName();
        long filesize = file.getBytes();
        List<Receiver> receivers = delivery.getReceivers();
        String recipients = receivers.stream().map(Receiver::getUserid).collect(Collectors.joining(", "));
        String verifyMailboxChecked = isVerifyMailboxChecked != null ? String.valueOf(isVerifyMailboxChecked) : EMPTY;

        logger.log(Level.forName(CUSTOM_LEVEL, CUSTOM_INT_VALUE),
                ACTION_LABEL + SEND_FILE_ACTION + SEPARATOR +
                USERID_LABEL + userId + SEPARATOR +
                TENANT_LABEL + tenant + SEPARATOR +
                DELIVERY_UUID_LABEL + uuid + SEPARATOR +
                FILE_LABEL + filename + " (" + filesize + ")" + SEPARATOR +
                RECIPIENTS_LABEL + recipients + SEPARATOR +
                PRODUCT_NUMBER_LABEL + productNumber + SEPARATOR +
                VERIFY_MAILBOX_CHECKED + verifyMailboxChecked);
    }

    public void logReceiveAction(LoggedInUser loggedInUser, Delivery delivery) {
        String userId = loggedInUser.getUsername();
        String tenant = loggedInUser.getTenant();
        String uuid = delivery.getUuid().toString();
        File file = delivery.getFile();
        String filename = file.getName();
        long filesize = file.getBytes();
        String sender = delivery.getSender();

        logger.log(Level.forName(CUSTOM_LEVEL, CUSTOM_INT_VALUE),
                ACTION_LABEL + DOWNLOAD_FILE_ACTION + SEPARATOR +
                USERID_LABEL + userId + SEPARATOR +
                TENANT_LABEL + tenant + SEPARATOR +
                DELIVERY_UUID_LABEL + uuid + SEPARATOR +
                FILE_LABEL + filename + " (" + filesize + ")" + SEPARATOR +
                SENDER_LABEL + sender);
    }

    public void logUserAction(String action, LoggedInUser loggedInUser, String fileName, UUID deliveryUUID) {
        String userId = loggedInUser == null ? EMPTY : loggedInUser.getUsername();
        String tenant = loggedInUser == null ? EMPTY : loggedInUser.getTenant();
        String uuid = deliveryUUID == null ? EMPTY : deliveryUUID.toString();

        logger.log(Level.forName(CUSTOM_LEVEL, CUSTOM_INT_VALUE),
                ACTION_LABEL + action + SEPARATOR +
                USERID_LABEL + userId + SEPARATOR +
                TENANT_LABEL + tenant + SEPARATOR +
                DELIVERY_UUID_LABEL + uuid + SEPARATOR +
                FILE_LABEL + fileName);
    }

    public void logUserAction(String action) {
        this.logUserAction(action, null, EMPTY, null);
    }

    public void logUserAction(String action, LoggedInUser loggedInUser) {
        this.logUserAction(action, loggedInUser, EMPTY, null);
    }

    public void logUserAction(String action, LoggedInUser loggedInUser, String fileName) {
        this.logUserAction(action, loggedInUser, fileName, null);
    }

    public void logUserAction(String action, LoggedInUser loggedInUser, UUID deliveryUUID) {
        this.logUserAction(action, loggedInUser, EMPTY, deliveryUUID);
    }
}
