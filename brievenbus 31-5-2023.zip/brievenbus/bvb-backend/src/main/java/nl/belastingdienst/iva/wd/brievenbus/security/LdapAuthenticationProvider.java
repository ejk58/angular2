package nl.belastingdienst.iva.wd.brievenbus.security;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import nl.belastingdienst.iva.wd.brievenbus.domain.ApplicationUser;

public class LdapAuthenticationProvider implements AuthenticationProvider {

	private final SecurityUtils securityUtils;

	public LdapAuthenticationProvider(SecurityUtils securityUtils) {
		this.securityUtils = securityUtils;
	}

	@Override
	public Authentication authenticate(Authentication authentication) {
		ApplicationUser user = new ApplicationUser();
		user.setUsername(authentication.getPrincipal().toString());
		// ldap authentication accepts empty passwords!
		user.setPassword(authentication.getCredentials().toString().isEmpty() ? null : authentication.getCredentials().toString());
		return securityUtils.authenticateInLdapForAutomaticDeliveriesLogin(user);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}
}
