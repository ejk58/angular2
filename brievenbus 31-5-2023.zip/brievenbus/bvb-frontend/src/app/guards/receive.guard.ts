import {Injectable} from '@angular/core';
import {CanActivate, Router} from '@angular/router';
import {ApplicationConfigService} from '../services/application-config.service';
import {ApplicationPlatform} from '../domain/application-platform';

@Injectable()
export class ReceiveGuard implements CanActivate {

  constructor(private readonly applicationConfigService: ApplicationConfigService, private readonly router: Router) {
  }

  canActivate() {
    if (this.applicationConfigService.getApplicationPlatform() !== ApplicationPlatform.DWB) {
      this.router.navigate(['']);
    }
    return true;
  }
}
