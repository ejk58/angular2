import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Router} from '@angular/router';
import {LoginService} from '../services/login.service';

@Injectable()
export class LoggedInGuard implements CanActivate {

  constructor(private readonly loginService: LoginService, private readonly router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot) {
    if (!this.loginService.isLoggedInNow()) {
      // queryParamsHandling is NOT handled in a guard!
      return this.router.createUrlTree(['login'], {queryParams: route.queryParams});
    }
    return true;
  }
}
