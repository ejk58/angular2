import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {LoginService} from './services/login.service';
import {Observable, Subject} from 'rxjs';
import {DialogService} from 'primeng/dynamicdialog';
import {ErrorService} from './services/error.service';
import {takeUntil} from 'rxjs/operators';
import {ErrorComponent} from './error/error.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {

  // Necessary to show modal ErrorComponent automatically
  @ViewChild('hiddenModalBtn', {read: ElementRef}) myHiddenModalBtn: ElementRef;

  private readonly ngUnsubscribe$ = new Subject<void>();

  title = 'Brievenbus';
  isLoggedIn$: Observable<boolean>;
  loggedInUser$: Observable<string>;

  constructor(private readonly loginService: LoginService,
              private readonly errorService: ErrorService,
              private readonly dialogService: DialogService) {
  }

  ngOnInit(): void {
    this.isLoggedIn$ = this.loginService.isLoggedIn();
    this.loggedInUser$ = this.loginService.loggedInUser();
    this.initializeModalForErrorMessage();
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe$.next();
    this.ngUnsubscribe$.complete();
  }

  logout(): void {
    this.loginService.logout();
  }

  // Only necessary to show modal ErrorComponent automatically.
  public openModalForErrorMessage(): void {
    // Intentionally left empty.
  }

  private initializeModalForErrorMessage(): void {
    this.errorService
      .getErrorMessage()
      .pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe({
        next: errorMessage => {
          this.dialogService.open(ErrorComponent, {data: {errorMessage}, header: 'Foutmelding', width: '50%'});
          this.myHiddenModalBtn.nativeElement.click(); // Show modal ErrorComponent automatically
        }, error: error => {
          console.log(error);
        }
      });
  }

}
