import {Component, OnInit} from '@angular/core';
import {ApplicationPlatform} from './domain/application-platform';
import {Router} from '@angular/router';
import {ApplicationConfigService} from './services/application-config.service';

@Component({
  selector: 'app-platform-choice',
  template: ''
})
export class PlatformChoiceComponent implements OnInit {

  constructor(private readonly applicationConfigService: ApplicationConfigService,
              private readonly router: Router) { }

  ngOnInit() {
    if (this.applicationConfigService.getApplicationPlatform() === ApplicationPlatform.ADP) {
      this.router.navigate(['send'], {queryParamsHandling: 'preserve'});
    } else if (this.applicationConfigService.getApplicationPlatform() === ApplicationPlatform.DWB) {
      this.router.navigate(['receive'], {queryParamsHandling: 'preserve'});
    } else {
      this.router.navigate(['login']);
    }
  }
}
