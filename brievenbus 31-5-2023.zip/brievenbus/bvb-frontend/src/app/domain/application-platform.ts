export enum ApplicationPlatform {
  ADP = 'ADP',
  DWB = 'DWB'
}
