export interface VerificationValues {
  isCheckedPerson: boolean;
  isCheckedMailbox: boolean;
}
