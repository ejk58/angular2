import {RecipientType} from './recipient-type';

export interface Receiver {
  id: string;
  email: string;
  name: string;
  type: RecipientType;
}
