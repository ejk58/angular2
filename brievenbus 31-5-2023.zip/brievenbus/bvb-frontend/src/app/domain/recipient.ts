import {RecipientType} from './recipient-type';

export interface Recipient {
  id: string;
  name: string;
  email: string;
  adGroup?: string;
  type: RecipientType
}
