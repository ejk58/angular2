export type DisclaimerType = 'verify-person' | 'verify-mailbox' | 'receive';
