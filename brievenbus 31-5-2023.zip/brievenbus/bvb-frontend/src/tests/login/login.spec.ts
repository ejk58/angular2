import {expect, Page, test} from '@playwright/test';
import {General} from '../shared/general';
import {Login} from '../shared/login';
import {APPURL, BRIEVENBUS_USER} from '../shared/shared.constants';
import LoginPo from './LoginPo';
import config from '../playwright.config';

test.describe('Login', () => {

  let page: Page, general: General, login: Login, loginPo: LoginPo;

  test.beforeAll(async ({browser}) => {
    page = await browser.newPage({viewport: null});
    await page.setViewportSize({width: config.use.viewport.width, height: config.use.viewport.height});
    general = new General(page);
    login = new Login(page);
    loginPo = new LoginPo(page);

    await page.goto(`${APPURL.baseUrl.adp}/login`);
  });

  test.beforeEach(async ({}, testInfo) => {
    testInfo.snapshotSuffix = '';
  });

  test.afterAll(async () => {
    await page.close();
  });

  test('Should show initial login page', async () => {
    await general.waitForAngular();
    await login.openApp('adp');
    await general.checkWindow('loginInitial.png');
  });

  test('Should not show the logged in content in the header before logging inn page', async () => {
    await expect(page.locator('.logged-in-header-content')).not.toBeVisible();
    await general.checkRegion(page.locator('body > app-root > header'), 'loginHeaderContentNotPresentBeforeLoggingIn.png')
  });

  test('Should not login with invalid password', async () => {
    await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password + '1', true);
    await expect(loginPo.loginError).toHaveText(loginPo.errorMessageRetry);
    await general.checkRegion(loginPo.authenticationContainer, 'loginError.png');
  });

  test('Should not login with invalid user', async () => {
    await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1 + 'Wrong', BRIEVENBUS_USER.user.password, true);
    await expect(loginPo.loginError).toHaveText(loginPo.errorMessageRetry);
  });

  test('Should not login without password', async () => {
    await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, '', true);
    await general.checkRegion(loginPo.authenticationContainer, 'loginErrorNoPassword.png');
  });

  test('Should login with correct user', async () => {
    await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
    await expect(page.locator('.receivers-container .sub-header')).toHaveText('Ontvangers');
  });

  test('Should show the logged in content in the header after logging in', async () => {
    await expect(page.locator('.logged-in-header-content > span')).toBeVisible();
    await expect(page.locator('.logged-in-header-content > span')).toHaveText(BRIEVENBUS_USER.user.ivatest1);
    await general.checkRegion(page.locator('body > app-root > header'), 'loginHeaderContentPresentAfterLoggingIn.png');
  });
});
