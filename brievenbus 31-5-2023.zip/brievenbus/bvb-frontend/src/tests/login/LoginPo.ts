import {Locator, Page} from '@playwright/test';

export default class LoginPo {
  readonly authenticationContainer: Locator;
  readonly userIdInput: Locator;
  readonly userPasswordInput: Locator;
  readonly loginError: Locator;
  readonly errorMessageRetry: string;

  constructor(page: Page) {
    this.authenticationContainer = page.locator('.login-form');
    this.userIdInput = page.locator('form > span > input').nth(0);
    this.userPasswordInput = page.locator('form > span > input').nth(1);
    this.loginError = page.locator('.login-form .login-error');
    this.errorMessageRetry = 'Gebruikersnaam en/of wachtwoord fout';
  }
}
