import {Page, test} from '@playwright/test';
import {General} from '../../shared/general';
import {Login} from '../../shared/login';
import {APPURL, BRIEVENBUS_USER} from '../../shared/shared.constants';
import CheckPo from './CheckPo';
import SelectPo from '../select/SelectPo';
import config from '../../playwright.config';

test.describe('Send (adp): Check', () => {

  let page: Page, general: General, login: Login, checkPo: CheckPo, selectPo: SelectPo;

  const path = require('path'),
    resourceDir = `${process.cwd()}/resources`; // comment for local use
  // resourceDir = `${process.cwd()}/src/tests//resources`;  //uncomment for local use

  test.beforeAll(async ({browser}) => {
    page = await browser.newPage({viewport: null});
    await page.setViewportSize({width: config.use.viewport.width, height: config.use.viewport.height});
    general = new General(page);
    login = new Login(page);
    checkPo = new CheckPo(page);
    selectPo = new SelectPo(page);

    await page.goto(`${APPURL.baseUrl.adp}/login`);
    await login.loginToApp('adp', BRIEVENBUS_USER.user.ivatest1, BRIEVENBUS_USER.user.password);
    await selectPo.receiversUserid.fill('bihas07');
    await selectPo.receiversButtonPlus.click();
    await selectPo.fileUploadInput.setInputFiles(path.resolve(resourceDir, 'upload.txt'));
    await selectPo.buttonContainerConfirm.click();
  });

  test.beforeEach(async ({}, testInfo) => {
    testInfo.snapshotSuffix = '';
  });

  test.afterAll(async () => {
    await page.close();
  });

  test('Should show initial check page', async () => {
    await general.checkWindow('sendCheckInitial.png')
  });

  test('Should show check page when navigated back to add user and replaced file', async () => {
    await checkPo.buttonContainerBack.click();
    await selectPo.receiversUserid.fill('kerke02');
    await selectPo.receiversButtonPlus.click();
    await selectPo.fileUploadRemove.click();
    await selectPo.fileUploadInput.setInputFiles(path.resolve(resourceDir, 'uploadSecond.txt'));
    await selectPo.buttonContainerConfirm.click();
    await general.checkRegion(checkPo.wizardContainer, 'sendCheckNavigateBackWithNewData.png');
  });
});
