import {Locator, Page} from '@playwright/test';

export default class CheckPo {
  readonly wizardContainer: Locator;
  readonly buttonContainerBack: Locator;

  constructor(page: Page) {
    this.wizardContainer = page.locator('.wizard-container');
    this.buttonContainerBack = page.locator('.button-container .back');
  }
}
