import {Locator, Page} from '@playwright/test';

export default class SendPo {
  readonly appContent: Locator;
  readonly wizardContainer: Locator;
  readonly wizardContinue: Locator;
  readonly wizardBack: Locator;
  readonly wizardSelectbox: Locator;
  readonly wizardSendSuccessContainer: Locator;

  constructor(page: Page) {
    // wizard container
    this.appContent = page.locator('.app-content');
    this.wizardContainer = page.locator('.wizard-container');
    this.wizardContinue = page.locator('.button-container .continue');
    this.wizardBack = page.locator('.button-container .back');
    this.wizardSelectbox = page.locator('b-disclaimer .p-checkbox-box');
    this.wizardSendSuccessContainer = page.locator('.send-succes-container .sub-header');
  }
}
