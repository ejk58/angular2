import {expect, Locator, Page} from '@playwright/test';
import config from '../playwright.config';

interface CheckRegionOptions {
  // Elements to remove from the page before taking a screenshot of an element.
  elementsToRemove?: string[],
  // When set to `"disabled"`, stops CSS animations, CSS transitions and Web Animations.
  animations?: 'disabled' | 'allow',
  // Time in milliseconds between page actions and taking a screenshot of an element.
  delay?: number
}

interface BrowserSizeOptions {
  // Make the viewport of the browser larger with given value in pixels.
  extraScrollHeight?: number,
  // Array of elements to mask on the page.
  mask?: Array<Locator>,
  // An acceptable ratio of pixels that are different to the total amount of pixels, between `0` and `1`.
  maxDiffRatio?: boolean
}

export class General {
  page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async checkRegion(locator: Locator, imageName: string, options?: CheckRegionOptions) {
    const animations = options?.animations ? options.animations : 'disabled';
    const delay = options?.delay ? options.delay : 0;
    const elementsToRemove = (options?.elementsToRemove !== undefined) ? options?.elementsToRemove : '';

    await this.removeElementsFromPage(elementsToRemove);
    await expect(locator).toBeVisible({timeout: delay});
    expect(await locator.screenshot({
      animations: animations,
    })).toMatchSnapshot(imageName, {maxDiffPixelRatio: 0.02});
  }

  async checkWindow(imageName: string) {
    expect(await this.page.screenshot({
      animations: 'disabled'
    })).toMatchSnapshot(imageName);
  }

  async checkFullPage(imageName: string, extraOptions?: BrowserSizeOptions) {
    await this.setBrowserSize({extraScrollHeight: extraOptions?.extraScrollHeight});
    const defaultCustomMask = [this.page.locator('app-root header')];
    const customMask = !extraOptions?.mask ? defaultCustomMask : [...defaultCustomMask, ...extraOptions.mask];
    expect(await this.page.screenshot({
      fullPage: true,
      mask: customMask,
      animations: 'disabled'
    })).toMatchSnapshot(imageName, extraOptions?.maxDiffRatio && {maxDiffPixelRatio: 0.02});
  }

  async removeElementsFromPage(elements: string[] | string): Promise<void> {
    for (const item of elements) {
      await this.page.evaluate((sel) => {
        const selector = document.querySelectorAll(sel);
        for (let i = 0; i < selector.length; i++) {
          selector[i].parentNode.removeChild(selector[i]);
        }
      }, item);
    }
  }

  async waitForAngular() {
    await this.page.evaluate(async () => {
      // @ts-expect-error
      if (window.getAllAngularTestabilities) {
        // @ts-expect-error
        await Promise.all(window.getAllAngularTestabilities().map(whenStable));

        async function whenStable(testability) {
          return new Promise((res) => testability.whenStable(res));
        }
      }
    });
  }

  async elementScrollTo(selector: string, x: number, y: number) {
    const selectorScrollToPosition = {selector: selector, x: x, y: y};

    await this.page.evaluate((selectorScrollTo) => {
      document.querySelector(selectorScrollTo.selector).scrollTo(selectorScrollTo.x, selectorScrollTo.y);
    }, selectorScrollToPosition);
  }

  async elementScrollInToView(elementCssSelector: string) {
    await this.page.evaluate((selector) => {
      document.querySelectorAll(selector)[0].scrollIntoView();
    }, elementCssSelector);
  }

  async getElementSize(elementCssSelector: string) {
    return this.page.evaluate((selector) => {
      const innerScroll = document.querySelector(selector);
      return {width: innerScroll.scrollWidth, height: innerScroll.scrollHeight};
    }, elementCssSelector);
  }

  async setBrowserSize(extraOptions?: { extraScrollHeight?: number, originalHeight?: boolean }) {
    const currentViewport = this.page.viewportSize();
    const innerScrollHeight = await this.page.evaluate(() => {
      const innerScroll = document.querySelector('html');
      return innerScroll.scrollHeight;
    });

    if (!extraOptions?.extraScrollHeight) {
      await this.page.setViewportSize({
        width: currentViewport.width,
        height: extraOptions?.originalHeight ? config.use.viewport.height : innerScrollHeight
      });
    } else {
      await this.page.setViewportSize({
        width: currentViewport.width,
        height: innerScrollHeight + extraOptions.extraScrollHeight
      });
    }
  }

  async delay(time) {
    return new Promise(function (resolve) {
      setTimeout(resolve, time)
    });
  }

}
