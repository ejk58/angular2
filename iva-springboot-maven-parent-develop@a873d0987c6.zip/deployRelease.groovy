@Library("GENERIC") _
    pipelineDeployArtifactFromNexus_v1 {
	baseDirectory = ""
	deploymentId = "iva-common"
	integrationPipeline = ""
	packageChoices = "iva-common\n"
	applicationVersionChoices = ""
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
}
