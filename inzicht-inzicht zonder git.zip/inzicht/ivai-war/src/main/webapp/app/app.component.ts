import {Component, OnInit} from '@angular/core';
import {DEFAULT_INTERRUPTSOURCES, Idle} from '@ng-idle/core';
import {AuthenticationService} from '@inzicht/services/authentication.service';
import {environment} from '../environments/environment';
import {PrimeNGConfig, Translation} from 'primeng/api';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {

  public title = 'Inzicht';
  svg_path = environment.svg_path;
  public username: string;
  public readonly sessionInactivityTimeInSeconds = 36000;
  private readonly translation: Translation = {
    dayNames: ['Zondag', 'Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag'],
    dayNamesShort: ['Zo', 'Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za'],
    dayNamesMin: ['Z', 'M', 'D', 'W', 'D', 'V', 'Z'],
    monthNames: ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'],
    monthNamesShort: ['jan', 'feb', 'mar', 'apr', 'mei', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dec'],
    today: 'Vandaag',
    clear: 'Wis datum',
    weekHeader: 'Wk'
  };

  constructor(private readonly auth: AuthenticationService, private readonly config: PrimeNGConfig, idle: Idle) {
    idle.setIdle(this.sessionInactivityTimeInSeconds);
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    idle.onTimeout.subscribe({
      next: () => this.auth.logout(),
      error: error => console.error(`Error occurred during idle timeout, could not logout (${error})`)
    });

    this.auth.getUserName().subscribe({
      next: userName => {
        if (userName) {
          this.username = userName.text;
        }
      },
      error: () => console.error('Error occurred when getting the username during auth')
    });
  }

  ngOnInit(): void {
    this.auth.sendUserName(null);
    this.config.setTranslation(this.translation);
  }

}
