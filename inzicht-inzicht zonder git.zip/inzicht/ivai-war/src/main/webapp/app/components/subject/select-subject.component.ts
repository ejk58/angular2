import {Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewEncapsulation} from '@angular/core';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {PathKey} from '@inzicht/classes/path-key';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import * as storeActions from '@inzicht/store/actions';
import * as fromSelectors from '@inzicht/store/selectors';
import {Subject} from '@inzicht/classes/subject';
import {SearchResult} from '@inzicht/classes/search-result';
import {Domain} from '@inzicht/classes/domain';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {tap} from 'rxjs/operators';
import {Side} from '@inzicht/commons/side';
import {DomainSubjectType} from '@inzicht/classes/domain-subject-type';

@Component({
  selector: 'i-select-subject',
  templateUrl: './select-subject.component.html',
  styleUrls: ['./select-subject.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})

export class SelectSubjectComponent implements OnInit, OnDestroy, OnChanges {

  @Input() side: Side;
  @Input() domain: Domain;
  @Input() focus: boolean;

  @Output() selected: EventEmitter<boolean> = new EventEmitter<boolean>();

  public subjectSearchKey: string;
  public subjectTypes: DomainSubjectType[];
  public selectedSubjectType: DomainSubjectType;
  public selectedSubject: Subject;

  public loading$: Observable<boolean>;
  public searchResult$: Observable<SearchResult>;

  private shouldNavigateOnSingleResult: boolean = false;

  constructor(private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit(): void {
    this.subjectTypes = this.domain.subjectTypes;
    this.selectedSubjectType = this.subjectTypes[0];
    this.loading$ = this.store.select(fromSelectors.getSubjectLoadingState);

    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeSubject => this.selectedSubject = activeSubject,
        error: error => console.error(`Error while getting selected subject (${error})`)
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // react to changes of 'domain' because otherwise the searchResult$ pipe is not re-evaluated
    // since the value that's being observed (domain-reducer :: domain.searchResult) has not been changed.

    if (changes.domain) {
      this.subjectTypes = this.domain.subjectTypes;
      this.selectedSubjectType = this.subjectTypes[0];

      this.searchResult$ = this.store.select<SearchResult>(fromSelectors.getSearchResultsFromDomainState(this.side, this.domain.domainId))
        .pipe(
          this.unsubscriber.takeUntilForUnsubscribe,
          tap(searchResult => {
            if (this.shouldNavigateOnSingleResult && searchResult && searchResult.subjects && searchResult.subjects.length === 1) {
              this.shouldNavigateOnSingleResult = false;
              this.selectASubject(searchResult.subjects[0]);
            }
          }));
    }
  }

  isSelectedSubject(subject: Subject): boolean {
    if (this.selectedSubject) {
      const obj1 = JSON.stringify(subject);
      const obj2 = JSON.stringify(this.selectedSubject);

      return obj1 === obj2;
    }
    return false;
  }

  search(): void {
    this.subjectSearchKey = (this.subjectSearchKey == null) ? null : this.subjectSearchKey.replace(/^[0\.,\ \/]+|[\.,\ \/]+/g, '');

    // since this component initiates the search, it should be the only one that reacts to the search results
    this.shouldNavigateOnSingleResult = true;

    if (this.subjectSearchKey !== null && this.subjectSearchKey !== '') {
      this.store.dispatch(storeActions.subjectFind({
        side: this.side,
        domain: this.domain,
        searchType: this.selectedSubjectType,
        searchKey: this.subjectSearchKey
      }));
    }
  }

  selectASubject(subject: Subject): void {
    this.store.dispatch(storeActions.selectDomainWithSubject({
      side: this.side,
      domain: this.domain,
      subject: subject,
      pageId: subject.navigation ? subject.navigation.initPageId : undefined,
      params: this.constructParams(subject.model, this.domain.pathKeys)
    }));
  }

  private constructParams(subjectModel: Object, pathKeys: PathKey[]): any {
    const params: any = {};
    pathKeys.forEach(pathKey => {
      if (subjectModel[pathKey.name]) {
        params[pathKey.name] = subjectModel[pathKey.name];
      }
    });
    return params;
  }
}

