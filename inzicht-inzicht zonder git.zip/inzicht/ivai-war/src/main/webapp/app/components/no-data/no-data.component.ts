import {Component} from '@angular/core';

@Component({
  selector: 'i-no-data',
  templateUrl: './no-data.component.html',
  styleUrls: ['./no-data.component.scss']
})

export class NoDataComponent {
}
