import { Component } from '@angular/core';

@Component({
  selector: 'bd-stylesheet',
  templateUrl: './bd-stylesheet.component.html'
})
export class BdStylesheetComponent {

  selectedCategories: any;
}
