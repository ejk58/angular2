import {Component, EventEmitter, Input, Output} from '@angular/core';
import {sanitizeSelector} from '@inzicht/commons/inzicht-functions';

@Component({
  selector: 'i-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent {

  @Input() showTitle: string;
  @Input() dropdownLabel: string;
  @Input() dropdownName: string;
  @Input() validationMessage: string;
  @Input() options: Array<{}>;
  @Input() required: boolean;
  @Input() selectedOption: any;
  @Input() submitted: boolean;
  @Input() color: string;

  @Output() selected: EventEmitter<string> = new EventEmitter<string>();

  public open: boolean;
  public active: boolean;

  toggleOptions() {
    this.open = !this.open;
  }

  selectOption(selected: string) {
    this.selectedOption = selected;
    this.toggleOptions();
    this.selected.emit(selected);
  }

  public sanitizeSelector(selector: string): string {
    return sanitizeSelector(selector);
  }
}
