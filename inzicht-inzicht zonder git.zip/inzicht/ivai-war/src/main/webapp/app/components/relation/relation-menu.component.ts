import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import * as fromSelectors from '@inzicht/store/selectors';
import * as storeActions from '@inzicht/store/actions';
import {Subject} from '@inzicht/classes/subject';
import {PathKey} from '@inzicht/classes/path-key';

@Component({
  selector: 'i-relation-menu',
  templateUrl: './relation-menu.component.html',
  styleUrls: ['./relation-menu.component.scss'],
  providers: [Unsubscriber]
})
export class RelationMenuComponent implements OnInit, OnDestroy {

  @Input() side: any;
  @Output() selected: EventEmitter<boolean> = new EventEmitter<boolean>();

  public relations$: Observable<any>;
  public error$: Observable<string>;
  public loading$: Observable<boolean>;

  public filterValue: string;
  public params: any;
  public selectedSubject: Subject;

  constructor(private readonly store: Store,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly unsubscriber: Unsubscriber) {}

  ngOnInit(): void {
    this.filterValue = '';

    const indicatedRelationsSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRelations');
    this.relations$ = this.store.select(fromSelectors[indicatedRelationsSelector]);

    const indicatedRelationLoadingSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRelationLoading');
    this.loading$ = this.store.select(fromSelectors[indicatedRelationLoadingSelector]);

    const indicatedRelationErrorSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRelationError');
    this.error$ = this.store.select(fromSelectors[indicatedRelationErrorSelector]);

    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeSubject => this.selectedSubject = activeSubject,
        error: error => console.error(`Error while getting selected subject (${error})`)
      });

    this.store.select(fromSelectors.getRouterSides)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: routerSides => {
          if (this.side && routerSides && routerSides[this.side]) {
            this.params = routerSides[this.side];
          }
        },
        error: error => console.error(`Error while handling router sides (${error})`)
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public switchToRelation(relation: Subject): void {
    const domain = this.store.selectSync(fromSelectors.getActiveDomain(this.side));

    this.store.dispatch(storeActions.selectDomainWithSubject({
      side: this.side,
      domain: domain,
      subject: relation,
      params: this.constructParams(relation.model, domain.pathKeys)
    }));
  }

  private constructParams(subjectModel: Object, pathKeys: PathKey[]): any {
    const params: any = {};
    pathKeys.filter(pathKey => pathKey.mandatory).forEach(pathKey => params[pathKey.name] = subjectModel[pathKey.name]);
    return params;
  }
}
