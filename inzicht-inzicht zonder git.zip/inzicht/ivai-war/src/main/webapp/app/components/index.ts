import {LoginComponent} from '@inzicht/components/login/login.component';
import {SubjectComponent} from '@inzicht/components/subject/subject.component';
import {SelectSubjectComponent} from '@inzicht/components/subject/select-subject.component';
import {HeaderComponent} from '@inzicht/components/header/header.component';
import {PageMenuComponent} from '@inzicht/components/page-menu/page-menu.component';
import {PageComponent} from '@inzicht/components/page/page.component';
import {WidgetComponent} from '@inzicht/components/widget/widget.component';
import {MainComponent} from '@inzicht/components/main/main.component';
import {FooterComponent} from '@inzicht/components/footer/footer.component';
import {RelationComponent} from '@inzicht/components/relation/relation.component';
import {RelationMenuComponent} from '@inzicht/components/relation/relation-menu.component';
import {FeedbackComponent} from '@inzicht/components/feedback/feedback.component';
import {AcceptanceReviewComponent} from '@inzicht/components/acceptance-review/acceptance-review.component';
import {ReleaseNotesComponent} from '@inzicht/components/release-notes/release-notes.component';
import {ReleaseNoteComponent} from '@inzicht/components/release-notes/release-note.component';
import {HelpComponent} from '@inzicht/components/help/help.component';
import {DropdownComponent} from '@inzicht/components/dropdown/dropdown.component';
import {GraphZoomButtonsComponent} from '@inzicht/components/graph-zoom-buttons/graph-zoom-buttons.component';
import {FiltersComponent} from '@inzicht/components/filters/filters.component';
import {SingleValuePageFilterComponent} from '@inzicht/components/filters/single-value-page-filter/single-value-page-filter.component';
import {MultiValuePageFilterComponent} from '@inzicht/components/filters/multi-value-page-filter/multi-value-page-filter.component';
import {DatePageFilterComponent} from '@inzicht/components/filters/date-page-filter/date-page-filter.component';
import {ValueComponent} from '@inzicht/components/value/value.component';
import {TextComponent} from '@inzicht/components/text/text.component';
import {TabsComponent} from '@inzicht/components/tabs/tabs.component';
import {StatefulTabsComponent} from '@inzicht/components/tabs/stateful-tabs.component';
import {TextElementComponent} from '@inzicht/components/text/text-element.component';
import {SparklineComponent} from '@inzicht/components/sparkline/sparkline.component';
import {DomainComponent} from '@inzicht/components/domain/domain.component';
import {DeepLinkComponent} from '@inzicht/components/deep-link/deep-link.component';
import {NoDataComponent} from '@inzicht/components/no-data/no-data.component';
import {WidgetLegendComponent} from '@inzicht/components/widget/widget-legend.component';
import {LegendButtonComponent} from '@inzicht/components/legend-button/legend-button.component';
import {WidgetErrorComponent} from '@inzicht/components/widget/widget-error.component';

// Tijdelijk voor stylesheet
import {BdStylesheetComponent} from '@inzicht/components/bd-stylesheet/bd-stylesheet.component';

export const list = [
  LoginComponent,
  SubjectComponent,
  SelectSubjectComponent,
  HeaderComponent,
  PageMenuComponent,
  PageComponent,
  MainComponent,
  DomainComponent,
  DeepLinkComponent,
  RelationComponent,
  RelationMenuComponent,
  FooterComponent,
  FeedbackComponent,
  AcceptanceReviewComponent,
  ReleaseNotesComponent,
  ReleaseNoteComponent,
  HelpComponent,
  WidgetComponent,
  DropdownComponent,
  GraphZoomButtonsComponent,
  FiltersComponent,
  SingleValuePageFilterComponent,
  MultiValuePageFilterComponent,
  DatePageFilterComponent,
  BdStylesheetComponent,
  ValueComponent,
  TextComponent,
  TabsComponent,
  StatefulTabsComponent,
  TextElementComponent,
  SparklineComponent,
  NoDataComponent,
  WidgetLegendComponent,
  LegendButtonComponent,
  WidgetErrorComponent,
];
