import {Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild} from '@angular/core';
import {NgForm} from '@angular/forms';
import {Store} from '@ngrx/store';
import {BehaviorSubject, EMPTY, Observable} from 'rxjs';
import {switchMap, tap} from 'rxjs/operators';
import {FileUpload} from 'primeng/fileupload';

import {TrackingService} from '@inzicht/services/tracking.service';
import {FeedbackService} from '@inzicht/services/feedback.service';
import * as storeActions from '@inzicht/store/actions';
import * as fromSelectors from '@inzicht/store/selectors';
import {RouterStateUrl} from '@inzicht/store/reducers';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {sanitizeSelector} from '@inzicht/commons/inzicht-functions';

@Component({
  selector: 'i-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss'],
  providers: [FeedbackService, Unsubscriber]
})
export class FeedbackComponent implements OnChanges, OnInit, OnDestroy {

  @ViewChild('feedbackForm', {read: NgForm, static: false}) formCtrl: NgForm;
  @ViewChild('attachmentUpload', {read: FileUpload, static: false}) attachmentUpload: FileUpload;

  @Input() public engaged: boolean = false;
  @Input() public widgetTitle: string;
  @Input() public widgetId: string;
  @Input() public side: string;

  private readonly engaged$ = new BehaviorSubject(this.engaged);

  public submitting: boolean = false;
  public submittedSuccesfully: boolean = false;
  public serverErrorOccurred: boolean = false;
  public tooManyAttachments: boolean = false;
  public serverErrorStatus: number;

  public feedback: {
    message?: string;
    scope?: string;
    topic?: string;
  } = {};

  public feedbackScopeList: string[];
  public readonly feedbackTopicList: string[] = [
    'De getoonde gegevens zijn onjuist, onvolledig of niet actueel.',
    'De snelheid waarmee de applicatie reageert of foutmeldingen die in beeld verschijnen.',
    'Onderdelen van de applicatie of velden die verwarring oproepen.',
    'Gebruikersgemak.',
    'Overige wensen.'
  ];

  public jiraAttachmentsAvailable$: Observable<boolean>;
  public jiraAttachmentsMaxFileSize$: Observable<number>;
  public jiraAttachmentsFileLimit$: Observable<number>;

  private scopeOptionSpecificPart: string;
  private readonly scopeOptionPageLeft: string = `Pagina links`;
  private readonly scopeOptionPageRight: string = `Pagina rechts`;
  private readonly scopeOptionWholePage: string = `Deze pagina (als geheel)`;
  private readonly scopeOptionAllPages: string = `Alle pagina's`;

  private selectedScope: string;

  private activeScreens: any;
  private activeSide: any;

  private activeLeftDomainId: string;
  private activeLeftPageId: string;
  private activeRightDomainId: string;
  private activeRightPageId: string;

  private selectedDomainId: string;
  private selectedPageId: string;


  constructor(private readonly feedbackService: FeedbackService,
              private readonly trackingService: TrackingService,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) {
  }

  ngOnInit() {
    // Listen to changes in the route, and re-initialize options
    const routerStateSource$: Observable<RouterStateUrl> = this.store.select(fromSelectors.getRouterState);
    const routerState$ = this.engaged$.pipe(
      tap(engaged => {
        if (this.submittedSuccesfully && !engaged) {
          this.reset();
        }
      }),
      switchMap(engaged => engaged ? routerStateSource$ : EMPTY)
    );

    routerState$
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: routerState => {
          this.activeScreens = routerState.routerSidesParams;

          // Don't display feedbackScope options if there is no selected Domain
          if (this.displayScopeList()) {
            this.activeLeftPageId = this.activeScreens.left.pageId;
            this.activeLeftDomainId = this.activeScreens.left.domainId;
          }

          if (this.activeScreens.right) {
            this.activeRightPageId = this.activeScreens.right.pageId;
            this.activeRightDomainId = this.activeScreens.right.domainId;
            this.feedbackScopeList = [this.scopeOptionPageLeft, this.scopeOptionPageRight, this.scopeOptionAllPages];
          } else {
            this.activeRightPageId = undefined;
            this.activeRightDomainId = undefined;
            this.feedbackScopeList = [this.scopeOptionWholePage, this.scopeOptionAllPages];
          }

          // Delete selected scope from feedback when no longer present in scopeList
          if (this.feedbackScopeList.indexOf(this.feedback.scope) < 0) {
            delete this.feedback.scope;
          }

          if (this.widgetTitle) {
            this.scopeOptionSpecificPart = `Onderdeel "${this.widgetTitle}"`;
            this.feedbackScopeList.unshift(this.scopeOptionSpecificPart);
            this.feedback.scope = this.scopeOptionSpecificPart;
            this.processSelectedScope(this.feedback.scope);
          }
        },
        error: error => console.error(`Error occurred when processing router state (${error})`)
      });

    this.jiraAttachmentsAvailable$ = this.store.select(fromSelectors.getSystemProperty('jiraAttachmentsAvailable'));
    this.jiraAttachmentsMaxFileSize$ = this.store.select(fromSelectors.getSystemProperty('jiraAttachmentsMaxFileSize'));
    this.jiraAttachmentsFileLimit$ = this.store.select(fromSelectors.getSystemProperty('jiraAttachmentsFileLimit'));
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (typeof changes.engaged !== 'undefined') {
      this.engaged$.next(changes.engaged.currentValue);
    }
  }

  public displayScopeList(): boolean {
    if (this.activeScreens) {
      const keys: string[] = Object.keys(this.activeScreens);
      return keys.length > 0 && keys.every(k => typeof this.activeScreens[k] !== 'undefined');
    } else {
      return false;
    }
  }

  public processSelectedScope(selectedScope: string): void {
    if (this.side && this.side === 'right') {
      this.activeSide = this.activeScreens.right;
      this.selectedDomainId = this.activeRightDomainId;
      this.selectedPageId = this.activeRightPageId;
      this.selectedScope = this.activeRightPageId;
    } else {
      this.activeSide = this.activeScreens.left;
      this.selectedDomainId = this.activeLeftDomainId;
      this.selectedPageId = this.activeLeftPageId;
      this.selectedScope = this.activeLeftPageId;
    }

    if (selectedScope === this.scopeOptionAllPages) {
      this.selectedScope = this.scopeOptionAllPages;
    }

    if (selectedScope === this.scopeOptionPageRight) {
      this.selectedDomainId = this.activeRightDomainId;
      this.selectedScope = this.activeRightPageId;
    }
  }

  public onSelect(event: DataTransfer): void {
    const jiraAttachmentsFileLimit = this.store.selectSync(fromSelectors.getSystemProperty('jiraAttachmentsFileLimit'));
    const newAttachmentCount = event.files ? event.files.length : 0;
    this.tooManyAttachments = this.attachmentUpload && (this.attachmentUpload.files.length + newAttachmentCount) > jiraAttachmentsFileLimit;
  }

  public onRemove(event: any): void {
    const jiraAttachmentsFileLimit: number = this.store.selectSync(fromSelectors.getSystemProperty('jiraAttachmentsFileLimit'));
    this.tooManyAttachments = this.attachmentUpload && this.attachmentUpload.files.length > (jiraAttachmentsFileLimit + 1);
  }

  public onSubmit(): void {
    const jiraAttachmentsFileLimit = this.store.selectSync(fromSelectors.getSystemProperty('jiraAttachmentsFileLimit'));
    this.tooManyAttachments = this.attachmentUpload && this.attachmentUpload.files.length > jiraAttachmentsFileLimit;

    if (this.formCtrl.valid && !this.submitting && !this.tooManyAttachments) {
      this.submitting = true;
      this.trackingService.trackEvent('klik', `Klik feedback versturen:${this.activeSide}`, null, null);

      const selectedSide = this.getSide();
      const feedback = {
        remark: this.feedback.message,
        url: window.location.href,
        topic: this.feedback.topic,
        side: selectedSide,
        domainId: this.selectedDomainId ? this.selectedDomainId : 'Geen klantbeeld gekozen',
        scope: this.selectedScope ? this.selectedScope : 'Geen pagina gekozen', // but scope = page
        widget: this.widgetTitle ? `${this.widgetTitle} (${this.widgetId})` : null,
        subjectNr: this.activeSide && this.activeSide.subjectNr ? this.activeSide.subjectNr : null
      };

      const formData = new FormData();
      formData.append('feedback', JSON.stringify(feedback));

      if (this.attachmentUpload) {
        this.attachmentUpload.files.forEach(attachment => formData.append('attachment', attachment, attachment.name));
      }

      this.feedbackService.sendFeedback(formData)
        .pipe(this.unsubscriber.takeUntilForUnsubscribe)
        .subscribe(
          res => {
            this.submittedSuccesfully = true;
            this.serverErrorOccurred = false;
            this.submitting = false;
          },
          err => {
            this.submittedSuccesfully = false;
            this.serverErrorOccurred = true;
            this.serverErrorStatus = err.status;
            this.submitting = false;
          });
    }
  }

  public cancelFeedbackForm(): void {
    this.store.dispatch(storeActions.sidebarClose());
    this.reset();
    this.formCtrl.resetForm();
  }

  public sanitizeSelector(selector: string): string {
    return sanitizeSelector(selector);
  }

  private reset(): void {
    this.submittedSuccesfully = false;
    this.serverErrorOccurred = false;
    this.serverErrorStatus = undefined;
    this.tooManyAttachments = false;
    this.submitting = false;
    this.feedback = {};

    if (this.attachmentUpload) {
      this.attachmentUpload.files = [];
    }
  }

  private getSide(): string {
    const selectedSide = this.side ? this.side : this.activeSide;

    if (selectedSide === 'left') {
      return 'Links';
    } else if (selectedSide === 'right') {
      return 'Rechts';
    }

    return null;
  }
}
