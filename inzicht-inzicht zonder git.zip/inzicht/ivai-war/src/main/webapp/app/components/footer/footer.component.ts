import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';

import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';

import * as fromSelectors from '@inzicht/store/selectors';

@Component({
  selector: 'i-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  public version$: Observable<string>;
  public currentRoute: string;

  constructor(private readonly route: ActivatedRoute,
              private readonly store: Store) {}

  ngOnInit() {
    this.version$ = this.store.select(fromSelectors.getSystemVersionState);

    this.route.params.subscribe({
      next: params => {
        this.currentRoute = this.route.snapshot.url[0].path;
      },
      error: error => console.error(`Error processing router changes (${error})`)
    });
  }
}
