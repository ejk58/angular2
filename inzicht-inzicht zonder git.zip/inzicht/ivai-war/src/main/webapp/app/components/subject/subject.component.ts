import {Component, Input, ChangeDetectionStrategy} from '@angular/core';
import {Subject} from '@inzicht/classes/subject';

@Component({
  selector: 'i-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class SubjectComponent {

  @Input() subject: Subject;
  @Input() selected?: boolean;
  @Input() inverted?: boolean;

}
