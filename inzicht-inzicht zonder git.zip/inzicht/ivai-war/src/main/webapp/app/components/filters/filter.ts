import {FilterOption} from '@inzicht/components/filters/filter-option';

export class Filter {
  key: string;
  label: string;
  options: FilterOption[];
  placeholder: string;
  showClear: boolean;
  type: 'MultiValuePageFilter' | 'SingleValuePageFilter' | 'DatePageFilter';
  forcedSelection: boolean;
  selection?: any;
}
