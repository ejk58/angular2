import {Component, Input, ChangeDetectionStrategy} from '@angular/core';
import {Subject} from '@inzicht/classes/subject';

@Component({
  selector: 'i-relation',
  templateUrl: './relation.component.html',
  styleUrls: ['./relation.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class RelationComponent {

  @Input() relation: Subject;
  @Input() selected?: boolean;
  @Input() inverted?: boolean;

}
