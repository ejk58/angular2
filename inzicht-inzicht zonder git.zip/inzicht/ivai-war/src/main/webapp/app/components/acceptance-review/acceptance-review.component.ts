import {Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild} from '@angular/core';
import {NgForm} from '@angular/forms';
import {Store} from '@ngrx/store';
import {BehaviorSubject, EMPTY, Observable} from 'rxjs';
import {switchMap, tap} from 'rxjs/operators';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {AcceptanceReviewService} from '@inzicht/services/acceptance-review.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import * as storeActions from '@inzicht/store/actions';
import {RouterStateUrl} from '@inzicht/store/reducers';
import * as fromSelectors from '@inzicht/store/selectors';

@Component({
  selector: 'i-acceptance-review',
  templateUrl: './acceptance-review.component.html',
  styleUrls: ['./acceptance-review.component.scss'],
  providers: [AcceptanceReviewService, Unsubscriber]
})
export class AcceptanceReviewComponent implements OnChanges, OnInit, OnDestroy {

  @ViewChild('acceptanceReviewForm', { static: false }) formCtrl: NgForm;

  @Input() public engaged: boolean = false;
  @Input() public widgetTitle: string;
  @Input() public widgetId: string;
  @Input() public side: string;

  private readonly engaged$ = new BehaviorSubject(this.engaged);

  public submittedSuccesfully: boolean = false;
  public serverErrorOccurred: boolean = false;
  public serverErrorStatus: number;

  public acceptanceReview: {
    enoughInformation?: string;
    accordingToSource?: string;
    informationUpToDate?: string;
    goodUserExperience?: string;
    noFurtherRemarks?: string;
  } = {};

  private activeScreens: any;

  constructor(private readonly acceptanceReviewService: AcceptanceReviewService,
              private readonly trackingService: TrackingService,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) {}

  ngOnInit() {
    // Listen to changes in the route, and re-initialize options
    const routerStateSource$: Observable<RouterStateUrl> = this.store.select(fromSelectors.getRouterState);
    const routerState$ = this.engaged$.pipe(
      tap(engaged => {
        if (this.submittedSuccesfully && !engaged) {
          this.reset();
        }
      }),
      switchMap(engaged => engaged ? routerStateSource$ : EMPTY)
    );

    routerState$
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: routerState => {
          this.activeScreens = routerState.routerSidesParams;
        },
        error: error => console.error(`Error occurred when processing router state, could not extract sides (${error})`)
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (typeof changes.engaged !== 'undefined') {
      this.engaged$.next(changes.engaged.currentValue);
    }
  }

  public onSubmit(): void {
    const activeScreen = this.activeScreens[this.side];

    this.trackingService.trackEvent('klik', `Klik gat versturen:${activeScreen}`, null, null);

    if (this.formCtrl.valid) {
      const acceptanceReview = {
        url: window.location.href,
        widget: this.widgetTitle ? `${this.widgetTitle} (${this.widgetId})` : null,
        side: this.side,
        subjectNr: activeScreen && activeScreen.subjectNr ? activeScreen.subjectNr : null,

        enoughInformation: Number(this.acceptanceReview.enoughInformation),
        accordingToSource: Number(this.acceptanceReview.accordingToSource),
        informationUpToDate: Number(this.acceptanceReview.informationUpToDate),
        goodUserExperience: Number(this.acceptanceReview.goodUserExperience),
        noFurtherRemarks: Number(this.acceptanceReview.noFurtherRemarks)
      };

      this.acceptanceReviewService.sendAcceptanceReview(acceptanceReview)
        .pipe(this.unsubscriber.takeUntilForUnsubscribe)
        .subscribe(
          res => {
            this.submittedSuccesfully = true;
            this.serverErrorOccurred = false;
          },
          err => {
            this.submittedSuccesfully = false;
            this.serverErrorOccurred = true;
            this.serverErrorStatus = err.status;
          });
    }
  }

  public cancelAcceptanceReviewForm(): void {
    this.store.dispatch(storeActions.sidebarClose());
    this.reset();
    this.formCtrl.resetForm();
  }

  private reset(): void {
    this.submittedSuccesfully = false;
    this.serverErrorOccurred = false;
    this.serverErrorStatus = undefined;
    this.acceptanceReview = {};
  }
}
