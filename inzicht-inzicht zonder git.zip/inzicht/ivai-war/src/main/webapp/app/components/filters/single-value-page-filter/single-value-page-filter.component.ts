import {Component, Input, Output, EventEmitter, OnChanges, SimpleChanges} from '@angular/core';

import {Filter} from '@inzicht/components/filters/filter';

@Component({
  selector: 'i-single-value-page-filter',
  templateUrl: './single-value-page-filter.component.html',
  styleUrls: ['./single-value-page-filter.component.scss']
})
export class SingleValuePageFilterComponent implements OnChanges {

  @Input() filter: Filter;
  @Input() selection: any;

  @Output() selected: EventEmitter<any> = new EventEmitter<any>();

  public internalSelection: any;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.selection) {
      this.internalSelection = changes.selection.currentValue;
    }
  }

  public onChange(): void {
    this.selected.emit(this.internalSelection);
  }

}
