import {Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewEncapsulation} from '@angular/core';
import {ActivatedRoute, Params, Router} from '@angular/router';

import {Store} from '@ngrx/store';
import {forkJoin, Observable} from 'rxjs';
import {concatMap, filter, first} from 'rxjs/operators';

import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {WidgetService} from '@inzicht/services/widget.service';
import * as fromSelectors from '@inzicht/store/selectors';
import {dateToYyyyMmDd, yyyyMmDdToDate} from '@inzicht/commons/inzicht-functions';
import {Filter} from '@inzicht/components/filters/filter';
import {Message} from '@inzicht/classes/message';
import {FilterOption} from '@inzicht/components/filters/filter-option';

@Component({
  selector: 'i-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})
export class FiltersComponent implements OnDestroy, OnInit {

  @Input() widgetId: string;
  @Input() side: string;
  @Input() isFixed: boolean;

  @Output() globalFilterLoaded: EventEmitter<number> = new EventEmitter<number>();

  public filters: Filter[];
  public pageSize: number;
  public filtersLoading: boolean;
  public filtersError: Message;
  public filtersOpen: boolean;
  private readonly filtersErrorMessageText = 'Er is een fout opgetreden bij het laden van de pagina-filters';

  private filterWidgetInfos: any[] = [];
  private pageId: string;
  private domainId: string;

  constructor(private readonly route: ActivatedRoute,
              private readonly router: Router,
              private readonly widgetService: WidgetService,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly unsubscriber: Unsubscriber,
              private readonly store: Store) {
  }

  ngOnInit() {
    this.initSplitViewSizesListener();
    this.initFilters();
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public onFilterChange(filter: Filter, newValue: any): void {
    this.trackingService.trackEvent('filter', `Filter globaal:${this.side}/gewijzigd:${filter.label}`, null, null);
    filter.selection = newValue;
    this.setFilterStateInUrl(false);
  }

  private initSplitViewSizesListener(): void {
    this.splitViewState.listenSizes().pipe(
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe({
      next: sizes => {
        if (sizes != null) {
          this.pageSize = sizes[this.side];
        } else {
          this.pageSize = 10000;
        }
      },
      error: error => {
        const errorCode = (error && error.statusCode) ? error.statusCode : Message.genericErrorCode;
        this.filtersError = new Message(errorCode, 'error', this.filtersErrorMessageText);
        console.error(`Error occurred while processing split view sizes (${error})`);
      }
    });
  }

  private initFilters(): void {
    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    this.filters = [];
    this.filtersLoading = true;

    this.widgetService.getWidgetDataByHttp(this.widgetId, this.side, null).pipe(
      concatMap(filterContainer => {
        this.filterWidgetInfos = filterContainer.options.widgets;
        const filterWidgets$ = this.filterWidgetInfos.map(this.getFilterWidget, this);
        const routerState$ = this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(first());
        return forkJoin(
          routerState$,
          ...filterWidgets$
        );
      }),
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe({
      next: ([routerState, ...filterWidgets]) => {
        this.domainId = routerState.domainId;
        this.pageId = routerState.pageId;
        this.filters = filterWidgets.map(filterWidget => this.createFilter(filterWidget, routerState));
        // In case of a filter with a forced selection: add selection to URL
        if (this.filters.some(filter => filter.forcedSelection)) {
          this.setFilterStateInUrl(true);
        }
        this.startUpdatingFiltersFromRouterState();
      },
      error: error => {
        const errorCode = error.status ? error.status : Message.genericErrorCode;
        this.filtersError = new Message(errorCode, 'error', this.filtersErrorMessageText);
        console.error(`Error occurred during initialization of filters (${error})`);
        this.reportGlobalFilterIsLoaded(errorCode);
      }
    });
  }

  private startUpdatingFiltersFromRouterState(): void {
    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(
      filter((routerState: any) => routerState && routerState.domainId === this.domainId && routerState.pageId === this.pageId),
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe({
      next: routerState => {
        this.filters.forEach(filter => this.setFilterSelectionBasedOnRouterState(filter, routerState, true));
        this.setFilterOptions();
      },
      error: error => console.error(`Error occurred while processing router state (${error})`)
    });
  }

  private setFilterOptions(): void {
    const newFilter = {};
    this.filters.forEach(filter => {
      if (filter.selection != undefined) {
        newFilter[filter.key] = filter.selection;
      }
    });
    forkJoin(
      this.filterWidgetInfos.map(filterWidgetInfo => this.widgetService.getWidgetDataByHttp(filterWidgetInfo.name, this.side, newFilter))
    ).pipe(
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe({
      next: filterWidgets => {
        filterWidgets.forEach((filterWidget, i) => {
          this.filters[i].options = this.createOptions(filterWidget.data, filterWidget.options.unfilteredOption);
          this.addUnknownSelectionToFilterOptions(this.filters[i]);
        });
        this.reportGlobalFilterIsLoaded(0);
      },
      error: error => {
        const errorCode = error.status ? error.status : Message.genericErrorCode;
        this.filtersError = new Message(errorCode, 'error', this.filtersErrorMessageText);
        console.error(`Error occurred when retrieving filter widget info (${error})`);
        this.reportGlobalFilterIsLoaded(errorCode);
      }
    });
  }

  private addUnknownSelectionToFilterOptions(filter: Filter): void {
    if (filter.selection != undefined) {
      if (Array.isArray(filter.selection)) {
        filter.selection.forEach(selection => {
          if (!this.isSelectionAlreadyInFilterOptions(filter.options, selection)) {
            filter.options.push({label: selection, value: selection});
          }
        });
      } else {
        if (!this.isSelectionAlreadyInFilterOptions(filter.options, filter.selection)) {
          filter.options.push({label: filter.selection, value: filter.selection});
        }
      }
    }
  }

  private reportGlobalFilterIsLoaded(errorCode: number): void {
    this.filtersLoading = false;
    this.globalFilterLoaded.emit(errorCode);
  }

  private setFilterSelectionBasedOnRouterState(filter: Filter, routerState: Params, routerStateCanClearFilters: boolean): void {
    const routerFilterValue = routerState[filter.key];
    if (routerFilterValue != null || routerStateCanClearFilters) {
      if (filter.type === 'SingleValuePageFilter') {
        filter.selection = this.toSingleValueFilterValue(routerFilterValue);
      } else if (filter.type === 'MultiValuePageFilter') {
        filter.selection = this.toMultiValueFilterValue(routerFilterValue);
      } else {
        filter.selection = this.toDateFilterValue(routerFilterValue);
      }
    }
    // In case of a forcedSelection: initialize selection when undefined
    if (this.isFilterWithForcedSelectionAndUndefinedSelection(filter)) {
      filter.selection = filter.options[0].value;
    }
  }

  private setFilterStateInUrl(replaceUrl: boolean): void {
    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    const routerState = this.store.selectSync(fromSelectors[indicatedRouterStateSelector]);
    const params = this.makeNavigationParams(routerState);
    this.router.navigate([params], {relativeTo: this.route, replaceUrl: replaceUrl});
  }

  private makeNavigationParams(routerState: Params): { [x: string]: any } {
    const params: { [x: string]: any } = {...routerState};
    delete params.domainId;
    delete params.pageId;
    this.filters.forEach(filter => {
      if (filter.selection != null && !(Array.isArray(filter.selection) && filter.selection.length === 0)) {
        if (filter.selection instanceof Date) {
          params[filter.key] = dateToYyyyMmDd(filter.selection);
        } else {
          params[filter.key] = filter.selection;
        }
      } else if (this.isFilterWithForcedSelectionAndUndefinedSelection(filter)) {
        params[filter.key] = filter.options[0].value;
      } else {
        delete params[filter.key];
      }
    });
    return params;
  }

  private createFilter(filterWidget: any, routerState: Params): Filter {
    const filter = this.createFilterBasedOnConfiguration(filterWidget);
    this.setFilterSelectionBasedOnRouterState(filter, routerState, false);
    this.addUnknownSelectionToFilterOptions(filter);
    return filter;
  }

  private createFilterBasedOnConfiguration(filterWidget: any): Filter {
    const forcedSelection = filterWidget.options.forcedSelection ? JSON.parse(filterWidget.options.forcedSelection) : false;
    const filterOptions = this.createOptions(filterWidget.data, filterWidget.options.unfilteredOption);

    const filter: Filter = {
      key: filterWidget.options.filterKey ? filterWidget.options.filterKey : 'Configuratiefout',
      label: filterWidget.options.label,
      options: filterOptions,
      placeholder: filterWidget.options.label,
      showClear: true,
      type: filterWidget.type,
      forcedSelection: forcedSelection
    };

    if (forcedSelection) {
      filter.placeholder = null;
      filter.showClear = false;

      if (filterOptions.length > 0) {
        filter.selection = filterOptions[0].value;
      }
    }

    return filter;
  }

  private createOptions(data: any[], unfilteredOption?: string): FilterOption[] {
    // Remove empty values from array
    const filteredData = data.filter(option => option.Filter.value !== null && option.Filter.value !== undefined);

    const options: FilterOption[] = filteredData.map(option => {
      let label: string = option.Filter.label;
      if (option.Filter.count) {
        label += ` (${option.Filter.count})`;
      }
      return {
        label: label,
        value: option.Filter.value
      };
    });

    if (unfilteredOption) {
      options.unshift({label: unfilteredOption, value: null});
    }

    return options;
  }

  private isSelectionAlreadyInFilterOptions(options: FilterOption[], selection: string): boolean {
    return options.some(option => option.value === selection);
  }

  private isFilterWithForcedSelectionAndUndefinedSelection(filter: Filter): boolean {
    return filter.forcedSelection && filter.options.length > 0 && filter.selection === undefined;
  }

  private toSingleValueFilterValue(value: string | number): string | number | undefined {
    return isNaN(value as any) ? value : Number(value);
  }

  private toMultiValueFilterValue(value: (string | number)[] | string | number): (string | number)[] | undefined {
    if (typeof value === 'undefined' || Array.isArray(value)) {
      return value;
    } else {
      return `${value}`.split(',').map(this.toSingleValueFilterValue);
    }
  }

  private toDateFilterValue(value: string | number): Date | undefined {
    if (value == null) {
      return null;
    } else if (isNaN(value as any)) {
      return yyyyMmDdToDate(`${value}`);
    } else {
      return new Date(value);
    }
  }

  private getFilterWidget(filterWidgetInfo: any): Observable<any> {
    return this.widgetService.getWidgetDataByHttp(filterWidgetInfo.name, this.side, null);
  }
}
