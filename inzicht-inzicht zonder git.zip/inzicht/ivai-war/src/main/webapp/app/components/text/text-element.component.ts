import {Component, Input, OnInit, Output, EventEmitter, ChangeDetectionStrategy} from '@angular/core';
import {BlockType, Block} from './block';

@Component({
  selector: 'i-text-element',
  templateUrl: './text-element.component.html',
  styleUrls: ['./text-element.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TextElementComponent implements OnInit {

  @Input() block: Block;
  @Output() action: EventEmitter<[Block, MouseEvent]> = new EventEmitter<[Block, MouseEvent]>();

  public components: Block[];
  public text: string;
  public style: string;
  public readMore: boolean;

  ngOnInit(): void {
    this.components = [];
    this.text = null;
    this.style = this.block.style + (this.hasClickEvent() ? ' click-event' : '');
    this.readMore = false;

    if (Array.isArray(this.block.text)) {
      this.components = this.block.text;
    } else if (this.block.text != null && typeof this.block.text === 'object') {
      this.components = [this.block.text];
    } else {
      this.text = this.block.text != null ? String(this.block.text) : null;
    }
  }

  public hasClickEvent(): boolean {
    return this.block.type === BlockType.linkType || this.block.type === BlockType.buttonType;
  }

  public handleMouseDown(event: MouseEvent): void {
    // This is to prevent the 'sticky scroll' cursor from engaging on Windows when clicking the middle mouse button
    event.preventDefault();
  }

  public handleMouseUp(event: MouseEvent): void {
    this.action.emit([this.block, event]);
  }

  public handleAction(action: [Block, MouseEvent]): void {
    this.action.emit(action);
  }

  public toggleReadMoreLess(): void {
    this.readMore = !this.readMore;
  }
}
