import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Store} from '@ngrx/store';

import {SplitWidth} from '@inzicht/classes/split-width';
import {AuthenticationService} from '@inzicht/services/authentication.service';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import * as storeActions from '@inzicht/store/actions';
import * as fromSelectors from '@inzicht/store/selectors';
import {HelpState} from '@inzicht/services/help.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {Subject} from '@inzicht/classes/subject';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {Domain} from '@inzicht/classes/domain';

@Component({
  selector: 'i-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [Unsubscriber]
})
export class HeaderComponent implements OnInit, OnDestroy {

  @Input() side: any;
  @Output() secondScreenActive: EventEmitter<boolean> = new EventEmitter<boolean>();

  public readonly accountMenuOptions = [
    { label: 'Feedback', icon: 'bd_chat_bubble_outline', command: this.openFeedbackInSidebar.bind(this), selected: false },
    { label: 'Uitloggen', icon: 'bd_lock_open', command: this.logout.bind(this), selected: false }
  ];

  public view: any;
  public currentRoute: string;
  public username: any;
  public loading: boolean;
  public selectedSubject: Subject;
  public activeDomain: Domain;
  private headerState: string;
  public splitWidth: SplitWidth = SplitWidth.default;

  constructor(private readonly route: ActivatedRoute,
              private readonly auth: AuthenticationService,
              public readonly splitViewState: SplitViewState,
              private readonly helpState: HelpState,
              private readonly trackingService: TrackingService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    this.store.select(fromSelectors.getActiveDomain(this.side))
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeDomain => this.activeDomain = activeDomain,
        error: error => console.error(`Error occurred while getting active domain from the store (${error})`)
      });

    const indicatedHeaderSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getActiveMenu');
    this.store.select(fromSelectors[indicatedHeaderSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeMenu => this.headerState = activeMenu,
        error: error => console.error(`Error occurred while getting active menu from the store (${error})`)
      });

    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeSubject => this.selectedSubject = activeSubject,
        error: error => console.error(`Error occurred while getting active subject from the store (${error})`)
      });

    this.route.params
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: params => this.currentRoute = this.route.snapshot.url[0].path,
        error: error => console.error(`Error occurred while getting current route (${error})`)
      });

    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: splitWidth => {
          if (splitWidth != null) {
            this.splitWidth = splitWidth;
          } else {
            this.splitWidth = SplitWidth.default;
          }
        },
        error: error => console.error(`Error occurred while listening to split view sizes (${error})`)
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public isDomainSelected(): boolean {
    return this.activeDomain !== null;
  }

  public isDomainMenuOpened(): boolean {
    return this.side && this.headerState === 'domain';
  }

  public isPageMenuOpened(): boolean {
    return this.side && this.headerState === 'page';
  }

  public isRelationMenuOpened(): boolean {
    return this.side && this.headerState === 'relation';
  }

  public isSubjectMenuOpened(): boolean {
    return this.side && this.headerState === 'subject';
  }

  public isAccountMenuOpened(): boolean {
    return this.side && this.headerState === 'account';
  }

  public selectAccountOption(index: number): void {
    for (let i = 0; i < this.accountMenuOptions.length; i++) {
      this.accountMenuOptions[i].selected = false;
    }
    this.accountMenuOptions[index].selected = true;
    this.accountMenuOptions[index].command();
  }

  private openFeedbackInSidebar(): void {
    this.trackingService.trackEvent('klik',
      `Klik feedback:${this.side}`, null, null);
    this.store.dispatch(storeActions.sidebarOpen({type: 'feedback'}));
    this.switchMenu('default');
  }

  public switchMenu(selectedMenu: string): void {
    const menuChanged = selectedMenu !== this.headerState;
    const menuClicked = selectedMenu !== 'default'; // clicking the same button twice toggles the menu

    if (menuChanged) {
      this.store.dispatch(storeActions.headerSelectMenu({ side: this.side, menu: selectedMenu }));
      if (this.selectedSubject && menuClicked) {
        this.trackingService.trackEvent('klik',
          `Klik ${selectedMenu}:${this.side}/open met icoon`,
          null, this.selectedSubject['subjectNr']);
      }
    } else if (menuClicked) {
      this.store.dispatch(storeActions.headerSelectMenu({ side: this.side, menu: 'default' }));
    }
  }

  public closeSecondScreen() {
    let subject: string;
    if (this.selectedSubject) {
      subject = this.selectedSubject['subjectNr'];
    }
    this.trackingService.trackEvent('klik',
      `Klik close:${this.side}/icoon close`,
      null, subject);
    this.secondScreenActive.emit(true);
  }

  logout() {
    this.auth.logout();
  }

  openHelpInSidebar() {
    const helpTexts = this.helpState.generalHelp;
    let subject: string;
    if (this.selectedSubject) {
      subject = this.selectedSubject['subjectNr'];
    }
    this.switchMenu('default');
    this.trackingService.trackEvent('klik',
      `Klik help:${this.side}/manier: icoon help`,
      null, subject);
    this.helpState.emitHelpText(helpTexts);
    this.store.dispatch(storeActions.sidebarOpen({type: 'help'}));
  }

  onClickedOutside(e: Event) {
    if (this.currentRoute !== 'login') {
      this.switchMenu('default');
    }
  }
}
