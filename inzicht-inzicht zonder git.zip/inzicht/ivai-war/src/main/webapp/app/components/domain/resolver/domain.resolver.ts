import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {Store} from '@ngrx/store';
import * as ConfigActions from '@inzicht/store/actions';

@Injectable()
export class DomainResolver implements Resolve<any> {

  constructor(private readonly store: Store) { }

  resolve() {
    this.store.dispatch(ConfigActions.loadConfig());
  }
}
