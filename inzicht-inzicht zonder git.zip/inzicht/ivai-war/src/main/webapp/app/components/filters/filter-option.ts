export class FilterOption {
  label: string;
  value: any;
}
