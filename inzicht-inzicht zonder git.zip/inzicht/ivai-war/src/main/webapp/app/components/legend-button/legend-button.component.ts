import {Component, EventEmitter, Input, Output, ViewEncapsulation} from '@angular/core';
import { TrackingService } from '@inzicht/services/tracking.service';

@Component({
  selector: 'i-legend-button',
  templateUrl: './legend-button.component.html',
  styleUrls: ['./legend-button.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class LegendButtonComponent {
  @Input() widgetId: string;
  @Input() side: string;
  @Input() buttonLabel?: string;

  @Output() EventEmitterVisible: EventEmitter<boolean> = new EventEmitter<boolean>();

  private visible: boolean;
  private defaultButtonLabel: string = 'Legenda';

  constructor(private readonly trackingService: TrackingService) {
    this.EventEmitterVisible.emit(this.visible);
  }

  public getButtonArrow() {
    return this.visible ? 'bd_keyboard_arrow_up bd-30' : 'bd_keyboard_arrow_down bd-30';
  }

  public toggleLegend(event: any) {
    this.visible = !this.visible;
    this.EventEmitterVisible.emit(this.visible);

    if (this.visible) {
      this.trackingService.trackEvent('klik',
        'Klik legenda open:' + this.side + '/widget:' + this.widgetId,
        null, null);
    }
  }

  public getButtonLabel() {
    return this.buttonLabel != null ? this.buttonLabel : this.defaultButtonLabel;
  }
}
