import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs';
import {ReleaseNote, ReleaseNotesService} from '@inzicht/services/release-notes.service';

@Component({
  selector: 'i-release-notes',
  templateUrl: './release-notes.component.html',
  styleUrls: ['./release-notes.component.scss'],
  providers: [ReleaseNotesService]
})

export class ReleaseNotesComponent implements OnInit {
  public releaseNotes$: Observable<ReleaseNote>;

  constructor(private readonly releaseNotesService: ReleaseNotesService) {}

  ngOnInit(): void {
    this.releaseNotes$ = this.releaseNotesService.getReleaseNotes();
  }
}
