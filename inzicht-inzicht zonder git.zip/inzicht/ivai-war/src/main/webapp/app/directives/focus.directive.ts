import { AfterContentInit, Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[ivaFocus]'
})
export class FocusDirective implements AfterContentInit {

  constructor(private readonly el: ElementRef) {
  }

  ngAfterContentInit (): void {
    this.el.nativeElement.focus();
  }
}
