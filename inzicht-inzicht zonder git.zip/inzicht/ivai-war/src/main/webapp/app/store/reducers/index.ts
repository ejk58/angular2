import {ActionReducerMap} from '@ngrx/store';
import * as fromRouterStore from '@ngrx/router-store';
import * as fromConfig from '@inzicht/store/reducers/config.reducer';
import * as fromState from '@inzicht/store/reducers/state.reducer';
import * as fromRouter from '@inzicht/store/reducers/router.reducer';
import * as fromHeader from '@inzicht/store/reducers/header.reducer';
import * as fromSubject from '@inzicht/store/reducers/subject.reducer';
import * as fromReleations from '@inzicht/store/reducers/relations.reducer';
import * as fromSidebar from '@inzicht/store/reducers/sidebar.reducer';
import * as fromBreadcrumb from '@inzicht/store/reducers/breadcrumb.reducer';
import * as fromSystem from '@inzicht/store/reducers/system.reducer';
import * as fromWidget from '@inzicht/store/reducers/widget.reducer';

export interface AppState {
  router: fromRouterStore.RouterReducerState<fromRouter.RouterStateUrl>;
  config: fromConfig.Config;
  state: fromState.State;
  header: fromHeader.HeaderState;
  subject: fromSubject.SubjectState;
  relations: fromReleations.RelationsState;
  sidebar: fromSidebar.SidebarState;
  breadcrumb: fromBreadcrumb.BreadcrumbState;
  system: fromSystem.SystemState;
  widget: fromWidget.WidgetState;
}

export const reducers: ActionReducerMap<AppState> = {
  router: fromRouterStore.routerReducer,
  config: fromConfig.configReducer,
  state: fromState.stateReducer,
  header: fromHeader.headerReducer,
  subject: fromSubject.subjectReducer,
  relations: fromReleations.relationsdReducer,
  sidebar: fromSidebar.sidebarReducer,
  breadcrumb: fromBreadcrumb.breadcrumbReducer,
  system: fromSystem.systemReducer,
  widget: fromWidget.widgetReducer
};

export const getAppState = (state: AppState): AppState => state;

export * from '@inzicht/store/reducers/router.reducer';
export * from '@inzicht/store/reducers/config.reducer';
export * from '@inzicht/store/reducers/state.reducer';
export * from '@inzicht/store/reducers/header.reducer';
export * from '@inzicht/store/reducers/subject.reducer';
export * from '@inzicht/store/reducers/relations.reducer';
export * from '@inzicht/store/reducers/sidebar.reducer';
export * from '@inzicht/store/reducers/breadcrumb.reducer';
export * from '@inzicht/store/reducers/system.reducer';
export * from '@inzicht/store/reducers/widget.reducer';
