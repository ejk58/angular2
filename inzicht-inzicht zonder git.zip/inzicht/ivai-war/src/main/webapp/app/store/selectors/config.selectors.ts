import {createSelector} from '@ngrx/store';
import * as fromReducers from '@inzicht/store/reducers/index';
import {Message} from '@inzicht/classes/message';
import {Domain} from '@inzicht/classes/domain';


export const getConfig = createSelector(
  fromReducers.getAppState,
  (appStore: fromReducers.AppState) => appStore.config);

export const getConfigLoading = createSelector(
  getConfig,
  config => config.loading);

export const getConfigErrorCode = createSelector(
  getConfig,
  config => config.errorCode);

export const getConfigErrorMessage = createSelector(
  getConfig,
  config => config.errorCode === 0 ? null : Message.getMessage(config.errorCode));


export const getDomainElements = createSelector(
  getConfig,
  config => config.domains);

export const getDomainMenuOptions = createSelector(
  getConfig,
  config => config.menuItems);


export const getDomain = createSelector(
  getConfig,
  (config, props) => config.domains[props.domainId]);

export const getPagesInDomain = createSelector(
  getConfig,
  (config, props) => {
    const domain: Domain = config.domains[props.domainId];
    return domain ? domain.pages : null;
  });

export const getPageInDomain = createSelector(
  getConfig,
  (config, props) => {
    const domain: Domain = config.domains[props.domainId];
    return domain ? domain.pages[props.pageId] : null;
  });

export const getMenuOptionsInDomain = createSelector(
  getConfig,
  (config, props) => {
    const domain: Domain = config.domains[props.domainId];
    return domain ? domain.menuOptions : null;
  });

export const getReflectionDomainAvailable = createSelector(
  getConfig,
  (config) => config.domains['reflection'] != undefined);
