import {ConfigEffects} from '@inzicht/store/effects/config.effects';
import {RouterEffects} from '@inzicht/store/effects/router.effects';
import {SubjectEffects} from '@inzicht/store/effects/subject.effects';
import {RelationEffects} from '@inzicht/store/effects/relation.effects';
import {SystemEffects} from '@inzicht/store/effects/system.effects';
import {WidgetEffects} from '@inzicht/store/effects/widget.effects';
import {StateEffects} from '@inzicht/store/effects/state.effects';

export const effects = [
  ConfigEffects,
  RouterEffects,
  SubjectEffects,
  RelationEffects,
  SystemEffects,
  WidgetEffects,
  StateEffects
];

export * from '@inzicht/store/effects/config.effects';
export * from '@inzicht/store/effects/router.effects';
export * from '@inzicht/store/effects/subject.effects';
export * from '@inzicht/store/effects/relation.effects';
export * from '@inzicht/store/effects/system.effects';
export * from '@inzicht/store/effects/widget.effects';
export * from '@inzicht/store/effects/state.effects';
