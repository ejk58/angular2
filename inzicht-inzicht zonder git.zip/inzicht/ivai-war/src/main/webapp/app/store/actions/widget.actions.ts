import {createAction, union} from '@ngrx/store';

export const widgetLoadSuccess = createAction(
  '[WIDGETS] Widget Load Success',
  (payload: any, requestUrl: string) => ({payload, requestUrl, 'currentTimestamp': Date.now()})
);

export const widgetLoadFailed = createAction(
  '[WIDGETS] Widget Load Failed',
  (payload: any, requestUrl: string) => ({payload, requestUrl, 'currentTimestamp': Date.now()})
);

export const widgetLoad = createAction(
  '[WIDGETS] Widget Load',
  (payload: any) => ({payload})
);

export const widgetCleanup = createAction(
  '[WIDGETS] Widget Cleanup',
  (widgetDataExpirationTimeInMilliseconds: number) => ({widgetDataExpirationTimeInMilliseconds, 'currentTimestamp': Date.now()})
);

export const widgetCleanCache = createAction(
  '[WIDGETS] Widget Clean Cache',
  (requestUrl: string) => ({requestUrl})
);

export const widgetReset = createAction(
  '[WIDGETS] Widget Reset'
);

const actions = union({
  widgetLoadSuccess,
  widgetLoadFailed,
  widgetLoad,
  widgetCleanup,
  widgetReset,
  widgetCleanCache
});

export type WidgetActionsUnion = typeof actions;


