import * as widgetReducer from '@inzicht/store/reducers/widget.reducer';
import {widgetCleanCache, widgetCleanup, widgetLoadFailed, widgetLoadSuccess, widgetReset} from '@inzicht/store';

const widgetItem1 = {
  loading: false,
  requestUrl: 'url1',
  timestamp: 1,
  widgetData: {prop1: 'een', prop2: 'twee'}
};
const widgetItem2 = {
  loading: false,
  requestUrl: 'url2',
  timestamp: 2,
  widgetData: {prop1: 'eenB', prop2: 'tweeB'}
};

describe('WidgetReducer', () => {
  describe('WidgetReducer', () => {
    it('should return the default state on a Widget Reset action', () => {
      const initialWidgetState = {
        lastCleanupTimestamp: null,
        widgetItems: []
      };
      const action = widgetReset();
      const state = widgetReducer.widgetReducer(undefined, action);

      expect(state.widgetItems).toEqual(initialWidgetState.widgetItems);
      expect(state.lastCleanupTimestamp).toBeNull();
    });

    it('should have added the widget in the list on a Widget Load Success action', () => {
      const currentWidgetState = {
        lastCleanupTimestamp: Date.now(),
        widgetItems: [widgetItem1, widgetItem2]
      };
      const widgetData3 = {
        prop1: 'drie', prop2: 'vier'
      };
      const action = widgetLoadSuccess(widgetData3, 'url3');
      const state = widgetReducer.widgetReducer(currentWidgetState, action);

      expect(state.widgetItems.length).toEqual(3);
      const newItemInStore = state.widgetItems.find(widgetItem => widgetItem.requestUrl === action.requestUrl) ;
      expect(newItemInStore).toBeTruthy();
      expect(newItemInStore.widgetData.prop1).toBe('drie');
      expect(newItemInStore.widgetData.prop2).toBe('vier');
    });

    it('should have overwritten an widget with the same url in the list', () => {
      const currentWidgetState = {
        lastCleanupTimestamp: Date.now(),
        widgetItems: [widgetItem1, widgetItem2]
      };
      const widgetData4 = {
        prop1: 'vijf', prop2: 'zes'
      };
      const action = widgetLoadSuccess(widgetData4, 'url2');
      const state = widgetReducer.widgetReducer(currentWidgetState, action);

      expect(state.widgetItems.length).toEqual(2);
      const newItemInStore = state.widgetItems.find(widgetItem => widgetItem.requestUrl === action.requestUrl) ;
      expect(newItemInStore).toBeTruthy();
      expect(newItemInStore.widgetData.prop1).toBe('vijf');
      expect(newItemInStore.widgetData.prop2).toBe('zes');
    });

    it('should have added an error to the list on a Widget Load Failed action', () => {
      const currentWidgetState = {
        lastCleanupTimestamp: Date.now(),
        widgetItems: [widgetItem1, widgetItem2]
      };
      const httpError = {
        status: 403,
        statusText: 'Not found',
        message: 'The requested data was not found'
      };
      const action = widgetLoadFailed(httpError, 'url3');
      const state = widgetReducer.widgetReducer(currentWidgetState, action);

      expect(state.widgetItems.length).toEqual(3);
      const newItemInStore = state.widgetItems.find(widgetItem => widgetItem.requestUrl === action.requestUrl) ;
      expect(newItemInStore).toBeTruthy();
      expect(newItemInStore.error.statusCode).toBe(403);
      expect(newItemInStore.error.statusText).toBe('Not found');
      expect(newItemInStore.error.message).toBe('The requested data was not found');
    });

    it('should have removed items from the list on a Widget cleanup action', () => {
      const currentWidgetState = {
        lastCleanupTimestamp: Date.now() - 61000,
        widgetItems: [widgetItem1, widgetItem2]
      };
      const widgetData3 = {
        prop1: 'drie', prop2: 'vier'
      };
      const action = widgetLoadSuccess(widgetData3, 'url3');
      const state = widgetReducer.widgetReducer(currentWidgetState, action);
      expect(state.widgetItems.length).toEqual(3);
      const cleanupAction = widgetCleanup(60000);
      const newState = widgetReducer.widgetReducer(state, cleanupAction);
      expect(newState.widgetItems.length).toEqual(1);
    });

    it('should have removed the widget from the list on a widgetCleanCache action', () => {
      const currentWidgetState = {
        lastCleanupTimestamp: Date.now(),
        widgetItems: [widgetItem1, widgetItem2]
      };

      const action = widgetCleanCache('url1');
      const newState = widgetReducer.widgetReducer(currentWidgetState, action);
      expect(newState.widgetItems.length).toEqual(1);
      const removedItemInStore = newState.widgetItems.find(widgetItem => widgetItem.requestUrl === 'url1') ;
      expect(removedItemInStore).toBeFalsy();
    });
  });
});
