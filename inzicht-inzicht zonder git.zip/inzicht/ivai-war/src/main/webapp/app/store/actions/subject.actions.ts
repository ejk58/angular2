import {createAction, union} from '@ngrx/store';
import {Subject} from '@inzicht/classes/subject';
import {Domain} from '@inzicht/classes/domain';

export const subjectFind = createAction(
  '[SUBJECT] Subject Find',
  (payload: any) => ({payload})
);

export const subjectFindSuccess = createAction(
  '[SUBJECT] Subject Find Success',
  (payload: {
    side: string;
    domainId: string;
    domainName: string;
    subjects?: Subject[];
    subjectNr?: string;
    subjectSearchKey?: string;
    type?: any;
    err?: any
  }) => ({payload})
);

export const subjectFindFailed = createAction(
  '[SUBJECT] Subject Find Failed',
  (payload: {
    side: string;
    domainId: string;
    domainName: string;
    subjects?: Subject[];
    subjectNr?: string;
    subjectSearchKey?: string;
    type?: any;
    err?: any
  }) => ({payload})
);

/* This action will be triggered to get and select "already selected subject"
 * when the app is started with copy paste url.
*/
export const subjectLoad = createAction(
  '[SUBJECT] Subject Load',
  (payload?: {side: string; domain: Domain; subjectModel: Object}) => ({payload})
);

export const subjectLoadFailed = createAction(
  '[SUBJECT] Subject Load Failed',
  (payload: {side: string; subject: Subject}) => ({payload})
);

export const subjectSelect = createAction(
  '[SUBJECT] Subject Select',
  (payload: {side: string; subject: Subject}) => ({payload})
);

export const subjectClear = createAction(
  '[SUBJECT] Subject Clear',
  (payload: {side: string; subject: any}) => ({payload})
);

export const subjectReset = createAction(
  '[SUBJECT] Subject Reset'
);

const actions = union ({
  subjectFind,
  subjectFindSuccess,
  subjectFindFailed,
  subjectLoad,
  subjectLoadFailed,
  subjectSelect,
  subjectClear,
  subjectReset
});

export type SubjectActionsUnion = typeof actions;
