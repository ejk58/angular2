import {createAction, union} from '@ngrx/store';

export const systemLoad = createAction(
  '[SYSTEM] System Load'
);

export const systemVersionLoadSuccess = createAction(
  '[SYSTEM] System Version Load Success',
  (payload: string) => ({payload})
);

export const systemVersionLoadFailed = createAction(
  '[SYSTEM] System Version Load Failed',
  (payload: any) => ({payload})
);

export const systemConfigurationLoadSuccess = createAction(
  '[SYSTEM] System Configuration Load Success',
  (payload: any) => ({payload})
);

export const systemConfigurationLoadFailed = createAction(
  '[SYSTEM] System Configuration Load Failed',
  (payload: any) => ({payload})
);

const actions = union({
  systemLoad,
  systemVersionLoadSuccess,
  systemVersionLoadFailed,
  systemConfigurationLoadSuccess,
  systemConfigurationLoadFailed,
});

export type SystemActionsUnion = typeof actions;
