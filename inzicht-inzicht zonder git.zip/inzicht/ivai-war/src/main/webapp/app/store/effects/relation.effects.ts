import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {of} from 'rxjs';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {RelationsActionsUnion, loadRelations, loadRelationsSuccess, loadRelationsFailed} from '@inzicht/store/actions/index';

@Injectable()
export class RelationEffects {
  constructor(private readonly action$: Actions<RelationsActionsUnion>,
              private readonly http: HttpClient) { }

  loadRelations$ = createEffect(() => this.action$.pipe(
    ofType(loadRelations.type),
    mergeMap(action => {
      const side = action.payload.side;
      const domainId = action.payload.domainId;
      const subjectModel = action.payload.subjectModel;

      let restUrl = `rest/relation?domainId=${domainId}`;
      Object.keys(subjectModel).forEach(key => {
        if (subjectModel[key]) {
          restUrl += `&${key}=${subjectModel[key]}`;
        }
      });

      return this.http
        .get(restUrl, {withCredentials: true})
        .pipe(map((relations: any) => loadRelationsSuccess({side, list: relations})))
        .pipe(catchError(err => of(loadRelationsFailed({side, error: err}))));
    })
  ));
}
