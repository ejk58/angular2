import { createSelector } from '@ngrx/store';
import * as fromReducers from '@inzicht/store/reducers/index';

export const getBreadcrumbState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.breadcrumb);

// Get the state of **left** side state of active menu
export const getBreadcrumbStateLeft = createSelector(
  getBreadcrumbState, breadcrumb => breadcrumb.left.breadcrumbs);

// Get the state of **right** side state of active menu
export const getBreadcrumbStateRight = createSelector(
  getBreadcrumbState, breadcrumb => breadcrumb.right.breadcrumbs);
