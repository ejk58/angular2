import {
  widgetCleanCache,
  widgetCleanup,
  widgetLoad,
  widgetLoadFailed,
  widgetLoadSuccess,
  widgetReset
} from '@inzicht/store';

const httpsUrl1: string = 'https://url1';

describe('WidgetAction', () => {
  describe('WidgetLoad', () => {
    it('should create a widgetload action', () => {
      const payload = httpsUrl1;
      const action = widgetLoad(payload);
      expect({...action}).toEqual({type: widgetLoad.type, payload});
    });
  });

  describe('WidgetLoadSuccess', () => {
    it('should create a widget success action', () => {
      const payload = {prop1: 'een', prop2: 'twee'};
      const requestUrl = httpsUrl1;
      const beforeTimestamp = Date.now();
      const action = widgetLoadSuccess(payload, requestUrl);
      const afterTimestamp = Date.now();

      expect(action.type).toEqual(widgetLoadSuccess.type);
      expect(action.payload).toEqual(payload);
      expect(action.requestUrl).toEqual(requestUrl);
      expect(action.currentTimestamp).toBeGreaterThanOrEqual(beforeTimestamp);
      expect(action.currentTimestamp).toBeLessThanOrEqual(afterTimestamp);
    });
  });

  describe('WidgetLoadFailed', () => {
    it('should create a widget failed action', () => {
      const payload = 'Error while getting data.';
      const requestUrl = httpsUrl1;
      const beforeTimestamp = Date.now();
      const action = widgetLoadFailed(payload, requestUrl);
      const afterTimestamp = Date.now();

      expect(action.type).toEqual(widgetLoadFailed.type);
      expect(action.payload).toEqual(payload);
      expect(action.requestUrl).toEqual(requestUrl);
      expect(action.currentTimestamp).toBeGreaterThanOrEqual(beforeTimestamp);
      expect(action.currentTimestamp).toBeLessThanOrEqual(afterTimestamp);
    });
  });

  describe('WidgetCleanup', () => {
    it('should create a widget cleanup action', () => {
      const widgetDataExpirationTimeInMilliseconds = 60000;
      const beforeTimestamp = Date.now();
      const action = widgetCleanup(widgetDataExpirationTimeInMilliseconds);
      const afterTimestamp = Date.now();

      expect(action.type).toEqual(widgetCleanup.type);
      expect(action.widgetDataExpirationTimeInMilliseconds).toEqual(widgetDataExpirationTimeInMilliseconds);
      expect(action.currentTimestamp).toBeGreaterThanOrEqual(beforeTimestamp);
      expect(action.currentTimestamp).toBeLessThanOrEqual(afterTimestamp);
    });
  });

  describe('WidgetReset', () => {
    it('should create a widget reset action', () => {
      const action = widgetReset();
      expect({...action}).toEqual({type: widgetReset.type});
    });
  });

  describe('widgetCleanCache', () => {
    it('should create a widget clean cache action', () => {
      const requestUrl = httpsUrl1;
      const action = widgetCleanCache(requestUrl);
      expect(action.type).toEqual(widgetCleanCache.type);
      expect(action.requestUrl).toEqual(requestUrl);
    });
  });
});
