import {createAction, union} from '@ngrx/store';

export const logout = createAction(
  '[GLOBAL] Logout'
);

const actions = union({
  logout
});

export type GlobalActionsUnion = typeof actions;
