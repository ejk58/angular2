import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class AcceptanceReviewService {

  constructor(private readonly http: HttpClient) { }

  sendAcceptanceReview(acceptanceReview): Observable<any> {
    return this.http.post('rest/acceptancereview', acceptanceReview);
  }
}
