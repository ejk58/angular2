import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Subject } from '@inzicht/classes/subject';

@Injectable()
export class SubjectService {

  constructor(private readonly http: HttpClient) {}

  public getSubjects(domainId: string, type: string, nr: string): Observable<any> {
    const url = `rest/subject/find?domainId=${domainId}&${type}=${nr}`;
    return this.http.get(url, {withCredentials: true});
  }

  public getSubject(domainId: string, params: {[key: string]: string}): Observable<any> {
    let queryParamString = '';
    Object.keys(params).forEach(key => {
      queryParamString += `&${key}=${params[key]}`;
    });

    const url = `rest/subject/find?domainId=${domainId}${queryParamString}`;
    return this.http.get(url, {withCredentials: true});
  }
}
