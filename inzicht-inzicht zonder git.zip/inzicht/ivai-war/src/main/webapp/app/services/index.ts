import {AuthenticationService} from '@inzicht/services/authentication.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {WidgetService} from '@inzicht/services/widget.service';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import {PageTitleService} from '@inzicht/services/page-title.service';
import {HelpState} from '@inzicht/services/help.service';
import {ReleaseNotesService} from '@inzicht/services/release-notes.service';
import {EventService} from '@inzicht/services/event.service';
import {SubjectService} from '@inzicht/services/subject.service';
import {DataTypeService} from '@inzicht/services/data-type.service';

export const list = [
  AuthenticationService,
  TrackingService,
  WidgetService,
  SplitViewState,
  PageTitleService,
  HelpState,
  ReleaseNotesService,
  EventService,
  SubjectService,
  DataTypeService
];
