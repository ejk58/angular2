import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';

import {Store} from '@ngrx/store';
import * as fromSelectors from '@inzicht/store/selectors';
import {first} from 'rxjs/operators';
import * as storeActions from '@inzicht/store/actions';

@Injectable()
export class WidgetService {
  routerSideParams: any;

  constructor(private readonly http: HttpClient,
              private readonly store: Store) {
    this.store.select(fromSelectors.getRouterState).subscribe({
      next: router => {
        this.routerSideParams = router.routerSidesParams;
      },
      error: error => console.error(`Error getting router state from store`)
    });
  }

  getWidgetDataByHttp(widgetId: string, side: string, filter: any): Observable<any> {
    const requestUrl = this.getRequestUrl(widgetId, side, filter);
    return this.http.get(requestUrl);
  }

  getWidget(widgetId: string, side: string, filter: any): Observable<any> {
    const requestUrl = this.getRequestUrl(widgetId, side, filter);
    this.removeNoCachingWidgetFromStore(requestUrl);
    this.store.dispatch(storeActions.widgetLoad({requestUrl}));
    return this.store.select(fromSelectors.getWidget(requestUrl))
      .pipe(first(widget => widget && widget.loading === false));
  }

  removeWidgetFromStore(widgetId: string, side: string, filter: any): void {
    const requestUrl = this.getRequestUrl(widgetId, side, filter);
    this.store.dispatch(storeActions.widgetCleanCache(requestUrl));
  }

  private removeNoCachingWidgetFromStore (requestUrl: string) {
    const widget = this.store.selectSync(fromSelectors.getWidget(requestUrl));
    if (widget != undefined && widget.widgetData != undefined && widget.error == undefined
      && widget.widgetData.options.noCaching && widget.widgetData.options.noCaching !== 'false') {
      this.store.dispatch(storeActions.widgetCleanCache(requestUrl));
    }
  }

  private getRequestUrl(widgetId: string, side: string, filter: any): string {
    const params: any = {};
    const propertiesToExclude: string[] = ['pageId', 'domainId'];
    const propertyValuesToExclude: string[] = ['null'];

    if (side && this.routerSideParams) {
      this.appendUrlParams(side, params, propertiesToExclude, propertyValuesToExclude);
    }
    if (filter) {
      this.appendFilterParams(filter, params, propertiesToExclude, propertyValuesToExclude);
    }

    let httpParams = new HttpParams();
    Object.keys(params).forEach(prop => {
      const value = Array.isArray(params[prop]) ? params[prop] : `${params[prop]}`.split(',');
      value.forEach(v => httpParams = httpParams.append(prop, v));
    });

    return `rest/widget/${widgetId}?${httpParams}`;
  }

  private appendUrlParams(side: string, params: any, propertiesToExclude: string[], propertyValuesToExclude: string[]): void {
    const urlParams = this.routerSideParams[side];
    params.domainId = urlParams.domainId;
    Object.keys(urlParams).forEach(prop => {
      if (propertiesToExclude.indexOf(prop) === -1 && propertyValuesToExclude.indexOf(urlParams[prop]) === -1) {
        this.putIfKeyAndValueAbsent(params, prop, urlParams[prop]);
      }
    });
  }

  private appendFilterParams(filter: any, params: any, propertiesToExclude: string[], propertyValuesToExclude: string[]): void {
    Object.keys(filter).forEach(prop => {
      if (propertiesToExclude.indexOf(prop) === -1 && propertyValuesToExclude.indexOf(filter[prop]) === -1) {
        this.putIfKeyAndValueAbsent(params, prop, filter[prop]);
      }
    });
  }

  private putIfKeyAndValueAbsent(params: any, key: string, value: any): void {
    if (typeof params[key] === 'undefined' || params[key] !== value) {
      params[key] = value;
    }
  }
}
