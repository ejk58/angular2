import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

export class ReleaseNote {
  public releaseDate: Date;
  public version: string;
  public domainName: string;
  public type: string;
  public description: string;
}

@Injectable()
export class ReleaseNotesService {

  constructor(private readonly http: HttpClient) { }

  public getReleaseNotes(): Observable<any> {
    return this.http.get('rest/releasenote?version=latest', {withCredentials: true});
  }
}
