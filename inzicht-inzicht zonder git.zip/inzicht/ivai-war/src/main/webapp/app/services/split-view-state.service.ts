import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

import { SplitWidth } from '@inzicht/classes/split-width';

@Injectable()
export class SplitViewState {
  public readonly breakpointMobile = 320;
  public readonly breakpointResponsive = 480;

  private readonly openSecondScreen$ = new BehaviorSubject(false);
  private readonly splitWidth$ = new BehaviorSubject(SplitWidth.default);

  emitSizes(sizes: SplitWidth) {
    setTimeout(() => this.splitWidth$.next(sizes));
  }

  listenSizes(): Observable<SplitWidth> {
    return this.splitWidth$;
  }

  emitOpen2Screen(open2Screen: boolean) {
    setTimeout(() => this.openSecondScreen$.next(open2Screen));
  }

  listenOpen2Screen(): Observable<boolean> {
    return this.openSecondScreen$;
  }
}
