import {Injectable} from '@angular/core';
import {Side} from '@inzicht/commons/side';
import {BehaviorSubject, Observable} from 'rxjs';
import {delay, map} from 'rxjs/operators';

export enum ChartEvent {
  enterTooltip = 'enterTooltip',
  leaveTooltip = 'leaveTooltip'
}

export enum LegendEvent {
  enableItem = 'enableItem',
  disableItem = 'disableItem'
}

export enum TableEvent {
  enterRow = 'enterRow',
  leaveRow = 'leaveRow'
}

export type EventType = ChartEvent | LegendEvent | TableEvent;

export class Event<T> {
  constructor(
    public readonly type: EventType,
    public readonly payload?: T
  ) {
  }
}

export type EventCallback = <T>(payload: T) => void;

export class EventListener {
  [widgetListenerName: string]: EventCallback;
}

export class EventListenerTypeMap {
  [type: string]: EventListener;
}

export class EventListenerSourceMap {
  [widgetSourceName: string]: EventListenerTypeMap;
}

export class EventListenerMap {
  left?: EventListenerSourceMap;
  right?: EventListenerSourceMap;
}

@Injectable()
export class EventService {

  private readonly listeners: EventListenerMap = {};
  private readonly listenersSubject$: BehaviorSubject<EventListenerMap> = new BehaviorSubject(this.listeners);

  public hasListeners(side: Side, widgetSourceName: string, ...eventTypes: EventType[]): Observable<boolean> {
    return this.listenersSubject$.pipe(
      delay(0),
      map(listeners => {
        if (listeners[side] && listeners[side][widgetSourceName]) {
          return eventTypes.some(eventType => listeners[side][widgetSourceName][eventType] && Object.keys(listeners[side][widgetSourceName][eventType]).length > 0);
        } else {
          return false;
        }
      })
    );
  }

  public listen(side: Side, widgetSourceName: string, eventType: EventType, widgetListenerName: string, callback: EventCallback): void {
    if (this.listeners[side] == null) {
      this.listeners[side] = {};
    }

    if (this.listeners[side][widgetSourceName] == null) {
      this.listeners[side][widgetSourceName] = {};
    }

    if (this.listeners[side][widgetSourceName][eventType] == null) {
      this.listeners[side][widgetSourceName][eventType] = {};
    }

    this.listeners[side][widgetSourceName][eventType][widgetListenerName] = callback;
    this.listenersSubject$.next(this.listeners);
  }

  public remove(side: Side, widgetSourceName: string, eventType: EventType, widgetListenerName: string): void {
    if (this.listeners[side] != null && this.listeners[side][widgetSourceName] != null && this.listeners[side][widgetSourceName][eventType] != null) {
      delete this.listeners[side][widgetSourceName][eventType][widgetListenerName];
      this.listenersSubject$.next(this.listeners);
    }
  }

  public broadcast<T>(side: Side, widgetSourceName: string, event: Event<T>): void {
    const existingSide = this.listeners[side];
    if (existingSide) {
      const existingSources = existingSide[widgetSourceName];
      if (existingSources != null) {
        const existingListeners = existingSources[event.type];
        if (existingListeners != null) {
          Object.keys(existingListeners).forEach(widgetName => {
            const callback = existingListeners[widgetName];
            callback(event.payload);
          });
        }
      }
    }
  }
}
