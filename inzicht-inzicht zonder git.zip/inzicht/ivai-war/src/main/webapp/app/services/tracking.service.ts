import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {CookieService} from 'ngx-cookie-service';

@Injectable()
export class TrackingService {

  private readonly idCharacterSet = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  private readonly idLength = 8;
  private currentId: string;

  constructor(private readonly http: HttpClient,
              private readonly cookieService: CookieService) {
    this.init();
  }

  private init(): void {
    this.generateId();
  }

  private generateId(): void {
    const cookieExists: boolean = this.cookieService.check('Inzicht');
    if (cookieExists) {
      const cookieValue: string = this.cookieService.get('Inzicht');
      this.currentId = cookieValue;
    } else {
      let rtn = '';
      for (let i = 0; i < this.idLength; i++) {
        rtn += this.idCharacterSet.charAt(Math.floor(Math.random() * this.idCharacterSet.length));
      }
      this.currentId = rtn;

      this.cookieService.set('Inzicht', this.currentId, new Date('9999-01-01'));
    }
  }

  public trackEvent(type: string, value1: string, value2: string, subjectNr: string): void {
    this.track(type, value1, value2, subjectNr);
  }

  public track(type: string, value1: string, value2: string, subjectNr: string): void {
    const location = window.location.href;
    const event = {
      'url': location,
      'subjectNumber': subjectNr,
      'type': type,
      'value1': value1,
      'value2': value2,
      'trackingid': this.currentId
    };

    this.http.post('rest/event', event, {withCredentials: true}).subscribe(
      data => data,
      error => console.error(`Failed to store the event in the database with the error: ${error.message}`)
    );
  }
}
