import {WidgetDefinition} from '@inzicht/classes/widget-definition';

export interface Page {
  key: string;
  type: 'main' | 'detail' | 'restricted';
  title: string;
  rows: WidgetDefinition[][];
  mandatoryPathKeys: string[];
  globalFilterWidget?: string;
  headerWidget?: string;
  label?: string;
}
