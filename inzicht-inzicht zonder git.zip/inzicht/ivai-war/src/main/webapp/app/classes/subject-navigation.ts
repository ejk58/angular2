export class SubjectNavigation {
  constructor(public domainId: string, public initPageId: string) {}
}
