export class SubjectPresentationLabel {
  constructor (public text: string, public color: string, public backgroundColor: string) {}
}
