import {Subject} from '@inzicht/classes/subject';

export interface SearchResult {
  subjects: Subject[];
  subjectSearchKey: string;
  errorCode?: number;
  message?: string;
}
