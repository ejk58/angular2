import * as d3 from 'd3';

import {LinkPainter} from '@inzicht/classes/links/link-painter';
import {LinkSubjectPresentation} from '@inzicht/classes/links/link-subject-presentation';
import {Link} from '@inzicht/classes/links/link';
import {LinkDirection} from '@inzicht/widgettypes/hierarchical-graph/model/link-direction';
import {Node} from '@inzicht/classes/nodes/node';

export class LinkRelationHierarchicalPainter implements LinkPainter<LinkSubjectPresentation> {

  public static readonly linkHeight = 80;
  public static readonly linkRadius: number = 40;
  public static readonly typeRadius: number = 20;
  public static readonly percentageRadius: number = 15;

  protected readonly calculateSourceX = (link: Link<Node<any, any>, any, any>): number =>
    link.source.x + (link.presentation.isPartnerLink ? (link.source.x > link.target.x ? -30 : 30 ) : 0);
  protected readonly calculateSourceY = (link: Link<Node<any, any>, any, any>): number =>
    link.source.y + (link.presentation.isPartnerLink ? -30 : 50);
  protected readonly calculateTargetX = (link: Link<Node<any, any>, any, any>): number =>
    link.target.x + (link.presentation.isPartnerLink ? (link.target.x > link.source.x ? -30 : 30 ) : 0);
  protected readonly calculateTargetY = (link: Link<Node<any, any>, any, any>): number =>
    link.target.y + (link.presentation.isPartnerLink ? -30 : (link.presentation.direction === LinkDirection.sibling ? 50 : -80));

  public drawLinks(graph: d3.Selection<any, any, any, any>, linkMainGroup: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>, links: Link<Node<any, any>, any, LinkSubjectPresentation>[]): void {

    const unlabeledLinks = links.filter(link => !link.presentation.isLabeled);
    const labeledLinks = links.filter(link => link.presentation.isLabeled);
    const sortedLinks = [...unlabeledLinks, ...labeledLinks];

    const linkGroups = linkMainGroup.selectAll('g.link')
      .data(sortedLinks, (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => link.id);

    this.drawNewLinks(linkGroups.enter().append('g'));
    this.updateExistingLinks(linkGroups);
    this.removeObsoleteLinks(linkGroups.exit());
  }

  protected drawNewLinks(newLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    newLinkGroups
      .attr('class', link => link.classes.join(' ') + ' link');

    this.drawLine(newLinkGroups);
    this.drawType(newLinkGroups);
    this.drawPercentage(newLinkGroups);
    this.drawEconomicInterest(newLinkGroups);
  }

  protected updateExistingLinks(existingLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    existingLinkGroups.selectAll('.link-line').filter((link: Link<Node<any, any>, any, LinkSubjectPresentation>) => !link.presentation.isCurvedLink)
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY);

    existingLinkGroups.selectAll('.link-line').filter((link: Link<Node<any, any>, any, LinkSubjectPresentation>) => link.presentation.isCurvedLink)
      .attr('d', (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => this.getCurvedLinePath(link));

    existingLinkGroups.selectAll('.link-type')
      .attr('transform', (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => this.getLabelTranslation(link));

    existingLinkGroups.selectAll('.link-percentage')
      .attr('transform', (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => this.getLabelTranslation(link));

    existingLinkGroups.selectAll('.link-economic-interest')
      .attr('transform', (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => this.getLabelTranslation(link));
  }

  protected removeObsoleteLinks(obsoleteLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    obsoleteLinkGroups.remove();
  }

  protected drawLine(newLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    newLinkGroups.filter(link => !link.presentation.isCurvedLink)
      .append('line')
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY)
      .classed('link-line', true);

    newLinkGroups.filter(link => link.presentation.isCurvedLink)
      .append('path')
      .attr('d', link => this.getCurvedLinePath(link))
      .classed('link-line', true);
  }

  protected drawType(newLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    const radius = LinkRelationHierarchicalPainter.typeRadius;
    const newLinkWithTypes = newLinkGroups.filter(link => link.presentation.isTypedLink)
      .append('g')
      .attr('transform', link => this.getLabelTranslation(link))
      .classed('link-type', true);

    newLinkWithTypes
      .append('polygon')
      .attr('points', `-${radius},-${Math.floor(radius * 2 / 3)},${radius},-${Math.floor(radius * 2 / 3)},0,${radius}`)
      .classed('link-type-triangle', true);

    newLinkWithTypes
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('link-type-text', true)
      .text(link => link.presentation.type);
  }

  protected drawPercentage(newLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    const newLinkWithPercentageGroups = newLinkGroups.filter(link => link.presentation.isPercentageLink)
      .append('g')
      .attr('transform', link => this.getLabelTranslation(link))
      .classed('link-percentage', true);

    newLinkWithPercentageGroups
      .append('circle')
      .attr('r', LinkRelationHierarchicalPainter.percentageRadius)
      .attr('cx', 0)
      .attr('cy', 0)
      .classed('link-percentage-circle', true);

    newLinkWithPercentageGroups
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(LinkRelationHierarchicalPainter.percentageRadius / 3))
      .classed('link-percentage-text', true)
      .text(link => link.presentation.percentage ? link.presentation.percentage : '?');
  }

  protected drawEconomicInterest(newLinkGroups: d3.Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    const newLinkWithEconomicInterestGroups = newLinkGroups.filter(link => link.presentation.isEconomicInterestLink)
      .append('g')
      .attr('transform', link => this.getLabelTranslation(link))
      .classed('link-economic-interest', true);

    newLinkWithEconomicInterestGroups
      .append('rect')
      .attr('width', 50)
      .attr('height', 23)
      .attr('x', -25)
      .attr('y', -11.5)
      .classed('link-economic-interest-rect', true);

    newLinkWithEconomicInterestGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 5)
      .classed('link-economic-interest-text', true)
      .text(link => link.presentation.economicInterest ? link.presentation.economicInterest : '?');
  }

  protected getCurvedLinePath(link: Link<Node<any, any>, any, LinkSubjectPresentation>): string {
    const sourceX = this.calculateSourceX(link);
    const distanceX = this.calculateTargetX(link) - sourceX;
    const sourceY = this.calculateSourceY(link);
    const distanceY = this.calculateTargetY(link) - sourceY;
    const verticalLine = distanceX === 0;

    const deviationX = verticalLine ? Math.floor(distanceY / 2) : Math.floor(distanceX / 2);
    const deviationY = verticalLine ? Math.floor(distanceY / 2) : Math.floor(Math.abs(distanceY / 3) + Math.abs(distanceX / 6));

    return `M${sourceX} ${sourceY}q${deviationX} ${deviationY} ${distanceX}  ${distanceY}`;
  }

  protected getLabelTranslation(link: Link<Node<any, any>, any, LinkSubjectPresentation>): string {
    const positionRatio = this.getLabelPositionRatio(link);
    const labelX = this.getValueForPositionRatio(this.calculateSourceX(link), this.calculateTargetX(link), positionRatio);
    const labelY = this.getValueForPositionRatio(this.calculateSourceY(link), this.calculateTargetY(link), positionRatio);
    return `translate(${labelX},${labelY})`;
  }

  protected getLabelPositionRatio(link: Link<Node<any, any>, any, LinkSubjectPresentation>): number {
    let bestPositionRatio = 0.50;
    let bestPositionCrossingLinkCount = this.getNumberOfCrossingLinks(link, bestPositionRatio);
    let positionRatio = 0.15;

    while (bestPositionCrossingLinkCount > 0 && positionRatio < 0.85) {
      const positionCrossingLinkCount = this.getNumberOfCrossingLinks(link, positionRatio);

      if (positionCrossingLinkCount < bestPositionCrossingLinkCount) {
        bestPositionRatio = positionRatio;
        bestPositionCrossingLinkCount = positionCrossingLinkCount;
      }

      positionRatio = positionRatio + 0.10;
    }

    return bestPositionRatio;
  }

  protected getNumberOfCrossingLinks(link: Link<Node<any, any>, any, LinkSubjectPresentation>, ratio: number): number {

    const sourceX = this.calculateSourceX(link);
    const targetX = this.calculateTargetX(link);
    const x = this.getValueForPositionRatio(sourceX, targetX, ratio);

    const sourceY = this.calculateSourceY(link);
    const targetY = this.calculateTargetY(link);
    const y = this.getValueForPositionRatio(sourceY, targetY, ratio);

    const minimumX = x - LinkRelationHierarchicalPainter.percentageRadius * 2;
    const maximumX = x + LinkRelationHierarchicalPainter.percentageRadius * 2;

    let count = 0;

    link.presentation.possibleCrossingLinks.forEach(possibleCrossingLink => {
      const crossingLinkSourceX = this.calculateSourceX(possibleCrossingLink);
      const crossingLinkTargetX = this.calculateTargetX(possibleCrossingLink);

      if ((crossingLinkSourceX < maximumX && crossingLinkTargetX > minimumX) || (crossingLinkSourceX > minimumX && crossingLinkTargetX < maximumX)) {
        const crossingLinkSourceY = this.calculateSourceY(possibleCrossingLink);
        const crossingLinkTargetY = this.calculateTargetY(possibleCrossingLink);
        const crossingRatio = (y - crossingLinkSourceY) / (crossingLinkTargetY - crossingLinkSourceY);

        if (crossingRatio >= 0.0 && crossingRatio <= 1.0) {
          const crossingX = this.getValueForPositionRatio(crossingLinkSourceX, crossingLinkTargetX, crossingRatio);

          if (crossingX > minimumX && crossingX < maximumX) {
            count++;
          }
        }
      }
    });

    return count;
  }

  protected getValueForPositionRatio(source: number, target: number, positionRatio: number): number {
    return source + (target - source) * positionRatio;
  }
}
