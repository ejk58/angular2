import {Node} from '@inzicht/classes/nodes/node';

export interface NodeFactory<M, P> {
  build(row: any): Node<M, P>;
}
