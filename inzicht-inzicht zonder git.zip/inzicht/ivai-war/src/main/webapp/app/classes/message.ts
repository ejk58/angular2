export class Message {

  // 4xx - HTTP Client Errors
  public static readonly badRequestCode = 400;
  public static readonly badRequestMessage = 'Er is een fout opgetreden bij het ophalen van de gegevens';

  public static readonly notAuthorizedCode = 401;
  public static readonly notAuthorizedMessage = 'Je probeert gegevens op te halen waartoe je geen rechten hebt';

  public static readonly forbiddenCode = 403;
  public static readonly forbiddenMessage = 'De gebruikerssessie op de server is verlopen, waardoor je automatisch uitgelogd bent';

  public static readonly notFoundCode = 404;
  public static readonly notFoundMessage = 'De gegevens konden niet gevonden worden';

  // 5xx - HTTP Server Errors
  public static readonly internalServerErrorCode = 500;
  public static readonly internalServerErrorMessage = 'Er is een fout opgetreden';

  public static readonly badGatewayCode = 502;
  public static readonly badGatewayMessage = 'Er is een fout opgetreden bij de bron';

  public static readonly serviceUnavailableCode = 503;
  public static readonly serviceUnavailableMessage = 'De server van Inzicht kan op dit moment niet bereikt worden';

  public static readonly gatewayTimeoutCode = 504;
  public static readonly gatewayTimeoutMessage = 'Het ophalen van de gegevens bij de bron duurt te lang en is afgebroken';

  // 7xx - Inzicht Messages
  public static readonly noResultsCode = 701;
  public static readonly noResultMessage = 'Geen resultaat';

  // 8xx - Inzicht Warnings

  // 9xx - Inzicht Errors
  public static readonly invalidSearchValueCode = 901;
  public static readonly invalidSearchValueMessage = 'De opgegeven zoekwaarde is niet valide';

  public static readonly invalidSubjectNrCode = 902;
  public static readonly invalidSubjectNrMessage = 'Het opgegeven BSN is niet valide';

  public static readonly invalidEntityNrCode = 903;
  public static readonly invalidEntityNrMessage = 'Het opgegeven entiteitnummer is niet valide';

  public static readonly genericErrorCode = 999;
  public static readonly defaultErrorMessage = 'Er is een fout opgetreden';

  public static readonly messageMap: Map<number, Message> = new Map([
    [Message.badRequestCode, new Message(Message.badRequestCode, 'error', Message.badRequestMessage)],
    [Message.notAuthorizedCode, new Message(Message.notAuthorizedCode, 'error', Message.notAuthorizedMessage)],
    [Message.forbiddenCode, new Message(Message.forbiddenCode, 'error', Message.forbiddenMessage)],
    [Message.notFoundCode, new Message(Message.notFoundCode, 'error', Message.notFoundMessage)],
    [Message.internalServerErrorCode, new Message(Message.internalServerErrorCode, 'error', Message.internalServerErrorMessage)],
    [Message.badGatewayCode, new Message(Message.badGatewayCode, 'error', Message.badGatewayMessage)],
    [Message.serviceUnavailableCode, new Message(Message.serviceUnavailableCode, 'error', Message.serviceUnavailableMessage)],
    [Message.gatewayTimeoutCode, new Message(Message.gatewayTimeoutCode, 'error', Message.gatewayTimeoutMessage)],
    [Message.noResultsCode, new Message(Message.noResultsCode, 'message', Message.noResultMessage)],
    [Message.invalidSearchValueCode, new Message(Message.invalidSearchValueCode, 'error', Message.invalidSearchValueMessage)],
    [Message.invalidSubjectNrCode, new Message(Message.invalidSubjectNrCode, 'error', Message.invalidSubjectNrMessage)],
    [Message.invalidEntityNrCode, new Message(Message.invalidEntityNrCode, 'error', Message.invalidEntityNrMessage)]
  ]);

  public text: string;

  constructor(public code: number,
              public type: 'error' | 'message' | 'news' | 'warning',
              public messageText: string,
              public details?: any) {

    this.text = (this.type === 'error' || this.type === 'warning') ? `${this.messageText} (${this.code}).` : `${this.messageText}.`;
  }

  public static getMessage(code: number): Message {
    return Message.messageMap.has(code) ? Message.messageMap.get(code) : new Message(code, 'error', Message.defaultErrorMessage);
  }
}
