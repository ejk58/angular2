import * as d3 from 'd3';

import {Node} from '@inzicht/classes/nodes/node';

export class Link<N extends Node<any, any>, M, P> implements d3.SimulationLinkDatum<N> {

  public id: string;
  public source: N;
  public target: N;

  public model: M;
  public presentation: P;

  public data: any;
  public classes: string[];

  public hasMatchingLink(node: N, linkedNode: N): boolean {
    return (this.source === node && this.target === linkedNode);
  }

  public hasMatchingNodes(node: N, linkedNode: N): boolean {
    return (this.source === node && this.target === linkedNode) || (this.source === linkedNode && this.target === node);
  }

  public getOtherNode(node: N): N {
    return (this.source === node) ? this.target : this.source;
  }
}
