import {Pipe, PipeTransform} from '@angular/core';
import {DatePipe} from '@angular/common';

@Pipe({
  name: 'iDate'
})
export class InzichtDatePipe implements PipeTransform {

  constructor(private readonly ngDatePipe: DatePipe) { }

  transform(value: { value?: number, filterValue?: string }, ...args: any[]): string {
    if (value == null) {
      return '';
    } else if (value.filterValue) {
      return value.filterValue;
    } else if (value.value) {
      try {
        return this.ngDatePipe.transform(value.value, ...args);
      } catch (e) {
        return '';
      }
    } else if (typeof value === 'string' || typeof value === 'number' || value instanceof Date) {
      try {
        return this.ngDatePipe.transform(value, ...args);
      } catch (e) {
        return '';
      }
    } else {
      return '';
    }
  }
}
