import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'processLight'
})
export class ProcessLightPipe implements PipeTransform {

  transform(value: any): string {
    let styledValue = '';

    if (value !== null && value.hasOwnProperty('Waarde') && value['Waarde'] !== null) {
      const innerValue = value['Waarde'];

      let colorValue = '';
      if (value['Kleur'] === 'STOPLICHT_GROEN') {
        colorValue = ' green';
      } else if (value['Kleur'] === 'STOPLICHT_GEEL') {
        colorValue = ' orange';
      } else if (value['Kleur'] === 'STOPLICHT_ROOD') {
        colorValue = ' red';
      }

      styledValue = `<div class="processlight"><div class="number">${innerValue}</div><div class="light ${colorValue}"></div></div>`;
    }

    return styledValue;
  }
}
