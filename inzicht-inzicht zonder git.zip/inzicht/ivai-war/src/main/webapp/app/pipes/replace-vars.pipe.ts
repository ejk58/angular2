import {OnDestroy, Pipe, PipeTransform} from '@angular/core';
import {Store} from '@ngrx/store';
import * as fromSelectors from '@inzicht/store/selectors';
import {Subscription} from 'rxjs';

@Pipe({
  name: 'replaceVars'
})
export class ReplaceVarsPipe implements PipeTransform, OnDestroy {

  private side: string = 'left';
  private taxYear: any;
  private subscription: Subscription;

  constructor(public store: Store) {
    this.subscription = this.store.select(fromSelectors.getRouterSides).subscribe({
      next: routerSides => {
        if (routerSides[this.side]) {
          this.taxYear = routerSides[this.side].taxYear;
        }
      },
      error: error => console.error(`Error getting router sides (${error})`)
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  transform(value: any, side: string, input: any): string {
    this.side = side;

    if (isNaN(value)) {
      if (input) {
        if (input['baseYear']) {
          this.taxYear = input['baseYear'];
        } else if (!isNaN(input)) {
          this.taxYear = Number(input);
        }
      }

      if (value && side && this.taxYear) {
        value = this.replaceTaxYear(value);
      }
    }

    return value;
  }

  private replaceTaxYear(label: string): string {
    let result = label;
    let taxYearMatch = result.match(/\{taxYear\s*[-+]?\s*\d*\}/);
    while (taxYearMatch !== null) {
      const taxYear = this.taxYear;
      const baseYear = Number(taxYear);

      const taxYearPlaceholder = taxYearMatch[0];
      const taxYearModifier = taxYearPlaceholder.match(/[-+]?\s*\d/);
      const taxYearDelta = (taxYearModifier === null ? 0 : Number(taxYearModifier[0].replace(/\s/g, '')));

      result = `${result.slice(0, taxYearMatch.index)}${(baseYear + taxYearDelta)}${result.slice(taxYearMatch.index + taxYearPlaceholder.length)}`;
      taxYearMatch = result.match(/\{taxYear\s*[-+]?\s*\d*\}/);
    }
    return result;
  }
}
