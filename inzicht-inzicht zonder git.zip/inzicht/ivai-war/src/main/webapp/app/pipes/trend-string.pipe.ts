import { Pipe, PipeTransform } from '@angular/core';
import {DomSanitizer, SafeHtml} from '@angular/platform-browser';

@Pipe({
  name: 'trendString'
})

export class TrendStringPipe implements PipeTransform {

  private innerValue = null;
  private newValue = '';

  constructor(protected sanitizer: DomSanitizer) {}

  transform(value: any): SafeHtml {
    if (value !== null) {
      if (value.hasOwnProperty('value') && value['value'] !== null) {
        this.innerValue = value['value'];
      }

      const stringValue = this.innerValue == null ? ' ' : String(this.innerValue);
      const iconValue = ((value.hasOwnProperty('revision') && value['revision'] === 1) || (value.hasOwnProperty('Correctie') && value['Correctie'] === 'J')) ? ' bd_lens' : '';

      this.newValue = '<div class="trendstring">' +
        '<div class="string">' + stringValue + '</div>' +
        '<div class="trendicon' + iconValue + '"></div>' +
        '</div>';
    }

    return this.sanitizer.bypassSecurityTrustHtml(this.newValue);
  }
}
