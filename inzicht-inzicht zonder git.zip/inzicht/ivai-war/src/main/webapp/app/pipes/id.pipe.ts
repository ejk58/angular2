import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'id'
})

export class IdPipe implements PipeTransform {

  transform(value: string): string {
    return value.split(/[-_/]/).map((part: string, index: number): string => {
      return (index === 0 ? part.toLowerCase() : (part[0].toUpperCase() + part.substring(1).toLowerCase()));
    }).join('');
  }
}
