import {LOCALE_ID, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {CurrencyPipe, DatePipe, DecimalPipe, registerLocaleData} from '@angular/common';
import localeNl from '@angular/common/locales/nl';

import {ButtonModule} from 'primeng/button';
import {CheckboxModule} from 'primeng/checkbox';
import {RadioButtonModule} from 'primeng/radiobutton';
import {DropdownModule} from 'primeng/dropdown';
import {InputSwitchModule} from 'primeng/inputswitch';
import {MultiSelectModule} from 'primeng/multiselect';
import {ToggleButtonModule} from 'primeng/togglebutton';
import {PaginatorModule} from 'primeng/paginator';
import {AccordionModule} from 'primeng/accordion';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import {SidebarModule} from 'primeng/sidebar';
import {MegaMenuModule} from 'primeng/megamenu';
import {DialogModule} from 'primeng/dialog';
import {PanelMenuModule} from 'primeng/panelmenu';
import {InputTextModule} from 'primeng/inputtext';
import {TableModule} from 'primeng/table';
import {TooltipModule} from 'primeng/tooltip';
import {FileUploadModule} from 'primeng/fileupload';
import {CalendarModule} from 'primeng/calendar';

import {StoreModule, Store} from '@ngrx/store';
import {EffectsModule} from '@ngrx/effects';
import {RouterStateSerializer, StoreRouterConnectingModule} from '@ngrx/router-store';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import {first} from 'rxjs/operators';

import {ClickOutsideModule} from 'ng-click-outside';
import {AngularSplitModule} from 'angular-split';
import {NgPipesModule} from 'ngx-pipes';
import {CookieService} from 'ngx-cookie-service';
import {NgIdleModule} from '@ng-idle/core';

import {AppComponent} from '@inzicht/app.component';
import {InzichtRoutingModule} from '@inzicht/app-routing.module';
import {FocusDirective} from '@inzicht/directives/focus.directive';
import {AutofocusDirective} from '@inzicht/directives/autofocus.directive';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import {LoggedInGuard} from '@inzicht/components/login/logged-in.guard';
import {NotificationListComponent} from '@inzicht/components/notification-list/notification-list.component';

import * as widgets from '@inzicht/widgettypes/index';
import * as components from '@inzicht/components/index';
import * as services from '@inzicht/services/index';
import * as pipes from '@inzicht/pipes/index';
import * as fromInzichtStore from '@inzicht/store/index';
import {ChartService} from '@inzicht/commons/chart.service';
import {ExcelExportUtil} from '@inzicht/commons/excel-export-util';
import {SubjectIconProvider} from '@inzicht/commons/subject-icon-provider';

// the second parameter 'nl' is optional
registerLocaleData(localeNl, 'nl');

// expand NGRX Store with a synchronized select method
// TODO: Duplicate code (app.module.ts AND test.ts)
// TODO: Is this the right place? Investigate other import/declaration options
declare module '@ngrx/store/src/store' {
  interface Store<T> {
    selectSync<K = any>(selector: any, props?: any): K;
  }
}

function selectSync<K = any>(selector: any, props?: any): K {
  let value;

  this.select(selector, props).pipe(first()).subscribe(val => {
    value = val;
  });

  return value;
}

Store.prototype.selectSync = selectSync;

// declare the app module
@NgModule({
  declarations: [
    AppComponent,
    FocusDirective,
    AutofocusDirective,
    ...components.list,
    ...widgets.list,
    ...pipes.list,
    NotificationListComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    InzichtRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AngularSplitModule,
    NgPipesModule,
    ClickOutsideModule,
    BrowserAnimationsModule,
    ButtonModule,
    CheckboxModule,
    DropdownModule,
    InputSwitchModule,
    MultiSelectModule,
    ToggleButtonModule,
    TableModule,
    PaginatorModule,
    AccordionModule,
    RadioButtonModule,
    OverlayPanelModule,
    BreadcrumbModule,
    SidebarModule,
    MegaMenuModule,
    DialogModule,
    BreadcrumbModule,
    PanelMenuModule,
    TooltipModule,
    FileUploadModule,
    CalendarModule,
    InputTextModule,
    StoreModule.forRoot(fromInzichtStore.reducers),
    // StoreModule.forFeature('inzichtStore', fromInzichtStore.reducers),
    StoreRouterConnectingModule.forRoot(),
    EffectsModule.forRoot([...fromInzichtStore.effects]),
    StoreDevtoolsModule.instrument(),
    NgIdleModule.forRoot()
  ],
  providers: [
    {provide: LOCALE_ID, useValue: 'nl-NL'},
    {provide: RouterStateSerializer, useClass: fromInzichtStore.CustomSerializer},
    ChartService,
    SubjectIconProvider,
    CookieService,
    LoggedInGuard,
    ...services.list,
    ...pipes.list,
    CurrencyPipe,
    DecimalPipe,
    DatePipe,
    PageNavigationUtilService,
    ExcelExportUtil,
    SelectorSideIndicator
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
