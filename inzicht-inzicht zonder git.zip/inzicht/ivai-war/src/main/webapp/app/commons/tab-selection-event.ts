export default class TabSelectionEvent {
  public tab: number;
  public auto: boolean;

  constructor(tab: number, auto: boolean) {
    this.tab = tab;
    this.auto = auto;
  }
}
