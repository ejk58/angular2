import { Injectable } from '@angular/core';
@Injectable()
export class SelectorSideIndicator {

  /**
   * To be able to get a specific piece of state from the store
   * selectors we need to be able to choose a selector name dynamically.
   *
   * indicatedSelectorName method helps to indicate correct selector name with the side that
   * we want to select.
   *
   * Param (side : string) : is the current side that is active.
   * Param (selector: string) : is the base selector name which will be indicated with side param.
   *
   * Example Usage: const side: 'left';
   *
   * indicatedSelectorName(side, 'getActiveDomain'); // returns getActiveDomainLeft
   */
  indicatedSelectorName(side: string, selector: string): string {
    const formattedSide = side ? side.charAt(0).toUpperCase() + side.slice(1) : 'Left';

    return selector + formattedSide;
  }
}
