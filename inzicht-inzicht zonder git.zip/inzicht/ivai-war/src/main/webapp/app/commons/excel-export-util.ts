import {Injectable} from '@angular/core';
import * as XLSX from 'xlsx';

@Injectable()
export class ExcelExportUtil {

  exportToExcel(widgetname, data) {
    const headers = [];
    let sheetName = 'Sheet1';
    if (widgetname != null) {
      sheetName = widgetname.replace(/[\s:]/g, '_');
      if (sheetName.length > 31) {
        sheetName = sheetName.substring(0, 28);
      }
    }

    const fileName = sheetName + '.xlsx';

    /* generate worksheet */
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data.data);
    // Columns
    const cols = data.options.columns;
    const colsStyle = [];
    Object.keys(cols).forEach(key => {
      colsStyle.push({ width: Number(cols[key].columnName.length) + 3 });
      headers.push(cols[key]);
    });
    ws['!cols'] = colsStyle;
    // Header
    for (let headerIndex = 0; headerIndex < headers.length; headerIndex++) {
      const headerCell = {v: headers[headerIndex].label};
      const headerCellRef = XLSX.utils.encode_cell({c: headerIndex, r: 0});
      ws[headerCellRef] = headerCell;
    }
    // Cells
    for (let rowIndex = 0; rowIndex < data.data.length; rowIndex++) {
      for (let columnIndex = 0; columnIndex < headers.length; columnIndex++) {
        const rawContent = data.data[rowIndex][headers[columnIndex].columnName];
        const contentCell = this.createCell(rawContent, headers[columnIndex], rowIndex);
        const contentCellRef = XLSX.utils.encode_cell({c: columnIndex, r: (rowIndex + 1)});
        ws[contentCellRef] = contentCell;
      }
    }
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    /* save to file */
    XLSX.writeFile(wb, fileName);
  }

  createCell(rawContent, columnDefinition, rowIndex) {
    const content = String(rawContent);
    const contentCell = {v: content, t: null, z: null};

    if (!content || content === 'null') {
      contentCell.v = '';
    } else if (columnDefinition.columnType === 'DATE') {
      contentCell.t = 'n';
      const cellDate = new Date(Number(content));
      contentCell.z = 'd-m-yyyy';
      contentCell.v = String(this.datenum(cellDate));
    } else if (columnDefinition.columnType === 'MONEY') {
      contentCell.t = 'n';
    } else {
      contentCell.t = 's';
    }
    return contentCell;
  }

  datenum(cellDate) {
    const epoch = Date.parse(cellDate);
    return (epoch - new Date(1899, 11, 30).getTime()) / (24 * 60 * 60 * 1000);
  }
}
