import * as _ from 'lodash-es';

/**
 * Returns an array filled with each underlying field of the given object.
 *
 * Example:
 * {
 *   homeAddress: {street: 'Homelane', number: 23},
 *   workAddress: {street: 'Workstreet', number: 95}
 * }
 *
 * would become
 *
 * [
 *   {street: 'Homelane', number: 23},
 *   {street: 'Workstreet', number: 95}
 * ]
 * @param object The object you wish to transform into an array
 */
export function objectFieldsAsArray(object: { [key: string]: any }): any[] {
  return Object.keys(object).map(key => object[key]);
}

/**
 * Returns an array filled with each underlying property's value of the given object.
 *
 * Example object:
 * {
 *   homeAddress: {street: 'Homelane', number: 23},
 *   workAddress: {street: 'Workstreet', number: 95}
 * }
 *
 * Example call: objectPropertiesAsArray(obj, 'street');
 *
 * Gives: ['Homelane', Workstreet']
 * @param object The object you wish to transform into an array
 */
export function objectPropertiesAsArray(object: { [key: string]: { [property: string]: any } }, property: string): any[] {
  return Object.keys(object).map(key => object[key][property]);
}

/**
 * Returns whether two objects are considered equal. Two objects are equal if they have the same properties with the same values (no more, no less)
 *
 * Examples:
 *
 * objectEquals({brand: 'Audi', color: 'black'}, {brand: 'Audi', color: 'red'}) will return *false*, because the color property is different.
 *
 * objectEquals({brand: 'Audi', color: 'black'}, {brand: 'Audi', color: 'black', price: 130000}) will return *false*, because the first object does not have a price property and will therefor differ.
 * @param a The first object
 * @param b  The second object
 * @param strongEquality True means the check should use strong equality (===), False means the check should use weak equality (==). Defaults to true.
 */
export function objectEquals(a: { [key: string]: any }, b: { [key: string]: any }, strongEquality: boolean = true): boolean {
  const keyEqualityCheck = strongEquality ? key => a[key] === b[key] : key => a[key] == b[key];
  return [...Object.keys(a), ...Object.keys(b)].every(keyEqualityCheck);
}

/**
 * Get the keys of the differences between two objects.
 *
 */
export function objectUnmatchingKeys(object1: any, object2: any): string[] {
  const keys = [...Object.keys(object1), ...Object.keys(object2)];
  return keys.filter(key => !object1.hasOwnProperty(key) || !object2.hasOwnProperty(key) || !_.isEqual(object1[key], object2[key]));
}

/**
 * Groups entries of an array by a shared key.
 *
 * Example:
 * const cars = [
 *  {brand: 'Audi', color: 'black'},
 *  {brand: 'Mercedes', color: 'black'},
 *  {brand: 'Audi', color: 'red'}
 * ]
 *
 * Example call:
 * const carsByColor = groupby(cars, 'color');
 *
 * Results in:
 * Map{
 * 'black': [{brand: 'Audi', color: 'black'}, {brand: 'Mercedes', color: 'black'}],
 * 'red': [{brand: 'Audi', color: 'red'}]
 * }
 */
export function groupBy<T>(array: T[], key: keyof T): Map<any, T[]> {
  return array.reduce((map, obj) => {
    const value = obj[key];
    map.set(value, (map.get(value) || []).concat([obj]));
    return map;
  }, new Map());
}

/**
 * The padStart() method pads the current string with another string (multiple times, if needed) until the resulting string reaches the given length.
 * The padding is applied from the start (left) of the current string.
 * This implementation is based on the String.prototype.padStart polyfill.
 * @param source The source string you'd wish to pad
 * @param targetLength The length of the resulting string once the current string has been padded.
 *        If the value is less than the current string's length, the current string is returned as is.
 * @param padString The string to pad the current string with. If this padding string is too long to stay within the targetLength,
 *        it will be truncated from the right. The default value is " " (U+0020 'SPACE').
 */
export function padStart(source: number | string, targetLength: number, padString: string = ' '): string {
  source = String(source);
  if (source.length >= targetLength) {
    return source;
  } else {
    const diff = targetLength - source.length;
    if (diff > padString.length) {
      padString += padString.repeat(diff / padString.length); // append to original to ensure we are longer than needed
    }
    return padString.slice(0, diff) + String(source);
  }
}

/** The document service we use to get links to documents gives invalid url's which we have to correct before using them. (issue IVAI-9741).
 *  It is not common to do this and normally this is only done on the url parameters or their values.
 *
 * @param url The url string you'd wish to encode the last segment of.
 *
 *  example:
 *  input = https://www.belastingdienst.nl/fncmis/resources/IdMet#.pdf.pdf
 *  output = https://www.belastingdienst.nl/fncmis/resources/IdMet%23.pdf.pdf
 */
export function encodeLastUriSegment(url: string): string {
  const lastSlashIndex = url.lastIndexOf('/');
  const lastSegment = url.substr(lastSlashIndex + 1);
  // minimum of 3 time / and at least one character after last / and no url parameters, i.e. no ? or =
  if (((url.match(/\//g) || []).length > 2) && (url.length > lastSlashIndex + 1) && lastSegment.indexOf('?') === -1 && lastSegment.indexOf('=') === -1) {
    return url.substr(0, lastSlashIndex + 1) + encodeURIComponent(lastSegment);
  }
  return url;
}

function dateToParts(date: Date): {dd: string, mm: string, yyyy: string} {
  const day = date.getDate();
  const dd = (day < 10) ? `0${day}` : `${day}`;

  const month = date.getMonth() + 1;
  const mm = (month < 10) ? `0${month}` : `${month}`;

  const yyyy = `${date.getFullYear()}`;

  return {dd, mm, yyyy};
}

export function dateToDdMmYyyy(date: Date): string {
  const { dd, mm, yyyy } = dateToParts(date);
  return `${dd}-${mm}-${yyyy}`;
}
export function dateToYyyyMmDd(date: Date): string {
  const { dd, mm, yyyy } = dateToParts(date);
  return `${yyyy}-${mm}-${dd}`;
}

export function yyyyMmDdToDate(dateString: string): Date {
  const parts: number[] = dateString.split('-').map(Number);
  return new Date(parts[0], parts[1] - 1, parts[2]);
}

export function matchToYyyyMmDd(dateString: string): boolean {
  const pattern = /^[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]$/;
  return pattern.test(dateString);
}

export function sanitizeSelector(selector: string): string {
  if (selector == null || selector.length === 0) {
    return selector;
  } else {
    return ('' + selector).replace(/\s/g, '');
  }
}

export function makeHyphensNonBreaking(content: string): string {
  const nonBreakingSpace = String.fromCharCode(8209);
  return !content ? content : content.replace(/-/g, nonBreakingSpace);
}
