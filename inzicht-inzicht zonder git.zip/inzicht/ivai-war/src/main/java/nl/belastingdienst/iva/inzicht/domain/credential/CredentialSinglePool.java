package nl.belastingdienst.iva.inzicht.domain.credential;

public class CredentialSinglePool implements CredentialPool {

    private Credential credential;
    
    public CredentialSinglePool(Credential credential) {
        this.credential = credential;
    }
    
    @Override
    public Credential getCredential() {
        return this.credential;
    }
}
