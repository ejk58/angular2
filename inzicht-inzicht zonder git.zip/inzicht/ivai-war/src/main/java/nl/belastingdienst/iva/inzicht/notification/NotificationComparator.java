package nl.belastingdienst.iva.inzicht.notification;

import java.util.Comparator;

import nl.belastingdienst.iva.inzicht.database.notification.Notification;

public class NotificationComparator implements Comparator<Notification> {

	private static final int DEFAULTPRIORITY = 0;
	
	@Override
	public int compare(Notification notification, Notification otherNotification) {
		int priority = notification.getPriority() == null ? DEFAULTPRIORITY : notification.getPriority();
		int otherPriority = otherNotification.getPriority() == null ? DEFAULTPRIORITY : otherNotification.getPriority();
		return priority - otherPriority;
	}
}
