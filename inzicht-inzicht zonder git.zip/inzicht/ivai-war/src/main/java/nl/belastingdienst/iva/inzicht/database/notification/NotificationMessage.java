package nl.belastingdienst.iva.inzicht.database.notification;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "NOTIFICATION_MESSAGE")
public class NotificationMessage {

  @Id
  @Column(name = "id")
  private Integer id;

  @Column(name = "message")
  private String message;

  @Column(name = "type")
  private String type;

  public String getMessage() {
    return this.message;
  }

  public String getType() {
    return this.type;
  }
}
