package nl.belastingdienst.iva.inzicht.database.configuration.attribute;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_ATTRIBUTE_GROUP")
@NamedQuery(name = AttributeGroup.QUERY_GETATTRIBUTEGROUPS, query = "SELECT a FROM AttributeGroup a ORDER BY a.key")
public class AttributeGroup {

	public static final String QUERY_GETATTRIBUTEGROUPS = "AttributeGroup.getAttributeGroups";
	
	@Id
	private Integer id;
	
	private String key;
	
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "ATTRIBUTE_GROUP_ID")
    @OrderBy("index ASC")
    private List<Attribute> attributeList;

	public Integer getId() {
		return this.id;
	}

	public String getKey() {
		return this.key;
	}

	public List<Attribute> getAttributeList() {
		return Collections.unmodifiableList(this.attributeList);
	}
	
	public Map<String, String> getAttributeMap() {
		Map<String, String> attributeMap = new HashMap<>();
		
		for (Attribute attribute : this.attributeList) {
			attributeMap.put(attribute.getKey(), attribute.getValue());
		}
		
		return attributeMap;
	}
}
