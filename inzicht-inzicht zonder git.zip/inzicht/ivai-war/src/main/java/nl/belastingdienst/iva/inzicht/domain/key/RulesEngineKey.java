package nl.belastingdienst.iva.inzicht.domain.key;

public class RulesEngineKey {

    public static final String RULEOPERATOR = "->";

    public static final String ACTIONOPERATOR = "+";

    public static final String ANDCONDITIONOPERATOR = "&";
    public static final String ORCONDITIONOPERATOR = "|";
    public static final String NOTCONDITIONOPERATOR = "!";
    
    public static final String GROUPSTART = "[";
    public static final String GROUPEND = "]";

    public static final String PARAMETERSTART = "(";
    public static final String PARAMETEREND = ")";
    public static final String PARAMETERSEPARATOR = ",";
    
    private RulesEngineKey() {
        throw new UnsupportedOperationException();
    }
}
