package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class AddQueryValueAction implements Action {

	public static final String NAME = "AddQueryValue";

	private String key;
	private String value;
	
	public AddQueryValueAction(String key, String value) {
		this.key = key;
		this.value = value;
	}
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
		restCallContext.addQueryValue(this.key, this.value);
		return Flow.CONTINUE;
	}
	
	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.key + 
				(this.value == null ? "" : RulesEngineKey.PARAMETERSEPARATOR + this.value) + RulesEngineKey.PARAMETEREND;
	}
}
