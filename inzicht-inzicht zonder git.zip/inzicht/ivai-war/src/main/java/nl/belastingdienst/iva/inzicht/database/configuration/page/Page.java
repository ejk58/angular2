package nl.belastingdienst.iva.inzicht.database.configuration.page;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;

@Entity
@Table(name = "CONF_PAGE")
@NamedQuery(name = Page.QUERY_GETPAGES, query = "SELECT p FROM Page p " +
		"LEFT JOIN FETCH p.query " +
		"LEFT JOIN FETCH p.pageColumns " +
		"LEFT JOIN FETCH p.attributeList " +
		"ORDER BY p.key")
public class Page {

	public static final String QUERY_GETPAGES = "Page.getPages";
	
	@Id
	private Integer id;
	private String key;
	private String title;
	private String type;
	
	@OneToOne(fetch = FetchType.EAGER)
	private Query query;

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "PAGE_ID")
	private List<PageDomain> pageDomains = new ArrayList<>();

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "PAGE_ID")
	@OrderBy(value = "index")
	private List<PageColumn> pageColumns = new ArrayList<>();

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "PAGE_ID")
	@OrderBy(value = "rowIndex, columnIndex")
	private List<PageWidget> pageWidgets = new ArrayList<>();

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "PAGE_ID")
	@OrderBy(value = "key")
	private List<PageAttribute> attributeList;
	
	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "PAGE_ID")
	@OrderBy(value = "name")
	private List<PagePathKey> mandatoryPathKeys = new ArrayList<>();

	@Transient
	private List<Domain> linkedDomains;

	public Integer getId() {
		return id;
	}

	public String getKey() {
		return key;
	}

	public String getTitle() {
		return title;
	}

	public String getType() {
		return type;
	}
	
	public List<PagePathKey> getMandatoryPathKeys() {
		return mandatoryPathKeys;
	}

	public Query getQuery() {
		return query;
	}

	public List<PageDomain> getPageDomains() {
		return Collections.unmodifiableList(pageDomains);
	}

	public List<PageColumn> getPageColumns() {
		return Collections.unmodifiableList(pageColumns);
	}

	public List<PageWidget> getPageWidgets() {
		return Collections.unmodifiableList(pageWidgets);
	}

	public List<PageAttribute> getAttributeList() {
		return this.attributeList;
	}

	public List<Domain> getLinkedDomains() {
		return this.linkedDomains == null ? Collections.<Domain> emptyList() : Collections.unmodifiableList(this.linkedDomains);
	}

	public void linkDomain(Domain domain) {
		if (this.linkedDomains == null) {
			this.linkedDomains = new ArrayList<>();
		}

		if (!this.linkedDomains.contains(domain)) {
			this.linkedDomains.add(domain);
		}

		for (PageWidget pageWidget : this.pageWidgets) {
			Widget widget = pageWidget.getWidget();
			widget.linkDomain(domain);
		}
	}
}
