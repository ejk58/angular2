package nl.belastingdienst.iva.inzicht.database.configuration.widget;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;

@Entity
@Table(name = "CONF_WIDGET_COLUMN")
public class WidgetColumn {

    @Id
    private int id;

    private int index;
    private String type;
    private String label;
    private String description;
    private String behaviour;
    private String filter;

    @OneToOne
    @JoinColumn(name = "QUERY_COLUMN_ID")
    private QueryColumn queryColumn;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "WIDGET_COLUMN_ID")
    private List<WidgetColumnAttribute> columnAttributes;

    @JsonIgnore
    public int getId() {
        return id;
    }

    public int getIndex() {
        return index;
    }

    public String getType() {
        return type;
    }
    
    public String getLabel() {
        return label;
    }

    public String getDescription() {
        return description;
    }

    public String getBehaviour() {
    	return this.behaviour;
    }
    
    public String getFilter() {
    	return this.filter;
    }
    
    public QueryColumn getQueryColumn() {
        return queryColumn;
    }
    
    public List<WidgetColumnAttribute> getColumnAttributes() {
    	return columnAttributes;
    }
}
