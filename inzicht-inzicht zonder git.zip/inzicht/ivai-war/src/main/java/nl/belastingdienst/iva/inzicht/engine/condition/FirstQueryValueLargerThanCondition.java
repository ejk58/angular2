package nl.belastingdienst.iva.inzicht.engine.condition;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.lang3.StringUtils;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class FirstQueryValueLargerThanCondition implements Condition {

	public static final String NAME = "FirstQueryValueLargerThan";
	
	private String queryValueKey;
	private int value;
	
	public FirstQueryValueLargerThanCondition(String queryValueKey, String value) {
		this.queryValueKey = queryValueKey;
		this.value = Integer.parseInt(value);
	}
	
	@Override
	public boolean test(RestCallContext restCallContext) {
		MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
		String queryValue = queryValues.getFirst(this.queryValueKey);
		return (StringUtils.isNotEmpty(queryValue) && StringUtils.isNumeric(queryValue) && Integer.parseInt(queryValue) > this.value);
	}

	@Override
	public String getCondition() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.queryValueKey + RulesEngineKey.PARAMETERSEPARATOR + this.value + RulesEngineKey.PARAMETEREND;
	}
}
