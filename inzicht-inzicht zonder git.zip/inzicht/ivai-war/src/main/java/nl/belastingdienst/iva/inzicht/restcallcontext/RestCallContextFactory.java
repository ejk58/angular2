package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotFoundException;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.User;

public class RestCallContextFactory {

    public RestCallContext getRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration, User user) {
    	RestServiceType restServiceType = serviceType != null ? serviceType : RestServiceType.NONE;
    	long beginTime = System.currentTimeMillis();
        return user == null ? 
        		buildUnauthenticatedRestCallContext(restServiceType, queryValues, configuration, beginTime) :
        		buildDefaultRestCallContext(restServiceType, queryValues, configuration, user, beginTime);
    }

    public RestCallContext getRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration) {
    	RestServiceType restServiceType = serviceType != null ? serviceType : RestServiceType.NONE;
    	long beginTime = System.currentTimeMillis();
        return buildUnauthenticatedRestCallContext(restServiceType, queryValues, configuration, beginTime);
    }

    public RestCallContext getRestCallContext(RestCallContext restCallContext, MultivaluedMap<String, String> queryValues) {
        long beginTime = restCallContext.getBeginTime();
        RestServiceType restServiceType = restCallContext.getServiceType();
        Configuration configuration = restCallContext.getConfiguration();
        User user = restCallContext.getUser();
        return buildDefaultRestCallContext(restServiceType, queryValues, configuration, user, beginTime);
    }
    
    public RestCallContext getRestCallContext(RestCallContext restCallContext) {
    	MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        return getRestCallContext(restCallContext, queryValues);
    }
    
    private RestCallContext buildDefaultRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, 
    		Configuration configuration, User user, long beginTime) {
    	RestServiceType restServiceType = serviceType != null ? serviceType : RestServiceType.NONE;
        List<DomainRole> authorizedRoles = determineAuthorizedRoles(queryValues, configuration);
        MultivaluedMap<String, String> restQueryValues = filterUndefinedQueryValues(queryValues);
        return new DefaultRestCallContext(restServiceType, restQueryValues, configuration, user, authorizedRoles, beginTime);
    }

    private RestCallContext buildUnauthenticatedRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, 
    		Configuration configuration, long beginTime) {
    	RestServiceType restServiceType = serviceType != null ? serviceType : RestServiceType.NONE;
        MultivaluedMap<String, String> restQueryValues = filterUndefinedQueryValues(queryValues);
        return new UnauthenticatedRestCallContext(restServiceType, restQueryValues, configuration, beginTime);
    }

    private MultivaluedMap<String, String> filterUndefinedQueryValues(MultivaluedMap<String, String> queryValues) {
    	MultivaluedMap<String, String> restQueryValues = new MultiValuedHashMap<>();

    	queryValues.entrySet().stream()
    			.filter(entry -> entry.getValue() != null && !entry.getValue().isEmpty() && !DomainUtils.isUndefined(entry.getValue().get(0)))
    			.forEach(entry -> restQueryValues.put(entry.getKey(), entry.getValue()));
    	
    	return restQueryValues;
    }
    
    private List<DomainRole> determineAuthorizedRoles(MultivaluedMap<String, String> queryValues, Configuration configuration) {
        Set<Domain> relatedDomains = determineLinkedViews(queryValues, configuration);
        Set<DomainRole> roles = new HashSet<>();
        
        for (Domain relatedDomain : relatedDomains) {
            roles.addAll(relatedDomain.getRoles());
        }

        return new ArrayList<>(roles);
    }

    private Set<Domain> determineLinkedViews(MultivaluedMap<String, String> queryValues, Configuration configuration) {
        Set<Domain> linkedDomains = null;

        if (queryValues.containsKey(QueryValueKey.DOMAINKEY)) {
        	linkedDomains = merge(linkedDomains, findDomain(queryValues.getFirst(QueryValueKey.DOMAINKEY), configuration));
        }
        
        if (queryValues.containsKey(QueryValueKey.PAGEKEY)) {
        	linkedDomains = merge(linkedDomains, findLinkedDomainsForPage(queryValues.getFirst(QueryValueKey.PAGEKEY), configuration));
        }
        
        if (queryValues.containsKey(QueryValueKey.WIDGETKEY)) {
        	linkedDomains = merge(linkedDomains, findLinkedDomainsForWidget(queryValues.getFirst(QueryValueKey.WIDGETKEY), configuration));
        }
        
        return linkedDomains == null ? Collections.<Domain>emptySet() : linkedDomains;
    }

    private Set<Domain> merge(Set<Domain> domainSet, Set<Domain> newDomainSet) {
    	if (domainSet == null) {
    		domainSet = newDomainSet; 
    	} else {
    		domainSet.retainAll(newDomainSet);
    	}
    	
    	return domainSet;
    }
    
    private Set<Domain> findDomain(String domainKey, Configuration configuration) {
        Domain domain = checkUnfoundItem("domain", domainKey, configuration.findDomain(domainKey));
        Set<Domain> domainSet = new HashSet<>();
        domainSet.add(domain);
        return domainSet;
    }
    
    private Set<Domain> findLinkedDomainsForPage(String pageKey, Configuration configuration) {
        Page page = checkUnfoundItem("page", pageKey, configuration.findPage(pageKey));
        return new HashSet<>(page.getLinkedDomains());
    }

    private Set<Domain> findLinkedDomainsForWidget(String widgetKey, Configuration configuration) {
        Widget widget = checkUnfoundItem("widget", widgetKey, configuration.findWidget(widgetKey));
        return new HashSet<>(widget.getLinkedDomains());
    }

    private <T> T checkUnfoundItem(String item, String key, T value) {
        if (value == null) {
            throw (key == null || DomainUtils.isUndefined(key)) ? 
            	    new BadRequestException("The " + item + " " + key + " is not defined.") :
            	    new NotFoundException("The " + item + " " + key + " is not found.");
        }
        
        return value;
    }
}
