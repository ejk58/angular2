package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class LoadWidgetQueryAction implements Action {

	public static final String NAME = "LoadWidgetQuery";
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
        Widget widget = restCallContext.findWidget();
        Query query = widget.getQuery();
        restCallContext.setQuery(query);
        return Flow.CONTINUE;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + RulesEngineKey.PARAMETEREND;
	}
}
