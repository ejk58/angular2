package nl.belastingdienst.iva.inzicht.jira;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractHttpServiceClient;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.JsonMapper;
import nl.belastingdienst.iva.inzicht.domain.Version;
import nl.belastingdienst.iva.inzicht.domain.datasource.HttpDatasource;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.jira.Attachment;
import nl.belastingdienst.iva.inzicht.domain.jira.Feedback;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class JiraFeedbackClient extends AbstractHttpServiceClient {
	
	private static final String DATASOURCENAME = "Jira rest-service";
	
	@Inject
	private JsonMapper jsonMapper;
	
	@Inject
	private JiraIssueMapper jiraIssueMapper;
	
	public void post(Feedback feedback, List<Attachment> attachments, RestCallContext restCallContext) {
		submitFeedback(feedback, restCallContext);
		submitAllAttachments(attachments, restCallContext);
	}
	
	public void submitFeedback(Feedback feedback, RestCallContext restCallContext) {
		validateFeedback(feedback);
		DataMap jiraIssue = createIssue(feedback, restCallContext);
		submitJiraIssue(jiraIssue, restCallContext);	
	}
	
	public void submitAllAttachments(List<Attachment> attachments, RestCallContext restCallContext) {
		attachments.stream().forEach(attachment -> submitAttachment(attachment, restCallContext));
	}
	
    @Override
	public void handleHttpStatusCode(HttpResponse response, String datasourceName, String requestDescription) {
		int statusCode = response.getStatusLine().getStatusCode();
		
		if (statusCode == 401) {
			String message = "Failed to authorize for the Jira environment or given project with status code 401 " + requestDescription;
			throw new InternalServerErrorException(message);
 		} else if (statusCode >= 400) {
			try {
				String jiraErrorResponse = EntityUtils.toString(response.getEntity());
				String message = "Received status code " + statusCode + " while submitting Jira-issue: " + 
						((jiraErrorResponse != null && !DomainUtils.EMPTY_ITEM.equals(jiraErrorResponse)) ? jiraErrorResponse : "<no response from server>") +
						" " + requestDescription;
				throw new BadGatewayException(message);
			} catch (IOException exception) {
				String message = "Received status code " + statusCode + " while submitting Jira-issue and failed to parse the error response " +
						requestDescription;
				throw new BadGatewayException(message);
			}
		}
	}
    
	private DataMap createIssue(Feedback feedback, RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
        String userName = restCallContext.getUserName();
        String environment = configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKENVIRONMENT);
		
        feedback.setUsername(userName);
        feedback.setVersion(Version.INSTANCE.getVersion());
        feedback.setCreated(new Date());
        feedback.setSummary(environment + ": Te beoordelen");
    	
		return this.jiraIssueMapper.map(feedback, configuration);		
	}
	
	private void submitJiraIssue(DataMap jiraIssue, RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
        HttpDatasource jiraFeedbackDatasource = configuration.getJiraFeedbackDatasource();
		String restUrl = getIssueRestUrl(jiraFeedbackDatasource);
        String requestDescription = "(Jira-issue-url = '" + restUrl + "')";
      	String jsonIssue = convertJiraIssue(jiraIssue);

      	CloseableHttpClient httpClient = jiraFeedbackDatasource.getHttpClient();
        HttpPost httpPost = createPostRequest(jiraFeedbackDatasource, restUrl, jsonIssue, null);

        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
        	handleHttpStatusCode(response, DATASOURCENAME, requestDescription);
        	extractIssueKeyFromResponse(response, restCallContext);
        } catch (IOException exception) {
        	handleException(exception, DATASOURCENAME, requestDescription);
        }
	}

	private void submitAttachment(Attachment attachment, RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
		HttpDatasource jiraFeedbackDatasource = configuration.getJiraFeedbackDatasource();
		String restUrl = getAttachmentRestUrl(jiraFeedbackDatasource, restCallContext);
        String requestDescription = "(Jira-attachment-url = '" + restUrl + 
        		"', file = '" + attachment.getFilename() + 
        		"', contentType = '" + attachment.getContentType() + "')";
        HttpEntity entity = MultipartEntityBuilder.create()
        		.setMode(HttpMultipartMode.BROWSER_COMPATIBLE)
        		.addPart("file", new InputStreamBody(attachment.getInputStream(), attachment.getFilename()))
        		.build();
        
        CloseableHttpClient httpClient = jiraFeedbackDatasource.getHttpClient();
        HttpPost httpPost = createPostRequest(jiraFeedbackDatasource, restUrl, entity, null);
        httpPost.setHeader("X-Atlassian-Token", "nocheck");
        
        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
        	handleHttpStatusCode(response, DATASOURCENAME, requestDescription);
        } catch (IOException exception) {
        	handleException(exception, DATASOURCENAME, requestDescription);
        }
	}
	
    private void validateFeedback(Feedback feedback) {
    	if (feedback.getDomainId() == null) {
    		throw new BadRequestException("The feedback is invalid with a missing domain");
    	}
    }
    
    private void extractIssueKeyFromResponse(HttpResponse response, RestCallContext restCallContext) {
    	try {
        	HttpEntity entity = response.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			DataMap responseMap = this.jsonMapper.mapToObject("Jira rest-call response (on create issue)", DataHashMap.class, responseString);
			restCallContext.addQueryValue(QueryValueKey.JIRAISSUEKEY, responseMap.getAsString("key"));
			
		} catch (IOException e) {
			String message = "Failed to parse the Jira-response to obtain the issue-key";
			throw new BadGatewayException(message);
		}
    }
    
    private String getIssueRestUrl(HttpDatasource jiraFeedbackDatasource) {
		String restUrl = jiraFeedbackDatasource.getValue(DatasourceKey.RESTURL);
		return restUrl + "/api/2/issue";
    }
    
    private String getAttachmentRestUrl(HttpDatasource jiraFeedbackDatasource, RestCallContext restCallContext) {
		String restUrl = jiraFeedbackDatasource.getValue(DatasourceKey.RESTURL);
		String issueKey = restCallContext.getFirstQueryValue(QueryValueKey.JIRAISSUEKEY);
		return restUrl + "/api/2/issue/" + issueKey + "/attachments";
    }
    
    private String convertJiraIssue(DataMap jiraIssue) {
    	return this.jsonMapper.mapToJsonString("Jira-issue (from feedback)", jiraIssue);
    }
}
