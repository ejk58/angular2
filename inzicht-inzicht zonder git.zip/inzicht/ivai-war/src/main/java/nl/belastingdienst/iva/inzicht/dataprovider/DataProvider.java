package nl.belastingdienst.iva.inzicht.dataprovider;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryFilter;
import nl.belastingdienst.iva.inzicht.database.configuration.query.ResultMapper;
import nl.belastingdienst.iva.inzicht.dataprovider.db2.Db2Client;
import nl.belastingdienst.iva.inzicht.dataprovider.internal.InternalClient;
import nl.belastingdienst.iva.inzicht.dataprovider.rest.RestServiceClient;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataClient;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotAuthorizedException;
import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.domain.permission.VipUtils;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;
import nl.belastingdienst.iva.inzicht.permission.PermissionFactory;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

public class DataProvider {

    @Inject
    private InternalClient internalClient;

    @Inject
    private TeradataClient teradataClient;

    @Inject
    private Db2Client db2Client;

    @Inject
    private RestServiceClient restServiceClient;
    
    @Inject
    private PermissionFactory permissionFactory;
    
    private Map<QueryType, DataProviderClient> clientMap;
    
    @PostConstruct
    private void initializeClientMap() {
        this.clientMap = new EnumMap<>(QueryType.class);

        this.clientMap.put(QueryType.INTERNAL, this.internalClient);
        this.clientMap.put(QueryType.TERADATA, this.teradataClient);
        this.clientMap.put(QueryType.DB2, this.db2Client);
        this.clientMap.put(QueryType.REST, this.restServiceClient);
    }

    public Result retrieveData(QueryInterface query, RestCallContext restCallContext) {
        
        if (query != null) {
            checkRequiredRoles(query, restCallContext);
            checkRequiredPermission(query, restCallContext);
            retrieveResult(query, restCallContext);
            mapResult(query, restCallContext);
            processVipInformation(query, restCallContext);
        } else {
        	setEmptyResult(restCallContext);
        }
        
        return restCallContext.getResult();
    }

    private void checkRequiredRoles(QueryInterface query, RestCallContext restCallContext) {
        if (!RoleUtils.isAuthorizedUser(restCallContext)) {
            throw new NotAuthorizedException("The user lacks a role (" + restCallContext.getAuthorizedRoles() + 
                    ") for a domain that is linked to the query " + query.getKey());
        }
    }

    private void checkRequiredPermission(QueryInterface query, RestCallContext restCallContext) {
    	List<QueryFilter> queryFilters = query.getQueryFilters();
    	String queryKey = query.getKey();
    	
    	analyzeQueryElement(queryKey, query.getQueryTemplate(), restCallContext);

    	for (QueryFilter queryFilter : queryFilters) {
    		analyzeQueryElement(queryKey, queryFilter.getFilterTemplate(), restCallContext);
    		analyzeQueryElement(queryKey, queryFilter.getNoFilterTemplate(), restCallContext);
    	}
    }
    
    private void analyzeQueryElement(String queryKey, String queryElement, RestCallContext restCallContext) {
    	if (queryElement != null) {
	        Matcher matcher = QueryUtils.PATTERN_ANYPARAMETER.matcher(queryElement);
	
	        while (matcher.find()) {
	            String parameter = matcher.group();
	            String parameterName = QueryUtils.extractParameterName(parameter);
	            String parameterValue = restCallContext.getFirstQueryValue(parameterName);
	            QueryParameterType parameterType = QueryUtils.extractParameterType(parameter);
	            
	            if (parameterType == null) {
	            	String message = "The type of the parameter '" + parameter + "' in query " + queryKey + " is not recognized.";
	            	throw new InternalServerErrorException(message);
	            }
	            
	            if (!this.permissionFactory.getAccess(restCallContext, parameterType, parameterValue)) {
	            	String message = "The user has no permission to access the data associated with a " + parameterName + 
	                		"(" + parameterType.getName() + ") value of '" + parameterValue + "' with the query " + queryKey + ".";
	                throw new NotAuthorizedException(message);
	            }
	        }
    	}
    }
    
    private void retrieveResult(QueryInterface query, RestCallContext restCallContext) {
        DataProviderClient client = this.clientMap.get(query.getType());
    	Result result = client.retrieveData(query, restCallContext);
    	restCallContext.setResult(result);
    }
    
    private void setEmptyResult(RestCallContext restCallContext) {
        restCallContext.setResult(DomainUtils.emptyResult());
    }
    
    private void mapResult(QueryInterface query, RestCallContext restCallContext) {
    	Result result = restCallContext.getResult();
        ResultMapper resultMapper = query.getResultMapper();
    	List<DataMap> data = result.getData();
        result.setData(resultMapper.map(data));
    }

    private void processVipInformation(QueryInterface query, RestCallContext restCallContext) {
    	if (query.getVipFilterColumnKey() != null) {
            filterVipInformation(query, restCallContext);
        }
        
        if (query.getVipMaskColumnKey() != null) {
            maskVipInformation(query, restCallContext);
        } else if (!query.getMaskableColumnKeys().isEmpty()) {
            maskVipInformationFromData(query, restCallContext);
        } 
        
        if (query.getVipTagColumnKey() != null) {
            tagVipInformation(query, restCallContext);
        }
    }
    
    private void filterVipInformation(QueryInterface query, RestCallContext restCallContext) {
    	Result result = restCallContext.getResult();
    	List<DataMap> data = result.getData();
        String vipFilterColumnKey = query.getVipFilterColumnKey();
        List<DataMap> dataRows = new ArrayList<>();
        
        for (DataMap dataMap : data) {
            String fiscalNr = dataMap.getAsString(vipFilterColumnKey);
            boolean access = this.permissionFactory.getAccess(restCallContext, fiscalNr);
            if (access) {
            	dataRows.add(dataMap);
            }
        }
        
        result.setData(DomainUtils.inArray(dataRows));
    }
    
    private void maskVipInformation(QueryInterface query, RestCallContext restCallContext) {
    	Result result = restCallContext.getResult();
    	List<DataMap> data = result.getData();
        String vipMaskColumnKey = query.getVipMaskColumnKey();
        List<String> maskableColumnKeys = query.getMaskableColumnKeys();
        List<DataMap> dataRows = new ArrayList<>();
        
        for (DataMap dataMap : data) {
            String fiscalNr = dataMap.getAsString(vipMaskColumnKey);
            boolean access = this.permissionFactory.getAccess(restCallContext, fiscalNr);
            if (!access) {
                for (String columnKey : maskableColumnKeys) {
                    dataMap.put(columnKey, VipUtils.VIP_MASK);
                }
            }
            dataRows.add(dataMap);
        }
        
        result.setData(dataRows);
    }
    
    private void tagVipInformation(QueryInterface query, RestCallContext restCallContext) {
    	Result result = restCallContext.getResult();
    	List<DataMap> data = result.getData();
        String vipTagColumnKey = query.getVipTagColumnKey();
        List<DataMap> dataRows = new ArrayList<>();
        
        for (DataMap dataMap : data) {
            String fiscalNr = dataMap.getAsString(vipTagColumnKey);
            Permission permission = this.permissionFactory.getPermission(restCallContext, fiscalNr);
            dataMap.put(vipTagColumnKey, permission);

            dataRows.add(dataMap);
        }
        
        result.setData(dataRows);
    }
    
    private void maskVipInformationFromData(QueryInterface query, RestCallContext restCallContext) {
    	Result result = restCallContext.getResult();
        boolean vipUser = RoleUtils.isVipUser(restCallContext);
        List<DataMap> dataRows = result.getData();

        if (!vipUser) {
            List<String> columnKeys = query.getMaskableColumnKeys();
            
            for (DataMap dataMap : dataRows) {
                if (VipUtils.detectVipMaskRow(dataMap)) {
                    for (String columnKey : columnKeys) {
                        dataMap.put(columnKey, VipUtils.VIP_MASK);
                    }
                }
            }
        }
    	
        result.setData(dataRows);
    }
}
