package nl.belastingdienst.iva.inzicht.domain.datasource;

import java.util.Map;

import nl.belastingdienst.iva.inzicht.domain.credential.Credential;

public interface Datasource {

    DatasourceType getType();
    String getKey();
    Map<String, String> getParameterMap();
    Credential getCredential();
    String getValue(String key);
    Integer getNumber(String key);
    boolean getBoolean(String key);
}
