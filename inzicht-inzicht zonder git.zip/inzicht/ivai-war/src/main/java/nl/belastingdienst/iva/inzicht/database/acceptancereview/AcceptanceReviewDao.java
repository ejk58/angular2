package nl.belastingdienst.iva.inzicht.database.acceptancereview;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import nl.belastingdienst.iva.inzicht.domain.Version;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class AcceptanceReviewDao {

	@PersistenceContext(unitName = "ivai-pu-inzicht")
	private EntityManager entityManager;
	
	public void saveAcceptanceReview(AcceptanceReview acceptanceReview, RestCallContext restCallContext) {
		try {
	    	acceptanceReview.setUsername(restCallContext.getUserName());
			acceptanceReview.setCreated(new Date());
			acceptanceReview.setVersion(Version.INSTANCE.getVersion());

			this.entityManager.persist(acceptanceReview);
		} catch (PersistenceException exception) {
			String message = "Failed to save an acceptance review (" + acceptanceReview + ") to the database with exception " + 
					exception.getClass() + ": " + exception.getMessage() + "."; 
			throw new InternalServerErrorException(message);
		}
	}
}
