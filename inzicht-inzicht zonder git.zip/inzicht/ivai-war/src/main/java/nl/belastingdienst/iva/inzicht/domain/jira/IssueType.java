package nl.belastingdienst.iva.inzicht.domain.jira;

public enum IssueType {
	EPIC("10000", false),
	STORY("10001", true),
	PROBLEM("10100", true),
	SUBTASK("10101", true),
	IMPROVEMENT("10102", true),
	TASK("10103", true),
	CUSTOMER_REQUEST("10104", true),
	WORKORDER("10105", true),
	BUG("10106", false),
	INCIDENT("10107", true);
	
	private String id;
	private boolean epicLinkSupported;
	
	private IssueType(String id, boolean epicLinkSupported) {
		this.id = id;
		this.epicLinkSupported = epicLinkSupported;
	}

	public String getId() {
		return id;
	}

	public boolean isEpicLinkSupported() {
		return epicLinkSupported;
	}
}
