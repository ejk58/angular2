package nl.belastingdienst.iva.inzicht.domain.key;

public class JiraIssueKey {

	public static final String ISSUE = "fields";
	
	public static final String PROJECT = "project";
	public static final String TYPE = "issuetype";
	public static final String SUMMARY = "summary";
	public static final String DESCRIPTION = "description";
	public static final String FIXVERSIONS = "fixVersions";
	public static final String LABELS = "labels";
	
	public static final String ID = "id";
	
    private JiraIssueKey() {
        throw new UnsupportedOperationException();
    }
}
