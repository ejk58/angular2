package nl.belastingdienst.iva.inzicht.database.acceptancereview;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AcceptanceReview {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    private String username;

    private String url;

    private String version;

    private String widget;

    private String side;

    @Column(name = "SUBJECT_NR")
    private String subjectNr;

    private Integer enoughInformation;
    private Integer accordingToSource;
    private Integer informationUpToDate;
    private Integer goodUserExperience;
    private Integer noFurtherRemarks;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getWidget() {
        return widget;
    }

    public void setWidget(String widget) {
        this.widget = widget;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public String getSubjectNr() {
        return subjectNr;
    }

    public void setSubjectNr(String subjectNr) {
        this.subjectNr = subjectNr;
    }

    public Integer getEnoughInformation() {
        return enoughInformation;
    }

    public void setEnoughInformation(Integer enoughInformation) {
        this.enoughInformation = enoughInformation;
    }

    public Integer getAccordingToSource() {
        return accordingToSource;
    }

    public void setAccordingToSource(Integer accordingToSource) {
        this.accordingToSource = accordingToSource;
    }

    public Integer getInformationUpToDate() {
        return informationUpToDate;
    }

    public void setInformationUpToDate(Integer informationUpToDate) {
        this.informationUpToDate = informationUpToDate;
    }

    public Integer getGoodUserExperience() {
        return goodUserExperience;
    }

    public void setGoodUserExperience(Integer goodUserExperience) {
        this.goodUserExperience = goodUserExperience;
    }

    public Integer getNoFurtherRemarks() {
        return noFurtherRemarks;
    }

    public void setNoFurtherRemarks(Integer noFurtherRemarks) {
        this.noFurtherRemarks = noFurtherRemarks;
    }

    @Override
    public String toString() {
        return "AcceptanceReview [id = " + id +
                ", created = " + created +
                ", username = " + username +
                ", url = " + url +
                ", widget = " + widget +
                ", subjectNr = " + subjectNr +
                ", enoughInformation = " + enoughInformation +
                ", accordingToSource = " + accordingToSource +
                ", informationUpToDate = " + informationUpToDate +
                ", goodUserExperience = " + goodUserExperience +
                ", noFurtherRemarks = " + noFurtherRemarks +
                "]";
    }
}
