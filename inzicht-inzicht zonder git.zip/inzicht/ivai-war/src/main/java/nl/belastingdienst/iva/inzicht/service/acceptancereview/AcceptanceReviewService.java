package nl.belastingdienst.iva.inzicht.service.acceptancereview;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import nl.belastingdienst.iva.inzicht.database.acceptancereview.AcceptanceReview;
import nl.belastingdienst.iva.inzicht.database.acceptancereview.AcceptanceReviewDao;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/acceptancereview")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class AcceptanceReviewService extends AbstractRestService {

    @Inject
    private AcceptanceReviewDao acceptanceReviewDao;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    public Response saveAcceptanceReview(AcceptanceReview acceptanceReview) {
        RestCallContext restCallContext = buildRestCallContext(acceptanceReview);
        
        try {
        	saveAcceptanceReview(acceptanceReview, restCallContext);
        	return buildResponse(restCallContext);
        } catch (Exception exception) {
        	return handleException(exception, restCallContext);
        }
    }

    private void saveAcceptanceReview(AcceptanceReview acceptanceReview, RestCallContext restCallContext) {
    	this.acceptanceReviewDao.saveAcceptanceReview(acceptanceReview, restCallContext);
    }
    
    private RestCallContext buildRestCallContext(AcceptanceReview acceptanceReview) {
    	RestCallContext restCallContext = buildRestCallContext(RestServiceType.ACCEPTANCEREVIEWSERVICE);
    	
    	restCallContext.addQueryValue("acceptanceReviewUrl", acceptanceReview.getUrl());
    	restCallContext.addQueryValue("acceptanceReviewWidgetId", acceptanceReview.getWidget());
    	restCallContext.addQueryValue("acceptanceReviewSubjectNr", acceptanceReview.getSubjectNr());
    	
    	return restCallContext;
    }    	
}
