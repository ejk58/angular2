package nl.belastingdienst.iva.inzicht.configuration.query;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class SimpleColumnMapper implements ColumnMapper {

	private String sourceKey;
	private String destinationKey;
	
	public SimpleColumnMapper(String sourceKey, String destinationKey) {
		this.sourceKey = sourceKey;
		this.destinationKey = destinationKey;
	}
	
	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public Object getValue(DataMap sourceDataMap) {
		return (sourceDataMap == null) ? null : sourceDataMap.get(this.sourceKey);
	}
}
