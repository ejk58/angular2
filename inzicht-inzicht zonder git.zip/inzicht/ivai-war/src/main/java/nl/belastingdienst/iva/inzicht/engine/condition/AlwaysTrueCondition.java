package nl.belastingdienst.iva.inzicht.engine.condition;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class AlwaysTrueCondition implements Condition {

	public static final String NAME = "AlwaysTrue";
	
	@Override
	public boolean test(RestCallContext restCallContext) {
		return true;
	}

	@Override
	public String getCondition() {
		return NAME + RulesEngineKey.PARAMETERSTART + RulesEngineKey.PARAMETEREND;
	}
}
