package nl.belastingdienst.iva.inzicht.dataprovider.sql;

import java.util.function.UnaryOperator;

public class SqlStringQueryParameterBuilder implements UnaryOperator<String> {

    @Override
    public String apply(String value) {
        return (value == null) ? null : ("'" + value.replace("'","''") + "'");
    }
}
