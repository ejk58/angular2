package nl.belastingdienst.iva.inzicht.domain.datasource;

public class InternalDatasource extends AbstractDatasource {

    public InternalDatasource(String key) {
        super(key);
    }
    
    @Override
    public DatasourceType getType() {
        return DatasourceType.INTERNAL;
    }
}
