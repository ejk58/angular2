package nl.belastingdienst.iva.inzicht.service.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.domain.DomainComparator;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@Typed(DomainResponseMapper.class)
public class DomainResponseMapper {

    @Inject
    private DomainMapper domainMapper;
    
    private DomainComparator domainComparator = new DomainComparator();
    
    public DataMap map(Set<Domain> domainSet, Configuration configuration) {
        List<Domain> domainList = new ArrayList<>(domainSet);
        DataMap domainResponse = new DataHashMap();
        DataMap domains = new DataHashMap();
        List<DataMap> domainMenuItems = new ArrayList<>();

        Collections.sort(domainList, this.domainComparator);
        for (Domain domain : domainList) {
            if (!domain.getPageDomains().isEmpty()) {
                String domainKey = domain.getKey();
                List<Page> pageList = configuration.findPagesByDomain(domainKey);
                DataMap mappedDomain = this.domainMapper.mapToDomain(domain, pageList);
                DataMap mappedMenuItem = this.domainMapper.mapToMenuItem(domain);

                domains.put(domainKey, mappedDomain);
                domainMenuItems.add(mappedMenuItem);
            }
        }
        
        domainResponse.put(ResponseKey.DOMAINS, domains);
        domainResponse.put(ResponseKey.MENUITEMS, domainMenuItems);
        
        return domainResponse;
    }
}
