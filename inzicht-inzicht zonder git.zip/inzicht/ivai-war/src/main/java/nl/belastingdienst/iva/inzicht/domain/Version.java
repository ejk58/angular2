package nl.belastingdienst.iva.inzicht.domain;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

import nl.belastingdienst.iva.inzicht.service.system.SystemService;

public enum Version {

    INSTANCE;
    
    private static final Logger logger = Logger.getLogger(Version.class);
    
    private String value;
    
    public String getVersion() {
        if (this.value == null) {
            retrieveVersion();
        }
        
        return this.value;
    }
    
    private void retrieveVersion() {
        try {
            Properties properties = new Properties();
            properties.load(SystemService.class.getClassLoader().getResourceAsStream("app-version.properties"));
            this.value = properties.get("version").toString();
        } catch (IOException exception) {
            this.value = "Unknown";
            logger.error("Retrieving the application version throws an exception: ", exception);
        }
    }
}