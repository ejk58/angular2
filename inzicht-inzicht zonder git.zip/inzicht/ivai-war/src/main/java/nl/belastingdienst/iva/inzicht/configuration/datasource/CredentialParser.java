package nl.belastingdienst.iva.inzicht.configuration.datasource;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.apache.log4j.Logger;

import com.ibm.websphere.security.NotImplementedException;
import com.ibm.wsspi.security.auth.callback.Constants;
import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandlerFactory;

import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.credential.Credential;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialEmptyPool;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialEncoding;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialPool;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialRandomPool;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialSinglePool;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialTransport;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialType;
import nl.belastingdienst.iva.inzicht.domain.datasource.AbstractDatasource;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;

public class CredentialParser {

    private static final Map<CredentialType, CredentialTransport> DEFAULTTTRANSPORTMAP;
    private static final CredentialPool EMPTYPOOL = new CredentialEmptyPool();
    
    static {
        Map<CredentialType, CredentialTransport> defaultTransportMap = new EnumMap<>(CredentialType.class);
        
        defaultTransportMap.put(CredentialType.LOGINPASSWORD, CredentialTransport.HTTPHEADER);
        defaultTransportMap.put(CredentialType.APIKEY, CredentialTransport.HTTPHEADER);
        defaultTransportMap.put(CredentialType.URLPARAMETER, CredentialTransport.URLPARAMETER);
        defaultTransportMap.put(CredentialType.LTPATOKEN, CredentialTransport.COOKIE);
        defaultTransportMap.put(CredentialType.LTPA2TOKEN, CredentialTransport.COOKIE);
        
        DEFAULTTTRANSPORTMAP = defaultTransportMap;
    }
    
    private static final Logger logger = Logger.getLogger(CredentialParser.class);

    public CredentialPool parse(AbstractDatasource datasource) {
        Map<String, String> parameterMap = datasource.getParameterMap();
        CredentialPool credentialPool = EMPTYPOOL;
        
        try {
            if (parameterMap.containsKey(DatasourceKey.CREDENTIALSPOOLSIZE)) {
                credentialPool = buildRandomCredentialPool(datasource);
            } else if (parameterMap.containsKey(DatasourceKey.CREDENTIALSTYPE)) {
                credentialPool = buildSingleCredentialPool(datasource);
            } 
        } catch (LoginException | IllegalStateException exception) {
            String key = datasource.getKey();
            String message = "Failed to extract the credential for datasource " + key + " with the exception " + 
                    exception.getClass().getSimpleName() + ": " + exception.getMessage();
            logger.error(MessageUtils.createMessage(MessageType.ERROR, message));
        }

        return credentialPool;
    }
    
    private CredentialPool buildSingleCredentialPool(AbstractDatasource datasource) throws LoginException {
        return new CredentialSinglePool(buildCredential(datasource, ""));
    }

    private CredentialPool buildRandomCredentialPool(AbstractDatasource datasource) throws LoginException {
        CredentialRandomPool credentialPool = new CredentialRandomPool();
        Map<String, String> parameterMap = datasource.getParameterMap();
        int poolsize = Integer.parseInt(parameterMap.get(DatasourceKey.CREDENTIALSPOOLSIZE));
        
        for (int index = 0; index < poolsize; index++) {
            credentialPool.addCredential(buildCredential(datasource, Integer.toString(index)));
        }
        
        return credentialPool;
    }

    private Credential buildCredential(AbstractDatasource datasource, String suffix) throws LoginException {
        Map<String, String> parameterMap = datasource.getParameterMap();
        String name = null;
        char[] password = null;

        if (parameterMap.containsKey(DatasourceKey.CREDENTIALMAPPING + suffix)) {
            String credentialAlias = parameterMap.get(DatasourceKey.CREDENTIALMAPPING + suffix);
            PasswordCredential passwordCredential = getCredentialFromWebsphere(credentialAlias);
            name = passwordCredential.getUserName();
            password = passwordCredential.getPassword();
        } else {
            name = parameterMap.get(DatasourceKey.CREDENTIALNAME + suffix);
            String credentialsValue = parameterMap.get(DatasourceKey.CREDENTIALVALUE + suffix);
            password = credentialsValue == null ? new char[0] : credentialsValue.toCharArray();
        }

        CredentialType type = CredentialType.findCredentialType(parameterMap.get(DatasourceKey.CREDENTIALSTYPE));
        CredentialEncoding encoding = CredentialEncoding.findCredentialEncoding(parameterMap.get(DatasourceKey.CREDENTIALSENCODING));
        CredentialTransport transport = findDefaultCredentialTransport(type);
        char[] value = encodeCredential(datasource, name, password);
        
        return new Credential(type, encoding, transport, name, password, value);
    }
    
    private char[] encodeCredential(AbstractDatasource datasource, String name, char[] password) {
        Map<String, String> parameterMap = datasource.getParameterMap();
        String datasourceKey = datasource.getKey();
        String typeKey = parameterMap.get(DatasourceKey.CREDENTIALSTYPE);
        String encodingKey = parameterMap.get(DatasourceKey.CREDENTIALSENCODING);

        CredentialType type = CredentialType.findCredentialType(typeKey);
        if (type == null) {
            throw new IllegalStateException("The credential type '" + typeKey + "' for datasource '" + datasourceKey + "' is not supported.");
        }
        
        CredentialEncoding encoding = CredentialEncoding.findCredentialEncoding(encodingKey);
        if (encoding == null) {
            throw new IllegalStateException("The credential encoding '" + encodingKey + "' for datasource '" + datasourceKey + "' is not supported.");
        }
        
        String combinedCredential = (type == CredentialType.LOGINPASSWORD) ? (name + ":" + new String(password)) : new String(password);
        String encodedCredential = encoding.encodeCredential(combinedCredential); 
        return encodedCredential == null ? new char[0] : encodedCredential.toCharArray();
    }

    private PasswordCredential getCredentialFromWebsphere(String credentialAlias) throws LoginException {
        Map<String, String> map = new HashMap<>();
        map.put(Constants.MAPPING_ALIAS, credentialAlias);
        
        CallbackHandler callbackHandler = getCallbackHandler(map);
        LoginContext loginContext = new LoginContext("DefaultPrincipalMapping", callbackHandler);
        loginContext.login();
        Subject subject = loginContext.getSubject();
        Set<?> credentials = subject.getPrivateCredentials();
        return (PasswordCredential) credentials.iterator().next();
    }
    
    private CallbackHandler getCallbackHandler(Map<String, String> map) {
        try {
            return WSMappingCallbackHandlerFactory.getInstance().getCallbackHandler(map, null);
        } catch (NotImplementedException exception) {
            throw new IllegalStateException(exception); 
        }
    }
    
    private CredentialTransport findDefaultCredentialTransport(CredentialType credentialType) {
        return DEFAULTTTRANSPORTMAP.get(credentialType);
    }
}
