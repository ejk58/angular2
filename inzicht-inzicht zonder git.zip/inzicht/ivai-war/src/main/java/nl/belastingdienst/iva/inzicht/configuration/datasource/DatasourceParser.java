package nl.belastingdienst.iva.inzicht.configuration.datasource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.HttpHeaders;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.DatasourceJPA;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.DatasourceParamJPA;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.credential.Credential;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialPool;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialType;
import nl.belastingdienst.iva.inzicht.domain.datasource.AbstractDatasource;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.datasource.DatasourceType;
import nl.belastingdienst.iva.inzicht.domain.datasource.HttpDatasource;
import nl.belastingdienst.iva.inzicht.domain.datasource.InternalDatasource;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;

public class DatasourceParser {

    private static final Logger logger = Logger.getLogger(DatasourceParser.class);
    
    private CredentialParser credentialParser;

    private Map<String, Datasource> datasourceMap;
    
    public DatasourceParser(List<DatasourceJPA> datasourceJPAList) {
        this.credentialParser = new CredentialParser();
        this.datasourceMap = new HashMap<>();
        
        for (DatasourceJPA datasourceJPA : datasourceJPAList) {
            Datasource datasource = parseDatasource(datasourceJPA);
            this.datasourceMap.put(datasource.getKey(), datasource);
        }
    }
    
    public Map<String, Datasource> getDatasourceMap() {
        return this.datasourceMap;
    }
    
    private Datasource parseDatasource(DatasourceJPA datasourceJPA) {
        AbstractDatasource datasource = createNewDatasource(datasourceJPA);
        datasourceJPA.setDatasource(datasource);
        
	    enhanceDatasource(datasource);
	    lockDatasource(datasource);
	    addHttpClient(datasource);

        return datasource;
    }
    
    private AbstractDatasource createNewDatasource(DatasourceJPA datasource) {
        String key = datasource.getKey();
        List<DatasourceParamJPA> parameterList = datasource.getParameterList();
        boolean isRestDatasource = parameterList.stream().anyMatch(parameter -> DatasourceKey.RESTURL.equals(parameter.getKey()));
        AbstractDatasource newDatasource = isRestDatasource ? new HttpDatasource(key) : new InternalDatasource(key);
        
        for (DatasourceParamJPA parameter : parameterList) {
            newDatasource.setValue(parameter.getKey(), parameter.getValue());
        }
        
        return newDatasource;
    }
    
    private void enhanceDatasource(AbstractDatasource datasource) {
        Map<String, String> parameterMap = datasource.getParameterMap();
        CredentialPool credentialPool = this.credentialParser.parse(datasource);
        Credential credential = credentialPool.getCredential();
        
        datasource.setCredentialPool(credentialPool);
        if (datasource.getType() == DatasourceType.REST && credential != null) {
            CredentialType type = credential.getType();

            if (type == CredentialType.LOGINPASSWORD && !parameterMap.containsKey(DatasourceKey.CREDENTIALSHEADER)) {
                datasource.setValue(DatasourceKey.CREDENTIALSHEADER, HttpHeaders.AUTHORIZATION);
            } else if (type == CredentialType.APIKEY && !parameterMap.containsKey(DatasourceKey.CREDENTIALSHEADER)) {
                datasource.setValue(DatasourceKey.CREDENTIALSHEADER, "x-api-key");
            } else if (type == CredentialType.LTPATOKEN && !parameterMap.containsKey(DatasourceKey.COOKIENAME)) {
                datasource.setValue(DatasourceKey.COOKIENAME, "LtpaToken");
            } else if (type == CredentialType.LTPA2TOKEN && !parameterMap.containsKey(DatasourceKey.COOKIENAME)) {
                datasource.setValue(DatasourceKey.COOKIENAME, "LtpaToken2");
            }
        }
    }
    
    private void lockDatasource(AbstractDatasource newDatasource) {
        newDatasource.lockParameterMap();
    }
    
    private void addHttpClient(AbstractDatasource newDatasource) {
    	if (newDatasource.getType() == DatasourceType.REST) {
    	    HttpDatasource restDatasource = (HttpDatasource) newDatasource;
    		CloseableHttpClient httpClient = createHttpClient(restDatasource);
    		restDatasource.setHttpClient(httpClient);
    	}
    }
    
    private CloseableHttpClient createHttpClient(HttpDatasource newDatasource) {
		HttpClientBuilder httpClientBuilder = HttpClients.custom()
				.useSystemProperties()
				.disableAutomaticRetries()
				.setDefaultRequestConfig(createRequestConfig(newDatasource));
		
		if (newDatasource.getBoolean(DatasourceKey.TRUSTALLCERTIFICATES)) {
			httpClientBuilder.setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);
			String message = "The datasource " + newDatasource.getKey() + " is set to trust all certificates!";
			logger.warn(MessageUtils.createMessage(MessageType.WARNING, message));
		}
		
		return httpClientBuilder.build();
    }
    
    private RequestConfig createRequestConfig(HttpDatasource newDatasource) {
    	RequestConfig.Builder requestConfigBuilder = RequestConfig.custom();
    	
    	if (newDatasource.getValue(DatasourceKey.CONNECTTIMEOUT) != null) {
    		requestConfigBuilder.setConnectTimeout(newDatasource.getNumber(DatasourceKey.CONNECTTIMEOUT));
    	}
    	
    	if (newDatasource.getValue(DatasourceKey.READTIMEOUT) != null) {
    		requestConfigBuilder.setSocketTimeout(newDatasource.getNumber(DatasourceKey.READTIMEOUT));
    	}
    	
    	if (newDatasource.getValue(DatasourceKey.REQUESTTIMEOUT) != null) {
    		requestConfigBuilder.setConnectionRequestTimeout(newDatasource.getNumber(DatasourceKey.REQUESTTIMEOUT));
    	}
    	
    	return requestConfigBuilder.build();
    }
}
