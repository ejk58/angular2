package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class ConcatColumnMapper implements ColumnMapper {

    private List<ColumnMapper> partialColumnMappers;
    private String destinationKey;
	
	public ConcatColumnMapper(List<ColumnMapper> partialColumnMappers, String destinationKey) {
		this.partialColumnMappers = partialColumnMappers;
		this.destinationKey = destinationKey;
	}

	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public String getValue(DataMap sourceDataMap) {
        StringBuilder result = new StringBuilder();
        
        for (ColumnMapper columnMapper : this.partialColumnMappers) {
        	Object value = columnMapper.getValue(sourceDataMap);
        	result.append(value);
        }
        
		return result.toString();
	}
}
