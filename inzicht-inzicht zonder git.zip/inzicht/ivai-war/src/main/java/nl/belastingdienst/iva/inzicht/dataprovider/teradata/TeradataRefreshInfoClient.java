package nl.belastingdienst.iva.inzicht.dataprovider.teradata;

import java.util.List;

import javax.enterprise.inject.Typed;
import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;

@Typed(TeradataRefreshInfoClient.class)
public class TeradataRefreshInfoClient extends TeradataClient {

    private static final QueryInterface QUERY_REFRESHINFO = new TeradataQuery("p_inz_updatedate_bron", 
            "SELECT LOWER(viewname) as viewName, bron as source, verversdatum as refreshDate " +
            "FROM {teradataSchema:config}.{viewName} " +
            "WHERE id = 1 AND bron IS NOT NULL");
    
    public List<DataMap> retrieveRefreshInfo(Configuration configuration) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>();
        Result result = retrieveDataAsMultiMap(QUERY_REFRESHINFO, configuration, queryValues);
        return result.getData();
    }
}
