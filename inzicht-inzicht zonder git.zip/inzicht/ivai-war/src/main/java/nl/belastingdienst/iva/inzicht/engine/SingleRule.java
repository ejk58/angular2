package nl.belastingdienst.iva.inzicht.engine;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.action.Action;
import nl.belastingdienst.iva.inzicht.engine.condition.Condition;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class SingleRule implements RuleInterface {

	private Condition condition;
	private Action action;
	
	public SingleRule(Condition condition, Action action) {
		this.condition = condition;
		this.action = action;
	}
	
	@Override
	public Flow apply(RestCallContext restCallContext) {
		Flow flow = Flow.CONTINUE;
		
		if (this.condition.test(restCallContext)) {
			flow = this.action.execute(restCallContext);
		}
		
		return flow;
	}

	@Override
	public String getRule() {
		return this.condition.getCondition() + " " + RulesEngineKey.RULEOPERATOR + " " + this.action.getAction();
	}
}
