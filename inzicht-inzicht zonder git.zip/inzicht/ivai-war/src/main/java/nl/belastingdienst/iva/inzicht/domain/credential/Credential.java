package nl.belastingdienst.iva.inzicht.domain.credential;

public class Credential {

    private CredentialType type;
    private CredentialEncoding encoding;
    private CredentialTransport transport;
    private String name;
    private char[] key;
    private char[] value;
    
    public Credential(CredentialType type, CredentialEncoding encoding, CredentialTransport transport, String name, char[] key, char[] value) {
        this.type = type;
        this.encoding = encoding;
        this.transport = transport;
        this.name = name;
        this.key = key;
        this.value = value;
    }

    public CredentialType getType() {
        return this.type;
    }
    
    public CredentialEncoding getEncoding() {
        return this.encoding;
    }
    
    public CredentialTransport getTransport() {
        return this.transport;
    }
    
    public String getName() {
        return this.name;
    }
    
    public char[] getKey() {
        return this.key;
    }
    
    public char[] getValue() {
        return this.value;
    }
}
