package nl.belastingdienst.iva.inzicht.domain.datasource;

public enum DatasourceType {
    INTERNAL,
    REST;
}
