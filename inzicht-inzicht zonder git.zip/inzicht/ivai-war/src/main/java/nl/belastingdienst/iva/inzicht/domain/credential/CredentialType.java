package nl.belastingdienst.iva.inzicht.domain.credential;

public enum CredentialType {

    LOGINPASSWORD("LOGINPASSWORD"),
    APIKEY("APIKEY"),
    URLPARAMETER("URLPARAMETER"),
    LTPATOKEN("LTPATOKEN"),
    LTPA2TOKEN("LTPA2TOKEN");
    
    private String name;
    
    private CredentialType(String name) {
        this.name = name;
    }

    public static CredentialType findCredentialType(String credentialTypeName) {
        for (CredentialType credentialType : values()) {
            if (credentialType.name.equals(credentialTypeName)) {
                return credentialType;
            }
        }
        
        return null;
    }
}
