package nl.belastingdienst.iva.inzicht.user;

public enum RoleType {

    ROLE(0, "role"),
    USER(1, "user");

    private int type;
    private String name;
    
    private RoleType(int type, String name) {
        this.type = type;
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name; 
    }
    
    public static RoleType findRoleType(int type) {
        for (RoleType roleType : values()) {
            if (roleType.type == type) {
                return roleType;
            }
        }
        
        return null;
    }
}
