package nl.belastingdienst.iva.inzicht.monitor;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.apache.log4j.Logger;

import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class MonitorFactory {
	
    private static final long FREEMEMORYTHRESHOLD = 32L * 1024L * 1024L;
    
    private static final Logger logger = Logger.getLogger(MonitorFactory.class);

    @PostConstruct
    public void initialize() {
        logMonitor();
    }

    @Schedule(minute = "*/15", hour = "*", persistent = false)
    public void update() {
    	logMonitor();
    }

    public Monitor getMonitor() {
    	return buildMonitor();
    }

    public DataMap getStatus() {
        return createStatus();
    }
    
    private void logMonitor() {
    	Monitor monitor = buildMonitor();
    	Long freeMemory = monitor.getPresumablyFreeMemory(); 
    	
        String message = MessageUtils.createMessage(MessageType.STATE, "Current system state, memory = (" + monitor + ").");
        logger.info(message);
        
    	if (freeMemory != null && freeMemory < FREEMEMORYTHRESHOLD) {
            message = MessageUtils.createMessage(MessageType.WARNING, 
                    "System is running out of memory, presumablyFreeMemory = " + MessageUtils.createSize(freeMemory) + ".");
            logger.warn(message);
    	}
    }

    private Monitor buildMonitor() {
        Monitor monitor = new Monitor();

        monitor.setMaximumAvailableMemory(Runtime.getRuntime().maxMemory());
        monitor.setAllocatedTotalMemory(Runtime.getRuntime().totalMemory());
        monitor.setAllocatedFreeMemory(Runtime.getRuntime().freeMemory());
        
        return monitor;
    }
    
    private DataMap createStatus() {
    	Monitor monitor = buildMonitor();
    	String maximumAvailableMemory = monitor.getMaximumAvailableMemory() == null ? MessageUtils.UNKNOWN : MessageUtils.createSize(monitor.getMaximumAvailableMemory()); 
    	String presumablyFreeMemory = monitor.getPresumablyFreeMemory() == null ? MessageUtils.UNKNOWN : MessageUtils.createSize(monitor.getPresumablyFreeMemory());
    	
        DataMap status = new DataHashMap();
        status.put("maximumAvailableMemory", maximumAvailableMemory);
        status.put("allocatedTotalMemory", MessageUtils.createSize(monitor.getAllocatedTotalMemory()));
        status.put("allocatedFreeMemory", MessageUtils.createSize(monitor.getAllocatedFreeMemory()));
        status.put("allocatedUsedMemory", MessageUtils.createSize(monitor.getAllocatedUsedMemory()));
        status.put("presumablyFreeMemory", presumablyFreeMemory);
        return status;
    }
}
