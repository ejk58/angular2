package nl.belastingdienst.iva.inzicht.engine.action;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.ForbiddenException;
import nl.belastingdienst.iva.inzicht.domain.exception.GatewayTimeoutException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotAuthorizedException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotFoundException;
import nl.belastingdienst.iva.inzicht.domain.exception.ServiceUnavailableException;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class ThrowExceptionAction implements Action {

	public static final String NAME = "ThrowException";

	private String exceptionName;
	private Class<? extends RuntimeException> exceptionClass;
	private String exceptionMessage;
	
	public ThrowExceptionAction(String exceptionName, String message) {
		this.exceptionName = exceptionName;
		this.exceptionMessage = message;
		
		if ("BadRequestException".equals(exceptionName)) {
			this.exceptionClass = BadRequestException.class;
		} else if ("NotAuthorizedException".equals(exceptionName)) {
			this.exceptionClass = NotAuthorizedException.class;
		} else if ("ForbiddenException".equals(exceptionName)) {
			this.exceptionClass = ForbiddenException.class;
		} else if ("NotFoundException".equals(exceptionName)) {
			this.exceptionClass = NotFoundException.class;
		} else if ("InternalServerErrorException".equals(exceptionName)) {
			this.exceptionClass = InternalServerErrorException.class;
		} else if ("BadGatewayException".equals(exceptionName)) {
			this.exceptionClass = BadGatewayException.class;
		} else if ("ServiceUnavailableException".equals(exceptionName)) {
			this.exceptionClass = ServiceUnavailableException.class;
		} else if ("GatewayTimeoutException".equals(exceptionName)) {
			this.exceptionClass = GatewayTimeoutException.class;
		} else {
			throw new IllegalStateException("The ThrowException-action did not find a supported exception with class name or status code " 
					+ exceptionName + ".");
		}
	}
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
		try {
			Constructor<? extends RuntimeException> exceptionConstructor = this.exceptionClass.getConstructor(String.class);
			throw exceptionConstructor.newInstance(this.exceptionMessage);
		} catch (IllegalAccessException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
			String message = "Failed to throw the requested exception of type " + this.exceptionName + 
					" in the ThrowException-action with exception " + ExceptionUtils.getExceptionsForMessage(exception);
			throw new InternalServerErrorException(message);
		}
	}
	
	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.exceptionName + RulesEngineKey.PARAMETERSEPARATOR + this.exceptionMessage + RulesEngineKey.PARAMETEREND;
	}
}
