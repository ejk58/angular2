package nl.belastingdienst.iva.inzicht.configuration.rule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.database.configuration.rule.Rule;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.MultipleRule;
import nl.belastingdienst.iva.inzicht.engine.RulesEngine;
import nl.belastingdienst.iva.inzicht.engine.SingleRule;

public class RuleGroupParser {

	private ConditionParser conditionParser;
	private ActionParser actionParser;

	private Map<String, RuleGroup> ruleGroups;
	
	public RuleGroupParser(RulesEngine rulesEngine) {
		this.conditionParser = new ConditionParser(rulesEngine);
		this.actionParser = new ActionParser(rulesEngine);
		
		this.ruleGroups = new HashMap<>();
	}

	public void parse(List<RuleGroup> ruleGroups) {
		for (RuleGroup ruleGroup : ruleGroups) {
			String key = ruleGroup.getKey();
			List<Rule> ruleList = ruleGroup.getRuleList();

			List<SingleRule> rules = ruleList.stream()
					.sorted((rule, otherRule) -> rule.getIndex().compareTo(otherRule.getIndex()))
					.map(rule -> parseSingleRule(rule.getValue()))
					.collect(Collectors.toList());

			MultipleRule rule = joinMultipleRules(key, rules);
			ruleGroup.setRule(rule);
			this.ruleGroups.put(key, ruleGroup);
		}
	}
	
	public Map<String, RuleGroup> getRuleGroupMap() {
		return this.ruleGroups;
	}
	
	private SingleRule parseSingleRule(String rule) {
		try {
			int divider = rule.indexOf(RulesEngineKey.RULEOPERATOR);
			String condition = rule.substring(0, divider);
			String action = rule.substring(divider + RulesEngineKey.RULEOPERATOR.length());

			return new SingleRule(this.conditionParser.parse(condition), this.actionParser.parse(action));
		} catch (RuntimeException exception) {
			throw new IllegalStateException("The rule " + rule + " could not be created with the exception: " + exception.getMessage(), exception);
		}
	}
	
	private MultipleRule joinMultipleRules(String key, List<SingleRule> rules) {
		return new MultipleRule(key, rules);
	}
}
