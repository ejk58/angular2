package nl.belastingdienst.iva.inzicht.configuration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import org.apache.log4j.Logger;

import nl.belastingdienst.iva.inzicht.configuration.attribute.AttributeGroupParser;
import nl.belastingdienst.iva.inzicht.configuration.datasource.DatasourceParser;
import nl.belastingdienst.iva.inzicht.configuration.domain.DomainParser;
import nl.belastingdienst.iva.inzicht.configuration.page.PageParser;
import nl.belastingdienst.iva.inzicht.configuration.query.QueryParser;
import nl.belastingdienst.iva.inzicht.configuration.rule.RuleGroupParser;
import nl.belastingdienst.iva.inzicht.configuration.widget.WidgetParser;
import nl.belastingdienst.iva.inzicht.database.configuration.ConfigurationDao;
import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.DatasourceJPA;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.datasource.HttpDatasource;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.engine.RulesEngine;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class ConfigurationFactory {

    private static final String CONFIGURATIONDATEFORMAT = "dd-MM-yyyy HH:mm:ss";
    private static final String TERADATADATASOURCEKEY = "Teradata/IVAI";
    private static final String MIHPROXYDATASOURCEKEY = "Rest/MihProxy";
    private static final String JIRAFEEDBACKDATASOURCEKEY = "Rest/JiraFeedback";

    private static final Logger logger = Logger.getLogger(ConfigurationFactory.class);

    @Inject
    private ConfigurationDao configurationDao;

    @Inject
    private RefreshInformationFactory refreshInformationFactory;

    @Inject
    private RulesEngine rulesEngine;
    
    private Configuration configuration;
    
    public ConfigurationFactory() {
        createEmptyConfiguration();
    }

    @PostConstruct
    public void initialize() {
        loadNewConfiguration();
        logCurrentConfiguration();
    }

    @Schedule(minute = "*/10", hour = "*", persistent = false)
    public void update() {
        loadNewConfiguration();
        logCurrentConfiguration();
    }

    public Configuration getConfiguration() {
        return this.configuration;
    }

    public DataMap getStatus() {
        return createStatus();
    }
    
    private void createEmptyConfiguration() {
        DefaultConfiguration newConfiguration = createErrorConfiguration();
        newConfiguration = addDefaultValues(newConfiguration);
        this.configuration = newConfiguration;
    }

    private void loadNewConfiguration() {
        logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Starting the update of the configuration cache"));

        long startTime = System.currentTimeMillis();
        try {
            DefaultConfiguration newConfiguration = createDefaultConfiguration();

            newConfiguration = addDomainPageWidgetConfiguration(newConfiguration);
            newConfiguration = addWidgetRefreshInformation(newConfiguration);
            newConfiguration = addConfigurationMetaData(newConfiguration, System.currentTimeMillis() - startTime);
            newConfiguration = addDefaultValues(newConfiguration);

            this.configuration = newConfiguration;

            logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Updated the configuration cache in " + 
                    this.configuration.getValue(ConfigurationKey.CONFIGURATIONUPDATEDURATION)));
        } catch (Exception exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Refreshing the configuration cache throws an exception " + 
                    ExceptionUtils.getExceptionsForMessage(exception)), exception);
        }
    }

    private void logCurrentConfiguration() {
        if (DomainUtils.isTrue(this.configuration.getValueAsString(ConfigurationKey.CONFIGURATIONNEWSETTINGSAVAILABLE))) {
            logger.info(MessageUtils.createMessage(MessageType.MESSAGE, 
                    "Loaded a new configuration, configuration = (" + this.configuration.toString()) + ").");
        }
    }

    private DefaultConfiguration createDefaultConfiguration() {
        return new DefaultConfiguration();
    }

    private ErrorConfiguration createErrorConfiguration() {
        return new ErrorConfiguration();
    }

    private DefaultConfiguration addDomainPageWidgetConfiguration(DefaultConfiguration newConfiguration) {
        List<AttributeGroup> attributeGroupList = readGlobalAttributes(newConfiguration);
        List<DatasourceJPA> datasourceList = readDatasources(newConfiguration);
        List<Query> queryList = readQueries(newConfiguration);
        List<RuleGroup> ruleGroupList = readRuleGroups(newConfiguration);
        List<Domain> domainList = readDomains(newConfiguration);
        List<Widget> widgetList = readWidgets(newConfiguration);
        List<Page> pageList = readPages(newConfiguration);
        
        addGlobalAttributes(newConfiguration, attributeGroupList);
        addDatasources(newConfiguration, datasourceList);
        addQueries(newConfiguration, queryList);
        addRuleGroups(newConfiguration, ruleGroupList);
        addDomains(newConfiguration, domainList);
        addPages(newConfiguration, pageList);
        addWidgets(newConfiguration, widgetList, pageList);

        return newConfiguration;
    }

    private DefaultConfiguration addWidgetRefreshInformation(DefaultConfiguration newConfiguration) {
        try {
            Map<String, DataMap[]> refreshInformation = this.refreshInformationFactory.createRefreshInformation(newConfiguration);
            Collection<Widget> widgetList = newConfiguration.getWidgetMap().values();

            for (Widget widget : widgetList) {
                if (widget.isRefreshInfo()) {
                    Query query = widget.getQuery();
                    String viewName = query.getViewName().trim().toLowerCase();
                    DataMap[] refreshInfo = refreshInformation.get(viewName);
                    widget.setRefreshInfoMap(refreshInfo == null ? DomainUtils.emptyDataMapArray() : refreshInfo);
                } else {
                    widget.setRefreshInfoMap(null);
                }
            }

            newConfiguration.setValue(ConfigurationKey.SOURCEREFRESHINFORMATIONAVAILABLE, Boolean.toString(refreshInformation.size() > 0));
        } catch (Exception exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Adding the refresh-information to the configuration cache throws an exception " + 
                    ExceptionUtils.getExceptionsForMessage(exception)), exception);
            newConfiguration.setValue(ConfigurationKey.SOURCEREFRESHINFORMATIONAVAILABLE, Boolean.toString(Boolean.FALSE));
        }

        return newConfiguration;
    }

    private DefaultConfiguration addConfigurationMetaData(DefaultConfiguration newConfiguration, long duration) {
        try {
            AttributeGroup attributeGroup = newConfiguration.getAttributeGroup(ConfigurationKey.GENERALGROUP);
            Map<String, String> attributeMap = attributeGroup == null ? new HashMap<>() : attributeGroup.getAttributeMap();
            if (attributeMap.get(ConfigurationKey.CONFIGURATIONLOADTIME) == null) {
                attributeMap.put(ConfigurationKey.CONFIGURATIONLOADTIME, "Unknown");
            }
            newConfiguration.setValues(attributeMap);

            DateFormat dateFormat = new SimpleDateFormat(CONFIGURATIONDATEFORMAT);
            String updateTime = dateFormat.format(new Date());
            newConfiguration.setValue(ConfigurationKey.CONFIGURATIONUPDATETIME, updateTime);

            newConfiguration.setValue(ConfigurationKey.CONFIGURATIONSTATUS, "OK");
            
            newConfiguration.setValue(ConfigurationKey.CONFIGURATIONUPDATEDURATION, MessageUtils.createDuration(duration));

            String loadTime = attributeMap.get(ConfigurationKey.CONFIGURATIONLOADTIME);
            boolean refreshIndication = !loadTime.equals(this.configuration.getValue(ConfigurationKey.CONFIGURATIONLOADTIME));
            newConfiguration.setValue(ConfigurationKey.CONFIGURATIONNEWSETTINGSAVAILABLE, Boolean.toString(refreshIndication));
        } catch (Exception exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Adding the configuration metadata to the configuration cache throws an exception " + 
                    ExceptionUtils.getExceptionsForMessage(exception)), exception);
        }

        return newConfiguration;
    }

    private DefaultConfiguration addDefaultValues(DefaultConfiguration newConfiguration) {
        for (Map.Entry<String, String> defaultValue : DefaultValues.VALUES.entrySet()) {
            newConfiguration.setDefaultValue(defaultValue.getKey(), defaultValue.getValue());
        }

        return newConfiguration;
    }    
    
    private List<AttributeGroup> readGlobalAttributes(DefaultConfiguration newConfiguration) {
        long startTime = System.currentTimeMillis();
        List<AttributeGroup> attributeGroupList = this.configurationDao.getAttributeGroups();
        newConfiguration.addConfigurationDetails("Read time (attributes)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
        return attributeGroupList;
    }
    
    private List<DatasourceJPA> readDatasources(DefaultConfiguration newConfiguration) {
        long startTime = System.currentTimeMillis();
        
        List<DatasourceJPA> datasourceList = this.configurationDao.getDatasources();
        
        newConfiguration.addConfigurationDetails("Read time (datasources)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
        return datasourceList;
    }
    
    private List<Domain> readDomains(DefaultConfiguration newConfiguration) {
        long startTime = System.currentTimeMillis();
        List<Domain> domainList = this.configurationDao.getDomains();
        newConfiguration.addConfigurationDetails("Read time (domains)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
        return domainList;
    }
    
    private List<Page> readPages(DefaultConfiguration newConfiguration) {
        long startTime = System.currentTimeMillis();
        List<Page> pageList = this.configurationDao.getPages();
        newConfiguration.addConfigurationDetails("Read time (pages)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
        return pageList;
    }
    
    private List<Widget> readWidgets(DefaultConfiguration newConfiguration) {
        long startTime = System.currentTimeMillis();
        List<Widget> widgetList = this.configurationDao.getWidgets();
        newConfiguration.addConfigurationDetails("Read time (widgets)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
        return widgetList;
    }
    
    private List<RuleGroup> readRuleGroups(DefaultConfiguration newConfiguration) {
        long startTime = System.currentTimeMillis();
        List<RuleGroup> ruleGroupList = this.configurationDao.getRuleGroups();
        newConfiguration.addConfigurationDetails("Read time (rules)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
        return ruleGroupList;
    }
    
    private List<Query> readQueries(DefaultConfiguration newConfiguration) {
        long startTime = System.currentTimeMillis();
        List<Query> queryList = this.configurationDao.getQueries();
        newConfiguration.addConfigurationDetails("Read time (queries)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
        return queryList;
    }
    
    private void addGlobalAttributes(DefaultConfiguration newConfiguration, List<AttributeGroup> attributeGroupList) {
        long startTime = System.currentTimeMillis();
        AttributeGroupParser attributeGroupParser = new AttributeGroupParser(attributeGroupList);
        Map<String, AttributeGroup> attributeGroupMap = attributeGroupParser.getAttributeGroupMap();
        newConfiguration.setAttributeGroupMap(attributeGroupMap);
        newConfiguration.addConfigurationDetails("Parse time (attributes)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
    }
    
    private void addDatasources(DefaultConfiguration newConfiguration, List<DatasourceJPA> datasourceList) {
        long startTime = System.currentTimeMillis();
        DatasourceParser datasourceParser = new DatasourceParser(datasourceList);
        Map<String, Datasource> datasourceMap = datasourceParser.getDatasourceMap();
        
        newConfiguration.setTeradataDatasource(getRestDatasource(datasourceMap, TERADATADATASOURCEKEY));
        newConfiguration.setMihProxyDatasource(getRestDatasource(datasourceMap, MIHPROXYDATASOURCEKEY));
        newConfiguration.setJiraFeedbackDatasource(getRestDatasource(datasourceMap, JIRAFEEDBACKDATASOURCEKEY));
        newConfiguration.addConfigurationDetails("Parse time (datasources)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
    }
    
    private void addDomains(DefaultConfiguration newConfiguration, List<Domain> domainList) {
        long startTime = System.currentTimeMillis();
        DomainParser domainParser = new DomainParser(domainList);
        newConfiguration.setDomainList(domainParser.getDomainList());
        newConfiguration.setDomainMap(domainParser.getDomainMap());
        newConfiguration.setDomainsByRoleMap(domainParser.getDomainsPerRole());
        newConfiguration.addConfigurationDetails("Parse time (domains)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
    }

    private void addPages(DefaultConfiguration newConfiguration, List<Page> pageList) {
        long startTime = System.currentTimeMillis();
        PageParser pageParser = new PageParser(pageList);
        newConfiguration.setPageMap(pageParser.getPageMap());
        newConfiguration.setPagesByDomainMap(pageParser.getPageByDomainMap());
        newConfiguration.addConfigurationDetails("Parse time (pages)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
    }
    
    private void addWidgets(DefaultConfiguration newConfiguration, List<Widget> widgetList, List<Page> pageList) {
        long startTime = System.currentTimeMillis();
        WidgetParser widgetParser = new WidgetParser(widgetList, pageList);        
        newConfiguration.setWidgetMap(widgetParser.getWidgetMap());
        newConfiguration.addConfigurationDetails("Parse time (widgets)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
    }
    
    private void addRuleGroups(DefaultConfiguration newConfiguration, List<RuleGroup> ruleGroupList) {
        long startTime = System.currentTimeMillis();
        RuleGroupParser ruleGroupParser = new RuleGroupParser(this.rulesEngine);
        ruleGroupParser.parse(ruleGroupList);
        Map<String, RuleGroup> ruleGroupMap = ruleGroupParser.getRuleGroupMap();
        newConfiguration.setRuleGroupMap(ruleGroupMap);
        newConfiguration.addConfigurationDetails("Parse time (rules)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
    }
    
    private void addQueries(DefaultConfiguration newConfiguration, List<Query> queryList) {
        long startTime = System.currentTimeMillis();
        QueryParser queryParser = new QueryParser(newConfiguration.getAttributeGroupMap());
        queryParser.parse(queryList);
        newConfiguration.addConfigurationDetails("Parse time (queries)", MessageUtils.createDuration(System.currentTimeMillis() - startTime));
    }
    
    private HttpDatasource getRestDatasource(Map<String, Datasource> datasourceMap, String key) {
        Datasource datasource = datasourceMap.get(key);
        
        if (!(datasource instanceof HttpDatasource)) {
            String message = "The datasource " + key + " is of the wrong type, it should be a rest-datasource.";
            throw new IllegalStateException(message);
        }
        
        return (HttpDatasource) datasource;
    }
    
    public void setConfiguration(Configuration configuration) {
        this.configuration = configuration;
    }
    
    public DataMap createStatus() {
        return new DataHashMap(this.configuration.getKeyValueMap()); 
    }
}
