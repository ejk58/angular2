package nl.belastingdienst.iva.inzicht.domain.credential;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class CredentialRandomPool implements CredentialPool {

    private List<Credential> credentialList;
    
    public CredentialRandomPool() {
        this.credentialList = new ArrayList<>();
    }

    public CredentialRandomPool(List<Credential> credentials) {
        this.credentialList = new ArrayList<>();
        this.credentialList.addAll(credentials);
    }

    @Override
    public Credential getCredential() {
        int randomIndex = ThreadLocalRandom.current().nextInt(0, this.credentialList.size());
        return this.credentialList.get(randomIndex);
    }
    
    public void addCredential(Credential credential) {
        this.credentialList.add(credential);
    }
    
    public void lockCredential() {
        this.credentialList = Collections.unmodifiableList(this.credentialList);
    }
}
