package nl.belastingdienst.iva.inzicht.domain;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;

public class UnmodifiableMultiValuedMap<K, V> implements MultivaluedMap<K, V> {

    MultivaluedMap<K, V> map;
    
    public UnmodifiableMultiValuedMap(MultivaluedMap<K, V> map) {
        this.map = map;
    }
    
    @Override
    public void clear() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean containsKey(Object key) {
        return this.map.containsKey(key);
    }

    @Override
    public boolean containsValue(Object value) {
        return this.map.containsValue(value);
    }

    @Override
    public Set<java.util.Map.Entry<K, List<V>>> entrySet() {
        return this.map.entrySet();
    }

    @Override
    public List<V> get(Object key) {
        return this.map.get(key);
    }

    @Override
    public boolean isEmpty() {
        return this.map.isEmpty();
    }

    @Override
    public Set<K> keySet() {
        return this.map.keySet();
    }

    @Override
    public List<V> put(K key, List<V> value) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void putAll(Map<? extends K, ? extends List<V>> map) {
        throw new UnsupportedOperationException();
    }

    @Override
    public List<V> remove(Object key) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int size() {
        return this.map.size();
    }

    @Override
    public Collection<List<V>> values() {
        return this.map.values();
    }

    @Override
    public void add(K key, V value) {
        throw new UnsupportedOperationException();
    }

    @Override
    public V getFirst(K key) {
        return this.map.getFirst(key);
    }

    @Override
    public void putSingle(K key, V value) {
        throw new UnsupportedOperationException();
    }
}
