package nl.belastingdienst.iva.inzicht.domain;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.dataprovider.Result;

public class DomainUtils {

    public static final String UNDEFINED_ITEM = "undefined";
    public static final String NULL_ITEM = "null";
    public static final String UNKNOWN_ITEM = "unknown";
    public static final String EMPTY_ITEM = "";
    
    public static final String TRUE_ITEM = "true";
    public static final String FALSE_ITEM = "false";

    private static final MultivaluedMap<String, String> EMPTY_MULTIVALUEDMAP = new UnmodifiableMultiValuedMap<>(new MultiValuedHashMap<String, String>());
    private static final DataMap EMPTY_DATAMAP = new DataHashMap();
    private static final DataMap[] EMPTY_DATAMAPARRAY = new DataHashMap[0];
    private static final Result EMPTY_RESULT = new Result(Collections.emptyList(), DomainUtils.EMPTY_DATAMAP);
    
    private DomainUtils() {
        throw new UnsupportedOperationException();
    }
    
    public static MultivaluedMap<String, String> emptyMultivaluedMap() {
        return EMPTY_MULTIVALUEDMAP;
    }
    
    public static DataMap emptyDataMap() {
        return EMPTY_DATAMAP;
    }
    
    public static DataMap[] emptyDataMapArray() {
        return EMPTY_DATAMAPARRAY;
    }
    
    public static Result emptyResult() {
    	return EMPTY_RESULT;
    }
    
    public static boolean isUndefined(String value) {
    	return UNDEFINED_ITEM.equalsIgnoreCase(value) || NULL_ITEM.equalsIgnoreCase(value);
    }
    
    public static boolean isTrue(String value) {
    	return TRUE_ITEM.equalsIgnoreCase(value);
    }
    
    public static DataMap inMap(String key, Object value) {
    	DataMap dataMap = new DataHashMap();
    	dataMap.put(key, value);
    	return dataMap;
    }
    
    public static DataMap[] inArray(DataMap dataMap) {
    	DataMap[] dataMapArray = new DataHashMap[1];
        dataMapArray[0] = dataMap;
        return dataMapArray;
    }
    
    public static DataMap[] inArray(Collection<DataMap> dataMapCollection) {
        return dataMapCollection == null ? EMPTY_DATAMAPARRAY : dataMapCollection.toArray(EMPTY_DATAMAPARRAY);
    }

    @SafeVarargs
	public static <K, V> V getFirst(MultivaluedMap<K, V> multiValuedMap, K... keys) {
    	for (K key : keys) {
    		V value = multiValuedMap.getFirst(key);
    		if (value != null) {
    			return value;
    		}
    	}
    	
    	return null;
    }

	public static Object getFromNestedMap(Map<?, ?> dataMap, List<String> keys) {
		return getFromNestedMap(dataMap, keys, 0);
	}
	
	private static Object getFromNestedMap(Map<?, ?> dataMap, List<String> keys, int index) {
		Object value = dataMap.get(keys.get(index));
		int nextIndex = index + 1;
		
		if (nextIndex < keys.size()) {
			return value instanceof Map ? getFromNestedMap((Map<?, ?>) value, keys, nextIndex) : null;
		}
		
		return value;
	}
}
