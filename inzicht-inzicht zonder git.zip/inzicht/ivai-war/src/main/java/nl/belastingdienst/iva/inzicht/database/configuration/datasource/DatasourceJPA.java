package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;

@Entity
@Table(name = "CONF_DATASOURCE")
@NamedQuery(name = DatasourceJPA.QUERY_GETDATASOURCES, query = "SELECT d FROM DatasourceJPA d ORDER BY d.key")
public class DatasourceJPA {

    public static final String QUERY_GETDATASOURCES = "Datasource.getDatasources"; 
    
    @Id
    private Integer id;
    private String key;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "DATASOURCE_ID")
    private List<DatasourceParamJPA> parameterList;

    @Transient
    private Datasource datasource;

    public Integer getId() {
        return this.id;
    }
    
    public String getKey() {
        return this.key;
    }
    
    public List<DatasourceParamJPA> getParameterList() {
        return this.parameterList;
    }
    
    public Datasource getDatasource() {
        return this.datasource;
    }
    
    public void setDatasource(Datasource datasource) {
        this.datasource = datasource;
    }
}
