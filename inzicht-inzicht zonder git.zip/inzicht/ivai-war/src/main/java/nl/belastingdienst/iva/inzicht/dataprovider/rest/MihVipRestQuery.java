package nl.belastingdienst.iva.inzicht.dataprovider.rest;

import java.util.Collections;
import java.util.List;

import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryFilter;
import nl.belastingdienst.iva.inzicht.database.configuration.query.ResultMapper;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryType;

public class MihVipRestQuery implements QueryInterface {
    
    private String queryTemplate;
      
    public MihVipRestQuery(String queryTemplate) {
        this.queryTemplate = queryTemplate;
    }

    @Override
    public String getKey() {
        return null;
    }

    @Override
    public QueryType getType() {
        return QueryType.REST;
    }

    @Override
    public String getViewName() {
        return "";
    }

    @Override
    public String getQueryTemplate() {
        return this.queryTemplate;
    }

    @Override
    public List<QueryColumn> getQueryColumns() {
        return Collections.<QueryColumn>emptyList();
    }

    @Override
    public List<QueryFilter> getQueryFilters() {
        return Collections.<QueryFilter>emptyList();
    }

    @Override
    public Datasource getDatasource() {
        return null;
    }
    
    @Override
    public String getVipFilterColumnKey() {
        return null;
    }

    @Override
    public String getVipMaskColumnKey() {
        return null;
    }

    @Override
    public String getVipTagColumnKey() {
        return null;
    }

    @Override
    public List<String> getMaskableColumnKeys() {
        return Collections.<String>emptyList();
    }

    @Override
    public ResultMapper getResultMapper() {
        return null;
    }

    @Override
    public boolean hasDatasource() {
        return false;
    }
}
