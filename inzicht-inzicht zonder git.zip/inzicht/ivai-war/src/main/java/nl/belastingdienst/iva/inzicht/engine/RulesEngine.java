package nl.belastingdienst.iva.inzicht.engine;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.engine.action.ActionFactory;
import nl.belastingdienst.iva.inzicht.engine.condition.ConditionFactory;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class RulesEngine {

    @Inject
    private ConditionFactory conditionFactory;
    
    @Inject
    private ActionFactory actionFactory;
    
	public RestCallContext run(RuleInterface rule, RestCallContext restCallContext) {
		rule.apply(restCallContext);
		return restCallContext;
	}
	
	public ConditionFactory getConditionFactory() {
		return this.conditionFactory;
	}
	
	public ActionFactory getActionFactory() {
		return this.actionFactory;
	}
	
    public DataMap getStatus() {
        return DomainUtils.emptyDataMap();
    }
}
