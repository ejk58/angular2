package nl.belastingdienst.iva.inzicht.service.system;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.annotation.Resource;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.Version;
import nl.belastingdienst.iva.inzicht.domain.exception.NotAuthorizedException;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.monitor.MonitorFactory;
import nl.belastingdienst.iva.inzicht.notification.NotificationFactory;
import nl.belastingdienst.iva.inzicht.permission.PermissionFactory;
import nl.belastingdienst.iva.inzicht.releasenote.ReleaseNoteFactory;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;
import nl.belastingdienst.iva.inzicht.user.UserFactory;

@Stateless
@Path("/system")
@RolesAllowed({ RoleUtils.INZICHT_USER_ROLE })
public class SystemService extends AbstractRestService {

    @Resource
    private SessionContext sessionContext;

    @Inject
    private ConfigurationFactory configurationFactory;

    @Inject
    private UserFactory userFactory;

    @Inject
    private PermissionFactory permissionFactory;

    @Inject
    private MonitorFactory monitorFactory;

    @Inject
    private NotificationFactory notificationFactory;

    @Inject
    private ReleaseNoteFactory releaseNoteFactory;

    @GET
    @Produces({ MediaType.APPLICATION_JSON })
    public Response getStatus(@Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.SYSTEMSERVICE, queryValues);
        
        try {
        	executeCommand(restCallContext);
        	createStatus(restCallContext);
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }

    @GET
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/configuration")
    public Response getConfiguration() {
        return Response.ok(this.configurationFactory.getStatus()).build();
    }

    @GET
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/version")
    public Response getVersion() {
        return Response.ok(Version.INSTANCE.getVersion()).build();
    }

    @GET
    @PermitAll
    @Produces({ MediaType.APPLICATION_JSON })
    @Path("/isalive")
    public Response isAlive() {
        RestCallContext restCallContext = buildUnauthenticatedRestCallContext(RestServiceType.ALIVESERVICE);
        
        try {
            DataMap components = new DataHashMap();
            components.put(ResponseKey.CONFIGURATION, getComponentDuration(() -> this.configurationFactory.getStatus()));
            components.put(ResponseKey.USER, getComponentDuration(() -> this.userFactory.getStatus()));
            components.put(ResponseKey.PERMISSION, getComponentDuration(() -> this.permissionFactory.getStatus()));
            
            DataMap status = new DataHashMap();
        	status.put(ResponseKey.COMPONENTS, components);
        	status.put(ResponseKey.SERVERNAME, getHostName());
        	status.put(ResponseKey.ALIVE, true);
        
        	restCallContext.setResponse(status);
	        return buildResponse(restCallContext);
	    } catch (Exception exception) {
	        return handleException(exception, restCallContext);
	    }
    }

    private RestCallContext buildUnauthenticatedRestCallContext(RestServiceType serviceType) {
    	MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>();
        Configuration configuration = this.configurationFactory.getConfiguration();
        return buildRestCallContext(serviceType, queryValues, configuration, null);
    }
    
    private void executeCommand(RestCallContext restCallContext) {
        executeReload(restCallContext, QueryValueKey.RELOADCONFIGURATION, ConfigurationKey.CONFIGURATIONRELOADALLOWED, 
        		"configuration", () -> this.configurationFactory.update());

        executeReload(restCallContext, QueryValueKey.RELOADNOTIFICATIONS, ConfigurationKey.CONFIGURATIONRELOADALLOWED, 
        		"notifications", () -> this.notificationFactory.update());

        executeReload(restCallContext, QueryValueKey.RELOADRELEASENOTES, ConfigurationKey.CONFIGURATIONRELOADALLOWED, 
        		"release notes", () -> this.releaseNoteFactory.update());
    }
    
    private void executeReload(RestCallContext restCallContext, String queryValueKey, String configurationKey, String name, 
    		Runnable updateMethod) {
        Configuration configuration = restCallContext.getConfiguration();
    	
        if (DomainUtils.isTrue(restCallContext.getFirstQueryValue(queryValueKey))) {
            if (!Boolean.TRUE.equals(configuration.getValueAsBoolean(configurationKey))) {
            	throw new NotAuthorizedException("This rest-service is not permitted to reload the " + name + ".");
            }
            
            updateMethod.run();
        }
    }
    
    private void createStatus(RestCallContext restCallContext) {
        DataMap status = new DataHashMap();

        status.put(ResponseKey.VERSION, Version.INSTANCE.getVersion());
        status.put(ResponseKey.CONFIGURATION, this.configurationFactory.getStatus());
        status.put(ResponseKey.USER, this.userFactory.getStatus());
        status.put(ResponseKey.PERMISSION, this.permissionFactory.getStatus());
        status.put(ResponseKey.MONITOR, this.monitorFactory.getStatus());
        status.put(ResponseKey.NOTIFICATION, this.notificationFactory.getStatus());
        status.put(ResponseKey.RELEASENOTE, this.releaseNoteFactory.getStatus());
    	status.put(ResponseKey.SERVERNAME, getHostName());

    	restCallContext.setResponse(status);
    }
    
    private String getHostName() {
		try {
			return InetAddress.getLocalHost().toString();
		} catch (UnknownHostException exception) {
			return "Onbekend";
		}
    }

    private long getComponentDuration(Runnable runnable) {
    	long beginTime = System.currentTimeMillis();
    	runnable.run();
    	return System.currentTimeMillis() - beginTime;
    }
}
