package nl.belastingdienst.iva.inzicht.engine.condition;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.AbstractRuleFactory;

public class ConditionFactory extends AbstractRuleFactory<Condition> {

	private Map<String, Function<List<String>, Condition>> conditionBuilderMap;
	
	public ConditionFactory() {
		initialize();
	}
	
	public Condition getCondition(String operator, List<Condition> conditionList) {
		if (RulesEngineKey.ANDCONDITIONOPERATOR.equals(operator)) {
			return new AndCondition(conditionList);
		} else if (RulesEngineKey.ORCONDITIONOPERATOR.equals(operator)) {
			return new OrCondition(conditionList);
		}
		
		throw new IllegalArgumentException("The operator '" + operator + "' is unrecognized in the condition-parser.");
	}

	public Condition getCondition(String operator, Condition condition) {
		if (RulesEngineKey.NOTCONDITIONOPERATOR.equals(operator)) {
			return new NotCondition(condition);
		}
		
		throw new IllegalArgumentException("The unary operator '" + operator + "' is unrecognized in the condition-parser.");
	}
	
	public Condition getCondition(String conditionDescription) {
		return super.get(conditionDescription);
	}
	
	@Override
	protected Condition build(String name, List<String> parameters) {
		Function<List<String>, Condition> conditionBuilder = this.conditionBuilderMap.get(name);
		
		if (conditionBuilder == null) {
			throw new IllegalArgumentException("The condition '" + name + "' condition is unrecognized in the condition-factory.");
		}
		
		return conditionBuilder.apply(parameters);
	}
	
	private void initialize() {
		this.conditionBuilderMap = new HashMap<>();
		
		this.conditionBuilderMap.put(AlwaysTrueCondition.NAME, (List<String> parameters) -> new AlwaysTrueCondition());
		
        this.conditionBuilderMap.put(AnyQueryValueEqualsCondition.NAME, (List<String> parameters) -> {
            String key = getParameter(parameters, 0);
            String value = getParameter(parameters, 1);
            return new AnyQueryValueEqualsCondition(key, value);
        });
        
		this.conditionBuilderMap.put(FirstQueryValueEqualsCondition.NAME, (List<String> parameters) -> {
			String key = getParameter(parameters, 0);
			String value = getParameter(parameters, 1);
			return new FirstQueryValueEqualsCondition(key, value);
		});
		
        this.conditionBuilderMap.put(FirstQueryValueLargerThanCondition.NAME, (List<String> parameters) -> {
            String key = getParameter(parameters, 0);
            String value = getParameter(parameters, 1);
            return new FirstQueryValueLargerThanCondition(key, value);
        });
        
		this.conditionBuilderMap.put(QueryValuePresentCondition.NAME, (List<String> parameters) -> {
			String key = getParameter(parameters, 0);
			return new QueryValuePresentCondition(key);
		});
		
		this.conditionBuilderMap.put(ResultContainsColumnValueCondition.NAME, (List<String> parameters) -> {
			String resultColumnDescription = getParameter(parameters, 0);
			List<String> resultColumn = Arrays.asList(resultColumnDescription.split("/"));
			String value = getParameter(parameters, 1);
			return new ResultContainsColumnValueCondition(resultColumn, value);
		});
	}	
}
