package nl.belastingdienst.iva.inzicht.domain.releasenote;

import java.util.Comparator;

public class ReleaseNoteComparator implements Comparator<ReleaseNote> {

	private static final int ASCENDING = 1;
	private static final int DESCENDING = -1;

	private VersionComparator versionComparator;
	
	public ReleaseNoteComparator() {
		this.versionComparator = new VersionComparator();
	}
	
	@Override
	public int compare(ReleaseNote releaseNote, ReleaseNote otherReleaseNote) {
		int result = compareVersions(releaseNote.getVersion(), otherReleaseNote.getVersion(), DESCENDING);

		if (result == 0) {
			result = compareDomains(releaseNote.getDomainIndex(), otherReleaseNote.getDomainIndex(), ASCENDING);
		}
		
		if (result == 0) {
			result = compareAttributes(releaseNote.getType(), otherReleaseNote.getType(), ASCENDING);
		}
		
		if (result == 0) {
			result = compareAttributes(releaseNote.getDescription(), otherReleaseNote.getDescription(), ASCENDING);
		}
		
		return result;
	}
	
	private int compareAttributes(String attribute, String otherAttribute, int sortOrder) {
		String element = attribute == null ? "" : attribute;
		String otherElement = otherAttribute == null ? "" : otherAttribute;
		return element.compareTo(otherElement) * sortOrder;
	}
	
	private int compareDomains(Integer domainIndex, Integer otherDomainIndex, int sortOrder) {
		int result;
		
		if (domainIndex != null) {
			result = (otherDomainIndex == null) ? -1 : domainIndex.compareTo(otherDomainIndex);
		} else {
			result = (otherDomainIndex == null) ? 0 : 1;
		}
		
		return result * sortOrder;
	}
	
	private int compareVersions(String version, String otherVersion, int sortOrder) {
		int reversedSortOrder = -1 * sortOrder;
		return this.versionComparator.compare(version, otherVersion) * reversedSortOrder;
	}
}
