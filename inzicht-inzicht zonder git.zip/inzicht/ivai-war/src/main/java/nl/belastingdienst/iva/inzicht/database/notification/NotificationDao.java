package nl.belastingdienst.iva.inzicht.database.notification;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

public class NotificationDao {

	@PersistenceContext(unitName = "ivai-pu-inzicht")
	private EntityManager entityManager;

	public List<Notification> getNotificationMessages() {
		TypedQuery<Notification> query = entityManager.createNamedQuery(Notification.QUERY_GETNOTIFICATION, Notification.class);
		return query.getResultList();
	}
}
