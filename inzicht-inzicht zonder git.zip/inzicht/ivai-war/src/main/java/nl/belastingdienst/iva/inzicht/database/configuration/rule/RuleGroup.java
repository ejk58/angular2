package nl.belastingdienst.iva.inzicht.database.configuration.rule;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import nl.belastingdienst.iva.inzicht.engine.MultipleRule;

@Entity
@Table(name = "CONF_RULE_GROUP")
@NamedQuery(name = RuleGroup.QUERY_GETRULEGROUPS, query = "SELECT r FROM RuleGroup r ORDER BY r.key")
public class RuleGroup {

	public static final String QUERY_GETRULEGROUPS = "RuleGroup.getRuleGroups";
	
	@Id
	private Integer id;
	
	private String key;
	
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "RULE_GROUP_ID")
    @OrderBy("index ASC")
    private List<Rule> ruleList;

    @Transient
    private MultipleRule rule;
    
	public Integer getId() {
		return this.id;
	}

	public String getKey() {
		return this.key;
	}

	public List<Rule> getRuleList() {
		return this.ruleList;
	}

	public MultipleRule getRule() {
		return this.rule;
	}

	public void setRule(MultipleRule rule) {
		this.rule = rule;
	}
}
