package nl.belastingdienst.iva.inzicht.domain;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.stream.Location;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.log4j.Logger;

import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;

public class XmlMapper {

    private static final String EMPTY_PATH = "";
    private static final String DIVIDER = "/";

    private static final Logger logger = Logger.getLogger(XmlMapper.class);

    public DataMap[] mapToDataMapArray(String description, String key, String object) {
        return mapToDataMapArray(description, "", key, object);
    }

    public DataMap[] mapToDataMapArray(String description, String basePath, String key, String object) {
        Map<String, String> elementPathMap = new HashMap<>();
        elementPathMap.put(EMPTY_PATH, key);

        return mapToDataMapArray(description, basePath, elementPathMap, object);
    }

    public DataMap[] mapToDataMapArray(String description, String basePath, Map<String, String> elementPaths, String object) {
        XMLStreamReader streamReader = null;
        boolean hasBasePath = basePath != null && !EMPTY_PATH.equals(basePath);
        List<DataMap> data = new ArrayList<>();

        try {
            streamReader = getXmlStreamReader(object);
            data = hasBasePath ? parseBasePath(streamReader, basePath, elementPaths) : skipBasePath(streamReader, elementPaths);
        } catch (XMLStreamException exception) {
            String message = createExceptionMessage("Failed to parse the " + description, exception, object);
            throw new InternalServerErrorException(message, exception);
        } catch (XmlMapperException exception) {
            String message = createXmlMapperExceptionMessage("Failed to map the " + description, exception, object);
            throw new InternalServerErrorException(message, exception);
        } finally {
            if (streamReader != null) {
                try {
                    streamReader.close();
                } catch (XMLStreamException exception) {
                    String message = MessageUtils.createMessage(MessageType.ERROR, "Failed to close the XML stream reader");
                    logger.error(message, exception);
                }
            }
        }

        return DomainUtils.inArray(data);
    }

    private List<DataMap> parseBasePath(XMLStreamReader streamReader, String basePath, Map<String, String> elementPaths) throws XMLStreamException, XmlMapperException {
        StringBuilder currentPath = new StringBuilder(EMPTY_PATH);
        List<DataMap> data = new ArrayList<>();
        boolean hasElements = !elementPaths.containsKey(EMPTY_PATH);

        while (streamReader.hasNext()) {
            if (streamReader.isStartElement()) {
                currentPath.append("/").append(streamReader.getLocalName());

                if (basePath.equals(currentPath.toString())) {
                    data.add(hasElements ? parseElementPaths(streamReader, elementPaths) : skipElementPaths(streamReader, elementPaths));
                }
            }

            if (streamReader.isEndElement()) {
                currentPath.delete(currentPath.lastIndexOf("/"), currentPath.length());
            }

            streamReader.next();
        }

        return data;
    }

    private List<DataMap> skipBasePath(XMLStreamReader streamReader, Map<String, String> elementPaths) throws XMLStreamException, XmlMapperException {
        List<DataMap> data = new ArrayList<>();
        boolean hasElements = !elementPaths.containsKey(EMPTY_PATH);
        data.add(hasElements ? parseElementPaths(streamReader, elementPaths) : skipElementPaths(streamReader, elementPaths));
        return data;
    }

    private DataMap parseElementPaths(XMLStreamReader streamReader, Map<String, String> elementPaths) throws XMLStreamException, XmlMapperException {
        StringBuilder currentPath = new StringBuilder();
        DataMap dataMap = new DataHashMap();
        boolean isInsideElementLoop = true;

        streamReader.next();
        while (isInsideElementLoop && streamReader.hasNext()) {

            if (streamReader.isStartElement()) {
                currentPath.append(DIVIDER).append(streamReader.getLocalName());

                String key = elementPaths.get(currentPath.toString());
                if (key != null) {
                    Object value = parseObject(streamReader, 1);
                    dataMap.put(key, value);
                }
            }

            if (streamReader.isEndElement()) {
                isInsideElementLoop = (currentPath.length() > 0);

                if (isInsideElementLoop) {
                    currentPath.delete(currentPath.lastIndexOf("/"), currentPath.length());
                }
            }

            if (isInsideElementLoop) {
                streamReader.next();
            }
        }

        return dataMap;
    }

    private DataMap skipElementPaths(XMLStreamReader streamReader, Map<String, String> elementPaths) throws XMLStreamException, XmlMapperException {
        String key = elementPaths.get(EMPTY_PATH);
        Object value = parseObject(streamReader, 1);
        DataMap dataMap = null;

        if (key != null) {
            dataMap = new DataHashMap();
            dataMap.put(key, value);
        } else if (value instanceof DataMap) {
            dataMap = (DataMap) value;
        } else {
            String message = "Failed to store the result in a map because the result is not an object";
            throw new XmlMapperException(message);
        }

        return dataMap;
    }

    private Object parseObject(XMLStreamReader streamReader, int count) throws XMLStreamException, XmlMapperException {
        Object object = null;

        streamReader.next();
        while (streamReader.hasNext() && !streamReader.isEndElement()) {
            if (streamReader.isStartElement()) {
                object = parseInnerObject(streamReader, object, count);
            } else if (streamReader.isCharacters()) {
                object = parseCharacters(streamReader, object, count);
            }

            streamReader.next();
        }

        return object;
    }

    private Object parseInnerObject(XMLStreamReader streamReader, Object object, int count) throws XMLStreamException, XmlMapperException {
        if (object != null && !(object instanceof DataMap)) {
            String message = "Failed to parse the object from XML because it contains mixed contents";
            Location location = streamReader.getLocation();
            throw new XmlMapperException(message, location);
        }

        DataMap dataMap = (object instanceof DataMap) ? (DataMap) object : new DataHashMap();
        String key = streamReader.getLocalName();
        Object value = parseObject(streamReader, count + 1);
        dataMap.put(key, value);
        return dataMap;
    }

    private Object parseCharacters(XMLStreamReader streamReader, Object object, int count) throws XmlMapperException {
        String text = streamReader.getText().trim();

        if (text.length() > 0 && object != null) {
            String message = "Failed to parse the object from XML because it contains mixed contents";
            Location location = streamReader.getLocation();
            throw new XmlMapperException(message, location);
        }

        return (text.length() > 0) ? text : object;
    }

    private XMLStreamReader getXmlStreamReader(String object) throws XMLStreamException {
        InputStream objectStream = (object == null) ? null : new ByteArrayInputStream(object.getBytes());
        XMLStreamReader streamReader = null;

        if (objectStream != null) {
            XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
            xmlInputFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, ""); // To protect Java XML Parsers from XXE attacks
            xmlInputFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, ""); // To protect Java XML Parsers from XXE attacks
            streamReader = xmlInputFactory.createXMLStreamReader(objectStream);
        }

        return streamReader;
    }

    private String createXmlMapperExceptionMessage(String description, XmlMapperException exception, Object object) {
        return description + " at character offset " + exception.getCharacterOffset() +
                " with error message '" + exception.getMessage() +
                "' (object = '" + object + "')";
    }

    private String createExceptionMessage(String description, Exception exception, Object object) {
        return description + " with exception " +
                ExceptionUtils.getExceptionsForMessage(exception) +
                " (cause = '" + exception.getCause() +
                "', message = '" + exception.getMessage() +
                "', object = '" + object + "')";
    }
}
