package nl.belastingdienst.iva.inzicht.service.notification;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.notification.Notification;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.notification.NotificationFactory;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/notification")
@RolesAllowed({ RoleUtils.INZICHT_USER_ROLE })
public class NotificationService extends AbstractRestService {

	@Inject
	private NotificationFactory notificationFactory;

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getNotifications(@Context UriInfo uriInfo) {
		MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
		RestCallContext restCallContext = buildRestCallContext(RestServiceType.NOTIFICATIONSERVICE, queryValues);

		try {
			checkRequiredRoles(restCallContext);
			restCallContext.setResponse(getNotifications(restCallContext));
			return buildResponse(restCallContext);
		} catch (Exception exception) {
			return handleException(exception, restCallContext);
		}
	}

	private List<Notification> getNotifications(RestCallContext restCallContext) {
		MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
		String domainKey = queryValues.getFirst(QueryValueKey.DOMAINKEY);
		String pageKey = queryValues.getFirst(QueryValueKey.PAGEKEY);
		return this.notificationFactory.filterNotifications(domainKey, pageKey);
	}
}
