package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class SetWidgetAttributeAction implements Action {

	public static final String NAME = "SetWidgetAttribute";

	private String key;
	private String value;
	
	public SetWidgetAttributeAction(String key, String value) {
		this.key = key;
		this.value = value;
	}
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
	    Object widgetResponse = restCallContext.getResponse();
	    
	    if (widgetResponse instanceof DataMap) {
	        DataMap widgetMap = (DataMap) widgetResponse;
	        Object optionsResponse = widgetMap.get(ResponseKey.OPTIONS);
	        
	        if (optionsResponse instanceof DataMap) {
	            DataMap optionsMap = (DataMap) optionsResponse;
	            optionsMap.put(this.key, this.value);
	        }
	    }
	    
		return Flow.CONTINUE;
	}
	
	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.key + 
				(this.value == null ? "" : RulesEngineKey.PARAMETERSEPARATOR + this.value) + RulesEngineKey.PARAMETEREND;
	}
}
