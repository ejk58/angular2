package nl.belastingdienst.iva.inzicht.engine;

import java.util.ArrayList;
import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.domain.rule.GroupCharacter;
import nl.belastingdienst.iva.inzicht.domain.rule.RuleUtils;

public abstract class AbstractRuleFactory<T> {

	protected T get(String description) {
		String name = getName(description);
		List<String> parameters = getParameters(description);
		return build(name, parameters);
	}
	
	protected abstract T build(String name, List<String> parameters);
	
	protected String getParameter(List<String> parameters, int index) {
		String parameter = parameters.get(index);
		return parameter == null ? null : parameter.trim();
	}
	
	private String getName(String description) {
		int index = description.indexOf(RulesEngineKey.PARAMETERSTART);
		return description.substring(0, index);
	}
	
	private List<String> getParameters(String description) {
		String parameterDescription = getParameterDescription(description);
		List<String> parameters = new ArrayList<>();
		int startIndex = 0;
		int index = 0;
		
		while (index < parameterDescription.length()) {
			
			if (RuleUtils.findAtIndex(parameterDescription, RulesEngineKey.PARAMETERSEPARATOR, index)) {
				if (index - startIndex > 0) {
					parameters.add(parameterDescription.substring(startIndex, index));
				}
				startIndex = index + 1;
			}

			if (RuleUtils.findGroupStartAtIndex(parameterDescription, GroupCharacter.ALL, index)) {
				index = RuleUtils.getEndOfGroupIndex(parameterDescription, GroupCharacter.ALL, index);
			} else {
				index++;
			}
		}
		
		if (index - startIndex > 0) {
			parameters.add(parameterDescription.substring(startIndex, index));
		}
		
		return parameters;
	}

	private String getParameterDescription(String description) {
		int startIndex = description.indexOf(RulesEngineKey.PARAMETERSTART);
		int endIndex = description.lastIndexOf(RulesEngineKey.PARAMETEREND);

		if (endIndex <= startIndex) {
			throw new IllegalArgumentException("The closing parenthesis in the condition or action '" + description + "' appears to be missing.");
		}

		return description.substring(startIndex + 1, endIndex);
	}
}
