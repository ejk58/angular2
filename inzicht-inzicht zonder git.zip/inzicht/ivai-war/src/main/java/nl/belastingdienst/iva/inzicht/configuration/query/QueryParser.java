package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;

public class QueryParser {

	private ColumnMapperFactory columnMapperFactory;
	
	public QueryParser(Map<String, AttributeGroup> attributeGroupMap) {
		this.columnMapperFactory = new ColumnMapperFactory(attributeGroupMap);
	}
	
    public void parse(List<Query> queryList) {
        for (Query query : queryList) {
            addColumnInformation(query);
            addVipColumns(query);
            addResultMapper(query);
        }
    }
    
	private void addColumnInformation(Query query) {
		for (QueryColumn column : query.getQueryColumns()) {
			column.setPartial(false);
		}
		
		for (QueryColumn column : query.getQueryColumns()) {
			column.determinePartialColumns();
		}
	}
	
	private void addVipColumns(Query query) {
	    List<String> maskableColumnKeys = new ArrayList<>();

		for (QueryColumn column : query.getQueryColumns()) {
		    if (column.isMaskable()) {
		        maskableColumnKeys.add(column.getDestinationKey());
		    }
		    
		    if (column.isVipFilter()) {
		        query.setVipFilterColumnKey(column.getDestinationKey());
		    }
            
            if (column.isVipMask()) {
                query.setVipMaskColumnKey(column.getDestinationKey());
            }
            
            if (column.isVipTag()) {
                query.setVipTagColumnKey(column.getDestinationKey());
            }
		}
		
		if (!maskableColumnKeys.isEmpty()) {
		    query.setMaskableColumnKeys(maskableColumnKeys);
		}
	}
	
	private void addResultMapper(Query query) {
		List<ColumnMapper> columnMapperList = new ArrayList<>();
		
		for (QueryColumn column : query.getQueryColumns()) {
			if (!column.isPartial()) {
				columnMapperList.add(this.columnMapperFactory.getColumnMapper(query, column));
			}
		}
		
		query.setResultMapper(new SimpleResultMapper(columnMapperList));
	}
}
