@Library("GENERIC") _
    pipelineDeployArtifactFromNexus {
	deploymentId = "inzicht"
	integrationPipeline = "inzicht-test"
	packageChoices = "inzicht"
	applicationVersionChoices = "3.68.1\n3.68.0\n3.67.0\n3.66.0\n3.65.0"
	asVersionChoices = "n.v.t"
	environmentChoices = "tst\nont\nacc\nprd"
	streetChoices = "str11/productie\nstr12/opleiding\nstr13\nstr14"
}
