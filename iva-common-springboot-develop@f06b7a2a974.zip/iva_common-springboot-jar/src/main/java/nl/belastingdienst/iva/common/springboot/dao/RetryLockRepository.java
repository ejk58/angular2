package nl.belastingdienst.iva.common.springboot.dao;

import nl.belastingdienst.iva.common.springboot.domain.RetryLock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;

import javax.persistence.LockModeType;

@Repository
public interface RetryLockRepository extends JpaRepository<RetryLock, Long> {
	@Lock(LockModeType.PESSIMISTIC_READ)
	RetryLock findFirstByIdGreaterThan(Long id);
}
