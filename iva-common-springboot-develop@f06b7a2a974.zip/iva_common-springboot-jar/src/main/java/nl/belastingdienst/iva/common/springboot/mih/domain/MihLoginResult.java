package nl.belastingdienst.iva.common.springboot.mih.domain;

import lombok.Data;

@Data
public class MihLoginResult {
    private String jsonWebToken;
}
