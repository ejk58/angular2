package nl.belastingdienst.iva.common.springboot.kta;

import lombok.Data;

/**
 * DTO voor zoeken naar entiteiten in KTA laag
 *
 * @author denee00
 */
@Data
public class EntiteitSearchDTO {
	private Integer entiteitNummer;
	private Integer kantoorCode;
	private String kantoorNaam;
	private String teamOmschrijving;
	private String naam;
	private String teamCode;
	private Integer maxResults;
}
