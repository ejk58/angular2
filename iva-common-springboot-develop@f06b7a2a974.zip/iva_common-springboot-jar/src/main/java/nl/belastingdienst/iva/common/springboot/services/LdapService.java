package nl.belastingdienst.iva.common.springboot.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import nl.belastingdienst.iva.common.springboot.exceptions.NotFoundException;
import nl.belastingdienst.iva.common.springboot.security.LdapGroup;
import nl.belastingdienst.iva.common.springboot.security.LdapGroupAttributesMapper;
import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.security.LdapPersonAttributesMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Scope(value = "singleton")
@Log4j2
@RequiredArgsConstructor
public class LdapService {

	private static int blockSize = 1450; //Intentionally 50 less than current max
	private static final String cacheName = "ldap";

	private final Environment environment;
	private final LdapTemplate ldapTemplate;
	private final CacheManager cacheManager;

	@Scheduled(cron = "0 0 0 * * *") // Clear at midnight
	public void killLdapCache() {
		log.info("Ldap cache clear");
		cacheManager.getCache(cacheName).clear();
	}

	public List<LdapPerson> getPersons(String userid) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
				.like(userid.trim() + "*");
		return ldapTemplate.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));
	}

	public List<LdapPerson> getPersonByLastNameOrUserId(String searchString) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and(
						LdapQueryBuilder.query().where("sn").like("*" + searchString + "*").or("cn").like( searchString + "*"));
		return ldapTemplate.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));
	}

	@Cacheable(value = cacheName)
	public List<LdapPerson> getPersonsInBothGroups(String smallGroup, List<String> largeGroup) {
		LdapGroup smallLdapGroup = getGroup(smallGroup);
		LdapGroup largeLdapGroup = getGroups(largeGroup);

		return (smallLdapGroup != null && largeLdapGroup != null) ?
				getPersonList(smallLdapGroup, largeLdapGroup) :
				Collections.emptyList();
	}

	private List<LdapPerson> getPersonList(LdapGroup smallLdapGroup, LdapGroup largeLdapGroup) {
		return largeLdapGroup.getMembers().stream().filter(m -> smallLdapGroup.getMembers().contains(m)).map(this::getPerson)
				.filter(p -> p != null).sorted(Comparator.comparing(LdapPerson::getUserId)).collect(Collectors.toList());
	}

	private LdapGroup getGroups(List<String> augGroepen) {
		LdapGroup result = new LdapGroup();
		result.setMembers(new ArrayList<>());
		augGroepen.forEach(groep -> {
			LdapGroup ldapGroup = this.getGroup(groep);
			if (ldapGroup != null) {
				ldapGroup.getMembers().stream().forEach(member -> {
					if (!result.getMembers().contains(member)) {
						result.getMembers().add(member);
					}
				});
			}
		});
		return result;
	}

	public LdapGroup getGroup(String augGroup) {
		int blockNr = 0;
		LdapGroup result = new LdapGroup();
		result.setMembers(new ArrayList<>());
		LdapGroup tempResult = null;

		do {
			tempResult = getBlock(augGroup, blockSize, blockNr);
			if (tempResult != null) {
				result.setName(tempResult.getName());
				result.getMembers().addAll(tempResult.getMembers());
			}
			blockNr++;
		} while (tempResult != null && tempResult.getMembers().size() == blockSize);
		result.getMembers().sort(String::compareToIgnoreCase);
		return result;
	}

	private LdapGroup getBlock(String augGroup, int blockSize, int blockNr) {
		LdapGroup result = null;
		int start = blockNr * blockSize;
		int einde = start + blockSize - 1;
		String range = String.format("member;range=%d-%d", start, einde);
		log.debug("Range is {}", range);
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).attributes("cn", range)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("group").and("cn").is(augGroup);
		List<LdapGroup> adGroepen = ldapTemplate.search(query, new LdapGroupAttributesMapper());
		if (adGroepen.size() == 1) {
			result = adGroepen.get(0);
		}
		return result;
	}

	/**
	 * @param userid
	 * 		A partial userid (A * will be added)
	 * @return A list of persons matching this string
	 */
	public List<LdapPerson> findPersons(String userid) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
				.like(userid.trim() + "*");
		return ldapTemplate.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));

	}

	public LdapPerson getPerson(String userid) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(100)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
				.is(userid.trim());
		List<LdapPerson> ldapPersonList = ldapTemplate
				.search(query, new LdapPersonAttributesMapper(environment.getProperty("ldap.emailKey")));
		return ldapPersonList == null || ldapPersonList.size() == 0 ? null : ldapPersonList.get(0);
	}

	public boolean isAdGroep(String werkgroep) {
		LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE)
				.base(environment.getProperty("ldap.partitionSuffix")).where("objectclass").is("group").and("cn").is(werkgroep);
		List<LdapGroup> adGroepen = ldapTemplate.search(query, new LdapGroupAttributesMapper());
		return adGroepen.size() == 1;
	}

	public List<LdapPerson> getPersonsFromAugGroup(String augGroup) {
		List<LdapPerson> result = new ArrayList<>();
		getGroup(augGroup).getMembers().forEach(userId -> result.add(getPerson(userId)));
		return result;
	}
}
