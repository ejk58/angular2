package nl.belastingdienst.iva.common.springboot.security;

import java.util.Arrays;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import org.springframework.ldap.core.AttributesMapper;

public class LdapPersonAttributesMapper implements AttributesMapper<LdapPerson> {

	private String emailKey = null;

	public LdapPersonAttributesMapper(String emailKey) {
		this.emailKey = emailKey;
	}

	public LdapPersonAttributesMapper() {
		// default
	}

	@Override
	public LdapPerson mapFromAttributes(Attributes attributes) throws NamingException {
		LdapPerson person = new LdapPerson();
		person.setUserId((String) attributes.get("cn").get());
		if (attributes.get("displayName") != null) {
			person.setName((String) attributes.get("displayName").get());
		}
		if (emailKey != null && attributes.get(emailKey) != null)
			person.setEmail((String) attributes.get(emailKey).get());
		Attribute memberAttribute = attributes.get("memberof");
		if (memberAttribute != null) {
			NamingEnumeration<?> groups = attributes.get("memberof").getAll();
			while (groups.hasMore()) {
				String cn = (String) groups.next();
				Arrays.stream(cn.split(","))
						.filter(e -> e.contains("CN="))
						.forEach(e -> person.getAdGroepen().add(e.substring(3).toUpperCase()));
			}
		}
		return person;
	}
}
