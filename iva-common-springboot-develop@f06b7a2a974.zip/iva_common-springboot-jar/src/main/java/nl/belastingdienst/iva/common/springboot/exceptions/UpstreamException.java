package nl.belastingdienst.iva.common.springboot.exceptions;

public class UpstreamException extends RuntimeException {
	private static final long serialVersionUID = -1L;

	public UpstreamException(String message) {
		super(message);
	}
}
