package nl.belastingdienst.iva.common.springboot.mih.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MihLogin {
    private String username;
    private String password;
}
