package nl.belastingdienst.iva.common.springboot.kta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.core.env.Environment;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import nl.belastingdienst.iva.common.springboot.domain.CompetentKantoor;
import nl.belastingdienst.iva.common.springboot.domain.EntiteitPersonenResult;
import nl.belastingdienst.iva.common.springboot.domain.NaamNummerDTO;
import nl.belastingdienst.iva.common.springboot.domain.PersoonDTO;
import nl.belastingdienst.iva.common.springboot.exceptions.ConfigurationException;
import nl.belastingdienst.jacob.encryption.service.EncryptionService;
import nl.belastingdienst.jacob.encryption.service.EncryptionServiceException;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class KtaClient {
	private static final String SCHEMA = ".schema";



	private static final String SQL_ENTITY = ".VW150_KZB_ACTUELE_ENTITEIT_PERSOON_ACTIVITEIT WHERE DOSNR = ? "
			+ "AND VERVDAT_REL >= CONCAT(YEAR(current timestamp - 5 YEARS), '-01-01') "
			+ "AND ACTIVITEIT_EINDDAT >= CONCAT(YEAR(current timestamp - 5 YEARS), '-01-01') "
			+ "ORDER BY BSN, ACTIVITEIT_MIDDEL, ACTIVITEIT_VOLGNR";

	private static final String SQL_ENTITY_NO_RESTRICT = ".VW150_KZB_ACTUELE_ENTITEIT_PERSOON_ACTIVITEIT WHERE DOSNR = ? "
			+ "ORDER BY BSN, ACTIVITEIT_MIDDEL, ACTIVITEIT_VOLGNR";

	private static final String SQL_PERSON = ".VW150_KZB_ACTUELE_ENTITEIT_PERSOON_ACTIVITEIT WHERE BSN = ? "
			+ "AND ((VERVDAT_REL >= CONCAT(YEAR(current timestamp - 5 YEARS), '-01-01') "
			+ "AND ACTIVITEIT_EINDDAT >= CONCAT(YEAR(current timestamp - 5 YEARS), '-01-01')) "
			+ "OR (INGDAT_REL IS NULL AND VERVDAT_REL IS NULL)) "
			+ "ORDER BY ACTIVITEIT_MIDDEL, ACTIVITEIT_VOLGNR";

	private static final String SQL_PERSON_NO_RESTRICT = ".VW150_KZB_ACTUELE_ENTITEIT_PERSOON_ACTIVITEIT WHERE BSN = ? "
			+ "ORDER BY ACTIVITEIT_MIDDEL, ACTIVITEIT_VOLGNR";



	private final Environment env;
	private final String prefix;
	private HikariDataSource ds;

	public KtaClient(Environment env, String prefix) {
		this.env = env;
		this.prefix = prefix;

		String driverClass = env.getRequiredProperty(prefix + ".driverClassName");
		String url = env.getRequiredProperty(prefix + ".jdbcUrl");
		String user = env.getRequiredProperty(prefix + ".username");
		String pw = env.getRequiredProperty(prefix + ".password");

		HikariConfig config = new HikariConfig();
		try {
			Class.forName(driverClass);
			config.setJdbcUrl(url);
			config.setUsername(user);
			config.setPassword(new EncryptionService().decrypt(pw));
			this.ds = new HikariDataSource(config);
		} catch (ClassNotFoundException e) {
			throw new ConfigurationException("Problem finding the driver manager class '" + driverClass + "'. ");
		} catch (EncryptionServiceException e) {
			throw new ConfigurationException("Problem decrypting password.");
		}
	}

	public CompetentKantoor getCompetentKantoor(Integer dosnr) {
		String sql = "SELECT KANTOOR_ID, DOSTEAM FROM " + env.getRequiredProperty(prefix + SCHEMA)
				+ ".VW048_ENTITEIT_BASISGEGEVENS WHERE DOSNR = ?";
		CompetentKantoor ret = getCompetentKantoorFromDb(dosnr, sql);
		if (ret.getKantoorId() == null) {
			sql = "SELECT hist.KANTOOR_ID, hist.DOSTEAM FROM " + env.getRequiredProperty(prefix + SCHEMA)
					+ ".VW118_VERVALLEN_ENTITEIT_BASISGEGEVENS hist WHERE hist.DOSNR = ? AND hist.VERVDAT = "
					+ "(SELECT MAX(hist2.VERVDAT) FROM " + env.getRequiredProperty(prefix + SCHEMA)
					+ ".VW118_VERVALLEN_ENTITEIT_BASISGEGEVENS hist2 WHERE hist2.DOSNR = hist.DOSNR)";
			ret = getCompetentKantoorFromDb(dosnr, sql);
		}
		return ret;
	}

	public NaamNummerDTO getNaamPersoon(String subject) {
		String sql =
				"SELECT BSN, VOORLETTERS, NAAM FROM " + env.getRequiredProperty(prefix + SCHEMA)
						+ ".VW150_KZB_ACTUELE_ENTITEIT_PERSOON_ACTIVITEIT WHERE BSN = ?";

		NaamNummerDTO result = getNaamNummer(subject, sql, true);
		return result;
	}

	public NaamNummerDTO getNaamEntiteit(String dossierNummer) {
		String sql = "SELECT DOSNR, DOSNAAM FROM " + env.getRequiredProperty(prefix + SCHEMA)
				+ ".VW048_ENTITEIT_BASISGEGEVENS WHERE DOSNR = ?";

		NaamNummerDTO result = getNaamNummer(dossierNummer, sql, false);
		if (result == null) {
			sql = "SELECT hist.DOSNR, hist.DOSNAAM FROM " + env.getRequiredProperty(prefix + SCHEMA)
					+ ".VW118_VERVALLEN_ENTITEIT_BASISGEGEVENS hist WHERE hist.DOSNR = ? AND hist.VERVDAT = "
					+ "(SELECT MAX(hist2.VERVDAT) FROM " + env.getRequiredProperty(prefix + SCHEMA)
					+ ".VW118_VERVALLEN_ENTITEIT_BASISGEGEVENS hist2 WHERE hist2.DOSNR = hist.DOSNR)";
			result = getNaamNummer(dossierNummer, sql, false);
		}
		return result;
	}

	public List<EntiteitDTO> getEntiteiten(EntiteitSearchDTO searchDTO) {
		String sql =
				"SELECT DOSNR, DOSNAAM, DOSTEAM, KANTOOR_ID, KANTNM, TEAMOMSCHR FROM " + env.getRequiredProperty(prefix + SCHEMA)
						+ ".VW048_ENTITEIT_BASISGEGEVENS WHERE ";
		if (searchDTO.getNaam() != null) {
			sql = addWhere(sql, "LOWER(DOSNAAM) like ?");
		}
		if (searchDTO.getKantoorCode() != null) {
			sql = addWhere(sql, "KANTOOR_ID = ?");
		}
		if (searchDTO.getKantoorNaam() != null) {
			sql = addWhere(sql, "LOWER(KANTNM) like ?");
		}
		if (searchDTO.getTeamCode() != null) {
			sql = addWhere(sql, "DOSTEAM = ?");
		}
		if (searchDTO.getTeamOmschrijving() != null) {
			sql = addWhere(sql, "LOWER(TEAMOMSCHR) like ?");
		}

		if (searchDTO.getMaxResults() != null) {
			sql += " LIMIT " + searchDTO.getMaxResults();
		}

		//volgorde net zo als hierboven
		try (Connection con = getConnection()) {

			log.debug("execute query : {}", sql);
			try (PreparedStatement ps = con.prepareStatement(sql)) {
				int index = 1;
				if (searchDTO.getNaam() != null) {
					ps.setString(index, "%" + searchDTO.getNaam().toLowerCase() + "%");
					index++;
				}
				if (searchDTO.getKantoorCode() != null) {
					ps.setInt(index, searchDTO.getKantoorCode());
					index++;
				}
				if (searchDTO.getKantoorNaam() != null) {
					ps.setString(index, "%" + searchDTO.getKantoorNaam().toLowerCase() + "%");
					index++;
				}
				if (searchDTO.getTeamCode() != null) {
					ps.setString(index, searchDTO.getTeamCode());
					index++;
				}
				if (searchDTO.getTeamOmschrijving() != null) {
					ps.setString(index, "%" + searchDTO.getTeamOmschrijving().toLowerCase() + "%");
				}
				ResultSet rs = ps.executeQuery();
				List<EntiteitDTO> resultList = ViewRecordMapper.mapToEntityDTO(rs);
				if (resultList.size() > 1) {
					return resultList;
				} else {
					log.debug("geen resultaat bij zoeken naar entiteit, sql: {}", sql);
					return new ArrayList<>();
				}

			} catch (SQLException e) {
				log.error("Problem retrieving entiteit", e);
			}
		} catch (SQLException throwables) {
			log.warn("Error closing connection to KTA");
		}
		return new ArrayList<>();
	}

	private String addWhere(String sql, String whereString) {
		String result = sql;
		if (result.endsWith("WHERE ")) {
			result += whereString;
		} else {
			result += " AND " + whereString;
		}
		return result;
	}

	public EntiteitDTO getEntiteit(String dossierNummer) {
		EntiteitDTO result;
		String sql =
				"SELECT DOSNR, DOSNAAM, DOSTEAM, KANTOOR_ID, KANTNM, TEAMOMSCHR FROM " + env.getRequiredProperty(prefix + SCHEMA)
						+ ".VW048_ENTITEIT_BASISGEGEVENS WHERE DOSNR = ?";
		try (Connection con = getConnection()) {

			log.debug("execute query : {}", sql);
			try (PreparedStatement ps = con.prepareStatement(sql)) {
				ps.setString(1, dossierNummer);
				ResultSet rs = ps.executeQuery();
				List<EntiteitDTO> resultList = ViewRecordMapper.mapToEntityDTO(rs);
				if (resultList.size() > 1) {
					log.warn("meerdere resultaten bij zoeken naar entiteit, sql: {}", sql);
					return null;
				} else if (resultList.size() == 0) {
					log.debug("geen resultaat bij zoeken naar entiteit, sql: {}", sql);
					return null;
				} else { //1 gevonden, geef terug
					return resultList.get(0);
				}
			} catch (SQLException e) {
				log.error("Problem retrieving entiteit", e);
			}
		} catch (SQLException throwables) {
			log.warn("Error closing connection to KTA");
		}
		return null;
	}

	public List<NaamNummerDTO> getNaamMeerdereEntiteiten(List<Integer> dossierNummers) {
		String sql = "SELECT DOSNR, DOSNAAM FROM " + env.getRequiredProperty(prefix + SCHEMA)
				+ ".VW048_ENTITEIT_BASISGEGEVENS WHERE DOSNR in (";

		List<NaamNummerDTO> result = getNaamNummers(dossierNummers, sql, false);
		// Aanname is dat entiteiten niet in beide sets zitten !
		if (result.size() != dossierNummers.size()) {
			sql = "SELECT hist.DOSNR, hist.DOSNAAM FROM " + env.getRequiredProperty(prefix + SCHEMA)
					+ ".VW118_VERVALLEN_ENTITEIT_BASISGEGEVENS hist WHERE hist.VERVDAT = " + "(SELECT MAX(hist2.VERVDAT) FROM "
					+ env.getRequiredProperty(prefix + SCHEMA)
					+ ".VW118_VERVALLEN_ENTITEIT_BASISGEGEVENS hist2 WHERE hist2.DOSNR = hist.DOSNR) AND hist.DOSNR in (";
			List<NaamNummerDTO> result2 = getNaamNummers(dossierNummers, sql, false);
			result.addAll(result2);
		}
		return result;
	}

	public NaamNummerDTO getNaamEntiteitForPersoon(String subject) {
		return getNaamEntiteitForPersoon(subject, false);
	}

	public NaamNummerDTO getNaamEntiteitForPersoon(String subject, boolean noRestrictions) {
		String dossierNummer = this.getDossierNummer(subject, noRestrictions);
		if (dossierNummer != null) {
			return this.getNaamEntiteit(dossierNummer);
		}
		return null;
	}

	public List<PersoonDTO> retrieveEntity(String subject, String subjectType) {
		return  retrieveEntity(subject, subjectType, false);
	}

	public List<PersoonDTO> retrieveEntity(String subject, String subjectType, boolean noRestrictions) {
		List<ViewRecord> records = null;
		if ("ENT".equalsIgnoreCase(subjectType)) {
			records = getRecords(subject, true, noRestrictions);
		} else {
			records = getRecords(subject, false, noRestrictions);
		}
		return PersoonDtoMapper.mapEntiteit(records);
	}

	public EntiteitPersonenResult getEntiteitPersonen(Integer entiteitNummer) {
		log.warn("method not implemented, called for entiteit {} ", entiteitNummer);
		return null;
	}

	private NaamNummerDTO getNaamNummer(String nummer, String sql, Boolean person) {
		List<NaamNummerDTO> resultList = new ArrayList<>();

		try (Connection con = getConnection()) {

			log.debug("execute query : {}", sql);
			try (PreparedStatement ps = con.prepareStatement(sql)) {
				ps.setString(1, nummer);
				ResultSet rs = ps.executeQuery();
				if (person) {
					resultList = ViewRecordMapper.mapToNaamNummerForPerson(rs, "BSN");
				} else {
					resultList = ViewRecordMapper.mapToNaamNummerForEntity(rs, "DOSNR");
					if (resultList.size() > 1) {
						log.warn("meerdere resultaten bij zoeken naar naam entiteit, sql: {}", sql);
					}
				}
			} catch (SQLException e) {
				log.error("Problem reading naam and nummer", e);
			}
		} catch (SQLException throwables) {
			log.warn("Error closing connection to KTA");
		}
		return (resultList.size() >= 1) ? resultList.get(0) : null;
	}

	private List<NaamNummerDTO> getNaamNummers(List<Integer> nummers, String sql, Boolean person) {
		List<NaamNummerDTO> resultList = new ArrayList<>();
		try (Connection con = getConnection()) {
			StringBuilder sb = new StringBuilder(sql);
			nummers.stream().forEach(n -> {
				sb.append("'").append(n).append("'").append(',');
			});
			sb.deleteCharAt(sb.length() - 1).append(')');

			log.debug("execute query : {}", sb.toString());
			try (PreparedStatement ps = con.prepareStatement(sb.toString())) {
				ResultSet rs = ps.executeQuery();
				if (person) {
					resultList = ViewRecordMapper.mapToNaamNummerForPerson(rs, "BSN");
				} else {
					resultList = ViewRecordMapper.mapToNaamNummerForEntity(rs, "DOSNR");
				}
			} catch (SQLException e) {
				log.error("Problem reading naam and nummer", e);
			}
		} catch (SQLException throwables) {
			log.warn("Error closing connection to KTA");
		}
		return resultList;
	}

	private CompetentKantoor getCompetentKantoorFromDb(Integer dosnr, String sql) {
		CompetentKantoor result = new CompetentKantoor();
		try (Connection con = getConnection()) {

			log.debug("execute query : {}", sql);

			try (PreparedStatement ps = con.prepareStatement(sql)) {
				ps.setInt(1, dosnr);
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					result.setKantoorId(rs.getInt("KANTOOR_ID"));
					result.setDosteam(rs.getString("DOSTEAM"));
				}
			} catch (SQLException e) {
				log.error("Problem reading competent kantoor", e);
			}

		} catch (SQLException throwables) {
			log.warn("Error closing connection to KTA");
		}
		return result;
	}

	private String getDossierNummer(String subject, boolean noRestrictions) {
		List<ViewRecord> records = getRecords(subject, false, noRestrictions);
		return (records != null && records.size() >= 1) ? String.valueOf(records.get(0).getDosNr()) : null;
	}

	private List<ViewRecord> getRecords(String subjectNumber, boolean forEntity, boolean noRestrictions) {
		log.debug("getRecords for subject : {}", subjectNumber);
		List<ViewRecord> result = Collections.emptyList();

		try (Connection con = getConnection()) {
			String schema = env.getRequiredProperty(prefix + SCHEMA);

			String sql;
			if (forEntity) {
				if (noRestrictions) {
					sql = SQL_ENTITY_NO_RESTRICT;
				} else {
					sql = SQL_ENTITY;
				}
			} else {
				if (noRestrictions) {
					sql = SQL_PERSON_NO_RESTRICT;
				} else {
					sql = SQL_PERSON;
				}

			}
			sql = "SELECT * FROM " + schema + sql;

			log.debug("execute query : {}", sql);
			try (PreparedStatement ps = con.prepareStatement(sql)) {
				ps.setString(1, subjectNumber);
				ResultSet rs = ps.executeQuery();
				result = ViewRecordMapper.map(rs);
				log.debug("aantal gevonden: {}", result.size());
			} catch (SQLException e) {
				log.error("Problem reading kta records from view.", e);
			}
		} catch (SQLException throwables) {
			log.warn("Error closing connection to KTA");
		}
		return result;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			conn = this.ds.getConnection();
		} catch (SQLException e) {
			throw new ConfigurationException(
					"Problem establishing a connection to the kta database using url '" + this.ds.getJdbcUrl() + "'. " + e
							.getMessage());
		}
		return conn;
	}
}
