package nl.belastingdienst.iva.common.springboot.exceptions;

public class CommonException extends RuntimeException {
	private static final long serialVersionUID = 9089908005989795456L;

	public CommonException(String message) {
		super(message);
	}

	public CommonException(String message, Exception e) {
		super(message, e);
	}

}
