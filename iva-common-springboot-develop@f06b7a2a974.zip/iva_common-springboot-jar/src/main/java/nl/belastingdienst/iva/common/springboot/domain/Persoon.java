package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

@Data
public class Persoon {
    private String type;
    private String finr;
    private String tussenVoegsel;
    private String achterNaam;
    private String naam;
    private String achterVoegsel;
    private String initialen;
    private String samengesteldeNaam;
    private String geboorteDatum;
    private String overlijdensDatum;
    private String oprichtingsDatum;
    private String opheffingsDatum;
    private String geslacht;
    private String huwelijkseStaat;
}
