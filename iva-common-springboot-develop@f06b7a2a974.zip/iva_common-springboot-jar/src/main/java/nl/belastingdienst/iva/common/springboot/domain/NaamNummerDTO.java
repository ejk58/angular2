package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NaamNummerDTO {
	private String naam;
	private Integer nummer;
}
