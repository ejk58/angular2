package nl.belastingdienst.iva.common.springboot.kta;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import nl.belastingdienst.iva.common.springboot.domain.NaamNummerDTO;

public class ViewRecordMapper {

	private ViewRecordMapper() {
		// empty
	}

	public static List<ViewRecord> map(ResultSet rs) throws SQLException {
		List<ViewRecord> result = new LinkedList<>();
		int cnt = 0;
		while (rs.next()) {
			result.add(mapRow(rs, cnt++));
		}
		return result;
	}

	private static ViewRecord mapRow(ResultSet rs, int i) throws SQLException {
		ViewRecord rec = new ViewRecord();
		rec.setDosNr(rs.getLong("DOSNR"));
		rec.setBsn(rs.getLong("BSN"));
		rec.setActiefRel(rs.getString("ACTIEF_REL"));
		rec.setIngDatRel(rs.getDate("INGDAT_REL"));
		rec.setVervDatRel(rs.getDate("VERVDAT_REL"));
		rec.setRedEindRelCd(rs.getInt("REDEN_EIND_REL"));
		rec.setNaam(rs.getString("NAAM"));
		rec.setVoorletters(rs.getString("VOORLETTERS"));
		rec.setNpInd(rs.getString("NPIND"));
		rec.setBegindatum(rs.getDate("BEGINDATUM"));
		rec.setEinddatum(rs.getDate("EINDDATUM"));
		rec.setActiviteitMiddel(rs.getString("ACTIVITEIT_MIDDEL"));
		if (rs.getObject("ACTIVITEIT_VOLGNR") != null && !Integer.valueOf(0)
				.equals(rs.getObject("ACTIVITEIT_VOLGNR"))) { // subnummer 0 moet ook naar null
			rec.setActiviteitVolgnr(rs.getObject("ACTIVITEIT_VOLGNR", Integer.class));
		}
		rec.setActivieitOndernCd(rs.getString("ACTIVITEIT_ONDERNCD"));
		rec.setActiviteitDoelgroep(rs.getInt("ACTIVITEIT_DOELGROEP"));
		rec.setActiviteitTeNmStel(rs.getString("ACTIVITEIT_TENMSTEL"));
		rec.setActiviteitIngDat(rs.getDate("ACTIVITEIT_INGDAT"));
		rec.setActiviteitEindDat(rs.getDate("ACTIVITEIT_EINDDAT"));
		return rec;
	}

	public static List<NaamNummerDTO> mapToNaamNummerForPerson(ResultSet rs, String nummerColName) throws SQLException {
		List<NaamNummerDTO> result = new ArrayList<>();

		while (rs.next()) {
			NaamNummerDTO naamNummerDTO = new NaamNummerDTO();
			StringBuilder sbNaam = new StringBuilder();
			if (rs.getString("VOORLETTERS") != null)
				sbNaam.append(rs.getString("VOORLETTERS")).append(" ");
			sbNaam.append(rs.getString("NAAM"));
			naamNummerDTO.setNaam(sbNaam.toString());
			naamNummerDTO.setNummer(rs.getInt(nummerColName));
			result.add(naamNummerDTO);
		}
		return result;
	}

	public static List<NaamNummerDTO> mapToNaamNummerForEntity(ResultSet rs, String nummerColName) throws SQLException {
		List<NaamNummerDTO> result = new ArrayList<>();

		while (rs.next()) {
			NaamNummerDTO naamNummerDTO = new NaamNummerDTO();
			naamNummerDTO.setNaam(rs.getString("DOSNAAM"));
			naamNummerDTO.setNummer(rs.getInt(nummerColName));
			result.add(naamNummerDTO);
		}
		return result;
	}

	public static List<EntiteitDTO> mapToEntityDTO(ResultSet rs) throws SQLException {
		List<EntiteitDTO> result = new ArrayList<>();
		while (rs.next()) {
			EntiteitDTO entiteitDTO = new EntiteitDTO();
			entiteitDTO.setNaam(rs.getString("DOSNAAM"));
			entiteitDTO.setDosNr(rs.getInt("DOSNR"));
			entiteitDTO.setKantoorId(rs.getInt("KANTOOR_ID"));
			entiteitDTO.setKantoorNaam(rs.getString("KANTNM"));
			entiteitDTO.setTeamCode(rs.getString("DOSTEAM"));
			entiteitDTO.setTeamOmschrijving(rs.getString("TEAMOMSCHR"));
			result.add(entiteitDTO);
		}
		return result;
	}

}
