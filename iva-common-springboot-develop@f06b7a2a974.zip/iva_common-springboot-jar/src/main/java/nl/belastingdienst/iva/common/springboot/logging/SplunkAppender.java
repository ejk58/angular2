package nl.belastingdienst.iva.common.springboot.logging;

import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Map;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.ExceptionUtils;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginElement;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.PatternLayout;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.common.springboot.exceptions.ApiError;
import nl.belastingdienst.iva.common.springboot.exceptions.ApiValidationError;
import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.common.springboot.exceptions.ConfigurationException;

@Plugin(name = "Splunk", category = "Core", elementType = "appender", printObject = true)
public class SplunkAppender extends AbstractAppender {

	private String url;
	private String token;
	private String service;
	private String serverName;

	private ObjectMapper objectMapper = new ObjectMapper();

	public static final Marker marker = MarkerFactory.getMarker("Splunk");

	private SplunkAppender(String name,
			Filter filter,
			Layout<? extends Serializable> layout, String url, String token, String service) {
		super(name, filter, layout, true);
		this.url = url;
		this.token = token;
		this.service = service;

		Map<String, String> env = System.getenv();
		if (env.get("splunk.token") != null) {
			this.token = env.get("splunk.token");
		}
		if (env.get("splunk.url") != null) {
			this.url = env.get("splunk.url");
		}
		if (env.get("splunk.service") != null) {
			this.service = env.get("splunk.service");
		}

		if (service == null) {
			throw new ConfigurationException("splunk.service niet gezet in properties application");
		}
		try {
			this.serverName = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			this.serverName = "Onbekend";
		}
	}

	@PluginFactory
	public static SplunkAppender createAppender(
			@PluginAttribute("name") String name,
			@PluginElement("Layout") Layout<? extends Serializable> layout,
			@PluginElement("Filter") final Filter filter,
			@PluginAttribute("url") String url,
			@PluginAttribute("token") String token,
			@PluginAttribute("service") String service) {
		if (name == null) {
			LOGGER.error("No name provided for SplunkAppender");
			return null;
		}

		if (layout == null) {
			layout = PatternLayout.createDefaultLayout();
		}

		return new SplunkAppender(name, filter, layout, url, token, service);
	}

	@Override
	public void append(LogEvent logEvent) {
		SplunkEvent splunkEvent = new SplunkEvent();
		splunkEvent.setEvent(new Event(logEvent.getMessage().getFormattedMessage(), logEvent.getLevel().name()));
		if (logEvent.getThrown() != null) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			logEvent.getThrown().printStackTrace(pw);
			splunkEvent.getEvent().setStackTrace(sw.toString());
		}

		if (logEvent.getMessage().getThrowable() != null) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			logEvent.getMessage().getThrowable().printStackTrace(pw);
			splunkEvent.getEvent().setStackTrace(sw.toString());
		}

		splunkEvent.setHost(this.serverName);
		splunkEvent.setTime(System.currentTimeMillis());
		splunkEvent.getFields().put("service", this.service);
		String json = null;
		try {
			json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(splunkEvent);
		} catch (JsonProcessingException e) {
			throw new CommonException("Error write Json to string", e);
		}
		send(json);
	}

	void send(String json) {
		try (CloseableHttpClient httpclient = createSSLAgnosticClient()) {
			LOGGER.debug("Sending logevent to Splunk {}", json);
			HttpPost httpPost = new HttpPost(url + "/services/collector/event");
			httpPost.addHeader("Authorization", token);
			httpPost.addHeader("Accept", "application/json");
			httpPost.addHeader("Content-Type", "application/json");
			httpPost.setEntity(new StringEntity(json));
			executePost(httpclient, httpPost);
		} catch (Exception e) {
			handleExeption(e);
		}
	}

	private void executePost(CloseableHttpClient httpclient, HttpPost httpPost) {

		try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
			if (response.getStatusLine().getStatusCode() != 200) {
				LOGGER.error(response);
				LOGGER.error(String.format("Failed to send a logging to splunk with statuscode %d",
						response.getStatusLine().getStatusCode()));
			}
		} catch (Exception e) {
			handleExeption(e);
		}
	}

	private void handleExeption(Exception e) {
		LOGGER.error(String.format("Failed to send a logging to splunk with an Exception (uri: %s, Message %s)",
				this.url, e.getLocalizedMessage()));
	}

	private CloseableHttpClient createSSLAgnosticClient()
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
		CloseableHttpClient httpclient;
		SSLContextBuilder builder = new SSLContextBuilder();
		SSLConnectionSocketFactory sslsf = null;
		builder.loadTrustMaterial(null, new TrustAllStrategy());
		sslsf = new SSLConnectionSocketFactory(
				builder.build(), new NoopHostnameVerifier());
		httpclient = HttpClients.custom().setSSLSocketFactory(
				sslsf).build();
		return httpclient;
	}

}
