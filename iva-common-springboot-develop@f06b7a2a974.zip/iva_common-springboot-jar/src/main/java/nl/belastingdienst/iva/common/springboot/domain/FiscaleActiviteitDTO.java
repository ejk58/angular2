package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

import java.time.LocalDate;

@Data
public class FiscaleActiviteitDTO {
    private String activiteit;
    private String naam;
    private Integer subnummer;
    private String ondernemerscode;
    private LocalDate ingangsdatum;
    private LocalDate einddatum;
    private String aangifteplicht;
    private String doelgroepcode;
}

