package nl.belastingdienst.iva.common.springboot.services;

import lombok.extern.log4j.Log4j2;
import nl.belastingdienst.iva.common.springboot.dao.RetryActionRepository;
import nl.belastingdienst.iva.common.springboot.dao.RetryLockRepository;
import nl.belastingdienst.iva.common.springboot.domain.RetryAction;
import nl.belastingdienst.iva.common.springboot.domain.RetryLock;
import nl.belastingdienst.iva.common.springboot.exceptions.CommonException;
import nl.belastingdienst.iva.common.springboot.logging.MattermostAppender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
@Scope(value = "singleton")
@Log4j2
@Configuration
@ComponentScan("nl.belastingdienst.iva")
@EnableJpaRepositories(basePackages = {"nl.belastingdienst.iva"})
public class RetryRestCallSerivce {

    @Autowired
    private RetryActionRepository retryActionRepo;
    @Autowired
    private RetryLockRepository retryLockRepository;

    @Autowired
    private ClientHttpRequestFactory httpRequestFactory;

    @Autowired
    private Environment env;

    public void retry(String url, HttpHeaders headers, Object body, HttpMethod method, Integer maxRetries,
                      Integer timeToSendinMinutes) {
        if (!Arrays.asList(HttpMethod.POST, HttpMethod.PUT, HttpMethod.DELETE).contains(method)) {
            throw new CommonException("Only POST, PUT or DELETE allowed for retry");
        }
        RetryAction retryAction = new RetryAction(method, headers, url, body);
        if (timeToSendinMinutes != null) {
            retryAction.setTimeToSendMessage(timeToSendinMinutes.longValue() * 60 * 1000);
        }
        retryAction.setMaxRetries(maxRetries);
        retryActionRepo.saveAndFlush(retryAction);
    }

    private void doPostRetry(RetryAction retryAction) {
        RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
        HttpEntity<? extends Object> request = new HttpEntity<>(retryAction.getBody(), retryAction.getHttpHeaders());
        try {
            restTemplate.exchange(retryAction.getUrl(), retryAction.getMethod(), request, String.class);
            retryActionRepo.delete(retryAction);
            retryActionRepo.flush();
            log.info("Retry succeeded: {}, after {} attempts", retryAction.getUrl(), retryAction.getNumberOfRetries() + 1);
        } catch (Exception e) {
            retryAction.setNumberOfRetries(retryAction.getNumberOfRetries() + 1);
            retryActionRepo.save(retryAction);
            log.error("Failed again {}, number of attempts {} ", e.getLocalizedMessage(), retryAction.getNumberOfRetries());
        }
    }

    @Scheduled(cron = "0 * 6-21 * * 1-5")
    @Transactional
    public void executeRetry() {
        RetryLock lock = retryLockRepository.findFirstByIdGreaterThan(0L);
        List<RetryAction> retries = retryActionRepo.findAllByInErrorIsFalse();
        if (retries.isEmpty()) {
            return;
        }
        retries.forEach(retryAction -> {
            switch (retryAction.getAction()) {
                case RETRY:
                    doPostRetry(retryAction);
                    break;
                case NO_RETRY_MAX_TIME_EXCEEDED:
                    log.error(MattermostAppender.marker, "{}, Problem with retry id: {}, max time exceeded",
                            env.getProperty("splunk.service"), String.valueOf(retryAction.getId()));
                    retryAction.setInError(true);
                    retryActionRepo.save(retryAction);
                    break;
                case NO_RETRY_MAX_RETRIES_REACHED:
                    log.error(MattermostAppender.marker, "{} Problem with retry id: {}, max retries reached",
                            env.getProperty("splunk.service"), String.valueOf(retryAction.getId()));
                    retryAction.setInError(true);
                    retryActionRepo.save(retryAction);
                    break;
                default:
                    throw new CommonException("nog niet geimplementeerd " + retryAction.getAction());
            }
        });
    }
}
