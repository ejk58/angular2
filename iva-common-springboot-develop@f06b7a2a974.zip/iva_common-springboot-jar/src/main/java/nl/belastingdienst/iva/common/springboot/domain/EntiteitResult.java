package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

@Data
public class EntiteitResult {
    private Entiteit entiteit;
}
