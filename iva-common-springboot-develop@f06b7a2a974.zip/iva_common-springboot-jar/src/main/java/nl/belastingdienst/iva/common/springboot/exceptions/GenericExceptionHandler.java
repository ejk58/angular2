package nl.belastingdienst.iva.common.springboot.exceptions;

import com.auth0.jwt.exceptions.JWTVerificationException;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.apache.logging.log4j.Level;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.stream.Collectors;

@Log4j2
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class GenericExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        return buildResponseEntity(new ApiError(GenericErrorType.JSON_FORMAT, ex.getCause().getMessage(),
                ((ServletWebRequest) request).getRequest().getRequestURI()), HttpStatus.BAD_REQUEST, Level.INFO);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.ARGUMENT_FORMAT, "Parameter error",
                ((ServletWebRequest) request).getRequest().getRequestURI());
        apiError.setValidationErrors(ex.getBindingResult().getAllErrors().stream().map(error -> {
            String fieldName = ((FieldError) error).getField();
            Object fv = ((FieldError) error).getRejectedValue();
            String fieldValue = fv != null ? ((FieldError) error).getRejectedValue().toString() : "";
            String errorMessage = error.getDefaultMessage();
            return new ApiValidationError(fieldName, fieldValue, errorMessage);
        }).collect(Collectors.toList()));
        return buildResponseEntity(apiError, HttpStatus.BAD_REQUEST, Level.INFO);
    }

    @ExceptionHandler(ConfigurationException.class)
    protected ResponseEntity<Object> handleConfiguration(ConfigurationException ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.SYSTEM_CONFIG, ex.getMessage(), request.getRequestURI());
        return buildResponseEntity(apiError, HttpStatus.INTERNAL_SERVER_ERROR, Level.ERROR, ex);
    }

    @ExceptionHandler(NotAllowedException.class)
    protected ResponseEntity<Object> handleNotAllowed(NotAllowedException ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.FORBIDDEN, ex.getMessage(), request.getRequestURI());
        return buildResponseEntity(apiError, HttpStatus.FORBIDDEN, Level.INFO);
    }

    @ExceptionHandler(NetworkException.class)
    protected ResponseEntity<Object> handleNetwork(NetworkException ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.UPSTREAM_UNAVAILABLE, ex.getMessage(), request.getRequestURI());
        return buildResponseEntity(apiError, HttpStatus.SERVICE_UNAVAILABLE, Level.ERROR, ex);
    }

    @ExceptionHandler(NotFoundException.class)
    protected ResponseEntity<Object> handleNotFound(NotFoundException ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.NOT_FOUND, ex.getWhy(), request.getRequestURI());
        ApiValidationError sub = new ApiValidationError(ex.getWhat(), ex.getKey(), ex.getWhy());
        apiError.setValidationErrors(Arrays.asList(sub));
        return buildResponseEntity(apiError, HttpStatus.BAD_REQUEST, Level.INFO);
    }

    @ExceptionHandler(NotPossibleException.class)
    protected ResponseEntity<Object> handleNotPossible(NotPossibleException ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.NOT_POSSIBLE, ex.getWhat(), request.getRequestURI());
        ApiValidationError sub = new ApiValidationError(ex.getWhat(), ex.getKey(), ex.getWhy());
        apiError.setValidationErrors(Arrays.asList(sub));
        return buildResponseEntity(apiError, HttpStatus.BAD_REQUEST, Level.INFO);
    }

    @ExceptionHandler(BadCredentialsException.class)
    protected ResponseEntity<Object> handleBadCredentials(BadCredentialsException ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.UNAUTHORIZED, ex.getMessage(), request.getRequestURI());
        return buildResponseEntity(apiError, HttpStatus.UNAUTHORIZED, Level.INFO);
    }

    @ExceptionHandler(JWTVerificationException.class)
    protected ResponseEntity<Object> handleBadToken(JWTVerificationException ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.BAD_TOKEN, ex.getClass().getSimpleName(), request.getRequestURI());
        return buildResponseEntity(apiError, HttpStatus.BAD_REQUEST, Level.INFO);
    }

    @ExceptionHandler(CommonException.class)
    protected ResponseEntity<Object> handleCommon(CommonException ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.UNCLASSIFIED, ex.getMessage(), request.getRequestURI());
        return buildResponseEntity(apiError, HttpStatus.INTERNAL_SERVER_ERROR, Level.ERROR, ex);
    }

    @ExceptionHandler(Exception.class)
    protected ResponseEntity<Object> handleOtherException(Exception ex, HttpServletRequest request) {
        ApiError apiError = new ApiError(GenericErrorType.NOT_ANTICIPATED, ex.toString(), request.getRequestURI());
        return buildResponseEntity(apiError, HttpStatus.INTERNAL_SERVER_ERROR, Level.ERROR, ex);
    }

    @ExceptionHandler(NotChangedException.class)
    protected ResponseEntity<Object> handleNotChanged(NotChangedException ex) {
        ApiError apiError = new ApiError(GenericErrorType.CONFLICT, ex.getMessage());
        return buildResponseEntity(apiError, HttpStatus.BAD_REQUEST, Level.INFO);
    }

    @ExceptionHandler(AuthenticationCredentialsNotFoundException.class)
    protected ResponseEntity<Object> handleProcessing(AuthenticationCredentialsNotFoundException ex) {
        ApiError apiError = new ApiError(GenericErrorType.UNAUTHORIZED, ex.getMessage());
        return buildResponseEntity(apiError, HttpStatus.UNAUTHORIZED, Level.INFO);
    }

    @ExceptionHandler(ValidationException.class)
    protected ResponseEntity<Object> handleValidation(ValidationException ex, HttpServletRequest request) {
        String message = null;
        if (ex.getResult() != null) {
            message = ex.getMessage();
        } else {
            StringBuffer sb = new StringBuffer();
            ex.getValidationResultList().stream().forEach(validationResult -> sb.append(validationResult.getMessage() + ", "));
            message = sb.toString().substring(0, sb.length() - 2);
        }
        ApiError apiError = new ApiError(GenericErrorType.VALIDATION, message, request.getRequestURI());
        return buildResponseEntity(apiError, HttpStatus.BAD_REQUEST, Level.DEBUG);
    }


    protected ResponseEntity<Object> buildResponseEntity(ApiError apiError, HttpStatus status, Level level) {
        if (level != null)
            log.log(level, apiError);
        return buildResponseEntity(apiError, status, level, null);
    }


    protected ResponseEntity<Object> buildResponseEntity(ApiError apiError, HttpStatus status, Level level, Exception e) {
        if (e != null) {
            log.log(level, e);
        } else {
            log.log(level, apiError);
        }
        return new ResponseEntity<>(apiError, status);
    }
}
