package nl.belastingdienst.iva.common.springboot.domain;

import java.time.LocalDate;
import java.util.List;

import lombok.Data;

@Data
public class PersoonDTO {
	private Long subject;
	private String naam;
	private String soort;
	private LocalDate start;
	private LocalDate einde;
	private LocalDate vervalDatumRelatie;
	private List<FiscaleActiviteitDTO> activiteiten;
}

