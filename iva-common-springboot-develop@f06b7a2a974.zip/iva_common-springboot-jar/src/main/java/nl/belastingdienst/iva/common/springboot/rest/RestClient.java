package nl.belastingdienst.iva.common.springboot.rest;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import nl.belastingdienst.iva.common.springboot.exceptions.SslException;

public class RestClient {

	@Autowired
	protected Environment env;

	protected RestTemplate getRestTemplate() throws SslException {
		HttpComponentsClientHttpRequestFactory requestFactory = null;
		try {
			SSLContextBuilder builder = new SSLContextBuilder();
			builder.loadTrustMaterial(null, new TrustStrategy() {
				@Override
				public boolean isTrusted(final X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			});
			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(builder.build());

			CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
			requestFactory = new HttpComponentsClientHttpRequestFactory();
			requestFactory.setHttpClient(httpClient);
		} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
			throw new SslException(e.getMessage());
		}
		return new RestTemplate(requestFactory);
	}

	protected HttpHeaders getStandardHttpHeaders(String apikeyProperty, String apiHeader) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(apiHeader, env.getProperty(apikeyProperty));
		return headers;
	}
}
