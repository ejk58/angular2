package nl.belastingdienst.iva.common.springboot.exceptions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
public class ApiValidationError {
    private String field;
    private String rejectedValue;
    private String message;
}
