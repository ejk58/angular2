package nl.belastingdienst.iva.common.springboot.security;

import lombok.Data;

@Data
public class LoginCredentials {
    private String username;
    private String password;
}

