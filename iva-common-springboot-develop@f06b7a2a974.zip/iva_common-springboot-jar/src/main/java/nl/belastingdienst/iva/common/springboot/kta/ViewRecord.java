package nl.belastingdienst.iva.common.springboot.kta;

import java.util.Date;

import lombok.Data;

@Data
public class ViewRecord {
	// Entiteit-Relatie-Persoon
	Long dosNr;					// entiteitnummer
	Long bsn;					// bsn indien np, rsin indien nnp (ook van vervallen relaties van 01-01-<min 10 jaar>
	String actiefRel; 			// ACTIEF_REL    J als relatie actief/actueel N als vervallen relatie
	Date ingDatRel;				// ingangsdatum van de relatie
	Date vervDatRel;			// vervaldatum van de relatie (9999-12-31 indien relatie actief/actueel)
	Integer redEindRelCd;		// reden eind relatie code, alleen 0 , 2 en 3 zijn geselecteerd.
	// Persoon
	String naam;				// naam van de persoon
	String voorletters;			// voornaam van de persoon indien np of null indien nnp
	String npInd;				// J indien NP, N indien NNP
	Date begindatum;			// geboortedatum np of oprichtingsdatum nnp
	Date einddatum;				// overlijdensdatum np of opheffingsdatum nnp
	// Activiteit
	String activiteitMiddel;	// Middelen OB, IH, LH of VPB
	Integer activiteitVolgnr;	// volgnr/subnr indien OB of LH, indien IH of VPB 0 (geen subnr/volgnr)
	String activieitOndernCd;	// ondernemerscode indien OB of VPB, indien IH of LH leeg
	Integer activiteitDoelgroep;// doelgroep indien IH, indien OB, LH of VPB 0
	String activiteitTeNmStel;	// tenaamstelling indien OB of LH, indien IH of VPB leeg
	Date activiteitIngDat;		// ingangsdatum activiteit
	Date activiteitEindDat;		// einddatum/vervaldatum activiteit
}
