package nl.belastingdienst.iva.common.springboot.logging;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginElement;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.PatternLayout;

import com.fasterxml.jackson.core.io.JsonStringEncoder;

@Plugin(name = "Mattermost", category = "Core", elementType = "appender", printObject = true)
public class MattermostAppender extends AbstractAppender {

	String webhookUrl;
	String channel;
	String serverName;

	public static final Marker marker = new MarkerManager.Log4jMarker("MatterMost");

	private MattermostAppender(String name,
			Filter filter,
			Layout<? extends Serializable> layout,
			final String webhookUrl,
			final String channel) {
		super(name, filter, layout, true);
		this.webhookUrl = webhookUrl;
		this.channel = channel;
		try {
			this.serverName = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			this.serverName = "Onbekend";
		}
	}

	@PluginFactory
	public static MattermostAppender createAppender(
			@PluginAttribute("name") String name,
			@PluginElement("Layout") Layout<? extends Serializable> layout,
			@PluginElement("Filter") final Filter filter,
			@PluginAttribute("webhookUrl") String webhookUrl,
			@PluginAttribute("channel") String channel) {
		if (name == null) {
			LOGGER.error("No name provided for MattermostAppender");
			return null;
		}
		if (webhookUrl == null) {
			webhookUrl = "https://machine-catchup.prod.belastingdienst.nl/hooks/4ftexca3ebge3egemhofb6ptpr";
		}
		if (layout == null) {
			layout = PatternLayout.createDefaultLayout();
		}
		return new MattermostAppender(name, filter, layout, webhookUrl, channel);
	}

	@Override
	public void append(LogEvent logEvent) {
		String msg = new String(getLayout().toByteArray(logEvent));
		send(msg, this.channel);
	}

	void send(String text, String channel) {
		try (CloseableHttpClient httpclient = createSSLAgnosticClient()) {
			LOGGER.debug("Sending message to MatterMost channel {}: {}", channel, text);
			HttpPost httpPost = new HttpPost(this.webhookUrl);
			String channelMessage = String.format("%s: %s", serverName, text);
			String jsonEncodedMessage = new String(new JsonStringEncoder().quoteAsString(channelMessage));
			StringEntity postingString = new StringEntity(
					String.format("{\"channel\": \"%s\",\"text\": \"%s\"}", channel, jsonEncodedMessage));
			httpPost.setEntity(postingString);
			httpPost.setHeader("Content-type", "application/json");
			executePost(httpclient, httpPost);
		} catch (Exception e) {
			handleExeption(e);
		}
	}

	private void executePost(CloseableHttpClient httpclient, HttpPost httpPost) {
		try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
			if (response.getStatusLine().getStatusCode() != 200) {
				LOGGER.error(String.format("Failed to send a mattermost notification with statuscode %d",
						response.getStatusLine().getStatusCode()));
			}
		} catch (Exception e) {
			handleExeption(e);
		}
	}

	private void handleExeption(Exception e) {
		LOGGER.error(String.format("Failed to send a mattermost notification with an Exception (uri: %s, Message %s)",
				this.webhookUrl, e.getLocalizedMessage()));
	}

	private CloseableHttpClient createSSLAgnosticClient()
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
		CloseableHttpClient httpclient;
		SSLContextBuilder builder = new SSLContextBuilder();
		SSLConnectionSocketFactory sslsf = null;
		builder.loadTrustMaterial(null, new TrustAllStrategy());
		sslsf = new SSLConnectionSocketFactory(
				builder.build(), new NoopHostnameVerifier());
		httpclient = HttpClients.custom().setSSLSocketFactory(
				sslsf).build();
		return httpclient;
	}

}
