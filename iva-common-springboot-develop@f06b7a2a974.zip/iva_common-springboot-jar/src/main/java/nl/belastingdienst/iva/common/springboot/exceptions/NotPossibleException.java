package nl.belastingdienst.iva.common.springboot.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class NotPossibleException extends RuntimeException {
    private static final long serialVersionUID = -1L;
    private final Object object;
    private final String what;
    private final String key;
    private final String why;
}
