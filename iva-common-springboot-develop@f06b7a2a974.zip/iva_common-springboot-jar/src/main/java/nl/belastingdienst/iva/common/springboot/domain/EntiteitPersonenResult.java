package nl.belastingdienst.iva.common.springboot.domain;

import lombok.Data;

import java.util.List;

@Data
public class EntiteitPersonenResult {
    private Entiteit entiteit;
    private List<String> deelnemers;
}
