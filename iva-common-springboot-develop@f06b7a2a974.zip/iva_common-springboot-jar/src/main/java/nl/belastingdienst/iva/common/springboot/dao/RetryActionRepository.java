package nl.belastingdienst.iva.common.springboot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import nl.belastingdienst.iva.common.springboot.domain.RetryAction;

@Repository
public interface RetryActionRepository extends JpaRepository<RetryAction, Long> {

	List<RetryAction> findAllByInErrorIsFalse();
}
