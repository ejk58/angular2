package nl.belastingdienst.iva.common.springboot.kta;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import nl.belastingdienst.iva.common.springboot.domain.FiscaleActiviteitDTO;
import nl.belastingdienst.iva.common.springboot.domain.PersoonDTO;

public class PersoonDtoMapperTest {

	@Test
	public void testMapEntiteit() {
		ViewRecord vr = null;
		List<ViewRecord> lijst = new LinkedList<>();
		List<ViewRecord> viewRecords = buildViewRecords(1, 2);
		lijst.add(viewRecords.get(0));
		lijst.add(viewRecords.get(1));
		List<PersoonDTO> persoonDTOS = PersoonDtoMapper.mapEntiteit(lijst);
		Assert.assertNotNull(persoonDTOS);
		Assert.assertEquals(1, persoonDTOS.size());
		Assert.assertEquals(1 * 11, persoonDTOS.get(0).getSubject().longValue());
		Assert.assertEquals("voorLetters_1 Naam_1", persoonDTOS.get(0).getNaam());
		Assert.assertEquals("J", persoonDTOS.get(0).getSoort());
		Assert.assertEquals(LocalDate.of(2020, 05, 5), persoonDTOS.get(0).getStart());
		Assert.assertEquals(null, persoonDTOS.get(0).getEinde());
		Assert.assertEquals(2, persoonDTOS.get(0).getActiviteiten().size());

		FiscaleActiviteitDTO[] aFA = persoonDTOS.get(0).getActiviteiten()
				.toArray(new FiscaleActiviteitDTO[persoonDTOS.get(0).getActiviteiten().size()]);

		Assert.assertEquals("activiteitMiddel_1_1", aFA[0].getActiviteit());
		Assert.assertEquals("ActiviteitTeNmStel_1_1", aFA[0].getNaam());
		Assert.assertEquals(1, aFA[0].getSubnummer().intValue());
		Assert.assertEquals("ActivieitOndernCd_1_1", aFA[0].getOndernemerscode());
		Assert.assertEquals(null, aFA[0].getIngangsdatum());
		Assert.assertEquals(null, aFA[0].getAangifteplicht());
		Assert.assertEquals("2", aFA[0].getDoelgroepcode());

		Assert.assertEquals("activiteitMiddel_1_2", aFA[1].getActiviteit());
		Assert.assertEquals("ActiviteitTeNmStel_1_2", aFA[1].getNaam());
		Assert.assertEquals(2, aFA[1].getSubnummer().intValue());
		Assert.assertEquals("ActivieitOndernCd_1_2", aFA[1].getOndernemerscode());
		Assert.assertEquals(LocalDate.of(2020, 5, 9), aFA[1].getIngangsdatum());
		Assert.assertEquals(null, aFA[1].getAangifteplicht());
		Assert.assertEquals("3", aFA[1].getDoelgroepcode());
	}

	private List<ViewRecord> buildViewRecords(long id, int numOfActiviteiten) {
		List<ViewRecord> vrs = new LinkedList<>();
		for (int teller = 0; teller < numOfActiviteiten; teller++) {
			vrs.add(buildViewRecord(id, teller + 1));
		}
		return vrs;
	}

	private ViewRecord buildViewRecord(long id, int actId) {
		ViewRecord vr = new ViewRecord();
		vr.setDosNr(id);
		vr.setBsn(id * 11);
		vr.setActiefRel("ActiefRel_" + id);
		vr.setIngDatRel(makeDate(id));
		vr.setVervDatRel(makeDate(id + 1));
		vr.setRedEindRelCd(Integer.valueOf((int) id + 1));
		vr.setNaam("Naam_" + id);
		vr.setVoorletters("voorLetters_" + id);
		vr.setNpInd(id % 2 == 0 ? "N" : "J");
		vr.setBegindatum(makeDate(id + 2));
		vr.setEinddatum(makeDate(id + 3));
		vr.setActiviteitMiddel("activiteitMiddel_" + id + "_" + actId);
		vr.setActiviteitVolgnr(Integer.valueOf(actId));
		vr.setActivieitOndernCd("ActivieitOndernCd_" + id + "_" + actId);
		vr.setActiviteitDoelgroep(Integer.valueOf(actId + 1));
		vr.setActiviteitTeNmStel("ActiviteitTeNmStel_" + id + "_" + actId);
		vr.setActiviteitIngDat(makeDate(id + actId + 4));
		vr.setActiviteitEindDat(makeDate(id + actId + 5));
		return vr;
	}

	private Date makeDate(long delta) {
		if (delta % 2 == 0)
			return null;
		LocalDate date = LocalDate.of(2020, 05, (int) (2 + delta));
		return Date.from(date.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
	}

}
