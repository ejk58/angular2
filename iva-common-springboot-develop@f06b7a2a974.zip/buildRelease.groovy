@Library("GENERIC") _
    pipelineRelease {
    baseDirectory = "iva_common-springboot-jar"
	deploymentId = "iva_common-springboot"
	deployPipeline = ""
	integrationPipeline = ""
	environmentChoices = "tst\nacc"
	streetChoices = "str11"
}
