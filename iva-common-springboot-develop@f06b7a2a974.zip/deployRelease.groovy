@Library("GENERIC") _
    pipelineDeployArtifactFromNexus_v1 {
	baseDirectory = "iva_common-springboot-jar"
	deploymentId = "iva_common-springboot"
	integrationPipeline = ""
	packageChoices = "iva_common-springboot\n"
	applicationVersionChoices = "2.56.0\n2.55.0\n2.54.0\n2.53.0\n2.52.0"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
}
