/*jshint esversion: 6 */
const { SpecReporter } = require('jasmine-spec-reporter');
var HtmlReporter2 = require('protractor-beautiful-reporter');

var fs = require('fs');

function rmDir(dirPath) {
    try {
        var files = fs.readdirSync(dirPath);
    }
    catch (e) {
        return;
    }
    if (files.length > 0)
        for (var i = 0; i < files.length; i++) {
            var filePath = dirPath + '/' + files[i];
            if (fs.statSync(filePath).isFile())
                fs.unlinkSync(filePath);
            else
                rmDir(filePath);
        }
    fs.rmdirSync(dirPath);
};

exports.config = {
    allScriptsTimeout: 10000,
    getPageTimeout: 120000,

    specs: [
        './e2e/**/*.e2e-spec.ts'
    ],

    localSeleniumStandaloneOpts: {
        // The port to start the Selenium Server on, or null if the server should
        // find its own unused port.
        // host: 'localhost',
        // port: 4444,
        jvmArgs: [
            '-Dwebdriver.chrome.driver=./node_modules/webdriver-manager/selenium/chromedriver_2.35.exe'
        ]
    },

    multiCapabilities: [
        {
            'browserName': 'chrome',
            'chromeOptions': {
                // Disable een aantal foutmeldingen EN disable infobar bij starten chrome
                'args': ['--disable-gpu --disable-infobars --disable-extensions --start-maximized --window-size=1366, 768'],
                //zorgt dat er geen extenties meer worden uitgevoerd, die kunnen je test onderbreken
                useAutomationExtension: false
            }
        }
    ],
    baseUrl: 'http://ivac.ont.belastingdienst.nl/view',
    // baseUrl: 'http://localhost:4200/',
    // Run tests on Selenium server, needed for run on Jenkins
    seleniumAddress: 'http://iva-selgrid.belastingdienst.nl:4444/wd/hub',
    useAllAngular2AppRoots: true,
    framework: 'jasmine',

    jasmineNodeOpts: {
        showColors: true,
        defaultTimeoutInterval: 120000,
        print: function () {}
    },
    onPrepare() {
        require('ts-node').register({
            project: './e2e/tsconfig.e2e.json'
        });

        jasmine.getEnv().addReporter(new SpecReporter({spec: {displayStacktrace: false} }));

        rmDir('./src/test/e2e/reports/e2e-tests');
        jasmine.getEnv().addReporter((new HtmlReporter2({
            baseDirectory: './e2e/reports/e2e-tests/',
            docTitle: 'Inzicht Configurator E2E test report'
        }).getJasmine2Reporter()));

        browser.waitForAngularEnabled(true);
        browser.manage().timeouts().implicitlyWait(5000);
        browser.manage().window().setSize(1366, 768);

        //image-comparison config
        rmDir('./src/test/e2e/reports/.tmp');
        const protractorImageComparison = require('protractor-image-comparison');
        browser.protractorImageComparison = new protractorImageComparison({
            baselineFolder: './e2e/baseline/',
            screenshotPath: './e2e/reports/.tmp/',
            autoSaveBaseline: true,
            ignoreTransparentPixel: true,
            disableCSSAnimation: true,
        });
    },

    onComplete: function () {
        //if (!!browser.driver) {
        browser.driver.close();
        browser.driver.quit();
        // }
    },
}
