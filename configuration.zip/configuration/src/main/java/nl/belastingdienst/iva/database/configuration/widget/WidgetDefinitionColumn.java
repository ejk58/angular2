package nl.belastingdienst.iva.database.configuration.widget;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn;
import nl.belastingdienst.iva.util.ExportUtils;
import org.codehaus.jackson.annotate.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "CONF_WIDGET_COLUMN")
public class WidgetDefinitionColumn {

    @Id
    private int id;

    private int index;
    private String type;
    private String style;
    private Integer level;
    private String label;
    private String description;
    private int width;
    private boolean visible;
    private boolean sortable;
    private boolean summable;
    private boolean comparable;
    private boolean filterable;
    private String domain;

    @OneToOne
    @JoinColumn(name = "QUERY_COLUMN_ID")
    private QueryDefinitionColumn queryColumn;

    @JsonIgnore
    public int getId() {
        return id;
    }

    public int getIndex() {
        return index;
    }

    public String getType() {
        return type;
    }

    public String getStyle() {
        return style;
    }

    public Integer getLevel() {
        return level;
    }

    public String getLabel() {
        return label;
    }

    public String getDescription() {
        return description;
    }

    public int getWidth() {
        return width;
    }

    public boolean isVisible() {
        return visible;
    }

    public boolean isSortable() {
        return sortable;
    }

    public boolean isSummable() {
        return summable;
    }

    public boolean isComparable() {
        return comparable;
    }

    public boolean isFilterable() {
        return filterable;
    }

    public String getDomain() {
        return domain;
    }

    public QueryDefinitionColumn getQueryColumn() {
        return queryColumn;
    }

    public String toSql(String widgetName, String queryKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_COLUMN\"(WIDGET_ID, QUERY_COLUMN_ID, INDEX, TYPE, LABEL, STYLE, LEVEL, DESCRIPTION, WIDTH, DOMAIN, VISIBLE, SORTABLE, SUMMABLE, COMPARABLE, FILTERABLE) VALUES (");

        sqlBuilder.append("(SELECT ID from CONF_WIDGET WHERE NAME = '" + widgetName + "'), ");
        sqlBuilder.append("(SELECT qc.ID FROM CONF_QUERY_COLUMN qc JOIN CONF_QUERY q ON q.ID = qc.QUERY_ID WHERE q.KEY = '" + queryKey + "' AND qc.INDEX = " + this.queryColumn.getIndex() + "), ");
        sqlBuilder.append(this.index + ", ");
        sqlBuilder.append(ExportUtils.getString(this.type) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.label) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.style) + ", ");
        sqlBuilder.append(this.level == null ? "null, " : this.level + ", ");
        sqlBuilder.append(ExportUtils.getString(this.description) + ", ");
        sqlBuilder.append(this.width + ", ");
        sqlBuilder.append(ExportUtils.getString(this.domain) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(this.visible) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(this.sortable) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(this.summable) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(this.comparable) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(this.filterable));
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
