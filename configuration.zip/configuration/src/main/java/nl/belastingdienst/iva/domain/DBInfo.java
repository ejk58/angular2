package nl.belastingdienst.iva.domain;


public class DBInfo {
    private String currentSchema = "???";

    public String getCurrentSchema() {
        return currentSchema;
    }

    public void setCurrentSchema(String currentSchema) {
        this.currentSchema = currentSchema;
    }
}
