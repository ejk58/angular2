package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinition;
import nl.belastingdienst.iva.domain.dto.QueryDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface QueryDefinitionRepository extends JpaRepository<QueryDefinition, Integer> {

    @Query("SELECT " +
            "new nl.belastingdienst.iva.domain.dto.QueryDto(d.id, d.viewName, d.key) " +
            " FROM QueryDefinition d ORDER BY d.key ASC")
    List<QueryDto> findAllDTOByOrderByViewNameAsc();
}
