package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionWidget;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TabWidgetDefinitionRepository extends JpaRepository<TabDefinitionWidget, Integer> {

}
