package nl.belastingdienst.iva.database.configuration.tab;


import nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn;
import org.codehaus.jackson.annotate.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "CONF_TAB_COLUMN")
public class TabDefinitionColumn {

    @Id
    private Integer id;

    private Integer index;

    @Column(name = "FILTERVALUE")
    private boolean filterValue;

    @Column(name = "FILTERLABEL")
    private boolean filterLabel;

    @OneToOne
    @JoinColumn(name = "QUERY_COLUMN_ID")
    private QueryDefinitionColumn queryColumn;

    @JsonIgnore
    public Integer getId() {
        return id;
    }

    @JsonIgnore
    public Integer getIndex() {
        return index;
    }

    public String getColumnName() {
        String alias = queryColumn.getAlias();
        return (alias == null) ? this.queryColumn.getName() : alias;
    }

    @JsonIgnore
    public boolean isMaskable() {
        return this.queryColumn.isMaskable();
    }

    @JsonIgnore
    public boolean isFilterValue() {
        return filterValue;
    }

    public boolean isFilterLabel() {
        return filterLabel;
    }

    public String toSql(String tabKey, String queryKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_TAB_COLUMN\"(TAB_ID, QUERY_COLUMN_ID, INDEX, FILTERVALUE, FILTERLABEL) VALUES (");
        sqlBuilder.append("(SELECT ID FROM CONF_TAB WHERE KEY = '" + tabKey + "'),");
        sqlBuilder.append("(SELECT qc.ID FROM CONF_QUERY_COLUMN qc JOIN CONF_QUERY q ON q.ID = qc.QUERY_ID WHERE q.KEY = '" + queryKey + "' AND qc.INDEX = " + this.queryColumn.getIndex() + "), ");
        sqlBuilder.append(this.index + ", ");
        sqlBuilder.append(this.filterValue ? "1, " : "0, ");
        sqlBuilder.append(this.filterLabel ? "1" : "0");
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
