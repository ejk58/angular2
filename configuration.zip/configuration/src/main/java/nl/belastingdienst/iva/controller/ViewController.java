package nl.belastingdienst.iva.controller;

import nl.belastingdienst.iva.database.configuration.view.ViewDefinition;
import nl.belastingdienst.iva.service.ViewDefinitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/views")
public class ViewController {
    private final ViewDefinitionService viewDefinitionService;

    @Autowired
    public ViewController(ViewDefinitionService viewDefinitionService) {
        this.viewDefinitionService = viewDefinitionService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<ViewDefinition> list() {
        return viewDefinitionService.findAll();
    }

    @RequestMapping(value = "oneview", method = RequestMethod.GET)
    public List<ViewDefinition> getTab(@RequestParam("key") String key) {
        return viewDefinitionService.findByKey(key);
    }
}
