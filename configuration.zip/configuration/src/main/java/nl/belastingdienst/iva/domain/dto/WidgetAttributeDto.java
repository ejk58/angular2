package nl.belastingdienst.iva.domain.dto;

public class WidgetAttributeDto {
    private Integer id;
    private Integer widgetId;
    private String key;
    private String value;
    
    public WidgetAttributeDto() {
        super();
    }

    public WidgetAttributeDto(Integer id, String key, String value, Integer widgetId) {
        this.id = id;
        this.widgetId = widgetId;
        this.key = key;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getWidgetId() {
        return widgetId;
    }

    public void setWidgetId(Integer widgetId) {
        this.widgetId = widgetId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
