package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.datasource.DatasourceDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DatasourceDefinitionRepository extends JpaRepository<DatasourceDefinition, Long> {

}
