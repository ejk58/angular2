package nl.belastingdienst.iva.service.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn;
import nl.belastingdienst.iva.domain.dto.QueryDto;
import nl.belastingdienst.iva.repository.QueryColumnDefinitionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinition;
import nl.belastingdienst.iva.repository.QueryDefinitionRepository;
import nl.belastingdienst.iva.service.QueryDefinitionService;

import java.util.List;

@Service
@Transactional
public class QueryDefinitionServiceImpl implements QueryDefinitionService {
    private final Logger log = LoggerFactory.getLogger(QueryDefinitionServiceImpl.class);

    private final QueryDefinitionRepository queryDefinitionRepository;
    private final QueryColumnDefinitionRepository queryColumnDefinitionRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    public QueryDefinitionServiceImpl(QueryDefinitionRepository queryDefinitionRepository, QueryColumnDefinitionRepository queryColumnDefinitionRepository) {
        this.queryDefinitionRepository = queryDefinitionRepository;
        this.queryColumnDefinitionRepository = queryColumnDefinitionRepository;
    }

    @Transactional(readOnly = true)
    public List<QueryDto> getList() {
        List<QueryDto> queryWidgetDtos = queryDefinitionRepository.findAllDTOByOrderByViewNameAsc();
        return queryWidgetDtos;
    }

    
    @Transactional(readOnly = true)
    public QueryDefinition findQueryDefinitionById(int id) {
        return queryDefinitionRepository.getOne(id);
    }

    @Transactional(readOnly = false)
    public QueryDefinition save(QueryDefinition queryDefinition) {
        return queryDefinitionRepository.saveAndFlush(queryDefinition);
        //return null;
    }

    @Transactional(readOnly = false)
    public QueryDefinitionColumn save(QueryDefinitionColumn queryDefinitionColumn) {
        return queryColumnDefinitionRepository.saveAndFlush(queryDefinitionColumn);
    }

    @Transactional(readOnly = false)
    public void delete(Integer queryDefinitionColumnId) {
        queryColumnDefinitionRepository.delete(queryDefinitionColumnId);
    }

    @Transactional(readOnly = true)
    public List<String> findAllColumnTypes() {
        return queryColumnDefinitionRepository.findAllDistinctColumnTypesOrderByTypeAsc();
    }

}
