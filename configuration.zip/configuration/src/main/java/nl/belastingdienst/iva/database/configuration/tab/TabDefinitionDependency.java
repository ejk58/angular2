package nl.belastingdienst.iva.database.configuration.tab;

import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_TAB_TYPE_DEPENDENCY")
public class TabDefinitionDependency {

    @Id
    private Integer id;

    private String dependency;

    public Integer getId() {
        return id;
    }

    public String getDependency() {
        return dependency;
    }

    public String toSql(String tabTypeDependencyKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_TAB_TYPE_DEPENDENCY\"(TAB_TYPE_DEPENDENCY_GROUP_ID, DEPENDENCY) VALUES (");
        sqlBuilder.append("(SELECT ID FROM CONF_TAB_TYPE_DEPENDENCY_GROUP WHERE KEY = '" + tabTypeDependencyKey + "'), ");
        sqlBuilder.append(ExportUtils.getString(this.dependency));
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
