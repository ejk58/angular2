package nl.belastingdienst.iva.service;

import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinition;
import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinitionAttribute;
import nl.belastingdienst.iva.domain.DataMap;
import nl.belastingdienst.iva.domain.dto.WidgetDto;

import java.util.List;

public interface WidgetDefinitionService {
    void delete(WidgetDefinitionAttribute widgetDefinitionAttribute);

    List<WidgetDto> findAll();

    List<String> findAllTypes();
    
    List<DataMap> findAllAttributes();
    
    WidgetDefinition save(WidgetDefinition widgetDefinition);

    WidgetDefinition clone(WidgetDefinition widgetDefinition);

    WidgetDefinitionAttribute save(WidgetDefinitionAttribute widgetDefinitionAttribute);

    WidgetDefinition getWidgetDefinition(int id);

    void deleteTabWidgetDefinitionById(int tabWidgetId);
}
