package nl.belastingdienst.iva.database.configuration.help;

import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;

@Entity
@Table(name = "CONF_HELP")
public class HelpDefinition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    private String key;
    private String title;
    private String content;

    public Integer getId() { return id; }

    public String getKey() { return key; }

    public String getTitle() { return title; }

    public String getContent() { return content; }

    public String toSql() {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_HELP\"(KEY, TITLE, CONTENT) VALUES (");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.title) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.content));
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
