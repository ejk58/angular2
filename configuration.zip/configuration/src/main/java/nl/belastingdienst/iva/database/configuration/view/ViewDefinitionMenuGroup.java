package nl.belastingdienst.iva.database.configuration.view;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import nl.belastingdienst.iva.util.ExportUtils;

@Entity
@Table(name = "CONF_VIEW_MENUGROUP")
public class ViewDefinitionMenuGroup {

    @Id
    private Integer id;
    private Integer index;
    private String title;
    @Column(name = "ICONNAME")
    private String iconName;
    
    public Integer getId() {
        return id;
    }

    public Integer getIndex() {
        return index;
    }

    public String getTitle() {
        return title;
    }

    public String getIconName() {
        return iconName;
    }

    public String toSql(String viewKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_VIEW_MENUGROUP\"(VIEW_ID, TITLE, ICONNAME, INDEX) VALUES (");
        sqlBuilder.append("(SELECT ID FROM CONF_VIEW WHERE KEY = '" + viewKey + "'), ");

        sqlBuilder.append(ExportUtils.getString(this.title) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.iconName) + ", ");
        sqlBuilder.append(this.index);
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
