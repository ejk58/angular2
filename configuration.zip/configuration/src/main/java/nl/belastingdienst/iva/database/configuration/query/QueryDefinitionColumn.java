package nl.belastingdienst.iva.database.configuration.query;

import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "CONF_QUERY_COLUMN")
public class QueryDefinitionColumn {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "QUERY_ID")
    private Integer queryId;


    @Column(name = "COMPOSITE_COLUMN_ID")
    private Integer compositeColumnId;

    private Integer index;
    private String name;
    private String alias;
    private String value;
    private String key;
    private String type;
    private boolean maskable;

    @OneToMany
    @JoinColumn(name = "COMPOSITE_COLUMN_ID")
    @OrderBy(value = "index")
    private List<nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn> columns;

    public Integer getId() {
        return this.id;
    }

    public List<nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn> getColumns() {
        return Collections.unmodifiableList(this.columns);
    }

    public Integer getIndex() {
        return this.index;
    }

    public String getName() {
        return this.name;
    }

    public String getAlias() {
        return this.alias;
    }

    public String getValue() {
        return this.value;
    }

    public String getKey() {
        return this.key;
    }

    public String getType() {
        return this.type;
    }

    public boolean isMaskable() {
        return this.maskable;
    }

    public Boolean isComposite() {
        return (this.columns != null) && !columns.isEmpty();
    }

    public String toSql(String querySelect, String queryColumnSelect) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES (");
        if (querySelect != null) {
            sqlBuilder.append(querySelect + ", ");
            sqlBuilder.append("null, ");
        } else {
            sqlBuilder.append("null, ");
            sqlBuilder.append(queryColumnSelect + ", ");
        }
        sqlBuilder.append(this.index + ", ");
        sqlBuilder.append(ExportUtils.getString(this.name) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.alias) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.value) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.type) + ", ");
        sqlBuilder.append(this.maskable ? "1" : "0");
        sqlBuilder.append(");\n");

        for (nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn queryDefinitionColumn : this.columns) {
        	String querySubColumnSelect = (querySelect != null) ?
        			"(SELECT ID from CONF_QUERY_COLUMN WHERE QUERY_ID = " + querySelect + " AND INDEX = " + this.index + ")" :
        			"(SELECT ID from CONF_QUERY_COLUMN WHERE COMPOSITE_COLUMN_ID = " + queryColumnSelect + " AND INDEX = " + this.index + ")";

            sqlBuilder.append(queryDefinitionColumn.toSql(null, querySubColumnSelect));
        }

        return sqlBuilder.toString();
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setMaskable(boolean maskable) {
        this.maskable = maskable;
    }

    public void setColumns(List<QueryDefinitionColumn> columns) {
        this.columns = columns;
    }

    public Integer getQueryId() {
        return queryId;
    }

    public void setQueryId(Integer queryId) {
        this.queryId = queryId;
    }

    public Integer getCompositeColumnId() {
        return compositeColumnId;
    }

    public void setCompositeColumnId(Integer compositeColumnId) {
        this.compositeColumnId = compositeColumnId;
    }
}
