package nl.belastingdienst.iva.database.configuration.tab;


import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;
import java.util.Collections;
import java.util.List;

@Entity
@Table(name = "CONF_TAB_TYPE_DEPENDENCY_GROUP")
@NamedQuery(name = nl.belastingdienst.iva.database.configuration.tab.TabDefinitionDependencyGroup.QUERY_GETTABDEFINITIONTYPEDEPENDENCYGROUPS, query = "SELECT t FROM TabDefinitionDependencyGroup t ORDER BY t.key")
public class TabDefinitionDependencyGroup {

    public static final String QUERY_GETTABDEFINITIONTYPEDEPENDENCYGROUPS = "TabDefinitionDependencyGroup.getTabDefinitionDependencyGroups";

    @Id
    private Integer id;

    private String key;

    private String label;

    @OneToMany
    @JoinColumn(name = "TAB_TYPE_DEPENDENCY_GROUP_ID")
    private List<nl.belastingdienst.iva.database.configuration.tab.TabDefinitionDependency> dependencies;

    public Integer getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public String getLabel() {
        return label;
    }

    public List<nl.belastingdienst.iva.database.configuration.tab.TabDefinitionDependency> getDependencies() {
        return Collections.unmodifiableList(dependencies);
    }

    public String toSql() {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- Dependency-group " + this.key + "\n");

        sqlBuilder.append("INSERT INTO \"CONF_TAB_TYPE_DEPENDENCY_GROUP\"(KEY, LABEL) VALUES (");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.label));
        sqlBuilder.append(");\n");

        for (TabDefinitionDependency dependency : this.dependencies) {
            sqlBuilder.append(dependency.toSql(this.key));
        }

        sqlBuilder.append("\n");
        return sqlBuilder.toString();
    }
}
