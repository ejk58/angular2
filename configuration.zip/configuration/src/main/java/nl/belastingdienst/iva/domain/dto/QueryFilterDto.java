package nl.belastingdienst.iva.domain.dto;

public class QueryFilterDto {
    private Integer id;
    private String filterTemplate;
    private String noFilterTemplate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFilterTemplate() {
        return filterTemplate;
    }

    public void setFilterTemplate(String filterTemplate) {
        this.filterTemplate = filterTemplate;
    }

    public String getNoFilterTemplate() {
        return noFilterTemplate;
    }

    public void setNoFilterTemplate(String noFilterTemplate) {
        this.noFilterTemplate = noFilterTemplate;
    }
}
