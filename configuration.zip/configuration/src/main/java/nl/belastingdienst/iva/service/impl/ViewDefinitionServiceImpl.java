package nl.belastingdienst.iva.service.impl;

import nl.belastingdienst.iva.database.configuration.view.ViewDefinition;
import nl.belastingdienst.iva.repository.ViewDefinitionRepository;
import nl.belastingdienst.iva.service.ViewDefinitionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Service
@Transactional
public class ViewDefinitionServiceImpl implements ViewDefinitionService {

    private final Logger log = LoggerFactory.getLogger(ViewDefinitionServiceImpl.class);

    @Autowired
    private ViewDefinitionRepository viewDefinitionRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional(readOnly = true)
    public List<ViewDefinition> findAll() {
        return viewDefinitionRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<ViewDefinition> findByKey(String key) {
        return viewDefinitionRepository.findByKeyContaining(key);
    }

    @Override
    public ViewDefinition findById(Integer viewId) {
        ViewDefinition one = viewDefinitionRepository.getOne(viewId);
        return one;
    }

    @Override
    public ViewDefinition save(ViewDefinition viewDefinition) {
        return viewDefinitionRepository.saveAndFlush(viewDefinition);
    }
}