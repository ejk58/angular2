package nl.belastingdienst.iva.controller;

import nl.belastingdienst.iva.domain.MessageType;
import nl.belastingdienst.iva.domain.ValidateMessage;
import nl.belastingdienst.iva.domain.ValidateQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

@CrossOrigin
@RestController
@RequestMapping("/api/validate")
public class ValidationController {

    @Autowired
    private EntityManager entityManager;
    
    @RequestMapping(method = RequestMethod.GET)
    public List<ValidateMessage> validate() {
    	List<ValidateMessage> messages = new ArrayList<ValidateMessage>();
    	
    	for (ValidateQuery validateQuery : ValidateQuery.values()) {
    		messages.addAll(check(validateQuery));
    	}
    	
    	if (messages.isEmpty()) {
    		messages.add(new ValidateMessage(MessageType.INFORMATION, "There are no validation messages."));
    	}
    	
    	return messages;
    }

    private List<ValidateMessage> check(ValidateQuery validateQuery) {
        Query query = this.entityManager.createNativeQuery(validateQuery.getQuery());
        List<?> resultList = query.getResultList();
        List<ValidateMessage> resultMessage = new ArrayList<ValidateMessage>();

        if (!resultList.isEmpty()) {
        	StringBuilder messageBuilder = new StringBuilder();
	        for (Object result : resultList) {
	        	if (messageBuilder.length() > 0) {
	        		messageBuilder.append(", ");
	        	}

	            messageBuilder.append((String) result);
	        }

        	resultMessage.add(new ValidateMessage(validateQuery.getMessageType(), validateQuery.getBaseMessage() + messageBuilder.toString()));
        }
        
        return resultMessage;
    }
}
