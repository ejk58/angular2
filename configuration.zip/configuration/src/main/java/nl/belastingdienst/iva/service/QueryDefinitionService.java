package nl.belastingdienst.iva.service;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinition;
import nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn;
import nl.belastingdienst.iva.domain.dto.QueryDto;

import java.util.List;

public interface QueryDefinitionService {

    List<QueryDto> getList();

    QueryDefinition findQueryDefinitionById(int id);

    QueryDefinition save(QueryDefinition queryDefinition);

    QueryDefinitionColumn save(QueryDefinitionColumn queryDefinitionColumn);

    void delete(Integer queryDefinitionColumnId);

    List<String> findAllColumnTypes();

}
