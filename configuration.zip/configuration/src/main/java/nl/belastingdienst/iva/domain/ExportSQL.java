package nl.belastingdienst.iva.domain;


public class ExportSQL {
    private String content;

    public ExportSQL(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
