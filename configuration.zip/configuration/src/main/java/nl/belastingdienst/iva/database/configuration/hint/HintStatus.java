package nl.belastingdienst.iva.database.configuration.hint;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "HINT_STATUS")
@NamedQuery(name = "HintStatus.reset", query = "DELETE FROM HintStatus hs WHERE hs.username = :username")
public class HintStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String username;

    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    @Column(name = "HINT_ID", updatable = false, insertable = false)
    private Integer hintId;

    public HintStatus() {
        // Default constructor
    }

    public HintStatus(String username) {
        this.username = username;
        this.created = new Date();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getHintId() {
        return hintId;
    }

    public void setHintId(Integer hintId) {
        this.hintId = hintId;
    }
}
