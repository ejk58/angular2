package nl.belastingdienst.iva.database.configuration.tab;

import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;

@Entity
@Table(name = "CONF_TAB_ATTRIBUTE")
public class TabDefinitionAttribute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private int id;

    private String key;
    private String value;

    public int getId() {
        return this.id;
    }

    public String getKey() {
        return this.key;
    }

    public String getValue() {
        return this.value;
    }

    public String toSql(String tabKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_TAB_ATTRIBUTE\"(TAB_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append("(SELECT t.ID from CONF_TAB t WHERE t.KEY='" + tabKey + "'), ");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.value));
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setValue(String value) {
        this.value = value;
    }
}

