package nl.belastingdienst.iva;

import nl.belastingdienst.iva.repository.DetachRepository;
import nl.belastingdienst.iva.repository.DetachRepositoryImpl;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.web.ErrorViewResolver;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.util.Collections;
import java.util.Map;

@SpringBootApplication
@EnableTransactionManagement
@EnableJpaRepositories
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(new Object[]{Application.class}, args);
    }

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    public DetachRepository detachRepository() {
        return new DetachRepositoryImpl();
    }

    @Bean
    ErrorViewResolver supportPathBasedLocationStrategyWithoutHashes() {
        return new ErrorViewResolver() {
            @Override
            public ModelAndView resolveErrorView(HttpServletRequest request, HttpStatus status, Map<String, Object> model) {
                return status == HttpStatus.NOT_FOUND ? new ModelAndView("", Collections.<String, Object>emptyMap(), HttpStatus.OK) : null;
            }
        };
    }

    @ConfigurationProperties(prefix = "datasource.db2")
    @Bean
    @Primary
    public DataSource db2DataSource() {
        return DataSourceBuilder.create().build();
    }

    @ConfigurationProperties(prefix = "datasource.teradata")
    @Bean
    public DataSource teraDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    JdbcTemplate jdbcTemplate(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(teraDataSource());
        return jdbcTemplate;
    }
}
