package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.help.HelpDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HelpDefinitionRepository extends JpaRepository<HelpDefinition, Long> {

}
