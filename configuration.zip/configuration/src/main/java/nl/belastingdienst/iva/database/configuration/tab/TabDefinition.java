package nl.belastingdienst.iva.database.configuration.tab;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinition;
import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionView;
import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "CONF_TAB")
public class TabDefinition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String key;

    private String title;

    @OneToOne
    private QueryDefinition query;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "TAB_ID")
    private List<TabDefinitionView> tabDefinitionViews = new ArrayList<TabDefinitionView>();

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "TAB_ID")
    @OrderBy(value = "index")
    private List<TabDefinitionColumn> tabDefinitionColumns = new ArrayList<TabDefinitionColumn>();

    @OneToMany
    @JoinColumn(name = "TAB_ID")
    @OrderBy(value = "key")
    private List<TabDefinitionAttribute> tabAttributes = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tabDefinition")
    @OrderBy(value = "rowIndex, columnIndex")
    private List<TabDefinitionWidget> tabDefinitionWidgets = new ArrayList<TabDefinitionWidget>();

    @ManyToOne(optional = true)
    @JoinColumn(name = "TAB_TYPE_DEPENDENCY_GROUP_ID", nullable = false, updatable = false)
    private TabDefinitionDependencyGroup tabDefinitionDependencyGroup;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key.toLowerCase().replace(' ', '-');
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public QueryDefinition getQuery() {
        return query;
    }

    public void setQuery(QueryDefinition query) {
        this.query = query;
    }

    public List<TabDefinitionWidget> getTabDefinitionColumns() {
        return Collections.unmodifiableList(tabDefinitionWidgets);
    }

    public void setTabDefinitionColumns(List<TabDefinitionColumn> tabDefinitionColumns) {
        this.tabDefinitionColumns = tabDefinitionColumns;
    }

    public List<TabDefinitionColumn> getTabDefinitionFilterLabels() {
        return Collections.unmodifiableList(tabDefinitionColumns);
    }

    public List<TabDefinitionWidget> getTabDefinitionWidgets() {
        return Collections.unmodifiableList(tabDefinitionWidgets);
    }

    public void setTabDefinitionWidgets(List<TabDefinitionWidget> tabDefinitionWidgets) {
        this.tabDefinitionWidgets = tabDefinitionWidgets;
    }

    public TabDefinitionDependencyGroup getTabDefinitionDependencyGroup() {
        return tabDefinitionDependencyGroup;
    }

    public void setTabDefinitionDependencyGroup(TabDefinitionDependencyGroup tabDefinitionDependencyGroup) {
        this.tabDefinitionDependencyGroup = tabDefinitionDependencyGroup;
    }

    public List<TabDefinitionView> getTabDefinitionViews() {
		return tabDefinitionViews;
	}

	public void setTabDefinitionViews(List<TabDefinitionView> tabDefinitionViews) {
		this.tabDefinitionViews = tabDefinitionViews;
	}
	
    public String toSql() {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- Tab " + this.key + "\n");

        sqlBuilder.append("INSERT INTO \"CONF_TAB\"(KEY, TITLE, QUERY_ID, TAB_TYPE_DEPENDENCY_GROUP_ID) VALUES (");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.title) + ", ");
        sqlBuilder.append(this.query == null ? "null, " : "(SELECT ID FROM CONF_QUERY WHERE KEY = '" + this.query.getKey() + "'), ");
        sqlBuilder.append(this.tabDefinitionDependencyGroup == null ? "null" : "(SELECT ID FROM CONF_TAB_TYPE_DEPENDENCY_GROUP WHERE KEY = '" + this.tabDefinitionDependencyGroup.getKey() + "')");
        sqlBuilder.append(");\n");

        if (this.query != null) {
            for (TabDefinitionColumn tabDefinitionColumn : this.tabDefinitionColumns) {
                sqlBuilder.append(tabDefinitionColumn.toSql(this.key, this.query.getKey()));
            }
        }

        for (TabDefinitionAttribute tabDefinitionAttribute : this.tabAttributes) {
            sqlBuilder.append(tabDefinitionAttribute.toSql(this.key));
        }

        for (TabDefinitionView tabDefinitionView : this.tabDefinitionViews) {
            sqlBuilder.append(tabDefinitionView.toSql(this.key));
        }

        for (TabDefinitionWidget tabDefinitionWidget : this.tabDefinitionWidgets) {
            sqlBuilder.append(tabDefinitionWidget.toSql(this.key));
        }

        sqlBuilder.append("\n");
        
        return sqlBuilder.toString();
    }

    public void addTabDefitionWidget(TabDefinitionWidget tabDefinitionWidget) {
        this.tabDefinitionWidgets.add(tabDefinitionWidget);
    }
}
