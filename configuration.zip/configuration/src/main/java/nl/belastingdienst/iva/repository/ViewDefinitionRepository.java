package nl.belastingdienst.iva.repository;


import nl.belastingdienst.iva.database.configuration.view.ViewDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ViewDefinitionRepository extends JpaRepository<ViewDefinition, Integer> {

    List<ViewDefinition> findByKeyContaining(String key);

}
