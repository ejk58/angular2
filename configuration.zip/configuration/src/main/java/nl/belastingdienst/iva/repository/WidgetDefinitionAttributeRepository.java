package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinitionAttribute;
import nl.belastingdienst.iva.domain.dto.WidgetAttributeDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface WidgetDefinitionAttributeRepository extends JpaRepository<WidgetDefinitionAttribute, Long> {
    @Query("SELECT " +
            "new nl.belastingdienst.iva.domain.dto.WidgetAttributeDto(a.id, a.key, a.value, a.widgetDefinition.id) " +
            "FROM WidgetDefinitionAttribute a WHERE a.widgetDefinition.id = :widgetId")
    List<WidgetAttributeDto> findAllDTOByWidgetId(@Param("widgetId") int widgetId);
    
    @Query("SELECT new nl.belastingdienst.iva.domain.dto.WidgetAttributeDto(a.id, a.key, a.value, a.widgetDefinition.id) FROM WidgetDefinitionAttribute a ORDER BY a.key, a.value ASC")
    List<WidgetAttributeDto> findAllAttributesByOrderByAttributeAsc();
}
