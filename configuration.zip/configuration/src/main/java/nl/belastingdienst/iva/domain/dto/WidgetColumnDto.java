package nl.belastingdienst.iva.domain.dto;

import java.util.List;

public class WidgetColumnDto {
    
    private Integer id;
    private Integer index;
    private String type;
    private String style;
    private Integer level;
    private String label;
    private boolean visible;
    private boolean sortable;
    private boolean summable;
    private boolean comparable;
    private boolean filterable;
    private QueryColumnDto queryColumn;
    private List<WidgetColumnDto> columns;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getIndex() {
        return index;
    }
    public void setIndex(Integer index) {
        this.index = index;
    }
    public String getStyle() {
        return style;
    }
    public void setStyle(String style) {
        this.style = style;
    }
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
    public String getLabel() {
        return label;
    }
    public void setLabel(String label) {
        this.label = label;
    }
    public QueryColumnDto getQueryColumn() {
        return queryColumn;
    }
    public void setQueryColumn(QueryColumnDto queryColumn) {
        this.queryColumn = queryColumn;
    }
    public List<WidgetColumnDto> getColumns() {
        return columns;
    }
    public void setColumns(List<WidgetColumnDto> columns) {
        this.columns = columns;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public boolean isVisible() {
        return visible;
    }
    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    public boolean isSortable() {
        return sortable;
    }
    public void setSortable(boolean sortable) {
        this.sortable = sortable;
    }
    public boolean isSummable() {
        return summable;
    }
    public void setSummable(boolean summable) {
        this.summable = summable;
    }
    public boolean isComparable() {
        return comparable;
    }
    public void setComparable(boolean comparable) {
        this.comparable = comparable;
    }
    public boolean isFilterable() {
        return filterable;
    }
    public void setFilterable(boolean filterable) {
        this.filterable = filterable;
    }

}
