package nl.belastingdienst.iva.database.configuration.hint;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
@NamedQuery(name = "Hint.getHints", query = "SELECT h FROM Hint h WHERE h.id NOT IN (SELECT hs.hintId FROM HintStatus hs where hs.username = :username) ORDER BY h.index")
public class Hint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private int radius;


    private String event;
    @Column(name = "ELEMENT_ID")
    private String elementId;

    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    private String title;

    private String content;

    private String index;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "HINT_ID")
    private List<nl.belastingdienst.iva.database.configuration.hint.HintStatus> states = new ArrayList<nl.belastingdienst.iva.database.configuration.hint.HintStatus>();

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getElementId() {
        return elementId;
    }

    public void setElementId(String elementId) {
        this.elementId = elementId;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public List<nl.belastingdienst.iva.database.configuration.hint.HintStatus> getStates() {
        return Collections.unmodifiableList(this.states);
    }

    public void setStates(List<nl.belastingdienst.iva.database.configuration.hint.HintStatus> states) {
        this.states = states;
    }

    public void addState(HintStatus hintStatus) {
        this.states.add(hintStatus);
    }
}
