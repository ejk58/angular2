package nl.belastingdienst.iva.service;

import nl.belastingdienst.iva.database.configuration.view.ViewDefinition;

import java.util.List;

public interface ViewDefinitionService {
    List<ViewDefinition> findAll();

    List<ViewDefinition> findByKey(String key);

    ViewDefinition findById(Integer viewId);

    ViewDefinition save(ViewDefinition viewDefinition);
}
