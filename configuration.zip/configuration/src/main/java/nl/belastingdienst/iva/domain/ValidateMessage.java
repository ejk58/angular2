package nl.belastingdienst.iva.domain;

public class ValidateMessage {

	private MessageType type;
	private String message;

	public ValidateMessage(MessageType type, String message) {
		this.type = type;
		this.message = message;
	}
	
	public MessageType getType() {
		return type;
	}
	
	public String getMessage() {
		return message;
	}
}
