package nl.belastingdienst.iva.domain.dto;

import java.util.List;

public class QueryColumnDto {
    
    private Integer id;
    private Integer queryId;
    private Integer compositeColumnId;
    private Integer index;
    private String name;
    private String alias;
    private boolean maskable;
    private String key;
    private String type;
    private String value;
    private List<QueryColumnDto> columns;
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getIndex() {
        return index;
    }
    public void setIndex(Integer index) {
        this.index = index;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAlias() {
        return alias;
    }
    public void setAlias(String alias) {
        this.alias = alias;
    }
    public boolean isMaskable() {
        return maskable;
    }
    public void setMaskable(boolean maskable) {
        this.maskable = maskable;
    }
    public List<QueryColumnDto> getColumns() {
        return columns;
    }
    public void setColumns(List<QueryColumnDto> columns) {
        this.columns = columns;
    }

    public Integer getQueryId() {
        return queryId;
    }

    public void setQueryId(Integer queryId) {
        this.queryId = queryId;
    }

    public Integer getCompositeColumnId() {
        return compositeColumnId;
    }

    public void setCompositeColumnId(Integer compositeColumnId) {
        this.compositeColumnId = compositeColumnId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
