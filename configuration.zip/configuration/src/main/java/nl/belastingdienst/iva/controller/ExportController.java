package nl.belastingdienst.iva.controller;

import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinition;
import nl.belastingdienst.iva.domain.ExportSQL;
import nl.belastingdienst.iva.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/api/export")
public class ExportController {

    @Autowired
    private HelpDefinitionRepository helpDefinitionRepository;

    @Autowired
    private DatasourceDefinitionRepository datasourceDefinitionRepository;

    @Autowired
    private AttributeGroupRepository attributeGroupRepository;

    @Autowired
    private TabDefinitionDependencyGroupRepository tabDefinitionDependencyGroupRepository;

    @Autowired
    private QueryDefinitionRepository queryDefinitionRepository;

    @Autowired
    private WidgetDefinitionRepository widgetDefinitionRepository;

    @Autowired
    private ViewDefinitionRepository viewDefinitionRepository;

    @Autowired
    private TabDefinitionRepository tabDefinitionRepository;

    @RequestMapping(method = RequestMethod.GET)
    public ExportSQL list() {
        List<WidgetDefinition> widgetList = getWidgets();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(createDeleteScript());
        sqlBuilder.append(addHelpInsertScript());
        sqlBuilder.append(createInsertScript(this.datasourceDefinitionRepository.findAll(), datasource -> datasource.toSql()));
        sqlBuilder.append(createInsertScript(this.attributeGroupRepository.findAll(), attributeGroup -> attributeGroup.toSql()));
        sqlBuilder.append(createInsertScript(this.tabDefinitionDependencyGroupRepository.findAll(), dependencyGroup -> dependencyGroup.toSql()));
        sqlBuilder.append(createInsertScript(this.queryDefinitionRepository.findAll(), query -> query.toSql()));
        sqlBuilder.append(createInsertScript(widgetList, widget -> widget.toSql()));
        sqlBuilder.append(createInsertScript(this.viewDefinitionRepository.findAll(), view -> view.toSql()));
        sqlBuilder.append(createInsertScript(this.tabDefinitionRepository.findAll(), tab -> tab.toSql()));

        return new ExportSQL(sqlBuilder.toString());
    }

    private String addHelpInsertScript() {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- Help \n");
        sqlBuilder.append(createInsertScript(this.helpDefinitionRepository.findAll(), help -> help.toSql()));
        sqlBuilder.append("\n");
        return sqlBuilder.toString();
    }

    private String createDeleteScript() {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("DELETE FROM \"CONF_HELP\";\n" +
                "DELETE FROM \"CONF_TAB_WIDGET\";\n" +
                "DELETE FROM \"CONF_TAB_COLUMN\";\n" +
                "DELETE FROM \"CONF_TAB_VIEW\";\n" +
                "DELETE FROM \"CONF_TAB_ATTRIBUTE\";\n" +
                "DELETE FROM \"CONF_TAB\";\n\n");
        sqlBuilder.append("DELETE FROM \"CONF_VIEW_ROLE\";\n" +
                "DELETE FROM \"CONF_VIEW_PATHKEY\";\n" +
                "DELETE FROM \"CONF_VIEW_MENUGROUP\";\n" +
                "DELETE FROM \"CONF_VIEW_ATTRIBUTE\";\n" +
                "DELETE FROM \"CONF_VIEW_SUBJECT_TYPE\";\n" +
                "DELETE FROM \"CONF_VIEW\";\n\n");
        sqlBuilder.append("DELETE FROM \"CONF_WIDGET_HELP\";\n" +
                "DELETE FROM \"CONF_WIDGET_COLUMN\";\n" +
                "DELETE FROM \"CONF_WIDGET_ATTRIBUTE\";\n" +
                "DELETE FROM \"CONF_WIDGET\";\n\n");
        sqlBuilder.append("DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IS NOT NULL;\n" +
                "DELETE FROM \"CONF_QUERY_COLUMN\";\n" +
                "DELETE FROM \"CONF_QUERY_FILTER\";\n" +
                "DELETE FROM \"CONF_QUERY_ATTRIBUTE\";\n" +
                "DELETE FROM \"CONF_QUERY\";\n\n");
        sqlBuilder.append("DELETE FROM \"CONF_TAB_TYPE_DEPENDENCY\";\n" +
                "DELETE FROM \"CONF_TAB_TYPE_DEPENDENCY_GROUP\";\n\n");
        sqlBuilder.append("DELETE FROM \"CONF_ATTRIBUTE\";\n" +
                "DELETE FROM \"CONF_ATTRIBUTE_GROUP\";\n\n");

        return sqlBuilder.toString();
    }

    private <T> String createInsertScript(List<T> elementList, Function<T, String> sqlMapper) {
        return elementList.stream().map(sqlMapper).collect(Collectors.joining(""));
    }
    
    private List<WidgetDefinition> getWidgets() {
        List<WidgetDefinition> widgetList = this.widgetDefinitionRepository.findAll();
        Set<String> innerWidgetNameSet = new HashSet<String>();

        for (WidgetDefinition widget : widgetList) {
            List<WidgetDefinition> innerWidgetList = widget.getWidgetDefinitionList();
            for (WidgetDefinition innerWidget : innerWidgetList) {
                innerWidgetNameSet.addAll(getInnerWidgetNames(innerWidget));
            }
        }

        return widgetList.stream().filter(widget -> !innerWidgetNameSet.contains(widget.getName())).collect(Collectors.toList());
    }
    
    private Set<String> getInnerWidgetNames(WidgetDefinition widget) {
        Set<String> innerWidgetNameSet = new HashSet<String>();

        innerWidgetNameSet.add(widget.getName());
        List<WidgetDefinition> innerWidgetList = widget.getWidgetDefinitionList();
        if (innerWidgetList != null && !innerWidgetList.isEmpty()) {
            for (WidgetDefinition innerWidget : innerWidgetList) {
                innerWidgetNameSet.addAll(getInnerWidgetNames(innerWidget));
            }
        }

        return innerWidgetNameSet;
    }
}
