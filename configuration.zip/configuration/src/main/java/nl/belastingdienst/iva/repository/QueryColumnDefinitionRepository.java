package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface QueryColumnDefinitionRepository extends JpaRepository<QueryDefinitionColumn, Integer> {

    @Query("SELECT DISTINCT qdc.type FROM QueryDefinitionColumn qdc ORDER BY qdc.type ASC")
    List<String> findAllDistinctColumnTypesOrderByTypeAsc();

}
