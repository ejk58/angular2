package nl.belastingdienst.iva.util;

public class ExportUtils {
	
	private ExportUtils() {
		throw new UnsupportedOperationException();
	}

    public static String getString(String input) {
        if (input == null) {
            return "null";
        }
        
        String escapedInput = input.replaceAll("'", "''");
        return "'" + escapedInput + "'";
    }

    public static String getBoolean(Boolean input) {
        if (input == null) {
            return "null";
        }
        
        return input ? "1" : "0";
    }
}
