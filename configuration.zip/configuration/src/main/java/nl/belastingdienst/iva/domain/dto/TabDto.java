package nl.belastingdienst.iva.domain.dto;

public class TabDto {
    private Integer id;

    private String key;

    private String title;

    private Integer tabDefinitionDependencyGroupId;

    private Integer viewId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getViewId() {
        return viewId;
    }

    public void setViewId(Integer viewId) {
        this.viewId = viewId;
    }

    public Integer getTabDefinitionDependencyGroupId() {
        return tabDefinitionDependencyGroupId;
    }

    public void setTabDefinitionDependencyGroupId(Integer tabDefinitionDependencyGroupId) {
        this.tabDefinitionDependencyGroupId = tabDefinitionDependencyGroupId;
    }

    @Override
    public String toString() {
        return "TabDto{" +
                "id=" + id +
                ", key='" + key + '\'' +
                ", title='" + title + '\'' +
                ", tabDefinitionDependencyGroupId=" + tabDefinitionDependencyGroupId +
                ", viewId=" + viewId +
                '}';
    }
}
