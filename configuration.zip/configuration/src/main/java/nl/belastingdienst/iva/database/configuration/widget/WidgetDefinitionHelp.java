package nl.belastingdienst.iva.database.configuration.widget;

import nl.belastingdienst.iva.database.configuration.help.HelpDefinition;

import javax.persistence.*;

@Entity
@Table(name = "CONF_WIDGET_HELP")
public class WidgetDefinitionHelp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "WIDGET_ID")
    private WidgetDefinition widgetDefinition;

    @Column(name = "INDEX")
    private Integer index;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "HELP_ID")
    private HelpDefinition helpDefinition;

    public WidgetDefinition getWidgetDefinition() { return widgetDefinition; }

    public Integer getIndex() { return index; }

    public HelpDefinition getHelpDefinition() { return helpDefinition; }

    public String toSql(String widgetName) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_HELP\"(WIDGET_ID, INDEX, HELP_ID) VALUES (");
        sqlBuilder.append("(SELECT ID from CONF_WIDGET WHERE NAME = '" + widgetName + "'), ");
        sqlBuilder.append(this.index + ", ");
        sqlBuilder.append("(SELECT ID from CONF_HELP WHERE KEY = '" + this.helpDefinition.getKey() + "')");
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
