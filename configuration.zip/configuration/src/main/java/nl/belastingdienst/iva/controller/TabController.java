package nl.belastingdienst.iva.controller;

import nl.belastingdienst.iva.database.configuration.tab.TabDefinition;
import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionDependencyGroup;
import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionView;
import nl.belastingdienst.iva.database.configuration.view.ViewDefinition;
import nl.belastingdienst.iva.domain.dto.TabDto;
import nl.belastingdienst.iva.service.TabDefinitionService;
import nl.belastingdienst.iva.service.ViewDefinitionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value = "/api/tabs")
public class TabController {

    private final TabDefinitionService tabDefinitionService;
    private final ViewDefinitionService viewDefinitionService;
    private ModelMapper modelMapper;

    @Autowired
    public TabController(TabDefinitionService tabDefinitionService, ViewDefinitionService viewDefinitionService, ModelMapper modelMapper) {
        this.tabDefinitionService = tabDefinitionService;
        this.viewDefinitionService = viewDefinitionService;
        this.modelMapper = modelMapper;
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public TabDto save(@RequestBody TabDto tabDto) {
        TabDefinition tabDefinition = convertToEntity(tabDto);
        addViewToTabDefinition(tabDefinition, tabDto);
        TabDefinition tabDefinitionCreated = tabDefinitionService.save(tabDefinition);
        return convertToDto(tabDefinitionCreated);
    }

    private void addViewToTabDefinition(TabDefinition tabDefinition, TabDto tabDto) {
        ViewDefinition viewDefinition = viewDefinitionService.findById(tabDto.getViewId());
        int groupIndex = (viewDefinition == null ? 1 : viewDefinition.determineMaxGroupIndex() + 1);
        
        TabDefinitionView tabDefinitionView = new TabDefinitionView();
        tabDefinitionView.setViewDefinition(viewDefinition);
        tabDefinitionView.setTabDefinition(tabDefinition);
        tabDefinitionView.setGroupIndex(groupIndex);
        tabDefinitionView.setMemberIndex(1);
        
        viewDefinitionService.save(viewDefinition);
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<TabDto> list() {
        List<TabDefinition> tabs = tabDefinitionService.findAllByOrderByTitleAsc();
        List<TabDto> tabDtoList = new ArrayList<>();
        for (TabDefinition tabDefinition : tabs) {
            TabDto tabDto = convertToDto(tabDefinition);
            tabDtoList.add(tabDto);
        }
        return tabDtoList;
    }

    @RequestMapping(value = "/onetab", method = RequestMethod.GET)
    public List<TabDefinition> getTab(@RequestParam("key") String key) {
        return tabDefinitionService.findByKey(key);
    }

    @RequestMapping(value = "/dependencygroups", method = RequestMethod.GET)
    public List<TabDefinitionDependencyGroup> listDependencyGroups() {
        return tabDefinitionService.listDependencyGroups();
    }

    @RequestMapping(value = "/viewdomain/{viewId}", method = RequestMethod.GET)
    public List<String> listViewdomains(@PathVariable int viewId) {
        ViewDefinition viewDef = viewDefinitionService.findById(viewId);
        return viewDef.getDomains();
    }

    private TabDto convertToDto(TabDefinition tabDefinition) {
        TabDto tabDto = modelMapper.map(tabDefinition, TabDto.class);
        
        Iterator<TabDefinitionView> iterator = tabDefinition.getTabDefinitionViews().iterator();
        if (iterator.hasNext()) {
            tabDto.setViewId(iterator.next().getViewDefinition().getId());
        } else {
            tabDto.setViewId(0);
        }
        return tabDto;
    }

    private TabDefinition convertToEntity(TabDto tabDto) {
        TabDefinition tabDefinition = modelMapper.map(tabDto, TabDefinition.class);
        TabDefinitionDependencyGroup tddg = tabDefinitionService.findTabDefinitionDependencyGroupById(tabDto.getTabDefinitionDependencyGroupId());
        tabDefinition.setTabDefinitionDependencyGroup(tddg);
        return tabDefinition;
    }
}
