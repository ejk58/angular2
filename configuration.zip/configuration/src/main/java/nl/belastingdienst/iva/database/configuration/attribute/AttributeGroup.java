package nl.belastingdienst.iva.database.configuration.attribute;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import nl.belastingdienst.iva.util.ExportUtils;

@Entity
@Table(name = "CONF_ATTRIBUTE_GROUP")
public class AttributeGroup {

	@Id
	private Integer id;
	
	private String key;
	
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "ATTRIBUTE_GROUP_ID")
    @OrderBy("index ASC")
    private List<Attribute> attributes;

	public Integer getId() {
		return this.id;
	}

	public String getKey() {
		return this.key;
	}

	public List<Attribute> getAttributes() {
		return this.attributes;
	}
	
	public String toSql() {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- Attribute-group " + this.key + "\n");

        sqlBuilder.append("INSERT INTO \"CONF_ATTRIBUTE_GROUP\"(KEY) VALUES (");
        sqlBuilder.append(ExportUtils.getString(this.key));
        sqlBuilder.append(");\n");

        for (Attribute attribute : this.attributes) {
        	sqlBuilder.append(attribute.toSql(this.key));
        }
        
        sqlBuilder.append("\n");
        return sqlBuilder.toString();
	}
}
