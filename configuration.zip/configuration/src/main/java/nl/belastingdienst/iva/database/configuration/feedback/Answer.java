package nl.belastingdienst.iva.database.configuration.feedback;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@NamedQuery(name = "Answer.getAnswerForUser", query = "SELECT a FROM Answer a WHERE a.username = :username AND a.question = :question")
@Table(name = "FEEDBACK_ANSWER")
public class Answer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "QUESTION_ID", updatable = false)
    private nl.belastingdienst.iva.database.configuration.feedback.Question question;

    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    private String username;

    private Integer rating;

    private String explanation;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public nl.belastingdienst.iva.database.configuration.feedback.Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

}
