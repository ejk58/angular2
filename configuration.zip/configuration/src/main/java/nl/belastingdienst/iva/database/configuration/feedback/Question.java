package nl.belastingdienst.iva.database.configuration.feedback;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;
import java.util.Date;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@NamedQuery(name = "Question.getQuestion", query = "SELECT q FROM Question q WHERE CURRENT_TIMESTAMP BETWEEN q.start AND q.end order by q.end")
@Table(name = "FEEDBACK_QUESTION")
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Temporal(TemporalType.TIMESTAMP)
    @XmlTransient
    private Date start;

    @Temporal(TemporalType.TIMESTAMP)
    @XmlTransient
    private Date end;

    private String question;

    public Integer getId() {
        return id;
    }

    public Date getStart() {
        return start;
    }

    public Date getEnd() {
        return end;
    }

    public String getQuestion() {
        return question;
    }

}
