package nl.belastingdienst.iva.domain.dto;

public class TabWidgetDto {
    private int id;

    private int gridColumns;

    private int rowIndex;

    private int columnIndex;

    private int widgetId;

    private int tabId;

    private String widgetDefinitionName;

    public int getTabId() {
        return tabId;
    }

    public void setTabId(int tabId) {
        this.tabId = tabId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGridColumns() {
        return gridColumns;
    }

    public void setGridColumns(int gridColumns) {
        this.gridColumns = gridColumns;
    }

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public int getColumnIndex() {
        return columnIndex;
    }

    public void setColumnIndex(int columnIndex) {
        this.columnIndex = columnIndex;
    }

    public int getWidgetId() {
        return widgetId;
    }

    public void setWidgetId(int widgetId) {
        this.widgetId = widgetId;
    }

    public String getWidgetDefinitionName() {
        return this.widgetDefinitionName;
    }

    public void setWidgetDefinitionName(String widgetDefinitionName) {
        this.widgetDefinitionName = widgetDefinitionName;
    }
}