package nl.belastingdienst.iva.repository;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class DetachRepositoryImpl implements DetachRepository {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void detach(Object o) {
        entityManager.detach(o);
    }
}
