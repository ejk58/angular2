package nl.belastingdienst.iva.database.configuration.view;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinition;
import nl.belastingdienst.iva.domain.DataMap;
import nl.belastingdienst.iva.domain.Domain;
import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionView;
import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;
import java.util.*;
import java.util.stream.Collectors;

@Entity
@Table(name = "CONF_VIEW")
public class ViewDefinition {

    @Id
    private Integer id;
    private String key;
    private String name;
    @Column(name = "ICONNAME")
    private String iconName;
    private Integer index;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "VIEW_ID")
    @OrderBy(value = "groupIndex ASC, memberIndex ASC")
    private List<TabDefinitionView> tabDefinitionViews = new ArrayList<TabDefinitionView>();
    
    @OneToMany
    @JoinColumn(name = "VIEW_ID")
    private List<ViewDefinitionRole> roles = new ArrayList<ViewDefinitionRole>();

    @OneToMany
    @JoinColumn(name = "VIEW_ID")
    @OrderBy(value = "index ASC")
    private List<ViewDefinitionPathKey> pathKeys = new ArrayList<ViewDefinitionPathKey>();

    @OneToMany
    @JoinColumn(name = "VIEW_ID")
    @OrderBy(value = "index ASC")
    private List<ViewDefinitionMenuGroup> menuGroups = new ArrayList<ViewDefinitionMenuGroup>();

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "VIEW_ID")
    @OrderBy(value = "name ASC")
    private List<ViewDefinitionSubjectType> subjectTypes = new ArrayList<ViewDefinitionSubjectType>();

    @OneToOne
    @JoinColumn(name = "SEARCH_VIP_QUERY_ID")
    private QueryDefinition searchVipQueryDefinition;

    @OneToOne
    @JoinColumn(name = "SEARCH_NOVIP_QUERY_ID")
    private QueryDefinition searchNoVipQueryDefinition;

    @OneToOne
    @JoinColumn(name = "WIZARD_VIP_QUERY_ID")
    private QueryDefinition wizardVipQueryDefinition;

    @OneToOne
    @JoinColumn(name = "WIZARD_NOVIP_QUERY_ID")
    private QueryDefinition wizardNoVipQueryDefinition;

    @ElementCollection(fetch = FetchType.EAGER)
    @Column(name="VALUE")
    @MapKeyColumn(name="KEY")
    @CollectionTable(name="CONF_VIEW_ATTRIBUTE", joinColumns=@JoinColumn(name="VIEW_ID"))
    private Map<String, String> attributes = new HashMap<String, String>();

    @Transient
    private DataMap viewMap;

    public Integer getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }
    
    public String getIconName() {
        return iconName;
    }

    public Integer getIndex() {
        return index;
    }

    public List<String> getDomains() {
    	return this.tabDefinitionViews.
    			stream().
    			map(tabDefinitionView -> tabDefinitionView.getTabDefinition()).
    			map(tabDefinition -> tabDefinition.getKey()).
    			collect(Collectors.toList());
    }

    public List<ViewDefinitionRole> getRoles() {
        return Collections.unmodifiableList(this.roles);
    }

    public List<ViewDefinitionPathKey> getPathKeys() {
        return Collections.unmodifiableList(this.pathKeys);
    }

    public List<ViewDefinitionMenuGroup> getMenuGroups() {
        return Collections.unmodifiableList(this.menuGroups);
    }

    public List<ViewDefinitionSubjectType> getSubjectTypes() {
        return Collections.unmodifiableList(this.subjectTypes);
    }

    public QueryDefinition getSearchVipQueryDefinition() {
        return searchVipQueryDefinition;
    }

    public QueryDefinition getSearchNoVipQueryDefinition() {
        return searchNoVipQueryDefinition;
    }

    public QueryDefinition getWizardVipQueryDefinition() {
        return wizardVipQueryDefinition;
    }

    public QueryDefinition getWizardNoVipQueryDefinition() {
        return wizardNoVipQueryDefinition;
    }

    public DataMap getViewMap() {
        return this.viewMap == null ? Domain.emptyDataMap() : this.viewMap;
    }

    public void setViewMap(DataMap viewMap) {
        this.viewMap = viewMap;
    }

    @Override
    public int hashCode() {
        return this.key.hashCode();
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }

        if (object == null || getClass() != object.getClass()) {
            return false;
        }

        ViewDefinition otherViewDefinition = (ViewDefinition) object;
        return this.key.equals(otherViewDefinition.key);
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }
    
    public int determineMaxGroupIndex() {
    	int maxGroupIndex = 0;
    	
    	if (this.tabDefinitionViews != null) {
	    	for (TabDefinitionView tabDefinitionView : this.tabDefinitionViews) {
	    		int groupIndex = (tabDefinitionView.getGroupIndex() == null ? 0 : tabDefinitionView.getGroupIndex());
	    		maxGroupIndex = Math.max(groupIndex, maxGroupIndex);
	    	}
    	}
    	
    	return maxGroupIndex;
    }

    public String toSql() {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- View " + this.key + "\n");

        sqlBuilder.append("INSERT INTO \"CONF_VIEW\"(KEY, NAME, ICONNAME, INDEX, SEARCH_VIP_QUERY_ID, SEARCH_NOVIP_QUERY_ID, WIZARD_VIP_QUERY_ID, WIZARD_NOVIP_QUERY_ID) VALUES (");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.name) + ", ");
        sqlBuilder.append(this.iconName == null ? "null, " : ExportUtils.getString(this.iconName) + ", ");
        sqlBuilder.append(this.index + ", ");
        sqlBuilder.append(this.searchVipQueryDefinition == null ? "null, " : "(SELECT ID FROM CONF_QUERY WHERE KEY = '" + this.searchVipQueryDefinition.getKey() + "'), ");
        sqlBuilder.append(this.searchNoVipQueryDefinition == null ? "null, " : "(SELECT ID FROM CONF_QUERY WHERE KEY = '" + this.searchNoVipQueryDefinition.getKey() + "'), ");
        sqlBuilder.append(this.wizardVipQueryDefinition == null ? "null, " : "(SELECT ID FROM CONF_QUERY WHERE KEY = '" + this.wizardVipQueryDefinition.getKey() + "'), ");
        sqlBuilder.append(this.wizardNoVipQueryDefinition == null ? "null " : "(SELECT ID FROM CONF_QUERY WHERE KEY = '" + this.wizardNoVipQueryDefinition.getKey() + "') ");
        sqlBuilder.append(");\n");

        for (ViewDefinitionRole role : this.roles) {
            sqlBuilder.append(role.toSql(this.key));
        }

        for (ViewDefinitionPathKey pathKey : this.pathKeys) {
            sqlBuilder.append(pathKey.toSql(this.key));
        }

        for (ViewDefinitionMenuGroup menuGroup : this.menuGroups) {
            sqlBuilder.append(menuGroup.toSql(this.key));
        }

        for (String key : this.attributes.keySet()) {
            String value = this.attributes.get(key);
            sqlBuilder.append("INSERT INTO \"CONF_VIEW_ATTRIBUTE\"(VIEW_ID, KEY, VALUE) VALUES (");
            sqlBuilder.append("(SELECT ID from CONF_VIEW WHERE KEY = '").append(this.key).append("'), ");
            sqlBuilder.append(ExportUtils.getString(key)).append(", ");
            sqlBuilder.append(ExportUtils.getString(value));
            sqlBuilder.append(");\n");
        }

        for (ViewDefinitionSubjectType viewDefinitionSubjectType : this.subjectTypes) {
            sqlBuilder.append("INSERT INTO \"CONF_VIEW_SUBJECT_TYPE\"(VIEW_ID, NAME, TYPE) VALUES (");
            sqlBuilder.append("(SELECT ID from CONF_VIEW WHERE KEY = '").append(this.key).append("'), ");
            sqlBuilder.append(ExportUtils.getString(viewDefinitionSubjectType.getName())).append(", ");
            sqlBuilder.append(ExportUtils.getString(viewDefinitionSubjectType.getType()));
            sqlBuilder.append(");\n");
        }

        sqlBuilder.append("\n");
        return sqlBuilder.toString();
    }
}
