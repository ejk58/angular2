package nl.belastingdienst.iva.database.configuration.tab;


import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinition;

import javax.persistence.*;

@Entity
@Table(name = "CONF_TAB_WIDGET")
public class TabDefinitionWidget {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "GRID_COLUMNS")
    private Integer gridColumns;

    @Column(name = "ROW_INDEX")
    private Integer rowIndex;
    @Column(name = "COLUMN_INDEX")

    private Integer columnIndex;
    @JoinColumn(name = "WIDGET_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private WidgetDefinition widgetDefinition;
    @JoinColumn(name = "TAB_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TabDefinition tabDefinition;

    public TabDefinition getTabDefinition() {
        return tabDefinition;
    }

    public void setTabDefinition(TabDefinition tabDefinition) {
        this.tabDefinition = tabDefinition;
    }

    public Integer getId() {
        return id;
    }

    public WidgetDefinition getWidgetDefinition() {
        return widgetDefinition;
    }

    public void setWidgetDefinition(WidgetDefinition widgetDefinition) {
        this.widgetDefinition = widgetDefinition;
    }

    public Integer getGridColumns() {
        return gridColumns;
    }

    public void setGridColumns(Integer gridColumns) {
        this.gridColumns = gridColumns;
    }

    public Integer getColumnIndex() {
        return columnIndex;
    }

    public void setColumnIndex(Integer columnIndex) {
        this.columnIndex = columnIndex;
    }

    public Integer getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(Integer rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String toSql(String tabKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_TAB_WIDGET\"(TAB_ID, WIDGET_ID, GRID_COLUMNS, ROW_INDEX, COLUMN_INDEX) VALUES (");
        sqlBuilder.append("(SELECT ID FROM CONF_TAB WHERE KEY = '" + tabKey + "'), ");
        sqlBuilder.append("(SELECT ID FROM CONF_WIDGET WHERE NAME = '" + this.widgetDefinition.getName() + "'), ");
        sqlBuilder.append(this.gridColumns + ", ");
        sqlBuilder.append(this.rowIndex + ", ");
        sqlBuilder.append(this.columnIndex);
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}