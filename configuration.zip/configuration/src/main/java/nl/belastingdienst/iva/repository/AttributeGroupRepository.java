package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.attribute.AttributeGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttributeGroupRepository extends JpaRepository<AttributeGroup, Long> {

}
