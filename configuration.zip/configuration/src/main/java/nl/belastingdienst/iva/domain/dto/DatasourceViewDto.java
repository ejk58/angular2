package nl.belastingdienst.iva.domain.dto;

import java.util.ArrayList;
import java.util.List;

public class DatasourceViewDto {

	private String viewName;
	private List<String> columnNames;
	
	public String getViewName() {
		return viewName;
	}
	
	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
	
	public List<String> getColumnNames() {
		return columnNames;
	}
	
	public void setColumnNames(List<String> columnNames) {
		this.columnNames = columnNames;
	}
	
	public void addColumnName(String columnName) {
		if (this.columnNames == null) {
			this.columnNames = new ArrayList<>();
		}
		
		this.columnNames.add(columnName);
//		this.columnNames.sort((column, otherColumn) -> column.compareTo(otherColumn));
	}
}
