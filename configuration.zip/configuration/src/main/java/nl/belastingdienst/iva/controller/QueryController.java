package nl.belastingdienst.iva.controller;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinitionAttribute;
import nl.belastingdienst.iva.database.configuration.query.QueryDefinitionColumn;
import nl.belastingdienst.iva.database.configuration.query.QueryDefinitionFilter;
import nl.belastingdienst.iva.domain.dto.*;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import nl.belastingdienst.iva.database.configuration.query.QueryDefinition;
import nl.belastingdienst.iva.service.QueryDefinitionService;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value = "/api/queries")
public class QueryController {
    private final QueryDefinitionService queryDefinitionService;
    private ModelMapper modelMapper;

    @Autowired
    public QueryController(QueryDefinitionService queryDefinitionService, ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
        this.queryDefinitionService = queryDefinitionService;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{queryId}")
    public QueryDto getQuery(@PathVariable int queryId){
        QueryDefinition queryDefinition = queryDefinitionService.findQueryDefinitionById(queryId);
        return convertToDto(queryDefinition);
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<QueryDto> list() {
        return queryDefinitionService.getList();
    }


    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public QueryDto save(@RequestBody QueryDto queryDto) {
        QueryDefinition queryDefinition = convertToEntity(queryDto);
        QueryDefinition queryDefinitionCreated = queryDefinitionService
                .save(queryDefinition);
        return convertToDto(queryDefinitionCreated);
    }

    @RequestMapping(value = "/columns/save", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public QueryColumnDto save(@RequestBody QueryColumnDto queryColumnDto) {
        QueryDefinitionColumn queryDefinitionColumn = convertToEntity(queryColumnDto);
        QueryDefinitionColumn queryDefinitionColumnSaved = queryDefinitionService.save(queryDefinitionColumn);
        return convertToDto(queryDefinitionColumnSaved);
    }

    @RequestMapping(value = "/columns/delete", method = RequestMethod.POST)
    public Integer delete(@RequestBody Integer columnId) {
        queryDefinitionService.delete(columnId);
        // TODO dit zou niet nodig moeten zijn maar blijkbaar wordt een object terug verwacht
        return columnId;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/columns/types")
    public List<String> getColumnTypes(){
        return queryDefinitionService.findAllColumnTypes();
    }

    private QueryDefinition convertToEntity(QueryDto queryDto) {
        return modelMapper.map(queryDto, QueryDefinition.class);
    }

    private QueryColumnDto convertToDto(QueryDefinitionColumn queryDefinitionColumn) {
        return modelMapper.map(queryDefinitionColumn, QueryColumnDto.class);
    }

    private QueryDefinitionColumn convertToEntity(QueryColumnDto queryColumnDto) {
        return modelMapper.map(queryColumnDto, QueryDefinitionColumn.class);
    }
    
    private QueryDto convertToDto(QueryDefinition queryDefinition) {
        QueryDto queryDto = modelMapper.map(queryDefinition, QueryDto.class);
        if (queryDefinition.getDatasource() != null) {
            queryDto.setDataSource(queryDefinition.getDatasource().getKey());
        }
        List<QueryAttributeDto> attributesDto = new ArrayList<QueryAttributeDto>();
        for (QueryDefinitionAttribute queryDefinitionAttribute: queryDefinition.getQueryAttributes()) {
            QueryAttributeDto queryAttributeDto = convertToDto(queryDefinitionAttribute);
            attributesDto.add(queryAttributeDto);
        }
        List<QueryFilterDto> filtersDto = new ArrayList<QueryFilterDto>();
        for (QueryDefinitionFilter queryDefinitionFilter: queryDefinition.getQueryFilters()) {
            QueryFilterDto queryFilterDto = convertToDto(queryDefinitionFilter);
            filtersDto.add(queryFilterDto);
        }
        queryDto.setQueryAttributes(attributesDto);
        queryDto.setQueryFilters(filtersDto);
        return queryDto;
    }

    private QueryAttributeDto convertToDto(QueryDefinitionAttribute queryDefinitionAttribute) {
        return modelMapper.map(queryDefinitionAttribute, QueryAttributeDto.class);
    }

    private QueryFilterDto convertToDto(QueryDefinitionFilter queryDefinitionFilter) {
        return modelMapper.map(queryDefinitionFilter, QueryFilterDto.class);
    }
}