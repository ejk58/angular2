package nl.belastingdienst.iva.database.configuration.query;

import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_QUERY_FILTER")
public class QueryDefinitionFilter {

    @Id
    private Integer id;

    private String parameter;
    @Column(name = "FILTERTEMPLATE")
    private String filterTemplate;
    @Column(name = "NOFILTERTEMPLATE")
    private String noFilterTemplate;

    public Integer getId() {
        return this.id;
    }

    public String getParameter() {
        return this.parameter;
    }

    public String getFilterTemplate() {
        return this.filterTemplate;
    }

    public String getNoFilterTemplate() {
        return this.noFilterTemplate;
    }

    public String toSql(String queryKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_QUERY_FILTER\"(QUERY_ID, PARAMETER, FILTERTEMPLATE, NOFILTERTEMPLATE) VALUES (");
        sqlBuilder.append("(SELECT q.ID FROM CONF_QUERY q WHERE q.KEY = '" + queryKey + "'), ");
        sqlBuilder.append(ExportUtils.getString(this.parameter) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.filterTemplate) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.noFilterTemplate));
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public void setFilterTemplate(String filterTemplate) {
        this.filterTemplate = filterTemplate;
    }

    public void setNoFilterTemplate(String noFilterTemplate) {
        this.noFilterTemplate = noFilterTemplate;
    }
}
