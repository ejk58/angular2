package nl.belastingdienst.iva.database.configuration.datasource;

import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Entity
@Table(name = "CONF_DATASOURCE")
@NamedQuery(name = nl.belastingdienst.iva.database.configuration.datasource.DatasourceDefinition.GETDATASOURCEDEFINITION, query = "SELECT d FROM DatasourceDefinition d ORDER BY d.key")
public class DatasourceDefinition {

    public static final String GETDATASOURCEDEFINITION = "DatasourceDefinition.getDatasourceDefinitions";

    private static final String FALSE = "0";

    @Id
    private Integer id;
    private String key;

    @OneToMany
    @JoinColumn(name = "DATASOURCE_ID")
    private List<DatasourceDefinitionParam> parameterList;

    @Transient
    private Map<String, String> parameterMap;

    public Integer getId() {
        return this.id;
    }

    public String getKey() {
        return this.key;
    }

    public List<DatasourceDefinitionParam> getParameterList() {
        return Collections.unmodifiableList(this.parameterList);
    }

    public Map<String, String> getParameterMap() {
        return (this.parameterMap == null) ? Collections.<String, String>emptyMap() : Collections.unmodifiableMap(this.parameterMap);
    }

    void setParameterMap(Map<String, String> parameterMap) {
        this.parameterMap = new HashMap<String, String>();
        this.parameterMap.putAll(parameterMap);
    }

    public boolean hasParameterMap() {
        return (this.parameterMap != null) && (this.parameterMap.size() > 0);
    }

    public String getValue(String key) {
        return this.parameterMap.get(key);
    }

    public Integer getNumber(String key) {
        String value = this.parameterMap.get(key);
        return (value == null) ? null : Integer.parseInt(value);
    }

    public boolean getBoolean(String key) {
        String value = this.parameterMap.get(key);
        return (value != null && value.length() > 0 && !FALSE.equals(value));
    }

    @Override
    public int hashCode() {
        return this.key.hashCode();
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }

        if (object == null || getClass() != object.getClass()) {
            return false;
        }

        nl.belastingdienst.iva.database.configuration.datasource.DatasourceDefinition otherDatasource = (nl.belastingdienst.iva.database.configuration.datasource.DatasourceDefinition) object;
        return this.key.equals(otherDatasource.key);
    }

    public String toSql() {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- Datasource " + this.key + "\n");

        sqlBuilder.append("MERGE INTO \"CONF_DATASOURCE\" AS D USING (VALUES");
        sqlBuilder.append(ExportUtils.getString(this.key));
        sqlBuilder.append(") AS X(\"KEY\") ON D.KEY = X.KEY WHEN NOT MATCHED THEN INSERT (KEY) VALUES (X.KEY);\n\n");

        return sqlBuilder.toString();
    }
}
