package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinition;
import nl.belastingdienst.iva.domain.dto.WidgetDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface WidgetDefinitionRepository extends JpaRepository<WidgetDefinition, Integer> {
	
    List<WidgetDefinition> findAllByOrderByTitleAsc();

    @Query("SELECT " +
            "new nl.belastingdienst.iva.domain.dto.WidgetDto(d.id, d.index, d.name, d.title, d.description, d.descriptionMore, d.type, d.visible, d.refreshInfo, d.queryDefinition.id) " +
            " FROM WidgetDefinition d ORDER BY d.title ASC")
    List<WidgetDto> findAllDTOByOrderByTitleAsc();

    @Query("SELECT DISTINCT d.type FROM WidgetDefinition d ORDER BY d.type ASC")
    List<String> findAllDistinctTypesByOrderByTypeAsc();
}
