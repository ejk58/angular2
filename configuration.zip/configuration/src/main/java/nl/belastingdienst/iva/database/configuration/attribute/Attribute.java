package nl.belastingdienst.iva.database.configuration.attribute;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import nl.belastingdienst.iva.util.ExportUtils;

@Entity
@Table(name = "CONF_ATTRIBUTE")
public class Attribute {

	private static final String KEY_GENERAL = "GENERAL";
	private static final String KEY_CONFIGURATIONLOADTIME = "configurationLoadTime";
	
    @Id
	private Integer id;
	
	private String key;
	private Integer index;
	private String value;
	
	public Integer getId() {
		return this.id;
	}
	
	public String getKey() {
		return this.key;
	}
	
	public Integer getIndex() {
		return this.index;
	}
	
	public String getValue() {
		return this.value;
	}
	
	public String toSql(String attributeGroupKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        if (KEY_GENERAL.equals(attributeGroupKey) && KEY_CONFIGURATIONLOADTIME.equals(this.key)) {
	        sqlBuilder.append("INSERT INTO \"CONF_ATTRIBUTE\"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES (");
	        sqlBuilder.append("(SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY='" + attributeGroupKey + "'), ");
	        sqlBuilder.append(this.index + ", ");
	        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
	        sqlBuilder.append("CHAR(CURRENT TIMESTAMP)");
	        sqlBuilder.append(");\n");
        } else {
	        sqlBuilder.append("INSERT INTO \"CONF_ATTRIBUTE\"(ATTRIBUTE_GROUP_ID, INDEX, KEY, VALUE) VALUES (");
	        sqlBuilder.append("(SELECT ag.ID from CONF_ATTRIBUTE_GROUP ag WHERE ag.KEY='" + attributeGroupKey + "'), ");
	        sqlBuilder.append(this.index + ", ");
	        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
	        sqlBuilder.append(ExportUtils.getString(this.value));
	        sqlBuilder.append(");\n");
        }

        return sqlBuilder.toString();
	}
}
