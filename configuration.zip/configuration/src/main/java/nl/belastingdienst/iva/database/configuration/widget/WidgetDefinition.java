package nl.belastingdienst.iva.database.configuration.widget;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import nl.belastingdienst.iva.database.configuration.help.HelpDefinition;
import nl.belastingdienst.iva.database.configuration.query.QueryDefinition;
import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "CONF_WIDGET")
public class WidgetDefinition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer index;
    private String name;
    private String type;
    private String title;
    private String description;
    @Column(name = "DESCRIPTIONMORE")
    private String descriptionMore;
    @Column(name = "REFRESHINFO")
    private Boolean refreshInfo;
    private Boolean visible;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "QUERY_ID")
    private QueryDefinition queryDefinition;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "widgetDefinition")
    @OrderBy(value = "key")
    @JsonManagedReference
    private List<WidgetDefinitionAttribute> attributeDefinitionList;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "widgetDefinition")
    @OrderBy(value = "index")
    private List<WidgetDefinitionHelp> helpDefinitionList;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "index")
    private List<WidgetDefinitionColumn> columnDefinitionList;

    @OneToMany
    @JoinColumn(name = "CONTAINER_WIDGET_ID")
    @OrderBy(value = "index")
    private List<WidgetDefinition> widgetDefinitionList;

    public WidgetDefinition() {
    	this.columnDefinitionList = new ArrayList<>();
    	this.attributeDefinitionList = new ArrayList<>();
        this.helpDefinitionList = new ArrayList<>();
    	this.widgetDefinitionList = new ArrayList<>();
	}

	public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIndex() {
        return this.index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescriptionMore() {
        return this.descriptionMore;
    }

    public void setDescriptionMore(String descriptionMore) {
        this.descriptionMore = descriptionMore;
    }

    public QueryDefinition getQueryDefinition() {
        return this.queryDefinition;
    }

    public Boolean isVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Boolean isRefreshInfo() {
        return refreshInfo;
    }

    public void setRefreshInfo(Boolean refreshInfo) {
        this.refreshInfo = refreshInfo;
    }

    public List<WidgetDefinitionAttribute> getAttributeDefinitionList() {
        return attributeDefinitionList;
    }

    public List<WidgetDefinitionHelp> getHelpDefinitionList() { return helpDefinitionList; }

    public List<WidgetDefinitionColumn> getColumnDefinitionList() {
        return columnDefinitionList;
    }

    public List<nl.belastingdienst.iva.database.configuration.widget.WidgetDefinition> getWidgetDefinitionList() {
        return widgetDefinitionList;
    }

    public String toSql() {
        return toSql(null);
    }

    public String toSql(String containerWidgetName) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- Widget " + this.name + "\n");

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET\"(QUERY_ID, CONTAINER_WIDGET_ID, INDEX, NAME, TYPE, TITLE, DESCRIPTION, DESCRIPTIONMORE, REFRESHINFO, VISIBLE) VALUES (");
        sqlBuilder.append(this.queryDefinition == null ? "null, " : "(SELECT q.ID FROM CONF_QUERY q WHERE q.KEY = '" + this.queryDefinition.getKey() + "'), ");
        sqlBuilder.append(containerWidgetName == null ? "null, " : "(SELECT w.ID FROM CONF_WIDGET w WHERE w.NAME = '" + containerWidgetName + "'), ");
        sqlBuilder.append(this.index + ", ");
        sqlBuilder.append(ExportUtils.getString(this.name) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.type) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.title) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.description) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.descriptionMore) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(this.refreshInfo) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(this.visible));
        sqlBuilder.append(");\n");

        for (WidgetDefinitionAttribute widgetDefinitionAttribute : this.attributeDefinitionList) {
            sqlBuilder.append(widgetDefinitionAttribute.toSql(this.name));
        }

        for (WidgetDefinitionHelp widgetDefinitionHelp : this.helpDefinitionList) {
            sqlBuilder.append(widgetDefinitionHelp.toSql(this.name));
        }

        for (WidgetDefinitionColumn widgetDefinitionColumn : this.columnDefinitionList) {
            sqlBuilder.append(widgetDefinitionColumn.toSql(this.name, this.queryDefinition == null ? null : this.queryDefinition.getKey()));
        }

        for (nl.belastingdienst.iva.database.configuration.widget.WidgetDefinition widgetDefinition : this.widgetDefinitionList) {
            sqlBuilder.append(widgetDefinition.toSql(this.name));
        }

        if (containerWidgetName == null) {
            sqlBuilder.append("\n");
        }

        return sqlBuilder.toString();
    }
}
