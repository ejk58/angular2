package nl.belastingdienst.iva.controller;

import nl.belastingdienst.iva.datasource.teradata.TeradataParser;
import nl.belastingdienst.iva.domain.dto.DatasourceViewDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@CrossOrigin
@RestController
@RequestMapping(value = "/api/datasources")
public class DatasourceController {

    private final TeradataParser teradataParser;

    @Autowired
    public DatasourceController(TeradataParser teradataParser) {
        this.teradataParser = teradataParser;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/views")
    @ResponseBody
    public Collection<DatasourceViewDto> getTDViewRecords() {
        return teradataParser.getTeradataViews();
    }

    @RequestMapping(method = RequestMethod.GET, value = "/columns/{viewName}")
    @ResponseBody
    public Collection<String> getTDViewColumns(@PathVariable String viewName) {
        return teradataParser.getTeradataViewColumns(viewName);
    }
}
