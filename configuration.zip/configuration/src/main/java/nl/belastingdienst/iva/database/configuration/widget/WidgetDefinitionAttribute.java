package nl.belastingdienst.iva.database.configuration.widget;

import com.fasterxml.jackson.annotation.JsonBackReference;
import nl.belastingdienst.iva.util.ExportUtils;
import org.codehaus.jackson.annotate.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "CONF_WIDGET_ATTRIBUTE")
public class WidgetDefinitionAttribute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "KEY")
    private String key;

    @Column(name = "VALUE")
    private String value;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "WIDGET_ID")
    @JsonBackReference
    private WidgetDefinition widgetDefinition;

    @JsonIgnore
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public WidgetDefinition getWidgetDefinition() {
        return widgetDefinition;
    }

    public void setWidgetDefinition(WidgetDefinition widgetDefinition) {
        this.widgetDefinition = widgetDefinition;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String toSql(String widgetName) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_ATTRIBUTE\"(WIDGET_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append("(SELECT ID from CONF_WIDGET WHERE NAME = '" + widgetName + "'), ");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.value));
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
