package nl.belastingdienst.iva.controller;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import nl.belastingdienst.iva.database.configuration.tab.TabDefinition;
import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionWidget;
import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinition;
import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinitionAttribute;
import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinitionColumn;
import nl.belastingdienst.iva.domain.DataMap;
import nl.belastingdienst.iva.domain.dto.TabWidgetDto;
import nl.belastingdienst.iva.domain.dto.WidgetAttributeDto;
import nl.belastingdienst.iva.domain.dto.WidgetAttributesDto;
import nl.belastingdienst.iva.domain.dto.WidgetColumnDto;
import nl.belastingdienst.iva.domain.dto.WidgetDto;
import nl.belastingdienst.iva.service.TabDefinitionService;
import nl.belastingdienst.iva.service.WidgetDefinitionService;

@CrossOrigin
@RestController
@RequestMapping(value = "/api/widgets")
public class WidgetController {
    private final WidgetDefinitionService widgetDefinitionService;
    private final TabDefinitionService tabDefinitionService;
    private ModelMapper modelMapper;

    @Autowired
    public WidgetController(WidgetDefinitionService widgetDefinitionService, TabDefinitionService tabDefinitionService,
                            ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
        this.widgetDefinitionService = widgetDefinitionService;
        this.tabDefinitionService = tabDefinitionService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<WidgetDto> list() {
        return widgetDefinitionService.findAll();
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/{widgetId}")
    public WidgetDto getWidget(@PathVariable int widgetId){
        WidgetDefinition widgetDefinition = widgetDefinitionService.getWidgetDefinition(widgetId);
        return convertToDto(widgetDefinition);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/tab/{tabId}")
    public List<TabWidgetDto> listByTabId(@PathVariable int tabId) {
        List<TabDefinitionWidget> tabDefinitionWidgets = tabDefinitionService.findById(tabId).getTabDefinitionWidgets();
        List<TabWidgetDto> tabWidgetDtoList = new ArrayList<>();
        for (TabDefinitionWidget tabDefinitionWidget : tabDefinitionWidgets) {
            TabWidgetDto tabWidgetDto = convertToDto(tabDefinitionWidget);
            tabWidgetDtoList.add(tabWidgetDto);
        }
        return tabWidgetDtoList;
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/tab/{tabWidgetId}")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void deleteBytabWidgetId(@PathVariable int tabWidgetId) {
        widgetDefinitionService.deleteTabWidgetDefinitionById(tabWidgetId);
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/attributes")
    public List<DataMap> listAttributes() {
    	List<DataMap> widgetAttributes = widgetDefinitionService.findAllAttributes();
        return widgetAttributes;
    }

    @RequestMapping(value = "/attributes/saveall", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public void save(@RequestBody WidgetAttributesDto widgetAttributesDto) {
        Integer widgetId = widgetAttributesDto.getWidgetId();
        for (WidgetAttributeDto attribute : widgetAttributesDto.getAttributes()) {
            attribute.setWidgetId(widgetId);
            WidgetDefinitionAttribute widgetDefinitionAttribute = convertToEntity(attribute);
            widgetDefinitionService.save(widgetDefinitionAttribute);
        }
    }

    @RequestMapping(value = "/attributes/save", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public WidgetAttributeDto save(@RequestBody WidgetAttributeDto widgetAttributeDto) {
        WidgetDefinitionAttribute widgetDefinitionAttribute = convertToEntity(widgetAttributeDto);
        WidgetDefinitionAttribute widgetDefinitionAttributeCreated = widgetDefinitionService
                .save(widgetDefinitionAttribute);
        return convertToDto(widgetDefinitionAttributeCreated);
    }

    @RequestMapping(value = "/attributes/deleteall", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public void delete(@RequestBody WidgetAttributesDto widgetAttributesDto) {
        Integer widgetId = widgetAttributesDto.getWidgetId();
        for (WidgetAttributeDto attribute : widgetAttributesDto.getAttributes()) {
            attribute.setWidgetId(widgetId);
            WidgetDefinitionAttribute widgetDefinitionAttribute = convertToEntity(attribute);
            widgetDefinitionService.delete(widgetDefinitionAttribute);
        }
    }

    @RequestMapping(value = "/attributes/delete", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public void delete(@RequestBody WidgetAttributeDto widgetAttributeDto) {
        WidgetDefinitionAttribute widgetDefinitionAttribute = convertToEntity(widgetAttributeDto);
        widgetDefinitionService.delete(widgetDefinitionAttribute);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/types")
    public List<String> listTypes() {
    	List<String> widgetTypes = widgetDefinitionService.findAllTypes();
        return widgetTypes;
    }
    
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public WidgetDto save(@RequestBody WidgetDto widgetDto) {
    	WidgetDefinition widget = convertToEntity(widgetDto);
    	widgetDefinitionService.save(widget);
    	return widgetDto;
    }

    @RequestMapping(value = "/copy", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public WidgetDto copy(@RequestBody WidgetDto widgetDto) {
        WidgetDefinition widgetToCopy = widgetDefinitionService.getWidgetDefinition(widgetDto.getId());
        WidgetDefinition widgetDefinition = copyWidgetByDto(widgetToCopy, widgetDto);
        return convertToDto(widgetDefinitionService.clone(widgetDefinition));
    }

    @RequestMapping(value = "/tabwidget", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public TabWidgetDto saveTabWidget(@RequestBody TabWidgetDto tabWidgetDto) {
        TabDefinition tabDefinition = tabDefinitionService.findById(tabWidgetDto.getTabId());
        TabDefinitionWidget tabDefinitionWidget = createTabWidgetByDto(tabWidgetDto);
        tabDefinitionWidget.setTabDefinition(tabDefinition);
        tabDefinition.addTabDefitionWidget(tabDefinitionWidget);
        tabDefinitionService.save(tabDefinition);
        return convertToDto(tabDefinitionWidget);
    }

    private TabDefinitionWidget createTabWidgetByDto(TabWidgetDto tabWidgetDto) {
        WidgetDefinition widgetDefinition = widgetDefinitionService.getWidgetDefinition(tabWidgetDto.getWidgetId());
        TabDefinitionWidget tabDefinitionWidget = new TabDefinitionWidget();
        tabDefinitionWidget.setColumnIndex(tabWidgetDto.getColumnIndex());
        tabDefinitionWidget.setGridColumns(tabWidgetDto.getGridColumns());
        tabDefinitionWidget.setRowIndex(tabWidgetDto.getRowIndex());
        tabDefinitionWidget.setWidgetDefinition(widgetDefinition);
        return tabDefinitionWidget;
    }

    private WidgetDefinitionAttribute convertToEntity(WidgetAttributeDto widgetAttributeDto) {
        WidgetDefinitionAttribute widgetDefinitionAttribute = modelMapper.map(widgetAttributeDto,
                WidgetDefinitionAttribute.class);
        widgetDefinitionAttribute
                .setWidgetDefinition(widgetDefinitionService.getWidgetDefinition(widgetAttributeDto.getWidgetId()));
        return widgetDefinitionAttribute;
    }

    private WidgetDefinition convertToEntity(WidgetDto widgetDto) {
        return modelMapper.map(widgetDto, WidgetDefinition.class);
    }

    private WidgetDto convertToDto(WidgetDefinition widgetDefinition) {
        WidgetDto widgetDto = modelMapper.map(widgetDefinition, WidgetDto.class);
        List<WidgetAttributeDto> attributesDto = new ArrayList<>();
        for (WidgetDefinitionAttribute widgetDefinitionAttribute : widgetDefinition.getAttributeDefinitionList()) {
            WidgetAttributeDto widgetAttributeDto = convertToDto(widgetDefinitionAttribute);
            attributesDto.add(widgetAttributeDto);
        }
        List<WidgetColumnDto> columnsDto = new ArrayList<>();
        for(WidgetDefinitionColumn widgetDefinitionColumn: widgetDefinition.getColumnDefinitionList()) {
            WidgetColumnDto widgetColumnDto = convertToDto(widgetDefinitionColumn);
            columnsDto.add(widgetColumnDto);
        }
        List<WidgetDto> childWidgetsDto = new ArrayList<>();
        for(WidgetDefinition widgetDefinitionChild: widgetDefinition.getWidgetDefinitionList()) {
            WidgetDto childWidgetDto = convertToDto(widgetDefinitionChild);
            childWidgetsDto.add(childWidgetDto);
        }
        widgetDto.setAttributes(attributesDto);
        widgetDto.setColumns(columnsDto);
        widgetDto.setChildWidgets(childWidgetsDto);
        return widgetDto;
    }
    

    private WidgetAttributeDto convertToDto(WidgetDefinitionAttribute widgetDefinitionAttribute) {
        return modelMapper.map(widgetDefinitionAttribute, WidgetAttributeDto.class);
    }
    
    private WidgetColumnDto convertToDto(WidgetDefinitionColumn widgetDefinitionColumn) {
        return modelMapper.map(widgetDefinitionColumn, WidgetColumnDto.class);
    }

    private TabWidgetDto convertToDto(TabDefinitionWidget tabDefinitionWidget) {
        return modelMapper.map(tabDefinitionWidget, TabWidgetDto.class);
    }

    private WidgetDefinition copyWidgetByDto(WidgetDefinition widgetToCopy, WidgetDto widgetDto) {
        widgetToCopy.setId(null);
        widgetToCopy.setName(widgetDto.getName());
        widgetToCopy.setTitle(widgetDto.getTitle());
        widgetToCopy.setDescription(widgetDto.getDescription());
        widgetToCopy.setDescriptionMore(widgetDto.getDescriptionMore());
        widgetToCopy.setType(widgetDto.getType());
        return widgetToCopy;
    }
}