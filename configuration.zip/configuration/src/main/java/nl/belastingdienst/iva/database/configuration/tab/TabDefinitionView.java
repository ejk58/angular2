package nl.belastingdienst.iva.database.configuration.tab;

import nl.belastingdienst.iva.database.configuration.view.ViewDefinition;

import javax.persistence.*;

@Entity
@Table(name = "CONF_TAB_VIEW")
public class TabDefinitionView {

    @Id
    private Integer id;

    @Column(name = "GROUP_INDEX")
    private Integer groupIndex;

    @Column(name = "MEMBER_INDEX")
    private Integer memberIndex;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "VIEW_ID")
    private ViewDefinition viewDefinition;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "TAB_ID")
    private TabDefinition tabDefinition;

    public Integer getId() {
        return id;
    }
    
	public Integer getGroupIndex() {
		return groupIndex;
	}

    public void setGroupIndex(Integer groupIndex) {
		this.groupIndex = groupIndex;
	}

	public Integer getMemberIndex() {
		return memberIndex;
	}

	public void setMemberIndex(Integer memberIndex) {
		this.memberIndex = memberIndex;
	}

	public ViewDefinition getViewDefinition() {
        return viewDefinition;
    }

	public void setViewDefinition(ViewDefinition viewDefinition) {
		this.viewDefinition = viewDefinition;
	}

	public TabDefinition getTabDefinition() {
        return tabDefinition;
    }
	
	public void setTabDefinition(TabDefinition tabDefinition) {
		this.tabDefinition = tabDefinition;
	}

	public String toSql(String tabKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_TAB_VIEW\"(TAB_ID, VIEW_ID, GROUP_INDEX, MEMBER_INDEX) VALUES (");
        sqlBuilder.append("(SELECT ID FROM CONF_TAB WHERE KEY = '" + tabKey + "'), ");
        sqlBuilder.append("(SELECT ID FROM CONF_VIEW WHERE KEY = '" + this.viewDefinition.getKey() + "'), ");
        sqlBuilder.append(this.groupIndex + ", ");
        sqlBuilder.append(this.memberIndex);
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
	}
}
