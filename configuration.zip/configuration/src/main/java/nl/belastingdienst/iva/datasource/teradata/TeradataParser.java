package nl.belastingdienst.iva.datasource.teradata;

import nl.belastingdienst.iva.domain.dto.DatasourceViewDto;
import nl.belastingdienst.iva.domain.dto.TeradataDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class TeradataParser {

	private static final String VIEW_QUERY = "SELECT c.TableName, c.ColumnName FROM dbc.Columns c " + 
			"WHERE c.DatabaseName = ? ORDER BY c.TableName ASC, c.ColumnId ASC";

	private static final String COLUMNS_PER_QUERY = "SELECT c.ColumnName FROM dbc.Columns c " +
			"WHERE c.DatabaseName = ? AND c.TableName = ? ORDER BY c.ColumnId ASC";

	@Value("${datasource.teradata.database}")
    private String database;

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public TeradataParser(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Collection<String> getTeradataViewColumns(String viewName) {
        List<String> teradataColumnList = this.jdbcTemplate.query(COLUMNS_PER_QUERY, new Object[]{ this.database, viewName }, (rs, rowNum) -> {
            return rs.getString("ColumnName").trim();
        });
    	return teradataColumnList;
	};

    public Collection<DatasourceViewDto> getTeradataViews() {
    	Map<String, DatasourceViewDto> datasourceQueryDtoMap = new HashMap<>();
    	List<TeradataDto> teradataViewList = this.jdbcTemplate.query(VIEW_QUERY, new Object[]{ this.database }, (rs, rowNum) -> {
            TeradataDto teradataDto = new TeradataDto();
            teradataDto.setViewName(rs.getString("TableName").trim());
            teradataDto.setColumnName(rs.getString("ColumnName").trim());
            return teradataDto;
        });
    	
    	for (TeradataDto teradataView : teradataViewList) {
    		String viewName = teradataView.getViewName();
    		String columnName = teradataView.getColumnName();
    		DatasourceViewDto datasourceQueryDto = datasourceQueryDtoMap.get(viewName);
    		
    		if (datasourceQueryDto == null) {
    			datasourceQueryDto = new DatasourceViewDto();
    			datasourceQueryDto.setViewName(viewName);
    			datasourceQueryDtoMap.put(viewName, datasourceQueryDto);
    		}
    		
    		datasourceQueryDto.addColumnName(columnName);
    	}
    	
    	List<DatasourceViewDto> datasourceQueryDtoList = new ArrayList<>();
    	datasourceQueryDtoList.addAll(datasourceQueryDtoMap.values());
    	datasourceQueryDtoList.sort((item, otherItem) -> item.getViewName().compareTo(otherItem.getViewName())); 
    	
    	return datasourceQueryDtoList;
    }
}
