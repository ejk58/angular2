package nl.belastingdienst.iva.domain.dto;

import java.util.List;

public class WidgetAttributesDto {
    private Integer widgetId;
    private List<WidgetAttributeDto> attributes;

    public Integer getWidgetId() {
        return widgetId;
    }

    public void setWidgetId(Integer widgetId) {
        this.widgetId = widgetId;
    }

    public List<WidgetAttributeDto> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<WidgetAttributeDto> attributes) {
        this.attributes = attributes;
    }

}
