package nl.belastingdienst.iva.database.configuration.query;

import javax.persistence.*;

import nl.belastingdienst.iva.util.ExportUtils;

@Entity
@Table(name = "CONF_QUERY_ATTRIBUTE")
public class QueryDefinitionAttribute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private int id;

    private String key;
    private String value;

    public int getId() {
        return this.id;
    }

    public String getKey() {
		return this.key;
	}

	public String getValue() {
		return this.value;
	}
	
    public String toSql(String queryKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_QUERY_ATTRIBUTE\"(QUERY_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append("(SELECT q.ID from CONF_QUERY q WHERE q.KEY='" + queryKey + "'), ");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.value));
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
