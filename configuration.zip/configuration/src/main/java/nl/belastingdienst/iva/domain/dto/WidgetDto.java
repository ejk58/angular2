package nl.belastingdienst.iva.domain.dto;

import java.util.List;

public class WidgetDto {

    private Integer id;
    private Integer index;
    private String name;
    private String title;
    private String description;
    private String descriptionMore;
    private String type;
    private Boolean visible;
    private Boolean refreshInfo;
    private List<WidgetAttributeDto> attributes;
    private Integer queryId;
    private List<WidgetColumnDto> columns;
    private List<WidgetDto> childWidgets;
     
    public WidgetDto(Integer id, Integer index, String name, String title, String description, String descriptionMore, String type, Boolean visible, Boolean refreshInfo, Integer queryId) {
        this.id = id;
        this.index = index;
        this.name = name;
        this.title = title;
        this.description = description;
        this.descriptionMore = descriptionMore;
        this.type = type;
        this.visible = visible;
        this.refreshInfo = refreshInfo;
        this.queryId = queryId;
    }
    
    public WidgetDto() {
    	// Default constructor
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean isVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Boolean isRefreshInfo() {
        return refreshInfo;
    }

    public void setRefreshInfo(Boolean refreshInfo) {
        this.refreshInfo = refreshInfo;
    }
    
    public List<WidgetAttributeDto> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<WidgetAttributeDto> attributes) {
        this.attributes = attributes;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescriptionMore() {
        return descriptionMore;
    }
    
    public void setDescriptionMore(String descriptionMore) {
        this.descriptionMore = descriptionMore;
    }

    public Integer getQueryId() {
        return queryId;
    }

    public void setQueryId(Integer queryId) {
        this.queryId = queryId;
    }

    public List<WidgetColumnDto> getColumns() {
        return columns;
    }

    public void setColumns(List<WidgetColumnDto> columns) {
        this.columns = columns;
    }
    
    public List<WidgetDto> getChildWidgets() {
        return childWidgets;
    }

    public void setChildWidgets(List<WidgetDto> childWidgets) {
        this.childWidgets = childWidgets;
    }
}