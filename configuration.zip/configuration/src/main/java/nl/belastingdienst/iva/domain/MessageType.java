package nl.belastingdienst.iva.domain;

public enum MessageType {
	ERROR,
	WARNING,
	INFORMATION
} 
