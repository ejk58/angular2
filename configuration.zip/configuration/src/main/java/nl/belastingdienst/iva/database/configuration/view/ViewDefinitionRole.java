package nl.belastingdienst.iva.database.configuration.view;

import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_VIEW_ROLE")
public class ViewDefinitionRole {

    @Id
    private Integer id;

    private String role;

    private Integer type;

    private Integer vipaccess;

    public Integer getId() {
        return id;
    }

    public String getRole() {
        return role;
    }

    public Integer getType() { return type; }

    public Integer getVipaccess() { return vipaccess; }

    public String toSql(String viewKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_VIEW_ROLE\"(VIEW_ID, ROLE, TYPE, VIPACCESS) VALUES (");
        sqlBuilder.append("(SELECT ID FROM CONF_VIEW WHERE KEY = '" + viewKey + "'), ");

        sqlBuilder.append(ExportUtils.getString(this.role) + ", ");
        sqlBuilder.append(this.type + ", ");
        sqlBuilder.append(this.vipaccess);
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
