package nl.belastingdienst.iva.domain.dto;

public class TeradataDto {

	private String viewName;
	private String columnName;

    public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }
}
