package nl.belastingdienst.iva.database.configuration.view;

import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_VIEW_PATHKEY")
public class ViewDefinitionPathKey {

    @Id
    private Integer id;
    private String key;
    private String name;
    private String title;
    private String type;

    private Integer index;
    private Boolean primary;
    private Boolean mandatory;

    public Integer getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public String getType() {
        return type;
    }

    public Integer getIndex() {
        return index;
    }

    public Boolean getPrimary() {
        return primary;
    }

    public Boolean getMandatory() {
        return mandatory;
    }

    public String toSql(String viewKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_VIEW_PATHKEY\"(VIEW_ID, KEY, NAME, TITLE, TYPE, INDEX, PRIMARY, MANDATORY) VALUES (");
        sqlBuilder.append("(SELECT ID FROM CONF_VIEW WHERE KEY = '" + viewKey + "'), ");

        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.name) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.title) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.type) + ", ");
        sqlBuilder.append(this.index + ", ");
        sqlBuilder.append(this.primary ? "1, " : "0, ");
        sqlBuilder.append(this.mandatory ? "1" : "0");
        sqlBuilder.append(");\n");

        return sqlBuilder.toString();
    }
}
