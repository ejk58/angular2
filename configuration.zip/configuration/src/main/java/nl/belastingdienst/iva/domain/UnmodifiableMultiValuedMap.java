package nl.belastingdienst.iva.domain;

import javax.ws.rs.core.MultivaluedMap;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class UnmodifiableMultiValuedMap<K, V> implements MultivaluedMap<K, V> {

    MultivaluedMap<K, V> map;

    public UnmodifiableMultiValuedMap(MultivaluedMap<K, V> map) {
        this.map = map;
    }


    public void clear() {
        throw new UnsupportedOperationException();
    }


    public boolean containsKey(Object key) {
        return this.map.containsKey(key);
    }


    public boolean containsValue(Object value) {
        return this.map.containsValue(value);
    }


    public Set<Entry<K, List<V>>> entrySet() {
        return this.map.entrySet();
    }


    public List<V> get(Object key) {
        return this.map.get(key);
    }


    public boolean isEmpty() {
        return this.map.isEmpty();
    }


    public Set<K> keySet() {
        return this.map.keySet();
    }


    public List<V> put(K key, List<V> value) {
        throw new UnsupportedOperationException();
    }


    public void putAll(Map<? extends K, ? extends List<V>> map) {
        throw new UnsupportedOperationException();
    }


    public List<V> remove(Object key) {
        throw new UnsupportedOperationException();
    }


    public int size() {
        return this.map.size();
    }


    public Collection<List<V>> values() {
        return this.map.values();
    }


    public void add(K key, V value) {
        throw new UnsupportedOperationException();
    }


    public V getFirst(K key) {
        return this.map.getFirst(key);
    }

    @Override
    public void addAll(K k, V[] vs) {

    }

    @Override
    public void addAll(K k, List<V> list) {

    }

    @Override
    public void addFirst(K k, V v) {

    }

    @Override
    public boolean equalsIgnoreValueOrder(MultivaluedMap<K, V> multivaluedMap) {
        return false;
    }


    public void putSingle(K key, V value) {
        throw new UnsupportedOperationException();
    }
}
