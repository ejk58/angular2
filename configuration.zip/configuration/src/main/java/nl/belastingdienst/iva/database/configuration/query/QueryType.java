package nl.belastingdienst.iva.database.configuration.query;

public enum QueryType {

    NONE(0),
    TERADATA(1),
    DB2(2),
    REST(3);

    private int type;

    private QueryType(int type) {
        this.type = type;
    }

    public static nl.belastingdienst.iva.database.configuration.query.QueryType findQueryType(int type) {
        for (nl.belastingdienst.iva.database.configuration.query.QueryType queryType : values()) {
            if (queryType.type == type) {
                return queryType;
            }
        }

        return null;
    }

    public int getValue() {
        return type;
    }
}
