package nl.belastingdienst.iva.service.impl;

import nl.belastingdienst.iva.database.configuration.tab.TabDefinition;
import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionDependencyGroup;
import nl.belastingdienst.iva.repository.TabDefinitionDependencyGroupRepository;
import nl.belastingdienst.iva.repository.TabDefinitionRepository;
import nl.belastingdienst.iva.service.TabDefinitionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Service
@Transactional
public class TabDefinitionServiceImpl implements TabDefinitionService {
    private final Logger log = LoggerFactory.getLogger(TabDefinitionServiceImpl.class);

    private final TabDefinitionRepository tabDefinitionRepository;
    private final TabDefinitionDependencyGroupRepository tabDefinitionDependencyGroupRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    public TabDefinitionServiceImpl(TabDefinitionRepository tabDefinitionRepository, TabDefinitionDependencyGroupRepository tabDefinitionDependencyGroupRepository) {
        this.tabDefinitionRepository = tabDefinitionRepository;
        this.tabDefinitionDependencyGroupRepository = tabDefinitionDependencyGroupRepository;
    }

    @Transactional(readOnly = false)
    public TabDefinition save(TabDefinition tabDefinition) {
        return tabDefinitionRepository.saveAndFlush(tabDefinition);
    }

    @Transactional(readOnly = false)
    public TabDefinitionDependencyGroup save(TabDefinitionDependencyGroup tabDefinitionDependencyGroup) {
        return tabDefinitionDependencyGroupRepository.saveAndFlush(tabDefinitionDependencyGroup);
    }

    @Transactional(readOnly = true)
    public List<TabDefinition> findAllByOrderByTitleAsc() {
        return tabDefinitionRepository.findAllByOrderByTitleAsc();
    }

    @Transactional(readOnly = true)
    public TabDefinition findById(int id) {
        return tabDefinitionRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public TabDefinitionDependencyGroup findTabDefinitionDependencyGroupById(int id) {
        return tabDefinitionDependencyGroupRepository.getOne(id);
    }

    @Transactional(readOnly = true)
    public List<TabDefinition> findByKey(String key) {
        return tabDefinitionRepository.findByKeyContaining(key);
    }

    @Transactional(readOnly = true)
    public List<TabDefinitionDependencyGroup> listDependencyGroups() {
        return tabDefinitionDependencyGroupRepository.findAll();
    }
}
