package nl.belastingdienst.iva.controller;

import nl.belastingdienst.iva.domain.DBInfo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@CrossOrigin
@RestController
@RequestMapping("/api/system")
public class SystemController {
    @Value("${spring.datasource.url}")
    private String dbUrl;

    @RequestMapping(value = "current-schema", method = RequestMethod.GET)
    public DBInfo getCurrentSchema() {
        String regex = "(.*=)([A-Z0-9]*)(;)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(dbUrl);
        DBInfo dbInfo = new DBInfo();
        if (matcher.matches()) {
            dbInfo.setCurrentSchema(matcher.group(2));
        }
        return dbInfo;
    }
}
