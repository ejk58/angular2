package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionDependencyGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TabDefinitionDependencyGroupRepository extends JpaRepository<TabDefinitionDependencyGroup, Integer> {

}
