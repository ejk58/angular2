package nl.belastingdienst.iva.service.impl;

import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinition;
import nl.belastingdienst.iva.database.configuration.widget.WidgetDefinitionAttribute;
import nl.belastingdienst.iva.domain.DataHashMap;
import nl.belastingdienst.iva.domain.DataMap;
import nl.belastingdienst.iva.domain.dto.WidgetAttributeDto;
import nl.belastingdienst.iva.domain.dto.WidgetDto;
import nl.belastingdienst.iva.repository.DetachRepository;
import nl.belastingdienst.iva.repository.TabWidgetDefinitionRepository;
import nl.belastingdienst.iva.repository.WidgetDefinitionAttributeRepository;
import nl.belastingdienst.iva.repository.WidgetDefinitionRepository;
import nl.belastingdienst.iva.service.WidgetDefinitionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

@Service
@Transactional
public class WidgetDefinitionServiceImpl implements WidgetDefinitionService {

    private final Logger log = LoggerFactory.getLogger(WidgetDefinitionServiceImpl.class);

    private final WidgetDefinitionRepository widgetDefinitionRepository;

    private final DetachRepository detachRepository;

    private final WidgetDefinitionAttributeRepository widgetDefinitionAttributeRepository;

    private final TabWidgetDefinitionRepository tabWidgetDefinitionRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    public WidgetDefinitionServiceImpl(WidgetDefinitionRepository widgetDefinitionRepository, WidgetDefinitionAttributeRepository widgetDefinitionAttributeRepository, TabWidgetDefinitionRepository tabWidgetDefinitionRepository, DetachRepository detachRepository) {
        this.widgetDefinitionRepository = widgetDefinitionRepository;
        this.widgetDefinitionAttributeRepository = widgetDefinitionAttributeRepository;
        this.tabWidgetDefinitionRepository = tabWidgetDefinitionRepository;
        this.detachRepository = detachRepository;
    }

    @Transactional(readOnly = true)
    public List<WidgetDto> findAll() {
        List<WidgetDto> widgetDtos = widgetDefinitionRepository.findAllDTOByOrderByTitleAsc();
        for (WidgetDto widgetDto: widgetDtos ) {
            widgetDto.setAttributes(widgetDefinitionAttributeRepository.findAllDTOByWidgetId(widgetDto.getId()));
        }
        return widgetDtos;
    }

    @Transactional(readOnly = true)
    public List<String> findAllTypes() {
        List<String> widgetTypes = widgetDefinitionRepository.findAllDistinctTypesByOrderByTypeAsc();
        return widgetTypes;
    }
    
    @Transactional(readOnly = true)
    public List<DataMap> findAllAttributes() {
        List<WidgetAttributeDto> widgetAttributes = widgetDefinitionAttributeRepository.findAllAttributesByOrderByAttributeAsc();
        
        Map<String, TreeSet<String>> attributesMap = new TreeMap<>();
        for (WidgetAttributeDto attribute : widgetAttributes) {
        	TreeSet<String> valueSet = attributesMap.get(attribute.getKey());
        	
        	if (valueSet == null) {
        		valueSet = new TreeSet<>();
        		attributesMap.put(attribute.getKey(), valueSet);
        	}
        	
    		valueSet.add(attribute.getValue());
        }
        
        List<DataMap> widgetDataMap = new ArrayList<>();
        for (Map.Entry<String, TreeSet<String>> attribute : attributesMap.entrySet()) {
        	DataMap attributeMap = new DataHashMap();
        	attributeMap.put("key", attribute.getKey());
        	attributeMap.put("values", attribute.getValue());
        	widgetDataMap.add(attributeMap);	
        }
        
        return widgetDataMap;
    }

    @Transactional(readOnly = false)
    public WidgetDefinition save(WidgetDefinition widgetDefinition) {
        return widgetDefinitionRepository.saveAndFlush(widgetDefinition);
    }

    @Transactional(readOnly = false)
    public WidgetDefinition clone(WidgetDefinition widgetDefinition) {
        detachRepository.detach(widgetDefinition);
        return widgetDefinitionRepository.saveAndFlush(widgetDefinition);
    }

    @Transactional(readOnly = false)
    public WidgetDefinitionAttribute save(WidgetDefinitionAttribute widgetDefinitionAttribute) {
        return widgetDefinitionAttributeRepository.saveAndFlush(widgetDefinitionAttribute);
    }

    @Transactional(readOnly = false)
    public void delete(WidgetDefinitionAttribute widgetDefinitionAttribute) {
        widgetDefinitionAttributeRepository.delete(widgetDefinitionAttribute);
    }

    @Override
    public WidgetDefinition getWidgetDefinition(int id) {
        return widgetDefinitionRepository.getOne(id);
    }

    @Override
    public void deleteTabWidgetDefinitionById(int tabWidgetId) {
        tabWidgetDefinitionRepository.delete(tabWidgetId);
    }

}
