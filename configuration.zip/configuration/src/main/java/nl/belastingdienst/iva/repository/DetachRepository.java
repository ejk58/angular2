package nl.belastingdienst.iva.repository;

public interface DetachRepository {

    void detach(Object o);
}
