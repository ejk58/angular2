package nl.belastingdienst.iva.domain;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class DataHashMap extends LinkedHashMap<String, Object> implements DataMap {

    private static final long serialVersionUID = 1L;

    public int getIndex(String key) {
        Set<String> keySet = this.keySet();
        int index = 0;

        for (String id : keySet) {
            if (id.equals(key)) {
                return index;
            }

            index++;
        }

        return -1;
    }

    public String getAsString(String key) {
        Object value = this.get(key);
        return (value == null ? null : value.toString());
    }

    public void put(int index, String key, Object value) {

        if (index == 0) {
            LinkedHashMap<String, Object> newDataMap = new LinkedHashMap<String, Object>();
            newDataMap.put(key, value);
            newDataMap.putAll(this);
            replaceAll(newDataMap);

        } else if (index > 0 && index < this.size()) {
            LinkedHashMap<String, Object> newDataMap = new LinkedHashMap<String, Object>();
            int i = 0;

            for (Map.Entry<String, Object> entry : this.entrySet()) {
                if (i == index) {
                    newDataMap.put(key, value);
                }

                newDataMap.put(entry.getKey(), entry.getValue());
                i++;
            }
            replaceAll(newDataMap);

        } else if (index == this.size()) {
            put(key, value);

        } else {
            String message = "The index " + index + " is not within the range of the DataMap with length " + size() + ".";
            throw new IllegalArgumentException(message);
        }
    }

    private void replaceAll(LinkedHashMap<String, Object> newDataMap) {
        clear();
        putAll(newDataMap);
    }
}
