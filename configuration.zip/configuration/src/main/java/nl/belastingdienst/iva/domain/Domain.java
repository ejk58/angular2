package nl.belastingdienst.iva.domain;

import javax.ws.rs.core.MultivaluedMap;

public class Domain {

    public static final String UNDEFINED_ITEM = "undefined";

    private static final MultivaluedMap<String, String> EMPTY_MULTIVALUEDMAP = new UnmodifiableMultiValuedMap<String, String>(new MultiValuedHashMap<String, String>());
    private static final DataMap EMPTY_DATAMAP = new DataHashMap();
    private static final DataMap[] EMPTY_DATAMAPARRAY = new DataHashMap[0];

    private Domain() {
        throw new UnsupportedOperationException();
    }

    public static MultivaluedMap<String, String> emptyMultivaluedMap() {
        return EMPTY_MULTIVALUEDMAP;
    }

    public static DataMap emptyDataMap() {
        return EMPTY_DATAMAP;
    }

    public static DataMap[] emptyDataMapArray() {
        return EMPTY_DATAMAPARRAY;
    }

    public static boolean isUndefined(String value) {
        return (value == null) || UNDEFINED_ITEM.equals(value);
    }
}
