package nl.belastingdienst.iva.service;

import nl.belastingdienst.iva.database.configuration.tab.TabDefinition;
import nl.belastingdienst.iva.database.configuration.tab.TabDefinitionDependencyGroup;

import java.util.List;

public interface TabDefinitionService {
    TabDefinition findById(int id);

    TabDefinitionDependencyGroup findTabDefinitionDependencyGroupById(int id);

    List<TabDefinition> findAllByOrderByTitleAsc();

    List<TabDefinition> findByKey(String key);

    TabDefinition save(TabDefinition tabDefinition);

    List<TabDefinitionDependencyGroup> listDependencyGroups();
}
