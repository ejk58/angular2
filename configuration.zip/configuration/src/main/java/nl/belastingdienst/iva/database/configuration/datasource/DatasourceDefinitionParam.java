package nl.belastingdienst.iva.database.configuration.datasource;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_DATASOURCE_PARAM")
public class DatasourceDefinitionParam {

    public static final String CREDENTIALSMAPPING = "credentialsMappingJAAS";
    public static final String CREDENTIALSTYPE = "credentialsType";
    public static final String CREDENTIALSENCODING = "credentialsEncoding";
    public static final String CREDENTIALSVALUE = "credentialsValue";

    public static final String RESTURL = "restUrl";
    public static final String TERADATASCHEMA = "teradataSchema";
    public static final String TRUSTALLCERTIFICATES = "trustAllCertificates";
    public static final String ACCEPTHEADER = "acceptHeader";

    public static final String CONNECTTIMEOUT = "connectTimeout";
    public static final String READTIMEOUT = "readTimeout";
    public static final String SLOWEXECUTIONTIME = "slowQueryThreshold";

    @Id
    private Integer id;
    private String key;
    private String value;

    public DatasourceDefinitionParam() {
        // Default constructor
    }

    public DatasourceDefinitionParam(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getId() {
        return this.id;
    }

    public String getKey() {
        return this.key;
    }

    public String getValue() {
        return this.value;
    }
}
