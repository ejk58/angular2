package nl.belastingdienst.iva.domain;

public enum ValidateQuery {

	DUPLICATEVIEWKEY(
			"SELECT V.KEY FROM CONF_VIEW V GROUP BY V.KEY HAVING COUNT(V.KEY) > 1",
			MessageType.ERROR,
			"Some view-keys appear more than once in the view configuration: "),
	UNUSEDVIEW(
			"SELECT V.KEY FROM CONF_VIEW V WHERE V.ID NOT IN (SELECT TV.VIEW_ID FROM CONF_TAB_VIEW TV)",
			MessageType.WARNING,
			"Some views are not linked to tabs and appear to be unused: "),
	VIEWATTRIBUTEWITHUNDERSCORE(
			"SELECT V.KEY FROM CONF_VIEW V WHERE V.ID IN " + 
					"(SELECT VA.VIEW_ID FROM CONF_VIEW_ATTRIBUTE VA WHERE VA.VIEW_ID = V.ID AND (VA.KEY LIKE '%\\_%' OR VA.KEY LIKE '%-%'))",
			MessageType.WARNING,
			"This view has at least one attribute with an underscore or a dash: "),
	DUPLICATETABKEY(
			"SELECT T.KEY FROM CONF_TAB T GROUP BY T.KEY HAVING COUNT(T.KEY) > 1",
			MessageType.ERROR,
			"Some tab-keys appear more than once in the tab configuration: "),
	UNUSEDTAB(
			"SELECT T.KEY FROM CONF_TAB T WHERE T.ID NOT IN (SELECT TV.TAB_ID FROM CONF_TAB_VIEW TV)",
			MessageType.WARNING,
			"Some tabs are not linked to views and appear to be unused: "),
	DUPLICATEWIDGETNAME(
			"SELECT W.NAME FROM CONF_WIDGET W GROUP BY W.NAME HAVING COUNT(W.NAME) > 1",
			MessageType.ERROR,
			"Some widget-names appear more than once in the widget configuration: "),
	UNUSEDWIDGET(
			"SELECT W.NAME FROM CONF_WIDGET W WHERE W.CONTAINER_WIDGET_ID IS NULL AND W.NAME NOT LIKE '%_EXPORT' AND W.ID NOT IN " +
					"(SELECT TW.WIDGET_ID FROM CONF_TAB_WIDGET TW)",
			MessageType.WARNING,
			"Some widgets are not linked to tabs or container widgets and appear to be unused: "),
	MISSINGWIDGETTITLE(
			"SELECT W.NAME FROM CONF_WIDGET W WHERE W.TITLE IS NULL",
			MessageType.WARNING,
			"Some widgets are missing a title: "),
	DUPLICATEWIDGETINDEX(
			"SELECT W.NAME FROM CONF_WIDGET W WHERE W.ID IN " +
					"(SELECT CONTAINER_WIDGET_ID FROM CONF_WIDGET WHERE CONTAINER_WIDGET_ID IS NOT NULL GROUP BY CONTAINER_WIDGET_ID, INDEX HAVING COUNT(INDEX) > 1)",
			MessageType.WARNING,
			"Some widgets inside these container-widgets use duplicate indexes: "),
	WIDGETATTRIBUTEWITHUNDERSCORE(
			"SELECT W.NAME FROM CONF_WIDGET W WHERE W.ID IN " + 
					"(SELECT WA.WIDGET_ID FROM CONF_WIDGET_ATTRIBUTE WA WHERE WA.WIDGET_ID = W.ID AND (WA.KEY LIKE '%\\_%' OR WA.KEY LIKE '%-%'))",
			MessageType.WARNING,
			"This widget has at least one attribute with an underscore or a dash: "),
	QUERYWITHMISSINGTERADATASCHEMA(
			"SELECT Q.KEY FROM CONF_QUERY Q WHERE Q.TYPE = 1 AND Q.QUERYTEMPLATE NOT LIKE '%{teradataSchema:config}%'",
			MessageType.ERROR, 
			"Some Teradata-queries lack a Teradata-schema: "),
	DUPLICATEQUERYKEY(
			"SELECT Q.KEY FROM CONF_QUERY Q GROUP BY Q.KEY HAVING COUNT(Q.KEY) > 1", 
			MessageType.ERROR, 
			"Some query-keys appear more than once in the query configuration: "),
	QUERYWITHMISSINGFILTERPLACEHOLDER(
			"SELECT Q.KEY FROM CONF_QUERY Q WHERE EXISTS (SELECT ID FROM CONF_QUERY_FILTER QF WHERE QF.QUERY_ID = Q.ID) " + 
            		"AND Q.QUERYTEMPLATE NOT LIKE '%{:filter}%'", 
			MessageType.ERROR, 
			"Some queries have filters but no filter-placeholder: "),
	UNUSEDQUERY(
			"SELECT Q.KEY FROM CONF_QUERY Q WHERE Q.ID NOT IN (" +
                    "SELECT COALESCE(W.QUERY_ID, 0) FROM CONF_WIDGET W UNION " +
                    "SELECT COALESCE(T.QUERY_ID, 0) FROM CONF_TAB T UNION " +
                    "SELECT COALESCE(V.SEARCH_VIP_QUERY_ID, 0) FROM CONF_VIEW V UNION " +
                    "SELECT COALESCE(V.SEARCH_NOVIP_QUERY_ID, 0) FROM CONF_VIEW V UNION " +
                    "SELECT COALESCE(V.WIZARD_VIP_QUERY_ID, 0) FROM CONF_VIEW V UNION " +
                    "SELECT COALESCE(N.WIZARD_NOVIP_QUERY_ID, 0) FROM CONF_VIEW N)",
			MessageType.WARNING, 
			"Some queries are not linked to views or tabs or widgets and appear to be unused: "),
	DUPLICATEQUERYCOLUMNINDEX(
			"SELECT Q.KEY FROM CONF_QUERY Q WHERE Q.ID IN " +
					"(SELECT QC.QUERY_ID FROM CONF_QUERY_COLUMN QC GROUP BY QC.QUERY_ID, INDEX HAVING COUNT(QC.QUERY_ID) > 1)", 
			MessageType.WARNING, 
			"Some queries have columns with identical indexes: "),
	QUERYWITHMISSINGORDERBY(
			"SELECT Q.KEY FROM CONF_QUERY Q WHERE Q.TYPE IN (1, 2) AND Q.QUERYTEMPLATE NOT LIKE '%ORDER BY %'", 
			MessageType.WARNING, 
			"Some SQL-queries do not contain an order by-clause: "),
	QUERYWITHORINWHERECLAUSE(
			"SELECT Q.KEY FROM CONF_QUERY Q WHERE Q.TYPE = 1 AND Q.QUERYTEMPLATE LIKE '% OR %'", 
			MessageType.WARNING, 
			"Some Teradata-queries contain an 'or' in the where-clause: "),
	QUERYWITHMISSINGFILTER(
			"SELECT Q.KEY FROM CONF_QUERY Q WHERE Q.QUERYTEMPLATE LIKE '%{:filter}%' " + 
					"AND NOT EXISTS (SELECT ID FROM CONF_QUERY_FILTER QF WHERE QF.QUERY_ID = Q.ID)", 
			MessageType.WARNING, 
			"Some queries have a filter-placeholder but no filters: ");
	
	private String query;
	private MessageType messageType;
	private String baseMessage;

	private ValidateQuery(String query, MessageType messageType, String baseMessage) {
		this.query = query;
		this.messageType = messageType;
		this.baseMessage = baseMessage;
	}

	public String getQuery() {
		return query;
	}

	public MessageType getMessageType() {
		return messageType;
	}

	public String getBaseMessage() {
		return baseMessage;
	}
}
