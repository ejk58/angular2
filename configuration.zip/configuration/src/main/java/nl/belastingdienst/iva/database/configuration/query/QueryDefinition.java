package nl.belastingdienst.iva.database.configuration.query;

import nl.belastingdienst.iva.database.configuration.datasource.DatasourceDefinition;
import nl.belastingdienst.iva.util.ExportUtils;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "CONF_QUERY")
public class QueryDefinition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    private Integer type;
    @Column(name = "VIEWNAME")
    private String viewName;
    @Column(name = "QUERYTEMPLATE")
    private String queryTemplate;
    private String key;

    @OneToMany
    @JoinColumn(name = "QUERY_ID")
    @OrderBy(value = "index")
    private List<QueryDefinitionColumn> queryColumns;

    @OneToMany
    @JoinColumn(name = "QUERY_ID")
    private List<QueryDefinitionFilter> queryFilters;

    @OneToMany
    @JoinColumn(name = "QUERY_ID")
    @OrderBy(value = "key")
    private List<QueryDefinitionAttribute> queryAttributes;

    @ManyToOne
    @JoinColumn(name = "DATASOURCE_ID")
    private DatasourceDefinition datasource;

    public QueryDefinition() {
        this.queryColumns = new ArrayList<>();
        this.queryFilters = new ArrayList<>();
        this.queryAttributes = new ArrayList<>();
    }

    public Integer getId() {
        return this.id;
    }

    public nl.belastingdienst.iva.database.configuration.query.QueryType getType() {
        return QueryType.findQueryType(type);
    }

    public String getViewName() {
        return this.viewName;
    }

    public String getQueryTemplate() {
        return this.queryTemplate;
    }

    public String getKey() {
        return this.key;
    }

    public List<QueryDefinitionColumn> getQueryColumns() {
        return this.queryColumns;
    }

    public List<QueryDefinitionFilter> getQueryFilters() {
        return this.queryFilters;
    }

    public List<QueryDefinitionAttribute> getQueryAttributes() {
        return this.queryAttributes;
    }

    public DatasourceDefinition getDatasource() {
        return this.datasource;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public void setType(QueryType type) {
        this.type = type.getValue();
    }

    public void setViewName(String viewName) {
        this.viewName = viewName;
    }

    public void setQueryTemplate(String queryTemplate) {
        this.queryTemplate = queryTemplate;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setQueryColumns(List<QueryDefinitionColumn> queryColumns) {
        this.queryColumns = queryColumns;
    }

    public void setQueryFilters(List<QueryDefinitionFilter> queryFilters) {
        this.queryFilters = queryFilters;
    }

    public void setQueryAttributes(List<QueryDefinitionAttribute> queryAttributes) {
        this.queryAttributes = queryAttributes;
    }

    public void setDatasource(DatasourceDefinition datasource) {
        this.datasource = datasource;
    }

    public String toSql() {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("-- Query " + this.key + "\n");

        sqlBuilder.append("INSERT INTO \"CONF_QUERY\"(KEY, TYPE, DATASOURCE_ID, VIEWNAME, QUERYTEMPLATE) VALUES (");
        sqlBuilder.append(ExportUtils.getString(this.key) + ", ");
        sqlBuilder.append(this.type + ", ");
        sqlBuilder.append(this.datasource == null ? "null, " : "(SELECT ID FROM CONF_DATASOURCE WHERE KEY = '" + this.datasource.getKey() + "'), ");
        sqlBuilder.append(ExportUtils.getString(this.viewName) + ", ");
        sqlBuilder.append(ExportUtils.getString(this.queryTemplate));
        sqlBuilder.append(");\n");

        for (QueryDefinitionColumn queryDefinitionColumn : this.queryColumns) {
            sqlBuilder.append(queryDefinitionColumn.toSql("(SELECT q.ID FROM CONF_QUERY q WHERE q.KEY = '" + this.key + "')", null));
        }

        for (QueryDefinitionFilter queryDefinitionFilter : this.queryFilters) {
            sqlBuilder.append(queryDefinitionFilter.toSql(this.key));
        }

        for (QueryDefinitionAttribute queryDefinitionAttribute : this.queryAttributes) {
            sqlBuilder.append(queryDefinitionAttribute.toSql(this.key));
        }

        sqlBuilder.append("\n");
        return sqlBuilder.toString();
    }


}
