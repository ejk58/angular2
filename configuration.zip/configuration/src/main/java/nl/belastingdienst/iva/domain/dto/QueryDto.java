package nl.belastingdienst.iva.domain.dto;

import java.util.ArrayList;
import java.util.List;

import nl.belastingdienst.iva.database.configuration.query.QueryType;

public class QueryDto {
    private Integer id;
    private QueryType type;
    private String queryTemplate;
    private String key;
    private String viewName;
    private String dataSource;
    private List<QueryColumnDto> queryColumns;
    private List<QueryFilterDto> queryFilters;
    private List<QueryAttributeDto> queryAttributes;

    public QueryDto(Integer id, String viewName, String key) {
        this.id = id;
        this.viewName = viewName;
        this.key = key;
    }

    public QueryDto() {
        // Default constructor
    }
    
    public String getQueryTemplate() {
        return queryTemplate;
    }
    
    public void setQueryTemplate(String queryTemplate) {
        this.queryTemplate = queryTemplate;
    }
    
    public String getKey() {
        return key;
    }
    
    public void setKey(String key) {
        this.key = key;
    }
    
    public String getDataSource() {
        return dataSource;
    }
    
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }
    
    public List<QueryColumnDto> getQueryColumns() {
        return queryColumns;
    }
    
    public void setQueryColumns(List<QueryColumnDto> queryColumns) {
        this.queryColumns = queryColumns;
    }
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getViewName() {
        return viewName;
    }
    
    public void setViewName(String viewName) {
        this.viewName = viewName;
    }
    
    public QueryType getType() {
        return type;
    }
    
    public void setType(QueryType type) {
        this.type = type;
    }


    public List<QueryFilterDto> getQueryFilters() {
        return queryFilters;
    }

    public void setQueryFilters(List<QueryFilterDto> queryFilters) {
        this.queryFilters = queryFilters;
    }

    public List<QueryAttributeDto> getQueryAttributes() {
        return queryAttributes;
    }

    public void setQueryAttributes(List<QueryAttributeDto> queryAttributes) {
        this.queryAttributes = queryAttributes;
    }


    public void addColumn(QueryColumnDto queryColumnDto) {
    	if (this.queryColumns == null) {
    		this.queryColumns = new ArrayList<QueryColumnDto>();
    	}
    	
    	this.queryColumns.add(queryColumnDto);
    }
}
