package nl.belastingdienst.iva.repository;

import nl.belastingdienst.iva.database.configuration.tab.TabDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TabDefinitionRepository extends JpaRepository<TabDefinition, Long> {
    List<TabDefinition> findAllByOrderByTitleAsc();

    TabDefinition findById(int id);

    List<TabDefinition> findByKeyContaining(String key);
}
