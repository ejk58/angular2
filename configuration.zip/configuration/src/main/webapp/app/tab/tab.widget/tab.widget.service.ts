import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {TabService} from '../tab.service';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {TabWidget} from '../../domain/tabwidget';

@Injectable()
export class TabWidgetService extends TabService {

    private apiWidgetTabUrl = 'api/widgets/tab';

    constructor(protected http: HttpClient) {
        super(http);
    }

    getTabWidgetsByTab(tabId: number): Observable<TabWidget[]> {
        return this.http.get<TabWidget[]>(this.apiWidgetTabUrl + '/' + tabId);
    }


    deleteTabwidget(tabWidgetId: number) {
        return this.http.delete(this.apiWidgetTabUrl + '/' + tabWidgetId);
    }
}
