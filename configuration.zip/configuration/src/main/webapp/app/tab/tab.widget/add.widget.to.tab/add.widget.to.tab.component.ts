import {FormBuilder, Validators, FormGroup} from '@angular/forms';
import {AddWidgetToTabService} from './add.widget.to.tab.service';
import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {Widget} from '../../../domain/widget';
import { fade } from '../../../animation/animations';
import {TabWidget} from '../../../domain/tabwidget';

@Component({
    selector: 'add-widget-to-tab',
    templateUrl: './add.widget.to.tab.component.html',
    styleUrls: ['./add.widget.to.tab.component.scss'],
    providers: [AddWidgetToTabService],
    animations: [
        fade
    ]
})
export class AddWidgetToTabComponent implements OnInit {
    public widgets: Array<Widget>;
    public loading: Boolean;
    public widgetSelected: Widget;
    widgetOnTabForm: FormGroup;
    public notAllInputFilled: boolean;
    public gridColumns = 4;
    public columnIndex = 1;

    @Input()
    public tabId: Number;

    @Input()
    public maxRowIndex: Number;

    @Output()
    saveEvent: EventEmitter<string> = new EventEmitter();

    constructor(private builder: FormBuilder, private addWidgetToTabService: AddWidgetToTabService) {
    }

    ngOnInit() {
        if (this.tabId === undefined) {
            this.notAllInputFilled = true;
        } else {
            this.notAllInputFilled = false;
            this.loading = true;
            this.addWidgetToTabService.getWidgets().subscribe(data => {
                    this.widgets = data;
                    this.loading = false;
                }
            );
            this.widgetOnTabForm = this.builder.group({
                widgetId: ['', Validators.required],
                tabId: ['', Validators.required],
                gridColumns: ['', Validators.required],
                rowIndex: [this.maxRowIndex, [Validators.required, Validators.min(1)]],
                columnIndex: ['', [Validators.required, Validators.min(1), Validators.max(this.gridColumns)]]
            });
        }
    }

    saveTabWidget(tabWidget: TabWidget) {
        this.addWidgetToTabService.saveTabWidget(tabWidget).subscribe(data => {
            this.saveEvent.emit();
        });
    }

    checkColumnIndex() {
        if (this.gridColumns < this.columnIndex) {
            this.columnIndex = this.gridColumns;
        }
    }
}
