import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {WidgetService} from '../../../widget/widget.service';
import {TabWidget} from '../../../domain/tabwidget';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class AddWidgetToTabService extends WidgetService {
    constructor(protected http: HttpClient) {
        super(http);
    }

    saveTabWidget(tabWidget: TabWidget) {
        return this.http.post(this.apiWidgetUrl + '/tabwidget', tabWidget, this.getHeaders());
    }
}
