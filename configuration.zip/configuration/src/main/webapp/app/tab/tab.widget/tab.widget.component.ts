import {Component, OnInit} from '@angular/core';
import {FormBuilder} from '@angular/forms';
import {TabWidgetService} from './tab.widget.service';
import {TabWidget} from '../../domain/tabwidget';
import {TabDefinition} from '../../domain/tabdefinition';
import {fade} from '../../animation/animations';

@Component({
    selector: 'tab-widget',
    templateUrl: './tab.widget.component.html',
    styleUrls: ['./tab.widget.component.scss', '../../../_table.scss'],
    providers: [TabWidgetService],
    animations: [
        fade
    ]
})
export class TabWidgetComponent implements OnInit {
    public tabs: TabDefinition[];
    public tabWidgets: TabWidget[];
    public tab: number;
    public widgetToTab: boolean;
    private maxRowIndex: number;

    constructor(private builder: FormBuilder, private tabWidgetService: TabWidgetService) {
    }

    ngOnInit() {
        this.tabWidgetService.getTabs().subscribe(data =>
            this.tabs = data
        );
    }

    onTabChange($event) {
        this.widgetToTab = false;
        this.tabWidgetService.getTabWidgetsByTab(this.tab).subscribe(data => {
            this.tabWidgets = data;
            this.defineMaxRowIndex();
        });
    }

    deleteTabWidget(tabWidgetId: number) {
        this.tabWidgetService.deleteTabwidget(tabWidgetId).subscribe(() => {
            this.tabWidgets = this.tabWidgets.filter(tabWidget => tabWidget.id !== tabWidgetId);
        });
    }

    addWidgetToTab() {
        this.widgetToTab = true;
    }

    defineMaxRowIndex() {
        let maxRowIndex = 1;
        for (const tabWidget of this.tabWidgets) {
            if (tabWidget.rowIndex >= maxRowIndex) {
                maxRowIndex = tabWidget.rowIndex + 1;
            }
        }
        this.maxRowIndex = maxRowIndex;
    }
}

