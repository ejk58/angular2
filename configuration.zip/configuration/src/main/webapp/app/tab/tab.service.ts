import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import {HttpClient} from '@angular/common/http';
import {ServiceHttpClient} from '../serviceHttpClient';
import {TabDefinition} from '../domain/tabdefinition';


@Injectable()
export class TabService extends ServiceHttpClient {
    private apiTabUrl = 'api/tabs';

    constructor(protected http: HttpClient) {
        super(http);
    }

    getTabs(): Observable<TabDefinition[]> {
        return this.http.get<TabDefinition[]>(this.apiTabUrl + '/' + name);
    }
}
