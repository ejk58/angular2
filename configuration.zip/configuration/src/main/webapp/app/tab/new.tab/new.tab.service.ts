import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import {TabDefinition} from '../../domain/tabdefinition';
import {HttpClient} from '@angular/common/http';
import {ServiceHttpClient} from '../../serviceHttpClient';

@Injectable()
export class NewTabService extends ServiceHttpClient {
    public tab: TabDefinition;
    private apiViewUrl = 'api/views';
    private apiTabUrl = 'api/tabs';

    private apiDependencyGroupUrl = this.apiTabUrl + '/dependencygroups';
    private apiViewDomainUrl = this.apiTabUrl + '/viewdomain';

    constructor(protected http: HttpClient) {
        super(http);
    }

    getViews(): Observable<any> {
        return this.http.get(this.apiViewUrl);
    }

    getDependencyGroups(): Observable<any> {
        return this.http.get(this.apiDependencyGroupUrl);
    }

    getViewDomains(viewId: number): Observable<any> {
        return this.http.get(this.apiViewDomainUrl + '/' + viewId);
    }

    getTabs(): Observable<any> {
        return this.http.get(this.apiTabUrl + '/' + name);
    }

    getTab(key: string): Observable<any> {
        return this.http.get(this.apiTabUrl + '/onetab?key=' + key);
    }


    storeTab(tabDefinition: TabDefinition): Observable<any> {
        const body = JSON.stringify(tabDefinition);
        return this.http.post(this.apiTabUrl + '/' + name, body, this.getHeaders());
    }
}
