import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {TabDefinition} from '../../domain/tabdefinition';
import {NewTabService} from './new.tab.service';

@Component({
    selector: 'new-tab',
    templateUrl: './new.tab.component.html',
    styleUrls: ['./new.tab.component.scss'],
    providers: [NewTabService]
})
export class NewTabComponent implements OnInit {
    public views: Object;
    public tabs: Object;
    public tab: TabDefinition;
    public dependencyGroups: Object;
    public viewDomains: Object;
    public result: Object;
    public saved: Boolean;

    tabForm: FormGroup;

    constructor(private builder: FormBuilder, private newTabService: NewTabService) {
    }

    ngOnInit() {
        this.newTabService.getViews().subscribe(data =>
            this.views = data
        );

        this.newTabService.getDependencyGroups().subscribe(data =>
            this.dependencyGroups = data
        );

        this.tabForm = this.builder.group({
            tabTitle: ['', [Validators.required, Validators.pattern('[A-Za-z-_0-9\ ]*')]],
            tabViewName: ['', Validators.required],
            dependencyGroupName: ['', Validators.required]
        });


        this.tabForm.valueChanges.subscribe(data => {
            if (this.tabForm.valid) {
                this.tab = new TabDefinition(null, data.tabTitle, data.tabTitle, data.tabViewName.id, null, data.dependencyGroupName.id);
            }
        });
    }

    getViews() {
        this.newTabService.getViews().subscribe(data =>
            this.views = data
        );
    }

    getDependencyGroups() {
        this.newTabService.getDependencyGroups().subscribe(data =>
            this.getDependencyGroups = data
        );
    }

    getViewDomains(viewId: number) {
        this.newTabService.getViewDomains(viewId).subscribe(data => {
            this.viewDomains = data;
        });
    }

    storeTab() {
        if (this.tabForm.valid) {
            this.newTabService.storeTab(this.tab).subscribe(res => {
                this.tabForm.reset();
                this.saved = true;
                setTimeout(() => {
                    this.saved = false;
                }, 4000);
            });
        }
    }
}
