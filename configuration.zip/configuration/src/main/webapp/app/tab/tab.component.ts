import {Component, OnInit} from '@angular/core';
import {TabService} from './tab.service';

@Component({
    selector: 'tab',
    templateUrl: './tab.component.html',
    styleUrls: ['./tab.component.scss', '../../_accordion.scss'],
    providers: [TabService]
})
export class TabComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {

    }
}
