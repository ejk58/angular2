import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {WidgetCopyService} from './widget.copy.service';
import {Widget} from '../../domain/widget';

@Component({
    selector: 'widget-copy',
    templateUrl: './widget.copy.component.html',
    styleUrls: ['./widget.copy.component.scss'],
    providers: [WidgetCopyService]
})
export class WidgetCopyComponent implements OnInit {
    public widgets: Array<Widget>;
    public loading: Boolean;
    public widgetSelected: Widget;
    public saved: Boolean;

    widgetCopyForm: FormGroup;

    constructor(private builder: FormBuilder, private widgetCopyService: WidgetCopyService) {
    }

    ngOnInit() {
        this.loading = true;
        this.widgetCopyService.getWidgets().subscribe(data => {
                this.widgets = data;
                this.loading = false;
            }
        );

        this.widgetCopyForm = this.builder.group({
            id: ['', Validators.required],
            name: ['', Validators.required],
            type: ['', Validators.required],
            title: ['', Validators.required],
            description: [''],
            descriptionMore: ['']
        });
    }

    saveCopyOfWidget(widget: Widget) {
        this.widgetCopyService.copyWidget(widget).subscribe(data => {
            this.widgets.push(data);
            this.widgetSelected = null;
            this.widgetCopyForm.reset();
            this.saved = true;
            setTimeout(() => {
                this.saved = false;
            }, 4000);
        });
    }
}

