import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {WidgetService} from '../widget.service';
import {Observable} from 'rxjs';
import {Widget} from '../../domain/widget';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class WidgetCopyService extends WidgetService {
    constructor(protected http: HttpClient) {
        super(http);
    }

    copyWidget(widget: Widget): Observable<any> {
        return this.http.post(this.apiWidgetUrl + '/copy', widget, this.getHeaders());
    }
}
