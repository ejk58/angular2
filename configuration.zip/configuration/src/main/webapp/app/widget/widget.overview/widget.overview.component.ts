import {Component, OnInit} from '@angular/core';
import {WidgetService} from '../widget.service';
import {Widget} from '../../domain/widget';
import {DataTable} from 'primeng/primeng';


@Component({
    selector: 'widget-overview',
    templateUrl: './widget.overview.component.html',
    styleUrls: ['../../../_table.scss'],
    providers: [WidgetService]
})
export class WidgetOverviewComponent implements OnInit {
    public widgets: Array<Widget>;
    public loading:  boolean;

    constructor(private widgetService: WidgetService) {
    };

    ngOnInit() {
        this.loading = true;
        this.widgetService.getWidgets().subscribe(data => {
                this.widgets = data;
                this.loading = false;
            }
        );
    };

    reset(table: DataTable) {
        table.reset();
    };

}
