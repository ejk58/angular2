import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {WidgetModifyService} from './widget.modify.service';
import {Widget} from '../../domain/widget';
import {WidgetType} from '../../domain/widgettype';

@Component({
    selector: 'widget-modify',
    templateUrl: './widget.modify.component.html',
    styleUrls: ['./widget.modify.component.scss'],
    providers: [WidgetModifyService]
})
export class WidgetModifyComponent implements OnInit {
    public widgets: Array<Widget>;
    public loading: Boolean;
    public widgetSelected: Widget;
    public saved: Boolean;
    public widgetTypes: Array<String> = [];

    widgetModifyForm: FormGroup;

    constructor(private builder: FormBuilder, private widgetModifyService: WidgetModifyService) {
    }

    ngOnInit() {
        this.loading = true;
        this.widgetModifyService.getWidgets().subscribe(data => {
            this.widgets = data;
            this.loading = false;
        });

        this.widgetModifyService.getWidgetTypes().subscribe(data => {
            this.widgetTypes = data;
            this.loading = false;
        });

        this.widgetModifyForm = this.builder.group({
            id: [''],
            name: [''],
            type: [''],
            title: [''],
            description: [''],
            descriptionMore: [''],
            index: [''],
            visible: [''],
            refreshInfo: ['']
        });
    }

    saveModifyOfWidget(widget: Widget) {
        this.widgetModifyService.modifyWidget(widget).subscribe(data => {
            this.widgets = this.widgets.filter(theWidget => {
                return theWidget.name !== this.widgetSelected.name;
            });
            this.widgets.push(data);
            this.widgets.sort((widget1, widget2) => {
                return (widget1.title > widget2.title) ? 1 : ((widget1.title > widget2.title) ? -1 : 0);
            });
            this.widgetSelected = null;
            this.saved = true;
            setTimeout(() => {
                this.saved = false;
            }, 4000);
        });
    }
}

