import {Component, OnInit} from '@angular/core';
import {WidgetService} from './widget.service';
import {QueryService} from '../query/query.service';

@Component({
    selector: 'widget',
    templateUrl: './widget.component.html',
    styleUrls: ['./widget.component.scss', '../../_accordion.scss'],
    providers: [WidgetService, QueryService]
})
export class WidgetComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {

    }
}

