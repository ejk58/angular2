import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import {Widget} from '../domain/widget';
import {HttpClient} from '@angular/common/http';
import {ServiceHttpClient} from '../serviceHttpClient';


@Injectable()
export class WidgetService extends ServiceHttpClient {
    public apiWidgetUrl = 'api/widgets';

    constructor(protected http: HttpClient) {
        super(http);
    }

    getWidgets(): Observable<Array<Widget>> {
        return this.http.get<Array<Widget>>(this.apiWidgetUrl);
    }

    storeWidget(widget: Widget): Observable<any> {
        const name = 'save';
        return this.http.post(this.apiWidgetUrl + '/' + name, widget, this.getHeaders());
    }

    getWidget(widgetId: number): Observable<Widget> {
        return this.http.get<Widget>(this.apiWidgetUrl + '/' + widgetId);
    }
}
