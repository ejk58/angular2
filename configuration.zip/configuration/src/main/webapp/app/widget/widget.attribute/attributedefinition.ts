export class AttributeDefinition {
    public attrKey: string;
    public attrType: string;
    public attrDefault: string;
    public attrFixed: boolean;

    constructor(attrKey: string, attrType: string, attrDefault: string, attrFixed: boolean) {
        this.attrKey = attrKey;
        this.attrType = attrType;
        this.attrDefault = attrDefault;
        this.attrFixed = attrFixed;
    }
}
