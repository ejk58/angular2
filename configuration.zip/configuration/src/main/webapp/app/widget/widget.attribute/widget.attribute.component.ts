import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {WidgetAttributeService} from './widget.attribute.service';
import {WidgetAttribute} from '../../domain/widgetattribute';
import {Widget} from '../../domain/widget';
import {AttributeDefinition} from '../../domain/attributedefinition';
import {AttributeOption} from '../../domain/attributeoption';

@Component({
    selector: 'widget-attribute',
    templateUrl: './widget.attribute.component.html',
    styleUrls: ['./widget.attribute.component.scss', '../../../_table.scss'],
    providers: [WidgetAttributeService]
})
export class WidgetAttributeComponent implements OnInit {
    public widgets: Array<Widget>;
    public widget: Widget;
    public loading: Boolean;
    public showAddForm: Boolean;
    public attributeDefinitions: Array<AttributeDefinition> = [];
    public newAttribute: WidgetAttribute = new WidgetAttribute(null, null, null, null);
    public attributes: Array<AttributeOption> = [];
    public attributeValues: Array<String> = [];

    widgetAttributesForm: FormGroup;

    constructor(private builder: FormBuilder, private widgetAttributeService: WidgetAttributeService) {
    }

    ngOnInit() {
        this.loading = true;
        this.showAddForm = false;
        this.widgetAttributeService.getWidgets().subscribe(data => {
                this.widgets = data;
                this.loading = false;
            });

        this.widgetAttributeService.getAttributes().subscribe(data => {
            for (let i = 0; i < data.length; i++) {
                this.attributes.push(new AttributeOption(data[i]['key'], data[i]['values']));
            }

            this.loading = false;
        });

        this.widgetAttributesForm = this.builder.group({
            id: [''],
            widgetName: [''],
            attributeKey: ['', Validators.required],
            attributeValue: ['', Validators.required]
        });
    }

    storeWidgetAttribute() {
        const widgetAttribute = new WidgetAttribute(null, this.widget.id, this.newAttribute.key, this.newAttribute.value);
        this.widgetAttributeService.storeWidgetAttribute(widgetAttribute).subscribe(data => {
            this.widget.attributes.push(data);
            this.newAttribute = new WidgetAttribute(null, null, null, null);
            this.showAddForm = false;
            setTimeout(() => {
            }, 4000);
        });
    }

    deleteWidgetAttribute(attribute: WidgetAttribute) {
        const widgetAttribute = new WidgetAttribute(attribute.id, this.widget.id, attribute.key, attribute.value);
        this.widgetAttributeService.deleteWidgetAttribute(widgetAttribute).subscribe(res => {
            this.widget.attributes = this.widget.attributes.filter(function (el) {
                return el.id !== attribute.id;
            });
        });
    }

    onAttributeChange(newAttribute) {
        for (let i = 0; i < this.attributes.length; i++) {
            if (this.attributes[i]['key'] === newAttribute.key) {
                this.newAttribute.value = this.attributes[i]['values'][0];
                this.attributeValues = this.attributes[i]['values'];
            }
        }

        // let control = this.widgetAttributesForm.get('attributeValue');
        // if (this.newAttribute.attrFixed) {
        //     control.disable();
        // } else {
        //     control.enable();
        // }
        // if (this.newAttribute.attrType == 'integer') {
        //     control.validator = Validators.pattern('[1-9]{1}[0-9]*');
        // } else {
        //     control.validator = Validators.required;
        // }
    }

    showAddAttributeForm() {
        this.showAddForm = true;
    }

    cancel() {
        this.newAttribute = new WidgetAttribute(null, null, null, null);
        this.showAddForm = false;
    }
}
