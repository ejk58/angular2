import { Component, OnInit } from '@angular/core';
import { Widget } from '../../domain/widget';
import { Query } from '../../domain/query';
import 'codemirror/mode/sql/sql';
import {WidgetService} from '../widget.service';
import {QueryService} from '../../query/query.service';

@Component({
    selector: 'widget-query',
    templateUrl: './widget.query.component.html',
    styleUrls: ['./widget.query.component.scss', '../../../_table.scss'],
    providers: [WidgetService, QueryService]
})
export class WidgetQueryComponent implements OnInit {
    public widgets: Widget[];
    public widgetSelected: Widget;
    public loading: Boolean;
    public query: Query;
    public widgetWithColumns: Widget;
    public childWidgets: Widget[];

    constructor(private widgetService: WidgetService, private queryService: QueryService) {
    }

    ngOnInit() {
        this.loading = true;
        this.widgetService.getWidgets().subscribe(data => {
            this.widgets = data;
            this.loading = false;
        });
    }

    onWidgetChange($event) {
        if (this.widgetSelected.queryId != null) {
            this.loading = true;
            this.queryService.getQuery(this.widgetSelected.queryId).subscribe(data => {
                if (data != null) {
                    this.query = data;
                }
                this.loading = false;
            });
        } else {
            this.query = null;
        }
        this.loading = true;
        this.widgetService.getWidget(this.widgetSelected.id).subscribe(data => {
            this.widgetWithColumns = data;
            this.childWidgets = this.widgetWithColumns.childWidgets;
            this.loading = false;
        });
    }
}

