import {Injectable} from '@angular/core';
import {Http, Response, RequestOptions, Headers} from '@angular/http';
import {Observable} from 'rxjs';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';

@Injectable()
export class ServiceHttpClient {

    constructor(protected http: HttpClient) {
    }

    handleError(error: HttpErrorResponse) {
      return Observable.throw(`${error.message}`);
    }

    getHeaders(): any {
        const headers = new HttpHeaders({'Content-Type': 'application/json; charset=utf-8'});
        return {headers: headers};
    }

}
