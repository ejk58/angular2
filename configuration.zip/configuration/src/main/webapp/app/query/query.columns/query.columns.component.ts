import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {QueryService} from '../query.service';
import {Query} from '../../domain/query';
import {QueryColumn} from '../../domain/querycolumn';
import {Message} from '../../domain/message';
import {DatasourceService} from '../../datasource/datasource.service';

@Component({
    selector: 'query-columns',
    templateUrl: './query.columns.component.html',
    styleUrls: ['./query.columns.component.scss', '../../../_table.scss'],
    providers: [QueryService, DatasourceService],
    encapsulation: ViewEncapsulation.None
})
export class QueryColumnsComponent implements OnInit {
    public queries: Query[];
    public querySelected: Query;
    public queryDetails: Query;
    public columnTypes: String[];
    public columnNames: String[];

    public queryColumns: Array<QueryColumn>;
    public column: QueryColumn = new QueryColumn();
    public loading: boolean;
    public displayDialog: boolean;
    public isNewQueryColumn: boolean;
    public chooseColumn = true;

    public msgs: Message[];

    constructor(private queryService: QueryService, private datasourceService: DatasourceService) {
        this.loading = true;
    }

    ngOnInit() {
        this.loading = true;
        this.queryService.getQueries().subscribe(data => {
            this.queries = data;
            this.loading = false;
        });
        this.queryService.getColumnTypes().subscribe(data => {
            this.columnTypes = data;
        });
    }

    onQueryChange($event) {
        if (this.querySelected) {
            this.queryDetails = this.querySelected;
        }
        this.loading = true;
        this.datasourceService.getViewColumns(this.querySelected.viewName).subscribe(data => {
            if (data != null) {
                this.columnNames = data;
            }
        });
        this.queryService.getQuery(this.querySelected.id).subscribe(data => {
            if (data != null) {
                this.queryDetails = data;
                this.queryColumns = this.getFlatlistOfAllColumns(this.queryDetails);
            }
            this.loading = false;
        });
    }

    showDialogToAdd() {
        this.isNewQueryColumn = true;
        this.column = new QueryColumn();
        this.displayDialog = true;
        this.msgs = [];
    }

    save() {
        // todo hier wordt de save van de query gedaan
        this.column = null;
        this.displayDialog = false;
    }

    saveColumn() {
        if (this.columnDataIsValid()) {
            const queryColumns = [...this.queryColumns];

            // or the query is parent or another column
            if (this.column.compositeColumnId == null) {
                this.column.queryId = this.queryDetails.id;
            } else {
                this.column.queryId = null;
            }

            if (this.isNewQueryColumn) {
                this.column.columns = [];
                queryColumns.push(this.column);
            } else {
                queryColumns[this.findSelectedQueryColumnIndex(this.column.id)] = this.column;
            }
            this.queryDetails.queryColumns = queryColumns;
            this.queryColumns = queryColumns;

            this.queryService.storeQueryColumn(this.column)
                .subscribe(
                    data => {
                        this.column.id = data.id;
                        this.displayDialog = false;
                    },
                    error => {
                        this.msgs.push(new Message('error', 'Error Message',  'Er is iets misgegaan bij het opslaan.'));
                    }
                );
        }
    }

    columnDataIsValid(): boolean {
        let result = true;
        this.msgs = [];

        const newIndex = this.column.index;
        for (const column of this.queryColumns) {
            if (column.index === newIndex && this.column.id !== column.id) {
                result = false;
                this.msgs.push(new Message('error', 'Error Message',  'Kolom index wordt al gebruikt.'));
            }
        }
        return result;
    }

    deleteColumn() {
        this.msgs = [];
        this.queryService.deleteQueryColumn(this.column.id)
            .subscribe(
                data => {
                    const index = this.findSelectedQueryColumnIndex(this.column.id);
                    this.queryColumns = this.queryColumns.filter((val, i) => i !== index);
                    this.displayDialog = false;
                },
                error => {
                    if (error.error.message.includes('ConstraintViolationException')) {
                        this.msgs.push(new Message('error', 'Error Message', 'Query kolom wordt nog gebruikt door 1 of meer widgets.'));
                    } else {
                        this.msgs.push(new Message('error', 'Error Message',  'Er is iets misgegaan bij het verwijderen.'));
                    };
                }
            );
    }

    findSelectedQueryColumnIndex(id: number): number {
        return this.queryColumns.findIndex(col => col.id === id);
    }

    onRowSelect(event) {
        this.isNewQueryColumn = false;
        this.chooseColumn = false;
        this.column = this.cloneColumn(event.data);
        this.displayDialog = true;
        this.msgs = [];
    }

    cloneColumn(col: QueryColumn): QueryColumn {
        return JSON.parse(JSON.stringify(col));
    }

    styleRow(rowData): string {
        return 'sublevel-' + rowData.level;
    }

    private getFlatlistOfAllColumns(query: Query): Array<QueryColumn> {
        const flatColumnList: Array<QueryColumn> = [];
        query.queryColumns.forEach((column) => {
            column.level = 0;
            flatColumnList.push(column);
            if (column.columns != null && column.columns.length > 0) {
                this.addSubColumns(flatColumnList, column.columns, 1);
            }
        });
        return flatColumnList;
    }

    private addSubColumns(columnList: Array<QueryColumn>, subColumns: Array<QueryColumn>, level: number) {
        subColumns.forEach(subColumn => {
            subColumn.level = level;
            columnList.push(subColumn);
            if (subColumn.columns != null && subColumn.columns.length > 0) {
                this.addSubColumns(columnList, subColumn.columns, (level + 1));
            }
        });
    }
}
