import { Component, OnInit } from '@angular/core';
import {QueryService} from './query.service';

@Component({
    selector: 'query',
    templateUrl: './query.component.html',
    styleUrls: ['./query.component.scss', '../../_accordion.scss'],
    providers: [QueryService]
})

export class QueryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
