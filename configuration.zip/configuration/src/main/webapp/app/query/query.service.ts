import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Query} from '../domain/query';
import {QueryColumn} from '../domain/querycolumn';
import {HttpClient} from '@angular/common/http';
import {ServiceHttpClient} from '../serviceHttpClient';

@Injectable()
export class QueryService  extends ServiceHttpClient {
    public apiQueryUrl = 'api/queries';

    constructor(protected http: HttpClient) {
       super(http);
    };

    getQuery(queryId: number): Observable<Query> {
        return this.http.get<Query>(this.apiQueryUrl + '/' + queryId);
    }

    getQueries(): Observable<Query[]> {
        return this.http.get<Query[]>(this.apiQueryUrl);
    }

    storeQuery(query: Query): Observable<Query> {
        return this.http.post<Query>(this.apiQueryUrl + '/save', query, {responseType: 'json'});
    }

    storeQueryColumn(queryColumn: QueryColumn): Observable<QueryColumn> {
        return this.http.post<QueryColumn>(this.apiQueryUrl + '/columns/save', queryColumn, {responseType: 'json'});
    }

    deleteQueryColumn(columnId: number): Observable<any> {
        return this.http.post(this.apiQueryUrl + '/columns/delete', columnId, {responseType: 'json'});
    }

    getColumnTypes(): Observable<String[]> {
        return this.http.get<String[]>(this.apiQueryUrl + '/columns/types');
    }
}
