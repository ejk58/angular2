import {Component, OnInit} from '@angular/core';
import {QueryService} from '../query.service';
import {Query} from '../../domain/query';

@Component({
    selector: 'query-info',
    templateUrl: './query.info.component.html',
    styleUrls: ['./query.info.component.scss', '../../../_table.scss'],
    providers: [QueryService]
})
export class QueryInfoComponent implements OnInit {
    public queries: Query[];
    public loading: Boolean;
    public querySelected: Query;
    public queryDetails: Query;

    constructor(private queryService: QueryService) {
        this.loading = true;
    }

    ngOnInit() {
        this.loading = true;
        this.queryService.getQueries().subscribe(data => {
            this.queries = data;
            this.loading = false;
        });
    }

    onQueryChange($event) {
        if (this.querySelected) {
            this.queryDetails = null;
        }
        this.loading = true;
        this.queryService.getQuery(this.querySelected.id).subscribe(data => {
            if (data != null) {
                this.queryDetails = data;
            }
            this.loading = false;
        });
    }

}
