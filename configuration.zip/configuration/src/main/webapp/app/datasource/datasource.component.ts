import {Component, OnInit} from '@angular/core';
import {DatasourceService} from './datasource.service';
import {DatasourceView} from '../domain/datasourceview';

@Component({
    selector: 'datasource',
    templateUrl: './datasource.component.html',
    styleUrls: [
        './datasource.component.scss'
    ],
    providers: [DatasourceService]
})
export class DatasourceComponent implements OnInit {
    public datasourceViews:  Array<DatasourceView>;
    public loading: Boolean;

    constructor(private datasourceService: DatasourceService) {
    }

    ngOnInit() {
        this.loading = true;
        this.getDatasourceViews();
    }

    getDatasourceViews() {
        this.loading = true;
        this.datasourceService.getDatasourceViews().subscribe(data => {
            this.datasourceViews = data;
            this.loading = false;
        });
    }

}
