import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import {ServiceHttpClient} from '../serviceHttpClient';
import {HttpClient} from '@angular/common/http';
import {DatasourceView} from '../domain/datasourceview';

@Injectable()
export class DatasourceService extends ServiceHttpClient {
    private apiUrl = '/api/datasources';

    constructor(public http: HttpClient) {
        super(http);
    }

    getDatasourceViews(): Observable<any> {
        return this.http.get(this.apiUrl + '/views');
    }

    getViewColumns(viewName: string): Observable<String[]> {
        return this.http.get<String[]>(this.apiUrl + '/columns/' + viewName);
    }
}
