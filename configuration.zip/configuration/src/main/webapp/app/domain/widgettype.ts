export class WidgetType {

    constructor(public type: string) {
    }
}
