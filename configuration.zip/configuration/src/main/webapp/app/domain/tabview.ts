export class TabView {

    constructor(public id: number,
                public tabId: number,
                public viewId: number) {
    }
}
