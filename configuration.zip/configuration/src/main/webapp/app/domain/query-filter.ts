export class QueryFilter {
    constructor(public id: number,
                public filterTemplate: string,
                public noFilterTemplate) {
    }
}
