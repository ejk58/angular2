export class AttributeOption {

    constructor(public key: string,
                public values: Array<string>) {
    }
}
