 export class TabDefinitionDependencyGroup {

    constructor(public id: number,
                public key: string,
                public label: string,
                public dependencies: Array<Object>) {
    }
}
