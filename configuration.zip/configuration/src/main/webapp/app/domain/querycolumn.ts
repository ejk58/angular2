export class QueryColumn {

    constructor(public id?: number,
                public queryId?: number,
                public compositeColumnId?: number,
                public index?: number,
                public name?: string,
                public alias?: string,
                public maskable?: boolean,
                public key?: string,
                public type?: string,
                public value?: string,
                public columns?: Array<QueryColumn>,
                public level?: number) {
    }
}
