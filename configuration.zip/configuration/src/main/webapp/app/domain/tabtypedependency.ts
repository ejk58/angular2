export class TabTypeDependency {

    constructor(public id: number,
                public dependency: string) {
    }
}
