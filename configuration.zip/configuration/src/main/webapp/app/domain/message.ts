export class Message {
    constructor(public severity: string,
                public summary: string,
                public detail: string) {
    }
}

