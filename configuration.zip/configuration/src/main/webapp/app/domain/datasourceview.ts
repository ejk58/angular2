export class DatasourceView {

    constructor(public viewName: string,
                public creator: string,
                public created: Date,
                public modified: Date,
                public createdStr: string,
                public modifiedStr: string) {

    }
}
