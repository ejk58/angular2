export class AttributeDefinition {

    constructor(public attrKey: string,
                public attrType: string,
                public attrDefault: string,
                public attrFixed: boolean) {
    }
}
