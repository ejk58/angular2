import { QueryColumn } from './querycolumn';
export class WidgetColumn {
    public id: number;
    public index: number;
    public type: string;
    public style: string;
    public level: number;
    public queryColumn: QueryColumn;
    public visible: boolean;
    public sortable: boolean;
    public summable: boolean;
    public comparable: boolean;
    public filterable: boolean;
    public columns: Array<WidgetColumn> = [];

}
