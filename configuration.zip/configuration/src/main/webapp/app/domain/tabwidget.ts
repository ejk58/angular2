export class TabWidget {

    constructor(public id: number,
                public gridColumns: number,
                public rowIndex: number,
                public columnIndex: number,
                public widgetId: number,
                public widgetDefinitionName: string) {
    }
}
