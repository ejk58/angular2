export class WidgetAttribute {

    constructor(public id: number,
                public widgetId: number,
                public key: string,
                public value: string) {
    }
}
