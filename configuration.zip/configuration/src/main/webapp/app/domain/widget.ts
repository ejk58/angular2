import {WidgetAttribute} from './widgetattribute';
import {WidgetType} from './widgettype';
import {WidgetColumn} from './widgetcolumn';


export class Widget {
    public id: number;
    public index: number;
    public name: string;
    public type: string;
    public title: string;
    public description: string;
    public descriptionMore: string;
    public visible: boolean;
    public refreshInfo: boolean;
    public queryId: number;
    public attributes: Array<WidgetAttribute> = [];
    public columns: Array<WidgetColumn> = [];
    public childWidgets: Array<Widget> = [];

    constructor(id: number, index: number, name: string, type: string, title: string, description: string, descriptionMore: string, visible: boolean, refreshInfo: boolean, queryId: number, attributes: Array<WidgetAttribute>) {
        this.id = id;
        this.index = index;
        this.name = name;
        this.type = type;
        this.title = title;
        this.description = description;
        this.descriptionMore = descriptionMore;
        this.visible = visible;
        this.refreshInfo = refreshInfo;
        this.queryId = queryId;
        this.attributes = attributes;
    }

    add(widgetAttribute: WidgetAttribute): void {
        this.attributes.push(widgetAttribute);
    }
}
