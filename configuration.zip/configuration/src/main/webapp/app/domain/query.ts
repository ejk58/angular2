import {QueryColumn} from './querycolumn';
import {QueryFilter} from './query-filter';
import {QueryAttribute} from './query-attribute';

export class Query {
    constructor(public id: number,
                public type: number,
                public viewName: string,
                public queryTemplate: string,
                public key: string,
                public dataSource: string,
                public queryColumns: Array<QueryColumn>,
                public queryFilters: Array<QueryFilter>,
                public queryAttributes: Array<QueryAttribute>) {
    }
}
