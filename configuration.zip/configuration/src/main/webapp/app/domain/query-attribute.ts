export class QueryAttribute {
    constructor(public id: number,
                public key: string,
                public value: string) {
    }
}
