export class TabDefinition {

    constructor(public id: number,
                public key: string,
                public title: string,
                public viewId: number,
                public queryId: number,
                public tabDefinitionDependencyGroupId: number) {
    }
}
