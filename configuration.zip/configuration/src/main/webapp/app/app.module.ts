import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CodemirrorModule} from 'ng2-codemirror';
import {AppComponent} from './app.component';
import {AppRoutingModule} from './app-routing.module';
import {ViewComponent} from './view/view.component';
import {TabComponent} from './tab/tab.component';
import {NewTabComponent} from './tab/new.tab/new.tab.component';
import {TabWidgetComponent} from './tab/tab.widget/tab.widget.component';
import {AddWidgetToTabComponent} from './tab/tab.widget/add.widget.to.tab/add.widget.to.tab.component';
import {WidgetAttributeComponent} from './widget/widget.attribute/widget.attribute.component';
import {WidgetComponent} from './widget/widget.component';
import {WidgetModifyComponent} from './widget/widget.modify/widget.modify.component';
import {WidgetCopyComponent} from './widget/widget.copy/widget.copy.component';
import {WidgetQueryComponent} from './widget/widget.query/widget.query.component';
import {WidgetOverviewComponent} from './widget/widget.overview/widget.overview.component';
import {DatasourceComponent} from './datasource/datasource.component';
import {ValidatorComponent} from './validator/validator.component';
import {ExporterComponent} from './exporter/exporter.component';
import {DbInfoComponent} from './db-info/db-info.component';
import {DataTableModule, ButtonModule, DialogModule, MessagesModule} from 'primeng/primeng';
import {TableModule} from 'primeng/table';
import {QueryComponent} from './query/query.component';
import {QueryInfoComponent} from './query/query.info/query.info.component';
import {QueryColumnsComponent} from './query/query.columns/query.columns.component';
import {HttpClientModule} from '@angular/common/http';

@NgModule({
    declarations: [
        AppComponent,
        ViewComponent,
        TabComponent,
        TabWidgetComponent,
        AddWidgetToTabComponent,
        NewTabComponent,
        WidgetComponent,
        WidgetAttributeComponent,
        WidgetModifyComponent,
        WidgetCopyComponent,
        WidgetQueryComponent,
        WidgetOverviewComponent,
        QueryComponent,
        QueryInfoComponent,
        QueryColumnsComponent,
        ExporterComponent,
        ValidatorComponent,
        DbInfoComponent,
        DatasourceComponent
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        CodemirrorModule,
        AppRoutingModule,
        DataTableModule,
        TableModule,
        ButtonModule,
        DialogModule,
        MessagesModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule {
}
