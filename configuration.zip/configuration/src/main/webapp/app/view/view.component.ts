import {Component, OnInit} from '@angular/core';
import {ViewService} from './view.service';

@Component({
    selector: 'view',
    templateUrl: './view.component.html',
    styleUrls: ['./view.component.scss', '../../_table.scss'],
    providers: [ViewService]
})
export class ViewComponent implements OnInit {
    public views: Object;

    constructor(private viewService: ViewService) {
    }

    ngOnInit() {
    }

    getViews() {
        this.viewService.getViews().subscribe(data =>
            this.views = data
        );
    }
}
