import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import {ServiceHttpClient} from '../serviceHttpClient';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class ViewService extends ServiceHttpClient {
    private apiUrl = 'api/views';

    constructor(protected http: HttpClient) {
        super(http);
    }

    getViews(): Observable<any> {
        return this.http.get(this.apiUrl);
    }
}
