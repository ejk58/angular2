import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import 'rxjs/add/operator/map';
import {ServiceHttpClient} from '../serviceHttpClient';

@Injectable()
export class ExporterService extends ServiceHttpClient {
    private apiUrl = 'api/export';

    constructor(public http: HttpClient) {
        super(http);
    }

    getSQLExport(): Observable<any> {
        return this.http.get(this.apiUrl);
    }

}
