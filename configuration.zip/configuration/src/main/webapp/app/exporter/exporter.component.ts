import {Component, OnInit} from '@angular/core';
import {ExporterService} from './exporter.service';
import 'codemirror/mode/sql/sql';

@Component({
    selector: 'export',
    templateUrl: './exporter.component.html',
    styleUrls: [
            './exporter.component.scss'
    ],
    providers: [ExporterService]
})
export class ExporterComponent implements OnInit {
    public content: String;
    public loading: Boolean;
    public codeMirrorConfig: Object;

    constructor(private exporterService: ExporterService) {
        this.codeMirrorConfig = {mode: 'text/x-sql', lineNumbers: true, }
    }

    ngOnInit() {
        this.loading = false;
    }

    getSQLExport() {
        this.loading = true;
        this.exporterService.getSQLExport().subscribe(data => {
            this.content = data.content;
            this.loading = false;
        });
    }
}
