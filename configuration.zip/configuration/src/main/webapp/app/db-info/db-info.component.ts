import {Component, OnInit} from '@angular/core';
import 'codemirror/mode/sql/sql';
import {DBInfoService} from './db-info.service';

@Component({
    selector: 'db-info',
    templateUrl: './db-info.component.html',
    styleUrls: [
        './db-info.component.scss'
    ],
    providers: [DBInfoService]
})
export class DbInfoComponent implements OnInit {
    public currentSchema: String;

    constructor(private dbInfoService: DBInfoService) {
    }

    ngOnInit() {
        this.dbInfoService.getCurrentSchema().subscribe(data => {
            this.currentSchema = data.currentSchema;
        });
    }
}

