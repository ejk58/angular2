import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import {HttpClient} from '@angular/common/http';
import {ServiceHttpClient} from '../serviceHttpClient';

@Injectable()
export class DBInfoService extends ServiceHttpClient {
    private apiUrl = '/api/system/current-schema';

    constructor(public http: HttpClient) {
        super(http);
    }

    getCurrentSchema(): Observable<any> {
        return this.http.get(this.apiUrl);
    }
}
