import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ViewComponent} from './view/view.component';
import {TabComponent} from './tab/tab.component';
import {WidgetComponent} from './widget/widget.component';
import {ExporterComponent} from './exporter/exporter.component';
import {ValidatorComponent} from './validator/validator.component';
import {WidgetOverviewComponent} from './widget/widget.overview/widget.overview.component';
import {DatasourceComponent} from './datasource/datasource.component';
import {QueryComponent} from './query/query.component';

const routes: Routes = [
    {path: 'view', component: ViewComponent},
    {path: 'tab', component: TabComponent},
    {path: 'widget', component: WidgetComponent},
    {path: 'query', component: QueryComponent},
    {path: 'export', component: ExporterComponent},
    {path: 'validator', component: ValidatorComponent},
    {path: 'datasource', component: DatasourceComponent},
    {path: 'tmp', component: WidgetOverviewComponent},
    {path: '', redirectTo: '/view', pathMatch: 'full'},
    {path: '**', redirectTo: '/view'}
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: []
})
export class AppRoutingModule {
}

