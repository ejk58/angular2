import {Component, OnInit} from '@angular/core';
import {ValidatorService} from './validator.service';

@Component({
    selector: 'validate',
    templateUrl: './validator.component.html',
    styleUrls: [
        './validator.component.scss'
    ],
    providers: [ValidatorService]
})
export class ValidatorComponent implements OnInit {
    public content: Array<String>;
    public loading: Boolean;

    constructor(private validatorService: ValidatorService) {
    }

    ngOnInit() {
        this.loading = false;
    }

    getValidate() {
        this.loading = true;
        this.validatorService.getValidate().subscribe(data => {
            this.content = data;
            this.loading = false;
        });
    }

}
