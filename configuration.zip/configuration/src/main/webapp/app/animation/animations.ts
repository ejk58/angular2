import {style, animate, transition, trigger} from '@angular/animations';

export const fade = trigger(
    'fadeAnimation',
    [
        transition(
            ':enter', [
                style({opacity: 0}),
                animate('1000ms', style({'opacity': 1}))
            ]
        ),
        transition(
            ':leave', [
                style({'opacity': 1}),
                animate('500ms', style({'opacity': 0}))
            ]
        )]
);
