node {
    try {
        checkout scm

        properties([
                parameters([
                        choice(name: 'run_it_test', choices: 'NO\nYES', description: 'Run the integration tests?')
                ]),
                disableConcurrentBuilds(),
                pipelineTriggers([pollSCM('')])
        ])

        stage('Build') {
            sh "mvn clean install"
        }

        stage('Deploy') {
            def packagePath = sh(returnStdout: true, script: "find target/ -name *.jar").trim()
            echo "Publish ${JOB_NAME} ${packagePath}"
            sh "sshpass -p ci scp -o StrictHostKeyChecking=no ${packagePath} ci@ivac.ont.belastingdienst.nl:/mnt/data/home/ci"

            sh "sshpass -p ci ssh -o StrictHostKeyChecking=no ci@ivac.ont.belastingdienst.nl 'cd ~; sh stop.sh || true'"
            sh "sshpass -p ci ssh -o StrictHostKeyChecking=no ci@ivac.ont.belastingdienst.nl 'cd ~; sh start.sh || true'"
        }


        stage('Integration') {
            if (run_it_test ==~ /(?i)(Y|YES|T|TRUE|ON|RUN)/) {
                //TODO
            } else {
                echo "'run_it_test' set to false >> Robot tests skipped."
            }
        }

        stage('Sonar') {
            sonarQuality()
        }

        currentBuild.result = 'SUCCESS'
    } catch (any) {
        currentBuild.result = 'FAILURE'
        throw any
    } finally {
        if (run_it_test ==~ /(?i)(Y|YES|T|TRUE|ON|RUN)/) {
            robotLogPublication()
            emailNotification()
        }
    }
}