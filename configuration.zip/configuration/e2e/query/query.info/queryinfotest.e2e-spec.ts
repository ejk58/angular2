import { browser, by, element } from 'protractor';

describe('Query info component check', function () {

    beforeEach(function () {
        browser.get('http://localhost:4200/query');
        element(by.xpath('//label[@for="query-info-toggle"]')).click();
        browser.driver.sleep(1000).then(function () {
            element(by.id('queriesdropdown')).element(by.cssContainingText('option', 'DI_OB_INVOER_QUERY')).click();
        });
    });


    it('Type en datasource kloppen', function () {
        expect(element(by.id('querytype')).getText()).toMatch('TERADATA');
        expect(element(by.id('datasource')).getText()).toMatch('Teradata/IVAI');
    });


});