import {browser, by, element} from 'protractor';

function sleep() {
    browser.driver.sleep(1500); // sleep for demonstration reasons
}

describe('Bla Bla describing', function () {
    beforeEach(() =>
    {
        browser.get('https://www.angularjs.org');
        sleep();
    });

    it('Should work' , () => {
        element(by.model('yourName')).sendKeys('pietje');
        sleep();
        sleep();
    });
});