import { browser, by, element } from 'protractor';

describe('Widget component check', function () {

  beforeEach(function() {
    browser.get('http://localhost:4200/widget');
  });


    it('De titels van de tabbladen kloppen', function () {
        // We checken de teksten van elementen
        let modifytabs = element(by.xpath('.//*[text()="Overzicht widgets"]'));
        expect(modifytabs.isPresent()).toBeTruthy();
        modifytabs = element(by.xpath('.//*[text()="Widget aanpassen"]'));
        expect(modifytabs.isPresent()).toBeTruthy();
        modifytabs = element(by.xpath('.//*[text()="Widget attributen aanpassen"]'));
        expect(modifytabs.isPresent()).toBeTruthy();
        modifytabs = element(by.xpath('.//*[text()="Widget kopiëren"]'));
        expect(modifytabs.isPresent()).toBeTruthy();
        modifytabs = element(by.xpath('.//*[text()="Widget raadplegen"]'));
        expect(modifytabs.isPresent()).toBeTruthy();
    });

    it('Het aantal tabbladen klopt', function () {
        // tellen
        const aantalTabs = element.all(by.xpath('.//*[@class = "accordion"]'));

        // checken via exacte match
        expect(aantalTabs.count()).toMatch('5');

        // checken via vergelijking
        expect(aantalTabs.count()).toBeLessThan(6);
    });


});