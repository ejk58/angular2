import { browser, by, element } from 'protractor';

describe('Widget component attribute check', function () {

    beforeEach(function () {
        browser.get('http://localhost:4200/widget');
        element(by.xpath('//label[@for="widget-attribute-toggle"]')).click();
        browser.driver.sleep(1000).then(function () {
            element(by.id('widgetsdropdown_widgetattributes')).element(by.cssContainingText('option', 'Aangegeven (ZORGKOSTEN_A)')).click();
        });
    });


    it('Het type widget klopt', function () {
        expect(element(by.id('widget_type')).getText()).toMatch('TableCollapsible');
    });

    it('Er zijn geen attributen', function () {
        const attributen = element(by.xpath('.//*[text()="Er zijn geen attributen voor dit widget."]'));
        expect(attributen.isPresent()).toBeTruthy();
    });

    it('Er wordt een attribuut toegevoegd', function () {
        element(by.id('add_attribute_button')).click();
        element(by.cssContainingText('option', 'ktaLinkWidget')).click();

        const buttonDisabled = element(by.xpath('.//*[@class = "button buttondisabled"][text()="Opslaan"]'));
        expect(buttonDisabled.isPresent()).toBeFalsy();

        element(by.xpath('.//*[text()="Opslaan"]')).click().then(function () {
            expect(element(by.id('verwijder_attibute_0')).isPresent()).toBeTruthy();
            expect(element(by.xpath('.//*[text()="ktaLinkWidget"]')).isPresent()).toBeTruthy();
        });

    });

    it('Het zojuist toegevoegde attribuut wordt verwijderd', function () {
        // element(by.id('verwijder_attibute_0')).getText().then(console.log);
        expect(element(by.id('verwijder_attibute_0'))).toBeTruthy();
        element(by.id('verwijder_attibute_0')).click().then(function () {
            expect(element(by.id('verwijder_attibute_0')).isPresent()).toBeFalsy();
        });

    });

    it('Bij annuleren wordt niets opgeslagen', function () {
        element(by.id('add_attribute_button')).click();
        element(by.cssContainingText('option', 'maxScreenRows')).click();

        // pre condition
        expect(element(by.id('verwijder_attibute_0')).isPresent()).toBeFalsy();
        expect(element(by.xpath('.//*[@class = "button cancel-button"][text()="Annuleren"]')).isDisplayed()).toBeTruthy();

        element(by.xpath('.//*[@class = "button cancel-button"][text()="Annuleren"]')).click().then(function() {
            // post condition
            expect(element(by.id('verwijder_attibute_0')).isPresent()).toBeFalsy();
            expect(element(by.xpath('.//*[@class = "button cancel-button"][text()="Annuleren"]')).isDisplayed()).toBeFalsy();
        });
    });

});
