# Inzicht Configuration

Following bullets but be done first to be able to run the application:

* Node or NPM should not be on the path
* There should no global node modules on your path
* Make sure you don't have a global .npmrc file in your home dir. You can check this with npm config list (after `mvn clean install`)
* SASS-BINARY should not be set as env var
* Maven should be version 3.3.9 or higher
* Mirror Settings for Maven (otherwise the local repo doesn't work):

````
<mirrors>
  <mirror>
    <id>central</id>
    <mirrorOf>*,!project.local</mirrorOf>
    <url>http://iva-nexus.belastingdienst.nl/repository/maven-public</url>
   </mirror>
</mirrors>
````

This project will build with:

`mvn clean install`

To start the Spring-Boot backend you can run commando:

`mvn spring-boot:run`

Starting front-end development with (back-end should be deployed on localhost:8080):

`npm start`

Look in **package.json** for more useful commando's

#### Execute NG commands

To execute NG-cli commando's you can run the following commands:

``npm run ng [-- <args>]``

e.g.:

`npm run ng -- v`

`npm run ng -- doc test`

#### Run artifact
The jar artifact is an executable jar

`java -jar <jar-name>`

e.g.:

`java -jar inzicht-configuratie-0.0.1-SNAPSHOT.jar`



