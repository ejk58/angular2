DELETE FROM ivab02.configuration;

INSERT INTO ivab02.configuration("key", "value") VALUES ('noOfDaysFileIsAvailable', '1');
INSERT INTO ivab02.configuration("key", "value") VALUES ('maxFileSizeMb', '500');