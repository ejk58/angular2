package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.DatasourceBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.DomainBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.Query;
import nl.belastingdienst.iva.wd.configurator.domain.QueryBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.QueryColumn;
import nl.belastingdienst.iva.wd.configurator.domain.QueryColumnBuilder;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class QuerySqlFactoryTest {

    private QuerySqlFactory querySqlFactory;

    public QuerySqlFactoryTest() {
        this.querySqlFactory = new QuerySqlFactory();
    }

    @Test
    public void testQuerySqlFactoryForInsertScriptWithACorrectQueryWithoutNestedColumns() {
        List<QueryColumn> queryColumns = new ArrayList<>();
        queryColumns.add(QueryColumnBuilder.build(1, "COLUMN_ID", "columnId", null, null, "NUMBER", false, null));
        queryColumns.add(QueryColumnBuilder.build(2, "COLUMN_TYPE", null, null, "columnType", "STRING", false, null));
        queryColumns.add(QueryColumnBuilder.build(3, "COLUMN_NAME", null, null, null, "STRING", false, null));
        queryColumns.add(QueryColumnBuilder.build(4, null, null, "Fixed Value", "columnValue", "STRING", false, null));
        
        Query query = new QueryBuilder()
        		.withDatasource(DatasourceBuilder.build("TEST_DATASOURCE"))
        		.withKey("TEST_QUERY")
        		.withType(1)
        		.withViewname("TEST_TABLE")
        		.withQuerytemplate("SELECT {resultColumns} FROM {viewname} WHERE EVERYBODY = HAPPY;")
        		.withQueryColumns(queryColumns)
        		.withOwnerDomain(DomainBuilder.build("TEST_DOMAIN", "Nuclear Test Area"))
        		.build();

        String result = this.querySqlFactory.getInsertScript(query);

        Assert.assertTrue(result.startsWith("-- Query TEST_QUERY"));
        Assert.assertTrue(result.contains("('TEST_QUERY', 1, (SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'TEST_DATASOURCE'), 'TEST_TABLE', 'SELECT {resultColumns} FROM {viewname} WHERE EVERYBODY = HAPPY;', (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'TEST_DOMAIN'))"));
        Assert.assertEquals(4, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_QUERY_COLUMN\""));
    }
}
