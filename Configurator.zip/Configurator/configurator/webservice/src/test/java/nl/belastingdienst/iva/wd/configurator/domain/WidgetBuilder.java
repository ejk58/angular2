package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.ArrayList;
import java.util.List;

public class WidgetBuilder {

	private Widget widget;
	
	public WidgetBuilder() {
		this.widget = new Widget();
		this.widget.setColumnList(new ArrayList<>());
		this.widget.setAttributeList(new ArrayList<>());
		this.widget.setHelpList(new ArrayList<>());
	}
	
	public Widget build() {
		return this.widget;
	}

	public WidgetBuilder withName(String name) {
		this.widget.setName(name);
		return this;
	}

	public WidgetBuilder withIndex(Integer index) {
		this.widget.setIndex(index);
		return this;
	}

	public WidgetBuilder withType(String type) {
		this.widget.setType(type);
		return this;
	}

	public WidgetBuilder withTitle(String title) {
		this.widget.setTitle(title);
		return this;
	}

	public WidgetBuilder withDescription(String description) {
		this.widget.setDescription(description);
		return this;
	}

	public WidgetBuilder withRefreshinfo(boolean refreshinfo) {
		this.widget.setRefreshinfo(refreshinfo);
		return this;
	}

	public WidgetBuilder withVisible(boolean visible) {
		this.widget.setVisible(visible);
		return this;
	}

	public WidgetBuilder withQuery(Query query) {
		this.widget.setQuery(query);
		return this;
	}

	public WidgetBuilder withRuleGroup(RuleGroup ruleGroup) {
		this.widget.setRuleGroup(ruleGroup);
		return this;
	}

	public WidgetBuilder withWidgetColumns(List<WidgetColumn> widgetColumns) {
		this.widget.setColumnList(widgetColumns);
		return this;
	}

	public WidgetBuilder withWidgetAttributes(List<WidgetAttribute> widgetAttributes) {
		this.widget.setAttributeList(widgetAttributes);
		return this;
	}

	public WidgetBuilder withWidgetHelps(List<WidgetHelp> widgetHelps) {
		this.widget.setHelpList(widgetHelps);
		return this;
	}

	public WidgetBuilder withContainerWidget(Widget containerWidget) {
		this.widget.setContainerWidget(containerWidget);
		return this;
	}

	public WidgetBuilder withOwnerDomain(Domain ownerDomain) {
		this.widget.setOwnerDomain(ownerDomain);
		return this;
	}
}
