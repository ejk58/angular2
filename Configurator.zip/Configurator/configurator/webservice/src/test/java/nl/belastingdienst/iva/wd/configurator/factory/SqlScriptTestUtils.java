package nl.belastingdienst.iva.wd.configurator.factory;

public final class SqlScriptTestUtils {
	
	private SqlScriptTestUtils() {
		throw new UnsupportedOperationException();
	}

	public static int countOccurences(String string, String substring) {
		int count = 0;
		int index = 0;
		
		while (index >= 0) {
			index = string.indexOf(substring, index);
			if (index >= 0) {
				count++;
				index++;
			}
		}
		
		return count;
	}
}
