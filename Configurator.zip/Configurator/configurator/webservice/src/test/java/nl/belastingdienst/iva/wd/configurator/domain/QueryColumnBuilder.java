package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.ArrayList;
import java.util.List;

public class QueryColumnBuilder {

	private QueryColumn queryColumn;
	
	public QueryColumnBuilder() {
		this.queryColumn = new QueryColumn();
		this.queryColumn.setColumnList(new ArrayList<>());
	}
	
	public QueryColumn build() {
		return this.queryColumn;
	}
	
	public QueryColumnBuilder withIdex(Integer index) {
		this.queryColumn.setIndex(index);
		return this;
	}

	public QueryColumnBuilder withName(String name) {
		this.queryColumn.setName(name);
		return this;
	}

	public QueryColumnBuilder withAlias(String alias) {
		this.queryColumn.setAlias(alias);
		return this;
	}

	public QueryColumnBuilder withValue(String value) {
		this.queryColumn.setValue(value);
		return this;
	}

	public QueryColumnBuilder withKey(String key) {
		this.queryColumn.setKey(key);
		return this;
	}

	public QueryColumnBuilder withType(String type) {
		this.queryColumn.setType(type);
		return this;
	}

	public QueryColumnBuilder withMaskable(boolean maskable) {
		this.queryColumn.setMaskable(maskable);
		return this;
	}

	public QueryColumnBuilder withInnerColumns(List<QueryColumn> innerColumns) {
		this.queryColumn.setColumnList(innerColumns);
		return this;
	}

	public QueryColumnBuilder withInnerColumn(QueryColumn innerColumn) {
		List<QueryColumn> innerColumns = this.queryColumn.getColumnList();
		innerColumns.add(innerColumn);
		return this;
	}
	
	public static QueryColumn build(Integer index, String name, String alias, String value, String key, String type, 
    		boolean maskable, List<QueryColumn> innerQueryColumns) {
	
		return new QueryColumnBuilder()
				.withIdex(index)
				.withName(name)
				.withAlias(alias)
				.withValue(value)
				.withKey(key)
				.withType(type)
				.withMaskable(maskable)
				.withInnerColumns(innerQueryColumns == null ? new ArrayList<>() : innerQueryColumns)
				.build();
	}
}
