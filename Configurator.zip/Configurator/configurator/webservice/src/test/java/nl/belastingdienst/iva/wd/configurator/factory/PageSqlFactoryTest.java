package nl.belastingdienst.iva.wd.configurator.factory;

import java.util.Collections;

import org.junit.Assert;
import org.junit.Test;

import nl.belastingdienst.iva.wd.configurator.domain.DomainBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.Page;
import nl.belastingdienst.iva.wd.configurator.domain.PageBuilder;

public class PageSqlFactoryTest {

	private PageSqlFactory pageSqlFactory;
	
	public PageSqlFactoryTest() {
		this.pageSqlFactory = new PageSqlFactory();
	}
	
	@Test
	public void testPageSqlFactoryForInsertScriptWithSimplePage() {
		Page page = new PageBuilder()
				.withKey("new-page")
				.withTitle("Nieuwe pagina")
				.withType("main")
				.withOwnerDomain(DomainBuilder.build("owner-key", "Eigenaar"))
				.build();
		
		String result = this.pageSqlFactory.getInsertScript(page, Collections.emptyList());
		
		Assert.assertTrue(result.startsWith("-- Page new-page"));
		Assert.assertTrue(result.contains("('new-page', 'Nieuwe pagina', null, 'main', (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'owner-key'))"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_PAGE\""));
	}
}
