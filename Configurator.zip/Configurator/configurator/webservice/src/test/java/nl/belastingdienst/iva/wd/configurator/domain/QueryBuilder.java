package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.ArrayList;
import java.util.List;

public class QueryBuilder {

	private Query query;
	
	public QueryBuilder() {
		this.query = new Query();
		this.query.setColumnList(new ArrayList<>());
	}
	
	public Query build() {
		return this.query;
	}
	
	public QueryBuilder withType(Integer type) {
		this.query.setType(type);
		return this;
	}

	public QueryBuilder withKey(String key) {
		this.query.setKey(key);
		return this;
	}

	public QueryBuilder withViewname(String viewname) {
		this.query.setViewname(viewname);
		return this;
	}

	public QueryBuilder withQuerytemplate(String querytemplate) {
		this.query.setQuerytemplate(querytemplate);
		return this;
	}

	public QueryBuilder withDatasource(Datasource datasource) {
		this.query.setDatasource(datasource);
		return this;
	}

	public QueryBuilder withQueryColumns(List<QueryColumn> queryColumns) {
		this.query.setColumnList(queryColumns);
		return this;
	}
	
	public QueryBuilder withQueryColumn(QueryColumn queryColumn) {
		List<QueryColumn> queryColumns = this.query.getColumnList();
		queryColumns.add(queryColumn);
		return this;
	}
	
	public QueryBuilder withOwnerDomain(Domain ownerDomain) {
		this.query.setOwnerDomain(ownerDomain);
		return this;
	}
}
