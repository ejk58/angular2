package nl.belastingdienst.iva.wd.configurator.domain;

public class DomainBuilder {

	private Domain domain;
	
	public DomainBuilder() {
		this.domain = new Domain();
	}
	
	public Domain build() {
		return this.domain;
	}
	
	public DomainBuilder withKey(String key) {
		this.domain.setKey(key);
		return this;
	}

	public DomainBuilder withName(String name) {
		this.domain.setName(name);
		return this;
	}
	
	public static Domain build(String key, String name) {
		return new DomainBuilder()
				.withKey(key)
				.withName(name)
				.build();
	}
}
