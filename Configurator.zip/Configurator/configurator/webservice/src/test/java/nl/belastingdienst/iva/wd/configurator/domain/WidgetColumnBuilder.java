package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.ArrayList;
import java.util.List;

public class WidgetColumnBuilder {

	private WidgetColumn queryColumn;
	
	public WidgetColumnBuilder() {
		this.queryColumn = new WidgetColumn();
		this.queryColumn.setColumnAttributeList(new ArrayList<>());
	}
	
	public WidgetColumn build() {
		return this.queryColumn;
	}
	
	public WidgetColumnBuilder withIdex(Integer index) {
		this.queryColumn.setIndex(index);
		return this;
	}

	public WidgetColumnBuilder withType(String type) {
		this.queryColumn.setType(type);
		return this;
	}

	public WidgetColumnBuilder withLabel(String label) {
		this.queryColumn.setLabel(label);
		return this;
	}

	public WidgetColumnBuilder withDescription(String description) {
		this.queryColumn.setDescription(description);
		return this;
	}

	public WidgetColumnBuilder withBehaviour(String behaviour) {
		this.queryColumn.setBehaviour(behaviour);
		return this;
	}

	public WidgetColumnBuilder withFilter(String filter) {
		this.queryColumn.setFilter(filter);
		return this;
	}

	public WidgetColumnBuilder withQueryColumn(QueryColumn queryColumn) {
		this.queryColumn.setQueryColumn(queryColumn);
		return this;
	}

	public WidgetColumnBuilder withWidgetColumnAttributes(List<WidgetColumnAttribute> widgetColumnAttributes) {
		this.queryColumn.setColumnAttributeList(widgetColumnAttributes);
		return this;
	}

	public static WidgetColumn build(Integer index, String type, String label, String description, String behaviour, String filter, 
    		QueryColumn queryColumn, List<WidgetColumnAttribute> widgetColumnAttributes) {
	
		return new WidgetColumnBuilder()
				.withIdex(index)
				.withType(type)
				.withLabel(label)
				.withDescription(description)
				.withBehaviour(behaviour)
				.withFilter(filter)
				.withQueryColumn(queryColumn)
				.withWidgetColumnAttributes(widgetColumnAttributes == null ? new ArrayList<>() : widgetColumnAttributes)
				.build();
	}
}
