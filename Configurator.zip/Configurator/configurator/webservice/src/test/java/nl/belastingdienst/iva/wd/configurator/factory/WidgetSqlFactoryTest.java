package nl.belastingdienst.iva.wd.configurator.factory;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.Assert;

import nl.belastingdienst.iva.wd.configurator.domain.QueryBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.QueryColumn;
import nl.belastingdienst.iva.wd.configurator.domain.QueryColumnBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.domain.WidgetBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.WidgetColumn;
import nl.belastingdienst.iva.wd.configurator.domain.WidgetColumnBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.DatasourceBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.Domain;
import nl.belastingdienst.iva.wd.configurator.domain.DomainBuilder;
import nl.belastingdienst.iva.wd.configurator.domain.Query;

public class WidgetSqlFactoryTest {
	
	private WidgetSqlFactory widgetSqlFactory;
	
	public WidgetSqlFactoryTest() {
		QuerySqlFactory querySqlFactory = new QuerySqlFactory();
		this.widgetSqlFactory = new WidgetSqlFactory(querySqlFactory);
	}
	
	@Test
	public void testWidgetSqlFactoryForInsertScriptWithAWidgetWithoutAnything() {
		Widget widget = buildWidgetWithoutAnything();
		String result = this.widgetSqlFactory.getInsertScript(widget);
		
		Assert.assertTrue(result.startsWith("-- Widget HAPPY_WIDGET"));
		Assert.assertTrue(result.contains("(null, null, 1, 'HAPPY_WIDGET_CONTAINER', null, 'Een groepje blije widgets', 'Deze widgets zijn heel blij.', 0, 0, (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'happy-key'))"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_WIDGET\""));
	}
	
	@Test
	public void testWidgetSqlFactoryForInsertScriptWithAWidgetAndQuery() {
		Widget widget = buildWidgetWithQuery();
		String result = this.widgetSqlFactory.getInsertScript(widget);
		
		Assert.assertTrue(result.startsWith("-- Query SAD_QUERY"));
		Assert.assertTrue(result.contains("('SAD_QUERY', 1, (SELECT ID FROM CONF_DATASOURCE WHERE KEY = 'HAPPY_SOURCE'), 'THE_BEST_VIEW', 'SELECT {resultColumns} FROM {viewname} WHERE EVERYTHING = GREAT', (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'sad-key'))"));
		Assert.assertTrue(result.contains("-- Widget SAD_WIDGET"));
		Assert.assertTrue(result.contains("((SELECT ID FROM CONF_QUERY WHERE KEY = 'SAD_QUERY'), null, 1, 'SAD_WIDGET', 'Table', 'Een treurige widget', 'Deze widget is niet blij.', 0, 0, (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'sad-key'))"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_QUERY\""));
        Assert.assertEquals(4, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_QUERY_COLUMN\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_WIDGET\""));
        Assert.assertEquals(4, SqlScriptTestUtils.countOccurences(result, "INSERT INTO \"CONF_WIDGET_COLUMN\""));
	}
	
	@Test
	public void testWidgetSqlFactoryForDeleteScriptWithWidgetWithoutAnything() {
		Widget widget = buildWidgetWithoutAnything();
		String result = this.widgetSqlFactory.getDeleteScript(widget);
		
		Assert.assertTrue(result.startsWith("-- Widget HAPPY_WIDGET"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_COLUMN\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_HELP\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_ATTRIBUTE\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET\""));
	}
	
	@Test
	public void testWidgetSqlFactoryForUpdateScriptWithAWidgetWithoutAnything() {
		Widget widget = buildWidgetWithoutAnything();
		String result = this.widgetSqlFactory.getUpdateScript(widget);
		
		Assert.assertTrue(result.startsWith("-- Widget HAPPY_WIDGET"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_COLUMN\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_HELP\""));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "DELETE FROM \"CONF_WIDGET_ATTRIBUTE\""));
		Assert.assertTrue(result.contains("(null, null, 1, 'HAPPY_WIDGET_CONTAINER', null, 'Een groepje blije widgets', 'Deze widgets zijn heel blij.', 0, 0, (SELECT ID FROM CONF_DOMAIN WHERE KEY = 'happy-key'))"));
        Assert.assertEquals(1, SqlScriptTestUtils.countOccurences(result, "MERGE INTO \"CONF_WIDGET\""));
	}
	
	
	
	
	
	
	
	private Widget buildWidgetWithoutAnything() {
		Domain ownerDomain = DomainBuilder.build("happy-key", "Blij Klantbeeld");
		
		return new WidgetBuilder()
				.withName("HAPPY_WIDGET_CONTAINER")
				.withTitle("Een groepje blije widgets")
				.withDescription("Deze widgets zijn heel blij.")
				.withIndex(1)
				.withOwnerDomain(ownerDomain)
				.build();
	}

	private Widget buildWidgetWithQuery() {
		List<QueryColumn> queryColumns = new ArrayList<>();
		queryColumns.add(QueryColumnBuilder.build(1, "COLUMN_ID", "columnId", null, null, "NUMBER", false, null));
		queryColumns.add(QueryColumnBuilder.build(2, "COLUMN_TYPE", null, null, "columnType", "STRING", false, null));
		queryColumns.add(QueryColumnBuilder.build(3, "COLUMN_NAME", null, null, null, "STRING", false, null));
		queryColumns.add(QueryColumnBuilder.build(4, null, null, "Fixed Value", "columnValue", "STRING", false, null));

		List<WidgetColumn> widgetColumns = new ArrayList<>();
		widgetColumns.add(WidgetColumnBuilder.build(1, "NUMBER", "Id", null, "visible", null, queryColumns.get(0), null));
		widgetColumns.add(WidgetColumnBuilder.build(2, "STRING", "Type", null, "visible", "text", queryColumns.get(1), null));
		widgetColumns.add(WidgetColumnBuilder.build(3, "STRING", "Naam", null, "visible", "text", queryColumns.get(2), null));
		widgetColumns.add(WidgetColumnBuilder.build(4, "STRING", "Waarde", "Deze waarde is constant", "visible", null, queryColumns.get(3), null));
		
		Domain ownerDomain = DomainBuilder.build("sad-key", "Treurig Klantbeeld");
		
		Query query = new QueryBuilder()
				.withDatasource(DatasourceBuilder.build("HAPPY_SOURCE"))
				.withKey("SAD_QUERY")
				.withType(1)
				.withViewname("THE_BEST_VIEW")
				.withQuerytemplate("SELECT {resultColumns} FROM {viewname} WHERE EVERYTHING = GREAT")
				.withOwnerDomain(ownerDomain)
				.withQueryColumns(queryColumns)
				.build();

		return new WidgetBuilder()
				.withName("SAD_WIDGET")
				.withType("Table")
				.withTitle("Een treurige widget")
				.withDescription("Deze widget is niet blij.")
				.withIndex(1)
				.withQuery(query)
				.withWidgetColumns(widgetColumns)
				.withOwnerDomain(ownerDomain)
				.build();
	}
}
