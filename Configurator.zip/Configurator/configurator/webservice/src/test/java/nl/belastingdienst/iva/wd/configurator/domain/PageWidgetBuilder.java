package nl.belastingdienst.iva.wd.configurator.domain;

public class PageWidgetBuilder {

	private PageWidget pageWidget;
	
	public PageWidgetBuilder() {
		this.pageWidget = new PageWidget();
	}
	
	public PageWidget build() {
		return this.pageWidget;
	}
	
	public PageWidgetBuilder withPage(Page page) {
		this.pageWidget.setPage(page);
		return this;
	}

	public PageWidgetBuilder withWidget(Widget widget) {
		this.pageWidget.setWidget(widget);
		return this;
	}

	public PageWidgetBuilder withGridColumns(Integer gridColumns) {
		this.pageWidget.setGridColumns(gridColumns);
		return this;
	}

	public PageWidgetBuilder withRowIndex(Integer rowIndex) {
		this.pageWidget.setRowIndex(rowIndex);
		return this;
	}

	public PageWidgetBuilder withColumnIndex(Integer columnIndex) {
		this.pageWidget.setColumnIndex(columnIndex);
		return this;
	}
}
