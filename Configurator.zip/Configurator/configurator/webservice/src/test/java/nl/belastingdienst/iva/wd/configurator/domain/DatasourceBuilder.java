package nl.belastingdienst.iva.wd.configurator.domain;

public class DatasourceBuilder {

	private Datasource datasource;
	
	public DatasourceBuilder() {
		this.datasource = new Datasource();
	}
	
	public Datasource build() {
		return this.datasource;
	}
	
	public DatasourceBuilder withKey(String key) {
		this.datasource.setKey(key);
		return this;
	}
	
	public static Datasource build(String key) {
		return new DatasourceBuilder()
				.withKey(key)
				.build();
	}
}
