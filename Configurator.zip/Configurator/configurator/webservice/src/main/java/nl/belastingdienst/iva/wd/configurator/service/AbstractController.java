package nl.belastingdienst.iva.wd.configurator.service;

import nl.belastingdienst.iva.wd.configurator.datasource.configurator.ConfiguratorChangeRepository;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.sql.SQLException;

public abstract class AbstractController {

    @Autowired
    ConfiguratorChangeRepository configuratorChangeRepository;

    ResponseEntity<String> handleRolloutChangeOnSourceDatabase(Change change) throws SQLException {
        configuratorChangeRepository.rolloutChangeOnSourceDatabase(change);
        return ResponseEntity.ok(ResponseMessages.CHANGE_ROLLOUT_OK);
    }
}
