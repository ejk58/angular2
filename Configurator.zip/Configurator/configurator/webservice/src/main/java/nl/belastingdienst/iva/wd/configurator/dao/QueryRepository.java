package nl.belastingdienst.iva.wd.configurator.dao;

import nl.belastingdienst.iva.wd.configurator.domain.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QueryRepository extends CrudRepository<Query, Integer> {
    Query findByKey(String key);

    @org.springframework.data.jpa.repository.Query("SELECT DISTINCT query.key FROM Query query ORDER BY query.key ASC")
    List<String> findAllQueryKeysOrderByNameAsc();
}
