package nl.belastingdienst.iva.wd.configurator.factory;

import java.util.List;

import org.springframework.stereotype.Component;

import nl.belastingdienst.iva.wd.configurator.domain.Domain;
import nl.belastingdienst.iva.wd.configurator.domain.Page;
import nl.belastingdienst.iva.wd.configurator.domain.PageWidget;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.util.ExportUtils;

@Component
public class PageSqlFactory {

    private static final String NEWLINE = "\n";
    
    public String getInsertScript(Page page, List<PageWidget> pageWidgets) {
    	String pageKey = page.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        sqlBuilder.append(getMergeScriptForPage(page));
        sqlBuilder.append(getInsertScriptForPageProperties(page, pageWidgets));

        return sqlBuilder.toString();
    }
    
    public String getUpdateScript(Page page, List<PageWidget> pageWidgets) {
    	String pageKey = page.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        sqlBuilder.append(getDeleteScriptForPageProperties(pageKey));
        sqlBuilder.append(getMergeScriptForPage(page));
        sqlBuilder.append(getInsertScriptForPageProperties(page, pageWidgets));

        return sqlBuilder.toString();
    }

    public String getUpdateScript(String pageKey, List<PageWidget> pageWidgets) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        sqlBuilder.append(getDeleteScriptForPageWidgets(pageKey));
        sqlBuilder.append(getInsertScriptForPageWidgets(pageKey, pageWidgets));

        return sqlBuilder.toString();
    }
    
    public String getDeleteScript(Page page) {
    	String pageKey = page.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForPage(pageKey));
        sqlBuilder.append(getDeleteScriptForPageProperties(pageKey));
        sqlBuilder.append(getDeleteScriptForPage(pageKey));

        return sqlBuilder.toString();
    }
    
    private String getPrefixScriptForPage(String pageKey) {
        return "-- Page " + pageKey + NEWLINE;
    }

    private String getMergeScriptForPage(Page page) {
        Domain ownerDomain = page.getOwnerDomain();
        String ownerDomainKey = ownerDomain == null ? null : ownerDomain.getKey();
    	StringBuilder sqlBuilder = new StringBuilder();
    	
    	sqlBuilder.append("MERGE INTO \"CONF_PAGE\" AS P USING (VALUES (");
    	sqlBuilder.append(ExportUtils.getString(page.getKey()) + ", ");
    	sqlBuilder.append(ExportUtils.getString(page.getTitle()) + ", ");
    	sqlBuilder.append("null, ");
    	sqlBuilder.append(ExportUtils.getString(page.getType()) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_DOMAIN", "KEY", ownerDomainKey));
    	sqlBuilder.append(")) AS X(KEY, TITLE, QUERY_ID, TYPE, OWNER_DOMAIN_ID) ON P.KEY = X.KEY" + NEWLINE);
    	sqlBuilder.append("  WHEN MATCHED THEN UPDATE SET TITLE = X.TITLE, QUERY_ID = X.QUERY_ID, TYPE = X.TYPE, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID" + NEWLINE);
    	sqlBuilder.append("  WHEN NOT MATCHED THEN INSERT (KEY, TITLE, QUERY_ID, TYPE, OWNER_DOMAIN_ID) VALUES (X.KEY, X.TITLE, X.QUERY_ID, X.TYPE, X.OWNER_DOMAIN_ID);" + NEWLINE);
    	
    	return sqlBuilder.toString();
    }

    private String getDeleteScriptForPage(String pageKey) {
        return "DELETE FROM \"CONF_PAGE\" WHERE KEY = '" + pageKey + "';" + NEWLINE;
    }
    
    private String getInsertScriptForPageProperties(Page page, List<PageWidget> pageWidgets) {
    	String pageKey = page.getKey();
    	StringBuilder sqlBuilder = new StringBuilder();
    	
    	sqlBuilder.append(getInsertScriptForPageWidgets(pageKey, pageWidgets));
    	
    	// TODO PageDomain
    	
    	// TODO PagePathKey
    	
    	// TODO PageAttribute
    	
    	// TODO PageColumn?
    	
    	return sqlBuilder.toString();
    }

    private String getInsertScriptForPageWidgets(String pageKey, List<PageWidget> pageWidgets) {
    	StringBuilder sqlBuilder = new StringBuilder();
    	
    	if (pageWidgets != null) {
    		pageWidgets.stream().forEach(pageWidget -> sqlBuilder.append(getInsertScriptForPageWidget(pageKey, pageWidget)));
    	}

    	return sqlBuilder.toString();
    }
    
    private String getDeleteScriptForPageProperties(String pageKey) {
    	StringBuilder sqlBuilder = new StringBuilder();
    	
//    	TODO sqlBuilder.append("DELETE FROM \"CONF_PAGE_PATHKEY\" WHERE PAGE_ID = (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + NEWLINE);
    	sqlBuilder.append(getDeleteScriptForPageWidgets(pageKey));
//    	TODO sqlBuilder.append("DELETE FROM \"CONF_PAGE_COLUMN\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + NEWLINE);
//    	TODO sqlBuilder.append("DELETE FROM \"CONF_PAGE_DOMAIN\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + NEWLINE);
//    	TODO sqlBuilder.append("DELETE FROM \"CONF_PAGE_ATTRIBUTE\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + NEWLINE);
    	
    	return sqlBuilder.toString();
    }

    private String getDeleteScriptForPageWidgets(String pageKey) {
    	return "DELETE FROM \"CONF_PAGE_WIDGET\" WHERE PAGE_ID IN (SELECT P.ID FROM CONF_PAGE P WHERE P.KEY = '" + pageKey + "');" + NEWLINE;
    }

    private String getInsertScriptForPageWidget(String pageKey, PageWidget pageWidget) {
    	Widget widget = pageWidget.getWidget();
    	String widgetName = widget == null ? null : widget.getName();
        StringBuilder sqlBuilder = new StringBuilder();
        
        sqlBuilder.append("INSERT INTO \"CONF_PAGE_WIDGET\"(PAGE_ID, WIDGET_ID, GRID_COLUMNS, ROW_INDEX, COLUMN_INDEX) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_PAGE", "KEY", pageKey) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_WIDGET", "NAME", widgetName) + ", ");
        sqlBuilder.append(pageWidget.getGridColumns() + ", ");
        sqlBuilder.append(pageWidget.getRowIndex() + ", ");
        sqlBuilder.append(pageWidget.getColumnIndex());
        sqlBuilder.append(");" + NEWLINE);

        return sqlBuilder.toString();
    }
}
