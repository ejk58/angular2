package nl.belastingdienst.iva.wd.configurator.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONF_WIDGET_HELP")
public class WidgetHelp {

    @Id
    private int id;

    private Integer index;

    @JoinColumn(name = "HELP_ID")
    @ManyToOne()
    private Help help;
}
