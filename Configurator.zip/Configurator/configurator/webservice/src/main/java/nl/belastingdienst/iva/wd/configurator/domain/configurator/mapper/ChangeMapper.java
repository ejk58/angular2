package nl.belastingdienst.iva.wd.configurator.domain.configurator.mapper;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ChangeMapper implements RowMapper<Change> {

    @Override
    public Change mapRow(ResultSet resultSet, int i) throws SQLException {
        Change change = new Change();
        change.setId(resultSet.getInt("change_id"));
        change.setDomainKey(resultSet.getString("change_domain_key"));
        change.setDomain(resultSet.getString("change_domain"));
        change.setTag(resultSet.getString("change_tag"));
        change.setAdministrator(resultSet.getString("change_administrator"));
        change.setSequenceNo(resultSet.getLong("change_sequence_no"));
        change.setDate(resultSet.getTimestamp("change_date"));
        return change;
    }
}
