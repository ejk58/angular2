package nl.belastingdienst.iva.wd.configurator.service;

import nl.belastingdienst.iva.wd.configurator.dao.QueryRepository;
import nl.belastingdienst.iva.wd.configurator.domain.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/query")
public class QueryController {

    @Autowired
    private QueryRepository queryRepository;

    @GetMapping(value = "/keys")
    public ResponseEntity<List<String>> getQueryKeys() {
        List<String> queryKeys = queryRepository.findAllQueryKeysOrderByNameAsc();
        return ResponseEntity.ok(queryKeys);
    }

    @GetMapping(value = "/{viewName}")
    public ResponseEntity<Query> getQuery(@PathVariable String viewName) {
        Query query = queryRepository.findByKey(viewName);
        return ResponseEntity.ok(query);
    }

}
