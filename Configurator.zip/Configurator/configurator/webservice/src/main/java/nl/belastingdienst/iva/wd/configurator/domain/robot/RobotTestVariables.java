package nl.belastingdienst.iva.wd.configurator.domain.robot;

import lombok.Data;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.dto.RobotTestsDto;
import nl.belastingdienst.iva.wd.configurator.util.RobotConstants;
import java.util.List;
import java.util.stream.Collectors;

@Data
public class RobotTestVariables {

    private RobotTestVariables() { throw new UnsupportedOperationException(); }

    public static String toRobot(Widget widget, RobotTestsDto testsDto) {
        StringBuilder robotBuilder = new StringBuilder();
        robotBuilder.append("*** Variables ***\n");

        String restService = "/widget/" + widget.getName() + "?domainId=${" + testsDto.getDomain() + "}";
        robotBuilder.append("${rest_service}        ").append(restService).append("\n");

        robotBuilder.append("@{fn}=                 ");
        List<String> fn = widget.getColumnList().stream().map(widgetColumn -> widgetColumn.getQueryColumn().getName()).collect(Collectors.toList());
        fn.forEach(n -> robotBuilder.append(n).append(RobotConstants.SPACES));
        robotBuilder.append("\n");

        return robotBuilder.toString();
    }
}

/*

*** Variables ***
${rest_service}        /widget/AFGESLOTEN_VORDERINGEN_WIDGET?domainId=${invordering}&entity=${ENTITY1}
@{fn}=                 betaalgedrag_omschr    betaald_eur    oninbaar_eur    verlaagd_eur    verminderd_eur

 */
