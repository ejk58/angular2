package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

@Entity
@Getter
@Setter
public class Change {

    @Id
    private Integer id;

    private Long releaseId;
    private String domain;
    private String domainKey;
    private String tag;
    private long sequenceNo;
    private String administrator;
    private Date date;
    private String sql;
    private String rollbackSql;
}
