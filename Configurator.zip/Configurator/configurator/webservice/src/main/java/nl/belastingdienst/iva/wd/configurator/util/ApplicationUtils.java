package nl.belastingdienst.iva.wd.configurator.util;

import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.security.LdapPersonAttributesMapper;
import nl.belastingdienst.iva.wd.configurator.dto.GroupDomainDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ApplicationUtils {

    private static final String SOURCE_DB = "datasource_db2";

    @Autowired
    private Environment env;

    @Autowired
    private LdapTemplate ldapTemplate;

    @Autowired
    private ApplicationContext context;

    @Value("${configurator.groups}")
    private List<String> configuratorGroups;


    public List<GroupDomainDto> getDomainList() {
        LdapPerson person = getPerson(getUserId()).get(0);
        return getDomains(person);
    }

    public String getUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth.getPrincipal().toString();
    }

    public NamedParameterJdbcTemplate getTemplate(String environment) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        String datasource = env.getProperty(environment);

        dataSource.setDriverClassName(env.getProperty(datasource + ".driverClassName"));
        dataSource.setUrl(env.getProperty(datasource + ".jdbc-url"));
        dataSource.setUsername(env.getProperty(datasource + ".username"));
        dataSource.setPassword(env.getProperty(datasource + ".password"));

        return new NamedParameterJdbcTemplate(dataSource);
    }

    public Connection getConnectionForEnvironment(String environment) throws SQLException {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        String datasource = env.getProperty(environment);

        dataSource.setDriverClassName(env.getProperty(datasource + ".driverClassName"));
        dataSource.setUrl(env.getProperty(datasource + ".jdbc-url"));
        dataSource.setUsername(env.getProperty(datasource + ".username"));
        dataSource.setPassword(env.getProperty(datasource + ".password"));

        return dataSource.getConnection();
    }

    public String getDatabaseSchema(String key) {
        return env.getProperty(key);
    }

    public boolean userHasAccessToDomain(String domainId) {
        LdapPerson person = getPerson(getUserId()).get(0);
        return userHasAccessToDomain(person, domainId);
    }

    public Connection getSourceDBConnection() throws SQLException {
        DataSource ds = (DataSource)this.context.getBean(SOURCE_DB);
        return ds.getConnection();
    }

    private boolean userHasAccessToDomain(LdapPerson person, String domainId) {
        List<GroupDomainDto> domains = getDomains(person);
        return domains.stream().anyMatch(groupDomainDto -> groupDomainDto.getDomainId().equals(domainId));
    }

    private List<GroupDomainDto> getDomains(LdapPerson person) {
        List<GroupDomainDto> domains = new ArrayList<>();
        List<String> adGroups = person.getAdGroepen().stream().map(String::toLowerCase).collect(Collectors.toList());
        for (String group : configuratorGroups) {
            if (adGroups.contains(group)) {
                domains.add(createGroupDomainDto(group));
            }
        }
        return domains;
    }

    private List<LdapPerson> getPerson(String userid) {
        LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(1)
                .base(env.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
                .is(userid.trim());
        return ldapTemplate.search(query, new LdapPersonAttributesMapper(null));
    }

    private GroupDomainDto createGroupDomainDto(String groupid) {
        List<String> groupData = Arrays.asList(env.getRequiredProperty(groupid).split("\\s*,\\s*"));
        GroupDomainDto groupDomainDto = new GroupDomainDto();
        groupDomainDto.setGroupId(groupid);
        groupDomainDto.setDomainId(groupData.get(0));
        groupDomainDto.setDomainName(groupData.get(1));
        return groupDomainDto;
    }
}
