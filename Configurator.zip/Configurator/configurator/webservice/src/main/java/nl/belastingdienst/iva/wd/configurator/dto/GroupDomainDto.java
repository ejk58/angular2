package nl.belastingdienst.iva.wd.configurator.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class GroupDomainDto {
    private String groupId;
    private String domainId;
    private String domainName;
}
