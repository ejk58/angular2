package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CONF_PAGE")
public class Page {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String key;
    private String title;
    private String type;

    @ManyToOne()
    @JoinColumn(name = "OWNER_DOMAIN_ID")
    private Domain ownerDomain;
}
