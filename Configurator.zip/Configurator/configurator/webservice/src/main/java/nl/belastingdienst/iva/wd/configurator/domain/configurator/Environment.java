package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Environment {
    private String name;
    private String type;
}
