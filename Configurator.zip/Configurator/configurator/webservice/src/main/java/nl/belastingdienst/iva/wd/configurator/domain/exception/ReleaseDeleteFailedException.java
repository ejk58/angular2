package nl.belastingdienst.iva.wd.configurator.domain.exception;

public class ReleaseDeleteFailedException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public ReleaseDeleteFailedException() { super(); }

    public ReleaseDeleteFailedException(String message) { super(message); }
}
