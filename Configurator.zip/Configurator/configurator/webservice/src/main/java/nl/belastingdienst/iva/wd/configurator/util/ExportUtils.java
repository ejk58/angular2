package nl.belastingdienst.iva.wd.configurator.util;

public class ExportUtils {
    private ExportUtils() {
        throw new UnsupportedOperationException();
    }

    public static String getString(String input) {
        if (input == null) {
            return "null";
        }

        String escapedInput = input.replace("'", "''");
        return "'" + escapedInput + "'";
    }

    public static String getBoolean(Boolean input) {
        if (input == null) {
            return "null";
        }

        return input ? "1" : "0";
    }
    
    public static String getSelectId(String table, String keyName, String keyValue) {
    	return keyValue == null ? "null" : "(SELECT ID FROM " + table + " WHERE " + keyName + " = '" + keyValue + "')";
    }
}
