package nl.belastingdienst.iva.wd.configurator.domain.exception;

public class ChangeInsertFailedException extends RuntimeException {
    private static final long serialVersionUID = -1L;

    public ChangeInsertFailedException() { super(); }

    public ChangeInsertFailedException(String message) { super(message); }
}
