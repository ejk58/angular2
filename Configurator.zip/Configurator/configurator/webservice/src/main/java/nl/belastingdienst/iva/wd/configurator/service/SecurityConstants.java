package nl.belastingdienst.iva.wd.configurator.service;

public class SecurityConstants {
    private SecurityConstants() {
    }
    public static final String SECRET = "SecretKeyToGenJWTs";
    public static final long EXPIRATION_TIME = 1000L * 60 * 60; //Millis
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_STRING = "Authorization";
    public static final String APPLICATION_PLATFORM = "applicationPlatform";
}
