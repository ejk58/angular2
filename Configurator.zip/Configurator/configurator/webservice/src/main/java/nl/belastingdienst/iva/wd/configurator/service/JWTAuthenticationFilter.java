package nl.belastingdienst.iva.wd.configurator.service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import nl.belastingdienst.iva.wd.configurator.domain.ApplicationUser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.common.springboot.security.LdapPerson;
import nl.belastingdienst.iva.common.springboot.security.LdapPersonAttributesMapper;

@Slf4j
public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private LdapTemplate ldapTemplate;
    private Environment env;
    private List<String> configuratorGroups;

    protected static final Logger LOGGER = LogManager.getLogger(JWTAuthenticationFilter.class);

    JWTAuthenticationFilter(Environment env, LdapTemplate ldapTemplate) {
        this.env = env;
        this.ldapTemplate = ldapTemplate;
        this.configuratorGroups = Arrays.asList(env.getRequiredProperty("configurator.groups").split("\\s*,\\s*"));
        setFilterProcessesUrl("/api/login");
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest req,
                                                HttpServletResponse res) {
        try {
            ApplicationUser user = new ObjectMapper().readValue(req.getInputStream(), ApplicationUser.class);

            // ldap authentication accepts empty passwords!
            if (user.getPassword().isEmpty()) {
                user.setPassword(null);
            }

            String partitionSuffix = env.getRequiredProperty("ldap.partitionSuffix");

            if (!ldapTemplate.authenticate(partitionSuffix, "(cn=" + user.getUsername() + ")", user.getPassword())) {
                throw new BadCredentialsException("Wrong userid or password");
            }

            if (!userHasAtLeastOneOfRequiredGroups(user.getUsername())) {
                throw new BadCredentialsException("userid is not connected to any group required to use configurator");
            }

            return new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword(), null);
        } catch (IOException e) {
            String message = "Exception raised while authenticating user: " + e.getMessage();
            LOGGER.warn(message);
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest req,
                                            HttpServletResponse res,
                                            FilterChain chain,
                                            Authentication auth) {
        long validityPeriod = Long.parseLong(env.getRequiredProperty("jwt.validity.period.in.days")) * 24 * 60 * 60 * 1000;

        String token = JWT.create()
                .withSubject(auth.getPrincipal().toString())
                .withExpiresAt(new Date(System.currentTimeMillis() + validityPeriod))
                .sign(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes()));

        res.addHeader(SecurityConstants.HEADER_STRING, SecurityConstants.TOKEN_PREFIX + token);
    }


    private List<LdapPerson> getPerson(String userid) {
        LdapQuery query = LdapQueryBuilder.query().searchScope(SearchScope.SUBTREE).countLimit(1)
                .base(env.getProperty("ldap.partitionSuffix")).where("objectclass").is("person").and("cn")
                .is(userid.trim());
        return ldapTemplate.search(query, new LdapPersonAttributesMapper(null));
    }

    private boolean userHasAtLeastOneOfRequiredGroups(String userid) {
        boolean groupFound = false;
        LdapPerson persoon = getPerson(userid).get(0);
        List<String> adGroepen = persoon.getAdGroepen().stream().map(String::toLowerCase).collect(Collectors.toList());
        if (adGroepen != null) {
            groupFound = adGroepen.stream().anyMatch(group -> this.configuratorGroups.contains(group));
        }
        return groupFound;
    }
}