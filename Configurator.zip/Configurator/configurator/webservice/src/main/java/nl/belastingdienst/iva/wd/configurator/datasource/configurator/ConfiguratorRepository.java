package nl.belastingdienst.iva.wd.configurator.datasource.configurator;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.jdbc.datasource.init.ScriptStatementFailedException;
import org.springframework.jdbc.datasource.init.ScriptUtils;

import java.sql.Connection;
import java.sql.SQLException;

interface ConfiguratorRepository {

    default void runSqlScript(Connection connection, String rolloutSql, boolean closeConnection) throws SQLException {
        try {
            connection.setAutoCommit(false); // Disable auto commit
            ScriptUtils.executeSqlScript(connection, new ByteArrayResource(rolloutSql.getBytes()));
            connection.commit(); // Commit manually to avoid only part of the script is committed
        } catch (ScriptStatementFailedException | SQLException exception) {
            connection.rollback();
            throw (exception);
        } finally {
            // We should not close the connection to the source database
            if (closeConnection) {
                connection.close();
            } else {
                connection.setAutoCommit(true);
            }
        }
    }

}
