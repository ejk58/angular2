package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.Datasource;
import nl.belastingdienst.iva.wd.configurator.domain.Domain;
import nl.belastingdienst.iva.wd.configurator.domain.Query;
import nl.belastingdienst.iva.wd.configurator.domain.QueryAttribute;
import nl.belastingdienst.iva.wd.configurator.domain.QueryColumn;
import nl.belastingdienst.iva.wd.configurator.domain.QueryFilter;
import nl.belastingdienst.iva.wd.configurator.util.ExportUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Component
public class QuerySqlFactory {

    private static final String NEWLINE = "\n";
    
    public String getInsertScript(Query query) {
        String queryKey = query.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForQuery(queryKey));
        sqlBuilder.append(getMergeScriptForQuery(query));
        sqlBuilder.append(getInsertScriptForQueryProperties(query));

        return sqlBuilder.toString();
    }

    public String getUpdateScript(Query query) {
        String queryKey = query.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForQuery(queryKey));
        sqlBuilder.append(getDeleteScriptForQueryProperties(queryKey));
        sqlBuilder.append(getMergeScriptForQuery(query));
        sqlBuilder.append(getInsertScriptForQueryProperties(query));

        return sqlBuilder.toString();
    }

    public String getDeleteScript(Query query) {
        String queryKey = query.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForQuery(queryKey));
        sqlBuilder.append(getDeleteScriptForQueryProperties(queryKey));
        sqlBuilder.append(getDeleteScriptForQuery(queryKey));
        return sqlBuilder.toString();
    }

    private String getPrefixScriptForQuery(String queryKey) {
        return "-- Query " + queryKey + "\n";
    }

    private String getMergeScriptForQuery(Query query) {
    	Datasource datasource = query.getDatasource();
        String datasourceKey = datasource == null ? null : datasource.getKey();
        Domain ownerDomain = query.getOwnerDomain();
        String ownerDomainKey = ownerDomain == null ? null : ownerDomain.getKey();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("MERGE INTO \"CONF_QUERY\" AS Q USING (VALUES (");
        sqlBuilder.append(ExportUtils.getString(query.getKey()) + ", ");
        sqlBuilder.append(query.getType() + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_DATASOURCE", "KEY", datasourceKey) + ", ");
        sqlBuilder.append(ExportUtils.getString(query.getViewname()) + ", ");
        sqlBuilder.append(ExportUtils.getString(query.getQuerytemplate()) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_DOMAIN", "KEY", ownerDomainKey));
        sqlBuilder.append(")) AS X(KEY, TYPE, DATASOURCE_ID, VIEWNAME, QUERYTEMPLATE, OWNER_DOMAIN_ID) ON Q.KEY = X.KEY" + NEWLINE);
        sqlBuilder.append("  WHEN MATCHED THEN UPDATE SET KEY = X.KEY, TYPE = X.TYPE, DATASOURCE_ID = X.DATASOURCE_ID, VIEWNAME = X.VIEWNAME, QUERYTEMPLATE = X.QUERYTEMPLATE, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID" + NEWLINE);
        sqlBuilder.append("  WHEN NOT MATCHED THEN INSERT (KEY, TYPE, DATASOURCE_ID, VIEWNAME, QUERYTEMPLATE, OWNER_DOMAIN_ID) VALUES (X.KEY, X.TYPE, X.DATASOURCE_ID, X.VIEWNAME, X.QUERYTEMPLATE, X.OWNER_DOMAIN_ID);" + NEWLINE);

        return sqlBuilder.toString();
    }

    private String getDeleteScriptForQuery(String queryKey) {
        return "DELETE FROM \"CONF_QUERY\" WHERE KEY = '" + queryKey + "';" + NEWLINE;
    }

    private String getInsertScriptForQueryProperties(Query query) {
        List<QueryColumn> queryColumns = query.getColumnList() == null ? Collections.emptyList() : query.getColumnList();
        List<QueryFilter> queryFilters = query.getQueryFilters() == null ? Collections.emptyList() : query.getQueryFilters();
        List<QueryAttribute> queryAttributes = query.getQueryAttributes() == null ? Collections.emptyList() : query.getQueryAttributes();
        String queryKey = query.getKey();
        String querySelect = ExportUtils.getSelectId("CONF_QUERY", "KEY", queryKey);
        StringBuilder sqlBuilder = new StringBuilder();

        for (QueryColumn queryColumn: queryColumns) {
            sqlBuilder.append(getInsertScriptForQueryColumn(queryColumn, querySelect, null));
        }

        for (QueryFilter queryFilter: queryFilters) {
            sqlBuilder.append(getInsertScriptForQueryFilter(queryFilter, queryKey));
        }

        for (QueryAttribute queryAttribute: queryAttributes) {
            sqlBuilder.append(getInsertScriptForQueryAttribute(queryAttribute, queryKey));
        }

        return sqlBuilder.toString();
    }

    private String getDeleteScriptForQueryProperties(String queryKey) {
        return "DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC3.ID FROM CONF_QUERY_COLUMN QC3 JOIN CONF_QUERY_COLUMN QC2 ON QC3.COMPOSITE_COLUMN_ID = QC2.ID JOIN CONF_QUERY_COLUMN QC ON QC2.COMPOSITE_COLUMN_ID = QC.ID JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = '" + queryKey + "');" + NEWLINE +
            "DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC2.ID FROM CONF_QUERY_COLUMN QC2 JOIN CONF_QUERY_COLUMN QC ON QC2.COMPOSITE_COLUMN_ID = QC.ID JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = '" + queryKey + "');" + NEWLINE +
            "DELETE FROM \"CONF_QUERY_COLUMN\" WHERE COMPOSITE_COLUMN_ID IN (SELECT QC.ID FROM CONF_QUERY_COLUMN QC JOIN CONF_QUERY Q ON QC.QUERY_ID = Q.ID WHERE Q.KEY = '" + queryKey + "');" + NEWLINE +
            "DELETE FROM \"CONF_QUERY_COLUMN\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = '" + queryKey + "');" + NEWLINE +
            "DELETE FROM \"CONF_QUERY_FILTER\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = '" + queryKey + "');" + NEWLINE +
            "DELETE FROM \"CONF_QUERY_ATTRIBUTE\" WHERE QUERY_ID IN (SELECT Q.ID FROM CONF_QUERY Q WHERE Q.KEY = '" + queryKey + "');" + NEWLINE;
    }
    
    private String getInsertScriptForQueryColumn(QueryColumn queryColumn, String querySelect, String queryColumnSelect) {
        List<QueryColumn> innerQueryColumns = queryColumn.getColumnList() == null ? Collections.emptyList() : queryColumn.getColumnList();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_QUERY_COLUMN\"(QUERY_ID, COMPOSITE_COLUMN_ID, INDEX, NAME, ALIAS, VALUE, KEY, TYPE, MASKABLE) VALUES (");
        if (querySelect != null) {
            sqlBuilder.append(querySelect + ", null, ");
        } else {
            sqlBuilder.append("null, " + queryColumnSelect + ", ");
        }
        sqlBuilder.append(queryColumn.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getString(queryColumn.getName()) + ", ");
        sqlBuilder.append(ExportUtils.getString(queryColumn.getAlias()) + ", ");
        sqlBuilder.append(ExportUtils.getString(queryColumn.getValue()) + ", ");
        sqlBuilder.append(ExportUtils.getString(queryColumn.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(queryColumn.getType()) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(queryColumn.isMaskable()) + ");" + NEWLINE);

        for (QueryColumn innerQueryColumn : innerQueryColumns) {
            String querySubColumnSelect = (querySelect != null) ?
                    "(SELECT ID from CONF_QUERY_COLUMN WHERE QUERY_ID = " + querySelect + " AND INDEX = " + queryColumn.getIndex() + ")" :
                    "(SELECT ID from CONF_QUERY_COLUMN WHERE COMPOSITE_COLUMN_ID = " + queryColumnSelect + " AND INDEX = " + queryColumn.getIndex() + ")";

            sqlBuilder.append(getInsertScriptForQueryColumn(innerQueryColumn, null, querySubColumnSelect));
        }

        return sqlBuilder.toString();
    }

    private String getInsertScriptForQueryFilter(QueryFilter queryFilter, String queryKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_QUERY_FILTER\"(QUERY_ID, PARAMETER, FILTERTEMPLATE, NOFILTERTEMPLATE) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_QUERY", "KEY", queryKey) + ", ");
        sqlBuilder.append(ExportUtils.getString(queryFilter.getParameter()) + ", ");
        sqlBuilder.append(ExportUtils.getString(queryFilter.getFilterTemplate()) + ", ");
        sqlBuilder.append(ExportUtils.getString(queryFilter.getNoFilterTemplate()) + ");" + NEWLINE);
        
        return sqlBuilder.toString();
    }

    private String getInsertScriptForQueryAttribute(QueryAttribute queryAttribute, String queryKey) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_QUERY_FILTER\"(QUERY_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append("(SELECT q.ID FROM CONF_QUERY q WHERE q.KEY = '" + queryKey + "'), ");
        sqlBuilder.append(ExportUtils.getString(queryAttribute.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(queryAttribute.getValue()) + ");" + NEWLINE);
        
        return sqlBuilder.toString();
    }
}
