package nl.belastingdienst.iva.wd.configurator.domain;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "CONF_RULE_GROUP")
public class RuleGroup {

    @Id
    private Integer id;

    private String key;

    @OneToMany()
    @JoinColumn(name = "RULE_GROUP_ID")
    @OrderBy("index ASC")
    private List<Rule> ruleList;
}
