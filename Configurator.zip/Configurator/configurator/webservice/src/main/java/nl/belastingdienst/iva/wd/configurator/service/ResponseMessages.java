package nl.belastingdienst.iva.wd.configurator.service;

public class ResponseMessages {

    private ResponseMessages() {
    }

    public static final String CHANGE_DELETE_NOK = "Let op! Het verwijderen van de change is niet gelukt.";
    public static final String CHANGE_DELETE_OK = "Het verwijderen van de change is gelukt!";
    public static final String CHANGE_EXISTS = "Let op! Het opslaan is niet gelukt. De naam voor de change bestaat al.";
    public static final String CHANGE_IN_RELEASE = "De change is aan een release gekoppeld.";
    public static final String CHANGE_NOT_EXISTS = "De change bestaat niet meer.";
    public static final String CHANGE_NOT_MOST_RECENT = "De change is niet meer de recentste.";
    public static final String CHANGE_ROLLOUT_OK = "De change is opgeslagen in de configuratie database en uitgevoerd in de source database.";
    public static final String OK = "Het opslaan is gelukt!";
    public static final String RELEASE_DELETE_NOK = "Let op! Het verwijderen van de release is niet gelukt.";
    public static final String RELEASE_DELETE_OK = "Het verwijderen van de release is gelukt!";
    public static final String RELEASE_EXISTS = "Let op! Het opslaan is niet gelukt. De naam voor de release bestaat al.";
    public static final String RELEASE_NOT_EXISTS = "De release bestaat niet meer.";
    public static final String RELEASE_NOT_MOST_RECENT = "De release is niet meer de recentste.";
    public static final String RELEASE_ROLLBACK_NOK = "Let op! Het terugdraaien van de release is niet gelukt.";
    public static final String RELEASE_ROLLBACK_OK = "Het terugdraaien van de release is gelukt!";
    public static final String RELEASE_ROLLOUT_OK = "Het uitrollen van de release is gelukt!";
    public static final String SERVER_ERROR = "Er is een fout opgetreden op de server.";
    public static final String UNAUTHORIZED = "Let op! Het opslaan is niet gelukt. Je hebt geen toegang tot klantbeeld ";
}
