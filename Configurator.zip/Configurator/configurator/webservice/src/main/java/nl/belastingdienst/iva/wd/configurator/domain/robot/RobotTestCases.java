package nl.belastingdienst.iva.wd.configurator.domain.robot;

public class RobotTestCases {

    private RobotTestCases() { throw new UnsupportedOperationException(); }

    public static String toRobot() {
        return
            "*** Test Cases ***\n" +
            "REST Response Check for Invalid and Valid Calls\n" +
            "    [Tags]   REST\n" +
            "    [Template]    Widget Rest Call\n" +
            "    #URI                                                     expected response    testcase\n" +
            "    ${rest_service}&subjectNr=${SUBJECTUNKNOWN}              401                  # Unknown subject\n" +
            "    ${rest_service}&subjectNr=${SUBJECTALPHA}                400                  # Subjectnumber with illegal character\n" +
            "    ${rest_service}&subjectNr=${SUBJECTTOOLONG}              400                  # Subjectnumber is too long\n" +
            "    ${rest_service}                                          400                  # Call without subjectnumber\n" +
            "    ${rest_service}&subjectNr=${SUBJECT1}                    200                  # Valid call";
    }

}

/*

*** Test Cases ***
REST Response Check for Invalid and Valid Calls
    [Tags]   REST
    [Template]    Widget Rest Call
    #URI                                                     expected response    testcase
    ${rest_service}&subjectNr=${SUBJECTUNKNOWN}              401                  # Unknown subject
    ${rest_service}&subjectNr=${SUBJECTALPHA}                400                  # Subjectnumber with illegal character
    ${rest_service}&subjectNr=${SUBJECTTOOLONG}              400                  # Subjectnumber is too long
    ${rest_service}                                          400                  # Call without subjectnumber
    ${rest_service}&subjectNr=${SUBJECT1}                    200                  # Valid call

 */
