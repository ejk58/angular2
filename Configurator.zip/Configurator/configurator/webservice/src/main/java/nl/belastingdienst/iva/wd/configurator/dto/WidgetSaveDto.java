package nl.belastingdienst.iva.wd.configurator.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class WidgetSaveDto {
	
    private String tag;
    private WidgetDto widget;
    private WidgetDto widgetOriginal;
    private GroupDomainDto groupDomain;
}
