package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import lombok.Getter;
import lombok.Setter;
import nl.belastingdienst.iva.wd.configurator.dto.GroupDomainDto;

import java.util.List;

@Getter
@Setter
public class ReleaseAndChanges {
    private List<Change> changes;
    private Release release;
    private GroupDomainDto groupDomain;
}


