package nl.belastingdienst.iva.wd.configurator.service;

import nl.belastingdienst.iva.wd.configurator.dto.VersionDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin
@PropertySource(ignoreResourceNotFound=true,value="classpath:git.properties")
@RestController
@RequestMapping("/api/system")
public class SystemController {
    @Value("${git.build.version: <buildVersion>}")
    private String version;
    @Value("${git.commit.time: <commitTime>}")
    private String commitDate;
    @Value("${git.commit.id.abbrev: <commitId>}")
    private String commitId;

    @GetMapping("/version")
    public ResponseEntity<VersionDto>getVersion() {
        VersionDto versionDto = new VersionDto();
        versionDto.setVersion(this.version);
        versionDto.setCommitId(this.commitId);
        versionDto.setCommitDate(this.commitDate);
        return ResponseEntity.ok(versionDto);
    }

}
