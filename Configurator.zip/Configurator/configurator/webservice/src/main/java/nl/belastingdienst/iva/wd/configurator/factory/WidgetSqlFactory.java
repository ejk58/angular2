package nl.belastingdienst.iva.wd.configurator.factory;

import nl.belastingdienst.iva.wd.configurator.domain.Domain;
import nl.belastingdienst.iva.wd.configurator.domain.Help;
import nl.belastingdienst.iva.wd.configurator.domain.Query;
import nl.belastingdienst.iva.wd.configurator.domain.QueryColumn;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.domain.WidgetAttribute;
import nl.belastingdienst.iva.wd.configurator.domain.WidgetColumn;
import nl.belastingdienst.iva.wd.configurator.domain.WidgetColumnAttribute;
import nl.belastingdienst.iva.wd.configurator.domain.WidgetHelp;
import nl.belastingdienst.iva.wd.configurator.util.ExportUtils;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class WidgetSqlFactory {

    private static final String NEWLINE = "\n";
    
	private QuerySqlFactory querySqlFactory;

    @Autowired
    public WidgetSqlFactory(QuerySqlFactory querySqlFactory) {
        this.querySqlFactory = querySqlFactory;
    }

    public String getInsertScript(Widget widget) {
        String widgetName = widget.getName();
        Query query = widget.getQuery();
        StringBuilder sqlBuilder = new StringBuilder();

        if (query != null) {
            sqlBuilder.append(this.querySqlFactory.getInsertScript(query));
        	sqlBuilder.append(getEmptyLine());
        }

        sqlBuilder.append(getPrefixScriptForWidget(widgetName));
        sqlBuilder.append(getMergeScriptForWidget(widget));
        sqlBuilder.append(getInsertScriptForWidgetProperties(widget));

        return sqlBuilder.toString();
    }

    public String getUpdateScript(Widget widget) {
        String widgetName = widget.getName();
        Query query = widget.getQuery();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForWidget(widgetName));
        sqlBuilder.append(getDeleteScriptForWidgetProperties(widgetName));

        if (query != null) {
        	sqlBuilder.append(getEmptyLine());
            sqlBuilder.append(this.querySqlFactory.getUpdateScript(query));
        	sqlBuilder.append(getEmptyLine());
            sqlBuilder.append(getPrefixScriptForWidget(widgetName));
        }
        
        sqlBuilder.append(getMergeScriptForWidget(widget));
        sqlBuilder.append(getInsertScriptForWidgetProperties(widget));

        return sqlBuilder.toString();
    }

    public String getDeleteScript(Widget widget) {
        String widgetName = widget.getName();
        Query query = widget.getQuery();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append(getPrefixScriptForWidget(widgetName));
        sqlBuilder.append(getDeleteScriptForWidgetProperties(widgetName));
        sqlBuilder.append(getDeleteScriptForWidget(widgetName));

        if (query != null) {
        	sqlBuilder.append(getEmptyLine());
            sqlBuilder.append(this.querySqlFactory.getDeleteScript(query));
        }

        return sqlBuilder.toString();
    }

    private String getPrefixScriptForWidget(String widgetName) {
        return "-- Widget " + widgetName + NEWLINE;
    }

    private String getEmptyLine() {
        return NEWLINE;
    }

    private String getMergeScriptForWidget(Widget widget) {
        Query query = widget.getQuery();
        String queryKey = query == null ? null : query.getKey();
        Domain ownerDomain = widget.getOwnerDomain();
        String ownerDomainKey = ownerDomain == null ? null : ownerDomain.getKey();
        Widget containerWidget = widget.getContainerWidget();
        String containerWidgetName = containerWidget == null ? null : containerWidget.getName();
        StringBuilder sqlBuilder = new StringBuilder();
        
        sqlBuilder.append("MERGE INTO \"CONF_WIDGET\" AS W USING (VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_QUERY", "KEY", queryKey) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_WIDGET", "NAME", containerWidgetName) + ", ");
        sqlBuilder.append(widget.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getString(widget.getName()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widget.getType()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widget.getTitle()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widget.getDescription()) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(widget.isRefreshinfo()) + ", ");
        sqlBuilder.append(ExportUtils.getBoolean(widget.isVisible()) + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_DOMAIN", "KEY", ownerDomainKey));
        sqlBuilder.append(")) AS X(QUERY_ID, CONTAINER_WIDGET_ID, INDEX, NAME, TYPE, TITLE, DESCRIPTION, REFRESHINFO, VISIBLE, OWNER_DOMAIN_ID) ON W.NAME = X.NAME" + NEWLINE);
        sqlBuilder.append("  WHEN MATCHED THEN UPDATE SET QUERY_ID = X.QUERY_ID, CONTAINER_WIDGET_ID = X.CONTAINER_WIDGET_ID, INDEX = X.INDEX, NAME = X.NAME, TYPE = X.TYPE, TITLE = X.TITLE, DESCRIPTION = X.DESCRIPTION, REFRESHINFO = X.REFRESHINFO, VISIBLE = X.VISIBLE, OWNER_DOMAIN_ID = X.OWNER_DOMAIN_ID" + NEWLINE);
        sqlBuilder.append("  WHEN NOT MATCHED THEN INSERT (QUERY_ID, CONTAINER_WIDGET_ID, INDEX, NAME, TYPE, TITLE, DESCRIPTION, REFRESHINFO, VISIBLE, OWNER_DOMAIN_ID) VALUES (X.QUERY_ID, X.CONTAINER_WIDGET_ID, X.INDEX, X.NAME, X.TYPE, X.TITLE, X.DESCRIPTION, X.REFRESHINFO, X.VISIBLE, X.OWNER_DOMAIN_ID);" + NEWLINE);

        return sqlBuilder.toString();
    }

    private String getDeleteScriptForWidget(String widgetName) {
        return "DELETE FROM \"CONF_WIDGET\" WHERE NAME = '" + widgetName + "';" + NEWLINE;
    }

    private String getInsertScriptForWidgetProperties(Widget widget) {
    	String widgetName = widget.getName();
    	Query query = widget.getQuery();
        StringBuilder sqlBuilder = new StringBuilder();
    	
        if (widget.getColumnList() != null) {
        	widget.getColumnList().stream().forEach(widgetColumn -> sqlBuilder.append(getInsertScriptForWidgetColumn(widgetName, query.getKey(), widgetColumn)));
        }
    	
        if (widget.getAttributeList() != null) {
        	widget.getAttributeList().stream().forEach(widgetAttribute -> sqlBuilder.append(getInsertScriptForWidgetAttribute(widgetName, widgetAttribute)));
        }
        
        if (widget.getHelpList() != null) {
        	widget.getHelpList().stream().forEach(widgetHelp -> sqlBuilder.append(getInsertScriptForWidgetHelp(widgetName, widgetHelp)));
        }
        
        return sqlBuilder.toString();
    }

    private String getDeleteScriptForWidgetProperties(String widgetName) {
        return "DELETE FROM \"CONF_WIDGET_COLUMN_ATTRIBUTE\" WHERE WIDGET_COLUMN_ID IN (SELECT WC.ID FROM CONF_WIDGET_COLUMN WC JOIN CONF_WIDGET W ON WC.WIDGET_ID = W.ID WHERE W.NAME = '" + widgetName + "');" + NEWLINE +
                "DELETE FROM \"CONF_WIDGET_COLUMN\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = '" + widgetName + "');" + NEWLINE +
                "DELETE FROM \"CONF_WIDGET_HELP\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = '" + widgetName + "');" + NEWLINE +
                "DELETE FROM \"CONF_WIDGET_ATTRIBUTE\" WHERE WIDGET_ID IN (SELECT W.ID FROM CONF_WIDGET W WHERE W.NAME = '" + widgetName + "');" + NEWLINE;
    }

    private String getInsertScriptForWidgetColumn(String widgetName, String queryKey, WidgetColumn widgetColumn) {
    	List<WidgetColumnAttribute> widgetColumnAttributes = widgetColumn.getColumnAttributeList();
    	QueryColumn queryColumn = widgetColumn.getQueryColumn();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_COLUMN\"(WIDGET_ID, QUERY_COLUMN_ID, INDEX, TYPE, LABEL, DESCRIPTION, BEHAVIOUR, FILTER) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_WIDGET", "NAME", widgetName) + ", ");
        sqlBuilder.append("(SELECT qc.ID FROM CONF_QUERY_COLUMN qc JOIN CONF_QUERY q ON q.ID = qc.QUERY_ID WHERE q.KEY = '" + queryKey + "' AND qc.INDEX = " + queryColumn.getIndex() + "), ");
        sqlBuilder.append(widgetColumn.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getType()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getLabel()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getDescription()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getBehaviour()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumn.getFilter()));
        sqlBuilder.append(");" + NEWLINE);

        if (widgetColumnAttributes != null) {
        	widgetColumnAttributes.stream()
        		.forEach(widgetColumnAttribute -> sqlBuilder.append(getInsertScriptForWidgetColumnAttribute(widgetColumnAttribute, widgetName, widgetColumn.getIndex())));
        }
        
        return sqlBuilder.toString();
    }
    
    private String getInsertScriptForWidgetColumnAttribute(WidgetColumnAttribute widgetColumnAttribute, String widgetName, int widgetColumnIndex) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_COLUMN_ATTRIBUTE\"(WIDGET_COLUMN_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append("(SELECT ID FROM \"CONF_WIDGET_COLUMN\" WHERE WIDGET_ID = " + ExportUtils.getSelectId("CONF_WIDGET", "NAME", widgetName) + " AND INDEX = " + widgetColumnIndex + "), ");
        sqlBuilder.append(ExportUtils.getString(widgetColumnAttribute.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetColumnAttribute.getValue()));
        sqlBuilder.append(");" + NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForWidgetAttribute(String widgetName, WidgetAttribute widgetAttribute) {
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_ATTRIBUTE\"(WIDGET_ID, KEY, VALUE) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_WIDGET", "NAME", widgetName) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetAttribute.getKey()) + ", ");
        sqlBuilder.append(ExportUtils.getString(widgetAttribute.getValue()));
        sqlBuilder.append(");" + NEWLINE);

        return sqlBuilder.toString();
    }

    private String getInsertScriptForWidgetHelp(String widgetName, WidgetHelp widgetHelp) {
    	Help help = widgetHelp.getHelp();
        StringBuilder sqlBuilder = new StringBuilder();

        sqlBuilder.append("INSERT INTO \"CONF_WIDGET_HELP\"(WIDGET_ID, INDEX, HELP_ID) VALUES (");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_WIDGET", "NAME", widgetName) + ", ");
        sqlBuilder.append(widgetHelp.getIndex() + ", ");
        sqlBuilder.append(ExportUtils.getSelectId("CONF_HELP", "KEY", help.getKey()));
        sqlBuilder.append(");" + NEWLINE);

        return sqlBuilder.toString();
    }
}
