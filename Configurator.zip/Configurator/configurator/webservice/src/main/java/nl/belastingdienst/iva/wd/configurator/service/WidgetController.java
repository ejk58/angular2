package nl.belastingdienst.iva.wd.configurator.service;

import nl.belastingdienst.iva.wd.configurator.dao.WidgetAttributeRepository;
import nl.belastingdienst.iva.wd.configurator.dao.WidgetRepository;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ChangeInsertFailedException;
import nl.belastingdienst.iva.wd.configurator.dto.GroupDomainDto;
import nl.belastingdienst.iva.wd.configurator.dto.WidgetDto;
import nl.belastingdienst.iva.wd.configurator.dto.WidgetSaveDto;
import nl.belastingdienst.iva.wd.configurator.factory.WidgetMapper;
import nl.belastingdienst.iva.wd.configurator.factory.WidgetSqlFactory;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/widget")
public class WidgetController extends AbstractController {

    @Autowired
    private WidgetRepository widgetRepository;

    @Autowired
    private WidgetAttributeRepository widgetAttributeRepository;

    @Autowired
    private WidgetSqlFactory widgetSqlFactory;

    @Autowired
    private WidgetMapper widgetMapper;

    @Autowired
    private ApplicationUtils applicationUtils;

    @GetMapping(value = "/names")
    public ResponseEntity<List<String>> getWidgetNames() {
        List<String> widgetNames = widgetRepository.findAllWidgetNamesByOrderByNameAsc();
        return ResponseEntity.ok(widgetNames);
    }

    @GetMapping(value = "/names/{domainKey}")
    public ResponseEntity<List<String>> getWidgetNamesForDomain(@PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }
        List<String> widgetNames = widgetRepository.findAllAllowedWidgetNamesOrderByNameAsc(domainKey);

        return ResponseEntity.ok(widgetNames);
    }

    @GetMapping(value = "/types")
    public ResponseEntity<List<String>> getWidgetTypes() {
        List<String> widgetTypes = widgetRepository.findAllWidgetTypesByOrderByTypeAsc();
        return ResponseEntity.ok(widgetTypes);
    }

    @GetMapping(value = "/attributekeys")
    public ResponseEntity<List<String>> getWidgetAttributeKeys() {
        List<String> widgetAttributeKeys = widgetAttributeRepository.findAllWidgetAttributeKeysByOrderByKeyAsc();
        return ResponseEntity.ok(widgetAttributeKeys);
    }

    @GetMapping(value = "/{name}")
    public ResponseEntity<Widget> getWidget(@PathVariable String name) {
        Widget widget = widgetRepository.findByName(name);
        return ResponseEntity.ok(widget);
    }

    @PostMapping(value = "/configurationQuery")
    public ResponseEntity<String> getConfigurationQuery(@RequestBody WidgetDto widgetDto) {
        String sql = createQueryAndWidgetSqlStatements(widgetDto);
        return ResponseEntity.ok(sql);
    }

    @Transactional
    @PostMapping(value = "/save")
    public ResponseEntity<String> saveWidget(@RequestBody WidgetSaveDto widgetSaveDto) throws SQLException {
        GroupDomainDto groupDomain = widgetSaveDto.getGroupDomain();
        if (!applicationUtils.userHasAccessToDomain(groupDomain.getDomainId())) {
            throw new AccessDeniedException(groupDomain.getDomainName());
        }

        if (configuratorChangeRepository.checkUniqueChangeTag(widgetSaveDto.getTag())) {
            Change change = createAndStoreNewWidget(widgetSaveDto);
            return handleRolloutChangeOnSourceDatabase(change);
        }

        throw new ChangeInsertFailedException(ResponseMessages.CHANGE_EXISTS);
    }

    private Change createAndStoreNewWidget(WidgetSaveDto widgetSaveDto) {
        Change change = new Change();
        change.setDomain(widgetSaveDto.getGroupDomain().getDomainName());
        change.setDomainKey(widgetSaveDto.getGroupDomain().getDomainId());
        change.setTag(widgetSaveDto.getTag());
        change.setSequenceNo(new Date().getTime()); // - Sequence number is now just the timestamp so more or less redundant with the date.
        change.setAdministrator(applicationUtils.getUserId());
        change.setDate(new Date());
        change.setSql(createQueryAndWidgetSqlStatements(widgetSaveDto.getWidget()));
        if(widgetSaveDto.getWidgetOriginal() != null) {
            change.setRollbackSql(createQueryAndWidgetSqlStatements(widgetSaveDto.getWidgetOriginal()));
        } else {
            change.setRollbackSql(createDeleteWidgetSqlStatements(widgetSaveDto.getWidget()));
        }

        configuratorChangeRepository.saveChange(change);
        return change;
    }

    private String createQueryAndWidgetSqlStatements(WidgetDto widgetDto) {
        Widget widget = this.widgetMapper.map(widgetDto);
        return this.widgetSqlFactory.getUpdateScript(widget);
    }

    private String createDeleteWidgetSqlStatements(WidgetDto widgetDto) {
        Widget widget = this.widgetMapper.map(widgetDto);
        return this.widgetSqlFactory.getDeleteScript(widget);
    }
}
