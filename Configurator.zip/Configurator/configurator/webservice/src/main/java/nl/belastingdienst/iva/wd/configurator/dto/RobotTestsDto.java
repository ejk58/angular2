package nl.belastingdienst.iva.wd.configurator.dto;

import lombok.Data;

@Data
public class RobotTestsDto {
    private String widgetName;
    private String domain;
    private String page;
    private String user;
}
