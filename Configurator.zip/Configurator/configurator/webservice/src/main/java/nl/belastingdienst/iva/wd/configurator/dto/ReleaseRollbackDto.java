package nl.belastingdienst.iva.wd.configurator.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Release;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ReleaseRolloutInfo;

@Data
@Getter
@Setter
public class ReleaseRollbackDto {
    private String environment;
    private Release currentRelease;
    private GroupDomainDto groupDomain;
}
