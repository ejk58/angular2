package nl.belastingdienst.iva.wd.configurator.service;

import nl.belastingdienst.iva.wd.configurator.dao.DomainRepository;
import nl.belastingdienst.iva.wd.configurator.dao.PageRepository;
import nl.belastingdienst.iva.wd.configurator.dao.PageWidgetRepository;
import nl.belastingdienst.iva.wd.configurator.domain.Domain;
import nl.belastingdienst.iva.wd.configurator.domain.Page;
import nl.belastingdienst.iva.wd.configurator.domain.PageWidget;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ChangeInsertFailedException;
import nl.belastingdienst.iva.wd.configurator.dto.PageAndPageWidgetDto;
import nl.belastingdienst.iva.wd.configurator.dto.PageDto;
import nl.belastingdienst.iva.wd.configurator.factory.PageSqlFactory;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/page")
public class PageController extends AbstractController {

    @Autowired
    private PageRepository pageRepository;

    @Autowired
    private DomainRepository domainRepository;

    @Autowired
    private PageWidgetRepository pageWidgetRepository;

    @Autowired
    private PageSqlFactory pageSqlFactory;

    @Autowired
    private ApplicationUtils applicationUtils;

    @GetMapping(value = "/keys")
    public ResponseEntity<List<String>> getAllPageKeys() {
        List<String> pageKeys = pageRepository.findAllPageKeysOrderByNameAsc();

        return ResponseEntity.ok(pageKeys);
    }

    @GetMapping(value = "/keys/{domainKey}")
    public ResponseEntity<List<String>> getPageKeysForDomain(@PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }
        List<String> pageKeys = pageRepository.findAllAllowedPageKeysOrderByNameAsc(domainKey);

        return ResponseEntity.ok(pageKeys);
    }

    @GetMapping(value = "/{pageKey}")
    public ResponseEntity<Page> getPage(@PathVariable String pageKey) {
        Page page = pageRepository.findByKey(pageKey);
        return ResponseEntity.ok(page);
    }

    @GetMapping(value = "/layout/{pageKey}")
    public ResponseEntity<PageAndPageWidgetDto> getWidgetsOnPage(@PathVariable String pageKey) {
        Page page = pageRepository.findByKey(pageKey);

        // to avoid (deep) cloning we get the data 2 times.
        List<PageWidget> initialWidgets = pageWidgetRepository.findByPage(page);
        List<PageWidget> widgets = pageWidgetRepository.findByPage(page);

        PageAndPageWidgetDto pageAndWidgets = new PageAndPageWidgetDto(page, initialWidgets, widgets, "");
        return ResponseEntity.ok(pageAndWidgets);
    }

    @PostMapping(value = "/configurationQuery")
    public ResponseEntity<String> getConfigurationQuery(@RequestBody PageAndPageWidgetDto pageAndPageWidgetDto) {
        return ResponseEntity.ok(createPageWidgetsSqlStatements(pageAndPageWidgetDto.getPage(), pageAndPageWidgetDto.getWidgets()));
    }

    @Transactional
    @PostMapping(value = "/changeLayout")
    public ResponseEntity<String> changePageLayout(@RequestBody PageAndPageWidgetDto pageAndPageWidgetDto) throws SQLException {
        if (!applicationUtils.userHasAccessToDomain(pageAndPageWidgetDto.getGroupDomain().getDomainId())) {
            throw new AccessDeniedException(pageAndPageWidgetDto.getGroupDomain().getDomainName());
        }
        if (configuratorChangeRepository.checkUniqueChangeTag(pageAndPageWidgetDto.getTag())) {
            Change change = createAndStoreChangeForChangedPageLayout(pageAndPageWidgetDto);
            return handleRolloutChangeOnSourceDatabase(change);
        }
        throw new ChangeInsertFailedException(ResponseMessages.CHANGE_EXISTS);
    }

    @Transactional
    @PostMapping(value = "/new")
    public ResponseEntity<String> newPage(@RequestBody PageDto pageDto) throws SQLException {
        if (!applicationUtils.userHasAccessToDomain(pageDto.getGroupDomain().getDomainId())) {
            throw new AccessDeniedException(pageDto.getGroupDomain().getDomainName());
        }
        if (configuratorChangeRepository.checkUniqueChangeTag(pageDto.getTag())) {
            Domain domain = domainRepository.findByKey(pageDto.getGroupDomain().getDomainId());
            Change change = createAndStoreChangeForNewPage(pageDto, domain);
            return handleRolloutChangeOnSourceDatabase(change);
        }
        throw new ChangeInsertFailedException(ResponseMessages.CHANGE_EXISTS);
    }

    private Change createAndStoreChangeForNewPage(PageDto pageDto, Domain domain) {
        Page page = createPage(pageDto, domain);
        Change change = new Change();
        change.setDomain(domain.getName());
        change.setDomainKey(domain.getKey());
        change.setTag(pageDto.getTag());
        change.setSequenceNo(new Date().getTime()); // - Sequence number is now just the timestamp so more or less redundant with the date.
        change.setAdministrator(applicationUtils.getUserId());
        change.setDate(new Date());
        change.setSql(pageSqlFactory.getInsertScript(page, new ArrayList<>()));
        change.setRollbackSql(pageSqlFactory.getDeleteScript(page));
        configuratorChangeRepository.saveChange(change);
        return change;
    }

    private Page createPage(PageDto pageDto, Domain domain) {
        Page page = new Page();
        page.setKey(pageDto.getKey());
        page.setTitle(pageDto.getTitle());
        page.setType(pageDto.getType());
        page.setOwnerDomain(domain);
        return page;
    }

    private Change createAndStoreChangeForChangedPageLayout(PageAndPageWidgetDto pageAndPageWidgetDto) {
        Change change = new Change();
        change.setDomain(pageAndPageWidgetDto.getGroupDomain().getDomainName());
        change.setDomainKey(pageAndPageWidgetDto.getGroupDomain().getDomainId());
        change.setTag(pageAndPageWidgetDto.getTag());
        change.setSequenceNo(new Date().getTime()); // - Sequence number is now just the timestamp so more or less redundant with the date.
        change.setAdministrator(applicationUtils.getUserId());
        change.setDate(new Date());
        change.setSql(createPageWidgetsSqlStatements(pageAndPageWidgetDto.getPage(), pageAndPageWidgetDto.getWidgets()));
        change.setRollbackSql(createPageWidgetsSqlStatements(pageAndPageWidgetDto.getPage(), pageAndPageWidgetDto.getInitialWidgets()));
        configuratorChangeRepository.saveChange(change);
        return change;
    }

    private String createPageWidgetsSqlStatements(Page page, List<PageWidget> pageWidgets) {
        return this.pageSqlFactory.getUpdateScript(page.getKey(), pageWidgets);
    }

}
