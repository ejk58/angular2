package nl.belastingdienst.iva.wd.configurator.datasource.configurator;

import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ChangeReleaseEnvironment;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.mapper.ChangeReleaseEnvironmentMapper;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ChangeDeleteFailedException;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class ConfiguratorChangeRepository implements ConfiguratorRepository {

    private static final String SOURCE_DB_SCHEMA = "spring.jpa.properties.hibernate.default_schema";

    @Autowired
    private NamedParameterJdbcTemplate namedJdbcTemplateConfigurator;

    @Autowired
    private ApplicationUtils applicationUtils;

    @Autowired
    private ChangeReleaseEnvironmentMapper changeReleaseEnvironmentMapper;

    @Value("${configurator.db.schema}")
    private String schema;

    public List<ChangeReleaseEnvironment> getChangesReleaseEnvironmentInfo() {
        String sql = "WITH temp_release_environment AS (" +
                        "SELECT re.administrator, re.deployment_date, re.domain_key, r.id as release_id, e.name as environment_name, e.type as environment_type " +
                        "FROM " + schema + ".release_environment re " +
                        "LEFT JOIN " + schema + ".release r ON r.id = re.release_id " +
                        "LEFT JOIN " + schema + ".environment e ON e.id = re.environment_id ) " +
                        "SELECT c.id AS change_id, c.domain_key AS change_domain_key, c.domain AS change_domain, c.tag AS change_tag, c.sequence_no AS change_sequence_no, c.date AS change_date, c.administrator AS change_administrator, " +
                               "r.id AS release_id, r.domain_key AS release_domain_key, r.tag AS release_tag, r.date AS release_date, r.administrator AS release_administrator, " +
                               "tre.administrator AS release_environment_administrator, tre.deployment_date as release_environment_deployment_date, tre.domain_key as release_environment_domain_key, " +
                               "tre.environment_name AS environment_name, tre.environment_type AS environment_type " +
                        "FROM " + schema + ".change c " +
                        "LEFT JOIN " + schema + ".release r ON c.release_id = r.id " +
                        "LEFT JOIN temp_release_environment tre ON c.release_id = tre.release_id " +
                        "ORDER BY change_date DESC";

        return namedJdbcTemplateConfigurator.query(sql, changeReleaseEnvironmentMapper);
    }

    public Change getChange(Integer changeId) {
        String sql = "SELECT * FROM " + schema + ".change WHERE id = '" + changeId + "'";
        List<Change> changes = namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Change.class));
        return (changes.isEmpty()) ? null : changes.get(0);
    }

    public Change getMostRecentChange(String domainKey) {
        String sql = "SELECT * FROM " + schema + ".change WHERE DOMAIN_KEY = '" + domainKey + "' ORDER BY DATE DESC FETCH FIRST 1 ROWS ONLY";
        List<Change> mostRecentChange = namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Change.class));
        return (mostRecentChange.isEmpty()) ? null : mostRecentChange.get(0);
    }

    public List<Change> getChangesForDomain(String domainKey) {
        String sql = "SELECT * FROM " + schema + ".change WHERE RELEASE_ID IS NULL AND DOMAIN_KEY = '" + domainKey + "' ORDER BY DATE ASC";
        return namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Change.class));
    }

    public List<Change> getChangesOfRelease(String domainKey, String releaseTag) {
        String sql = "SELECT * FROM " + schema + ".change WHERE RELEASE_ID = (SELECT ID FROM " + schema + ".release WHERE DOMAIN_KEY = '" + domainKey + "' AND TAG = '" + releaseTag + "') ORDER BY SEQUENCE_NO";
        return namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Change.class));
    }

    public List<Change> getChangesOfReleaseInReverseOrder(String domainKey, String releaseTag) {
        String sql = "SELECT * FROM " + schema + ".change WHERE RELEASE_ID = (SELECT ID FROM " + schema + ".release WHERE DOMAIN_KEY = '" + domainKey + "' AND TAG = '" + releaseTag + "') ORDER BY SEQUENCE_NO DESC";
        return namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(Change.class));
    }

    public List<String> getAllChangeTags() {
        String sql = "SELECT tag FROM " + schema + ".change ORDER BY DATE ASC";
        return namedJdbcTemplateConfigurator.query(sql, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet resultSet, int i) throws SQLException {
                return resultSet.getString(1);
            }
        });
    }

    public boolean checkUniqueChangeTag(String changeTag) {
        String sql = "SELECT tag FROM " + schema + ".change WHERE tag = '" + changeTag + "'";
        List<String> tags = namedJdbcTemplateConfigurator.query(sql, new BeanPropertyRowMapper(String.class));
        return tags.isEmpty();
    }

    public void saveChange(Change change) {
        String sqlStatement =
            "insert into " + schema + ".change (release_id, domain, domain_key, tag, sequence_no, administrator, date, sql, rollback_sql) values(:releaseId, :domain, :domainKey, :tag, :sequenceNo, :administrator, :date, :sql, :rollbackSql)";
        BeanPropertySqlParameterSource paramSource = new BeanPropertySqlParameterSource(change);
        namedJdbcTemplateConfigurator.update(sqlStatement, paramSource);
    }

    public void saveChangeReleaseId(Change change, String releaseTag) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("releaseTag", releaseTag);
        paramSource.addValue("changeTag", change.getTag());

        String sqlStatement =
            "update " + schema + ".change SET RELEASE_ID = (select id from " + schema +
                ".release where tag = :releaseTag) where tag = :changeTag";

        namedJdbcTemplateConfigurator.update(sqlStatement, paramSource);
    }

    public void deleteChange(Integer changeId) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("changeId", changeId);

        String sqlDeleteStatement =
            "delete from " + schema + ".change where id = :changeId";

        if (!isChangeInRelease(changeId)) {
            namedJdbcTemplateConfigurator.update(sqlDeleteStatement, paramSource);
        } else {
            throw new ChangeDeleteFailedException();
        }
    }

    public void rolloutChangeOnSourceDatabase(Change change) throws SQLException {
        String databaseSchema = applicationUtils.getDatabaseSchema(SOURCE_DB_SCHEMA);
        Connection connection = applicationUtils.getSourceDBConnection();
        rolloutChange(connection, databaseSchema, change, false);
    }

    public void rollbackChangeOnSourceDatabase(Change change) throws SQLException {
        String databaseSchema = applicationUtils.getDatabaseSchema(SOURCE_DB_SCHEMA);
        Connection connection = applicationUtils.getSourceDBConnection();
        rollbackChange(connection, databaseSchema, change, false);
    }

    private boolean isChangeInRelease(Integer changeId) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("changeId", changeId);

        String sql =
            "SELECT COUNT(id) FROM " + schema + ".change WHERE id = :changeId AND release_id IS NOT NULL";

        return namedJdbcTemplateConfigurator.queryForObject(sql, paramSource, Integer.class) > 0;
    }

    private void rolloutChange(Connection connection, String schema, Change change, boolean closeConnection) throws SQLException {
        String rolloutSql = "set schema '" + schema + "';";
        rolloutSql += change.getSql();
        runSqlScript(connection, rolloutSql, closeConnection);
    }

    private void rollbackChange(Connection connection, String schema, Change change, boolean closeConnection) throws SQLException {
        String rollbackSql = "set schema '" + schema + "';";
        rollbackSql += change.getRollbackSql();
        runSqlScript(connection, rollbackSql, closeConnection);
    }

}
