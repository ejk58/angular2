package nl.belastingdienst.iva.wd.configurator.domain.configurator;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class ReleaseEnvironment {
    private String domainKey;
    private Release release;
    private Environment environment;
    private String administrator;
    private Date deploymentDate;
}
