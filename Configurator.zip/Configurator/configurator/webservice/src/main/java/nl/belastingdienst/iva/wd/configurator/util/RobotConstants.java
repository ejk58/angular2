package nl.belastingdienst.iva.wd.configurator.util;

public class RobotConstants {
    private RobotConstants() { throw new UnsupportedOperationException(); }

    public static final String SPACES = "    ";

    public static final String EXAMPLE_STRING = "Configurator";
    public static final String EXAMPLE_INT = "1000";
    public static final String EXAMPLE_BOOLEAN = "False";
    public static final String EXAMPLE_EMPTY = "${EMPTY}";

    public static String typeToExampleValue(String type) {
        if ("STRING".equals(type)) {
            return EXAMPLE_STRING;
        } else if ("NUMBER".equals(type)) {
            return EXAMPLE_INT;
        } else if ("BOOLEAN".equals(type)) {
            return EXAMPLE_BOOLEAN;
        } else {
            return EXAMPLE_EMPTY;
        }
    }

}
