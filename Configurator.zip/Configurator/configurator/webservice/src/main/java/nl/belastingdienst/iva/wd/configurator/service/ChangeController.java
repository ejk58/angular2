package nl.belastingdienst.iva.wd.configurator.service;

import nl.belastingdienst.iva.wd.configurator.datasource.configurator.ConfiguratorChangeRepository;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.Change;
import nl.belastingdienst.iva.wd.configurator.domain.configurator.ChangeReleaseEnvironment;
import nl.belastingdienst.iva.wd.configurator.domain.exception.ChangeDeleteFailedException;
import nl.belastingdienst.iva.wd.configurator.util.ApplicationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.sql.SQLException;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/change")
public class ChangeController {

    @Autowired
    private ConfiguratorChangeRepository configuratorChangeRepository;

    @Autowired
    private ApplicationUtils applicationUtils;

    @GetMapping(value = "/overview")
    public ResponseEntity<List<ChangeReleaseEnvironment>> getChangesOverview() {
        List<ChangeReleaseEnvironment> changes = configuratorChangeRepository.getChangesReleaseEnvironmentInfo();
        return ResponseEntity.ok(changes);
    }

    @GetMapping(value = "/changes/{domainKey}")
    public ResponseEntity<List<Change>> getChangesForDomain(@PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }
        List<Change> changes = configuratorChangeRepository.getChangesForDomain(domainKey);
        return ResponseEntity.ok(changes);
    }

    @GetMapping(value = "/mostRecent/{domainKey}")
    public ResponseEntity<Change> getMostRecentChangeForDomain(@PathVariable String domainKey) {
        if (!applicationUtils.userHasAccessToDomain(domainKey)) {
            throw new AccessDeniedException(domainKey);
        }
        Change change = configuratorChangeRepository.getMostRecentChange(domainKey);
        return ResponseEntity.ok(change);
    }

    @GetMapping(value = "/allChangeTags")
    public ResponseEntity<List<String>> getAllChangeTags() {
        List<String> allChangeTags = configuratorChangeRepository.getAllChangeTags();
        return ResponseEntity.ok(allChangeTags);
    }

    @Transactional
    @DeleteMapping(value = "/delete/{changeId}")
    public ResponseEntity<String> deleteChange(@PathVariable Integer changeId) throws SQLException {
        Change changeToDelete = configuratorChangeRepository.getChange(changeId);
        if (changeToDelete == null) {
            throw new ChangeDeleteFailedException(ResponseMessages.CHANGE_NOT_EXISTS);
        }

        Change mostRecentChange = configuratorChangeRepository.getMostRecentChange(changeToDelete.getDomainKey());
        if (mostRecentChange == null) {
            throw new ChangeDeleteFailedException(ResponseMessages.CHANGE_NOT_EXISTS);
        }

        if (!changeToDelete.getId().equals(mostRecentChange.getId())) {
            throw new ChangeDeleteFailedException(ResponseMessages.CHANGE_NOT_MOST_RECENT);
        }
        if (changeToDelete.getReleaseId() != null) {
            throw new ChangeDeleteFailedException(ResponseMessages.CHANGE_IN_RELEASE);
        }
        if (!applicationUtils.userHasAccessToDomain(changeToDelete.getDomainKey())) {
            throw new AccessDeniedException(changeToDelete.getDomain());
        }

        configuratorChangeRepository.rollbackChangeOnSourceDatabase(changeToDelete);
        configuratorChangeRepository.deleteChange(changeId);
        return ResponseEntity.ok(ResponseMessages.CHANGE_DELETE_OK);
    }

}
