package nl.belastingdienst.iva.wd.configurator.domain.robot;

import lombok.Data;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.dto.RobotTestsDto;
import nl.belastingdienst.iva.wd.configurator.util.RobotConstants;
import java.util.Arrays;
import java.util.List;

@Data
public class RobotTestSettings {

    private RobotTestSettings() { throw new UnsupportedOperationException(); }

    public static String toRobot(Widget widget, RobotTestsDto testsDto) {
        StringBuilder robotBuilder = new StringBuilder();
        robotBuilder.append("*** Settings ***\n");

        robotBuilder.append("Documentation   ");
        List<String> documentation = Arrays.asList(testsDto.getDomain(), widget.getTitle());
        documentation.forEach(doc -> robotBuilder.append(doc).append(RobotConstants.SPACES));
        robotBuilder.append("\n");

        robotBuilder.append("Force Tags      ");
        List<String> forceTags = Arrays.asList(testsDto.getDomain(), testsDto.getPage(), widget.getTitle(), "Widget", "Draft");
        forceTags.forEach(forceTag -> robotBuilder.append(forceTag).append(RobotConstants.SPACES));
        robotBuilder.append("\n");

        robotBuilder.append("Library         ").append("RequestsLibrary\n");
        robotBuilder.append("Resource        ").append("${CURDIR}${/}..${/}..${/}..${/}resources${/}keywords.robot\n");
        robotBuilder.append("Suite Setup     ").append("run Keywords  Setup REST  AND  Login Rest  ").append(testsDto.getUser());

        return robotBuilder.toString();
    }
}

/*

*** Settings ***
Documentation   Invordering Balansgegevens
Force Tags      Invordering  Klantprofiel  Balansgegevens  Widget  Final
Library         RequestsLibrary
Resource        ${CURDIR}${/}..${/}..${/}..${/}resources${/}keywords.robot
Suite Setup     run Keywords  Setup REST  AND  Login Rest  ${USER_INVORDERING}

 */
