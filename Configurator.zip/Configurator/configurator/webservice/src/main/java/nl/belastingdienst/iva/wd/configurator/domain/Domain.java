package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "CONF_DOMAIN")
public class Domain {
    @Id
    private Integer id;
    private String key;
    private String name;

    @Column(name = "RELATION_VIP_QUERY_ID")
    private Integer relationVipQueryId;

    @Column(name = "RELATION_NOVIP_QUERY_ID")
    private Integer relationNoVipQueryId;

    @Column(name = "SEARCH_VIP_QUERY_ID")
    private Integer searchVipQueryId;

    @Column(name = "SEARCH_NOVIP_QUERY_ID")
    private Integer searchNoVipQueryId;

    private Integer index;
    private String iconname;

    @Column(name = "SUBJECT_QUERY_ID")
    private Integer subjectQueryId;

}
