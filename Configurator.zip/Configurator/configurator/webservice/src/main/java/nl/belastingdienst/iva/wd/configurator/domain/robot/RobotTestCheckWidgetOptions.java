package nl.belastingdienst.iva.wd.configurator.domain.robot;

import lombok.Data;
import nl.belastingdienst.iva.wd.configurator.domain.Widget;
import nl.belastingdienst.iva.wd.configurator.util.RobotConstants;
import java.util.stream.Collectors;

@Data
public class RobotTestCheckWidgetOptions {

    private RobotTestCheckWidgetOptions() { throw new UnsupportedOperationException(); }

    public static String toRobot(Widget widget) {
        StringBuilder robotBuilder = new StringBuilder();

        robotBuilder.append("REST Check Widget Options\n");
        robotBuilder.append("    [Tags]   REST\n");
        robotBuilder.append("    [Template]    REST Check Json Response\n");
        robotBuilder.append("\n");

        robotBuilder.append("    #field     name        row         options             values\n");
        robotBuilder.append("    type       ${EMPTY}    ${EMPTY}    ${WIDGETTYPE}       ").append(widget.getType()).append("\n");
        robotBuilder.append("\n");

        robotBuilder.append("    #field     name        row         options             description    label                     refreshInfo     widgets\n");
        robotBuilder.append("    options    ${EMPTY}    ${EMPTY}    ${WIDGETOPTIONS}    ").append(widget.getDescription() == null ? "None" : widget.getDescription()).append("            ").append(widget.getTitle()).append("    []              []\n");
        robotBuilder.append("\n");

        robotBuilder.append("    #field      name                   row    options                columnName                    columnType       label               maskable     composite   behaviour                filter\n");
        widget.getColumnList().forEach(widgetColumn -> {
            robotBuilder.append("    columns     " + widgetColumn.getQueryColumn().getName()).append(RobotConstants.SPACES);
            robotBuilder.append("0").append(RobotConstants.SPACES);
            robotBuilder.append("${COLUMNOPTIONS}").append(RobotConstants.SPACES);
            robotBuilder.append(widgetColumn.getQueryColumn().getName()).append(RobotConstants.SPACES);
            robotBuilder.append(widgetColumn.getType()).append(RobotConstants.SPACES);
            robotBuilder.append(widgetColumn.getLabel()).append(RobotConstants.SPACES);
            robotBuilder.append("False").append(RobotConstants.SPACES);
            robotBuilder.append("False").append(RobotConstants.SPACES);
            robotBuilder.append("visible").append(RobotConstants.SPACES);
            robotBuilder.append("None\n");
        });
        robotBuilder.append("\n");

        String columnNames = widget.getColumnList().stream().map(widgetColumn -> widgetColumn.getQueryColumn().getName()).collect(Collectors.joining(RobotConstants.SPACES));
        robotBuilder.append("    #field       name        row    options    ").append(columnNames);
        robotBuilder.append("\n");

        String exampleValues = widget.getColumnList().stream().map(widgetColumn -> RobotConstants.typeToExampleValue(widgetColumn.getType())).collect(Collectors.joining(RobotConstants.SPACES));
        widget.getColumnList().forEach(widgetColumn -> robotBuilder.append("    data         ${EMPTY}    0      ${fn}      ").append(exampleValues).append("\n"));

        return robotBuilder.toString();
    }

}

/*

REST Check Widget Options
    [Tags]   REST
    [Template]    REST Check Json Response

    #field     name        row         options             values
    type       ${EMPTY}    ${EMPTY}    ${WIDGETTYPE}       Table

    #field     name        row         options             description    label                     refreshInfo     widgets
    options    ${EMPTY}    ${EMPTY}    ${WIDGETOPTIONS}    None           Afgesloten vorderingen    []              []

    #field     name        row         options                  title          content
    helpTexts  ${EMPTY}    0           ${WIDGETHELPTEXTS}       Help           Totaal overzicht van de afgesloten vorderingen die zijn betaald/verminderd/oninbaar of verlaagd zijn.

    #field      name                   row    options                columnName                    columnType       label               maskable     composite   behaviour                filter
    columns     betaalgedrag_omschr    0      ${COLUMNOPTIONS}       betaalgedrag_omschr           STRING           Invorderingsfase    False        False       visible                  None
    columns     betaald_eur            0      ${COLUMNOPTIONS}       betaald_eur                   MONEY            Betaald             False        False       visible                  None
    columns     oninbaar_eur           0      ${COLUMNOPTIONS}       oninbaar_eur                  MONEY            Oninbaar            False        False       visible                  None
    columns     verlaagd_eur           0      ${COLUMNOPTIONS}       verlaagd_eur                  MONEY            Verlaagd            False        False       visible                  None
    columns     verminderd_eur         0      ${COLUMNOPTIONS}       verminderd_eur                MONEY            Verminderd          False        False       visible                  None

    #field       name        row    options    betaalgedrag_omschr       betaald_eur    oninbaar_eur    verlaagd_eur    verminderd_eur
    data         ${EMPTY}    0      ${fn}      Uitstel (3)               17888          2785            1075            17112
    data         ${EMPTY}    1      ${fn}      Massale proces (1)        977            0               10              0
    data         ${EMPTY}    2      ${fn}      Begin vervolging (1)      512            0               0               0
    data         ${EMPTY}    3      ${fn}      Insolventie (2)           8514           785             45              1112

 */
