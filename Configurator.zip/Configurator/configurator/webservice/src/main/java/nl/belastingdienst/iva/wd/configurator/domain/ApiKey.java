package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Data;

@Data
//@Entity
public class ApiKey {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String key;
    private String methoden;
}

