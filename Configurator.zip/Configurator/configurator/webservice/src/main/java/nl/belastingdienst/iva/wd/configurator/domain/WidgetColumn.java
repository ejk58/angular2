package nl.belastingdienst.iva.wd.configurator.domain;

import lombok.Getter;
import lombok.Setter;
import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "CONF_WIDGET_COLUMN")
public class WidgetColumn {

    @Id
    private int id;

    private int index;
    private String type;
    private String label;
    private String description;
    private String behaviour;
    private String filter;

    @OneToOne
    @JoinColumn(name = "QUERY_COLUMN_ID")
    private QueryColumn queryColumn;

    @OneToMany()
    @JoinColumn(name = "WIDGET_COLUMN_ID")
    private List<WidgetColumnAttribute> columnAttributeList;
}
