import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {catchError} from 'rxjs/operators';
import {AbstractDataService} from './abstract-data.service';
import {Environment} from '../domain/environment/environment';

@Injectable()
export class EnvironmentService extends AbstractDataService {

  private readonly environmentUrl = 'api/environment';

  getEnvironments(): Observable<Environment[]> {
    return this.http.get<Environment[]>(`${this.environmentUrl}`)
      .pipe(catchError(this.handleError));
  }

}
