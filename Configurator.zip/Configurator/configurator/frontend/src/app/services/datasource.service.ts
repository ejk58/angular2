import {AbstractDataService} from './abstract-data.service';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {catchError} from 'rxjs/operators';

@Injectable()
export class DatasourceService extends AbstractDataService {

  private readonly datasourcesUrl = '/api/datasources';

  getDatasourceViews(): Observable<any> {
    return this.http.get(this.datasourcesUrl + '/views')
      .pipe(catchError(this.handleError));
  }

  getViewColumns(viewName: string): Observable<string[]> {
    return this.http.get<string[]>(this.datasourcesUrl + '/columns/' + viewName)
      .pipe(catchError(this.handleError));
  }

  getQueryValidation(queryTemplate: string): Observable<string> {
    return this.http.get(this.datasourcesUrl + '/validate/' + queryTemplate, {responseType: 'text'})
      .pipe(catchError(this.handleError));
  }
}
