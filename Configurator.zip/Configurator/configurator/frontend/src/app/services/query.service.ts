import {Injectable} from '@angular/core';
import {catchError} from 'rxjs/operators';
import {AbstractDataService} from './abstract-data.service';
import {Observable} from 'rxjs';
import {Query} from '../domain/query/query';

@Injectable()
export class QueryService extends AbstractDataService {

  private readonly queryUrl = 'api/query';

  getQueryKeys(): Observable<string[]> {
    return this.http.get<string[]>(`${this.queryUrl}/keys`)
      .pipe(catchError(this.handleError));
  }

  getQuery(key: string): Observable<Query> {
    return this.http.get<Query>(`${this.queryUrl}/${key}`)
      .pipe(catchError(this.handleError));
  }

}
