import {Injectable} from '@angular/core';
import {catchError} from 'rxjs/operators';
import {AbstractDataService} from './abstract-data.service';
import {Observable} from 'rxjs';
import {Version} from '../domain/system/version';

@Injectable()
export class SystemService extends AbstractDataService {

  private readonly systemUrl = 'api/system';

  getVersion(): Observable<Version> {
    return this.http.get<Version>(`${this.systemUrl}/version`)
      .pipe(catchError(this.handleError));
  }
}
