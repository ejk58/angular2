import {Injectable} from '@angular/core';
import {catchError} from 'rxjs/operators';
import {AbstractDataService} from './abstract-data.service';
import {BehaviorSubject, Observable} from 'rxjs';
import {ApplicationDomain} from '../domain/application/application-domain';

@Injectable()
export class DomainService extends AbstractDataService {

  private readonly domainUrl = 'api/domain';
  private activeDomainLocal$: BehaviorSubject<ApplicationDomain> = new BehaviorSubject({domainId: '', domainName: ''});
  private activeDomainLocal: ApplicationDomain;

  get activeDomain$(): Observable<ApplicationDomain> {
    return this.activeDomainLocal$.asObservable();
  }

  get activeDomain(): ApplicationDomain {
    return this.activeDomainLocal;
  }

  public getDomains(): Observable<ApplicationDomain[]> {
    return this.http.get<ApplicationDomain[]>(`${this.domainUrl}`)
      .pipe(catchError(this.handleError));
  }

  public activateDomain(domain: ApplicationDomain): void {
    this.activeDomainLocal$.next(domain);
    this.activeDomainLocal = domain;
  }
}
