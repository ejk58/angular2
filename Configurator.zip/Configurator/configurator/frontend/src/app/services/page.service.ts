import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {catchError, map, switchMap} from 'rxjs/operators';
import {PageAndPageWidgets} from '../domain/dto/page-and-page-widgets';
import {PageDto} from '../domain/dto/page-dto';
import {Page} from '../domain/page/page';
import {AbstractDataService} from './abstract-data.service';
import {DomainService} from './domain.service';

@Injectable()
export class PageService extends AbstractDataService {

  private readonly pageUrl = 'api/page';

  constructor(http: HttpClient, private readonly domainService: DomainService) {
    super(http);
  }

  getAllPageKeys(): Observable<string[]> {
    return this.http.get<string[]>(`${this.pageUrl}/keys`)
      .pipe(catchError(this.handleError));
  }

  getPageKeysForDomain(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string[]>(`${this.pageUrl}/keys/${domain.domainId}`)
              .pipe(map(pageKeys => pageKeys ? pageKeys : undefined))
              .pipe(catchError(this.handleError));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getPage(pageKey: string): Observable<Page> {
    return this.http.get<Page>(`${this.pageUrl}/${pageKey}`)
      .pipe(catchError(this.handleError));
  }

  getWidgetsOnPage(pageKey: string): Observable<PageAndPageWidgets> {
    return this.http.get<PageAndPageWidgets>(`${this.pageUrl}/layout/${pageKey}`)
      .pipe(catchError(this.handleError));
  }

  getConfigurationQuery(layout: PageAndPageWidgets): Observable<string> {
    const layoutWithDomain = {...layout, groupDomain: this.domainService.activeDomain};
    return this.http.post(`${this.pageUrl}/configurationQuery`, layoutWithDomain, {responseType: 'text'});
  }

  changePageLayout(layout: PageAndPageWidgets): Observable<string> {
    const layoutWithDomain = {...layout, groupDomain: this.domainService.activeDomain};
    return this.http.post(`${this.pageUrl}/changeLayout`, layoutWithDomain, {responseType: 'text'});
  }

  newPage(pageDto: PageDto): Observable<string> {
    const pageDtoWithDomain = {...pageDto, groupDomain: this.domainService.activeDomain};
    return this.http.post(`${this.pageUrl}/new`, pageDtoWithDomain, {responseType: 'text'});
  }
}
