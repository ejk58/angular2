import {WizardData} from '../domain/wizard/wizard-data';
import {WizardRoute} from '../domain/wizard/wizard-route';
import {WizardStore} from '../domain/wizard/wizard-store';

export abstract class AbstractWizardService<T extends WizardData> {

  private readonly wizardRouteLocal: WizardRoute;
  private readonly wizardStoreLocal: WizardStore;
  private isCurrentStepValidLocal: boolean = false;

  protected constructor(wizardRoute: WizardRoute, wizardStore: WizardStore) {
    this.wizardRouteLocal = wizardRoute;
    this.wizardStoreLocal = wizardStore;
  }

  get wizardData(): T {
    return <T>this.wizardRouteLocal.currentStep.data;
  }

  set wizardData(wizardData: T) {
    this.wizardRouteLocal.currentStep.data = wizardData;
  }

  get isCurrentStepValid(): boolean {
    return this.isCurrentStepValidLocal;
  }

  set isCurrentStepValid(isCurrentStepValid: boolean) {
    this.isCurrentStepValidLocal = isCurrentStepValid;
  }

  protected resetWizardState(): void {
    this.wizardRouteLocal.reset();
    this.wizardStoreLocal.resetDataForWizard(this.wizardRouteLocal.name);
  }

  public abstract initializeWizard(): void;

}
