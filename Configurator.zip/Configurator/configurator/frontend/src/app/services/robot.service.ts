import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {catchError} from 'rxjs/operators';
import {RobotTests} from '../domain/dto/robot-tests';

import {AbstractDataService} from './abstract-data.service';

@Injectable()
export class RobotService extends AbstractDataService {

  private readonly robotUrl = 'api/robot';

  exportRobotScript(dto: RobotTests): Observable<string> {
    return this.http.post(`${this.robotUrl}/export`, dto, {responseType: 'text'})
      .pipe(catchError(this.handleError));
  }

}
