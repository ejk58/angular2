import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {catchError, map, switchMap} from 'rxjs/operators';
import {AbstractDataService} from './abstract-data.service';
import {Observable, of} from 'rxjs';
import {Widget} from '../domain/widget/widget';
import {WidgetWizardData} from '../wizards/widget-wizards/common/widget-wizard-data';
import {DomainService} from './domain.service';

@Injectable()
export class WidgetService extends AbstractDataService {

  private readonly widgetUrl = 'api/widget';

  constructor(http: HttpClient, private readonly domainService: DomainService) {
    super(http);
  }

  getWidget(name: string): Observable<Widget> {
    return this.http.get<Widget>(`${this.widgetUrl}/${name}`)
      .pipe(catchError(this.handleError));
  }

  getAllWidgetNames(): Observable<string[]> {
    return this.http.get<string[]>(`${this.widgetUrl}/names`)
      .pipe(catchError(this.handleError));
  }

  getWidgetNamesForDomain(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string[]>(`${this.widgetUrl}/names/${domain.domainId}`)
              .pipe(map(widgetNames => widgetNames ? widgetNames : undefined))
              .pipe(catchError(this.handleError));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getWidgetTypes(): Observable<string[]> {
    return this.http.get<string[]>(`${this.widgetUrl}/types`)
      .pipe(catchError(this.handleError));
  }

  saveWidget(widgetWizardData: WidgetWizardData): Observable<string> {
    const widgetDtoWithDomain = {
      widget: widgetWizardData.widget,
      widgetOriginal: widgetWizardData.widgetOriginal,
      tag: widgetWizardData.tag,
      groupDomain: this.domainService.activeDomain
    };
    return this.http.post(`${this.widgetUrl}/save`, widgetDtoWithDomain, {responseType: 'text'});
  }

}
