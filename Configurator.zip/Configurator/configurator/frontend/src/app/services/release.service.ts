import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {catchError, map, switchMap} from 'rxjs/operators';
import {AbstractDataService} from './abstract-data.service';
import {DomainService} from './domain.service';
import {NewReleaseWizardData} from '../wizards/new-release-wizard/new-release-wizard-data';
import {ReleaseRolloutInfo} from '../domain/release/release-rollout-info';
import {DeployReleaseWizardData} from '../wizards/deploy-release-wizard/deploy-release-wizard-data';
import {ReleaseDeployed} from '../domain/release/release-deployed';
import {Release} from '../domain/release/release';
import {RollbackReleaseWizardData} from '../wizards/rollback-release-wizard/rollback-release-wizard-data';

@Injectable()
export class ReleaseService extends AbstractDataService {

  private readonly releaseUrl = 'api/release';

  constructor(http: HttpClient, private readonly domainService: DomainService) {
    super(http);
  }

  getReleasesDeployed(): Observable<ReleaseDeployed[]> {
    return this.http.get<ReleaseDeployed[]>(`${this.releaseUrl}/deployed`)
      .pipe(catchError(this.handleError));
  }

  getReleasesNotDeployedForDomain(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string[]>(`${this.releaseUrl}/notDeployed/${domain.domainId}`)
              .pipe(map(releases => releases ? releases : undefined))
              .pipe(catchError(this.handleError));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getAllReleaseTags(): Observable<string[]> {
    return this.http.get<string[]>(`${this.releaseUrl}/allReleaseTags`)
      .pipe(catchError(this.handleError));
  }

  getRolloutInfoForDomain(environment: string): Observable<ReleaseRolloutInfo> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<ReleaseRolloutInfo>(`${this.releaseUrl}/rolloutInfo/${environment}/${domain.domainId}`)
              .pipe(map(releaseRolloutInfo => releaseRolloutInfo ? releaseRolloutInfo : undefined))
              .pipe(catchError(this.handleError));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getCurrentReleaseForDomain(environment: string): Observable<Release> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<Release>(`${this.releaseUrl}/currentRelease/${environment}/${domain.domainId}`)
              .pipe(map(release => release ? release : undefined))
              .pipe(catchError(this.handleError));
          } else {
            return of(undefined);
          }
        })
      );
  }

  save(releaseAndChanges: NewReleaseWizardData): Observable<string> {
    const releaseAndChangesWithDomain = {...releaseAndChanges, groupDomain: this.domainService.activeDomain};
    return this.http.post(`${this.releaseUrl}/save`, releaseAndChangesWithDomain, {responseType: 'text'});
  }

  delete(releaseId: number): Observable<string> {
    return this.http.delete(`${this.releaseUrl}/delete/${releaseId}`, {responseType: 'text'});
  }

  rollout(deployReleaseWizardData: DeployReleaseWizardData): Observable<string> {
    const dataWithDomain = {...deployReleaseWizardData, groupDomain: this.domainService.activeDomain};
    return this.http.post(`${this.releaseUrl}/rollout`, dataWithDomain, {responseType: 'text'});
  }

  rollback(rollbackReleaseWizardData: RollbackReleaseWizardData): Observable<string> {
    const dataWithDomain = {...rollbackReleaseWizardData, groupDomain: this.domainService.activeDomain};
    return this.http.post(`${this.releaseUrl}/rollback`, dataWithDomain, {responseType: 'text'});
  }

}
