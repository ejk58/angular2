import {Injectable} from '@angular/core';
import {catchError} from 'rxjs/operators';
import {AbstractDataService} from './abstract-data.service';
import {Observable} from 'rxjs';

@Injectable()
export class WidgetAttributeService extends AbstractDataService {

  getWidgetAttributes(): Observable<string[]> {
    return this.http.get<string[]>('/api/widget/attributekeys')
      .pipe(catchError(this.handleError));
  }

}
