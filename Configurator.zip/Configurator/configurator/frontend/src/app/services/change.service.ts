import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {catchError, map, switchMap} from 'rxjs/operators';
import {AbstractDataService} from './abstract-data.service';
import {HttpClient} from '@angular/common/http';
import {DomainService} from './domain.service';
import {ChangeReleaseEnvironmentInfo} from '../domain/change/change-release-environment-info';

@Injectable()
export class ChangeService extends AbstractDataService {

  private readonly changeUrl = 'api/change';

  constructor(http: HttpClient, private readonly domainService: DomainService) {
    super(http);
  }

  getMostRecentChange(): Observable<string> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string>(`${this.changeUrl}/mostRecent/${domain.domainId}`)
              .pipe(map(change => change ? change : undefined))
              .pipe(catchError(this.handleError));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getChangesForDomain(): Observable<string[]> {
    return this.domainService.activeDomain$
      .pipe(
        switchMap(domain => {
          if (domain?.domainId) {
            return this.http.get<string[]>(`${this.changeUrl}/changes/${domain.domainId}`)
              .pipe(map(changes => changes ? changes : undefined))
              .pipe(catchError(this.handleError));
          } else {
            return of(undefined);
          }
        })
      );
  }

  getAllChangeTags(): Observable<string[]> {
    return this.http.get<string[]>(`${this.changeUrl}/allChangeTags`)
      .pipe(catchError(this.handleError));
  }

  getChangesReleaseEnvironmentInfo(): Observable<ChangeReleaseEnvironmentInfo[]> {
    return this.http.get<ChangeReleaseEnvironmentInfo[]>(`${this.changeUrl}/overview`)
      .pipe(catchError(this.handleError));
  }

  delete(changeId: number): Observable<string> {
    return this.http.delete(`${this.changeUrl}/delete/${changeId}`, {responseType: 'text'});
  }

}
