export interface TableData {
  label: string;
  value: any;
}
