import {Release} from './release';

export interface ReleaseRolloutInfo {
  currentRelease: Release;
  nextRelease: Release;
}
