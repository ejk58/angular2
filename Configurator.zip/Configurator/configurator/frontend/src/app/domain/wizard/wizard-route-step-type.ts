export enum WizardRouteStepType {
  Selection = 0,
  Execution = 1,
  Success = 2,
  Error = 3
}
