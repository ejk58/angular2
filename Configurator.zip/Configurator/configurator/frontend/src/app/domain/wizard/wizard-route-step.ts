import {WizardRouteStepType} from './wizard-route-step-type';

export class WizardRouteStep<T> {

  private readonly nameLocal: string;
  private readonly labelLocal: string;
  private readonly typeLocal: WizardRouteStepType;
  private seqNrLocal: number;
  private dataLocal: T;

  constructor(name: string, type: WizardRouteStepType, label: string) {
    this.nameLocal = name;
    this.typeLocal = type;
    this.labelLocal = label;
  }

  get name(): string {
    return this.nameLocal;
  }

  get type(): WizardRouteStepType {
    return this.typeLocal;
  }

  get label(): string {
    return this.labelLocal;
  }

  get seqNr(): number {
    return this.seqNrLocal;
  }

  set seqNr(seqNr: number) {
    this.seqNrLocal = seqNr;
  }

  get data(): T {
    return this.dataLocal;
  }

  set data(data: T) {
    this.dataLocal = data;
  }

}
