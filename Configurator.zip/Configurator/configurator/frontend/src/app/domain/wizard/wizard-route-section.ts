import {WizardStep} from './wizard-step';

export class WizardRouteSection {

  private readonly stepsLocal: WizardStep[];

  constructor(steps: WizardStep[]) {
    this.stepsLocal = steps;
  }

  get steps(): WizardStep[] {
    return this.stepsLocal;
  }

}
