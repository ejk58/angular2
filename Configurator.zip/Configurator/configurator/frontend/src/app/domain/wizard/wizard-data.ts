import {WidgetWizardData} from '../../wizards/widget-wizards/common/widget-wizard-data';
import {RobotTestsWizardData} from '../../wizards/robot-tests-wizard/robot-tests-wizard-data';
import {ChangePageWizardData} from '../../wizards/change-page-wizard/change-page-wizard-data';
import {NewPageWizardData} from 'src/app/wizards/new-page-wizard/new-page-wizard-data';
import {NewReleaseWizardData} from '../../wizards/new-release-wizard/new-release-wizard-data';
import {DeployReleaseWizardData} from '../../wizards/deploy-release-wizard/deploy-release-wizard-data';
import {DeleteReleaseWizardData} from '../../wizards/delete-release-wizard/delete-release-wizard-data';
import {DeleteChangeWizardData} from '../../wizards/delete-change-wizard/delete-change-wizard-data';
import {RollbackReleaseWizardData} from '../../wizards/rollback-release-wizard/rollback-release-wizard-data';

export type WizardData =
  WidgetWizardData
  | ChangePageWizardData
  | NewPageWizardData
  | NewReleaseWizardData
  | DeployReleaseWizardData
  | RollbackReleaseWizardData
  | DeleteReleaseWizardData
  | RobotTestsWizardData
  | DeleteChangeWizardData;
