export interface ApplicationUser {
  userId: string;
  password: string;
}
