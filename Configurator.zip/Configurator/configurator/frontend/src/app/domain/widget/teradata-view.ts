export interface TeradataView {
  name: string,
  columns: string[]
}
