export interface WidgetColumnAttribute {
    key: string;
    value: string;
}
