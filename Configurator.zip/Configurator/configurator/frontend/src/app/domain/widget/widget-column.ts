import {QueryColumn} from '../query/query-column';
import {WidgetColumnAttribute} from './widget-column-attribute';

export interface WidgetColumn {
  id?: number;

  index: number;
  type: string;
  label: string;
  description: string;
  behaviour: string;
  filter: string;

  queryColumn: QueryColumn;
  columnAttributes: WidgetColumnAttribute[];
}
