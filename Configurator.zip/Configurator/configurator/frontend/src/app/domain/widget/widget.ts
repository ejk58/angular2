import {WidgetAttribute} from './widget-attribute';
import {PageWidget} from '../page/page-widget';
import {WidgetColumn} from './widget-column';
import {Query} from '../query/query';

export interface Widget {
  id: number;
  containerWidgetId?: string;
  index?: number;
  name: string;
  type: string;
  title: string;
  description?: string;
  refreshinfo: boolean;
  visible: boolean;

  query: Query;

  pageWidgets: PageWidget[];
  attributeList: WidgetAttribute[];
  columnList: WidgetColumn[];
}
