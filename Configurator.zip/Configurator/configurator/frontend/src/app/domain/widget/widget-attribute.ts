export interface WidgetAttribute {
  id: number;
  key: string;
  value: string;
}
