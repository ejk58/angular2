import {Change} from './change';
import {ReleaseDeployed} from '../release/release-deployed';

export interface ChangeReleaseEnvironmentInfo {
    change: Change;
    releaseEnvironment: ReleaseDeployed;
}
