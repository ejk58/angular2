
export interface Change {
  id: number;
  releaseId: number;
  domainKey: string;
  tag: string;
  sequenceNo: number;
  administrator: string;
  date: string;
  sql: string;
  rollbackSql: string;
}
