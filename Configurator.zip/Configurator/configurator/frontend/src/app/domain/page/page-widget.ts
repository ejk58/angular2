import {Page} from './page';
import {Widget} from '../widget/widget';

export interface PageWidget {
  id: number;
  gridColumns: number;
  rowIndex: number;
  columnIndex: number;
  page: Page;
  widget: Widget;
}
