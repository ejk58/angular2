import {QueryColumn} from './query-column';

export interface Query {
  id: number;
  type: number;
  viewname: string;
  querytemplate: string;
  key: string;
  datasource: number;
  columnList: QueryColumn[];
}
