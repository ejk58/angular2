export interface QueryColumn {
  index: number;
  name: string;
  alias: string;
  value: string;
  key: string;
  type: string;
  maskable: boolean;

  mandatory?: boolean;

  columnList: QueryColumn[];
}
