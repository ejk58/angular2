export enum QueryType {
  INTERNAL = 0,
  TERADATA = 1,
  DB2 = 2,
  REST = 3
}
