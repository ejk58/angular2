export class QueryFilter {
  public filterTemplate: string;
  public nofilterTemplate?: string;
  public parameter?: string;
}
