export interface PageDto {
  key: string;
  title: string;
  type: 'main' | 'detail';
  domainKey: string;
  tag: string;
}
