import { ApplicationDomain } from '../application/application-domain';
import {Page} from '../page/page';
import {PageWidget} from '../page/page-widget';

export interface PageAndPageWidgets {
  page: Page;
  initialWidgets: PageWidget[];
  widgets: PageWidget[];
  domain?: ApplicationDomain;
  tag: string;
}
