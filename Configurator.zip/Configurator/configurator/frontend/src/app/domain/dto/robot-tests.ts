export interface RobotTests {
  widgetName: string;
  domain: string;
  page: string;
  user: string;
}
