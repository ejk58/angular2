import {Component, OnInit} from '@angular/core';
import {ReleaseDeployed} from '../../domain/release/release-deployed';
import {ReleaseService} from '../../services/release.service';

@Component({
  selector: 'c-release-overview',
  templateUrl: './release-overview.component.html',
  styleUrls: ['./release-overview.component.scss']
})
export class ReleaseOverviewComponent implements OnInit {

  public releasesDeployed: ReleaseDeployed[] = [];

  constructor(private readonly releaseService: ReleaseService) { }

  ngOnInit(): void {
    this.getReleasesDeployed();
  }

  private getReleasesDeployed(): void {
    this.releaseService.getReleasesDeployed().subscribe(releasesDeployed => {
      this.releasesDeployed = releasesDeployed;
    });
  }
}
