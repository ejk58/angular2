import {Injectable} from '@angular/core';
import {ActivatedRoute, ActivatedRouteSnapshot, CanActivate, Router} from '@angular/router';
import {LoginService} from '../services/login.service';

@Injectable()
export class LoggedInGuard implements CanActivate {

  constructor(private loginService: LoginService, private router: Router, private activatedRoute: ActivatedRoute) {
  }

  canActivate(route: ActivatedRouteSnapshot) {
    if (!this.loginService.isLoggedInNow()) {
      // queryParamsHandling is NOT handled in a guard!
      return this.router.createUrlTree(['login'], { queryParams: route.queryParams });
    }
    return true;
  }
}
