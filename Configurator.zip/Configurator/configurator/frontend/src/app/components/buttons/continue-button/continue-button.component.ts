import {Component, EventEmitter, Input, Output} from '@angular/core';
import {AbstractWizardService} from '../../../services/abstract-wizard.service';
import {WizardData} from '../../../domain/wizard/wizard-data';

@Component({
  selector: 'c-continue-button',
  templateUrl: './continue-button.component.html',
  styleUrls: ['./continue-button.component.scss']
})
export class ContinueButtonComponent {

  @Input() hide: boolean;
  @Input() wizardService: AbstractWizardService<WizardData>;
  @Output() clicked: EventEmitter<void> = new EventEmitter<void>();

  public continue(): void {
    this.clicked.emit();
  }

}
