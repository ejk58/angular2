import {Pipe, PipeTransform} from '@angular/core';
import {DatePipe} from '@angular/common';

@Pipe({
  name: 'cDateTime'
})
export class DateTimePipe implements PipeTransform {

  constructor(private readonly ngDatePipe: DatePipe) { }

  transform(value: string): string {
    if (value == null) {
      return '';
    } else {
      try {
        return this.ngDatePipe.transform(value, 'dd-MM-yyyy HH:mm:ss');
      } catch (e) {
        return '';
      }
    }
  }
}
