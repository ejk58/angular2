import {Component, Input} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';

@Component({
  selector: 'c-success-step',
  templateUrl: './success-step.component.html',
  styleUrls: ['./success-step.component.scss']
})

export class SuccessStepComponent extends AbstractWizardStep {

  @Input() message: string;

  constructor() {
    super();
  }

  isStepValid(): void {
    // Intentionally left blank
  }

}
