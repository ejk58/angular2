import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Tag} from '../../../domain/tag/tag';
import {ReleaseService} from '../../../services/release.service';

@Component({
  selector: 'c-release-tag',
  templateUrl: './release-tag.component.html',
  styleUrls: ['./release-tag.component.scss']
})

export class ReleaseTagComponent implements OnInit {

  @Input() tag: string;
  @Output() tagChanged: EventEmitter<Tag> = new EventEmitter();

  private releaseTags: string[];

  public isTagUnique: boolean = true;

  constructor(private readonly releaseService: ReleaseService) {
  }

  ngOnInit(): void {
    this.getAllReleaseTags();
  }

  getAllReleaseTags(): void {
    this.releaseService.getAllReleaseTags().subscribe(releaseTags => {
      this.releaseTags = releaseTags;
      this.onTagChange();
    });
  }

  onTagChange(): void {
    this.tag = this.tag?.trim();
    this.isTagUnique = !this.releaseTags.includes(this.tag);
    const tag: Tag = {tag: this.tag, isUnique: this.isTagUnique};
    this.tagChanged.emit(tag);
  }

}

