import {Component, OnInit} from '@angular/core';
import {LoginService} from '../../services/login.service';
import {Observable} from 'rxjs';
import {ApplicationDomain} from '../../domain/application/application-domain';
import {DomainService} from '../../services/domain.service';
import {MenuItem} from 'primeng/api';
import {WizardStore} from '../../domain/wizard/wizard-store';

@Component({
  selector: 'c-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent implements OnInit {
  public isLoggedIn$: Observable<boolean>;
  public loggedInUser: string;
  public domainMenuItems: MenuItem[] = [];
  public activeDomain$: Observable<ApplicationDomain>;
  public accountMenuOpen: boolean = false;
  public pageMenuOpen: boolean = false;
  public isCurrentStepFirstStep$: Observable<boolean>;

  constructor(private loginService: LoginService, private domainService: DomainService, private wizardStore: WizardStore) {  }

  ngOnInit(): void {
    this.isLoggedIn$ = this.loginService.isLoggedIn();
    this.activeDomain$ = this.domainService.activeDomain$;
    this.isCurrentStepFirstStep$ = this.wizardStore.isCurrentStepFirstStep$;

    this.loginService.loggedInUser().subscribe(user => {
      this.loggedInUser = user;
      if (this.loggedInUser) {
        this.domainService.getDomains().subscribe(domains => {
          this.domainMenuItems = domains.map(domain => {
            return {label: domain.domainName, command: () => this.domainService.activateDomain(domain)};
          });
          this.domainService.activateDomain(domains[0]);
        });
      }
    });
  }

  logout(): void {
    this.accountMenuOpen = false;
    this.pageMenuOpen = false;
    this.loginService.logout();
  }

  public toggleAccountMenu(): boolean {
    return this.accountMenuOpen = !this.accountMenuOpen;
  }

  public togglePageMenu(): boolean {
    return this.pageMenuOpen = !this.pageMenuOpen;
  }

  public handlePageMenuOpen(event: boolean): void {
    this.pageMenuOpen = event;
  }

}
