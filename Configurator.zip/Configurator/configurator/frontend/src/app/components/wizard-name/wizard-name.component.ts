import {PageMenuService} from '../../services/page-menu.service';
import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'c-wizard-name',
  templateUrl: './wizard-name.component.html',
  styleUrls: ['./wizard-name.component.scss']
})

export class WizardNameComponent implements OnInit {

    public wizardName: string;

    constructor(private readonly pageMenuService: PageMenuService) {  }

    ngOnInit(): void {
      this.wizardName = this.pageMenuService.getCurrentMenuLabel();
    }
}
