import {Directive, DoCheck} from '@angular/core';
import {Observable} from 'rxjs';

@Directive()
// eslint-disable-next-line @angular-eslint/directive-class-suffix
export abstract class AbstractWizardStep implements DoCheck {

  public abstract isStepValid(): void;

  // Optional methods can't be abstract
  public executeChanges?(): Observable<string> {
    throw new Error('Bij een WizardStep van het type "Execution" moet de "executeChanges" methode worden geimplementeerd!');
  }

  ngDoCheck(): void {
    this.isStepValid();
  }

}
