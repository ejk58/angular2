import {Component, OnInit} from '@angular/core';
import {RobotTestsWizardService} from './robot-tests-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {RobotTestsWizardRoute} from './robot-tests-wizard-route';

@Component({
  selector: 'c-robot-tests-wizard',
  templateUrl: './robot-tests-wizard.component.html',
  styleUrls: ['./robot-tests-wizard.component.scss']
})
export class RobotTestsWizardComponent extends AbstractWizard implements OnInit {

  constructor(public readonly robotTestWizardService: RobotTestsWizardService,
              private readonly robotTestWizardRoute: RobotTestsWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(robotTestWizardService, robotTestWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.robotTestWizardService.initializeWizard();
  }

}
