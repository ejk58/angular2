import {RobotTests} from '../../domain/dto/robot-tests';
import {Execution} from '../../domain/execution/execution';

export interface RobotTestsWizardData {
  robotTests: RobotTests;
  execution: Execution;
}
