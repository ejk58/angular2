import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {RobotTests} from 'src/app/domain/dto/robot-tests';
import {RobotTestsWizardService} from '../../robot-tests-wizard.service';

@Component({
  selector: 'c-robot-tests-data-entry-step',
  templateUrl: './robot-tests-data-entry-step.component.html',
  styleUrls: ['./robot-tests-data-entry-step.component.scss']
})

export class RobotTestsDataEntryStepComponent extends AbstractWizardStep implements OnInit {

  public robotTests: RobotTests;

  constructor(private readonly robotTestsWizardService: RobotTestsWizardService) {
    super();
  }

  ngOnInit(): void {
    this.robotTests = this.robotTestsWizardService.wizardData.robotTests;
  }

  isStepValid(): void {
    this.robotTestsWizardService.isCurrentStepValid = (
      this.robotTests.domain != null && (this.robotTests.domain.trim().length !== 0) &&
      this.robotTests.page != null && (this.robotTests.page.trim().length !== 0) &&
      this.robotTests.user != null && (this.robotTests.user.trim().length !== 0)
    );
  }

}
