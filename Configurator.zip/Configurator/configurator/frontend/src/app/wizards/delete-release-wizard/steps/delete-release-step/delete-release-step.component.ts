import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {DeleteReleaseWizardService} from '../../delete-release-wizard.service';
import {ReleaseService} from '../../../../services/release.service';
import {Observable} from 'rxjs';
import {Release} from '../../../../domain/release/release';

@Component({
  selector: 'c-delete-release-step',
  templateUrl: './delete-release-step.component.html',
  styleUrls: ['./delete-release-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: DeleteReleaseStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class DeleteReleaseStepComponent extends AbstractWizardStep implements OnInit {

  public release: Release;
  public deleteRelease: boolean;

  constructor(private readonly deleteReleaseWizardService: DeleteReleaseWizardService,
              private readonly releaseService: ReleaseService) {
    super();
  }

  ngOnInit(): void {
    this.release = this.deleteReleaseWizardService.wizardData.release;
  }

  public executeChanges(): Observable<string> {
    return this.releaseService.delete(this.deleteReleaseWizardService.wizardData.release.id);
  }

  isStepValid(): void {
    this.deleteReleaseWizardService.isCurrentStepValid = this.deleteRelease != null && this.deleteRelease != false;
  }

}
