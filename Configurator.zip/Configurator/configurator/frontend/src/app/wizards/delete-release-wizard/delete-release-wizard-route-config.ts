import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {DeleteReleaseWizardRoute} from './delete-release-wizard-route';
import {DeleteReleaseWizardData} from './delete-release-wizard-data';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';
import {AppInjector} from '../../app-injector';
import {ExecutionStatus} from '../../domain/execution/execution-status';
import {DeleteReleaseWizardService} from './delete-release-wizard.service';

// Steps
const deleteReleaseSelectionStep: WizardRouteStep<DeleteReleaseWizardData> = new WizardRouteStep('deleteReleaseSelectionStep', WizardRouteStepType.Selection, 'Selecteer release');
const deleteReleaseStep: WizardRouteStep<DeleteReleaseWizardData> = new WizardRouteStep('deleteReleaseStep', WizardRouteStepType.Execution, 'Samenvatting');
const successStep: WizardRouteStep<DeleteReleaseWizardData> = new WizardRouteStep('successStep', WizardRouteStepType.Success, 'Succes');
const errorStep: WizardRouteStep<DeleteReleaseWizardData> = new WizardRouteStep('errorStep', WizardRouteStepType.Error, 'Fout');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([deleteReleaseSelectionStep, deleteReleaseStep]);
const sectionSuccess: WizardRouteSection = new WizardRouteSection([successStep]);
const sectionError: WizardRouteSection = new WizardRouteSection([errorStep]);
const sections: WizardRouteSection[] = [sectionMain, sectionSuccess, sectionError];

// Split-functions
const splitFunctionMain = (): WizardRouteSection => {
  const deleteReleaseWizardService: DeleteReleaseWizardService = AppInjector.get(DeleteReleaseWizardService);
  if (deleteReleaseWizardService.wizardData.execution.status === ExecutionStatus.Success) {
    return sectionSuccess;
  } else {
    return sectionError;
  }
};

// Splits
const splitMain: WizardRouteSplit = new WizardRouteSplit(sectionMain, splitFunctionMain);
const splits: WizardRouteSplit[] = [splitMain];

// RouteConfig
export const DeleteReleaseWizardRouteConfig: WizardRoute = new WizardRoute(DeleteReleaseWizardRoute.name, sections, splits, sectionMain);
