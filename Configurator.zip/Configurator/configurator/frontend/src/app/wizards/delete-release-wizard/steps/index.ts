import {DeleteReleaseSelectionStepComponent} from './delete-release-selection-step/delete-release-selection-step.component';
import {DeleteReleaseStepComponent} from './delete-release-step/delete-release-step.component';

export const list = [
  DeleteReleaseSelectionStepComponent,
  DeleteReleaseStepComponent
];
