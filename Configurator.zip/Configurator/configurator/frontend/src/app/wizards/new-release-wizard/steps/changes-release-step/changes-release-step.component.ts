import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {NewReleaseWizardService} from '../../new-release-wizard.service';
import {ReleaseService} from '../../../../services/release.service';
import {Observable} from 'rxjs';
import {Release} from '../../../../domain/release/release';
import {Tag} from '../../../../domain/tag/tag';

@Component({
  selector: 'c-changes-release-step',
  templateUrl: './changes-release-step.component.html',
  styleUrls: ['./changes-release-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: ChangesReleaseStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class ChangesReleaseStepComponent extends AbstractWizardStep implements OnInit {

  private isTagUnique: boolean = false;

  public changes: any[];
  public release: Release;

  constructor(private readonly newReleaseWizardService: NewReleaseWizardService,
              private readonly releaseService: ReleaseService) {
    super();
  }

  ngOnInit(): void {
    this.changes = this.newReleaseWizardService.wizardData.changes;
    this.release = {id: undefined, tag: undefined};
    this.newReleaseWizardService.wizardData.release = this.release;
  }

  public onTagChanged(tag: Tag): void {
    this.release.tag = tag.tag;
    this.isTagUnique = tag.isUnique;
  }

  public executeChanges(): Observable<string> {
    return this.releaseService.save(this.newReleaseWizardService.wizardData);
  }

  isStepValid(): void {
    this.newReleaseWizardService.isCurrentStepValid = this.release.tag != null && this.release.tag != '' && this.isTagUnique;
  }

}
