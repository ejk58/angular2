import {ChangesSelectionStepComponent} from './changes-selection-step/changes-selection-step.component';
import {ChangesReleaseStepComponent} from './changes-release-step/changes-release-step.component';

export const list = [
  ChangesSelectionStepComponent,
  ChangesReleaseStepComponent
];
