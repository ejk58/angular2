import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {NewReleaseWizardRoute} from './new-release-wizard-route';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {NewReleaseWizardData} from './new-release-wizard-data';
import {Execution} from '../../domain/execution/execution';

@Injectable()
export class NewReleaseWizardService extends AbstractWizardService<NewReleaseWizardData> {

  constructor(private readonly newReleaseWizardRoute: NewReleaseWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(newReleaseWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {changes: [], release: undefined, execution};
  }

}
