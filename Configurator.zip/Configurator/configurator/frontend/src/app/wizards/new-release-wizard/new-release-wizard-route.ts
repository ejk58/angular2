import {WizardRoute} from '../../domain/wizard/wizard-route';

export class NewReleaseWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when NewReleaseWizardService is used in NewReleaseWizardRouteConfig.
}
