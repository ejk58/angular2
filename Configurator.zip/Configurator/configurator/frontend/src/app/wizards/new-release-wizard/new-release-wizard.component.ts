import {Component, OnInit} from '@angular/core';
import {NewReleaseWizardService} from './new-release-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {NewReleaseWizardRoute} from './new-release-wizard-route';

@Component({
  selector: 'c-new-release-wizard',
  templateUrl: './new-release-wizard.component.html',
  styleUrls: ['./new-release-wizard.component.scss']
})
export class NewReleaseWizardComponent extends AbstractWizard implements OnInit {

  constructor(public newReleaseWizardService: NewReleaseWizardService,
              private readonly newReleaseWizardRoute: NewReleaseWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(newReleaseWizardService, newReleaseWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.newReleaseWizardService.initializeWizard();
  }

}
