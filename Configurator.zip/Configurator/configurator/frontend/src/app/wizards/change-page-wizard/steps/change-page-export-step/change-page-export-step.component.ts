import {Component, OnInit} from '@angular/core';
import {PageService} from 'src/app/services/page.service';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {ChangePageWizardService} from '../../change-page-wizard.service';
import {PageAndPageWidgets} from '../../../../domain/dto/page-and-page-widgets';

@Component({
  selector: 'c-change-page-export-step',
  templateUrl: './change-page-export-step.component.html',
  styleUrls: ['./change-page-export-step.component.scss']
})

export class ChangePageExportStepComponent extends AbstractWizardStep implements OnInit {

  public configurationQuery: string;
  public pageAndPageWidgets: PageAndPageWidgets;

  constructor(private readonly pageService: PageService,
              private readonly changePageWizardService: ChangePageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.pageAndPageWidgets = this.changePageWizardService.wizardData.pageAndPageWidgets;
    this.getConfigurationQuery();
  }

  private getConfigurationQuery(): void {
    this.pageService.getConfigurationQuery(this.pageAndPageWidgets).subscribe(response => {
      this.configurationQuery = response;
    });
  }

  public copyTextarea(): void {
    const copyTextarea: HTMLTextAreaElement = document.querySelector('#exportInputArea');
    copyTextarea.select();
    document.execCommand('copy');
    copyTextarea.setSelectionRange(0, 0);
  }

  public isStepValid(): void {
    this.changePageWizardService.isCurrentStepValid = true;
  }

}
