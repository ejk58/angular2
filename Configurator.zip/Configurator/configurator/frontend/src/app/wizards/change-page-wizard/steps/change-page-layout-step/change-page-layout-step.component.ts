import {Component, OnInit} from '@angular/core';
import {Page} from 'src/app/domain/page/page';
import {PageWidget} from 'src/app/domain/page/page-widget';
import {PageService} from 'src/app/services/page.service';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {ChangePageWizardService} from '../../change-page-wizard.service';
import {Direction} from '../../../../domain/page/direction';

@Component({
  selector: 'c-change-page-layout-step',
  templateUrl: './change-page-layout-step.component.html',
  styleUrls: ['./change-page-layout-step.component.scss']
})

export class ChangePageLayoutStepComponent extends AbstractWizardStep implements OnInit {

  public pageKey: string;
  public page: Page;
  public widgets: PageWidget[] = [];
  public rows: PageWidget[][] = [];

  constructor(private readonly pageService: PageService,
              private readonly changePageWizardService: ChangePageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.pageKey = this.changePageWizardService.wizardData.pageKey;
    if (this.changePageWizardService.wizardData.pageAndPageWidgets.page === undefined) {
      this.getPageInfoAndInitializeData();
    } else {
      this.initializeData();
    }
  }

  public moveWidgetToRow(currentRowIndex: number, currentColumnIndex: number, direction: Direction): void {
    if (this.cantMoveToRow(currentRowIndex, direction)) {
      return;
    }

    // When moving at the extremes, add a new empty row at beginning or end of array
    const isFirstRow: boolean = currentRowIndex === 0;
    const isLastRow: boolean = currentRowIndex === this.rows.length - 1;
    if (isFirstRow && direction === Direction.Up) {
      this.rows.unshift([]);
      currentRowIndex++; // Add 1 to currentRowIndex because new row is inserted at beginning of array
    }
    if (isLastRow && direction === Direction.Down) {
      this.rows.push([]);
    }

    // Move
    const pageWidgetToMove = this.rows[currentRowIndex][currentColumnIndex];
    this.rows[currentRowIndex].splice(currentColumnIndex, 1);
    this.rows[currentRowIndex + direction].splice(currentColumnIndex, 0, pageWidgetToMove);

    // Remove row if empty and update row and column indices
    this.removeRowIfEmpty(currentRowIndex);
    this.updateRowAndColumnIndices();
  }

  public moveWidgetInRow(row: PageWidget[], columnIndex: number, direction: Direction): void {
    if (this.cantMoveLeft(columnIndex, direction) || this.cantMoveRight(row, columnIndex, direction)) {
      return;
    }

    // Swap
    const columnIndexToSwapWith = columnIndex + direction;
    [row[columnIndex], row[columnIndexToSwapWith]] = [row[columnIndexToSwapWith], row[columnIndex]];

    // Update row and column indices
    this.updateRowAndColumnIndices();
  }

  public setPageWidgetWidth(pageWidget: PageWidget, gridColumns: number): void {
    pageWidget.gridColumns = gridColumns;
  }

  public removeWidgetFromRow(rowIndex: number, columnIndex: number): void {
    // Remove
    const widgetId = this.rows[rowIndex][columnIndex]['id'];
    this.rows[rowIndex].splice(columnIndex, 1);
    this.widgets.splice(this.widgets.findIndex(widget => widget.id === widgetId), 1);

    // Remove row if empty and update row and column indices
    this.removeRowIfEmpty(rowIndex);
    this.updateRowAndColumnIndices();
  }

  public cantMoveToRow(rowIndex: number, direction: Direction): boolean {
    const isAloneAtTheTop = rowIndex === 0 && this.rows[rowIndex].length === 1;
    const isAloneAtTheBottom = rowIndex === this.rows.length - 1 && this.rows[this.rows.length - 1].length === 1;
    return (isAloneAtTheTop && direction === Direction.Up) || (isAloneAtTheBottom && direction === Direction.Down);
  }

  public cantMoveLeft(columnIndex: number, direction: Direction): boolean {
    const isFirstPageWidgetInRow = columnIndex === 0;
    return isFirstPageWidgetInRow && direction === Direction.Left;
  }

  public cantMoveRight(row: PageWidget[], columnIndex: number, direction: Direction): boolean {
    const isLastPageWidgetInRow = columnIndex === row.length - 1;
    return isLastPageWidgetInRow && direction === Direction.Right;
  }

  public isRowTooWide(row: PageWidget[]): boolean {
    return row.reduce((total, pageWidget) => total + pageWidget.gridColumns, 0) > 4;
  }

  // Necessary for use of direction in html
  public get direction(): typeof Direction {
    return Direction;
  }

  private removeRowIfEmpty(rowIndex: number) {
    if (this.rows[rowIndex].length === 0) {
      this.rows.splice(rowIndex, 1);
    }
  }

  private updateRowAndColumnIndices() {
    this.rows.forEach((row, rowIndex) =>
      row.forEach((pageWidget, columnIndex) => {
        pageWidget.rowIndex = rowIndex + 1;
        pageWidget.columnIndex = columnIndex + 1;
      }));
  }

  private getPageInfoAndInitializeData(): void {
    this.pageService.getWidgetsOnPage(this.pageKey).subscribe(pageAndPageWidgets => {
      this.changePageWizardService.wizardData.pageAndPageWidgets = pageAndPageWidgets;
      this.initializeData();
    });
  }

  private initializeData() {
    this.page = this.changePageWizardService.wizardData.pageAndPageWidgets.page;
    this.widgets = this.changePageWizardService.wizardData.pageAndPageWidgets.widgets;
    this.rows = this.transformPageWidgetsIntoRows(this.widgets);
  }

  private transformPageWidgetsIntoRows(pageWidgets: PageWidget[]): any[] {
    const rows: PageWidget[][] = [];
    pageWidgets.forEach(pageWidget => {
      const row = rows[pageWidget.rowIndex - 1] || [];

      let i = 0;
      let inserted = false;
      while (i < pageWidget.columnIndex && i < 4) {
        const existingPageWidget = row[i];
        if (existingPageWidget) {
          if (existingPageWidget.columnIndex > pageWidget.columnIndex) {
            row.splice(i, 0, pageWidget);
            inserted = true;
            break;
          } else {
            i += existingPageWidget.gridColumns;
          }
        }
        i++;
      }

      if (!inserted) {
        row.splice(i, 0, pageWidget);
      }

      rows[pageWidget.rowIndex - 1] = row;
    });
    return rows.filter(() => true); // Remove 'holes' in array (due to settings in configuration file)
  }

  isStepValid(): void {
    this.changePageWizardService.isCurrentStepValid = !this.rows.some(row => this.isRowTooWide(row));
  }

}
