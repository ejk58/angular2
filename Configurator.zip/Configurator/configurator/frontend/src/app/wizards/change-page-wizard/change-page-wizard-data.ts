import {PageAndPageWidgets} from '../../domain/dto/page-and-page-widgets';
import {Execution} from '../../domain/execution/execution';

export interface ChangePageWizardData {
  pageKey: string;
  pageAndPageWidgets: PageAndPageWidgets;
  execution: Execution;
}
