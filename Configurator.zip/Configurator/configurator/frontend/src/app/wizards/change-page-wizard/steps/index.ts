import {ChangePageSelectionStepComponent} from './change-page-selection-step/change-page-selection-step.component';
import {ChangePageLayoutStepComponent} from './change-page-layout-step/change-page-layout-step.component';
import {ChangePageExportStepComponent} from './change-page-export-step/change-page-export-step.component';
import {ChangePageSummaryStepComponent} from './change-page-summary-step/change-page-summary-step.component';

export const list = [
  ChangePageSelectionStepComponent,
  ChangePageLayoutStepComponent,
  ChangePageExportStepComponent,
  ChangePageSummaryStepComponent
];
