import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {ChangePageWizardRoute} from './change-page-wizard-route';
import {ChangePageWizardData} from './change-page-wizard-data';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';
import {AppInjector} from '../../app-injector';
import {ExecutionStatus} from '../../domain/execution/execution-status';
import {ChangePageWizardService} from './change-page-wizard.service';

// Steps
const changePageSelectionStep: WizardRouteStep<ChangePageWizardData> = new WizardRouteStep('changePageSelectionStep', WizardRouteStepType.Selection, 'Selecteer een pagina');
const changePageLayoutStep: WizardRouteStep<ChangePageWizardData> = new WizardRouteStep('changePageLayoutStep', WizardRouteStepType.Selection, 'Deel de pagina in');
const changePageExportStep: WizardRouteStep<ChangePageWizardData> = new WizardRouteStep('changePageExportStep', WizardRouteStepType.Selection, 'Configuratie query');
const changePageSummaryStep: WizardRouteStep<ChangePageWizardData> = new WizardRouteStep('changePageSummaryStep', WizardRouteStepType.Execution, 'Samenvatting');
const successStep: WizardRouteStep<ChangePageWizardData> = new WizardRouteStep('successStep', WizardRouteStepType.Success, 'Succes');
const errorStep: WizardRouteStep<ChangePageWizardData> = new WizardRouteStep('errorStep', WizardRouteStepType.Error, 'Fout');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([changePageSelectionStep, changePageLayoutStep, changePageExportStep, changePageSummaryStep]);
const sectionSuccess: WizardRouteSection = new WizardRouteSection([successStep]);
const sectionError: WizardRouteSection = new WizardRouteSection([errorStep]);
const sections: WizardRouteSection[] = [sectionMain, sectionSuccess, sectionError];

// Split-functions
const splitFunctionMain = (): WizardRouteSection => {
  const changePageWizardService: ChangePageWizardService = AppInjector.get(ChangePageWizardService);
  if (changePageWizardService.wizardData.execution.status === ExecutionStatus.Success) {
    return sectionSuccess;
  } else {
    return sectionError;
  }
};

// Splits
const splitMain: WizardRouteSplit = new WizardRouteSplit(sectionMain, splitFunctionMain);
const splits: WizardRouteSplit[] = [splitMain];

// RouteConfig
export const ChangePageWizardRouteConfig: WizardRoute = new WizardRoute(ChangePageWizardRoute.name, sections, splits, sectionMain);
