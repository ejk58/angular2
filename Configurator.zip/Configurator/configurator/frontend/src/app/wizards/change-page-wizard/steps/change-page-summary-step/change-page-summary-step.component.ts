import {Component, OnInit} from '@angular/core';
import {PageService} from 'src/app/services/page.service';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {ChangePageWizardService} from '../../change-page-wizard.service';
import {Observable} from 'rxjs';
import {PageAndPageWidgets} from '../../../../domain/dto/page-and-page-widgets';
import {Tag} from '../../../../domain/tag/tag';
import {TableColumn} from '../../../../domain/table/table-column';
import * as _ from 'lodash-es';

@Component({
  selector: 'c-change-page-summary-step',
  templateUrl: './change-page-summary-step.component.html',
  styleUrls: ['./change-page-summary-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: ChangePageSummaryStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class ChangePageSummaryStepComponent extends AbstractWizardStep implements OnInit {

  private isTagUnique: boolean = false;
  public pageAndPageWidgets: PageAndPageWidgets;
  public colsWidgetsOnPage: TableColumn[];

  constructor(private readonly pageService: PageService,
              private readonly changePageWizardService: ChangePageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.pageAndPageWidgets = this.changePageWizardService.wizardData.pageAndPageWidgets;
    this.pageAndPageWidgets.initialWidgets = _.sortBy(this.pageAndPageWidgets.initialWidgets, ['rowIndex', 'columnIndex']);
    this.pageAndPageWidgets.widgets = _.sortBy(this.pageAndPageWidgets.widgets, ['rowIndex', 'columnIndex']);
    this.setColsForWidgetsOnPageTable();
  }

  public onTagChanged(tag: Tag): void {
    this.pageAndPageWidgets.tag = tag.tag;
    this.isTagUnique = tag.isUnique;
  }

  public executeChanges(): Observable<string> {
    return this.pageService.changePageLayout(this.pageAndPageWidgets);
  }

  public isStepValid(): void {
    this.changePageWizardService.isCurrentStepValid =
      this.pageAndPageWidgets.tag !== ''
      && this.pageAndPageWidgets.tag !== undefined
      && this.pageAndPageWidgets.tag !== null
      && this.isTagUnique;
  }

  private setColsForWidgetsOnPageTable(): void {
    this.colsWidgetsOnPage = [
      {field: 'widget.name', header: 'Widget naam'},
      {field: 'widget.title', header: 'Widget titel'},
      {field: 'rowIndex', header: 'Rijnummer'},
      {field: 'columnIndex', header: 'Kolomnummer'},
      {field: 'gridColumns', header: 'Breedte'}
    ];
  }

}
