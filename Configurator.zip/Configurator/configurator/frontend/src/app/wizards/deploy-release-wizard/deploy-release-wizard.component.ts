import {Component, OnInit} from '@angular/core';
import {DeployReleaseWizardService} from './deploy-release-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {DeployReleaseWizardRoute} from './deploy-release-wizard-route';

@Component({
  selector: 'c-deploy-release-wizard',
  templateUrl: './deploy-release-wizard.component.html',
  styleUrls: ['./deploy-release-wizard.component.scss']
})
export class DeployReleaseWizardComponent extends AbstractWizard implements OnInit {

  constructor(public deployReleaseWizardService: DeployReleaseWizardService,
              private readonly deployReleaseWizardRoute: DeployReleaseWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(deployReleaseWizardService, deployReleaseWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.deployReleaseWizardService.initializeWizard();
  }

}
