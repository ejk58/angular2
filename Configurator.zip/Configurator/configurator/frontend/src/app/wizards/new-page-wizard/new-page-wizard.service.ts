import {Injectable} from '@angular/core';
import {AbstractWizardService} from '../../services/abstract-wizard.service';
import {NewPageWizardRoute} from './new-page-wizard-route';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {NewPageWizardData} from './new-page-wizard-data';
import {Execution} from '../../domain/execution/execution';

@Injectable()
export class NewPageWizardService extends AbstractWizardService<NewPageWizardData> {

  constructor(private readonly newPageWizardRoute: NewPageWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(newPageWizardRoute, wizardStore);
  }

  public initializeWizard(): void {
    super.resetWizardState();
    const pageDto = {key: undefined, title: undefined, type: undefined, domainKey: undefined, tag: undefined};
    const execution: Execution = {status: undefined, message: undefined};
    this.wizardData = {pageKey: undefined, pageDto, execution};
  }

}
