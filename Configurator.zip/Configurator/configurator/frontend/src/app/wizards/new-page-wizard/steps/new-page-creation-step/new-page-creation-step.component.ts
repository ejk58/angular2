import {Component, OnInit} from '@angular/core';
import {PageService} from 'src/app/services/page.service';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {NewPageWizardService} from '../../new-page-wizard.service';
import {PageDto} from 'src/app/domain/dto/page-dto';
import {Observable} from 'rxjs';
import {Tag} from '../../../../domain/tag/tag';

@Component({
  selector: 'c-new-page-creation-step',
  templateUrl: './new-page-creation-step.component.html',
  styleUrls: ['./new-page-creation-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: NewPageCreationStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class NewPageCreationStepComponent extends AbstractWizardStep implements OnInit {

  private pageKey: string;
  private existingPageKeys: string[] = [];
  private isTagUnique: boolean = false;

  public pageDto: PageDto;
  public isPageKeyUnique: boolean = true;

  constructor(private readonly pageService: PageService,
              private newPageWizardService: NewPageWizardService) {
    super();
  }

  ngOnInit(): void {
    this.pageKey = this.newPageWizardService.wizardData.pageKey;
    this.pageDto = this.newPageWizardService.wizardData.pageDto;
    this.getAndCheckPageKeys();
  }

  private getAndCheckPageKeys(): void {
    this.pageService.getAllPageKeys().subscribe(pageKeys => {
      this.existingPageKeys = pageKeys;
      if (this.isUserCreatingNewPage()) {
        this.isPageKeyUnique = true;
      } else if (this.isUserExecutingStepForTheFirstTime()) {
        this.getPageAndFillPageDto(this.pageKey);
      } else {
        this.checkPageKey(this.pageDto.key);
      }
    });
  }

  private isUserCreatingNewPage(): boolean {
    return this.pageKey === null || this.pageKey === undefined;
  }

  private isUserExecutingStepForTheFirstTime(): boolean {
    return this.pageDto.key === undefined &&
      this.pageDto.title === undefined &&
      this.pageDto.type === undefined &&
      this.pageDto.tag === undefined;
  }

  private getPageAndFillPageDto(key: string): void {
    this.pageService.getPage(key).subscribe(page => {
      this.pageDto.key = page.key;
      this.pageDto.title = page.title;
      this.pageDto.type = page.type;
      this.checkPageKey(page.key);
    });
  }

  private checkPageKey(key: string): void {
    this.isPageKeyUnique = !this.existingPageKeys.includes(key.trim());
  }

  public onTagChanged(tag: Tag): void {
    this.pageDto.tag = tag.tag;
    this.isTagUnique = tag.isUnique;
  }

  public onPageDtoKeyChange(key: string): void {
    this.pageDto.key = key;
    this.checkPageKey(key);
  }

  public executeChanges(): Observable<string> {
    return this.pageService.newPage(this.newPageWizardService.wizardData.pageDto);
  }

  isStepValid(): void {
    this.newPageWizardService.isCurrentStepValid =
      this.pageDto.key != undefined && this.pageDto.key.trim().length > 0 && this.isPageKeyUnique &&
      this.pageDto.title != undefined && this.pageDto.title.trim().length > 0 &&
      this.pageDto.type != undefined &&
      this.pageDto.tag !== undefined && this.pageDto.tag.trim().length > 0 && this.pageDto.tag !== null && this.isTagUnique;
  }

}
