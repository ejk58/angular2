import {NewPageCreationStepComponent} from './new-page-creation-step/new-page-creation-step.component';
import {NewPageSelectionStepComponent} from './new-page-selection-step/new-page-selection-step.component';

export const list = [
  NewPageSelectionStepComponent,
  NewPageCreationStepComponent
];
