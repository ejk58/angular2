import {WizardRoute} from '../../domain/wizard/wizard-route';

export class NewPageWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when NewPageWizardService is used in NewPageWizardRouteConfig.
}
