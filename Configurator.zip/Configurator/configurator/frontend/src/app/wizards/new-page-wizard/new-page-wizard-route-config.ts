import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {NewPageWizardRoute} from './new-page-wizard-route';
import {NewPageWizardData} from './new-page-wizard-data';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';
import {AppInjector} from '../../app-injector';
import {ExecutionStatus} from '../../domain/execution/execution-status';
import {NewPageWizardService} from './new-page-wizard.service';

// Steps
const newPageSelectionStep: WizardRouteStep<NewPageWizardData> = new WizardRouteStep('newPageSelectionStep', WizardRouteStepType.Selection, 'Selecteer een pagina');
const newPageCreationStep: WizardRouteStep<NewPageWizardData> = new WizardRouteStep('newPageCreationStep', WizardRouteStepType.Execution, 'Maak een pagina');
const successStep: WizardRouteStep<NewPageWizardData> = new WizardRouteStep('successStep', WizardRouteStepType.Success, 'Succes');
const errorStep: WizardRouteStep<NewPageWizardData> = new WizardRouteStep('errorStep', WizardRouteStepType.Error, 'Fout');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([newPageSelectionStep, newPageCreationStep]);
const sectionSuccess: WizardRouteSection = new WizardRouteSection([successStep]);
const sectionError: WizardRouteSection = new WizardRouteSection([errorStep]);
const sections: WizardRouteSection[] = [sectionMain, sectionSuccess, sectionError];

// Split-functions
const splitFunctionMain = (): WizardRouteSection => {
  const newPageWizardService: NewPageWizardService = AppInjector.get(NewPageWizardService);
  if (newPageWizardService.wizardData.execution.status === ExecutionStatus.Success) {
    return sectionSuccess;
  } else {
    return sectionError;
  }
};

// Splits
const splitMain: WizardRouteSplit = new WizardRouteSplit(sectionMain, splitFunctionMain);
const splits: WizardRouteSplit[] = [splitMain];

// RouteConfig
export const NewPageWizardRouteConfig: WizardRoute = new WizardRoute(NewPageWizardRoute.name, sections, splits, sectionMain);
