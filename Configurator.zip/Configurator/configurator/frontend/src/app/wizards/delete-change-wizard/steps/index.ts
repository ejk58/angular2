import {DeleteChangeSelectionStepComponent} from './delete-change-selection-step/delete-change-selection-step.component';
import {DeleteChangeStepComponent} from './delete-change-step/delete-change-step.component';

export const list = [
  DeleteChangeSelectionStepComponent,
  DeleteChangeStepComponent
];
