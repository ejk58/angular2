import {Execution} from '../../domain/execution/execution';
import {Change} from '../../domain/change/change';

export interface DeleteChangeWizardData {
  change: Change;
  execution: Execution;
}
