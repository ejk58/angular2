import {WizardRoute} from '../../domain/wizard/wizard-route';

export class DeleteChangeWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when DeleteChangeWizardService is used in DeleteChangeWizardRouteConfig.
}
