import {RollbackReleaseChooseEnvironmentStepComponent} from './rollback-release-choose-environment-step/rollback-release-choose-environment-step.component';
import {RollbackReleaseChooseReleaseStepComponent} from './rollback-release-choose-release-step/rollback-release-choose-release-step.component';

export const list = [
  RollbackReleaseChooseEnvironmentStepComponent,
  RollbackReleaseChooseReleaseStepComponent
];
