import {WizardRoute} from '../../domain/wizard/wizard-route';
import {WizardRouteSection} from '../../domain/wizard/wizard-route-section';
import {WizardRouteSplit} from '../../domain/wizard/wizard-route-split';
import {WizardRouteStep} from '../../domain/wizard/wizard-route-step';
import {WizardRouteStepType} from '../../domain/wizard/wizard-route-step-type';
import {AppInjector} from '../../app-injector';
import {ExecutionStatus} from '../../domain/execution/execution-status';
import {RollbackReleaseWizardData} from './rollback-release-wizard-data';
import {RollbackReleaseWizardService} from './rollback-release-wizard.service';
import {RollbackReleaseWizardRoute} from './rollback-release-wizard-route';

// Steps
const rollbackReleaseChooseEnvironmentStep: WizardRouteStep<RollbackReleaseWizardData> = new WizardRouteStep('rollbackReleaseChooseEnvironmentStep', WizardRouteStepType.Selection, 'Selecteer een omgeving');
const rollbackReleaseChooseReleaseStep: WizardRouteStep<RollbackReleaseWizardData> = new WizardRouteStep('rollbackReleaseChooseReleaseStep', WizardRouteStepType.Execution, 'Selecteer een release');
const successStep: WizardRouteStep<RollbackReleaseWizardData> = new WizardRouteStep('successStep', WizardRouteStepType.Success, 'Succes');
const errorStep: WizardRouteStep<RollbackReleaseWizardData> = new WizardRouteStep('errorStep', WizardRouteStepType.Error, 'Fout');

// Sections
const sectionMain: WizardRouteSection = new WizardRouteSection([rollbackReleaseChooseEnvironmentStep, rollbackReleaseChooseReleaseStep]);
const sectionSuccess: WizardRouteSection = new WizardRouteSection([successStep]);
const sectionError: WizardRouteSection = new WizardRouteSection([errorStep]);
const sections: WizardRouteSection[] = [sectionMain, sectionSuccess, sectionError];

// Split-functions
const splitFunctionMain = (): WizardRouteSection => {
  const rollbackReleaseWizardService: RollbackReleaseWizardService = AppInjector.get(RollbackReleaseWizardService);
  if (rollbackReleaseWizardService.wizardData.execution.status === ExecutionStatus.Success) {
    return sectionSuccess;
  } else {
    return sectionError;
  }
};

// Splits
const splitMain: WizardRouteSplit = new WizardRouteSplit(sectionMain, splitFunctionMain);
const splits: WizardRouteSplit[] = [splitMain];

// RouteConfig
export const RollbackReleaseWizardRouteConfig: WizardRoute = new WizardRoute(RollbackReleaseWizardRoute.name, sections, splits, sectionMain);
