import {Component, OnDestroy, OnInit} from '@angular/core';
import {AbstractWizardStep} from 'src/app/common/abstract-wizard-step';
import {Release} from '../../../../domain/release/release';
import {ReleaseService} from 'src/app/services/release.service';
import {Observable, Subscription} from 'rxjs';
import {RollbackReleaseWizardService} from '../../rollback-release-wizard.service';

@Component({
  selector: 'c-rollback-release-choose-release-step',
  templateUrl: './rollback-release-choose-release-step.component.html',
  styleUrls: ['./rollback-release-choose-release-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: RollbackReleaseChooseReleaseStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class RollbackReleaseChooseReleaseStepComponent extends AbstractWizardStep implements OnInit, OnDestroy {

  public selectedEnvironment: string;
  public currentRelease: Release;
  public isChecked: boolean;
  private subscription: Subscription;

  constructor(private readonly rollbackReleaseWizardService: RollbackReleaseWizardService,
              private readonly releaseService: ReleaseService) {
    super();
  }

  ngOnInit(): void {
    this.selectedEnvironment = this.rollbackReleaseWizardService.wizardData.environment;
    this.getCurrentReleaseForDomain();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private getCurrentReleaseForDomain(): void {
    this.subscription = this.releaseService.getCurrentReleaseForDomain(this.selectedEnvironment).subscribe(currentRelease => {
      this.rollbackReleaseWizardService.wizardData.currentRelease = currentRelease;
      this.initializeData();
    });
  }

  private initializeData() {
    this.currentRelease = this.rollbackReleaseWizardService.wizardData.currentRelease;
  }

  public executeChanges(): Observable<string> {
    return this.releaseService.rollback(this.rollbackReleaseWizardService.wizardData);
  }

  isStepValid(): void {
    this.rollbackReleaseWizardService.isCurrentStepValid = this.isChecked;
  }

}
