import {Component, OnInit} from '@angular/core';
import {RollbackReleaseWizardService} from './rollback-release-wizard.service';
import {AbstractWizard} from '../../common/abstract-wizard';
import {WizardStore} from '../../domain/wizard/wizard-store';
import {RollbackReleaseWizardRoute} from './rollback-release-wizard-route';

@Component({
  selector: 'c-rollback-release-wizard',
  templateUrl: './rollback-release-wizard.component.html',
  styleUrls: ['./rollback-release-wizard.component.scss']
})
export class RollbackReleaseWizardComponent extends AbstractWizard implements OnInit {

  constructor(public rollbackReleaseWizardService: RollbackReleaseWizardService,
              private readonly rollbackReleaseWizardRoute: RollbackReleaseWizardRoute,
              private readonly wizardStore: WizardStore) {
    super(rollbackReleaseWizardService, rollbackReleaseWizardRoute, wizardStore);
  }

  ngOnInit(): void {
    this.rollbackReleaseWizardService.initializeWizard();
  }

}
