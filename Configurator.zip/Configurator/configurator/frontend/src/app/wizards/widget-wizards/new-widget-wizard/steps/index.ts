import {NewWidgetSelectionStepComponent} from './new-widget-selection-step/new-widget-selection-step.component';
import {NewWidgetCreationStepComponent} from './new-widget-creation-step/new-widget-creation-step.component';
import {NewQueryCreationStepComponent} from './new-query-creation-step/new-query-creation-step.component';

export const list = [
  NewWidgetSelectionStepComponent,
  NewWidgetCreationStepComponent,
  NewQueryCreationStepComponent
];
