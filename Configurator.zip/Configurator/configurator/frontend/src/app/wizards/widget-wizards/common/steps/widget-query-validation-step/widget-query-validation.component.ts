import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import {DatasourceService} from '../../../../../services/datasource.service';
import {Query} from '../../../../../domain/query/query';
import {Widget} from 'src/app/domain/widget/widget';
import {QueryColumn} from '../../../../../domain/query/query-column';
import {WidgetWizardService} from '../../widget-wizard.service';

@Component({
  selector: 'c-widget-query-validation-step',
  templateUrl: './widget-query-validation.component.html',
  styleUrls: ['./widget-query-validation.component.scss']
})

export class WidgetQueryValidationComponent extends AbstractWizardStep implements OnInit {

  public widget: Widget;
  public query: Query;

  public rawQueryString: string;
  public queryExecutionString: string;
  public teradataResult;
  public queryExcutionError: string;
  public resultTableColumns: { name: string, type: string }[] = [];
  public queryParameters: any[];
  public isValid = true;
  private stringTypes = [':string', ':fiscalnumber'];

  constructor(private readonly datasourceService: DatasourceService,
              private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.widget = this.widgetWizardService.wizardData.widget;
    this.query = this.widgetWizardService.wizardData.widget.query;

    const resultColumnString = this.constructResultColumns(this.query.columnList);
    this.rawQueryString = this.query.querytemplate.replace('{resultColumns}', resultColumnString);
    this.rawQueryString = this.rawQueryString.replace('{viewName}', this.query.viewname);

    this.queryParameters = this.getQueryParameters();
  }

  public executeQuery(): void {
    this.teradataResult = null;
    this.queryExcutionError = null;
    this.queryExecutionString = this.rawQueryString.slice();

    this.queryParameters.forEach(param => this.queryExecutionString =
      this.queryExecutionString.replace(param.key, this.isStringType(param.key) ? `'${param.value}'` : param.value));

    this.datasourceService.getQueryValidation(this.queryExecutionString).subscribe(result => {
      if (result && result.includes('fout opgetreden')) {
        this.queryExcutionError = result;
        this.isValid = false;
      } else {
        this.isValid = true;
        this.teradataResult = JSON.parse(result);
      }
    });
  }

  private getQueryParameters(): string[] {
    const result = [];
    const whereClause = this.rawQueryString.match(/WHERE.*/gi);
    if (whereClause && whereClause[0]) {
      const paramList = whereClause[0].match(/\{(\w+|):\w+\}/g);
      paramList.forEach(param => result.push({'key': param, 'value': ''}));
    }
    return result;
  }

  private constructResultColumns(columns: QueryColumn[]): string {
    return columns.map(column => {
      if (column['columnList']?.length > 0) {
        return this.constructResultColumns(column['columnList']);
      }
      if (column.alias) {
        this.resultTableColumns.push({
          'name': column.alias,
          'type': column.type
        });
        return `${column.name} as ${column.alias}`;
      } else {
        this.resultTableColumns.push({
          'name': column.name,
          'type': column.type
        });
        return `${column.name}`;
      }
    }
    ).join(',');
  }

  private isStringType(parameter: string): boolean {
    return this.stringTypes.some(element => parameter.includes(element));
  }

  isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid = this.isValid;
  }
}
