import {Component, OnInit} from '@angular/core';
import {WidgetService} from 'src/app/services/widget.service';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import {WidgetWizardService} from '../../../common/widget-wizard.service';
import {NieuwWidget} from '../../new-widget-wizard-constants';
import {SelectItem} from '../../../../../common/select-item';

@Component({
  selector: 'c-new-widget-selection-step',
  templateUrl: './new-widget-selection-step.component.html',
  styleUrls: ['./new-widget-selection-step.component.scss']
})
export class NewWidgetSelectionStepComponent extends AbstractWizardStep implements OnInit {

  public widgetNames: SelectItem[] = [];
  public selectedWidgetName: string;

  constructor(private readonly widgetService: WidgetService,
              private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.selectedWidgetName = this.widgetWizardService.wizardData.widget.name;
    this.getAllWidgetNames();
  }

  onSelectedWidgetNameChange(): void {
    this.widgetWizardService.initializeWizard();
    this.widgetWizardService.wizardData.widget.name = this.selectedWidgetName !== NieuwWidget ? this.selectedWidgetName : null;
  }

  public isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid =
      this.selectedWidgetName !== ''
      && this.selectedWidgetName !== undefined
      && this.selectedWidgetName !== null;
  }

  private getAllWidgetNames() {
    this.widgetService.getAllWidgetNames().subscribe(widgetNames => {
      this.widgetNames = widgetNames ? widgetNames.map(widgetName => ({label: widgetName, value: widgetName})) : [];
      this.widgetNames.unshift({label: NieuwWidget, value: NieuwWidget});
    });
  }

}
