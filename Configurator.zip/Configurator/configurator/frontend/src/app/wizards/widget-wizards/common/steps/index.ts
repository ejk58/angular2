import {QueryColumnCreationStepComponent} from './query-column-creation-step/query-column-creation-step.component';
import {WidgetColumnCreationStepComponent} from './widget-column-creation-step/widget-column-creation-step.component';
import {WidgetQueryValidationComponent} from './widget-query-validation-step/widget-query-validation.component';
import {WidgetAttributeStepComponent} from './widget-attribute-step/widget-attribute-step.component';
import {ConfigurationQueryStepComponent} from './configuration-query-step/configuration-query-step.component';
import {WidgetSummaryStepComponent} from './widget-summary-step/widget-summary-step.component';

export const list = [
  QueryColumnCreationStepComponent,
  WidgetColumnCreationStepComponent,
  WidgetQueryValidationComponent,
  WidgetAttributeStepComponent,
  ConfigurationQueryStepComponent,
  WidgetSummaryStepComponent
];
