import {Component, OnInit} from '@angular/core';
import {WidgetAttributeService} from '../../../../../services/widget-attribute.service';
import {WidgetAttribute} from '../../../../../domain/widget/widget-attribute';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import * as _ from 'lodash-es';
import {Widget} from 'src/app/domain/widget/widget';
import {WidgetWizardService} from '../../widget-wizard.service';
import {SelectItem} from '../../../../../common/select-item';

@Component({
  selector: 'c-widget-attribute-step',
  templateUrl: './widget-attribute-step.component.html',
  styleUrls: ['./widget-attribute-step.component.scss']
})

export class WidgetAttributeStepComponent extends AbstractWizardStep implements OnInit {

  private lastId: number = 0;

  public widget: Widget;
  public loading = false;
  public clonedSelectedWidgetAttributes: WidgetAttribute[] = [];
  public widgetAttributes: SelectItem[] = [];
  public selectedWidgetAttribute: string;

  constructor(private readonly widgetAttributeService: WidgetAttributeService,
              private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.widget = this.widgetWizardService.wizardData.widget;

    this.widgetAttributeService.getWidgetAttributes().subscribe(widgetAttributes => {
      if (widgetAttributes) {
        this.widgetAttributes = widgetAttributes.map(wa => {
          return {label: wa, value: wa};
        });
        this.selectedWidgetAttribute = this.widgetAttributes[0] ? this.widgetAttributes[0].value : undefined;
      } else {
        this.widgetAttributes = [];
      }
    });
  }

  public addWidgetAttribute(): void {
    this.loading = true;
    this.widget.attributeList.push({'key': this.selectedWidgetAttribute, 'value': '', 'id': this.lastId++});
    this.loading = false;
  }

  public removeWidgetAttribute(index: number): void {
    this.widget.attributeList.splice(index, 1);
  }

  onRowEditInit(selectedWidgetAttributes: WidgetAttribute): void {
    this.clonedSelectedWidgetAttributes[selectedWidgetAttributes.id] = _.cloneDeep(selectedWidgetAttributes);
  }

  onRowEditSave(selectedWidgetAttributes: WidgetAttribute): void {
    delete this.clonedSelectedWidgetAttributes[selectedWidgetAttributes.id];
  }

  onRowEditCancel(selectedWidgetAttributes: WidgetAttribute, index: number): void {
    this.widget.attributeList[index] = this.clonedSelectedWidgetAttributes[selectedWidgetAttributes.id];
    delete this.clonedSelectedWidgetAttributes[selectedWidgetAttributes.id];
  }

  public isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid = true;

    /*
    return this.widget.attributeList.every(attribute => {
      return attribute.key != null && attribute.key !== '' &&
             attribute.value != null && attribute.value !== ''
    });
    */
  }
}
