import {QueryColumn} from '../../../../../domain/query/query-column';
import {WidgetColumn} from '../../../../../domain/widget/widget-column';

export class WidgetAndQueryColumn {
  public queryColumn: QueryColumn;
  public widgetColumn: WidgetColumn;
  id: number;
}
