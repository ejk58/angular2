import {Component, OnInit} from '@angular/core';
import {WidgetService} from 'src/app/services/widget.service';
import {Widget} from 'src/app/domain/widget/widget';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import {Query} from 'src/app/domain/query/query';
import {WidgetWizardService} from '../../../common/widget-wizard.service';
import {SelectItem} from '../../../../../common/select-item';

@Component({
  selector: 'c-new-widget-creation-step',
  templateUrl: './new-widget-creation-step.component.html',
  styleUrls: ['./new-widget-creation-step.component.scss']
})
export class NewWidgetCreationStepComponent extends AbstractWizardStep implements OnInit {

  public widget: Widget;

  public givenWidgetName: string;
  public widgetNames: string[] = [];
  public widgetContainerNames: SelectItem[] = [];
  public widgetTypes: SelectItem[] = [];
  public selectedWidgetType: string;
  public selectedWidgetContainer: string;
  public uniqueWidgetName: boolean = true;
  public isContainerWidget: boolean = false;

  constructor(private readonly widgetService: WidgetService,
              private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.widget = this.widgetWizardService.wizardData.widget;

    this.widgetService.getAllWidgetNames().subscribe(widgetNames => {
      this.widgetNames = widgetNames;

      if (this.widget.name) {
        this.changeAndCheckWidgetName(this.widget.name);
        if (!this.uniqueWidgetName) {
          // if the widget already exists, that means we can load its config!
          this.givenWidgetName = this.widget.name;

          // TODO fix nested subscribe
          this.widgetService.getWidget(this.widget.name).subscribe(widget => {
            this.copyWidgetProperties(widget);
            this.widgetWizardService.wizardData.widgetOriginal = null;
          });
        }
      }

      this.widgetContainerNames = widgetNames.map(wn => {
        return {label: wn, value: wn};
      });
      this.selectedWidgetContainer = this.widgetContainerNames[0] ? this.widgetContainerNames[0].value : undefined;
    });

    this.widgetService.getWidgetTypes().subscribe(widgetTypes => {
      this.widgetTypes = widgetTypes.map(wt => {
        return {label: wt, value: wt};
      });
      this.selectedWidgetType = this.widgetTypes[0] ? this.widgetTypes[0].value : undefined;
    });
  }

  /**
   * Copy all properties of the given widget, while keeping the @Input() widget assignment intact (to share state with the wizard)
   */
  private copyWidgetProperties(original: Widget): void {
    this.widget.containerWidgetId = original.containerWidgetId;
    this.widget.index = original.index;
    this.widget.name = original.name;
    this.widget.type = original.type;
    this.widget.title = original.title;
    this.widget.description = original.description;
    this.widget.refreshinfo = original.refreshinfo;
    this.widget.visible = original.visible;

    this.copyQueryProperties(original.query);

    while (this.widget.pageWidgets.length > 0) {
      this.widget.pageWidgets.pop();
    }
    original.columnList.forEach(() => this.widget.pageWidgets.push());

    while (this.widget.attributeList.length > 0) {
      this.widget.attributeList.pop();
    }
    original.attributeList.forEach(att => this.widget.attributeList.push(att));

    while (this.widget.columnList.length > 0) {
      this.widget.columnList.pop();
    }
    original.columnList.forEach(c => this.widget.columnList.push(c));
  }

  /**
   * Copy all properties of the given Query, while keeping the @Input() widget assignment intact (to share state with the wizard)
   */
  private copyQueryProperties(original: Query): void {
    this.widget.query.id = original.id;
    this.widget.query.type = original.type;
    this.widget.query.viewname = original.viewname;
    this.widget.query.querytemplate = original.querytemplate;
    this.widget.query.key = original.key;
    this.widget.query.datasource = original.datasource;
    this.widget.query.columnList = original.columnList;
  }

  changeAndCheckWidgetName(widgetName: string): void {
    const uppercaseWidgetName = widgetName.toLocaleUpperCase();
    this.widget.name = uppercaseWidgetName;
    this.uniqueWidgetName = !this.widgetNames.includes(uppercaseWidgetName);
  }

  resetWidgetContainer() {
    this.widget.containerWidgetId = null;
  }

  resetWidgetIndex() {
    this.widget.index = null;
  }

  isIndexValid(): boolean {
    return this.widget.containerWidgetId ? this.widget.index != null : true;
  }

  isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid = this.widget.name && this.isIndexValid();
  }

}
