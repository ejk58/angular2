import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import {Widget} from '../../../../../domain/widget/widget';
import {WidgetWizardData} from '../../widget-wizard-data';
import {TableColumn} from '../../../../../domain/table/table-column';
import {TableData} from '../../../../../domain/table/table-data';
import {WidgetService} from '../../../../../services/widget.service';
import {WidgetWizardService} from '../../widget-wizard.service';
import {Observable} from 'rxjs';
import {Tag} from '../../../../../domain/tag/tag';
import {QueryType} from '../../../../../domain/query/query-type';


@Component({
  selector: 'c-widget-summary-step',
  templateUrl: './widget-summary-step.component.html',
  styleUrls: ['./widget-summary-step.component.scss'],
  providers: [{provide: AbstractWizardStep, useExisting: WidgetSummaryStepComponent}]
})

/**
 * Declaring 'Providers' is necessary to be able to use {@link AbstractWizardStep} in @ViewChild in {@link AbstractWizard}
 */
export class WidgetSummaryStepComponent extends AbstractWizardStep implements OnInit {

  private isTagUnique: boolean = false;

  public widget: Widget;
  public widgetWizardData: WidgetWizardData;

  public defaultCols: TableColumn[] = [{field: 'label', header: 'Naam'}, {field: 'value', header: 'Waarde'}];

  public widgetData: TableData[];
  public queryData: TableData[];
  public colsWidgetColumns: TableColumn[];
  public colsQueryColumns: TableColumn[];
  public colsWidgetAttributes: TableColumn[];

  constructor(private readonly widgetService: WidgetService,
              private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.widgetWizardData = this.widgetWizardService.wizardData;
    this.widget =  this.widgetWizardData.widget;

    this.setDataForWidgetTable();
    this.setDataForQueryTable();
    this.setColsForWidgetColumnsTable();
    this.setColsForQueryColumnsTable();
    this.setColsForWidgetAttributesTable();
  }

  public executeChanges(): Observable<string> {
    return this.widgetService.saveWidget(this.widgetWizardService.wizardData);
  }

  public onTagChanged(tag: Tag): void {
    this.widgetWizardData.tag = tag.tag;
    this.isTagUnique = tag.isUnique;
  }

  public isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid = this.widgetWizardData.tag !== '' && this.widgetWizardData.tag !== undefined && this.widgetWizardData.tag !== null && this.isTagUnique;
  }

  private setDataForWidgetTable(): void {
    this.widgetData = [
      {label: 'Type', value: this.widget.type},
      {label: 'Container', value: this.widget.containerWidgetId},
      {label: 'Index', value: this.widget.index},
      {label: 'Name', value: this.widget.name},
      {label: 'Title', value: this.widget.title},
      {label: 'Description', value: this.widget.description}
    ];
  }

  private setDataForQueryTable(): void {
    this.queryData = [
      {label: 'Key', value: this.widget.query.key},
      {label: 'Viewname', value: this.widget.query.viewname},
      {label: 'Datasource', value: this.widget.query.datasource['key']},
      {label: 'Type', value: QueryType[this.widget.query.type]},
      {label: 'Template', value: this.widget.query.querytemplate}
    ];
  }

  private setColsForWidgetColumnsTable(): void {
    this.colsWidgetColumns = [
      {field: 'label', header: 'Label'},
      {field: 'type', header: 'Type'},
      {field: 'description', header: 'Description'},
      {field: 'behaviour', header: 'Behaviour'},
      {field: 'filter', header: 'Filter'}
    ];
  }

  private setColsForQueryColumnsTable(): void {
    this.colsQueryColumns = [
      {field: 'name', header: 'Name'},
      {field: 'alias', header: 'Alias'},
      {field: 'value', header: 'Value'},
      {field: 'key', header: 'Key'},
      {field: 'type', header: 'Type'},
      {field: 'maskable', header: 'Maskable'},
      {field: 'mandatory', header: 'Mandatory'},
      {field: '', header: 'Query columns'} // TODO: nog goed vullen !!
    ];
  }

  private setColsForWidgetAttributesTable(): void {
    this.colsWidgetAttributes = [
      {field: 'key', header: 'Attribute'},
      {field: 'value', header: 'Value'}
    ];
  }

}
