import {Component, OnInit} from '@angular/core';
import {DatasourceService} from '../../../../../services/datasource.service';
import {QueryService} from '../../../../../services/query.service';
import {Query} from '../../../../../domain/query/query';
import {Widget} from 'src/app/domain/widget/widget';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import {TeradataView} from 'src/app/domain/widget/teradata-view';
import {WidgetWizardService} from '../../../common/widget-wizard.service';
import {SelectItem} from '../../../../../common/select-item';

@Component({
  selector: 'c-new-query-creation-step',
  templateUrl: './new-query-creation-step.component.html',
  styleUrls: ['./new-query-creation-step.component.scss']
})

export class NewQueryCreationStepComponent extends AbstractWizardStep implements OnInit {

  public widget: Widget;
  public query: Query;
  public teradataView: TeradataView;

  public teradataViewSelectItems: SelectItem[] = [];
  public newQuery: boolean = true;

  private teradataViews: any[] = [];
  private existingQueryKeys: string[] = [];

  constructor(private readonly datasourceService: DatasourceService,
              private readonly queryService: QueryService,
              private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.widget = this.widgetWizardService.wizardData.widget;
    this.query = this.widgetWizardService.wizardData.widget.query;
    this.teradataView = this.widgetWizardService.wizardData.teradataView;

    const enteredOnNewWidget = this.query.viewname == null;

    this.datasourceService.getDatasourceViews().subscribe(views => {
      this.teradataViews = views;
      this.teradataViewSelectItems = views.map(view => {
        return {label: view.viewName, value: view.viewName};
      });

      if (enteredOnNewWidget && views[0]) {
        this.query.viewname = views[0].viewName;
      }
      if (this.isTeradataTypeSelected()) {
        this.onTeradataViewDropdownChange(this.query.viewname);
      }
      if (!enteredOnNewWidget) {
        this.setInitialQueryKey();
      }
      this.changeAndCheckQueryKey(this.query.key);
    });

    this.queryService.getQueryKeys().subscribe(queryKeys => {
      this.existingQueryKeys = queryKeys;
    });
  }

  private setInitialQueryKey() {
    if (this.widget.name.endsWith('_WIDGET')) {
      this.query.key = this.widget.name.slice(0, -7);
    } else if (this.widget.name.endsWith('_CONTAINER')) {
      this.query.key = this.widget.name.slice(0, -10);
    }

    this.query.key = this.query.key + '_QUERY';
  }

  onQueryTypeGroupChange(): void {
    if (!this.isTeradataTypeSelected()) {
      this.teradataView.name = undefined;
      this.teradataView.columns = undefined;
    }
  }

  isTeradataTypeSelected(): boolean {
    return this.query.type === 1;
  }

  changeAndCheckQueryKey(value: string): void {
    const uppercaseQuery = value.toLocaleUpperCase();
    this.query.key = uppercaseQuery;
    this.newQuery = !this.existingQueryKeys.includes(uppercaseQuery);
  }

  onTeradataViewDropdownChange(selectedView: string) {
    const view = this.teradataViews.find(teradataView => teradataView.viewName === selectedView);
    this.teradataView.name = view.viewName;
    this.teradataView.columns = view.columnNames;
  }

  isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid = this.query.viewname != null && this.query.key != null && this.query.key !== '';
  }

}
