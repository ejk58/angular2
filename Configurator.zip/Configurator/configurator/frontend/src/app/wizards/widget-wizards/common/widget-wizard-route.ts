import {WizardRoute} from '../../../domain/wizard/wizard-route';

export class WidgetWizardRoute extends WizardRoute {
  // Necessary to prevent circular dependency when WidgetWizardService is used in WidgetWizardRouteConfig.
}
