import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import {Widget} from 'src/app/domain/widget/widget';
import {WidgetWizardService} from '../../widget-wizard.service';

@Component({
  selector: 'c-configuration-query-step',
  templateUrl: './configuration-query-step.component.html',
  styleUrls: ['./configuration-query-step.component.scss']
})

export class ConfigurationQueryStepComponent extends AbstractWizardStep implements OnInit {

  public widget: Widget;
  public configurationQuery: string;

  constructor(private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.widget = this.widgetWizardService.wizardData.widget;
    this.getConfigurationQuery();
  }

  public getConfigurationQuery(): void {
    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    const requestOptions: RequestInit = {method: 'POST', headers: myHeaders, body: JSON.stringify(this.widget), redirect: 'follow'};

    fetch('/api/widget/configurationQuery', requestOptions)
      .then(response => response.text())
      .then(result => this.configurationQuery = result)
      .catch(error => console.log('error', error));
  }

  public copyTextarea(): void {
    const copyTextarea: HTMLTextAreaElement = document.querySelector('#exportInputArea');
    copyTextarea.select();
    document.execCommand('copy');
    copyTextarea.setSelectionRange(0, 0);
  }

  public isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid = true;
  }

}
