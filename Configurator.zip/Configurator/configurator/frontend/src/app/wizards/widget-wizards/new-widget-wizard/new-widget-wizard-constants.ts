export const NieuwWidget: string = 'Nieuw Widget';
