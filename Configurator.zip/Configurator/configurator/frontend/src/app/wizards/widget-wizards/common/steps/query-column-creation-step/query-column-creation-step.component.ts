import {Component, OnInit} from '@angular/core';
import {AbstractWizardStep} from '../../../../../common/abstract-wizard-step';
import {WidgetAndQueryColumn} from './widget-and-query-column';
import {QueryFilter} from 'src/app/domain/query/query-filter';
import * as _ from 'lodash-es';
import {Widget} from 'src/app/domain/widget/widget';
import {Query} from 'src/app/domain/query/query';
import {TeradataView} from 'src/app/domain/widget/teradata-view';
import {WidgetWizardService} from '../../widget-wizard.service';
import {QueryColumn} from 'src/app/domain/query/query-column';
import {WidgetColumn} from 'src/app/domain/widget/widget-column';
import {SelectItem} from '../../../../../common/select-item';

@Component({
  selector: 'c-query-column-creation-step',
  templateUrl: './query-column-creation-step.component.html',
  styleUrls: ['./query-column-creation-step.component.scss']
})

export class QueryColumnCreationStepComponent extends AbstractWizardStep implements OnInit {

  public widget: Widget;
  public query: Query;
  public teradataView: TeradataView;

  private lastId = 0;
  private clonedColumns: WidgetAndQueryColumn[] = [];

  public widgetAndQueryColumnList: WidgetAndQueryColumn[];
  public queryFilters: QueryFilter[] = [];
  public viewColumnSelectItems: SelectItem[] = [];
  public viewColumn: string;

  public booleanOptions: any[] = [
    {label: 'False', value: false},
    {label: 'True', value: true}
  ];
  public typeOptions: any[] = [
    {label: 'STRING', value: 'STRING'},
    {label: 'NUMBER', value: 'NUMBER'},
    {label: 'MONEY', value: 'MONEY'},
    {label: 'PERCENTAGE', value: 'PERCENTAGE'},
    {label: 'DRILLDOWNSTRING', value: 'DRILLDOWNSTRING'},
    {label: 'PAGELINKSTRING', value: 'PAGELINKSTRING'},
    {label: 'ASSPECIFIED', value: 'ASSPECIFIED'}
  ];

  constructor(private readonly widgetWizardService: WidgetWizardService) {
    super();
  }

  ngOnInit(): void {
    this.widget = this.widgetWizardService.wizardData.widget;
    this.query = this.widgetWizardService.wizardData.widget.query;
    this.teradataView = this.widgetWizardService.wizardData.teradataView;

    if (this.teradataView) {
      this.viewColumnSelectItems = this.teradataView.columns.map(viewColumn => {
        return {label: viewColumn, value: viewColumn};
      });
      this.viewColumn = this.viewColumnSelectItems[0] ? this.viewColumnSelectItems[0].value : undefined;
    } else {
      this.viewColumnSelectItems = [];
    }

    if (this.query.columnList == undefined) {
      this.query.columnList = [];
    }

    this.widgetAndQueryColumnList = this.widget.columnList
      .map((widgetColumn, index) => ({
        'widgetColumn': widgetColumn,
        'queryColumn': (widgetColumn.queryColumn != undefined ? widgetColumn.queryColumn : this.createNewQueryColumn()),
        'id': index
      }));

    const queryColumnsWithoutWidgetColumnList = this.query.columnList
      .filter(queryColumn => !this.widgetAndQueryColumnList.some(column => column.queryColumn.index === queryColumn.index))
      .map((queryColumn, index) => ({
        'widgetColumn': undefined,
        'queryColumn': queryColumn,
        'id': index
      }));

    this.widgetAndQueryColumnList = this.widgetAndQueryColumnList.concat(queryColumnsWithoutWidgetColumnList);
    this.query.columnList = this.widgetAndQueryColumnList.map(column => column.queryColumn);
    this.query.columnList.forEach(queryColumn => {
      if (
        (queryColumn.alias === 'IS_VIP' || queryColumn.alias === 'vip_ind') ||
        (queryColumn.alias === 'PARENT' && this.widgetMustHaveParentColumn())
      ) {
        queryColumn.mandatory = true;
      }
    });
    this.addMandatoryOrExtraQueryColumns();
  }

  public addColumn(): void {
    const queryColumn = this.createNewQueryColumn();
    this.pushQueryColumn(queryColumn);
  }

  public removeColumn(index: number): void {
    if (this.widgetAndQueryColumnList[index].widgetColumn == undefined) {
      this.query.columnList.splice(index, 1);
      this.widgetAndQueryColumnList.splice(index, 1);
    }
  }

  onRowEditInit(column: WidgetAndQueryColumn): void {
    this.clonedColumns[column.id] = _.cloneDeep(column);
  }

  onRowEditSave(column: WidgetAndQueryColumn): void {
    delete this.clonedColumns[column.id];
    this.forceMandatoryColumns();
  }

  onRowEditCancel(column: WidgetAndQueryColumn, index: number): void {
    this.widgetAndQueryColumnList[index] = this.clonedColumns[column.id];
    this.query.columnList[index] = this.clonedColumns[column.id].queryColumn;
    delete this.clonedColumns[column.id];
  }

  public forceMandatoryColumns(): void {
    if (this.widget.columnList.some(widgetColumn => widgetColumn.queryColumn && widgetColumn.queryColumn.maskable)) {
      if (!this.isIsVipQueryColumnPresent()) {
        this.addIsVipQueryColumn();
      }
    } else {
      if (this.isIsVipQueryColumnPresent()) {
        const index = this.query.columnList.findIndex(queryColumn => queryColumn.alias === 'IS_VIP');
        this.query.columnList.splice(index, 1);
        this.widgetAndQueryColumnList.splice(index, 1);
      }
    }
  }

  public addQueryFilter(): void {
    this.queryFilters.push({filterTemplate: '', nofilterTemplate: null, parameter: null});
  }

  public removeQueryFilter(index: number): void {
    this.queryFilters.splice(index, 1);
  }

  private createNewQueryColumn(): QueryColumn {
    const nextIndex = this.query.columnList.reduce((maxIndex, column) => Math.max(maxIndex, column.index), 0) + 1;
    return {index: nextIndex, name: this.viewColumn, alias: null, value: null, key: null, type: null, maskable: false , columnList: []};
  }

  private pushQueryColumn(queryColumn: QueryColumn, widgetColumn?: WidgetColumn): void {
    this.query.columnList.push(queryColumn);

    this.widgetAndQueryColumnList.push({
      widgetColumn: widgetColumn,
      queryColumn: queryColumn,
      id: this.widgetAndQueryColumnList.length
    });
  }

  private addMandatoryOrExtraQueryColumns(): void {
    if (this.widgetMustHaveParentColumn()) {
      this.addParentColumn();
    }
  }

  private widgetMustHaveParentColumn(): boolean {
    return this.widget.type === 'TableCollapsible' || this.widget.type === 'FlexibleCollapsibleTable';
  }

  private addParentColumn(): void {
    const parentQueryColumn: QueryColumn = this.createNewQueryColumn();
    parentQueryColumn.name = '';
    parentQueryColumn.alias = 'PARENT';
    parentQueryColumn.type = 'NUMBER';
    parentQueryColumn.mandatory = true;

    const parentWidgetColumn: WidgetColumn = {
      index: this.widget.columnList.length,
      type: 'NUMBER',
      label: 'Parent',
      description: null,
      behaviour: 'invisible',
      filter: null,
      queryColumn: parentQueryColumn,
      columnAttributes: []
    };

    this.pushQueryColumn(parentQueryColumn, parentWidgetColumn);
  }

  private addIsVipQueryColumn(): void {
    const isVipQueryColumn: QueryColumn = this.createNewQueryColumn();
    isVipQueryColumn.name = ''; // ?
    isVipQueryColumn.alias = 'IS_VIP';
    isVipQueryColumn.type = 'NUMBER';
    isVipQueryColumn.mandatory = true;

    this.pushQueryColumn(isVipQueryColumn);
  }

  private isIsVipQueryColumnPresent(): boolean {
    return this.query.columnList.some(queryColumn => queryColumn.alias === 'IS_VIP');
  }

  public isStepValid(): void {
    this.widgetWizardService.isCurrentStepValid = true;
  }

}
