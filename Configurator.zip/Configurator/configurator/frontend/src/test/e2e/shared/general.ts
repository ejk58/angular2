'use strict';

import {browser, by, element, ElementFinder, protractor} from 'protractor';

/**
 * Wait until element is visible.
 * If not visible within 5 seconds an error will be thrown.
 *
 * @param {ElementFinder} elementFinder The element that needs to be visible.
 * */
export async function waitForElementVisible(elementFinder: ElementFinder, timeout: number = 5000): Promise<{}> {
  return browser.wait(await protractor.ExpectedConditions.visibilityOf(elementFinder), timeout, 'Element not visible.');
}

/**
 * Wait until element is not visible.
 * If not invisible within 5 seconds an error will be thrown.
 *
 * @param {ElementFinder} elementFinder The element that needs to be invisible.
 */
export async function waitForElementNotVisible(elementFinder: ElementFinder, timeout: number = 5000): Promise<{}> {
  return browser.wait(protractor.ExpectedConditions.invisibilityOf(elementFinder), timeout, 'Element is visible.');
}

/**
 * Wait until element is present.
 * If not present within 5 seconds an error will be thrown.
 *
 * @param {ElementFinder} elementFinder The element that needs to be present.
 * */
export async function waitForElementPresent(elementFinder: ElementFinder, timeout: number = 5000): Promise<{}> {
  return browser.wait(protractor.ExpectedConditions.presenceOf(elementFinder), timeout, 'Element not present.');
}

/**
 * Wait until element is not present.
 * If still present after 5 seconds an error will be thrown.
 *
 * @param {ElementFinder} elementFinder The element that should not be present.
 * */
export async function waitForElementNotPresent(elementFinder: ElementFinder, timeout: number = 5000): Promise<{}> {
  return browser.wait(protractor.ExpectedConditions.stalenessOf(elementFinder), timeout, 'Element is present.');
}

/**
 * Wait until all loading spinners on the page are gone.
 */
export async function waitForWidgetsLoaded(timeout: number = 15000): Promise<{}> {
  return browser.wait(protractor.ExpectedConditions.invisibilityOf(element(by.css('.fa-spin.loading'))), timeout, 'Elements are loading.');
}

/**
 * Replacement of browser.setLocation (Protractor) because that doesn't work in Angular 2+.
 *
 * @param (url) URL to navigate to
 */
export async function setLocation(url: string): Promise<{}> {
  return browser.executeScript(pUrl => window.location.href = `#/${pUrl}`, url);
}

export async function checkUrlContains(substring: string): Promise<{}> {
  return browser.wait(protractor.ExpectedConditions.urlContains(substring), 5000);
}

/**
 * Wait for 5 seconds to check if element is not clickable.
 * If not visible within 5 seconds an error will be thrown.
 *
 * @param {ElementFinder} elementFinder The element that needs to be visible.
 * */
export async function waitForElementNotClickable(elementFinder: ElementFinder, timeout: number = 5000): Promise<{}> {
  let ec = protractor.ExpectedConditions;
  return browser.wait(await ec.not(ec.elementToBeClickable(elementFinder)), timeout, 'Element is clickable.');
}

/**
 * Wait for 5 seconds to check if element is clickable.
 * If not visible within 5 seconds an error will be thrown.
 *
 * @param {ElementFinder} elementFinder The element that needs to be visible.
 * */
export async function waitForElementClickable(elementFinder: ElementFinder, timeout: number = 5000): Promise<{}> {
  return browser.wait(await protractor.ExpectedConditions.elementToBeClickable(elementFinder), timeout, 'Element is not clickable.');
}

/**
 * Check of a element has a given class.
 *
 * @param {ElementFinder} elementFinder The element that needs to be checked.
 * @param {string} elementClass Class to be checked.
 * */
export async function elementHasClass(elementFinder: ElementFinder, elementClass: string): Promise<{}> {
  return elementFinder.getAttribute('class').then(function (classes) {
    return classes.split(' ').indexOf(elementClass) !== -1;
  });
};
