'use strict'

export const APPURL = {
  baseUrl: 'https://configurator.apps.dtap.belastingdienst.nl/', // voorbeeld
  pageId: {
    login: 'login'
  }
};

export const CONFIGURATOR_USER = {
  user: {
    ivatest1: 'ivatest1',
    ivatest2: 'ivatest2',
    password: 'Welkom01'
  }
};
