#!/bin/bash
oc delete project wd-inzicht-configurator
sleep 10
