#!/bin/bash
oc new-project wd-inzicht-configurator --description="Team Inge" --display-name="Inzicht Configurator"
oc process openshift//jenkins-cpet | oc create -f -
oc import-image registry.chp.belastingdienst.nl/redhatio/openjdk-11-rhel7:latest --confirm
./process "rolebinding-Alle teamleden.yaml"
./process inzicht-configurator-pipeline.yaml
