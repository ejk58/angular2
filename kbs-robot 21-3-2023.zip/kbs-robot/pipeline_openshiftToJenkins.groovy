@Library("GENERIC") _
    pipelineTest_v2_openshift {
		deploymentId = "ivakbs"
        robotTestPath = "iva-klantbehandelsysteem-robot/testsuites"
        robotArguments = "--include FINAL --exclude NIGHTLY"
        robotNonCriticals = "--skiponfailure NONCRITICAL --skiponfailure BUG"
        environmentChoices = "ont\ntst\nacc"
        streetChoices = "1\n2\n3"
        convertNumericStreetChoicesToStrxx = "true"
    }