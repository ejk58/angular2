# KBS robot tests

## How to run tests?
For the testing of KBS we make use of the BrowserLibrary. For this library you will need a valid NodeJs installation. Follow the steps on https://robotframework-browser.org/ to install this library. Note: Make sure to run the command 'rfbrowser init'. Or optionally 'rfbrowser init --skip-browsers'.

Now, everything necessary to test is installed. However, we make use of your local chrome installation to run the browser, meaning you will need to create a file caled local.resource in the iva-klantbehandelsysteem-robot/resources folder. This file needs to contain the following information:
```*** Variables ***
${LOCAL_CHROME}  C:/Program Files/Google/Chrome/Application/chrome.exe
```
**Make sure to update this to match your local chrome when copying!!!**
In Jenkins, we will insert this variable through the command line, to match the location of chrome on the server/in the container.

### Running locally
If you want to run against a local version of KBS, make sure your database is build with context ONT or TST. The 'TEST_ENTITEITEN' table is only built within these contexts!!!

You also need to copy the local.resource.template, name it local.resource and update the variables. The last step is to change the environment in variables.resource to local

## Parallel testing
Check https://confluence.belastingdienst.nl/display/CM/Parallel+Testing for more information