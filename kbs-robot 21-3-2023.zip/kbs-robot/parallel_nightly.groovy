pipelineTestParallel_v1 {
		deploymentId = "kbs"
		project = "kbs"
            robotTestPath = "iva-klantbehandelsysteem-robot/testsuites"
            robotArguments = "-i FINAL -i NIGHTLY -v PARALLEL:True -v LOCAL_CHROME:/opt/google/chrome/chrome"
            robotNonCriticals = "--skiponfailure NONCRITICAL --skiponfailure BUG"
            robotDir = "/srv/jenkins/home/robotframework_413/bin/"
            environmentChoices = "ont\ntst\nacc"
            robotRunner=pabot
            splitlevel = "SUITE"
            streetChoices = "str11\nstr12\nstr13"
            pabotProcesses=8
    	pipelineTrigger = [cron('H 22 * * *')]
        }
