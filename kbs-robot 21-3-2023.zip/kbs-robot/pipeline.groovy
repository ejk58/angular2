    pipelineTest_v4a {
		  deploymentId = "kbs"
		  project = "kbs"
        robotTestPath = "iva-klantbehandelsysteem-robot/testsuites"
        robotArguments = "--include FINAL --exclude NIGHTLY"
        robotNonCriticals = "--skiponfailure BUG"
        robotDir = "/srv/jenkins/home/robotframework_413/bin/"
      environmentChoices = "ont\ntst\nacc"
      streetChoices = "str11\nstr12\nstr13"
    }
