from datetime import datetime, timedelta
import time
from robot.api import logger
from robot.libraries.BuiltIn import BuiltIn
from robot.api.deco import not_keyword, keyword
import jaydebeapi
import random
import string
import pprint

all_middel_ids = [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30]

kolommen_klantsessie =                        "ID, ENTITEIT_NUMMER, STARTDATUM, EINDDATUM, CONTROLE_PLAATSGEVONDEN, ACT_GEBASEERD_GEHOUDEN_KLANTSESSIE, TOELICHTING_GEHOUDEN_KLANTSESSIE"
kolommen_klantsessie_ex_toelichting =         "ID, ENTITEIT_NUMMER, STARTDATUM, EINDDATUM, CONTROLE_PLAATSGEVONDEN, ACT_GEBASEERD_GEHOUDEN_KLANTSESSIE"
kolommen_klantsessie_zooef =                  "KLANTSESSIE_ID, MIDDEL_ID, OBSERVATIES, VORIGE_OBSERVATIES_NOG_ACTUEEL"
kolommen_klantsessie_compliance =             "KLANTSESSIE_ID, MIDDEL_ID, KENMERK_ID, SCORE, TOELICHTING"
kolommen_klantsessie_compliance_per_proces =  "KLANTSESSIE_ID, MIDDEL_ID, VOOROVERLEG, HEFFING, BEZWAREN"
kolommen_klantsessie_strategie =              "KLANTSESSIE_ID, MIDDEL_ID, KORTE_TERMIJN, MIDDELLANGE_TERMIJN"
kolommen_klantsessie_status =                 "KLANTSESSIE_ID, MIDDEL_ID, ZOOEF_STATUS,COMPLIANCE_STATUS,STRATEGIE_STATUS,VOORBEREIDING_AFRONDEN_STATUS,VOORBEREIDING_AFGEROND"
kolommen_klantsessie_strategie_risicos =      "KLANTSESSIE_ID, MIDDEL_ID, RISICO_ID"
kolommen_klantsessie_resultaat =              "KLANTSESSIE_ID, KENMERK_ID, SCORE, STRATEGIE_GERICHT_OP, TOELICHTING"

query_insert_middel      = "INSERT INTO ENTITEIT_KENMERK (BSN_RSIN, KENMERK_TYPE, KENMERK_ID) (SELECT {entiteitNummer}, 'MID', {middel} FROM sysibm.sysdummy1 WHERE NOT EXISTS (SELECT * FROM ENTITEIT_KENMERK WHERE BSN_RSIN={entiteitNummer} AND KENMERK_ID={middel}))"
query_insert_klantsessie = "INSERT INTO KLANTSESSIE ({kolommenKlantsessie}) VALUES ({id},'{entiteitNummer}', {timeStampStart}, {timeStampEnd}, {controle}, {actualiseren}, '{toelichting}')"
query_insert_klantsessie_no_toelichting = "INSERT INTO KLANTSESSIE ({kolommenKlantsessie}) VALUES ({id},'{entiteitNummer}', {timeStampStart}, {timeStampEnd}, {controle}, {actualiseren})"
query_zooef_observaties =  "INSERT INTO KLANTSESSIE_ZOOEF ({kolommenKlantsessieZooef}) VALUES ('{klantsessieId}', '{middelId}', '{observaties}', '{observatiesActueel}')"
query_compliance =         "INSERT INTO KLANTSESSIE_COMPLIANCE ({kolommenKlantsessieCompliance}) VALUES ('{klantsessieId}', {middelId}, {aspectId}, {score}, '{toelichting}')"
query_compliance_proces =  "INSERT INTO KLANTSESSIE_COMPLIANCE_PER_PROCESS ({kolommenKlantsessieCompliancePerProces}) VALUES ('{klantsessieId}', {middelId}, {vooroverlegValue}, {heffingValue}, {bezwarenValue})"
query_strategie =          "INSERT INTO KLANTSESSIE_STRATEGIE ({kolommenKlantsessieStrategie}) VALUES ('{klantsessieId}', {middelId}, '{strategieKorteTermijn}', '{strategieMiddellangeTermijn}')"
query_klantsessie_status = "INSERT INTO KLANTSESSIE_STATUS ({kolommenKlantsessieStatus}) VALUES ('{klantsessieId}', {middelId}, '{zooefStatus}', '{complianceStatus}','{strategieStatus}', '{voorbereidingStatus}',{voorbereidingAfgerond})"
query_strategie_risico   = "INSERT INTO KLANTSESSIE_STRATEGIE_RISICOS ({kolommenKlantsessieRisicos}) VALUES ({klantsessieId},{middelId},{risicoId})"
query_resultaat          = "INSERT INTO KLANTSESSIE_UITKOMST ({kolommenKlantsessieResultaat}) VALUES ('{klantsessieId}', {aspectId}, {score}, {strategie}, '{toelichting}')"

aspect_positief_beeld =      {"name": "Positief beeld", "id": 147}
aspect_gedeeld_belang =      {"name": "Gedeeld belang ", "id": 148}
aspect_mogelijkheid_vragen = {"name": "Mogelijkheid vragen/controle", "id": 150}
aspect_deskundigheid =       {"name": "Deskundigheid", "id": 151}
aspect_open_communicatie =   {"name": "Open communicatie", "id": 153}
aspect_openheid =            {"name": "Openheid verstoringen", "id": 154}
aspect_duidelijkheid =       {"name": "Duidelijkheid verwachtingen", "id": 155}
aspect_list = [aspect_positief_beeld, aspect_gedeeld_belang, aspect_mogelijkheid_vragen, aspect_deskundigheid, aspect_open_communicatie, aspect_openheid, aspect_duidelijkheid]

@not_keyword
def connect_to_db2():
    db2_class =          BuiltIn().get_variable_value("${DB2_CLASS}")
    db2_connect_string = BuiltIn().get_variable_value("${DB2_CONNECT_STRING}")
    db2_login =          BuiltIn().get_variable_value("@{DB2_LOGIN}")
    db_drivers =         BuiltIn().get_variable_value("@{DB-DRIVERS}")
    db_schema =          BuiltIn().get_variable_value("${DB2_SCHEMA}")
    logger.debug("Connecting to Database")
    db_connect_string="'{db2_class}', '{db2_connect_string}', {db2_login}, {db_drivers}".format(db2_class=db2_class,db2_connect_string=db2_connect_string,db2_login=db2_login,db_drivers=db_drivers)
    db_connect_string = 'jaydebeapi.connect(%s)' % db_connect_string
    conn=eval(db_connect_string)
    curr=conn.cursor()
    logger.debug("Setting schema to {db_schema}".format(db_schema=db_schema))
    curr.execute("SET CURRENT SCHEMA='{schema}'".format(schema=db_schema))
    logger.debug("Connection successful")
    return curr

@not_keyword
def query_db(cursor,sql_string):
    logger.debug(sql_string)
    cursor.execute(sql_string)
    return int((cursor.fetchone())[0])

@not_keyword
def query_multiple(cursor,sql_string):
    result_list=[]
    logger.debug(sql_string)
    cursor.execute(sql_string)
    query_result=cursor.fetchall()
    for result in query_result:
        result_list.append(str(result[0]))
    return result_list

@not_keyword
def check_string_or_boolean(variable):
    if type(variable)==type("string"): return eval(variable)
    else: return variable

class Klantsessie:
    def __init__(self, entiteit_nummer, middel_ids="", clear=False, previous=False, fixed=False, timestamp_start="", timestamp_end="", controle_plaatsgevonden=True, toelichting_klantsessie="", zooef_observaties_actueel=False, zooef_observaties=True, compliance_score=True, compliance_toelichting=True, compliance_toelichting_list="", compliance_proces=True, strategie_risicos=True, strategie_korte_termijn=True, strategie_middellange_termijn=True, actualiseren_gebaseerd=False, completed=True, compliance_score_list="", vooroverleg_value="", heffing_value="", bezwaren_value="", resultaat=True,  resultaat_score_list="", resultaat_strategie_list="", resultaat_toelichting_list=""):
        self.entiteit_nummer=entiteit_nummer
        if type(middel_ids)==list: self.middel_ids=middel_ids.copy()
        elif middel_ids=="": self.middel_ids=random.sample(all_middel_ids,random.randint(3,8))
        else: self.middel_ids=[middel_ids]
        for middel in self.middel_ids:
            self.add_middel_to_entiteit_db(middel)
        if previous:
            logger.debug(self.middel_ids)
            if (141 and '141') not in self.middel_ids: self.middel_ids.append(141)
            if (142 and '142') not in self.middel_ids: self.middel_ids.append(142)
        logger.debug(self.middel_ids)
        self.timestamp_start=timestamp_start
        self.timestamp_end=timestamp_end
        self.controle=controle_plaatsgevonden
        if type(controle_plaatsgevonden)==type("string"): self.controle=eval(controle_plaatsgevonden)
        else: self.controle=controle_plaatsgevonden
        if toelichting_klantsessie=="":
            self.toelichting_klantsessie = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(12))
        elif toelichting_klantsessie=="empty":
            self.toelichting_klantsessie = "empty"
        else:
            self.toelichting_klantsessie = toelichting_klantsessie
        #true and false values to determine whether to enter the following steps into the database
        self.zooef_observaties_actueel      =   check_string_or_boolean(zooef_observaties_actueel)
        self.zooef_observaties              =   check_string_or_boolean(zooef_observaties)
        self.compliance_score               =   check_string_or_boolean(compliance_score)
        self.compliance_toelichting         =   check_string_or_boolean(compliance_toelichting)
        self.compliance_proces              =   check_string_or_boolean(compliance_proces)
        self.strategie_korte_termijn        =   check_string_or_boolean(strategie_korte_termijn)
        self.strategie_middellange_termijn  =   check_string_or_boolean(strategie_middellange_termijn)
        self.strategie_risicos              =   check_string_or_boolean(strategie_risicos)
        self.actualiseren_gebaseerd         =   check_string_or_boolean(actualiseren_gebaseerd)
        self.clear                          =   check_string_or_boolean(clear)
        self.completed                      =   check_string_or_boolean(completed)
        self.previous                       =   check_string_or_boolean(previous)
        self.resultaat                      =   check_string_or_boolean(resultaat)
        self.compliance_toelichting_list    =   compliance_toelichting_list
        self.compliance_score_list          =   compliance_score_list
        self.vooroverleg_value              =   vooroverleg_value
        self.heffing_value                  =   heffing_value
        self.bezwaren_value                 =   bezwaren_value 
        if self.clear: self.clear_klantsessie_for_entiteit()
        elif not(self.previous): self.check_existing_klantsessies()
        self.generate_timestamps_for_klantsessie(fixed)
        self.klantsessie_id=self.insert_klantsessie_in_db()
        for middel in self.middel_ids:
            self.insert_klantsessie_data_per_middel(middel)
            if not(self.previous):
                self.insert_klantsessie_status_in_db(middel)
        self.resultaat_score_list=resultaat_score_list
        self.resultaat_strategie_list=resultaat_strategie_list
        self.resultaat_toelichting_list=resultaat_toelichting_list
        if self.resultaat: self.insert_klantsessie_resultaat_in_db()
        logger.info(self.__str__())

    def __str__(self):
        return pprint.pformat(vars(self))

    def add_middel_to_entiteit_db(self,middel):
        if middel==141 or middel==142 or middel=='141' or middel=='142': return
        curr = connect_to_db2()
        logger.debug(query_insert_middel.format(entiteitNummer=self.entiteit_nummer,middel=middel))
        curr.execute(query_insert_middel.format(entiteitNummer=self.entiteit_nummer,middel=middel))
        curr.close()

    def add_risico_to_klantsessie(self,middel_id,risico_id):
        curr = connect_to_db2()
        logger.info(query_strategie_risico.format(kolommenKlantsessieRisicos=kolommen_klantsessie_strategie_risicos,klantsessieId=self.klantsessie_id,middelId=middel_id,risicoId=risico_id))
        curr.execute(query_strategie_risico.format(kolommenKlantsessieRisicos=kolommen_klantsessie_strategie_risicos,klantsessieId=self.klantsessie_id,middelId=middel_id,risicoId=risico_id))
        curr.close()

    def check_existing_klantsessies(self):
        logger.debug("Checking whether there are other current klantsessies")
        curr=connect_to_db2()
        id=query_multiple(curr,"SELECT ID FROM KLANTSESSIE WHERE ENTITEIT_NUMMER='{entiteitNummer}' AND EINDDATUM IS NULL".format(entiteitNummer=self.entiteit_nummer))
        logger.debug(id)
        if len(id)!=0: logger.warn("There is already an existing current klantsessie for entiteit {entiteitNummer}. Use clear=True to remove a current klantsessie from the database before trying to insert it.".format(entiteitNummer=self.entiteit_nummer))
        curr.close()

    def clear_klantsessie_for_entiteit(self):
        logger.debug("Deleting all existing klantsessies")
        curr=connect_to_db2()
        logger.debug("SELECT ID FROM KLANTSESSIE WHERE ENTITEIT_NUMMER='{entiteitNummer}'".format(entiteitNummer=self.entiteit_nummer))
        klantsessie_ids = query_multiple(curr, "SELECT ID FROM KLANTSESSIE WHERE ENTITEIT_NUMMER='{entiteitNummer}'".format(entiteitNummer=self.entiteit_nummer))
        logger.debug("Existing klantsessie(s): {klantsessies}".format(klantsessies=", ".join(klantsessie_ids)))
        if len(klantsessie_ids) == 0: return
        for id in klantsessie_ids:
            curr.execute("DELETE FROM KLANTSESSIE WHERE ID='{id}'".format(id=id))
            curr.execute("DELETE FROM KLANTSESSIE_COMPLIANCE WHERE KLANTSESSIE_ID ='{id}'".format(id=id))
            curr.execute("DELETE FROM KLANTSESSIE_COMPLIANCE_PER_PROCESS WHERE KLANTSESSIE_ID ='{id}'".format(id=id))
            curr.execute("DELETE FROM KLANTSESSIE_ZOOEF WHERE KLANTSESSIE_ID ='{id}'".format(id=id))
            curr.execute("DELETE FROM KLANTSESSIE_STRATEGIE WHERE KLANTSESSIE_ID='{id}'".format(id=id))
            curr.execute("DELETE FROM KLANTSESSIE_STRATEGIE_RISICOS WHERE KLANTSESSIE_ID='{id}'".format(id=id))
            curr.execute("DELETE FROM KLANTSESSIE_STATUS WHERE KLANTSESSIE_ID='{id}'".format(id=id))
            curr.execute("DELETE FROM KLANTSESSIE_UITKOMST WHERE KLANTSESSIE_ID='{id}'".format(id=id))
        logger.info("Deleted all existing klantsessies")
        curr.close()
        time.sleep(0.1)

    def insert_klantsessie_in_db(self):
        logger.info("Going to insert klantsessie in database")
        curr=connect_to_db2()
        max_id = query_db(curr,"SELECT max(id) FROM KLANTSESSIE")
        logger.debug("Current max id: {max_id}".format(max_id=max_id))
        new_id = int(max_id)+1
        logger.debug("New id: {new_id}".format(new_id=new_id))
        if  self.toelichting_klantsessie!="empty":
            logger.debug(query_insert_klantsessie.format(kolommenKlantsessie=kolommen_klantsessie,id=new_id,entiteitNummer=self.entiteit_nummer,timeStampStart=self.timestamp_start,timeStampEnd=self.timestamp_end, controle=self.controle, actualiseren=str(self.actualiseren_gebaseerd).lower(), toelichting=self.toelichting_klantsessie))
            curr.execute(query_insert_klantsessie.format(kolommenKlantsessie=kolommen_klantsessie,id=new_id,entiteitNummer=self.entiteit_nummer,timeStampStart=self.timestamp_start,timeStampEnd=self.timestamp_end, controle=self.controle, actualiseren=str(self.actualiseren_gebaseerd).lower(), toelichting=self.toelichting_klantsessie))
        else:
            logger.debug(query_insert_klantsessie_no_toelichting.format(kolommenKlantsessie=kolommen_klantsessie_ex_toelichting,id=new_id,entiteitNummer=self.entiteit_nummer,timeStampStart=self.timestamp_start,timeStampEnd=self.timestamp_end, controle=self.controle, actualiseren=str(self.actualiseren_gebaseerd).lower()))
            curr.execute(query_insert_klantsessie_no_toelichting.format(kolommenKlantsessie=kolommen_klantsessie_ex_toelichting,id=new_id,entiteitNummer=self.entiteit_nummer,timeStampStart=self.timestamp_start,timeStampEnd=self.timestamp_end, controle=self.controle, actualiseren=str(self.actualiseren_gebaseerd).lower()))
        curr.close()
        return new_id
    
    def insert_klantsessie_data_per_middel(self,middel):
        logger.info("Going to insert klantsessie data per middel")
        curr=connect_to_db2()
        zoeef_observaties_text = "".join(random.choice(string.ascii_letters + string.digits) for i in range(20))
        logger.debug(query_zooef_observaties.format(kolommenKlantsessieZooef=kolommen_klantsessie_zooef,klantsessieId=self.klantsessie_id, middelId=middel, observatiesActueel=self.zooef_observaties_actueel, observaties=zoeef_observaties_text))
        if self.zooef_observaties: curr.execute(query_zooef_observaties.format(kolommenKlantsessieZooef=kolommen_klantsessie_zooef,klantsessieId=self.klantsessie_id, middelId=middel, observatiesActueel=self.zooef_observaties_actueel, observaties=zoeef_observaties_text))
        if self.compliance_score: 
            if self.compliance_score_list=="": compliance_score_list=[random.randint(0,5) for i in range(0,7)]
            else: compliance_score_list=self.compliance_score_list
        else: compliance_score_list = ["null" for i in range(len(aspect_list))]
        
        if self.compliance_toelichting: 
            if self.compliance_toelichting_list=="":
                compliance_toelichting_list = [''.join(random.choice(string.ascii_letters + string.digits) for i in range(12)) for i in range(len(aspect_list))]
            else: compliance_toelichting_list = self.compliance_toelichting_list
        else: compliance_toelichting_list = ["null" for i in range(len(aspect_list))]
        index = 0
        for aspect in aspect_list:
            if compliance_score_list[index]!="":
                logger.debug(query_compliance.format(kolommenKlantsessieCompliance=kolommen_klantsessie_compliance,klantsessieId=self.klantsessie_id, middelId=middel, aspectId=aspect['id'], score=compliance_score_list[index], toelichting=compliance_toelichting_list[index]))
                curr.execute(query_compliance.format(kolommenKlantsessieCompliance=kolommen_klantsessie_compliance,klantsessieId=self.klantsessie_id, middelId=middel, aspectId=aspect['id'], score=compliance_score_list[index], toelichting=compliance_toelichting_list[index]))
            index += 1
        if self.vooroverleg_value=="": vooroverleg_value=random.choice([143,144,145])
        else: vooroverleg_value=self.vooroverleg_value
        if self.heffing_value=="": heffing_value=random.choice([143,144,145])
        else: heffing_value=self.heffing_value
        if self.bezwaren_value=="": bezwaren_value=random.choice([143,144,145])
        else: bezwaren_value=self.bezwaren_value
        if self.compliance_proces: curr.execute(query_compliance_proces.format(kolommenKlantsessieCompliancePerProces=kolommen_klantsessie_compliance_per_proces,klantsessieId=self.klantsessie_id,middelId=middel, vooroverlegValue=vooroverleg_value, heffingValue=heffing_value,bezwarenValue=bezwaren_value))
        if self.strategie_korte_termijn: strategie_korte_termijn_text = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(12))
        else: strategie_korte_termijn_text = "null"
        if self.strategie_middellange_termijn: strategie_middellange_termijn_text = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(12))
        else: strategie_middellange_termijn_text = "null"
        logger.debug(query_strategie.format(kolommenKlantsessieStrategie=kolommen_klantsessie_strategie,klantsessieId=self.klantsessie_id,middelId=middel,strategieKorteTermijn=strategie_korte_termijn_text, strategieMiddellangeTermijn=strategie_middellange_termijn_text))
        curr.execute(query_strategie.format(kolommenKlantsessieStrategie=kolommen_klantsessie_strategie,klantsessieId=self.klantsessie_id,middelId=middel,strategieKorteTermijn=strategie_korte_termijn_text, strategieMiddellangeTermijn=strategie_middellange_termijn_text))
        curr.close()

    def insert_klantsessie_status_in_db(self, middel):
        logger.info("Going to insert klantsessie status in db")
        curr=connect_to_db2()
        if self.zooef_observaties and self.completed: 
            zooef_status = "DONE" 
        elif self.zooef_observaties: 
            zooef_status = "COMPLETED"
        else:
            zooef_status = "INITIAL"
        if self.compliance_score and self.compliance_toelichting and self.compliance_proces and self.completed:
            compliance_status  = "DONE"
        elif self.compliance_score and self.compliance_toelichting and self.compliance_proces:
            compliance_status  = "COMPLETED"
        elif self.compliance_score or self.compliance_toelichting or self.compliance_proces:
            compliance_status  = "TOUCHED"
        else:
            compliance_status  = "INITIAL"
        if self.strategie_korte_termijn and self.strategie_middellange_termijn and self.completed:
            strategie_status  = "DONE"
        elif self.strategie_korte_termijn and self.strategie_middellange_termijn:
            strategie_status  = "COMPLETED"
        elif self.strategie_korte_termijn or self.strategie_middellange_termijn:
            strategie_status  = "TOUCHED"
        else:
            strategie_status  = "INITIAL"
        if self.completed: 
            voorbereiding_status = "DONE"
        else:
            voorbereiding_status = "INITIAL"
        logger.debug(query_klantsessie_status.format(kolommenKlantsessieStatus=kolommen_klantsessie_status,klantsessieId=self.klantsessie_id, middelId=middel, zooefStatus=zooef_status, complianceStatus=compliance_status, strategieStatus=strategie_status, voorbereidingStatus=voorbereiding_status, voorbereidingAfgerond=str(self.completed).lower()))
        curr.execute(query_klantsessie_status.format(kolommenKlantsessieStatus=kolommen_klantsessie_status,klantsessieId=self.klantsessie_id, middelId=middel, zooefStatus=zooef_status, complianceStatus=compliance_status, strategieStatus=strategie_status, voorbereidingStatus=voorbereiding_status, voorbereidingAfgerond=str(self.completed).lower()))
        curr.close()
        
    def insert_klantsessie_resultaat_in_db(self):
        logger.info("Going to insert klantsessie resultaat in database")
        curr=connect_to_db2()
        index = 0
        if self.resultaat_score_list=="": resultaat_score_list=[random.randint(0,5) for i in range(0,7)]
        else: resultaat_score_list=self.resultaat_score_list
        if self.resultaat_strategie_list=="": resultaat_strategie_list=[random.choice([139,140]) for i in range(0,7)]
        else: resultaat_strategie_list=self.resultaat_strategie_list
        if self.compliance_toelichting: 
            if self.resultaat_toelichting_list=="":
                resultaat_toelichting_list = [''.join(random.choice(string.ascii_letters + string.digits) for i in range(12)) for i in range(len(aspect_list))]
            else: resultaat_toelichting_list = self.resultaat_toelichting_list
        else: resultaat_toelichting_list = ["null" for i in range(len(aspect_list))]
        for aspect in aspect_list:
            if resultaat_score_list[index]!="":
                logger.debug(query_resultaat.format(kolommenKlantsessieResultaat=kolommen_klantsessie_resultaat, klantsessieId=self.klantsessie_id, aspectId=aspect['id'], score=resultaat_score_list[index], strategie=resultaat_strategie_list[index], toelichting=resultaat_toelichting_list[index]))
                curr.execute(query_resultaat.format(kolommenKlantsessieResultaat=kolommen_klantsessie_resultaat, klantsessieId=self.klantsessie_id, aspectId=aspect['id'], score=resultaat_score_list[index], strategie=resultaat_strategie_list[index], toelichting=resultaat_toelichting_list[index]))
            index += 1
        curr.close()

    def generate_timestamps_for_klantsessie(self,fixed):
        logger.info("Variables set, going to generate timestamps")
        today = datetime.now()
        yesterday = (datetime.now()-timedelta(days=1))
        if self.timestamp_start=="":
            if fixed:
                self.timestamp_start="{ts '"+str(datetime.fromtimestamp("2022-03-22 16:14:08.337447"))+"'}"
            elif self.previous:
                self.timestamp_start="{ts '"+str(yesterday)+"'}"
            else:
                self.timestamp_start="{ts '"+str(today)+"'}"
        else: self.timestamp_start="{ts '"+str(self.timestamp_start)+"'}"
        if self.timestamp_end=="":
            if fixed and self.previous:
                self.timestamp_end="{ts '"+str(datetime.fromtimestamp("2022-03-23 16:14:08.337447"))+"'}"
            elif fixed:
                self.timestamp_end="null"
            elif self.previous:
                self.timestamp_end="{ts '"+str(today)+"'}"
            else:
                self.timestamp_end="null"
        else: self.timestamp_end="{ts '"+str(self.timestamp_end)+"'}"
        logger.info("Timestamps set")
        logger.debug(self.timestamp_start)
        logger.debug(self.timestamp_end)

@keyword
def create_klantsessie(**varargs):
    logger.debug(varargs)
    return Klantsessie(**varargs)

@keyword
def add_risico_to_klantsessie(klantsessie,middel_id,risico_ids):
    if type(risico_ids)!=list: risico_ids=[risico_ids]
    for risico_id in risico_ids:
        klantsessie.add_risico_to_klantsessie(middel_id,risico_id)