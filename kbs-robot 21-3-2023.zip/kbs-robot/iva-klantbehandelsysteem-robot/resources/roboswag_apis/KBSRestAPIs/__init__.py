"""
**OpenAPI version:** 2.0
**Title:** KBS Rest APIs
**API Version:** 1.0
**Description:** To log in, use fake-login-controller login api to generate JWT token. Click "Try it out" and fill in username and password. Generated token can be found in server response. 
 Token (in format "Bearer kiuadshfiuha") should be pasted in JWT field when clicking Authorize.

**Contact:**
    **name:** Webdevelopment Team 3
**License:**
    **name:** Apache 2.0
    **url:** http://www.apache.org/licenses/LICENSE-2.0.html
"""
