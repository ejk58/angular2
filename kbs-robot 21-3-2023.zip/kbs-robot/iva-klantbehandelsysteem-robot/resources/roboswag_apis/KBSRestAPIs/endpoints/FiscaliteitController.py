import logging
import json

from roboswag import APIModel


class FiscaliteitController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def add_entiteit_middel_kenmerk_using_post(
        self,
        authorization=None,
        entiteit_middel_kenmerk_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** addEntiteitMiddelKenmerk
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "entiteitNummer": {"type": "integer", "format": "int64"},
                            "hasLinkableRisicos": {"type": "boolean"},
                            "hoofdKenmerkId": {"type": "integer", "format": "int64"},
                            "id": {"type": "integer", "format": "int64"},
                            "rank": {"type": "integer", "format": "int64"},
                            "subKenmerk1Id": {"type": "integer", "format": "int64"},
                            "subKenmerk2Id": {"type": "integer", "format": "int64"},
                            "subKenmerk3Id": {"type": "integer", "format": "int64"},
                        },
                        "title": "EntiteitMiddelKenmerkDto",
                    },
                },
                "title": "LoggingWrapperEntiteitMiddelKenmerkDto",
            }
            self.validate.schema(json.loads(entiteit_middel_kenmerk_dto), schema)

        _body = overwrite_body if overwrite_body else entiteit_middel_kenmerk_dto
        response = self.post(
            "/api/fiscaliteit/addEntiteitMiddelKenmerk",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def add_entiteit_middel_risico_using_post(
        self,
        authorization=None,
        entiteit_middel_risico_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** addEntiteitMiddelRisico
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "beheersing": {"type": "integer", "format": "int32"},
                            "entiteitMiddelKenmerkId": {
                                "type": "integer",
                                "format": "int64",
                            },
                            "entiteitNummer": {"type": "integer", "format": "int64"},
                            "hoofdRisicoId": {"type": "integer", "format": "int64"},
                            "id": {"type": "integer", "format": "int64"},
                            "keyRisk": {"type": "integer", "format": "int32"},
                            "middelKenmerk": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "integer", "format": "int64"},
                                    "kenmerk": {"type": "string"},
                                    "middelId": {"type": "integer", "format": "int32"},
                                    "parentId": {"type": "integer", "format": "int64"},
                                },
                                "title": "MiddelKenmerk",
                            },
                            "rank": {"type": "integer", "format": "int64"},
                            "statusId": {"type": "integer", "format": "int64"},
                            "subRisicoId": {"type": "integer", "format": "int64"},
                        },
                        "title": "EntiteitMiddelRisicoDto",
                    },
                },
                "title": "LoggingWrapperEntiteitMiddelRisicoDto",
            }
            self.validate.schema(json.loads(entiteit_middel_risico_dto), schema)

        _body = overwrite_body if overwrite_body else entiteit_middel_risico_dto
        response = self.post(
            "/api/fiscaliteit/addEntiteitMiddelRisico",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_kenmerken_for_risico_using_get(
        self,
        middel_risico_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getKenmerkenForRisico
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/getKenmerkenForRisico/{middel_risico_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "compositeId": {
                                "type": "object",
                                "properties": {
                                    "middelKenmerkId": {
                                        "type": "integer",
                                        "format": "int64",
                                    },
                                    "middelRisicoId": {
                                        "type": "integer",
                                        "format": "int64",
                                    },
                                },
                                "title": "KenmerkRisicosKoppelingCompositeId",
                            },
                            "middelKenmerk": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "integer", "format": "int64"},
                                    "kenmerk": {"type": "string"},
                                    "middelId": {"type": "integer", "format": "int32"},
                                    "parentId": {"type": "integer", "format": "int64"},
                                },
                                "title": "MiddelKenmerk",
                            },
                            "middelRisico": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "integer", "format": "int64"},
                                    "middelId": {"type": "integer", "format": "int32"},
                                    "parentId": {"type": "integer", "format": "int64"},
                                    "rank": {"type": "integer", "format": "int64"},
                                    "risico": {"type": "string"},
                                },
                                "title": "MiddelRisico",
                            },
                        },
                        "title": "KenmerkRisicosKoppeling",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_middel_kenmerken_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getMiddelKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/fiscaliteit/middelKenmerken", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int64"},
                            "kenmerk": {"type": "string"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "parentId": {"type": "integer", "format": "int64"},
                        },
                        "title": "MiddelKenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_middel_risicos_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getMiddelRisicos
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/fiscaliteit/middelRisicos", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int64"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "parentId": {"type": "integer", "format": "int64"},
                            "rank": {"type": "integer", "format": "int64"},
                            "risico": {"type": "string"},
                        },
                        "title": "MiddelRisico",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_risicos_by_middel_id_and_middelkenmerk_id_using_get(
        self,
        middel_kenmerk_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getRisicosByMiddelIdAndMiddelkenmerkId
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/middelRisicos/{middel_kenmerk_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int64"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "parentId": {"type": "integer", "format": "int64"},
                            "rank": {"type": "integer", "format": "int64"},
                            "risico": {"type": "string"},
                        },
                        "title": "MiddelRisico",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_ranks_of_selected_entiteit_middel_kenmerken_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        emk_list=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateRanksOfSelectedEntiteitMiddelKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "entiteitNummer": {
                                    "type": "integer",
                                    "format": "int64",
                                },
                                "hoofdKenmerkId": {
                                    "type": "integer",
                                    "format": "int64",
                                },
                                "id": {"type": "integer", "format": "int64"},
                                "rank": {"type": "integer", "format": "int64"},
                                "subKenmerk1Id": {"type": "integer", "format": "int64"},
                                "subKenmerk2Id": {"type": "integer", "format": "int64"},
                                "subKenmerk3Id": {"type": "integer", "format": "int64"},
                            },
                            "title": "EntiteitMiddelKenmerk",
                        },
                    },
                },
                "title": "LoggingWrapperListEntiteitMiddelKenmerk",
            }
            self.validate.schema(json.loads(emk_list), schema)

        _body = overwrite_body if overwrite_body else emk_list
        response = self.post(
            f"/api/fiscaliteit/{entiteit_nummer}/entiteitMiddelKenmerken/rank",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_entiteit_middel_kenmerken_for_risico_using_get(
        self,
        entiteit_nummer,
        middel_risico_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getEntiteitMiddelKenmerkenForRisico
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/{entiteit_nummer}/getEntiteitMiddelKenmerkenForRisico/{middel_risico_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "additionalProperties": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int64"},
                            "kenmerk": {"type": "string"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "parentId": {"type": "integer", "format": "int64"},
                        },
                        "title": "MiddelKenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_ranks_of_selected_entiteit_middel_risicos_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        emr_list=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateRanksOfSelectedEntiteitMiddelRisicos
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "beheersing": {"type": "integer", "format": "int32"},
                                "entiteitMiddelKenmerkId": {
                                    "type": "integer",
                                    "format": "int64",
                                },
                                "entiteitNummer": {
                                    "type": "integer",
                                    "format": "int64",
                                },
                                "hoofdRisicoId": {"type": "integer", "format": "int64"},
                                "id": {"type": "integer", "format": "int64"},
                                "keyRisk": {"type": "integer", "format": "int32"},
                                "rank": {"type": "integer", "format": "int64"},
                                "statusId": {"type": "integer", "format": "int64"},
                                "subRisicoId": {"type": "integer", "format": "int64"},
                            },
                            "title": "EntiteitMiddelRisico",
                        },
                    },
                },
                "title": "LoggingWrapperListEntiteitMiddelRisico",
            }
            self.validate.schema(json.loads(emr_list), schema)

        _body = overwrite_body if overwrite_body else emr_list
        response = self.post(
            f"/api/fiscaliteit/{entiteit_nummer}/selectedEntiteitMiddelRisicos/rank",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_entiteit_middel_kenmerken_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedEntiteitMiddelKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/{entiteit_nummer}/{middel_id}/entiteitMiddelKenmerken",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "entiteitNummer": {"type": "integer", "format": "int64"},
                            "hasLinkableRisicos": {"type": "boolean"},
                            "hoofdKenmerkId": {"type": "integer", "format": "int64"},
                            "id": {"type": "integer", "format": "int64"},
                            "rank": {"type": "integer", "format": "int64"},
                            "subKenmerk1Id": {"type": "integer", "format": "int64"},
                            "subKenmerk2Id": {"type": "integer", "format": "int64"},
                            "subKenmerk3Id": {"type": "integer", "format": "int64"},
                        },
                        "title": "EntiteitMiddelKenmerkDto",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_algemene_kenmerken_en_attentiepunten_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getAlgemeneKenmerkenEnAttentiepunten
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/{entiteit_nummer}/{middel_id}/getAlgemeneKenmerkenEnAttentiepunten",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_entiteit_middel_risicos_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedEntiteitMiddelRisicos
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/{entiteit_nummer}/{middel_id}/selectedEntiteitMiddelRisicos",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "beheersing": {"type": "integer", "format": "int32"},
                            "entiteitMiddelKenmerkId": {
                                "type": "integer",
                                "format": "int64",
                            },
                            "entiteitNummer": {"type": "integer", "format": "int64"},
                            "hoofdRisicoId": {"type": "integer", "format": "int64"},
                            "id": {"type": "integer", "format": "int64"},
                            "keyRisk": {"type": "integer", "format": "int32"},
                            "middelKenmerk": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "integer", "format": "int64"},
                                    "kenmerk": {"type": "string"},
                                    "middelId": {"type": "integer", "format": "int32"},
                                    "parentId": {"type": "integer", "format": "int64"},
                                },
                                "title": "MiddelKenmerk",
                            },
                            "rank": {"type": "integer", "format": "int64"},
                            "statusId": {"type": "integer", "format": "int64"},
                            "subRisicoId": {"type": "integer", "format": "int64"},
                        },
                        "title": "EntiteitMiddelRisicoDto",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def delete_entiteit_middel_kenmerk_using_delete(
        self,
        id,
        authorization=None,
        logging_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** deleteEntiteitMiddelKenmerk
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {"loggingId": {"type": "string"}},
                "title": "LoggingWrapperVoid",
            }
            self.validate.schema(json.loads(logging_wrapper), schema)

        _body = overwrite_body if overwrite_body else logging_wrapper
        response = self.delete(
            f"/api/fiscaliteit/{id}/deleteEntiteitMiddelKenmerk",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 204:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def delete_entiteit_middel_risico_using_delete(
        self,
        id,
        authorization=None,
        logging_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** deleteEntiteitMiddelRisico
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {"loggingId": {"type": "string"}},
                "title": "LoggingWrapperVoid",
            }
            self.validate.schema(json.loads(logging_wrapper), schema)

        _body = overwrite_body if overwrite_body else logging_wrapper
        response = self.delete(
            f"/api/fiscaliteit/{id}/deleteEntiteitMiddelRisico",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 204:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_entiteit_middel_kenmerk_by_id_using_get(
        self,
        id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getEntiteitMiddelKenmerkById
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/{id}/entiteitMiddelKenmerk",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "entiteitNummer": {"type": "integer", "format": "int64"},
                        "hoofdKenmerkId": {"type": "integer", "format": "int64"},
                        "id": {"type": "integer", "format": "int64"},
                        "rank": {"type": "integer", "format": "int64"},
                        "subKenmerk1Id": {"type": "integer", "format": "int64"},
                        "subKenmerk2Id": {"type": "integer", "format": "int64"},
                        "subKenmerk3Id": {"type": "integer", "format": "int64"},
                    },
                    "title": "EntiteitMiddelKenmerk",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_kenmerken_by_middel_id_using_get(
        self,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getKenmerkenByMiddelId
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/{middel_id}/middelKenmerken",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int64"},
                            "kenmerk": {"type": "string"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "parentId": {"type": "integer", "format": "int64"},
                        },
                        "title": "MiddelKenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_risicos_by_middel_id_using_get(
        self,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getRisicosByMiddelId
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/fiscaliteit/{middel_id}/middelRisicos",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int64"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "parentId": {"type": "integer", "format": "int64"},
                            "rank": {"type": "integer", "format": "int64"},
                            "risico": {"type": "string"},
                        },
                        "title": "MiddelRisico",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
