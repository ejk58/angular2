import logging
import json

from roboswag import APIModel


class FakeLoginController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def fake_login_using_post(
        self,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
    ):
        """
        **Summary:** Login.
        """
        if validate_payload:
            schema = {"type": "object", "title": "FakeLoginBody"}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.post("/api/login", body=_body, status=exp_status)

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def fake_logout_using_post(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** Logout.
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.post("/api/logout", headers=headers, status=exp_status)

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
