import logging
import json

from roboswag import APIModel


class FeedbackRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def add_feedback_using_post(
        self,
        authorization=None,
        feedback=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** addFeedback
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "created": {"type": "string", "format": "date-time"},
                    "email": {"type": "string"},
                    "id": {"type": "integer", "format": "int64"},
                    "melding": {"type": "string"},
                    "naam": {"type": "string"},
                    "pagina": {"type": "string"},
                    "rollen": {"type": "string"},
                    "userId": {"type": "string"},
                    "versionInfo": {"type": "string"},
                    "versionInformation": {
                        "type": "object",
                        "properties": {
                            "application": {"type": "string"},
                            "buildNumber": {"type": "string"},
                            "buildTime": {"type": "string"},
                            "version": {"type": "string"},
                            "versionInformation": {"type": "string"},
                        },
                        "title": "VersionInformation",
                    },
                },
                "title": "Feedback",
            }
            self.validate.schema(json.loads(feedback), schema)

        _body = overwrite_body if overwrite_body else feedback
        response = self.post(
            "/api/feedback", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "created": {"type": "string", "format": "date-time"},
                        "email": {"type": "string"},
                        "id": {"type": "integer", "format": "int64"},
                        "melding": {"type": "string"},
                        "naam": {"type": "string"},
                        "pagina": {"type": "string"},
                        "rollen": {"type": "string"},
                        "userId": {"type": "string"},
                        "versionInfo": {"type": "string"},
                        "versionInformation": {
                            "type": "object",
                            "properties": {
                                "application": {"type": "string"},
                                "buildNumber": {"type": "string"},
                                "buildTime": {"type": "string"},
                                "version": {"type": "string"},
                                "versionInformation": {"type": "string"},
                            },
                            "title": "VersionInformation",
                        },
                    },
                    "title": "Feedback",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
