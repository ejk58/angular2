import logging
import json

from roboswag import APIModel


class KlantsessieResultaatRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_klantsessie_resultaat_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getKlantsessieResultaat
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/resultaat/{entiteit_nummer}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "currentEntries": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "klantsessieId": {
                                        "type": "integer",
                                        "format": "int64",
                                    },
                                    "lastKlantSessieDate": {
                                        "type": "string",
                                        "format": "date-time",
                                    },
                                    "middel": {
                                        "type": "object",
                                        "properties": {
                                            "groep": {"type": "string"},
                                            "id": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                            "kenmerk": {"type": "string"},
                                            "kenmerkParentId": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                        },
                                        "title": "Kenmerk",
                                    },
                                    "resultaatByKenmerkId": {
                                        "type": "object",
                                        "additionalProperties": {
                                            "type": "object",
                                            "properties": {
                                                "kenmerk": {
                                                    "type": "object",
                                                    "properties": {
                                                        "groep": {"type": "string"},
                                                        "id": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                        "kenmerk": {"type": "string"},
                                                        "kenmerkParentId": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                    },
                                                    "title": "Kenmerk",
                                                },
                                                "score": {
                                                    "type": "integer",
                                                    "format": "int32",
                                                },
                                                "toelichting": {"type": "string"},
                                            },
                                            "title": "KenmerkChild",
                                        },
                                    },
                                },
                                "title": "KlantsessieResultaatEntryDto",
                            },
                        },
                        "kenmerken": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "kenmerk": {
                                        "type": "object",
                                        "properties": {
                                            "groep": {"type": "string"},
                                            "id": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                            "kenmerk": {"type": "string"},
                                            "kenmerkParentId": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                        },
                                        "title": "Kenmerk",
                                    },
                                    "kenmerkChildren": {
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "kenmerk": {
                                                    "type": "object",
                                                    "properties": {
                                                        "groep": {"type": "string"},
                                                        "id": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                        "kenmerk": {"type": "string"},
                                                        "kenmerkParentId": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                    },
                                                    "title": "Kenmerk",
                                                },
                                                "score": {
                                                    "type": "integer",
                                                    "format": "int32",
                                                },
                                                "toelichting": {"type": "string"},
                                            },
                                            "title": "KenmerkChild",
                                        },
                                    },
                                },
                                "title": "KenmerkParent",
                            },
                        },
                        "previousEntries": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "klantsessieId": {
                                        "type": "integer",
                                        "format": "int64",
                                    },
                                    "lastKlantSessieDate": {
                                        "type": "string",
                                        "format": "date-time",
                                    },
                                    "middel": {
                                        "type": "object",
                                        "properties": {
                                            "groep": {"type": "string"},
                                            "id": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                            "kenmerk": {"type": "string"},
                                            "kenmerkParentId": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                        },
                                        "title": "Kenmerk",
                                    },
                                    "resultaatByKenmerkId": {
                                        "type": "object",
                                        "additionalProperties": {
                                            "type": "object",
                                            "properties": {
                                                "kenmerk": {
                                                    "type": "object",
                                                    "properties": {
                                                        "groep": {"type": "string"},
                                                        "id": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                        "kenmerk": {"type": "string"},
                                                        "kenmerkParentId": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                    },
                                                    "title": "Kenmerk",
                                                },
                                                "score": {
                                                    "type": "integer",
                                                    "format": "int32",
                                                },
                                                "toelichting": {"type": "string"},
                                            },
                                            "title": "KenmerkChild",
                                        },
                                    },
                                },
                                "title": "KlantsessieResultaatEntryDto",
                            },
                        },
                    },
                    "title": "KlantsessieResultaatDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
