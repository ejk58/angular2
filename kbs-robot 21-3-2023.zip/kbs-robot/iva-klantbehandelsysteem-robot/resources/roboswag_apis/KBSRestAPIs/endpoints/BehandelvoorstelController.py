import logging
import json

from roboswag import APIModel


class BehandelvoorstelController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def create_behandel_voorstel_using_post(
        self,
        authorization=None,
        request=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** createBehandelVoorstel
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "behandelActiviteitCode": {"type": "string"},
                    "behandelVoorstelReference": {"type": "string"},
                    "subject": {"type": "string"},
                    "subjectType": {"type": "string"},
                    "userId": {"type": "string"},
                    "voorstelAction": {"type": "string"},
                    "voorstelType": {"type": "string"},
                },
                "title": "BehandelVoorstelRequestDto",
            }
            self.validate.schema(json.loads(request), schema)

        _body = overwrite_body if overwrite_body else request
        response = self.post(
            "/api/behandelvoorstel/create",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "token": {"type": "string"},
                    },
                    "title": "BehandelVoorstelResponse",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_behandelvoorstel_options_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getBehandelvoorstelOptions
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/behandelvoorstel/options", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "activiteitCodes": {
                                "type": "object",
                                "additionalProperties": {"type": "string"},
                            },
                            "voorstelType": {
                                "type": "object",
                                "properties": {
                                    "code": {"type": "string"},
                                    "omschrijving": {"type": "string"},
                                },
                                "title": "VoorstelType",
                            },
                        },
                        "title": "BehandelvoorstelOption",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_register_behandelvoorstel_url_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getRegisterBehandelvoorstelUrl
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/behandelvoorstel/register-behandelvoorstel-url",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {"url": {"type": "string"}},
                    "title": "RegisterBehandelvoorstelUrl",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_edit_token_using_post(
        self,
        authorization=None,
        request=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** getEditToken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "behandelActiviteitCode": {"type": "string"},
                    "behandelVoorstelReference": {"type": "string"},
                    "subject": {"type": "string"},
                    "subjectType": {"type": "string"},
                    "userId": {"type": "string"},
                    "voorstelAction": {"type": "string"},
                    "voorstelType": {"type": "string"},
                },
                "title": "BehandelVoorstelRequestDto",
            }
            self.validate.schema(json.loads(request), schema)

        _body = overwrite_body if overwrite_body else request
        response = self.post(
            "/api/behandelvoorstel/view-or-delete-token",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "token": {"type": "string"},
                    },
                    "title": "BehandelVoorstelResponse",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_behandel_voorstellen_using_get(
        self,
        entiteit_id,
        entiteit_naam,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getBehandelVoorstellen
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/behandelvoorstel/{entiteit_id}/{entiteit_naam}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "behandelActiviteitCode": {"type": "string"},
                            "behandelaars": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "behandelactiviteit": {"type": "string"},
                            "bsnRsin": {"type": "string"},
                            "id": {"type": "string"},
                            "middel": {"type": "string"},
                            "naam": {"type": "string"},
                            "personen": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "activiteiten": {
                                            "type": "array",
                                            "items": {
                                                "type": "object",
                                                "properties": {
                                                    "afwijkendePeriodeEinde": {
                                                        "type": "string"
                                                    },
                                                    "afwijkendePeriodeStart": {
                                                        "type": "string"
                                                    },
                                                    "middel": {"type": "string"},
                                                    "subnummer": {
                                                        "type": "integer",
                                                        "format": "int64",
                                                    },
                                                },
                                                "title": "BatActiviteit",
                                            },
                                        },
                                        "afwijkendePeriodeEinde": {"type": "string"},
                                        "afwijkendePeriodeStart": {"type": "string"},
                                        "subject": {
                                            "type": "integer",
                                            "format": "int64",
                                        },
                                    },
                                    "title": "BatPersoon",
                                },
                            },
                            "status": {"type": "string"},
                            "subjectType": {"type": "string"},
                            "voorstelType": {"type": "string"},
                        },
                        "title": "BehandelActiviteit",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
