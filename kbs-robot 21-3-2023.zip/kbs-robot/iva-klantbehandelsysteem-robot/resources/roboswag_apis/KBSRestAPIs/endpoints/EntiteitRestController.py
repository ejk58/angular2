import logging
import json

from roboswag import APIModel


class EntiteitRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_orggevegens_url_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getOrggevegensUrl
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/entiteiten/org-gegevens-url", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {"wijzigBehandelteamUrl": {"type": "string"}},
                    "title": "OrgUrls",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def search_entiteiten_using_get(
        self,
        authorization=None,
        entiteit_name=None,
        entiteit_number=None,
        klantpakket=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
        overwrite_query=None,
    ):
        """
        **Summary:** searchEntiteiten
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        _query = {
            "entiteitName": entiteit_name,
            "entiteitNumber": entiteit_number,
            "klantpakket": klantpakket,
        }
        if overwrite_query:
            _query = overwrite_query

        response = self.get(
            "/api/entiteiten/search", headers=headers, query=_query, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "adres": {"type": "string"},
                            "bestuurlijkVerband": {"type": "string"},
                            "brancheCode": {"type": "integer", "format": "int64"},
                            "brancheNaam": {"type": "string"},
                            "convenantIndicatie": {"type": "string"},
                            "formatiedat": {"type": "string", "format": "date"},
                            "kantoorCode": {"type": "string"},
                            "kantoorNaam": {"type": "string"},
                            "klantCoordinator": {"type": "string"},
                            "klantGroep": {"type": "string"},
                            "klantpakket": {"type": "string"},
                            "naam": {"type": "string"},
                            "nummer": {"type": "integer", "format": "int64"},
                            "ontbinddat": {"type": "string", "format": "date"},
                            "teamCode": {"type": "string"},
                            "teamNaam": {"type": "string"},
                        },
                        "title": "Entiteit",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_entiteit_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getEntiteit
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "adres": {"type": "string"},
                        "bestuurlijkVerband": {"type": "string"},
                        "brancheCode": {"type": "integer", "format": "int64"},
                        "brancheNaam": {"type": "string"},
                        "convenantIndicatie": {"type": "string"},
                        "formatiedat": {"type": "string", "format": "date"},
                        "kantoorCode": {"type": "string"},
                        "kantoorNaam": {"type": "string"},
                        "klantCoordinator": {"type": "string"},
                        "klantGroep": {"type": "string"},
                        "klantpakket": {"type": "string"},
                        "naam": {"type": "string"},
                        "nummer": {"type": "integer", "format": "int64"},
                        "ontbinddat": {"type": "string", "format": "date"},
                        "teamCode": {"type": "string"},
                        "teamNaam": {"type": "string"},
                    },
                    "title": "Entiteit",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_algemene_gegevens_kenmerken_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getAlgemeneGegevensKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/algemeneGegevens/kenmerken",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "aandachtsCategorie": {"type": "string"},
                        "convenantDeelname": {"type": "string"},
                        "goCategorie": {"type": "string"},
                        "vipIndicatie": {"type": "string"},
                        "wolbSom": {"type": "number"},
                        "zwaarteCategorie": {"type": "string"},
                    },
                    "title": "Kenmerken",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_algemene_gegevens_samenstelling_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getAlgemeneGegevensSamenstelling
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/algemeneGegevens/samenstelling",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "nummer": {"type": "string"},
                            "subject": {"type": "string"},
                            "type": {"type": "string"},
                        },
                        "title": "SubEntiteitTestData",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_org_behandelteam_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getOrgBehandelteam
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/behandelteam-org-gegevens",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "naam": {"type": "string"},
                            "rolNaam": {"type": "string"},
                            "toelichting": {"type": "string"},
                            "userid": {"type": "string"},
                        },
                        "title": "Behandelteam",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_convenantindicatie_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getConvenantindicatie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/convenantindicatie",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {"value": {"type": "string"}},
                    "title": "Convenantindicatie",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_dashboard_behandelvoorstellen_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getDashboardBehandelvoorstellen
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/dashboard/behandelvoorstellen",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "beroep": {"type": "string"},
                            "bezwaar": {"type": "string"},
                            "controle": {"type": "string"},
                            "heffing": {"type": "string"},
                            "invordering": {"type": "string"},
                            "middel": {"type": "string"},
                            "overig": {"type": "string"},
                            "totalen": {"type": "string"},
                            "vooroverleg": {"type": "string"},
                        },
                        "title": "Behandelvoorstel",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_entiteit_kenmerken_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getEntiteitKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/dashboard/kenmerken",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": {"type": "array", "items": {"type": "string"}},
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_dashboard_opdrachten_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getDashboardOpdrachten
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/dashboard/opdrachten",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "aantal": {"type": "string"},
                            "naam": {"type": "string"},
                        },
                        "title": "Opdracht",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_org_kantoor_team_gegevens_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getOrgKantoorTeamGegevens
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/kantoorteam-org-gegevens",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "kantoorCode": {"type": "integer", "format": "int64"},
                        "subject": {"type": "string"},
                        "team": {"type": "string"},
                    },
                    "title": "OrgKantoorTeam",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_org_klant_groep_gegevens_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getOrgKlantGroepGegevens
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/klantgroep-org-gegevens",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "klantcoordinator": {"type": "string"},
                        "klantgroepNaam": {"type": "string"},
                        "werkgroep": {"type": "string"},
                    },
                    "title": "OrgKlantGroep",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_missing_entiteit_org_gegevens_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getMissingEntiteitOrgGegevens
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/missing-entiteit-org-gegevens",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "branchecode": {"type": "integer", "format": "int64"},
                        "branchenaam": {"type": "string"},
                        "kantoornaam": {"type": "string"},
                        "teamnaam": {"type": "string"},
                    },
                    "title": "EntiteitKzbGegevens",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_sub_entiteit_selections_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        selected_subentiteit_bsn_rsins=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveSubEntiteitSelections
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "array",
                        "items": {"type": "integer", "format": "int64"},
                    },
                },
                "title": "LoggingWrapperSortedSetlong",
            }
            self.validate.schema(json.loads(selected_subentiteit_bsn_rsins), schema)

        _body = overwrite_body if overwrite_body else selected_subentiteit_bsn_rsins
        response = self.post(
            f"/api/entiteiten/{entiteit_nummer}/subEntiteitSelections/save",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_sub_entiteiten_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        page_request=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
        overwrite_query=None,
    ):
        """
        **Summary:** getZooSubEntiteiten
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        _query = {"pageRequest": page_request}
        if overwrite_query:
            _query = overwrite_query

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/subEntiteiten",
            headers=headers,
            query=_query,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "content": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "aanvullingen": {
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "groep": {"type": "string"},
                                                "id": {
                                                    "type": "integer",
                                                    "format": "int32",
                                                },
                                                "kenmerk": {"type": "string"},
                                                "kenmerkParentId": {
                                                    "type": "integer",
                                                    "format": "int32",
                                                },
                                            },
                                            "title": "Kenmerk",
                                        },
                                    },
                                    "beginDatum": {"type": "string"},
                                    "brancheCode": {"type": "string"},
                                    "bsnRsin": {"type": "integer", "format": "int64"},
                                    "eindDatum": {"type": "string"},
                                    "naam": {"type": "string"},
                                    "plaats": {"type": "string"},
                                    "soortPersoon": {"type": "string"},
                                },
                                "title": "ZooSubEntiteit",
                            },
                        },
                        "empty": {"type": "boolean"},
                        "first": {"type": "boolean"},
                        "last": {"type": "boolean"},
                        "number": {"type": "integer", "format": "int32"},
                        "numberOfElements": {"type": "integer", "format": "int32"},
                        "pageable": {
                            "type": "object",
                            "properties": {
                                "offset": {"type": "integer", "format": "int64"},
                                "pageNumber": {"type": "integer", "format": "int32"},
                                "pageSize": {"type": "integer", "format": "int32"},
                                "paged": {"type": "boolean"},
                                "sort": {
                                    "type": "object",
                                    "properties": {
                                        "empty": {"type": "boolean"},
                                        "sorted": {"type": "boolean"},
                                        "unsorted": {"type": "boolean"},
                                    },
                                    "title": "Sort",
                                },
                                "unpaged": {"type": "boolean"},
                            },
                            "title": "Pageable",
                        },
                        "size": {"type": "integer", "format": "int32"},
                        "sort": {
                            "type": "object",
                            "properties": {
                                "empty": {"type": "boolean"},
                                "sorted": {"type": "boolean"},
                                "unsorted": {"type": "boolean"},
                            },
                            "title": "Sort",
                        },
                        "totalElements": {"type": "integer", "format": "int64"},
                        "totalPages": {"type": "integer", "format": "int32"},
                    },
                    "title": "PageZooSubEntiteit",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_distinct_soort_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getDistinctSoort
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/subEntiteiten/distinct/soort",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "array", "items": {"type": "string"}}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_sub_entiteit_selections_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSubEntiteitSelections
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/subEntiteiten/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {"type": "integer", "format": "int64"},
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_omvang_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZooOmvang
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/entiteiten/{entiteit_nummer}/zoo/omvang",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "aantalBezwarenVerzoekenEnBeroepen": {
                            "type": "integer",
                            "format": "int32",
                        },
                        "aantalBsnRsinsInEntiteit": {
                            "type": "integer",
                            "format": "int32",
                        },
                        "aantalBuitenlandseDeelnemingen": {
                            "type": "integer",
                            "format": "int32",
                        },
                        "aantalVasteInrichtingen": {
                            "type": "integer",
                            "format": "int32",
                        },
                        "belastingschuld": {"type": "integer"},
                        "entiteitNummer": {"type": "integer", "format": "int64"},
                        "lastUpdated": {"type": "string", "format": "date-time"},
                        "lastUpdatedByUserId": {"type": "string"},
                        "totaalBetalingenJaarX": {"type": "integer"},
                        "totaalBetalingenJaarXMin1": {"type": "integer"},
                        "totaalBetalingenJaarXMin2": {"type": "integer"},
                        "totaleVrijgesteldeOmzet": {"type": "integer"},
                        "totalenAanslagenPerJaarVpb": {"type": "integer"},
                        "totalenPerJaarLhAantalLoongerechtigden": {"type": "integer"},
                        "totalenPerJaarLhTotaalLoonsom": {"type": "integer"},
                        "totalenPerJaarOb": {"type": "integer"},
                        "wolbSom": {"type": "number"},
                    },
                    "title": "ZooOmvang",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_zoo_omvang_using_put(
        self,
        entiteit_nummer,
        authorization=None,
        zoo_omvang_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveZooOmvang
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "aantalBezwarenVerzoekenEnBeroepen": {
                                "type": "integer",
                                "format": "int32",
                            },
                            "aantalBsnRsinsInEntiteit": {
                                "type": "integer",
                                "format": "int32",
                            },
                            "aantalBuitenlandseDeelnemingen": {
                                "type": "integer",
                                "format": "int32",
                            },
                            "aantalVasteInrichtingen": {
                                "type": "integer",
                                "format": "int32",
                            },
                            "belastingschuld": {"type": "integer"},
                            "entiteitNummer": {"type": "integer", "format": "int64"},
                            "lastUpdated": {"type": "string", "format": "date-time"},
                            "lastUpdatedByUserId": {"type": "string"},
                            "totaalBetalingenJaarX": {"type": "integer"},
                            "totaalBetalingenJaarXMin1": {"type": "integer"},
                            "totaalBetalingenJaarXMin2": {"type": "integer"},
                            "totaleVrijgesteldeOmzet": {"type": "integer"},
                            "totalenAanslagenPerJaarVpb": {"type": "integer"},
                            "totalenPerJaarLhAantalLoongerechtigden": {
                                "type": "integer"
                            },
                            "totalenPerJaarLhTotaalLoonsom": {"type": "integer"},
                            "totalenPerJaarOb": {"type": "integer"},
                            "wolbSom": {"type": "number"},
                        },
                        "title": "ZooOmvang",
                    },
                },
                "title": "LoggingWrapperZooOmvang",
            }
            self.validate.schema(json.loads(zoo_omvang_dto), schema)

        _body = overwrite_body if overwrite_body else zoo_omvang_dto
        response = self.put(
            f"/api/entiteiten/{entiteit_nummer}/zoo/omvang",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "aantalBezwarenVerzoekenEnBeroepen": {
                            "type": "integer",
                            "format": "int32",
                        },
                        "aantalBsnRsinsInEntiteit": {
                            "type": "integer",
                            "format": "int32",
                        },
                        "aantalBuitenlandseDeelnemingen": {
                            "type": "integer",
                            "format": "int32",
                        },
                        "aantalVasteInrichtingen": {
                            "type": "integer",
                            "format": "int32",
                        },
                        "belastingschuld": {"type": "integer"},
                        "entiteitNummer": {"type": "integer", "format": "int64"},
                        "lastUpdated": {"type": "string", "format": "date-time"},
                        "lastUpdatedByUserId": {"type": "string"},
                        "totaalBetalingenJaarX": {"type": "integer"},
                        "totaalBetalingenJaarXMin1": {"type": "integer"},
                        "totaalBetalingenJaarXMin2": {"type": "integer"},
                        "totaleVrijgesteldeOmzet": {"type": "integer"},
                        "totalenAanslagenPerJaarVpb": {"type": "integer"},
                        "totalenPerJaarLhAantalLoongerechtigden": {"type": "integer"},
                        "totalenPerJaarLhTotaalLoonsom": {"type": "integer"},
                        "totalenPerJaarOb": {"type": "integer"},
                        "wolbSom": {"type": "number"},
                    },
                    "title": "ZooOmvang",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
