import logging
import json

from roboswag import APIModel


class KlantsessieStatusRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_current_klantsessie_status_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getCurrentKlantsessieStatus
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/status/{entiteit_nummer}/{middel_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "complianceStatus": {
                            "type": "string",
                            "enum": [
                                "DISABLED",
                                "INITIAL",
                                "TOUCHED",
                                "COMPLETED",
                                "DONE",
                            ],
                        },
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "strategieStatus": {
                            "type": "string",
                            "enum": [
                                "DISABLED",
                                "INITIAL",
                                "TOUCHED",
                                "COMPLETED",
                                "DONE",
                            ],
                        },
                        "voorbereidingAfgerond": {"type": "boolean"},
                        "voorbereidingAfrondenStatus": {
                            "type": "string",
                            "enum": [
                                "DISABLED",
                                "INITIAL",
                                "TOUCHED",
                                "COMPLETED",
                                "DONE",
                            ],
                        },
                        "zooefStatus": {
                            "type": "string",
                            "enum": [
                                "DISABLED",
                                "INITIAL",
                                "TOUCHED",
                                "COMPLETED",
                                "DONE",
                            ],
                        },
                    },
                    "title": "KlantsessieStatus",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_voorbereiding_afgerond_using_post(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        logging_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateVoorbereidingAfgerond
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {"loggingId": {"type": "string"}},
                "title": "LoggingWrapperVoid",
            }
            self.validate.schema(json.loads(logging_wrapper), schema)

        _body = overwrite_body if overwrite_body else logging_wrapper
        response = self.post(
            f"/api/klantsessie/status/{entiteit_nummer}/{middel_id}/voorbereidingAfgerond",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
