import logging
import json

from roboswag import APIModel


class FiscaliteitOptionsController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_zo_f_middel_risico_beheersing_options_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZoFMiddelRisicoBeheersingOptions
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/fiscaliteit/options/middel-risico-beheersing",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_middel_risico_statussen_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getMiddelRisicoStatussen
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/fiscaliteit/options/middel-risico-status",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
