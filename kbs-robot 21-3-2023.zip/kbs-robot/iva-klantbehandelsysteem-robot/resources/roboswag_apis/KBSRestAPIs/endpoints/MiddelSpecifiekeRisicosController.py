import logging
import json

from roboswag import APIModel


class MiddelSpecifiekeRisicosController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def check_list_valid_to_business_rules_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        middel_specifieke_risico_check_list_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** checkListValidToBusinessRules
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "middelSpecifiekeRisico": {
                        "type": "object",
                        "properties": {
                            "beheersing": {"type": "integer", "format": "int32"},
                            "currentId": {"type": "integer", "format": "int64"},
                            "hoofdRisicoId": {"type": "integer", "format": "int64"},
                            "kenmerkId": {"type": "integer", "format": "int64"},
                            "keyRisk": {"type": "integer", "format": "int32"},
                            "statusId": {"type": "integer", "format": "int64"},
                            "subRisicoId": {"type": "integer", "format": "int64"},
                        },
                        "title": "MiddelSpecifiekeRisicoSelectionDto",
                    },
                    "middelSpecifiekeRisicoList": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "beheersing": {"type": "integer", "format": "int32"},
                                "entiteitMiddelKenmerkId": {
                                    "type": "integer",
                                    "format": "int64",
                                },
                                "entiteitNummer": {
                                    "type": "integer",
                                    "format": "int64",
                                },
                                "hoofdRisicoId": {"type": "integer", "format": "int64"},
                                "id": {"type": "integer", "format": "int64"},
                                "keyRisk": {"type": "integer", "format": "int32"},
                                "middelKenmerk": {
                                    "type": "object",
                                    "properties": {
                                        "id": {"type": "integer", "format": "int64"},
                                        "kenmerk": {"type": "string"},
                                        "middelId": {
                                            "type": "integer",
                                            "format": "int32",
                                        },
                                        "parentId": {
                                            "type": "integer",
                                            "format": "int64",
                                        },
                                    },
                                    "title": "MiddelKenmerk",
                                },
                                "rank": {"type": "integer", "format": "int64"},
                                "statusId": {"type": "integer", "format": "int64"},
                                "subRisicoId": {"type": "integer", "format": "int64"},
                            },
                            "title": "EntiteitMiddelRisicoDto",
                        },
                    },
                },
                "title": "MiddelSpecifiekeRisicoCheckListDto",
            }
            self.validate.schema(
                json.loads(middel_specifieke_risico_check_list_dto), schema
            )

        _body = (
            overwrite_body
            if overwrite_body
            else middel_specifieke_risico_check_list_dto
        )
        response = self.post(
            f"/api/middel-specifieke-risicos/check/list/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {"errorMessage": {"type": "string"}},
                    "title": "BusinessRuleResponse",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def check_valid_to_business_rules_using_post_1(
        self,
        entiteit_nummer,
        authorization=None,
        selectie_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** checkValidToBusinessRules
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "beheersing": {"type": "integer", "format": "int32"},
                    "currentId": {"type": "integer", "format": "int64"},
                    "hoofdRisicoId": {"type": "integer", "format": "int64"},
                    "kenmerkId": {"type": "integer", "format": "int64"},
                    "keyRisk": {"type": "integer", "format": "int32"},
                    "statusId": {"type": "integer", "format": "int64"},
                    "subRisicoId": {"type": "integer", "format": "int64"},
                },
                "title": "MiddelSpecifiekeRisicoSelectionDto",
            }
            self.validate.schema(json.loads(selectie_dto), schema)

        _body = overwrite_body if overwrite_body else selectie_dto
        response = self.post(
            f"/api/middel-specifieke-risicos/check/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {"errorMessage": {"type": "string"}},
                    "title": "BusinessRuleResponse",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_list_valid_to_business_rules_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        entiteit_middel_risico_dto_list=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveListValidToBusinessRules
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "beheersing": {"type": "integer", "format": "int32"},
                                "entiteitMiddelKenmerkId": {
                                    "type": "integer",
                                    "format": "int64",
                                },
                                "entiteitNummer": {
                                    "type": "integer",
                                    "format": "int64",
                                },
                                "hoofdRisicoId": {"type": "integer", "format": "int64"},
                                "id": {"type": "integer", "format": "int64"},
                                "keyRisk": {"type": "integer", "format": "int32"},
                                "middelKenmerk": {
                                    "type": "object",
                                    "properties": {
                                        "id": {"type": "integer", "format": "int64"},
                                        "kenmerk": {"type": "string"},
                                        "middelId": {
                                            "type": "integer",
                                            "format": "int32",
                                        },
                                        "parentId": {
                                            "type": "integer",
                                            "format": "int64",
                                        },
                                    },
                                    "title": "MiddelKenmerk",
                                },
                                "rank": {"type": "integer", "format": "int64"},
                                "statusId": {"type": "integer", "format": "int64"},
                                "subRisicoId": {"type": "integer", "format": "int64"},
                            },
                            "title": "EntiteitMiddelRisicoDto",
                        },
                    },
                },
                "title": "LoggingWrapperListEntiteitMiddelRisicoDto",
            }
            self.validate.schema(json.loads(entiteit_middel_risico_dto_list), schema)

        _body = overwrite_body if overwrite_body else entiteit_middel_risico_dto_list
        response = self.post(
            f"/api/middel-specifieke-risicos/save/list/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {"errorMessage": {"type": "string"}},
                    "title": "BusinessRuleResponse",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_overview_using_get(
        self,
        entiteitnummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getOverview
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/middel-specifieke-risicos/{entiteitnummer}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "beheersing": {"type": "string"},
                            "keyRisk": {"type": "integer", "format": "int32"},
                            "keyRiskAsString": {"type": "string"},
                            "middelAfkorting": {"type": "string"},
                            "risicoName": {"type": "string"},
                            "status": {"type": "string"},
                        },
                        "title": "LowestEntiteitMiddelRisicoDto",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
