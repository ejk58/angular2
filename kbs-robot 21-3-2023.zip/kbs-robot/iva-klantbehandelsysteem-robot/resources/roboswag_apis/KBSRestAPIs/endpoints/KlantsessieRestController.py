import logging
import json

from roboswag import APIModel


class KlantsessieRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_current_klantsessie_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getCurrentKlantsessie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/{entiteit_nummer}", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "actGebaseerdGehoudenKlantsessie": {"type": "boolean"},
                        "controlePlaatsgevonden": {"type": "boolean"},
                        "einddatum": {"type": "string", "format": "date-time"},
                        "entiteitNummer": {"type": "integer", "format": "int64"},
                        "id": {"type": "integer", "format": "int64"},
                        "startdatum": {"type": "string", "format": "date-time"},
                        "toelichtingGehoudenKlantsessie": {"type": "string"},
                        "zichtOpOrganisatieEnFiscaliteitPerMiddel": {
                            "type": "object",
                            "additionalProperties": {
                                "type": "object",
                                "properties": {
                                    "klantsessieId": {
                                        "type": "integer",
                                        "format": "int64",
                                    },
                                    "middelId": {"type": "integer", "format": "int32"},
                                    "observaties": {"type": "string"},
                                    "vorigeObservatiesNogActueel": {"type": "boolean"},
                                },
                                "title": "KlantsessieZooef",
                            },
                        },
                    },
                    "title": "Klantsessie",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_controle_plaatsgevonden_using_post_1(
        self,
        entiteit_nummer,
        authorization=None,
        controle_plaatsgevonden_body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateControlePlaatsgevonden
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {"type": "boolean"},
                },
                "title": "LoggingWrapperboolean",
            }
            self.validate.schema(json.loads(controle_plaatsgevonden_body), schema)

        _body = overwrite_body if overwrite_body else controle_plaatsgevonden_body
        response = self.post(
            f"/api/klantsessie/{entiteit_nummer}/controlePlaatsgevonden",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "actGebaseerdGehoudenKlantsessie": {"type": "boolean"},
                        "controlePlaatsgevonden": {"type": "boolean"},
                        "einddatum": {"type": "string", "format": "date-time"},
                        "entiteitNummer": {"type": "integer", "format": "int64"},
                        "id": {"type": "integer", "format": "int64"},
                        "startdatum": {"type": "string", "format": "date-time"},
                        "toelichtingGehoudenKlantsessie": {"type": "string"},
                        "zichtOpOrganisatieEnFiscaliteitPerMiddel": {
                            "type": "object",
                            "additionalProperties": {
                                "type": "object",
                                "properties": {
                                    "klantsessieId": {
                                        "type": "integer",
                                        "format": "int64",
                                    },
                                    "middelId": {"type": "integer", "format": "int32"},
                                    "observaties": {"type": "string"},
                                    "vorigeObservatiesNogActueel": {"type": "boolean"},
                                },
                                "title": "KlantsessieZooef",
                            },
                        },
                    },
                    "title": "Klantsessie",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_klantsessie_afgerond_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        logging_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateKlantsessieAfgerond
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {"loggingId": {"type": "string"}},
                "title": "LoggingWrapperVoid",
            }
            self.validate.schema(json.loads(logging_wrapper), schema)

        _body = overwrite_body if overwrite_body else logging_wrapper
        response = self.post(
            f"/api/klantsessie/{entiteit_nummer}/klantsessie-afronden",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "actGebaseerdGehoudenKlantsessie": {"type": "boolean"},
                        "controlePlaatsgevonden": {"type": "boolean"},
                        "einddatum": {"type": "string", "format": "date-time"},
                        "entiteitNummer": {"type": "integer", "format": "int64"},
                        "id": {"type": "integer", "format": "int64"},
                        "startdatum": {"type": "string", "format": "date-time"},
                        "toelichtingGehoudenKlantsessie": {"type": "string"},
                        "zichtOpOrganisatieEnFiscaliteitPerMiddel": {
                            "type": "object",
                            "additionalProperties": {
                                "type": "object",
                                "properties": {
                                    "klantsessieId": {
                                        "type": "integer",
                                        "format": "int64",
                                    },
                                    "middelId": {"type": "integer", "format": "int32"},
                                    "observaties": {"type": "string"},
                                    "vorigeObservatiesNogActueel": {"type": "boolean"},
                                },
                                "title": "KlantsessieZooef",
                            },
                        },
                    },
                    "title": "Klantsessie",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def check_klantsessie_afronden_enabled_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** checkKlantsessieAfrondenEnabled
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/{entiteit_nummer}/klantsessie-afronden-enabled",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "boolean"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_previous_klantsessie_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getPreviousKlantsessie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/{entiteit_nummer}/previous",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "actGebaseerdGehoudenKlantsessie": {"type": "boolean"},
                        "controlePlaatsgevonden": {"type": "boolean"},
                        "einddatum": {"type": "string", "format": "date-time"},
                        "entiteitNummer": {"type": "integer", "format": "int64"},
                        "id": {"type": "integer", "format": "int64"},
                        "startdatum": {"type": "string", "format": "date-time"},
                        "toelichtingGehoudenKlantsessie": {"type": "string"},
                        "zichtOpOrganisatieEnFiscaliteitPerMiddel": {
                            "type": "object",
                            "additionalProperties": {
                                "type": "object",
                                "properties": {
                                    "klantsessieId": {
                                        "type": "integer",
                                        "format": "int64",
                                    },
                                    "middelId": {"type": "integer", "format": "int32"},
                                    "observaties": {"type": "string"},
                                    "vorigeObservatiesNogActueel": {"type": "boolean"},
                                },
                                "title": "KlantsessieZooef",
                            },
                        },
                    },
                    "title": "Klantsessie",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_huidige_klantsessie_observaties_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getHuidigeKlantsessieObservaties
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/{entiteit_nummer}/{middel_id}/huidigeKlantsessieObservaties",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "observaties": {"type": "string"},
                        "vorigeObservatiesNogActueel": {"type": "boolean"},
                    },
                    "title": "KlantsessieZooef",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_zooef_observaties_using_post(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        observatie=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateZooefObservaties
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {"type": "string"},
                },
                "title": "LoggingWrapperstring",
            }
            self.validate.schema(json.loads(observatie), schema)

        _body = overwrite_body if overwrite_body else observatie
        response = self.post(
            f"/api/klantsessie/{entiteit_nummer}/{middel_id}/nieuweInzichtenEnObservaties",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "observaties": {"type": "string"},
                        "vorigeObservatiesNogActueel": {"type": "boolean"},
                    },
                    "title": "KlantsessieZooef",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_zooef_vorige_observaties_nog_actueel_using_post(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        observaties_actueel=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateZooefVorigeObservatiesNogActueel
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {"type": "boolean"},
                },
                "title": "LoggingWrapperboolean",
            }
            self.validate.schema(json.loads(observaties_actueel), schema)

        _body = overwrite_body if overwrite_body else observaties_actueel
        response = self.post(
            f"/api/klantsessie/{entiteit_nummer}/{middel_id}/observatiesActueel",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "observaties": {"type": "string"},
                        "vorigeObservatiesNogActueel": {"type": "boolean"},
                    },
                    "title": "KlantsessieZooef",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
