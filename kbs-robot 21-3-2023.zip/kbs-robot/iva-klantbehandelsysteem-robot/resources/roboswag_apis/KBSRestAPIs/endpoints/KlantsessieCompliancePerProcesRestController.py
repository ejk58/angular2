import logging
import json

from roboswag import APIModel


class KlantsessieCompliancePerProcesRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_compliance_per_proces_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getCompliancePerProces
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/compliance/per-proces/{entiteit_nummer}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "afkorting": {"type": "string"},
                            "bezwaren": {"type": "string"},
                            "heffing": {"type": "string"},
                            "vooroverleg": {"type": "string"},
                        },
                        "title": "PerProcesWithAbbreviatedMiddelProjection",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_klantsessie_compliance_per_proces_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        perproces=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateKlantsessieCompliancePerProces
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "bezwaren": {"type": "integer", "format": "int32"},
                            "heffing": {"type": "integer", "format": "int32"},
                            "klantsessieId": {"type": "integer", "format": "int64"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "vooroverleg": {"type": "integer", "format": "int32"},
                        },
                        "title": "PerProcesDto",
                    },
                },
                "title": "LoggingWrapperPerProcesDto",
            }
            self.validate.schema(json.loads(perproces), schema)

        _body = overwrite_body if overwrite_body else perproces
        response = self.post(
            f"/api/klantsessie/compliance/per-proces/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "bezwaren": {"type": "integer", "format": "int32"},
                        "heffing": {"type": "integer", "format": "int32"},
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "vooroverleg": {"type": "integer", "format": "int32"},
                    },
                    "title": "KlantsessieCompliancePerProces",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_klantsessie_compliance_per_proces_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getKlantsessieCompliancePerProces
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/compliance/per-proces/{entiteit_nummer}/{middel_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "bezwaren": {"type": "integer", "format": "int32"},
                        "heffing": {"type": "integer", "format": "int32"},
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "vooroverleg": {"type": "integer", "format": "int32"},
                    },
                    "title": "KlantsessieCompliancePerProces",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
