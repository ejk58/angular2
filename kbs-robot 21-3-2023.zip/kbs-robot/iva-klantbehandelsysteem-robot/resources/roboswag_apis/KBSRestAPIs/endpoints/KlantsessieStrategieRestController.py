import logging
import json

from roboswag import APIModel


class KlantsessieStrategieRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_current_klantsessie_strategie_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getCurrentKlantsessieStrategie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/strategie/current/{entiteit_nummer}/{middel_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "korteTermijn": {"type": "string"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "middellangeTermijn": {"type": "string"},
                    },
                    "title": "KlantsessieStrategieDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_previous_klantsessie_strategie_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getPreviousKlantsessieStrategie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/strategie/previous/{entiteit_nummer}/{middel_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "korteTermijn": {"type": "string"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "middellangeTermijn": {"type": "string"},
                    },
                    "title": "KlantsessieStrategieDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def delete_klantsessie_strategie_risico_using_delete(
        self,
        entiteit_nummer,
        klantsessie_id,
        middel_id,
        risco_id,
        authorization=None,
        logging_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** deleteKlantsessieStrategieRisico
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {"loggingId": {"type": "string"}},
                "title": "LoggingWrapperVoid",
            }
            self.validate.schema(json.loads(logging_wrapper), schema)

        _body = overwrite_body if overwrite_body else logging_wrapper
        response = self.delete(
            f"/api/klantsessie/strategie/risico/delete/{entiteit_nummer}/{klantsessie_id}/{middel_id}/{risco_id}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 204:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_risico_options_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getRisicoOptions
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/strategie/risico/options/{entiteit_nummer}/{middel_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int64"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "parentId": {"type": "integer", "format": "int64"},
                            "rank": {"type": "integer", "format": "int64"},
                            "risico": {"type": "string"},
                        },
                        "title": "MiddelRisico",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_risicos_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedRisicos
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/strategie/risico/selected/{entiteit_nummer}/{middel_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int64"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "parentId": {"type": "integer", "format": "int64"},
                            "rank": {"type": "integer", "format": "int64"},
                            "risico": {"type": "string"},
                        },
                        "title": "MiddelRisico",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_selected_risicos_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        klantsessie_strategie_risico_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveSelectedRisicos
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "klantsessieId": {"type": "integer", "format": "int64"},
                                "middelId": {"type": "integer", "format": "int32"},
                                "middelRisico": {
                                    "type": "object",
                                    "properties": {
                                        "id": {"type": "integer", "format": "int64"},
                                        "middelId": {
                                            "type": "integer",
                                            "format": "int32",
                                        },
                                        "parentId": {
                                            "type": "integer",
                                            "format": "int64",
                                        },
                                        "rank": {"type": "integer", "format": "int64"},
                                        "risico": {"type": "string"},
                                    },
                                    "title": "MiddelRisico",
                                },
                                "risicoId": {"type": "integer", "format": "int64"},
                            },
                            "title": "KlantsessieStrategieRisico",
                        },
                    },
                },
                "title": "LoggingWrapperListKlantsessieStrategieRisico",
            }
            self.validate.schema(
                json.loads(klantsessie_strategie_risico_wrapper), schema
            )

        _body = (
            overwrite_body if overwrite_body else klantsessie_strategie_risico_wrapper
        )
        response = self.post(
            f"/api/klantsessie/strategie/risico/selections/save/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_korte_termijn_klantsessie_strategie_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        klantsessie_strategie_dto_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveKorteTermijnKlantsessieStrategie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "klantsessieId": {"type": "integer", "format": "int64"},
                            "korteTermijn": {"type": "string"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "middellangeTermijn": {"type": "string"},
                        },
                        "title": "KlantsessieStrategieDto",
                    },
                },
                "title": "LoggingWrapperKlantsessieStrategieDto",
            }
            self.validate.schema(json.loads(klantsessie_strategie_dto_wrapper), schema)

        _body = overwrite_body if overwrite_body else klantsessie_strategie_dto_wrapper
        response = self.post(
            f"/api/klantsessie/strategie/save/korteTermijn/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "korteTermijn": {"type": "string"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "middellangeTermijn": {"type": "string"},
                    },
                    "title": "KlantsessieStrategieDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_middellange_termijn_klantsessie_strategie_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        klantsessie_strategie_dto_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveMiddellangeTermijnKlantsessieStrategie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "klantsessieId": {"type": "integer", "format": "int64"},
                            "korteTermijn": {"type": "string"},
                            "middelId": {"type": "integer", "format": "int32"},
                            "middellangeTermijn": {"type": "string"},
                        },
                        "title": "KlantsessieStrategieDto",
                    },
                },
                "title": "LoggingWrapperKlantsessieStrategieDto",
            }
            self.validate.schema(json.loads(klantsessie_strategie_dto_wrapper), schema)

        _body = overwrite_body if overwrite_body else klantsessie_strategie_dto_wrapper
        response = self.post(
            f"/api/klantsessie/strategie/save/middellangeTermijn/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "korteTermijn": {"type": "string"},
                        "middelId": {"type": "integer", "format": "int32"},
                        "middellangeTermijn": {"type": "string"},
                    },
                    "title": "KlantsessieStrategieDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
