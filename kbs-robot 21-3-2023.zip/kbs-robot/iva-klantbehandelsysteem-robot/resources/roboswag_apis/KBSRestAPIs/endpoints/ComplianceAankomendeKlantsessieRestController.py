import logging
import json

from roboswag import APIModel


class ComplianceAankomendeKlantsessieRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_act_gebaseerd_gehouden_klantsessie_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getActGebaseerdGehoudenKlantsessie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/compliance-aankomende/act-gebaseerd-gehouden-klantsessie/{entiteit_nummer}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "boolean"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_act_gebaseerd_gehouden_klantsessie_using_put(
        self,
        entiteit_nummer,
        authorization=None,
        logging_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateActGebaseerdGehoudenKlantsessie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {"loggingId": {"type": "string"}},
                "title": "LoggingWrapperVoid",
            }
            self.validate.schema(json.loads(logging_wrapper), schema)

        _body = overwrite_body if overwrite_body else logging_wrapper
        response = self.put(
            f"/api/klantsessie/compliance-aankomende/act-gebaseerd-gehouden-klantsessie/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "boolean"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_toelichting_gehouden_klantsessie_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getToelichtingGehoudenKlantsessie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/compliance-aankomende/toelichting-gehouden-klantsessie/{entiteit_nummer}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {"toelichting": {"type": "string"}},
                    "title": "ComplianceAankomendeKlantSessieToelichtingDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_toelichting_gehouden_klantsessie_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        text_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateToelichtingGehoudenKlantsessie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {"toelichting": {"type": "string"}},
                        "title": "ComplianceAankomendeKlantSessieToelichtingDto",
                    },
                },
                "title": "LoggingWrapperComplianceAankomendeKlantSessieToelichtingDto",
            }
            self.validate.schema(json.loads(text_dto), schema)

        _body = overwrite_body if overwrite_body else text_dto
        response = self.post(
            f"/api/klantsessie/compliance-aankomende/toelichting-gehouden-klantsessie/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {"toelichting": {"type": "string"}},
                    "title": "ComplianceAankomendeKlantSessieToelichtingDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_klantsessie_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getKlantsessie
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/compliance-aankomende/{entiteit_nummer}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "kenmerk": {"type": "string"},
                            "uitkomsten": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "beschrijving": {"type": "string"},
                                        "kenmerkId": {
                                            "type": "integer",
                                            "format": "int32",
                                        },
                                        "score": {"type": "integer", "format": "int32"},
                                        "strategie": {
                                            "type": "integer",
                                            "format": "int32",
                                        },
                                        "toelichting": {"type": "string"},
                                    },
                                    "title": "ComplianceUitkomst",
                                },
                            },
                        },
                        "title": "ComplianceAankomendeKlantsessieDto",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_controle_plaatsgevonden_using_post(
        self,
        entiteit_nummer,
        authorization=None,
        uitkomst_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateControlePlaatsgevonden
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "beschrijving": {"type": "string"},
                            "kenmerkId": {"type": "integer", "format": "int32"},
                            "score": {"type": "integer", "format": "int32"},
                            "strategie": {"type": "integer", "format": "int32"},
                            "toelichting": {"type": "string"},
                        },
                        "title": "ComplianceUitkomst",
                    },
                },
                "title": "LoggingWrapperComplianceUitkomst",
            }
            self.validate.schema(json.loads(uitkomst_dto), schema)

        _body = overwrite_body if overwrite_body else uitkomst_dto
        response = self.post(
            f"/api/klantsessie/compliance-aankomende/{entiteit_nummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "kenmerkId": {"type": "integer", "format": "int32"},
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "score": {"type": "integer", "format": "int32"},
                        "strategieGerichtOp": {"type": "integer", "format": "int32"},
                        "toelichting": {"type": "string"},
                    },
                    "title": "KlantsessieUitkomst",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
