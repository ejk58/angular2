import logging
import json

from roboswag import APIModel


class KlantsessieComplianceRestController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_klantsessie_compliance_chart_labels_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getKlantsessieComplianceChartLabels
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/klantsessie/compliance/chart-labels",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int32"},
                            "label": {"type": "string"},
                        },
                        "title": "ChartLabel",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_previous_klantsessie_compliance_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getPreviousKlantsessieCompliance
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/compliance/previous/{entiteit_nummer}/{middel_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "kenmerkParents": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "kenmerk": {
                                        "type": "object",
                                        "properties": {
                                            "groep": {"type": "string"},
                                            "id": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                            "kenmerk": {"type": "string"},
                                            "kenmerkParentId": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                        },
                                        "title": "Kenmerk",
                                    },
                                    "kenmerkChildren": {
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "kenmerk": {
                                                    "type": "object",
                                                    "properties": {
                                                        "groep": {"type": "string"},
                                                        "id": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                        "kenmerk": {"type": "string"},
                                                        "kenmerkParentId": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                    },
                                                    "title": "Kenmerk",
                                                },
                                                "score": {
                                                    "type": "integer",
                                                    "format": "int32",
                                                },
                                                "toelichting": {"type": "string"},
                                            },
                                            "title": "KenmerkChild",
                                        },
                                    },
                                },
                                "title": "KenmerkParent",
                            },
                        },
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "lastKlantSessieDate": {"type": "string", "format": "date"},
                    },
                    "title": "KlantsessieComplianceDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_klantsessie_compliance_score_using_post(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        kenmerk_child_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateKlantsessieComplianceScore
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "kenmerk": {
                                "type": "object",
                                "properties": {
                                    "groep": {"type": "string"},
                                    "id": {"type": "integer", "format": "int32"},
                                    "kenmerk": {"type": "string"},
                                    "kenmerkParentId": {
                                        "type": "integer",
                                        "format": "int32",
                                    },
                                },
                                "title": "Kenmerk",
                            },
                            "score": {"type": "integer", "format": "int32"},
                            "toelichting": {"type": "string"},
                        },
                        "title": "KenmerkChild",
                    },
                },
                "title": "LoggingWrapperKenmerkChild",
            }
            self.validate.schema(json.loads(kenmerk_child_dto), schema)

        _body = overwrite_body if overwrite_body else kenmerk_child_dto
        response = self.post(
            f"/api/klantsessie/compliance/score/{entiteit_nummer}/{middel_id}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "kenmerk": {
                            "type": "object",
                            "properties": {
                                "groep": {"type": "string"},
                                "id": {"type": "integer", "format": "int32"},
                                "kenmerk": {"type": "string"},
                                "kenmerkParentId": {
                                    "type": "integer",
                                    "format": "int32",
                                },
                            },
                            "title": "Kenmerk",
                        },
                        "score": {"type": "integer", "format": "int32"},
                        "toelichting": {"type": "string"},
                    },
                    "title": "KenmerkChild",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_klantsessie_compliance_toelichting_using_post(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        kenmerk_child_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateKlantsessieComplianceToelichting
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "kenmerk": {
                                "type": "object",
                                "properties": {
                                    "groep": {"type": "string"},
                                    "id": {"type": "integer", "format": "int32"},
                                    "kenmerk": {"type": "string"},
                                    "kenmerkParentId": {
                                        "type": "integer",
                                        "format": "int32",
                                    },
                                },
                                "title": "Kenmerk",
                            },
                            "score": {"type": "integer", "format": "int32"},
                            "toelichting": {"type": "string"},
                        },
                        "title": "KenmerkChild",
                    },
                },
                "title": "LoggingWrapperKenmerkChild",
            }
            self.validate.schema(json.loads(kenmerk_child_dto), schema)

        _body = overwrite_body if overwrite_body else kenmerk_child_dto
        response = self.post(
            f"/api/klantsessie/compliance/toelichting/{entiteit_nummer}/{middel_id}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "kenmerk": {
                            "type": "object",
                            "properties": {
                                "groep": {"type": "string"},
                                "id": {"type": "integer", "format": "int32"},
                                "kenmerk": {"type": "string"},
                                "kenmerkParentId": {
                                    "type": "integer",
                                    "format": "int32",
                                },
                            },
                            "title": "Kenmerk",
                        },
                        "score": {"type": "integer", "format": "int32"},
                        "toelichting": {"type": "string"},
                    },
                    "title": "KenmerkChild",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_current_klantsessie_compliance_using_get(
        self,
        entiteit_nummer,
        middel_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getCurrentKlantsessieCompliance
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/klantsessie/compliance/{entiteit_nummer}/{middel_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "kenmerkParents": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "kenmerk": {
                                        "type": "object",
                                        "properties": {
                                            "groep": {"type": "string"},
                                            "id": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                            "kenmerk": {"type": "string"},
                                            "kenmerkParentId": {
                                                "type": "integer",
                                                "format": "int32",
                                            },
                                        },
                                        "title": "Kenmerk",
                                    },
                                    "kenmerkChildren": {
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "kenmerk": {
                                                    "type": "object",
                                                    "properties": {
                                                        "groep": {"type": "string"},
                                                        "id": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                        "kenmerk": {"type": "string"},
                                                        "kenmerkParentId": {
                                                            "type": "integer",
                                                            "format": "int32",
                                                        },
                                                    },
                                                    "title": "Kenmerk",
                                                },
                                                "score": {
                                                    "type": "integer",
                                                    "format": "int32",
                                                },
                                                "toelichting": {"type": "string"},
                                            },
                                            "title": "KenmerkChild",
                                        },
                                    },
                                },
                                "title": "KenmerkParent",
                            },
                        },
                        "klantsessieId": {"type": "integer", "format": "int64"},
                        "lastKlantSessieDate": {"type": "string", "format": "date"},
                    },
                    "title": "KlantsessieComplianceDto",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
