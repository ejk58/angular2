import logging
import json

from roboswag import APIModel


class HelptextController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def store_helptext_using_post(
        self,
        authorization=None,
        helptext_dto=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** storeHelptext
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "changed": {"type": "string", "format": "date-time"},
                            "entiteit": {"type": "integer", "format": "int64"},
                            "id": {"type": "string"},
                            "txt": {"type": "string"},
                            "userId": {"type": "string"},
                        },
                        "title": "Helptext",
                    },
                },
                "title": "LoggingWrapperHelptext",
            }
            self.validate.schema(json.loads(helptext_dto), schema)

        _body = overwrite_body if overwrite_body else helptext_dto
        response = self.post(
            "/api/helptext/save", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "changed": {"type": "string", "format": "date-time"},
                        "entiteit": {"type": "integer", "format": "int64"},
                        "id": {"type": "string"},
                        "txt": {"type": "string"},
                        "userId": {"type": "string"},
                    },
                    "title": "Helptext",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_helptext_using_get(
        self,
        helptext_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getHelptext
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/helptext/{helptext_id}", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "changed": {"type": "string", "format": "date-time"},
                        "entiteit": {"type": "integer", "format": "int64"},
                        "id": {"type": "string"},
                        "txt": {"type": "string"},
                        "userId": {"type": "string"},
                    },
                    "title": "Helptext",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_helptext_for_entiteit_using_get(
        self,
        entiteit_id,
        helptext_id,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getHelptextForEntiteit
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/helptext/{helptext_id}/for/{entiteit_id}",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "changed": {"type": "string", "format": "date-time"},
                        "entiteit": {"type": "integer", "format": "int64"},
                        "id": {"type": "string"},
                        "txt": {"type": "string"},
                        "userId": {"type": "string"},
                    },
                    "title": "Helptext",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
