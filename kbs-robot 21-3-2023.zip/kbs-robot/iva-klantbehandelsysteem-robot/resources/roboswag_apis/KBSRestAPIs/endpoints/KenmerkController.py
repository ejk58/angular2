import logging
import json

from roboswag import APIModel


class KenmerkController(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def get_kenmerken_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get("/api/kenmerken", headers=headers, status=exp_status)

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_aandachtsgebieden_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZooAandachtsgebieden
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/aandachtsgebieden", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_attentiepunten_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZooAttentiepunten
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/attentiepunten", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_attentiepunten_inkomsten_belasting_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZooAttentiepuntenInkomstenBelasting
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/attentiepunten-inkomstenbelasting",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer", "format": "int32"},
                            "items": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "groep": {"type": "string"},
                                        "id": {"type": "integer", "format": "int32"},
                                        "kenmerk": {"type": "string"},
                                        "kenmerkParentId": {
                                            "type": "integer",
                                            "format": "int32",
                                        },
                                    },
                                    "title": "Kenmerk",
                                },
                            },
                            "label": {"type": "string"},
                        },
                        "title": "MultiSelectKenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_attentiepunten_loonheffing_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZooAttentiepuntenLoonheffing
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/attentiepunten-loonheffing",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_bedrijfsstrategien_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getBedrijfsstrategien
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/bedrijfsstrategien", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_branchecode_aanvullingen_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZooBranchecodeAanvullingen
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/branche-code-aanvullingen",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_actiepunten_kenmerken_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getActiepuntenKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/cijferbeoordeling/actiepunten",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_actiepunten_balans_kenmerken_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getActiepuntenBalansKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/cijferbeoordeling/actiepunten-balans",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_actiepunten_winst_en_verlies_kenmerken_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getActiepuntenWinstEnVerliesKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/cijferbeoordeling/actiepunten-winst-en-verlies",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_complexiteit_kenmerken_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getComplexiteitKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/complexiteit", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_externe_omgeving_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getExterneOmgeving
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/externeOmgeving", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_governance_structuur_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getGovernanceStructuur
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/governanceStructuur", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_klantsessie_compliance_confort_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getKlantsessieComplianceConfort
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/klantsessie/compliance-comfort",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_middelen_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZooMiddelen
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/middelen", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_middel_by_name_using_get(
        self,
        name,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getMiddelByName
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/middelen/{name}", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "empty": {"type": "boolean"},
                        "present": {"type": "boolean"},
                    },
                    "title": "OptionalKenmerk",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_risicomanagement_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getRisicomanagement
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/risicomanagement", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_strategieen_gebaseerd_op_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getStrategieenGebaseerdOp
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/strategie-gebaseerd-op", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_test_kenmerken_using_get(
        self,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getTestKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            "/api/kenmerken/testKenmerken", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_aandachtsgebieden_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedAandachtsgebieden
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/aandachtsgebieden/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                            "values": {"type": "boolean"},
                        },
                        "title": "KenmerkWithValuesDto",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def ge_selected_actiepunten_balans_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** geSelectedActiepuntenBalans
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/actiepunten-balans/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def ge_selected_actiepunten_winst_en_verlies_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** geSelectedActiepuntenWinstEnVerlies
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/actiepunten-winst-en-verlies/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def ge_selected_actiepunten_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** geSelectedActiepunten
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/actiepunten/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_actiepunt_ids_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedActiepuntIds
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/attentiepunten-inkomstenbelasting/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_attentiepunten_loonheffing_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedAttentiepuntenLoonheffing
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/attentiepunten-loonheffing/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def ge_selected_attentiepunten_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** geSelectedAttentiepunten
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/attentiepunten/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def ge_selected_bedrijfsstrategien_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** geSelectedBedrijfsstrategien
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/bedrijfsstrategien/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_complexiteit_kenmerken_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedComplexiteitKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/complexiteit/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_externe_omgeving_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedExterneOmgeving
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/externeOmgeving/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_governance_structuur_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedGovernanceStructuur
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/governanceStructuur/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def ge_selected_middelen_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** geSelectedMiddelen
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/middelen/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_risicomanagement_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedRisicomanagement
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/risicomanagement/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_zoo_aard_sector_using_get(
        self,
        bsn_rsin,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getZooAardSector
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/sector", headers=headers, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "integer", "format": "int32"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_zoo_aard_sector_using_post(
        self,
        bsn_rsin,
        authorization=None,
        sector=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveZooAardSector
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {"type": "integer", "format": "int32"},
                },
                "title": "LoggingWrapperint",
            }
            self.validate.schema(json.loads(sector), schema)

        _body = overwrite_body if overwrite_body else sector
        response = self.post(
            f"/api/kenmerken/{bsn_rsin}/sector",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_selected_ids_using_post(
        self,
        bsn_rsin,
        kenmerk_type,
        authorization=None,
        kenmerk_ids=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveSelectedIds
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "array",
                        "items": {"type": "integer", "format": "int32"},
                    },
                },
                "title": "LoggingWrapperListint",
            }
            self.validate.schema(json.loads(kenmerk_ids), schema)

        _body = overwrite_body if overwrite_body else kenmerk_ids
        response = self.post(
            f"/api/kenmerken/{bsn_rsin}/{kenmerk_type}/selection-ids/save",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def remove_selected_kenmerken_using_post(
        self,
        bsn_rsin,
        kenmerk_type,
        authorization=None,
        kenmerken_ids=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** removeSelectedKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "array",
                        "items": {"type": "integer", "format": "int32"},
                    },
                },
                "title": "LoggingWrapperListint",
            }
            self.validate.schema(json.loads(kenmerken_ids), schema)

        _body = overwrite_body if overwrite_body else kenmerken_ids
        response = self.post(
            f"/api/kenmerken/{bsn_rsin}/{kenmerk_type}/selections/remove",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_selected_kenmerken_using_post(
        self,
        bsn_rsin,
        kenmerk_type,
        authorization=None,
        kenmerken=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveSelectedKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "groep": {"type": "string"},
                                "id": {"type": "integer", "format": "int32"},
                                "kenmerk": {"type": "string"},
                                "kenmerkParentId": {
                                    "type": "integer",
                                    "format": "int32",
                                },
                                "values": {"type": "boolean"},
                            },
                            "title": "KenmerkWithValuesDto",
                        },
                    },
                },
                "title": "LoggingWrapperListKenmerkWithValuesDto",
            }
            self.validate.schema(json.loads(kenmerken), schema)

        _body = overwrite_body if overwrite_body else kenmerken
        response = self.post(
            f"/api/kenmerken/{bsn_rsin}/{kenmerk_type}/selections/save",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def update_selected_kenmerken_using_put(
        self,
        bsn_rsin,
        kenmerk_type,
        parent_entiteitnummer,
        authorization=None,
        kenmerken2_update=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** updateSelectedKenmerken
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {
                    "loggingId": {"type": "string"},
                    "wrappedObject": {
                        "type": "object",
                        "properties": {
                            "entiteitKenmerken2Remove": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "groep": {"type": "string"},
                                        "id": {"type": "integer", "format": "int32"},
                                        "kenmerk": {"type": "string"},
                                        "kenmerkParentId": {
                                            "type": "integer",
                                            "format": "int32",
                                        },
                                        "values": {"type": "boolean"},
                                    },
                                    "title": "KenmerkWithValuesDto",
                                },
                            },
                            "entiteitKenmerken2Save": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "groep": {"type": "string"},
                                        "id": {"type": "integer", "format": "int32"},
                                        "kenmerk": {"type": "string"},
                                        "kenmerkParentId": {
                                            "type": "integer",
                                            "format": "int32",
                                        },
                                        "values": {"type": "boolean"},
                                    },
                                    "title": "KenmerkWithValuesDto",
                                },
                            },
                        },
                        "title": "KenmerkUpdateBody",
                    },
                },
                "title": "LoggingWrapperKenmerkUpdateBody",
            }
            self.validate.schema(json.loads(kenmerken2_update), schema)

        _body = overwrite_body if overwrite_body else kenmerken2_update
        response = self.put(
            f"/api/kenmerken/{bsn_rsin}/{kenmerk_type}/selections/update/{parent_entiteitnummer}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 201:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def save_selected_kenmerk_using_delete(
        self,
        bsn_rsin,
        kenmerk_id,
        kenmerk_type,
        authorization=None,
        logging_wrapper=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** saveSelectedKenmerk
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {
                "type": "object",
                "properties": {"loggingId": {"type": "string"}},
                "title": "LoggingWrapperVoid",
            }
            self.validate.schema(json.loads(logging_wrapper), schema)

        _body = overwrite_body if overwrite_body else logging_wrapper
        response = self.delete(
            f"/api/kenmerken/{bsn_rsin}/{kenmerk_type}/selections/{kenmerk_id}/delete",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 204:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_selected_middel_by_name_and_group_using_get(
        self,
        bsn_rsin,
        groep,
        name,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getSelectedMiddelByNameAndGroup
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{bsn_rsin}/{name}/{groep}/middel/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "object",
                    "properties": {
                        "groep": {"type": "string"},
                        "id": {"type": "integer", "format": "int32"},
                        "kenmerk": {"type": "string"},
                        "kenmerkParentId": {"type": "integer", "format": "int32"},
                    },
                    "title": "Kenmerk",
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def get_entiteit_kenmerk_aanvullingen_branchecode_using_get(
        self,
        entiteit_nummer,
        authorization=None,
        exp_status=200,
        validate_schema=True,
        overwrite_headers=None,
    ):
        """
        **Summary:** getEntiteitKenmerkAanvullingenBranchecode
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        response = self.get(
            f"/api/kenmerken/{entiteit_nummer}/zoo/branchecodeaanvulling/selected",
            headers=headers,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "groep": {"type": "string"},
                            "id": {"type": "integer", "format": "int32"},
                            "kenmerk": {"type": "string"},
                            "kenmerkParentId": {"type": "integer", "format": "int32"},
                        },
                        "title": "Kenmerk",
                    },
                }
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
