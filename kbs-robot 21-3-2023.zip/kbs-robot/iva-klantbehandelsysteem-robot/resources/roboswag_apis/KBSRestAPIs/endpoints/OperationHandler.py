import logging
import json

from roboswag import APIModel


class OperationHandler(APIModel):
    def __init__(self, url):
        super().__init__(base_url=url)

    def handle_using_get_1(
        self,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.get(
            "/actuator/caches", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def handle_using_delete_1(
        self,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.delete(
            "/actuator/caches", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 204:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def handle_using_get(
        self,
        cache,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.get(
            f"/actuator/caches/{cache}", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def handle_using_delete(
        self,
        cache,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.delete(
            f"/actuator/caches/{cache}", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 204:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def handle_using_get_3(
        self,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.get(
            "/actuator/health", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def handle_using_get_2(
        self,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.get(
            "/actuator/health/**", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def handle_using_get_4(
        self,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.get(
            "/actuator/info", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def handle_using_get_6(
        self,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.get(
            "/actuator/metrics", headers=headers, body=_body, status=exp_status
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response

    def handle_using_get_5(
        self,
        required_metric_name,
        authorization=None,
        body=None,
        exp_status=200,
        validate_schema=True,
        validate_payload=True,
        overwrite_body=None,
        overwrite_headers=None,
    ):
        """
        **Summary:** handle
        """
        headers = {"Authorization": authorization}
        if overwrite_headers:
            headers = overwrite_headers

        if validate_payload:
            schema = {"type": "object", "additionalProperties": {"type": "string"}}
            self.validate.schema(json.loads(body), schema)

        _body = overwrite_body if overwrite_body else body
        response = self.get(
            f"/actuator/metrics/{required_metric_name}",
            headers=headers,
            body=_body,
            status=exp_status,
        )

        if validate_schema:
            if response.status_code == 200:
                schema = {"type": "object"}
                self.validate.schema(response.json(), schema)
            elif response.status_code == 401:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 403:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            elif response.status_code == 404:
                # TODO self.validate.response_as_text(response, "FILL EXPECTED MESSAGE")
                pass
            else:
                logging.error(
                    f"Received status code ({response.status_code}) is not expected by the API specification"
                )
                assert False

        return response
