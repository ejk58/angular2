class ModelAndView:
    def __init__(
        self,
        empty: bool,
        model: object,
        model_map: object,
        reference: bool,
        status: str,
        view: object,
        view_name: str,
    ):
        self.empty = empty
        self.model = model
        self.model_map = model_map
        self.reference = reference
        self.status = status
        self.view = view
        self.view_name = view_name
