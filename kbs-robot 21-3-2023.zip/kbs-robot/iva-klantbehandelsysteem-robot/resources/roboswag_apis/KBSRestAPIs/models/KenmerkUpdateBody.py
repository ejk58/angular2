class KenmerkUpdateBody:
    def __init__(
        self, entiteit_kenmerken_2_remove: str, entiteit_kenmerken_2_save: str
    ):
        self.entiteit_kenmerken_2_remove = entiteit_kenmerken_2_remove
        self.entiteit_kenmerken_2_save = entiteit_kenmerken_2_save
