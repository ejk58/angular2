class BehandelActiviteit:
    def __init__(
        self,
        behandel_activiteit_code: str,
        behandelaars: str,
        behandelactiviteit: str,
        bsn_rsin: str,
        id: str,
        middel: str,
        naam: str,
        personen: str,
        status: str,
        subject_type: str,
        voorstel_type: str,
    ):
        self.behandel_activiteit_code = behandel_activiteit_code
        self.behandelaars = behandelaars
        self.behandelactiviteit = behandelactiviteit
        self.bsn_rsin = bsn_rsin
        self.id = id
        self.middel = middel
        self.naam = naam
        self.personen = personen
        self.status = status
        self.subject_type = subject_type
        self.voorstel_type = voorstel_type
