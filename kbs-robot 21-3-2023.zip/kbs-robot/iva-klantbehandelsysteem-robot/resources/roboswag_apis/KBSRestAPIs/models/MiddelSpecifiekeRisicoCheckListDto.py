class MiddelSpecifiekeRisicoCheckListDto:
    def __init__(
        self, middel_specifieke_risico: object, middel_specifieke_risico_list: str
    ):
        self.middel_specifieke_risico = middel_specifieke_risico
        self.middel_specifieke_risico_list = middel_specifieke_risico_list
