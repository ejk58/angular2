class OrgUrls:
    def __init__(self, wijzig_behandelteam_url: str):
        self.wijzig_behandelteam_url = wijzig_behandelteam_url
