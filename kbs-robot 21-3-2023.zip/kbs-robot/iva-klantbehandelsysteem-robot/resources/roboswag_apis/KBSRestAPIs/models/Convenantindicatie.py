class Convenantindicatie:
    def __init__(self, value: str):
        self.value = value
