class EntiteitMiddelKenmerkDto:
    def __init__(
        self,
        entiteit_nummer: int,
        has_linkable_risicos: bool,
        hoofd_kenmerk_id: int,
        id: int,
        rank: int,
        sub_kenmerk_1_id: int,
        sub_kenmerk_2_id: int,
        sub_kenmerk_3_id: int,
    ):
        self.entiteit_nummer = entiteit_nummer
        self.has_linkable_risicos = has_linkable_risicos
        self.hoofd_kenmerk_id = hoofd_kenmerk_id
        self.id = id
        self.rank = rank
        self.sub_kenmerk_1_id = sub_kenmerk_1_id
        self.sub_kenmerk_2_id = sub_kenmerk_2_id
        self.sub_kenmerk_3_id = sub_kenmerk_3_id
