class BatActiviteit:
    def __init__(
        self,
        afwijkende_periode_einde: str,
        afwijkende_periode_start: str,
        middel: str,
        subnummer: int,
    ):
        self.afwijkende_periode_einde = afwijkende_periode_einde
        self.afwijkende_periode_start = afwijkende_periode_start
        self.middel = middel
        self.subnummer = subnummer
