class LoggingWrapperboolean:
    def __init__(self, logging_id: str, wrapped_object: bool):
        self.logging_id = logging_id
        self.wrapped_object = wrapped_object
