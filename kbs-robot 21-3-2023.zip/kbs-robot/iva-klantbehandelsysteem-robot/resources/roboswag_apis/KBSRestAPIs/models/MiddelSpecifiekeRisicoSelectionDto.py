class MiddelSpecifiekeRisicoSelectionDto:
    def __init__(
        self,
        beheersing: int,
        current_id: int,
        hoofd_risico_id: int,
        kenmerk_id: int,
        key_risk: int,
        status_id: int,
        sub_risico_id: int,
    ):
        self.beheersing = beheersing
        self.current_id = current_id
        self.hoofd_risico_id = hoofd_risico_id
        self.kenmerk_id = kenmerk_id
        self.key_risk = key_risk
        self.status_id = status_id
        self.sub_risico_id = sub_risico_id
