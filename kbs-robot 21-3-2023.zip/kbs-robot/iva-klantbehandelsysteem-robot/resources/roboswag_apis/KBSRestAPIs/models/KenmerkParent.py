class KenmerkParent:
    def __init__(self, kenmerk: object, kenmerk_children: str):
        self.kenmerk = kenmerk
        self.kenmerk_children = kenmerk_children
