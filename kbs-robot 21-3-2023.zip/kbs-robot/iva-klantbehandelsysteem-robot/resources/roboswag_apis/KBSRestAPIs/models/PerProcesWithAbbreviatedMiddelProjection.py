class PerProcesWithAbbreviatedMiddelProjection:
    def __init__(self, afkorting: str, bezwaren: str, heffing: str, vooroverleg: str):
        self.afkorting = afkorting
        self.bezwaren = bezwaren
        self.heffing = heffing
        self.vooroverleg = vooroverleg
