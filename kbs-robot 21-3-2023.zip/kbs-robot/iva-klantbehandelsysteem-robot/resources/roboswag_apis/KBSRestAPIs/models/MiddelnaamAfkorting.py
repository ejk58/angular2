class MiddelnaamAfkorting:
    def __init__(self, afkorting: str, middel_id: int, naam: str, rank: int):
        self.afkorting = afkorting
        self.middel_id = middel_id
        self.naam = naam
        self.rank = rank
