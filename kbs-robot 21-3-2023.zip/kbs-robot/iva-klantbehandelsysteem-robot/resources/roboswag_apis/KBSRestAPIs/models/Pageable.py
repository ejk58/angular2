class Pageable:
    def __init__(
        self,
        offset: int,
        page_number: int,
        page_size: int,
        paged: bool,
        sort: object,
        unpaged: bool,
    ):
        self.offset = offset
        self.page_number = page_number
        self.page_size = page_size
        self.paged = paged
        self.sort = sort
        self.unpaged = unpaged
