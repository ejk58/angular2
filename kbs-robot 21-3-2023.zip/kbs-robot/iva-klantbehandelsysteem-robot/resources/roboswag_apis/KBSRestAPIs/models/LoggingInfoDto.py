class LoggingInfoDto:
    def __init__(self, logging_id: str, modified_date: datetime, username: str):
        self.logging_id = logging_id
        self.modified_date = modified_date
        self.username = username
