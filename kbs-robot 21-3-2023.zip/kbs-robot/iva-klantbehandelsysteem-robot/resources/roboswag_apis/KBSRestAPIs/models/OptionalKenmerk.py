class OptionalKenmerk:
    def __init__(self, empty: bool, present: bool):
        self.empty = empty
        self.present = present
