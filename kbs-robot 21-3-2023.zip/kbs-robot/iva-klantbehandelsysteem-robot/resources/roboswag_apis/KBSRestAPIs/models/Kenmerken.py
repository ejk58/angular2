class Kenmerken:
    def __init__(
        self,
        aandachts_categorie: str,
        convenant_deelname: str,
        go_categorie: str,
        vip_indicatie: str,
        wolb_som: str,
        zwaarte_categorie: str,
    ):
        self.aandachts_categorie = aandachts_categorie
        self.convenant_deelname = convenant_deelname
        self.go_categorie = go_categorie
        self.vip_indicatie = vip_indicatie
        self.wolb_som = wolb_som
        self.zwaarte_categorie = zwaarte_categorie
