class Behandelteam:
    def __init__(self, naam: str, rol_naam: str, toelichting: str, userid: str):
        self.naam = naam
        self.rol_naam = rol_naam
        self.toelichting = toelichting
        self.userid = userid
