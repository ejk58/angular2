class MiddelRisico:
    def __init__(self, id: int, middel_id: int, parent_id: int, rank: int, risico: str):
        self.id = id
        self.middel_id = middel_id
        self.parent_id = parent_id
        self.rank = rank
        self.risico = risico
