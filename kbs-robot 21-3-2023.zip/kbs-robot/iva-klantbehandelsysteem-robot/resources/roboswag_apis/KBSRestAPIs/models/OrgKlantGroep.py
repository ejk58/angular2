class OrgKlantGroep:
    def __init__(self, klantcoordinator: str, klantgroep_naam: str, werkgroep: str):
        self.klantcoordinator = klantcoordinator
        self.klantgroep_naam = klantgroep_naam
        self.werkgroep = werkgroep
