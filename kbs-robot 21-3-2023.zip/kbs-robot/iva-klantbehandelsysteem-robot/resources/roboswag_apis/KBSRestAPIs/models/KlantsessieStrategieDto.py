class KlantsessieStrategieDto:
    def __init__(
        self,
        klantsessie_id: int,
        korte_termijn: str,
        middel_id: int,
        middellange_termijn: str,
    ):
        self.klantsessie_id = klantsessie_id
        self.korte_termijn = korte_termijn
        self.middel_id = middel_id
        self.middellange_termijn = middellange_termijn
