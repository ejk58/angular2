class BehandelvoorstelOption:
    def __init__(self, activiteit_codes: object, voorstel_type: object):
        self.activiteit_codes = activiteit_codes
        self.voorstel_type = voorstel_type
