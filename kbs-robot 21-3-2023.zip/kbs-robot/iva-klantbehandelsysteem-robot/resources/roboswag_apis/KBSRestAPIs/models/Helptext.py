class Helptext:
    def __init__(
        self, changed: datetime, entiteit: int, id: str, txt: str, user_id: str
    ):
        self.changed = changed
        self.entiteit = entiteit
        self.id = id
        self.txt = txt
        self.user_id = user_id
