class KenmerkWithValuesDto:
    def __init__(
        self, groep: str, id: int, kenmerk: str, kenmerk_parent_id: int, values: bool
    ):
        self.groep = groep
        self.id = id
        self.kenmerk = kenmerk
        self.kenmerk_parent_id = kenmerk_parent_id
        self.values = values
