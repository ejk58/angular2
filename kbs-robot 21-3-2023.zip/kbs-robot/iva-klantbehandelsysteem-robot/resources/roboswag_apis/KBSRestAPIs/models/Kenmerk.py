class Kenmerk:
    def __init__(self, groep: str, id: int, kenmerk: str, kenmerk_parent_id: int):
        self.groep = groep
        self.id = id
        self.kenmerk = kenmerk
        self.kenmerk_parent_id = kenmerk_parent_id
