class MultiSelectKenmerk:
    def __init__(self, id: int, items: str, label: str):
        self.id = id
        self.items = items
        self.label = label
