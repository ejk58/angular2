class PageZooSubEntiteit:
    def __init__(
        self,
        content: str,
        empty: bool,
        first: bool,
        last: bool,
        number: int,
        number_of_elements: int,
        pageable: object,
        size: int,
        sort: object,
        total_elements: int,
        total_pages: int,
    ):
        self.content = content
        self.empty = empty
        self.first = first
        self.last = last
        self.number = number
        self.number_of_elements = number_of_elements
        self.pageable = pageable
        self.size = size
        self.sort = sort
        self.total_elements = total_elements
        self.total_pages = total_pages
