class VoorstelType:
    def __init__(self, code: str, omschrijving: str):
        self.code = code
        self.omschrijving = omschrijving
