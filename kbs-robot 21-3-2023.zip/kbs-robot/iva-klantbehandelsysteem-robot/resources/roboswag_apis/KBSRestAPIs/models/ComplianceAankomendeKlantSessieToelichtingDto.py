class ComplianceAankomendeKlantSessieToelichtingDto:
    def __init__(self, toelichting: str):
        self.toelichting = toelichting
