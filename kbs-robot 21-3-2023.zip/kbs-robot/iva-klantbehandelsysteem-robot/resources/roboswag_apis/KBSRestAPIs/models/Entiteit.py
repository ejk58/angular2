class Entiteit:
    def __init__(
        self,
        adres: str,
        bestuurlijk_verband: str,
        branche_code: int,
        branche_naam: str,
        convenant_indicatie: str,
        formatiedat: date,
        kantoor_code: str,
        kantoor_naam: str,
        klant_coordinator: str,
        klant_groep: str,
        klantpakket: str,
        naam: str,
        nummer: int,
        ontbinddat: date,
        team_code: str,
        team_naam: str,
    ):
        self.adres = adres
        self.bestuurlijk_verband = bestuurlijk_verband
        self.branche_code = branche_code
        self.branche_naam = branche_naam
        self.convenant_indicatie = convenant_indicatie
        self.formatiedat = formatiedat
        self.kantoor_code = kantoor_code
        self.kantoor_naam = kantoor_naam
        self.klant_coordinator = klant_coordinator
        self.klant_groep = klant_groep
        self.klantpakket = klantpakket
        self.naam = naam
        self.nummer = nummer
        self.ontbinddat = ontbinddat
        self.team_code = team_code
        self.team_naam = team_naam
