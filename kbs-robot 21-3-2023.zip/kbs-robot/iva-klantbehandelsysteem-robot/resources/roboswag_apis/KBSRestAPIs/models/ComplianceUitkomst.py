class ComplianceUitkomst:
    def __init__(
        self,
        beschrijving: str,
        kenmerk_id: int,
        score: int,
        strategie: int,
        toelichting: str,
    ):
        self.beschrijving = beschrijving
        self.kenmerk_id = kenmerk_id
        self.score = score
        self.strategie = strategie
        self.toelichting = toelichting
