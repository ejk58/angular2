class Klantsessie:
    def __init__(
        self,
        act_gebaseerd_gehouden_klantsessie: bool,
        controle_plaatsgevonden: bool,
        einddatum: datetime,
        entiteit_nummer: int,
        id: int,
        startdatum: datetime,
        toelichting_gehouden_klantsessie: str,
        zicht_op_organisatie_en_fiscaliteit_per_middel: object,
    ):
        self.act_gebaseerd_gehouden_klantsessie = act_gebaseerd_gehouden_klantsessie
        self.controle_plaatsgevonden = controle_plaatsgevonden
        self.einddatum = einddatum
        self.entiteit_nummer = entiteit_nummer
        self.id = id
        self.startdatum = startdatum
        self.toelichting_gehouden_klantsessie = toelichting_gehouden_klantsessie
        self.zicht_op_organisatie_en_fiscaliteit_per_middel = (
            zicht_op_organisatie_en_fiscaliteit_per_middel
        )
