class BehandelVoorstelRequestDto:
    def __init__(
        self,
        behandel_activiteit_code: str,
        behandel_voorstel_reference: str,
        subject: str,
        subject_type: str,
        user_id: str,
        voorstel_action: str,
        voorstel_type: str,
    ):
        self.behandel_activiteit_code = behandel_activiteit_code
        self.behandel_voorstel_reference = behandel_voorstel_reference
        self.subject = subject
        self.subject_type = subject_type
        self.user_id = user_id
        self.voorstel_action = voorstel_action
        self.voorstel_type = voorstel_type
