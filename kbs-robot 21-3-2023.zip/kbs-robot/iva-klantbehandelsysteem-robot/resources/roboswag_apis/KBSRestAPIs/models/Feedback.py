class Feedback:
    def __init__(
        self,
        created: datetime,
        email: str,
        id: int,
        melding: str,
        naam: str,
        pagina: str,
        rollen: str,
        user_id: str,
        version_info: str,
        version_information: object,
    ):
        self.created = created
        self.email = email
        self.id = id
        self.melding = melding
        self.naam = naam
        self.pagina = pagina
        self.rollen = rollen
        self.user_id = user_id
        self.version_info = version_info
        self.version_information = version_information
