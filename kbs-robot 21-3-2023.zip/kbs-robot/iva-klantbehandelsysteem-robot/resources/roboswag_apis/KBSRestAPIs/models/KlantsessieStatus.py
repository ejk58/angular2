class KlantsessieStatus:
    def __init__(
        self,
        compliance_status: str,
        klantsessie_id: int,
        middel_id: int,
        strategie_status: str,
        voorbereiding_afgerond: bool,
        voorbereiding_afronden_status: str,
        zooef_status: str,
    ):
        self.compliance_status = compliance_status
        self.klantsessie_id = klantsessie_id
        self.middel_id = middel_id
        self.strategie_status = strategie_status
        self.voorbereiding_afgerond = voorbereiding_afgerond
        self.voorbereiding_afronden_status = voorbereiding_afronden_status
        self.zooef_status = zooef_status
