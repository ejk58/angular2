class KenmerkChild:
    def __init__(self, kenmerk: object, score: int, toelichting: str):
        self.kenmerk = kenmerk
        self.score = score
        self.toelichting = toelichting
