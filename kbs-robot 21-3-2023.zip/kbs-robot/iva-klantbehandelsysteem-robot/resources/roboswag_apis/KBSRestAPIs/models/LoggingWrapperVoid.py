class LoggingWrapperVoid:
    def __init__(self, logging_id: str):
        self.logging_id = logging_id
