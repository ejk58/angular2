class MiddelKenmerk:
    def __init__(self, id: int, kenmerk: str, middel_id: int, parent_id: int):
        self.id = id
        self.kenmerk = kenmerk
        self.middel_id = middel_id
        self.parent_id = parent_id
