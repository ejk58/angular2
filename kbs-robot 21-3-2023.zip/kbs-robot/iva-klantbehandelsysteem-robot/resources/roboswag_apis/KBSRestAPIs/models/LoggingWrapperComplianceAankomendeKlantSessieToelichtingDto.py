class LoggingWrapperComplianceAankomendeKlantSessieToelichtingDto:
    def __init__(self, logging_id: str, wrapped_object: object):
        self.logging_id = logging_id
        self.wrapped_object = wrapped_object
