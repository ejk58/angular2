class EntiteitKzbGegevens:
    def __init__(
        self, branchecode: int, branchenaam: str, kantoornaam: str, teamnaam: str
    ):
        self.branchecode = branchecode
        self.branchenaam = branchenaam
        self.kantoornaam = kantoornaam
        self.teamnaam = teamnaam
