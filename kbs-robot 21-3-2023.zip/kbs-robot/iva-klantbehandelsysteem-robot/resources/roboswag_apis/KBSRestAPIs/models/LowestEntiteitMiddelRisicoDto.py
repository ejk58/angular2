class LowestEntiteitMiddelRisicoDto:
    def __init__(
        self,
        beheersing: str,
        key_risk: int,
        key_risk_as_string: str,
        middel_afkorting: str,
        risico_name: str,
        status: str,
    ):
        self.beheersing = beheersing
        self.key_risk = key_risk
        self.key_risk_as_string = key_risk_as_string
        self.middel_afkorting = middel_afkorting
        self.risico_name = risico_name
        self.status = status
