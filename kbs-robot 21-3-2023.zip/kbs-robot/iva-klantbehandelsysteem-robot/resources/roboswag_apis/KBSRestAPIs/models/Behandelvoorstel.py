class Behandelvoorstel:
    def __init__(
        self,
        beroep: str,
        bezwaar: str,
        controle: str,
        heffing: str,
        invordering: str,
        middel: str,
        overig: str,
        totalen: str,
        vooroverleg: str,
    ):
        self.beroep = beroep
        self.bezwaar = bezwaar
        self.controle = controle
        self.heffing = heffing
        self.invordering = invordering
        self.middel = middel
        self.overig = overig
        self.totalen = totalen
        self.vooroverleg = vooroverleg
