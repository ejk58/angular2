class KlantsessieResultaatEntryDto:
    def __init__(
        self,
        klantsessie_id: int,
        last_klant_sessie_date: datetime,
        middel: object,
        resultaat_by_kenmerk_id: object,
    ):
        self.klantsessie_id = klantsessie_id
        self.last_klant_sessie_date = last_klant_sessie_date
        self.middel = middel
        self.resultaat_by_kenmerk_id = resultaat_by_kenmerk_id
