class Link:
    def __init__(self, href: str, templated: bool):
        self.href = href
        self.templated = templated
