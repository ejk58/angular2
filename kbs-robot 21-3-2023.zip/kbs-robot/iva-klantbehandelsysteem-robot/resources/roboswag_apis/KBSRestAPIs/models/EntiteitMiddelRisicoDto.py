class EntiteitMiddelRisicoDto:
    def __init__(
        self,
        beheersing: int,
        entiteit_middel_kenmerk_id: int,
        entiteit_nummer: int,
        hoofd_risico_id: int,
        id: int,
        key_risk: int,
        middel_kenmerk: object,
        rank: int,
        status_id: int,
        sub_risico_id: int,
    ):
        self.beheersing = beheersing
        self.entiteit_middel_kenmerk_id = entiteit_middel_kenmerk_id
        self.entiteit_nummer = entiteit_nummer
        self.hoofd_risico_id = hoofd_risico_id
        self.id = id
        self.key_risk = key_risk
        self.middel_kenmerk = middel_kenmerk
        self.rank = rank
        self.status_id = status_id
        self.sub_risico_id = sub_risico_id
