class VersionInformation:
    def __init__(
        self,
        application: str,
        build_number: str,
        build_time: str,
        version: str,
        version_information: str,
    ):
        self.application = application
        self.build_number = build_number
        self.build_time = build_time
        self.version = version
        self.version_information = version_information
