class ZooSubEntiteit:
    def __init__(
        self,
        aanvullingen: str,
        begin_datum: str,
        branche_code: str,
        bsn_rsin: int,
        eind_datum: str,
        naam: str,
        plaats: str,
        soort_persoon: str,
    ):
        self.aanvullingen = aanvullingen
        self.begin_datum = begin_datum
        self.branche_code = branche_code
        self.bsn_rsin = bsn_rsin
        self.eind_datum = eind_datum
        self.naam = naam
        self.plaats = plaats
        self.soort_persoon = soort_persoon
