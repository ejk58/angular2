class View:
    def __init__(self, content_type: str):
        self.content_type = content_type
