class Sort:
    def __init__(self, empty: bool, sorted: bool, unsorted: bool):
        self.empty = empty
        self.sorted = sorted
        self.unsorted = unsorted
