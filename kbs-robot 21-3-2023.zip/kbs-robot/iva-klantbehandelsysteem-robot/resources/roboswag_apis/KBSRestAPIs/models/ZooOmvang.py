class ZooOmvang:
    def __init__(
        self,
        aantal_bezwaren_verzoeken_en_beroepen: int,
        aantal_bsn_rsins_in_entiteit: int,
        aantal_buitenlandse_deelnemingen: int,
        aantal_vaste_inrichtingen: int,
        belastingschuld: str,
        entiteit_nummer: int,
        last_updated: datetime,
        last_updated_by_user_id: str,
        totaal_betalingen_jaar_x: str,
        totaal_betalingen_jaar_x_min_1: str,
        totaal_betalingen_jaar_x_min_2: str,
        totale_vrijgestelde_omzet: str,
        totalen_aanslagen_per_jaar_vpb: str,
        totalen_per_jaar_lh_aantal_loongerechtigden: str,
        totalen_per_jaar_lh_totaal_loonsom: str,
        totalen_per_jaar_ob: str,
        wolb_som: str,
    ):
        self.aantal_bezwaren_verzoeken_en_beroepen = (
            aantal_bezwaren_verzoeken_en_beroepen
        )
        self.aantal_bsn_rsins_in_entiteit = aantal_bsn_rsins_in_entiteit
        self.aantal_buitenlandse_deelnemingen = aantal_buitenlandse_deelnemingen
        self.aantal_vaste_inrichtingen = aantal_vaste_inrichtingen
        self.belastingschuld = belastingschuld
        self.entiteit_nummer = entiteit_nummer
        self.last_updated = last_updated
        self.last_updated_by_user_id = last_updated_by_user_id
        self.totaal_betalingen_jaar_x = totaal_betalingen_jaar_x
        self.totaal_betalingen_jaar_x_min_1 = totaal_betalingen_jaar_x_min_1
        self.totaal_betalingen_jaar_x_min_2 = totaal_betalingen_jaar_x_min_2
        self.totale_vrijgestelde_omzet = totale_vrijgestelde_omzet
        self.totalen_aanslagen_per_jaar_vpb = totalen_aanslagen_per_jaar_vpb
        self.totalen_per_jaar_lh_aantal_loongerechtigden = (
            totalen_per_jaar_lh_aantal_loongerechtigden
        )
        self.totalen_per_jaar_lh_totaal_loonsom = totalen_per_jaar_lh_totaal_loonsom
        self.totalen_per_jaar_ob = totalen_per_jaar_ob
        self.wolb_som = wolb_som
