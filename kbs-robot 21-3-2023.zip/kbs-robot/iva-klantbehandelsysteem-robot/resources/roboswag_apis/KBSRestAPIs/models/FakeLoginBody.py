class FakeLoginBody:
    def __init__(self):

        pass
