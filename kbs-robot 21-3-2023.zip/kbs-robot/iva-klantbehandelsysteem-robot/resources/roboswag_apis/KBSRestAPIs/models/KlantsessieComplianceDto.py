class KlantsessieComplianceDto:
    def __init__(
        self, kenmerk_parents: str, klantsessie_id: int, last_klant_sessie_date: date
    ):
        self.kenmerk_parents = kenmerk_parents
        self.klantsessie_id = klantsessie_id
        self.last_klant_sessie_date = last_klant_sessie_date
