class ChartLabel:
    def __init__(self, id: int, label: str):
        self.id = id
        self.label = label
