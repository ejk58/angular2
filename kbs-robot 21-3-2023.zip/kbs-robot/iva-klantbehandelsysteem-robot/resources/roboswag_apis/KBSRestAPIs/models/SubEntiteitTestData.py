class SubEntiteitTestData:
    def __init__(self, nummer: str, subject: str, type: str):
        self.nummer = nummer
        self.subject = subject
        self.type = type
