class KlantsessieStrategieRisico:
    def __init__(
        self, klantsessie_id: int, middel_id: int, middel_risico: object, risico_id: int
    ):
        self.klantsessie_id = klantsessie_id
        self.middel_id = middel_id
        self.middel_risico = middel_risico
        self.risico_id = risico_id
