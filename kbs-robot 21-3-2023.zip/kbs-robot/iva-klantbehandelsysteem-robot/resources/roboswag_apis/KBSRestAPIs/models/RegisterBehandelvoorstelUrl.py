class RegisterBehandelvoorstelUrl:
    def __init__(self, url: str):
        self.url = url
