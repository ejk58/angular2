class KlantsessieResultaatDto:
    def __init__(self, current_entries: str, kenmerken: str, previous_entries: str):
        self.current_entries = current_entries
        self.kenmerken = kenmerken
        self.previous_entries = previous_entries
