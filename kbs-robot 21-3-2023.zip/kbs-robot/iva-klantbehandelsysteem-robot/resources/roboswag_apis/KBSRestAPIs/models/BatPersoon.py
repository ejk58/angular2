class BatPersoon:
    def __init__(
        self,
        activiteiten: str,
        afwijkende_periode_einde: str,
        afwijkende_periode_start: str,
        subject: int,
    ):
        self.activiteiten = activiteiten
        self.afwijkende_periode_einde = afwijkende_periode_einde
        self.afwijkende_periode_start = afwijkende_periode_start
        self.subject = subject
