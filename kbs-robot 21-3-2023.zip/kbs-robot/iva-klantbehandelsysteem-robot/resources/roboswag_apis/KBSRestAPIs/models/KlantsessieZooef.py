class KlantsessieZooef:
    def __init__(
        self,
        klantsessie_id: int,
        middel_id: int,
        observaties: str,
        vorige_observaties_nog_actueel: bool,
    ):
        self.klantsessie_id = klantsessie_id
        self.middel_id = middel_id
        self.observaties = observaties
        self.vorige_observaties_nog_actueel = vorige_observaties_nog_actueel
