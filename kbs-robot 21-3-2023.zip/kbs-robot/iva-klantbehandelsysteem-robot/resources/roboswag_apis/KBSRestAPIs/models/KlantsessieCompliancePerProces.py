class KlantsessieCompliancePerProces:
    def __init__(
        self,
        bezwaren: int,
        heffing: int,
        klantsessie_id: int,
        middel_id: int,
        vooroverleg: int,
    ):
        self.bezwaren = bezwaren
        self.heffing = heffing
        self.klantsessie_id = klantsessie_id
        self.middel_id = middel_id
        self.vooroverleg = vooroverleg
