class KlantsessieUitkomst:
    def __init__(
        self,
        kenmerk_id: int,
        klantsessie_id: int,
        score: int,
        strategie_gericht_op: int,
        toelichting: str,
    ):
        self.kenmerk_id = kenmerk_id
        self.klantsessie_id = klantsessie_id
        self.score = score
        self.strategie_gericht_op = strategie_gericht_op
        self.toelichting = toelichting
