class OrgKantoorTeam:
    def __init__(self, kantoor_code: int, subject: str, team: str):
        self.kantoor_code = kantoor_code
        self.subject = subject
        self.team = team
