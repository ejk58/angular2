class ComplianceAankomendeKlantsessieDto:
    def __init__(self, kenmerk: str, uitkomsten: str):
        self.kenmerk = kenmerk
        self.uitkomsten = uitkomsten
