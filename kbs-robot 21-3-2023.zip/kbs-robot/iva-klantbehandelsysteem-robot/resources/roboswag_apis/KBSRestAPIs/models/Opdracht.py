class Opdracht:
    def __init__(self, aantal: str, naam: str):
        self.aantal = aantal
        self.naam = naam
