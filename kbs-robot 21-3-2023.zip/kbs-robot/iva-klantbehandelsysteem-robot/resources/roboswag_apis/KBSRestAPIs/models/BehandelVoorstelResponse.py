class BehandelVoorstelResponse:
    def __init__(self, id: str, token: str):
        self.id = id
        self.token = token
