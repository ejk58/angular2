class KenmerkRisicosKoppeling:
    def __init__(
        self, composite_id: object, middel_kenmerk: object, middel_risico: object
    ):
        self.composite_id = composite_id
        self.middel_kenmerk = middel_kenmerk
        self.middel_risico = middel_risico
