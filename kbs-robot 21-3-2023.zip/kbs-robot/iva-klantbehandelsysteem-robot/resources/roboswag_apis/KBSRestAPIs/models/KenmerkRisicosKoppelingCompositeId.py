class KenmerkRisicosKoppelingCompositeId:
    def __init__(self, middel_kenmerk_id: int, middel_risico_id: int):
        self.middel_kenmerk_id = middel_kenmerk_id
        self.middel_risico_id = middel_risico_id
