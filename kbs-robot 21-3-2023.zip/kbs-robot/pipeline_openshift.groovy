@Library("GENERIC") _
    pipelineTest_v3b_openshift {
		deploymentId = "kbs"
        project = "kbs"
            robotTestPath = "iva-klantbehandelsysteem-robot/testsuites"
            robotArguments = "--include FINAL --exclude NIGHTLY"
            robotNonCriticals = "--skiponfailure NONCRITICAL --skiponfailure BUG"
            robotDir = "/usr/local/bin/"
        environmentChoices = "ont\ntst\nacc"
        streetChoices = "1\n2\n3"
    }