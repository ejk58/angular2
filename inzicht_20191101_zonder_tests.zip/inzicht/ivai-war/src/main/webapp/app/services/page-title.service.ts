import { Injectable } from '@angular/core';

@Injectable()
export class PageTitleService {

  reset() { document.title = 'Inzicht'; }

  update(first: any, second?: any) {

    document.title =
      first ? second ?
      first  + ' | ' + second + ' | ' + 'Inzicht' :
      first  + ' | ' + 'Inzicht'                  :
      'Inzicht';
  }
}
