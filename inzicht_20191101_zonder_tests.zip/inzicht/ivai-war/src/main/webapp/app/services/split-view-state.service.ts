import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

import { SplitWidth } from '../classes/split-width';

@Injectable()
export class SplitViewState {
  public readonly breakpointMobile = 320;
  public readonly breakpointResponsive = 480;

  public offsetScroll = new BehaviorSubject<number>(null);

  private readonly openSecondScreen = new BehaviorSubject<boolean>(false);
  private readonly splitWidth = new BehaviorSubject<SplitWidth>(SplitWidth.default);

  emitSizes(sizes: SplitWidth) {
    setTimeout(() => this.splitWidth.next(sizes));
  }

  listenSizes(): Observable<SplitWidth> {
    return this.splitWidth;
  }

  emitOpen2Screen(open2Screen: boolean) {
    setTimeout(() => this.openSecondScreen.next(open2Screen));
  }

  listenOpen2Screen(): Observable<boolean> {
    return this.openSecondScreen;
  }
}
