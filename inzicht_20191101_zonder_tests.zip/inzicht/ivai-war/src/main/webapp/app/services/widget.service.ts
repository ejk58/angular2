import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';

import {Store} from '@ngrx/store';
import * as fromSelectors from '../store/selectors';

@Injectable()
export class WidgetService {
  routerSideParams: any;

  constructor(private readonly http: HttpClient,
              private readonly store: Store<any>) {
    this.store.select(fromSelectors.getRouterState).subscribe(router => {
      this.routerSideParams = router.routerSidesParams;
    });
  }

  get(widgetId: string, side: string, filter: any): Observable<any> {
    const params: any = {};
    const propertiesToExclude: string[] = ['pageId', 'domainId', 'tabId', 'ContainerId'];
    const propertyValuesToExclude: string[] = ['null'];

    if (side && this.routerSideParams) {
      this.appendUrlParams(side, params, propertiesToExclude, propertyValuesToExclude);
    }
    if (filter) {
      this.appendFilterParams(filter, params, propertiesToExclude, propertyValuesToExclude);
    }

    let httpParams = new HttpParams();
    Object.keys(params).forEach(prop => {
      const value = Array.isArray(params[prop]) ? params[prop] : ('' + params[prop]).split(',');
      value.forEach(v => httpParams = httpParams.append(prop, v));
    });

    return this.http.get('rest/widget/' + widgetId, { params: httpParams });
  }

  private appendUrlParams(side: string, params: any, propertiesToExclude: string[], propertyValuesToExclude: string[]): void {
    const urlParams = this.routerSideParams[side];
    params.domainId = urlParams.domainId;
    Object.keys(urlParams).forEach(prop => {
      if (propertiesToExclude.indexOf(prop) === -1 && propertyValuesToExclude.indexOf(urlParams[prop]) === -1) {
        this.putIfKeyAndValueAbsent(params, prop, urlParams[prop]);
      }
    });
  }

  private appendFilterParams(filter: any, params: any, propertiesToExclude: string[], propertyValuesToExclude: string[]): void {
    Object.keys(filter).forEach(prop => {
      if (propertiesToExclude.indexOf(prop) === -1 && propertyValuesToExclude.indexOf(filter[prop]) === -1) {
        this.putIfKeyAndValueAbsent(params, prop, filter[prop]);
      }
    });
  }

  private putIfKeyAndValueAbsent(params: any, key: string, value: any): void {
    if (typeof params[key] === 'undefined' || params[key] !== value) {
      params[key] = value;
    }
  }
}
