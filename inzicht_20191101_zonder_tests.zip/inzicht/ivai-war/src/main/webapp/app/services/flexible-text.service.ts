import {Injectable} from '@angular/core';
import {Store} from '@ngrx/store';
import {first} from 'rxjs/operators';

import * as fromSelectors from '../store/selectors';
import {SelectorSideIndicator} from '../commons/store-selector-side-indicator';
import { combineLatest } from 'rxjs';

export type TextArgument = string | number | TextElement;

export class TextElement {
  public arguments: {[key: string]: TextArgument};
  public style: string;

  constructor(public type: string, public startIndex: number, public endIndex: number) {
    this.arguments = {};
    this.style = 'text text-' + type.toLowerCase();
  }

  public addArgument(key: string, value: TextArgument): void {
    this.arguments[key] = value;
  }

  public getArgument(key: string): TextArgument {
    return this.arguments[key];
  }
}

export class TextValues {
  public side: string;
  public data: any;
}

@Injectable()
export class FlexibleTextService {

  public static readonly contextType: string = 'CONTEXT';
  public static readonly dataType: string = 'DATA';
  public static readonly environmentType: string = 'ENVIRONMENT';

  public static readonly sourceTypes: string[] = [FlexibleTextService.contextType, FlexibleTextService.dataType,
      FlexibleTextService.environmentType];

  public static readonly objectType: string = 'OBJECT';

  public static readonly modifierTypes: string[] = [FlexibleTextService.objectType];

  public static readonly textType: string = 'TEXT';
  public static readonly linkType: string = 'LINK';
  public static readonly buttonType: string = 'BUTTON';

  public static readonly outputTypes: string[] = [FlexibleTextService.textType, FlexibleTextService.linkType, FlexibleTextService.buttonType];

  public constructor(private readonly store: Store<any>,
      private readonly selectorSideIndicator: SelectorSideIndicator) {
    // Construct nothing
  }

  public getTextLabel(text: string, values: TextValues): string {
    const results = this.getTextResults(text, values);
    return results.map(value => (value && value.hasOwnProperty('label')) ? value['label'] : value).join('');
  }

  public getTextResults(text: string, values: TextValues): any[] {
    const elements = this.parseText(text);
    return this.fillText(elements, values);
  }

  public parseText(text: string): TextElement[] {
    const lastIndex = text.length;
    const elements = [];
    let index = 0;

    while (index < lastIndex) {
      const element = this.parseElement(text, index);

      if (element != null) {
        if (element.startIndex > index) {
          elements.push(this.createElement(text, index, element.startIndex));
        }

        elements.push(element);
        index = element.endIndex;
      } else {
        elements.push(this.createElement(text, index, lastIndex));
        index = lastIndex;
      }
    }

    return elements;
  }

  public fillText(elements: TextElement[], values: TextValues): any[] {
    return elements
        .map(element => this.fillElement(element, values));
  }

  public createElement(text: string, startIndex: number, endIndex: number): TextElement {
    const tag = new TextElement('TEXT', startIndex, endIndex);
    tag.addArgument('label', text.substring(startIndex, endIndex));
    return tag;
  }

  public parseElement(text: string, startIndex: number): TextElement {
    let tag = this.findFirstStartTag(text, startIndex);

    if (tag != null) {
      tag = this.findMatchingEndTag(text, tag);
      tag = this.parseArguments(text, tag);
    }

    return tag;
  }

  public fillElement(element: TextElement, values: TextValues): any {
    let result = this.fillArguments(element, values);

    if (element.type === 'CONTEXT') {
      result = this.getContextElement(result, values);
    } else if (element.type === 'DATA') {
      result = this.getDataElement(result, values);
    } else if (element.type === 'ENVIRONMENT') {
      result = this.getEnvironmentElement(result, values);
    }

    return result;
  }

  getContextElement(element: any, values: TextValues): any {
    const key = element['key'];
    let result;

    const indicatedPageConfigSelector = this.selectorSideIndicator.indicatedSelectorName(values.side, 'getPageConfigState');
    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(values.side, 'getRouterState');
    combineLatest(
      this.store.select(fromSelectors[indicatedRouterStateSelector]),
      this.store.select(fromSelectors[indicatedPageConfigSelector])
    ).pipe(
      first()
    ).subscribe(([sideParams, pageConfig]) => {
      const page = pageConfig.find(page => page.key === sideParams.pageId);
      result = page.mandatoryPathKeys.indexOf(key) > -1 ? sideParams[key] : null;
    });

    return result;
  }

  getDataElement(element: any, values: TextValues): any {
    const column = element['column'];
    const row = element['row'];
    let result = null;

    if (row != null && values.data.length > row && column != null && values.data[row].hasOwnProperty(column)) {
      result = values.data[row][column];
    } else {
      console.error('Error: An element ' + element['type']
          + ' tries to retrieve information that does not exist in the data-object in column "'
          + column + '" and at row ' + row + '.');
    }

    return result;
  }

  getEnvironmentElement(element: any, values: TextValues): any {
    const key = element['key'];
    let result = null;

    if (key === 'username') {
      result = sessionStorage.getItem('username');
    } else if (key === 'version') {
      result = this.store.select(fromSelectors.getSystemVersionState);
    } else if (key === 'date') {
      result = new Date().getMilliseconds();
    } else {
      console.error('Error: An element ' + element['type']
          + ' tries to access environment-information with the unsupported key "' + key + '".');
    }

    return result;
  }

  findFirstStartTag(text: string, startIndex: number): TextElement {
    const remainingText = text.substring(startIndex);
    const startTagMatch = remainingText.match('\\#([A-Z]*)\\(');
    let tag = null;

    if (startTagMatch != null && startTagMatch.length > 1) {
      const tagType = startTagMatch[1];
      tag = new TextElement(tagType, startTagMatch.index + startIndex, null);
    }

    return tag;
  }

  findMatchingEndTag(text: string, tag: TextElement): TextElement {
    let remainingIndex = tag.startIndex + tag.type.length + 1;
    let remainingText = text.substring(remainingIndex);
    let endTagMatch = remainingText.match('\\)' + tag.type + '\\#');
    let innerTag = this.findFirstStartTag(text, remainingIndex);

    if (innerTag != null && innerTag.startIndex < endTagMatch.index + remainingIndex) {
      innerTag = this.findMatchingEndTag(text, innerTag);

      remainingIndex = innerTag.endIndex;
      remainingText = text.substring(remainingIndex);
      endTagMatch = remainingText.match('\\)' + tag.type + '\\#');
      innerTag = this.findFirstStartTag(text, remainingIndex);
    }

    tag.endIndex = remainingIndex + endTagMatch.index + tag.type.length + 2;
    return tag;
  }

  parseArguments(text: string, tag: TextElement): TextElement {
    const lastIndex = tag.endIndex - tag.type.length - 2;
    const firstIndex = tag.startIndex + tag.type.length + 2;
    let index = firstIndex;

    while (index >= firstIndex && index < lastIndex) {
      const keyValueSeparatorIndex = text.indexOf('=', index);

      if (keyValueSeparatorIndex > 0) {
        const key = text.substring(index, keyValueSeparatorIndex);

        if (text.substring(keyValueSeparatorIndex + 1, keyValueSeparatorIndex + 2) === '#') {
          const valueTag = this.parseElement(text, keyValueSeparatorIndex);
          index = text.indexOf(';', valueTag.endIndex);
          tag.addArgument(key, valueTag);
        } else {
          index = text.indexOf(';', keyValueSeparatorIndex);
          const value = text.substring(keyValueSeparatorIndex + 1, (index >= firstIndex && index < lastIndex) ? index : lastIndex);
          tag.addArgument(key, value);
        }
      } else {
        console.error('Error: The string "' + text + '" contains a malformed argument at index ' + index + '.');
        index = lastIndex;
      }

      index++;
    }

    return tag;
  }

  fillArguments(element: TextElement, values: TextValues): any {
    const result = {};
    result['type'] = element.type;

    for (let key of Object.keys(element.arguments)) {
      const value = element.getArgument(key);
      result[key] = (value != null && typeof value === 'object' && value.hasOwnProperty('type') && value.hasOwnProperty('arguments')) ?
          this.fillElement(value, values) :
          value;
    }

    if (FlexibleTextService.outputTypes.indexOf(element.type) >= 0) {
      const style = result['style'] != null ? result['style'] : 'default';
      result['style'] = 'text text-' + element.type.toLowerCase() + ' ' + style;
    }

    return result;
  }
}
