import {Injectable} from '@angular/core';

import {Side} from '../commons/side';
import {BehaviorSubject, Observable} from 'rxjs';
import {delay, map} from 'rxjs/operators';

export enum ChartEvent {
  enterTooltip = 'enterTooltip',
  leaveTooltip = 'leaveTooltip'
}

export enum LegendEvent {
  enableItem = 'enableItem',
  disableItem = 'disableItem'
}

export enum TableEvent {
  enterRow = 'enterRow',
  leaveRow = 'leaveRow'
}

export type EventType = ChartEvent | LegendEvent | TableEvent;

export class Event<T> {
  constructor(
    public readonly type: EventType,
    public readonly payload?: T
  ) {
  }
}

export type EventCallback = <T>(_: T) => void;

export class EventListener {
  [widgetListenerName: string]: EventCallback;
}

export class EventListenerSourceMap {
  [widgetSourceName: string]: EventListener;
}

export class EventListenerTypeMap {
  [type: string /*EventType*/]: EventListenerSourceMap;
}

export class EventListenerMap {
  left?: EventListenerTypeMap;
  right?: EventListenerTypeMap;
}

@Injectable()
export class EventService {

  private readonly listeners: EventListenerMap = {};
  private readonly listenersSubject: BehaviorSubject<EventListenerMap> = new BehaviorSubject(this.listeners);

  public hasListeners(widgetSourceName: string, side: Side, ...eventTypes: EventType[]): Observable<boolean> {
    return this.listenersSubject.pipe(
      delay(0),
      map(listeners => {
        if (listeners[side]) {
          return eventTypes.some(eventType =>
            listeners[side][eventType] && listeners[side][eventType][widgetSourceName] && Object.keys(listeners[side][eventType][widgetSourceName]).length > 0
          );
        } else {
          return false;
        }
      })
    );
  }

  public listen(widgetSourceName: string, widgetListenerName: string, side: Side, eventType: EventType, cb: EventCallback): void {
    if (this.listeners[side] == null) {
      this.listeners[side] = {};
    }

    if (this.listeners[side][eventType] == null) {
      this.listeners[side][eventType] = {};
    }

    if (this.listeners[side][eventType][widgetSourceName] == null) {
      this.listeners[side][eventType][widgetSourceName] = {};
    }

    this.listeners[side][eventType][widgetSourceName][widgetListenerName] = cb;
    this.listenersSubject.next(this.listeners);
  }

  public remove(widgetSourceName: string, widgetListenerName: string, side: Side, eventType: EventType): void {
    if (this.listeners[side] != null && this.listeners[side][eventType] != null && this.listeners[side][eventType][widgetSourceName] != null) {
      delete this.listeners[side][eventType][widgetSourceName][widgetListenerName];
      this.listenersSubject.next(this.listeners);
    }
  }

  public broadcast<T>(widgetSourceName: string, side: Side, event: Event<T>): void {
    const existingSide = this.listeners[side];
    if (existingSide) {
      const existingSources = existingSide[event.type];
      if (existingSources != null) {
        const existingListeners = existingSources[widgetSourceName];
        if (existingListeners != null) {
          Object.keys(existingListeners).forEach(widgetName => {
            const cb = existingListeners[widgetName];
            cb(event.payload);
          });
        }
      }
    }
  }
}
