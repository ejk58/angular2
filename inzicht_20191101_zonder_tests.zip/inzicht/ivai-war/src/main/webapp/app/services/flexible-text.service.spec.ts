import {inject, TestBed} from '@angular/core/testing';
import {TextElement, FlexibleTextService, TextValues} from './flexible-text.service';

describe('FlexibleTextService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ ],
      providers: [
        FlexibleTextService
      ]
    });
  });

  describe('findFirstStartTag', () => {
    it('should find the first (and only) unnested tag (the CONTEXT-tag) in a given text',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Hopefully the test will find a #CONTEXT(key=subjectNr)CONTEXT# tag in this sentence.';
      const result = flexibleTextService.findFirstStartTag(text, 0);

      expect(result.type).toEqual('CONTEXT');
      expect(result.startIndex).toEqual(31);
      expect(result.endIndex).toBeNull();
    });
  });

  describe('findFirstStartTag', () => {
    it('should find the first tag (the CONTENT-tag) in a given text with multiple nested tags',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Hopefully the test will find a #CONTEXT(model=#OBJECT(key=subjectNr;value=7777777)OBJECT#)CONTEXT# tag in this sentence.';
      const result = flexibleTextService.findFirstStartTag(text, 0);

      expect(result.type).toEqual('CONTEXT');
      expect(result.startIndex).toEqual(31);
      expect(result.endIndex).toBeNull();
    });
  });

  describe('findMatchingEndTag', () => {
    it('should find the matching end of the single CONTEXT-tag in a given text',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Hopefully the test will find a #CONTEXT(key=subjectNr)CONTEXT# tag in this sentence.';
      const element = new TextElement('CONTEXT', 31, null);
      flexibleTextService.findMatchingEndTag(text, element);

      expect(element.type).toEqual('CONTEXT');
      expect(element.startIndex).toEqual(31);
      expect(element.endIndex).toEqual(62);
    });
  });

  describe('findMatchingEndTag', () => {
    it('should find the matching end of the outer CONTEXT-tag in a given text with nested CONTEXT-tags',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Hopefully the test will find a #CONTEXT(model=#CONTEXT(key=subjectNr)CONTEXT#)CONTEXT# tag in this sentence.';
      const element = new TextElement('CONTEXT', 31, null);
      flexibleTextService.findMatchingEndTag(text, element);

      expect(element.type).toEqual('CONTEXT');
      expect(element.startIndex).toEqual(31);
      expect(element.endIndex).toEqual(86);
    });
  });

  describe('parseArguments', () => {
    it('should parse no arguments from a given tag if the tag does not contain any arguments',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#OBJECT()OBJECT#';
      const element = new TextElement('OBJECT', 0, text.length);
      const result = flexibleTextService.parseArguments(text, element);

      expect(Object.keys(result.arguments).length).toEqual(0);
    });
  });

  describe('parseArguments', () => {
    it('should parse a single given argument from a given tag based on a given text and add it to the tag',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#OBJECT(key=value)OBJECT#';
      const element = new TextElement('OBJECT', 0, text.length);
      const result = flexibleTextService.parseArguments(text, element);

      expect(Object.keys(result.arguments).length).toEqual(1);
      expect(result.arguments.key).toEqual('value');
    });
  });

  describe('parseArguments', () => {
    it('should parse several given arguments from a given tag based on a given text and add them to the tag',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#OBJECT(teamName=Inge;app=Inzicht;numberOfDevelopers=6)OBJECT#';
      const element = new TextElement('OBJECT', 0, text.length);
      const result = flexibleTextService.parseArguments(text, element);

      expect(Object.keys(result.arguments).length).toEqual(3);
      expect(result.arguments.teamName).toEqual('Inge');
      expect(result.arguments.app).toEqual('Inzicht');
      expect(result.arguments.numberOfDevelopers).toEqual('6');
    });
  });

  describe('parseArguments', () => {
    it('should not parse a malformed argument from a given tag based on a given text',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#OBJECT(keyWithoutValue)OBJECT#';
      const element = new TextElement('OBJECT', 0, text.length);
      const result = flexibleTextService.parseArguments(text, element);

      expect(Object.keys(result.arguments).length).toEqual(0);
    });
  });

  describe('fillArguments', () => {
    it('should create a result-object with the single key/value-pair as the property of this object based on the given text-element',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const element = new TextElement('OBJECT', 0, 1);
      element.addArgument('key', 'value');
      const result = flexibleTextService.fillArguments(element, null);

      expect(Object.keys(result).length).toEqual(2);
      expect(result.type).toEqual('OBJECT');
      expect(result.key).toEqual('value');
    });
  });

  describe('fillArguments', () => {
    it('should create a result-object with two key/value-pairs as the properties of this object based on the given text-element',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const element = new TextElement('OBJECT', 0, 1);
      element.addArgument('teamName', 'Inge');
      element.addArgument('app', 'Inzicht');
      const result = flexibleTextService.fillArguments(element, null);

      expect(Object.keys(result).length).toEqual(3);
      expect(result.type).toEqual('OBJECT');
      expect(result.teamName).toEqual('Inge');
      expect(result.app).toEqual('Inzicht');
    });
  });

  describe('parseElement', () => {
    it('should parse a single given element from a given text and return it as a text-element',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#LINK(url=http://happymail.com;key=value)LINK#';
      const result = flexibleTextService.parseElement(text, 0);

      expect(result.type).toEqual('LINK');
      expect(result.startIndex).toEqual(0);
      expect(result.endIndex).toEqual(46);
      expect(Object.keys(result.arguments).length).toEqual(2);
      expect(result.arguments.url).toEqual('http://happymail.com');
      expect(result.arguments.key).toEqual('value');
    });
  });

  describe('parseElement', () => {
    it('should parse the first element from a given text with two consecutive elements',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#OBJECT(key=value)OBJECT##CONTEXT(key=subjectNr)CONTEXT#';
      const result = flexibleTextService.parseElement(text, 0);

      expect(result.type).toEqual('OBJECT');
      expect(result.startIndex).toEqual(0);
      expect(result.endIndex).toEqual(25);
      expect(Object.keys(result.arguments).length).toEqual(1);
      expect(result.arguments.key).toEqual('value');
    });
  });

  describe('parseElement', () => {
    it('should parse the second element from a given text with two consecutive elements if the index is moved past the first element',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#OBJECT(key=value)OBJECT##CONTEXT(key=subjectNr)CONTEXT#';
      const result = flexibleTextService.parseElement(text, 1);

      expect(result.type).toEqual('CONTEXT');
      expect(result.startIndex).toEqual(25);
      expect(result.endIndex).toEqual(56);
      expect(Object.keys(result.arguments).length).toEqual(1);
      expect(result.arguments.key).toEqual('subjectNr');
    });
  });

  describe('fillElement', () => {
    it('should return an object as described by the given text-element and filled with the given key/value-pair',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const element = new TextElement('OBJECT', 0, 1);
      element.addArgument('mailAddress', 'theo.tank@happymail.com');
      const result = flexibleTextService.fillElement(element, null);

      expect(Object.keys(result).length).toEqual(2);
      expect(result.type).toEqual('OBJECT');
      expect(result.mailAddress).toEqual('theo.tank@happymail.com');
    });
  });

  describe('fillElement', () => {
    it('should return an object as described by the given text-element and filled with the given data',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const element = new TextElement('DATA', 0, 1);
      element.addArgument('column', 'index');
      element.addArgument('row', 0);
      const values = new TextValues();
      values.data = [{'index': 'data-from-index-column', 'value1': 'data-from-value1-column'}];
      const result = flexibleTextService.fillElement(element, values);

      expect(result).toEqual('data-from-index-column');
    });
  });

  describe('fillElement', () => {
    it('should return nothing if the requested data is not available in the data-object',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const element = new TextElement('DATA', 0, 1);
      element.addArgument('column', 'value2');
      element.addArgument('row', 0);
      const values = new TextValues();
      values.data = [{'index': 'data-from-index-column', 'value1': 'data-from-value1-column'}];
      const result = flexibleTextService.fillElement(element, values);

      expect(result).toEqual(null);
    });
  });

  describe('fillElement', () => {
    it('should return nothing if the element requests environment-information that is not supported (has an unknown key)',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const element = new TextElement('ENVIRONMENT', 0, 1);
      element.addArgument('key', 'currentWeather');
      const result = flexibleTextService.fillElement(element, null);

      expect(result).toEqual(null);
    });
  });

  describe('parseText', () => {
    it('should create a single text-element from a sentence without any tags',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Hopefully the test will regards this sentence as a single element of type TEXT.';
      const elements = flexibleTextService.parseText(text);

      expect(elements.length).toEqual(1);
      expect(elements[0].type).toEqual('TEXT');
      expect(elements[0].startIndex).toEqual(0);
      expect(elements[0].endIndex).toEqual(79);
    });
  });

  describe('parseText', () => {
    it('should create a three text-elements from a sentence with a single CONTENT-tag',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Hopefully the test will find a #CONTEXT(key=subjectNr)CONTEXT# tag in this sentence.';
      const elements = flexibleTextService.parseText(text);

      expect(elements.length).toEqual(3);
      expect(elements[0].type).toEqual('TEXT');
      expect(elements[0].startIndex).toEqual(0);
      expect(elements[0].endIndex).toEqual(31);
      expect(elements[1].type).toEqual('CONTEXT');
      expect(elements[1].startIndex).toEqual(31);
      expect(elements[1].endIndex).toEqual(62);
      expect(elements[2].type).toEqual('TEXT');
      expect(elements[2].startIndex).toEqual(62);
      expect(elements[2].endIndex).toEqual(84);
    });
  });

  describe('parseText', () => {
    it('should create a three primary text-elements (and a nested text-element) from a sentence with two nested CONTENT-tags',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Hopefully the test will find a #CONTEXT(model=#CONTEXT(key=subjectNr)CONTEXT#)CONTEXT# tag in this sentence.';
      const elements = flexibleTextService.parseText(text);

      expect(elements.length).toEqual(3);
      expect(elements[0].type).toEqual('TEXT');
      expect(elements[0].startIndex).toEqual(0);
      expect(elements[0].endIndex).toEqual(31);
      expect(elements[1].type).toEqual('CONTEXT');
      expect(elements[1].startIndex).toEqual(31);
      expect(elements[1].endIndex).toEqual(86);
      expect(elements[2].type).toEqual('TEXT');
      expect(elements[2].startIndex).toEqual(86);
      expect(elements[2].endIndex).toEqual(108);
      const model = elements[1].getArgument('model') as TextElement;
      expect(model.type).toEqual('CONTEXT');
      expect(model.startIndex).toEqual(46);
      expect(model.endIndex).toEqual(77);
    });
  });

  describe('parseText', () => {
    it('should create five text-elements from a sentence with two consecutive tags',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'A sentence can contain both a #LINK(url=http://nu.nl)LINK# and a #FEEDBACK(type=global;state=empty)FEEDBACK# tag.';
      const elements = flexibleTextService.parseText(text);

      expect(elements.length).toEqual(5);
      expect(elements[0].type).toEqual('TEXT');
      expect(elements[0].startIndex).toEqual(0);
      expect(elements[0].endIndex).toEqual(30);
      expect(elements[1].type).toEqual('LINK');
      expect(elements[1].startIndex).toEqual(30);
      expect(elements[1].endIndex).toEqual(58);
      expect(elements[2].type).toEqual('TEXT');
      expect(elements[2].startIndex).toEqual(58);
      expect(elements[2].endIndex).toEqual(65);
      expect(elements[3].type).toEqual('FEEDBACK');
      expect(elements[3].startIndex).toEqual(65);
      expect(elements[3].endIndex).toEqual(108);
      expect(elements[4].type).toEqual('TEXT');
      expect(elements[4].startIndex).toEqual(108);
      expect(elements[4].endIndex).toEqual(113);
    });
  });

  describe('parseText', () => {
    it('should create five text-elements from a sentence with two similar consecutive BUTTON-tags',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Kies een #BUTTON(label=klantbeeld;action=open-domain-menu)BUTTON# of bekijk de #BUTTON(label=beknopte inleiding;action=open-help-panel)BUTTON# voor het gebruik van Inzicht.';
      const elements = flexibleTextService.parseText(text);

      expect(elements.length).toEqual(5);
      const domainButton = elements[1];
      const helpButton = elements[3];
      expect(elements[0].type).toEqual('TEXT');
      expect(elements[0].startIndex).toEqual(0);
      expect(elements[0].endIndex).toEqual(9);
      expect(domainButton.type).toEqual('BUTTON');
      expect(domainButton.startIndex).toEqual(9);
      expect(domainButton.endIndex).toEqual(65);
      expect(domainButton.arguments.label).toEqual('klantbeeld');
      expect(domainButton.arguments.action).toEqual('open-domain-menu');
      expect(elements[2].type).toEqual('TEXT');
      expect(elements[2].startIndex).toEqual(65);
      expect(elements[2].endIndex).toEqual(79);
      expect(helpButton.type).toEqual('BUTTON');
      expect(helpButton.startIndex).toEqual(79);
      expect(helpButton.endIndex).toEqual(142);
      expect(helpButton.arguments.label).toEqual('beknopte inleiding');
      expect(helpButton.arguments.action).toEqual('open-help-panel');
      expect(elements[4].type).toEqual('TEXT');
      expect(elements[4].startIndex).toEqual(142);
      expect(elements[4].endIndex).toEqual(172);
    });
  });

  describe('parseText', () => {
    it('should create nested text-elements from a complex text',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#LINK(label=7777777;page=i-presentation-algemeen;model=#OBJECT(subjectNr=7777777;entityNr=#CONTEXT(key=entityNr)CONTEXT#)OBJECT#;target=rightSide;style=link)LINK#.';
      const elements = flexibleTextService.parseText(text);

      expect(elements.length).toEqual(2);
      const rightSideLink = elements[0];
      expect(rightSideLink.type).toEqual('LINK');
      expect(rightSideLink.startIndex).toEqual(0);
      expect(rightSideLink.endIndex).toEqual(162);
      expect(rightSideLink.arguments.label).toEqual('7777777');
      expect(rightSideLink.arguments.page).toEqual('i-presentation-algemeen');
      expect(rightSideLink.arguments.target).toEqual('rightSide');
      expect(rightSideLink.arguments.style).toEqual('link');
      const modelObject = rightSideLink.arguments.model as TextElement;
      expect(modelObject.type).toEqual('OBJECT');
      expect(modelObject.arguments.subjectNr).toEqual('7777777');
      const entityContext = modelObject.arguments.entityNr as TextElement;
      expect(entityContext.type).toEqual('CONTEXT');
      expect(entityContext.arguments.key).toEqual('entityNr');
      expect(elements[1].type).toEqual('TEXT');
      expect(elements[1].startIndex).toEqual(162);
      expect(elements[1].endIndex).toEqual(163);
    });
  });


  describe('parseText', () => {
    it('should parse several given arguments from a given tag based on a given text and add them to the tag',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = '#OBJECT(teamName=Inge;app=Inzicht;numberOfDevelopers=6)OBJECT#';
      const elements = flexibleTextService.parseText(text);

      expect(elements.length).toEqual(1);
      expect(elements[0].type).toEqual('OBJECT');
      expect(elements[0].arguments['teamName']).toEqual('Inge');
      expect(elements[0].arguments['app']).toEqual('Inzicht');
      expect(elements[0].arguments['numberOfDevelopers']).toEqual('6');
    });
  });

  describe('fillText', () => {
    it('should return a list of result objects given a list containing a single text-element',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const element = new TextElement('TEXT', 0, 1);
      element.addArgument('label', 'Happy Text');
      const elements = [element];
      const result = flexibleTextService.fillText(elements, null);

      expect(result.length).toEqual(1);
      expect(result[0].label).toEqual('Happy Text');
    });
  });

  describe('fillText', () => {
    it('should return a list of result objects given a list containing several (nested) text-elements',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const values = new TextValues();
      values.data = [{'index': 'data-from-index-column', 'value1': 'data-from-value1-column'}];

      const innerElement = new TextElement('DATA', 0, 1);
      innerElement.addArgument('column', 'value1');
      innerElement.addArgument('row', 0);
      const firstElement = new TextElement('TEXT', 0, 1);
      firstElement.addArgument('label', 'Interesting data from the table = ');
      const secondElement = new TextElement('TEXT', 0, 1);
      secondElement.addArgument('label', innerElement);
      const elements = [firstElement, secondElement];
      const result = flexibleTextService.fillText(elements, values);

      expect(result.length).toEqual(2);
      expect(result[0].label).toEqual('Interesting data from the table = ');
      expect(result[1].label).toEqual('data-from-value1-column');
    });
  });

  describe('getTextLabel', () => {
    it('should parse the text, break the text in elements and return a text based on those elements given a single text without placeholders',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'This is a single uninterrupted line of text.';
      const result = flexibleTextService.getTextLabel(text, null);

      expect(result).toEqual(text);
    });
  });

  describe('getTextLabel', () => {
    it('should parse the text, break the text in elements and return a text based on those elements given a text with a single placeholders',
    () => {
      const flexibleTextService = new FlexibleTextService(null, null);
      const text = 'Klik #LINK(label=hier;url=http://dikkeaanbieding.nl)LINK# voor een dikke aanbieding!';
      const result = flexibleTextService.getTextLabel(text, null);

      expect(result).toEqual('Klik hier voor een dikke aanbieding!');
    });
  });
});
