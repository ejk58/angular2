import { Pipe, PipeTransform } from '@angular/core';
import {CurrencyPipe} from '@angular/common';

@Pipe({
  name: 'money'
})
export class MoneyPipe implements PipeTransform {

  constructor(private readonly cp: CurrencyPipe) { }

  transform(value: any): string {
    if (value !== null) {
      if (isNaN(value)) {
        return '<span class="money">' + value + '</span>';
      } else {
        return '<span class="money">' +  this.cp.transform(value, 'EUR', 'symbol', '1.0-0')
        + '</span>';
      }
    } else {
      return '';
    }
  }
}
