import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'complianceLight'
})
export class ComplianceLightPipe implements PipeTransform {

  constructor() { }

  transform(value: any): string {

    let styledValue = '';
    if (value !== null) {
      if (value === 1) {
        styledValue = '<div class="compliance-light number-1"></div>';
      } else if (value === 2) {
        styledValue = '<div class="compliance-light number-2"></div>';
      } else if (value === 3) {
        styledValue = '<div class="compliance-light number-3"></div>';
      } else if (value === 4) {
        styledValue = '<div class="compliance-light number-4"></div>';
      } else if (value === 5) {
        styledValue = '<div class="compliance-light number-5"></div>';
      } else if (value === 6) {
        styledValue = '<div class="compliance-light number-6"></div>';
      }
    }
    return styledValue;
  }
}
