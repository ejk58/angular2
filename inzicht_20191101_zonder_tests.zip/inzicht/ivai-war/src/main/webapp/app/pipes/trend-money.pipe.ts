import { Pipe, PipeTransform } from '@angular/core';
import {MoneyPipe} from './money.pipe';
import {DomSanitizer, SafeHtml} from '@angular/platform-browser';

@Pipe({
  name: 'trendMoney'
})

export class TrendMoneyPipe implements PipeTransform {

  private innerValue = null;
  private newValue = '';

  constructor(protected sanitizer: DomSanitizer,
              private readonly moneyPipe: MoneyPipe) {}

  transform(value: any): SafeHtml {
    if (value !== null) {
      if (value.hasOwnProperty('value') && value['value'] !== null) {
        this.innerValue = value['value'];
      } else if (value.hasOwnProperty('Bedrag') && value['Bedrag'] !== null) {
        this.innerValue = value['Bedrag'];
      }

      if (this.innerValue !== null && !isNaN(this.innerValue)) {
        this.innerValue = this.moneyPipe.transform(this.innerValue);
      }

      const stringValue = this.innerValue == null ? ' ' : String(this.innerValue);
      const iconValue = ((value.hasOwnProperty('revision') && value['revision'] === 1) || (value.hasOwnProperty('Correctie') && value['Correctie'] === 'J')) ? ' bd_lens' : '';

      this.newValue = '<div class="trendmoney">' +
        '<div class="money">' + stringValue + '</div>' +
        '<div class="trendicon' + iconValue + '"></div>' +
        '</div>';
    }

    return this.sanitizer.bypassSecurityTrustHtml(this.newValue);
  }
}
