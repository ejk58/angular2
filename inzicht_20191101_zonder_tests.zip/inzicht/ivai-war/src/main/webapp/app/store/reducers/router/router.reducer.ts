import {ActionReducerMap} from '@ngrx/store';
import {ActivatedRouteSnapshot, Params, RouterStateSnapshot} from '@angular/router';
import * as fromRouter from '@ngrx/router-store';
import {RouterStateSerializer} from '@ngrx/router-store';

export interface RouterSidesParams {
  left: Params;
  right?: Params;
}

export interface RouterStateUrl {
  url: string;
  params: Params;
  queryParams: Params;
  routerSidesParams: RouterSidesParams;
}

export const reducers: ActionReducerMap<any> = {
  router: fromRouter.routerReducer
};

export class CustomSerializer implements RouterStateSerializer<RouterStateUrl> {
  serialize(routerState: RouterStateSnapshot): RouterStateUrl {
    const { url } = routerState;
    const { queryParams } = routerState.root;
    const routerSidesParams: RouterSidesParams = {left: undefined};

    let state: ActivatedRouteSnapshot = routerState.root;
    const outlets = state.firstChild ? state.firstChild.children : [];

    outlets.forEach(view => routerSidesParams[view.outlet] = {...view.params} );

    while (state.firstChild) {
      state = state.firstChild;
    }

    const { params } = state;

    // Only return an object including the URL, params and query params
    // instead of the entire snapshot
    return { url, params, queryParams, routerSidesParams };
  }
}
