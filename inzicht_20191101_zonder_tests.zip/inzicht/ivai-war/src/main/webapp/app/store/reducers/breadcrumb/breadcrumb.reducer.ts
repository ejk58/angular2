import * as breadcrumbActions from '../../actions/breadcrumb/breadcrumb.actions';
import { DynamicSideIndicator } from '../../../commons/dynamic-side-indicator';
import {MenuItem} from 'primeng/api';

const sideGenerator = new DynamicSideIndicator();

export interface BreadcrumbState {
  left?: {
    breadcrumbs: MenuItem[];
  };
  right?: {
    breadcrumbs: MenuItem[];
  };
}

export const initialBreadcrumbState = {
  left: {
    breadcrumbs: []
  },
  right: {
    breadcrumbs: []
  }
};

export function breadcrumbReducer(state = initialBreadcrumbState, action: breadcrumbActions.BreadcrumbActions): BreadcrumbState {

  switch (action.type) {
    case breadcrumbActions.BREADCRUMB_ADD: {
      const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);
      state[updateSide].breadcrumbs.pop();
      const newBreadcrumbs =  state[updateSide].breadcrumbs;
      newBreadcrumbs.push(action.payload.breadcrumb);
      newBreadcrumbs.push({ label: action.payload.newLabel});
      return {
        [updateSide]: {
          breadcrumbs: newBreadcrumbs
        },
        [staticSide]: {
          breadcrumbs: state[staticSide].breadcrumbs
        }
      };
    }

    case breadcrumbActions.BREADCRUMB_REMOVE: {
      const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);
      const index = state[updateSide].breadcrumbs.findIndex(obj => obj === action.payload.breadcrumb);
      const newBreadcrumbs =  state[updateSide].breadcrumbs.slice(0, index + 1);
      return {
        [updateSide]: {
          breadcrumbs: newBreadcrumbs
        },
        [staticSide]: {
          breadcrumbs: state[staticSide].breadcrumbs
        }
      };
    }

    case breadcrumbActions.BREADCRUMB_RESET: {
      const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);
      const newBreadcrumbs =  state[updateSide].breadcrumbs;
      newBreadcrumbs.length = 0;
      return {
        [updateSide]: {
          breadcrumbs: newBreadcrumbs
        },
        [staticSide]: {
          breadcrumbs: state[staticSide].breadcrumbs
        }
      };
    }

    default:
      return state;
  }
}
