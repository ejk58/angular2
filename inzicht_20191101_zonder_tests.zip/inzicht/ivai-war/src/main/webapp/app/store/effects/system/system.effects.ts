import {Actions, Effect, ofType} from '@ngrx/effects';
import * as systemActions from '../../actions/system/system.actions';
import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {catchError, map, switchMap} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class SystemEffects {
  constructor(
    private readonly action$: Actions,
    private readonly http: HttpClient
  ) { }

  @Effect() systemVersion$: Observable<any> = this.action$.pipe(
    ofType(systemActions.SYSTEM_VERSION_LOAD),
    switchMap((action: systemActions.SystemVersionLoad) => {
      return this.http
        .get('rest/system/version', {withCredentials: true, responseType: 'text'})
        .pipe(map((data: any) => new systemActions.SystemVersionLoadSuccess(data)))
        .pipe(catchError(err => of(new systemActions.SystemVersionLoadFailed(err))));
    }));

  @Effect() systemConfiguration$: Observable<any> = this.action$.pipe(
    ofType(systemActions.SYSTEM_CONFIGURATION_LOAD),
    switchMap((action: systemActions.SystemConfigurationLoad) => {
      return this.http
        .get('rest/system/configuration', {withCredentials: true})
        .pipe(map((data: any) => new systemActions.SystemConfigurationLoadSuccess(data)))
        .pipe(catchError(err => of(new systemActions.SystemConfigurationLoadFailed(err))));
    }));
}
