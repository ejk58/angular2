import * as fromDomain from './domain/domain.reducer';
import * as fromRouter from './router/router.reducer';
import * as fromHeader from './header/header.reducer';
import * as fromSubject from './subject/subject.reducer';
import * as fromReleations from './relations/relations.reducer';
import * as fromPages from './page/page.reducer';
import * as fromModalWrapper from './modal-wrapper/modal-wrapper.reducer';
import * as fromBreadcrumb from './breadcrumb/breadcrumb.reducer';
import * as fromSystem from './system/system.reducer';

import * as fromRouterStore from '@ngrx/router-store';

import {ActionReducerMap, createFeatureSelector} from '@ngrx/store';

export interface AppState {
  domain: fromDomain.DomainState;
  router: fromRouterStore.RouterReducerState<fromRouter.RouterStateUrl>;
  header: fromHeader.HeaderState;
  subject: fromSubject.SubjectState;
  relations: fromReleations.RelationsState;
  page: fromPages.PageState;
  modalWrapper: fromModalWrapper.ModalWrapperstate;
  breadcrumb: fromBreadcrumb.BreadcrumbState;
  system: fromSystem.SystemState;
}

export const reducers: ActionReducerMap<AppState> = {
  domain: fromDomain.domainReducer,
  router: fromRouterStore.routerReducer,
  header: fromHeader.headerReducer,
  subject: fromSubject.subjectReducer,
  relations: fromReleations.relationsdReducer,
  page: fromPages.pageReducer,
  modalWrapper: fromModalWrapper.modalWrapperReducer,
  breadcrumb: fromBreadcrumb.breadcrumbReducer,
  system: fromSystem.systemReducer,
};

export const getAppState = createFeatureSelector<AppState>('inzichtStore');

export * from './domain/domain.reducer';
export * from './router/router.reducer';
export * from './header/header.reducer';
export * from './subject/subject.reducer';
export * from './relations/relations.reducer';
export * from './page/page.reducer';
export * from './modal-wrapper/modal-wrapper.reducer';
export * from './breadcrumb/breadcrumb.reducer';
export * from './system/system.reducer';

