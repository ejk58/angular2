import * as storeActions from '../../actions/domain/domain.actions';
import {SubjectValidator} from '../../../commons/subject-validators';
import {DynamicSideIndicator} from '../../../commons/dynamic-side-indicator';
import {Domain} from '../../../components/domain/domain';
import {Subject} from '../../../classes/subject';

const sideGenerator = new DynamicSideIndicator();
const subjectValidator = new SubjectValidator();

export interface SearchResult {
  name: string;
  subjects: Subject[];
  subjectSearchKey: string;
  error?: string;
}

export interface DomainState {
  loading: boolean;
  error?: number;
  menuItems: any;

  left?: {
    active: Domain;
    searchResults: SearchResult[];
  };
  right?: {
    active: Domain;
    searchResults: SearchResult[];
  };
}

export const initialDomainState: DomainState = {
  loading: false,
  menuItems: [],
  left: {
    active: null,
    searchResults: []
  },
  right: {
    active: null,
    searchResults: []
  }
};

function loadDomain(state: DomainState, action: storeActions.LoadMenu): DomainState {
  return {
    loading: true,
    menuItems: state.menuItems,
    left: {
      active: state.left.active,
      searchResults: []
    },
    right: {
      active: state.right.active,
      searchResults: []
    }
  };
}

function loadDomainSuccess(state: DomainState, action: storeActions.LoadMenuSuccess): DomainState {
  return {
    loading: false,
    menuItems: [...state.menuItems, ...action.payload],
    left: {
      active: state.left.active,
      searchResults: state.left.searchResults
    },
    right: {
      active: state.right.active,
      searchResults: state.right.searchResults
    }
  };
}

function loadDomainFailed(state: DomainState, action: storeActions.LoadMenuFailed): DomainState {
  return {
    loading: false,
    error: (action.payload && action.payload.status ? action.payload.status : -1),
    menuItems: state.menuItems,
    left: {
      active: state.left.active,
      searchResults: state.left.searchResults
    },
    right: {
      active: state.right.active,
      searchResults: state.right.searchResults
    }
  };
}

function loadSelectedDomain(state: DomainState, action: storeActions.LoadSelectedDomain): DomainState {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  let updateSearchResults: SearchResult[];
  const updateSearchResult: SearchResult = { name: action.payload.domain.name, subjects: [], subjectSearchKey: undefined };

  if (state[updateSide].searchResults.length === 0) {
    updateSearchResults = [updateSearchResult];
  } else {
    const domainExists: boolean = state[updateSide].searchResults.some((searchResult: SearchResult) => {
      return searchResult.name === updateSearchResult.name;
    });

    if (domainExists) {
      updateSearchResults = state[updateSide].searchResults;
    } else {
      updateSearchResults = [...state[updateSide].searchResults, updateSearchResult];
    }
  }

  return {
    loading: false,
    menuItems: state.menuItems,
    [updateSide]: {
      active: state[updateSide].active,
      searchResults: updateSearchResults
    },
    [staticSide]: {
      active: state[staticSide].active,
      searchResults: state[staticSide].searchResults
    }
  };
}

/**
 * On load Active domain (which is navigated to),
 * reset selected domain items as false
 */
function loadActiveDomain(state: DomainState, action: storeActions.LoadActiveDomain): DomainState {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    menuItems: state.menuItems,
    [updateSide]: {
      active: { ...state[updateSide].active, ...action.payload.domain },
      searchResults: state[updateSide].searchResults
    },
    [staticSide]: {
      active: state[staticSide].active,
      searchResults: state[staticSide].searchResults
    }
  };
}

function loadActiveDomainSubjects(state: DomainState, action: storeActions.LoadActiveDomainSubjects): DomainState {
  const payload = action.payload;
  const { updateSide, staticSide } = sideGenerator.getSides(payload.side);

  const searchResultIndex: number = state[updateSide].searchResults.findIndex(searchResult => searchResult.name === payload.domainName);
  state[updateSide].searchResults[searchResultIndex] = {
    name: payload.domainName,
    subjects: payload.subjects,
    subjectSearchKey: payload.subjectSearchKey,
    error: payload.err ? subjectValidator.generateErrorMessage(payload.err, payload.type, payload.subjectNr) : undefined
  };

  return {
    loading: false,
    menuItems: state.menuItems,
    [updateSide]: {
      active: state[updateSide].active,
      searchResults: [...state[updateSide].searchResults]
    },
    [staticSide]: {
      active: state[staticSide].active,
      searchResults: state[staticSide].searchResults
    }
  };
}

function clearActiveDomain(state: DomainState, action: storeActions.ClearActiveDomain): DomainState {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    menuItems: state.menuItems,
    [updateSide]: {
      active: null,
      searchResults: []
    },
    [staticSide]: {
      active: state[staticSide].active,
      searchResults: state[staticSide].searchResults
    }
  };
}

export function domainReducer(state = initialDomainState, action: storeActions.DomainActions): DomainState {

  switch (action.type) {
    case storeActions.LOAD_MENU: return loadDomain(state, action);

    case storeActions.LOAD_MENU_SUCCESS: return loadDomainSuccess(state, action);

    case storeActions.LOAD_MENU_FAILED: return loadDomainFailed(state, action);

    case storeActions.LOAD_SELECTED_DOMAIN: return loadSelectedDomain(state, action);

    case storeActions.LOAD_ACTIVE_DOMAIN: return loadActiveDomain(state, action);

    case storeActions.LOAD_SELECTED_DOMAIN_SUBJECTS: return loadActiveDomainSubjects(state, action);

    case storeActions.CLEAR_SELECTED_DOMAIN: return clearActiveDomain(state, action);

    case storeActions.DOMAIN_RESET: return initialDomainState;

    default:
      return state;
  }
}
