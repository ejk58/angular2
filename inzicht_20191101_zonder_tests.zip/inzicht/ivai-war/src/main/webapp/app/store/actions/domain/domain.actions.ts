import {Action} from '@ngrx/store';
import {Domain} from '../../../components/domain/domain';
import {Subject} from '../../../classes/subject';

export const LOAD_MENU                     = '[Domain] Load Menu';
export const LOAD_MENU_SUCCESS             = '[Domain] Load Menu Success';
export const LOAD_MENU_FAILED              = '[Domain] Load Menu Failed';

export const LOAD_ACTIVE_DOMAIN            = '[Domain] Load Active Domain';
export const LOAD_SELECTED_DOMAIN          = '[Domain] Load Selected Domain';
export const LOAD_SELECTED_DOMAIN_SUBJECTS = '[Domain] Load Selected Domain Subjects';
export const CLEAR_SELECTED_DOMAIN         = '[Domain] Clear Selected Domain';

export const SELECT_DOMAIN                 = '[Domain] Select';
export const SELECT_DOMAIN_WITH_SUBJECT    = '[Domain] Select With subject';
export const DOMAIN_SHARED_EFFECT          = '[Domain] Shared Effect';

export const DOMAIN_RESET                  = '[Domain] Reset';

export class LoadMenu implements Action {
  readonly type = LOAD_MENU;
}

export class LoadMenuSuccess implements Action {
  readonly type = LOAD_MENU_SUCCESS;
  constructor(public payload: Domain[]) {}
}

export class LoadMenuFailed implements Action {
  readonly type = LOAD_MENU_FAILED;
  constructor(public payload: any) {}
}

export class LoadActiveDomain implements Action {
  readonly type = LOAD_ACTIVE_DOMAIN;
  constructor(public payload: { side: string; domain: Domain }) {}
}

export class LoadSelectedDomain implements Action {
  readonly type = LOAD_SELECTED_DOMAIN;
  constructor(public payload: { side: string; domain: Domain }) {}
}

export class LoadActiveDomainSubjects implements Action {
  readonly type = LOAD_SELECTED_DOMAIN_SUBJECTS;
  constructor(public payload: {
    side: string;
    domainName: string;
    subjects?: Subject[];
    subjectNr?: string;
    subjectSearchKey?: string;
    type?: any;
    err?: any
  }) {}
}

export class ClearActiveDomain implements Action {
  readonly type = CLEAR_SELECTED_DOMAIN;
  constructor(public payload: { side: string; }) {}
}

export class SelectDomain implements Action {
  readonly type = SELECT_DOMAIN;
  constructor(public payload: any) {}
}

export class SelectDomainWithSubject implements Action {
  readonly type = SELECT_DOMAIN_WITH_SUBJECT;
  constructor(public payload: any) {}
}

export class DomainSharedEffect implements Action {
  readonly type = DOMAIN_SHARED_EFFECT;
  constructor(public payload: any) {}
}

export class DomainReset implements Action {
  readonly type = DOMAIN_RESET;
}

export type DomainActions
  = LoadMenu
  | LoadMenuSuccess
  | LoadMenuFailed
  | LoadActiveDomain
  | LoadSelectedDomain
  | LoadActiveDomainSubjects
  | SelectDomainWithSubject
  | DomainSharedEffect
  | ClearActiveDomain
  | SelectDomain
  | DomainReset;
