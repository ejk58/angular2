import { Action } from '@ngrx/store';

export const MODAL_OPEN  = '[MODAL] Open';
export const MODAL_CLOSE = '[MODAL] Close';

export class ModalOpen implements Action {
  readonly type = MODAL_OPEN;
  constructor(public payload?: string) { }
}

export class ModalClose implements Action {
  readonly type = MODAL_CLOSE;

  constructor(public payload?: string) { }
}

export type ModalActions = ModalOpen | ModalClose;
