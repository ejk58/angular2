import { createSelector } from '@ngrx/store';
import * as fromReducers from '../../reducers';
import {getPageConfigStateLeft} from '..';

export const getDomainState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.domain);

export const getDomainMenu = createSelector(
  getDomainState, domain => domain.menuItems);

export const getDomainLoading = createSelector(
  getDomainState, domain => domain.loading);

export const getDomainError = createSelector(
  getDomainState, domain => domain.error);

// Get the state of **left** side state & domain properties
export const getDomainStateLeft = createSelector(
  getDomainState, domain => domain.left);

export const getActiveDomainLeft = createSelector(
  getDomainStateLeft, domain => domain.active);

export const getActiveDomainIdDomainLeft = createSelector(
  getDomainStateLeft, domain => domain.active ? domain.active.domainId : null);

export const getSearchResultsByDomainLeft = createSelector(
  getDomainStateLeft, (domain, props) => domain.searchResults.find(searchResult => searchResult.name === props.name));

// Get the state of **right** side state & domain properties
export const getDomainStateRight = createSelector(
  getDomainState, domain => domain.right);

export const getActiveDomainRight = createSelector(
  getDomainStateRight, domain => domain.active);

export const getActiveDomainIdDomainRight = createSelector(
  getDomainStateRight, domain => domain.active ? domain.active.domainId : null);

export const getSearchResultsByDomainRight = createSelector(
  getDomainStateRight, (domain, props) => domain.searchResults.find(searchResult => searchResult.name === props.name));
