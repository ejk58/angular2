import { Action } from '@ngrx/store';

export const HEADER_SELECT_MENU = '[HEADER] Select Menu';
export const HEADER_RESET = '[HEADER] Reset';

export class HeaderSelectMenu implements Action {
  readonly type = HEADER_SELECT_MENU;

  constructor(public payload: {side: string; menu: string; }) { }
}

export class HeaderReset implements Action {
  readonly type = HEADER_RESET;
}

export type HeaderActions = HeaderSelectMenu | HeaderReset;
