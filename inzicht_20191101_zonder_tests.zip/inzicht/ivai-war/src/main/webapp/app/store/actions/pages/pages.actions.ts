import { Action } from '@ngrx/store';

export const LOAD_PAGE_MENU = '[PAGE] Load Page Menu';
export const LOAD_PAGE_MENU_SUCCESS = '[PAGE] Load Page Menu Success';
export const LOAD_PAGE_MENU_FAILED = '[PAGE] Load Page Menu Failed';

export const LOAD_PAGE_CONFIG = '[PAGE] Load Page Config';
export const LOAD_PAGE_CONFIG_SUCCESS = '[PAGE] Load Page Config Success';
export const LOAD_PAGE_CONFIG_FAILED = '[PAGE] Load Page Config Failed';

export const LOAD_PAGE = '[PAGE] Load Page';
export const LOAD_PAGE_SUCCESS = '[PAGE] Load Page Success';
export const LOAD_PAGE_FAILED = '[PAGE] Load Page Failed';

// Reset menu state if the user logs out // Temp exp..
export const RESET_PAGE = '[PAGE] Reset Page State';

export class LoadPageMenu implements Action {
  readonly type = LOAD_PAGE_MENU;

  constructor(public payload: any) { }
}

export class LoadPageMenuSuccess implements Action {
  readonly type = LOAD_PAGE_MENU_SUCCESS;

  constructor(public payload: any) { }
}

export class LoadPageMenuFailed implements Action {
  readonly type = LOAD_PAGE_MENU_FAILED;

  constructor(public payload: any) { }
}

export class LoadPageConfig implements Action {
  readonly type = LOAD_PAGE_CONFIG;

  constructor(public payload: any) { }
}

export class LoadPageConfigSuccess implements Action {
  readonly type = LOAD_PAGE_CONFIG_SUCCESS;

  constructor(public payload: any) { }
}

export class LoadPageConfigFailed implements Action {
  readonly type = LOAD_PAGE_CONFIG_FAILED;

  constructor(public payload: any) { }
}

export class LoadPage implements Action {
  readonly type = LOAD_PAGE;

  constructor(public payload: any) { }
}

export class LoadPageSuccess implements Action {
  readonly type = LOAD_PAGE_SUCCESS;

  constructor(public payload: any) { }
}

export class LoadPageFailed implements Action {
  readonly type = LOAD_PAGE_FAILED;

  constructor(public payload: any) { }
}

export class ResetPageState implements Action {
  readonly type = RESET_PAGE;
}

export type pageAll =
  | LoadPageMenu
  | LoadPageMenuSuccess
  | LoadPageMenuFailed
  | LoadPageConfig
  | LoadPageConfigSuccess
  | LoadPageConfigFailed
  | LoadPage
  | LoadPageSuccess
  | LoadPageFailed
  | ResetPageState;
