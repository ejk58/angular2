import * as storeActions from '../../actions';
import { DynamicSideIndicator } from '../../../commons/dynamic-side-indicator';

const sideGenerator = new DynamicSideIndicator();

export interface RelationsState {
  loading: boolean;
  error?: string;
  left?: {
    list: any;
  };
  right?: {
    list: any;
  };
}

export const initialRelationsState: RelationsState = {
  loading: false,
  left: {
    list: [],
  },
  right: {
    list: []
  }
};

function loadRelations(state: RelationsState, action: storeActions.LoadRelations) {
  return {
    loading: true,
    left: {
      list: state.left.list
    },
    right: {
      list: state.right.list
    }
  };
}

function loadRelationsSuccess(state: RelationsState, action: storeActions.LoadRelationsSuccess) {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    [updateSide]: {
      list: action.payload.list
    },
    [staticSide]: {
      list: state[staticSide].list
    }
  };
}

function loadRelationsFailed(state: RelationsState, action: storeActions.LoadRelationsFailed) {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    error: 'relations kunnen niet opgelaald worden...!',
    [updateSide]: {
      list: state[staticSide].list
    },
    [staticSide]: {
      list: state[staticSide].list
    }
  };
}

export function relationsdReducer(state = initialRelationsState, action: storeActions.RelationsAll): RelationsState {

  switch (action.type) {
    case storeActions.LOAD_RELATIONS: return loadRelations(state, action);

    case storeActions.LOAD_RELATIONS_SUCCESS: return loadRelationsSuccess(state, action);

    case storeActions.LOAD_RELATIONS_FAILED: return loadRelationsFailed(state, action);

    case storeActions.RELATIONS_RESET: return initialRelationsState;

    default:
      return state;
  }
}
