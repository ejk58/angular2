import { Location } from '@angular/common';
import { Injectable } from '@angular/core';
import { Params, Router } from '@angular/router';

import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { first, map, tap } from 'rxjs/operators';

import { SelectorSideIndicator } from '../../../commons/store-selector-side-indicator';
import * as routerActions from '../../actions';
import * as fromSelectors from '../../selectors';


@Injectable()
export class RouterEffects {
  @Effect({ dispatch: false })
  navigate$ = this.actions$.pipe(
    ofType(routerActions.GO),
    map((action: routerActions.Go) => action.payload),
    tap(({ path, query: queryParams, extras}) => {
      this.router.navigate(path, { queryParams, ...extras });
    })
  );

  @Effect({ dispatch: false })
  navigateTo$ = this.actions$.pipe(
    ofType(routerActions.GOTO),
    map((action: routerActions.GoTo) => action.payload),
    tap(({ side, domainId, pageId, params}) => {
      this.router.navigate(['/main', { outlets: { [side]: [domainId, pageId, params]}}]);
    })
  );

  @Effect({ dispatch: false })
  navigateToWithoutParams$ = this.actions$.pipe(
    ofType(routerActions.NAVIGATE_WITHOUT_PARAMS),
    map((action: routerActions.NavigateWithoutParams) => action.payload),
    tap(({ side, domainId, initPageId}) => {
      const otherSide = side === 'left' ? 'right' : 'left';
      const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(otherSide, 'getRouterState');
      this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(first()).subscribe(state => {
        const commands = {
          outlets: {
            [side]: [domainId, initPageId]
          }
        };

        if (state) {
          this.preserveOtherSide(state, commands, otherSide);
        }

        this.router.navigate(['/main', commands]);
      });
    })
  );

  @Effect({ dispatch: false })
  navigateToWithParams$ = this.actions$.pipe(
    ofType(routerActions.NAVIGATE_WITH_PARAMS),
    map((action: routerActions.NavigateWithParams) => action.payload),
    tap(({ side, domain, pageId, params}) => {
      const otherSide = side === 'left' ? 'right' : 'left';
      const destinationPageId = pageId ? pageId : domain.initPageId;
      const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(otherSide, 'getRouterState');
      this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(first()).subscribe(state => {
        const commands = {
          outlets: {
            [side]: [domain.domainId, destinationPageId, params]
          }
        };

        if (state) {
          this.preserveOtherSide(state, commands, otherSide);
        }

        this.router.navigate(['/main', commands]);
      });
    })
  );

  @Effect({ dispatch: false })
  navigateBack$ = this.actions$.pipe(
    ofType(routerActions.BACK),
    tap(() => this.location.back())
  );

  @Effect({ dispatch: false })
  navigateForward$ = this.actions$.pipe(
    ofType(routerActions.FORWARD),
    tap(() => this.location.forward())
  );

  constructor(
    private readonly actions$: Actions,
    private readonly router: Router,
    private readonly location: Location,
    private readonly store: Store<any>,
    private readonly selectorSideIndicator: SelectorSideIndicator
  ) {}

  private preserveOtherSide(state: Params, commands: any, otherSide: 'left'|'right'): void {
    const filtersJson = (state.filters) ? JSON.stringify(state.filters) : undefined;
    const otherDomainId = state.domainId;
    const otherPageId = state.pageId;

    const { ...otherParams } = state;
    delete otherParams.domainId;
    delete otherParams.pageId;
    delete otherParams.filters;

    if (state.filters) {
      commands.outlets[otherSide] = [otherDomainId, otherPageId, filtersJson, otherParams];
    } else {
      commands.outlets[otherSide] = [otherDomainId, otherPageId, otherParams];
    }
  }
}
