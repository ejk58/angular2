import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {Observable, of} from 'rxjs';
import {catchError, map, mergeMap, switchMap} from 'rxjs/operators';

import * as storeActions from '../../actions';
import {PageTitleService} from '../../../services/page-title.service';
import {Subject} from '../../../classes/subject';
import {SubjectPresentation} from '../../../classes/subject-presentation';
import {SubjectPresentationLabel} from '../../../classes/subject-presentation-label';
import {Domain} from '../../../components/domain/domain';

@Injectable()
export class SubjectEffects {
  constructor(
    private readonly action$: Actions,
    private readonly http: HttpClient,
    private readonly pageTitleService: PageTitleService
  ) { }

  @Effect() subject$: Observable<any> = this.action$.pipe(
    ofType(storeActions.SUBJECT_LOAD),
    switchMap((action: storeActions.SubjectLoad) => {
      const domainId = action.payload.domain.domainId;
      const domainName = action.payload.domain.name;
      const type = action.payload.type.type;
      const side = action.payload.side;
      const subjectSearchKey = action.payload.subjectSearchKey;
      const subjectNr = action.payload.subject;

      return this.http
        .get('rest/subject?domainId=' + domainId + '&' + type + '=' + subjectNr, {withCredentials: true})
        .pipe(mergeMap((subjects: Subject[]) => {
          return [
            new storeActions.SubjectLoadSuccess(),
            new storeActions.LoadActiveDomainSubjects({
              side: side,
              domainName: domainName,
              subjects: subjects,
              subjectSearchKey: subjectSearchKey
            })
          ];
        }))
        .pipe(catchError(error => {
          return of(
            new storeActions.LoadActiveDomainSubjects({
              side: action.payload.side,
              domainName: domainName,
              subjectNr: subjectNr,
              type: type,
              err: error.status
            })
          );
        }));
    }));

  // This effect will be triggered only for url navigation
  @Effect() loadedSubject$: Observable<any> = this.action$.pipe(
    ofType(storeActions.SUBJECT_LOAD_SELECTED_SUBJECT),
    mergeMap((action: storeActions.SubjectLoadSelectedSubject) => {
      const domain: Domain = action.payload.domain;
      const side: string = action.payload.side;
      const subjectModel: Object = action.payload.subjectModel;

      const domainId: string = domain.domainId;
      const primaryPathKeyName: string = (domain.pathKeys.find(pathKey => pathKey.primary)).name;

      return this.http
        .get('rest/subject?domainId=' + domainId + '&' + primaryPathKeyName + '=' + subjectModel[primaryPathKeyName], {withCredentials: true})
        .pipe(
          map((subjects: Subject[]) => {
            let selectedSubject: Subject = this.findMatchingSubject(subjects, subjectModel);
            selectedSubject = selectedSubject ? selectedSubject : this.createErrorSubject(subjectModel);
            this.pageTitleService.update(selectedSubject.model['subjectNr'], selectedSubject.presentation.name);
            return new storeActions.SubjectSelect({side, subject: selectedSubject});
          })
        )
        .pipe(
          catchError(() => {
            const selectedSubject = this.createErrorSubject(subjectModel);
            this.pageTitleService.update(selectedSubject.model['subjectNr'], selectedSubject.presentation.name);
            return of(new storeActions.SubjectLoadFailed({side, subject: selectedSubject}));
          })
        );
    }));

  private findMatchingSubject(subjects: Subject[], subjectModel: Object): Subject {
    return subjects.find(subject =>
      // Deliberately using == because of comparing unequal types.
      Object.keys(subjectModel).every(pathKey => subject.model[pathKey] == subjectModel[pathKey])
    );
  }

  private createErrorSubject(subjectModel: Object): Subject {
    const label: SubjectPresentationLabel = new SubjectPresentationLabel('FOUT', 'white', 'red');
    const presentation: SubjectPresentation = new SubjectPresentation('???', '???', 'Er is een fout opgetreden', label);
    return new Subject(presentation, subjectModel);
  }

}
