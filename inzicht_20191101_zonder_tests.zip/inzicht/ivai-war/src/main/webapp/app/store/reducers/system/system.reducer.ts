import * as storeActions from '../../actions';

export interface SystemState {
  error?: string;
  version: string;
  configurationUpdateTime: string;
  ktaEnvironment: string;
  hierarchicalGraphMaxRows: number;
  tablePaginatorMaxPageSize: number;
  tablePaginatorPositionBothThreshold: number;
}

export const initialSystemState = {
  version: 'unknown',
  configurationUpdateTime: '',
  ktaEnvironment: '',
  hierarchicalGraphMaxRows: 500,
  tablePaginatorMaxPageSize: 25,
  tablePaginatorPositionBothThreshold: 25,
};


export function systemReducer(state = initialSystemState, action: storeActions.SystemAll): SystemState {
  switch (action.type) {
    case storeActions.SYSTEM_VERSION_LOAD:
      return {...state};

    case storeActions.SYSTEM_VERSION_LOAD_SUCCESS:
      return {...state, version: action.payload};

    case storeActions.SYSTEM_VERSION_LOAD_FAILED:
      return {...state, error: 'System version cannot be loaded'};

    case storeActions.SYSTEM_CONFIGURATION_LOAD:
      return {...state};

    case storeActions.SYSTEM_CONFIGURATION_LOAD_SUCCESS:
      return {...state,
          configurationUpdateTime:  action.payload.configurationUpdateTime,
          ktaEnvironment: action.payload.ktaEnvironment,
          hierarchicalGraphMaxRows: +action.payload.hierarchicalGraphMaxRows,
          tablePaginatorMaxPageSize: +action.payload.tablePaginatorMaxPageSize,
          tablePaginatorPositionBothThreshold: +action.payload.tablePaginatorPositionBothThreshold};

    case storeActions.SYSTEM_CONFIGURATION_LOAD_FAILED:
      return {...state, error: 'System configuration cannot be loaded'};

    default:
      return state;
  }
}
