import { createSelector } from '@ngrx/store';
import * as fromReducers from '../../reducers';

export const getRelationsState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.relations);

export const getRelationsLoadingState = createSelector(
  getRelationsState, relations => relations.loading);

export const getRelationsLeft = createSelector(
  getRelationsState, relations => relations.left.list);

export const getRelationsRight = createSelector(
  getRelationsState, relations => relations.right.list);
