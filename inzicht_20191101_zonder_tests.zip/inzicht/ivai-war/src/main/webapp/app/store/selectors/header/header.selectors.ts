import { createSelector } from '@ngrx/store';
import * as fromReducers from '../../reducers';

export const getHeaderState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.header);

// Get the state of **left** side state of active menu
export const getActiveMenuLeft = createSelector(
  getHeaderState, header => header.left.activeMenu);

// Get the state of **right** side state of active menu
export const getActiveMenuRight = createSelector(
  getHeaderState, header => header.right.activeMenu);
