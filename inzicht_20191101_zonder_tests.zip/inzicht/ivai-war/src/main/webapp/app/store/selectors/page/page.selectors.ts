import * as fromReducers from '../../reducers';
import {createSelector} from '@ngrx/store';
import {getRouterStateLeft, getRouterStateRight} from '../router/router.selectors';
import {Page} from '../../../components/page/page';

export const getPageState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.page);

export const getPageLoadingState = createSelector(
  getPageState, page => page.loading);

// Get the state of **left** page state
export const getPageConfigStateLeft = createSelector(
  getPageState, page => page.left.pageConfig);

export const getPageMenuStateLeft = createSelector(
  getPageState, page => page.left.pageMenu);

export const getPageHasGlobalFiltersLeft = createSelector(
  getRouterStateLeft, getPageConfigStateLeft,
  (routerState, pageConfig) => {
    const page: Page = pageConfig.find(page => page.key === routerState.pageId);
    return page && page.globalFilterWidget != null;
  });

export const getPageByKeyLeft = createSelector(
  getPageConfigStateLeft,
  (pageConfig, props) => pageConfig.find(page => page.key === props.key));

// Get the state of **right** page state
export const getPageConfigStateRight = createSelector(
  getPageState, page => page.right.pageConfig);

export const getPageMenuStateRight = createSelector(
  getPageState, page => page.right.pageMenu);

export const getPageHasGlobalFiltersRight = createSelector(
  getRouterStateRight, getPageConfigStateRight,
  (routerState, pageConfig) => {
    const page: Page = pageConfig.find(page => page.key === routerState.pageId);
    return page && page.globalFilterWidget != null;
  });

export const getPageByKeyRight = createSelector(
  getPageConfigStateRight,
  (pageConfig, props) => pageConfig.find(page => page.key === props.key));
