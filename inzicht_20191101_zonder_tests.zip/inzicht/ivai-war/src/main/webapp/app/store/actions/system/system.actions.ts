import { Action } from '@ngrx/store';

export const SYSTEM_VERSION_LOAD = '[SYSTEM] System version Load';
export const SYSTEM_VERSION_LOAD_SUCCESS = '[SYSTEM] System version Load Success';
export const SYSTEM_VERSION_LOAD_FAILED = '[SYSTEM] System version Load Failed';
export const SYSTEM_CONFIGURATION_LOAD = '[SYSTEM] System configuration Load';
export const SYSTEM_CONFIGURATION_LOAD_SUCCESS = '[SYSTEM] System configuration Load Success';
export const SYSTEM_CONFIGURATION_LOAD_FAILED = '[SYSTEM] System configuration Load Failed';

export class SystemVersionLoad implements Action {
  readonly type = SYSTEM_VERSION_LOAD;
}

export class SystemVersionLoadSuccess implements Action {
  readonly type = SYSTEM_VERSION_LOAD_SUCCESS;
  constructor(public payload?: any) { }
}

export class SystemVersionLoadFailed implements Action {
  readonly type = SYSTEM_VERSION_LOAD_FAILED;
  constructor(public payload?: any) { }
}

export class SystemConfigurationLoad implements Action {
  readonly type = SYSTEM_CONFIGURATION_LOAD;
  constructor() { }
}

export class SystemConfigurationLoadSuccess implements Action {
  readonly type = SYSTEM_CONFIGURATION_LOAD_SUCCESS;
  constructor(public payload?: any) { }
}

export class SystemConfigurationLoadFailed implements Action {
  readonly type = SYSTEM_CONFIGURATION_LOAD_FAILED;
  constructor(public payload?: any) { }
}

export type SystemAll =
  SystemVersionLoad |
  SystemVersionLoadSuccess |
  SystemVersionLoadFailed |
  SystemConfigurationLoad |
  SystemConfigurationLoadSuccess |
  SystemConfigurationLoadFailed;
