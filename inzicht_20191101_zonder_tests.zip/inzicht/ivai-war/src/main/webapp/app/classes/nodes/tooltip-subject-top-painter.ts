import {Selection} from 'd3-ng2-service';
import {SubjectIconProvider} from '../../commons/subject-icon-provider';

import {Node} from './node';
import {NodeSubjectPresentation} from './node-subject-presentation';
import {TooltipPainter} from './tooltip-painter';
import {TooltipSubjectPainter} from './tooltip-subject-painter';

export class TooltipSubjectTopPainter  extends TooltipSubjectPainter {

  protected drawTooltip(): void {
    super.drawTooltip();
    this.drawArrow();
  }

  public showTooltip(node: Node<any, NodeSubjectPresentation>): void {
    if (node != null) {
      this.updateLabels(node);
      const labelWidth = this.calculateLabelWidth(node);
      this.updateButtons(node, labelWidth);
      const width = this.tooltipPadding * 3 + labelWidth + this.tooltipButtonWidth * 2;
      this.updateBackground(width);
      const x = Math.max(0, node.x + this.leftMargin - Math.floor((this.tooltipPadding * 3 + labelWidth + this.tooltipButtonWidth * 2) / 2));
      const y = node.y + this.topMargin - (this.tooltipLabelHeight * 4 + this.tooltipPadding * 2) - this.imageRadius;

      this.tooltipGroup
        .select('.tooltip-arrow-south')
        .attr('transform', 'translate(' + Math.floor((this.tooltipPadding * 3 + labelWidth + this.tooltipButtonWidth * 2) / 2) + ',0)');

      this.tooltipGroup
        .attr('pointer-events', 'auto')
        .attr('transform', 'translate(' + x + ',' + y + ')')
        .transition()
        .attr('opacity', 1.0);
    } else {
      this.tooltipGroup
        .attr('pointer-events', 'auto')
        .transition()
        .attr('opacity', 1.0);
    }
  }

  protected drawArrow(): void {
    this.tooltipGroup
      .append('g')
      .classed('tooltip-arrow', true)
      .classed('tooltip-arrow-south', true)
      .append('path')
      .attr('d', 'M0,' + (this.tooltipLabelHeight * 4 + this.tooltipPadding * 2 + 9) + 'l-9,-9h18z')
      .on('mouseover', () => this.showTooltip(null))
      .on('mouseout', () => this.hideTooltip());
  }
}
