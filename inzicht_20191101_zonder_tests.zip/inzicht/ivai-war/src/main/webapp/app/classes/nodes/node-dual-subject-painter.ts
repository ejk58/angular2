import {Selection} from 'd3-ng2-service';

import {NodePainter} from './node-painter';
import {Node} from './node';
import {NodeSubjectPresentation} from './node-subject-presentation';
import {NodeSubjectPainter} from './node-subject-painter';

export class NodeDualSubjectPainter extends NodeSubjectPainter implements NodePainter<NodeSubjectPresentation> {

  protected drawNewNodes(graph: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .attr('class', node => node.classes.join(' ') + ' node-design-subject')
      .classed('node-filter-person', node => node.presentation.isPerson)
      .classed('node-filter-business', node => !node.presentation.isPerson)
      .attr('transform', node => 'translate(' + (node.x + this.leftMargin) + ',' + (node.y + this.topMargin) + ')');

    this.drawSameEnitity(newNodeGroups);
    this.drawSameAddress(newNodeGroups);
    this.drawPersonSubjectIcon(newNodeGroups);
    this.drawDefaultSubjectIcon(newNodeGroups);
    this.drawAge(newNodeGroups);
    this.drawLabels(newNodeGroups);
    this.drawEventAura(newNodeGroups, graph);
  }

  protected drawDefaultSubjectIcon(newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-background', true)
      .classed('node-relation-married', node => node.presentation.isMarried)
      .classed('node-relation-livingtogether', node => node.presentation.isLivingTogether)
      .classed('node-relation-expartner', node => node.presentation.isExPartner)
      .classed('node-type-filter-person', node => node.presentation.isPerson && node.presentation.personType === node.presentation.type)
      .classed('node-type-filter-business', node => !node.presentation.isPerson || node.presentation.personType !== node.presentation.type)
      .text(node => this.subjectIconProvider.getMainSubjectIcon(node.presentation.type));

    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-filter-person', node => node.presentation.isPerson && node.presentation.personType === node.presentation.type)
      .classed('node-type-filter-business', node => !node.presentation.isPerson || node.presentation.personType !== node.presentation.type)
      .text(node => node.isMain ? this.subjectIconProvider.getMainSubjectIcon(node.presentation.type) : this.subjectIconProvider.getNormalSubjectIcon(node.presentation.type));
  }

  protected drawPersonSubjectIcon(newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(node => node.presentation.personType != null && node.presentation.personType !== node.presentation.type)
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-background', true)
      .classed('node-relation-married', node => node.presentation.isMarried)
      .classed('node-relation-livingtogether', node => node.presentation.isLivingTogether)
      .classed('node-relation-expartner', node => node.presentation.isExPartner)
      .classed('node-type-filter-person', true)
      .text(node => this.subjectIconProvider.getMainSubjectIcon(node.presentation.personType));

    newNodeGroups.filter(node => node.presentation.personType != null && node.presentation.personType !== node.presentation.type)
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-filter-person', true)
      .text(node => node.isMain ? this.subjectIconProvider.getMainSubjectIcon(node.presentation.personType) : this.subjectIconProvider.getNormalSubjectIcon(node.presentation.personType));
  }
}
