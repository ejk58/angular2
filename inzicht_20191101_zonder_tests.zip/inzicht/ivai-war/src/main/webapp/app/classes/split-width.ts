export class SplitWidth {
    static readonly default: SplitWidth = {left: 10000, right: 0};

    left: number;
    right: number;
}
