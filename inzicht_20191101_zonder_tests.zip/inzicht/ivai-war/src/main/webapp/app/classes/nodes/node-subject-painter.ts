import {Selection} from 'd3-ng2-service';
import {SubjectIconProvider} from '../../commons/subject-icon-provider';
import {SubjectType} from '../../commons/subject-type';

import {NodePainter} from './node-painter';
import {Node} from './node';
import {NodeSubjectPresentation} from './node-subject-presentation';
import {TooltipPainter} from './tooltip-painter';
import {TooltipSubjectSidePainter} from './tooltip-subject-side-painter';

export class NodeSubjectPainter implements NodePainter<NodeSubjectPresentation> {

  protected static readonly nodeRadius = 100;
  protected static readonly imageRadius = 30;
  protected static readonly labelHeight = 20;

  protected tooltipPainter: TooltipPainter<NodeSubjectPresentation>;

  constructor(protected readonly topMargin: number,
      protected readonly leftMargin: number,
      protected readonly tooltipGroup: Selection<any, any, any, any>,
      protected readonly subjectIconProvider: SubjectIconProvider,
      protected readonly profileFunction: Function,
      protected readonly relationFunction: Function) {

    this.tooltipPainter = new TooltipSubjectSidePainter(this.topMargin, this.leftMargin, NodeSubjectPainter.imageRadius + 10, this.tooltipGroup,
        this.profileFunction, this.relationFunction);
  }

  public drawNodes(graph: Selection<any, any, any, any>, nodeMainGroup: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, nodes: Node<any, NodeSubjectPresentation>[]) {
    const nodeGroups = nodeMainGroup.selectAll('g')
      .data(nodes, (node: Node<any, NodeSubjectPresentation>) => node.id);

    this.drawNewNodes(graph, nodeGroups.enter().append('g'));
    this.updateExistingNodes(nodeGroups);
    this.removeObsoleteNodes(nodeGroups.exit());
  }

  protected drawNewNodes(graph: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .attr('class', node => node.classes.join(' ') + ' node-design-subject')
      .attr('transform', node => 'translate(' + (node.x + this.leftMargin) + ',' + (node.y + this.topMargin) + ')');

    this.drawSameEnitity(newNodeGroups);
    this.drawSameAddress(newNodeGroups);
    this.drawSubjectIcon(newNodeGroups);
    this.drawAge(newNodeGroups);
    this.drawLabels(newNodeGroups);
    this.drawEventAura(newNodeGroups, graph);
  }

  protected updateExistingNodes(existingNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    existingNodeGroups
      .attr('transform', node => 'translate(' + (node.x + this.leftMargin) + ',' + (node.y + this.topMargin) + ')');
  }

  protected removeObsoleteNodes(obsoleteNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    obsoleteNodeGroups.remove();
  }

  protected handleMouseOverEvent(graph: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, node: Node<any, NodeSubjectPresentation>): void {
    this.tooltipPainter.showTooltip(node);
    graph.selectAll('.link-id-' + node.id).classed('link-highlight', true);
  }

  protected handleMouseOutEvent(graph: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, node: Node<any, NodeSubjectPresentation>): void {
    this.tooltipPainter.hideTooltip();
    graph.selectAll('.link-id-' + node.id).classed('link-highlight', false);
  }

  protected drawSameEnitity(newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(d => d.presentation.isSameEntity)
      .append('circle')
      .attr('cx', 0)
      .attr('cy', -NodeSubjectPainter.imageRadius + 1)
      .attr('r', NodeSubjectPainter.imageRadius + 6)
      .classed('node-same-entity', true);
  }

  protected drawSameAddress(newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(node => node.presentation.isSameAddress)
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(-2 * NodeSubjectPainter.imageRadius) + 3)
      .classed('node-same-address', true)
      .text(SubjectIconProvider.locationIcon);
  }

  protected drawSubjectIcon(newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-background', true)
      .classed('node-relation-married', node => node.presentation.isMarried)
      .classed('node-relation-livingtogether', node => node.presentation.isLivingTogether)
      .classed('node-relation-expartner', node => node.presentation.isExPartner)
      .text(node => this.subjectIconProvider.getMainSubjectIcon(node.presentation.type));

    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .text(node => node.isMain ? this.subjectIconProvider.getMainSubjectIcon(node.presentation.type) : this.subjectIconProvider.getNormalSubjectIcon(node.presentation.type));
  }

  protected drawAge(newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(d => d.presentation.age != null)
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(-NodeSubjectPainter.imageRadius) + 5)
      .classed('node-age-label', true)
      .text(node => node.presentation.age);
  }

  protected drawLabels(newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', NodeSubjectPainter.labelHeight + 2)
      .classed('node-name-label', true)
      .text(node => (node.presentation.name == null || node.presentation.name.length <= 18) ? node.presentation.name : node.presentation.name.substr(0, 16) + '...');

    newNodeGroups.filter(d => d.presentation.type != SubjectType.MeerDan20PersonenOpAdres)
      .append('text')
      .attr('x', 0)
      .attr('y', NodeSubjectPainter.labelHeight * 2 + 2)
      .classed('node-number-label', true)
      .text(node => node.presentation.subjectNr);
  }

  protected drawEventAura(newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, graph: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .append('circle')
      .classed('node-aura', true)
      .attr('cx', 0)
      .attr('cy', 0)
      .attr('r', NodeSubjectPainter.nodeRadius)
      .on('mouseover', node => this.handleMouseOverEvent(graph, node))
      .on('mouseout', node => this.handleMouseOutEvent(graph, node));
  }
}
