import {SubjectPresentation} from './subject-presentation';

export class Subject {
  constructor(public presentation: SubjectPresentation, public model: Object) {}
}
