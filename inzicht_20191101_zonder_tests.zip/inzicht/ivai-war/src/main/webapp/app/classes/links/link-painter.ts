import {Selection} from 'd3-ng2-service';
import {Link} from './link';
import {Node} from '../nodes/node';

export interface LinkPainter<P> {
  drawLinks(graph: Selection<any, any, any, any>, linkMainGroup: Selection<any, Link<Node<any, any>, any, P>, any, any>, links: Link<Node<any, any>, any, P>[]): void;
}
