import {SimulationNodeDatum} from 'd3-ng2-service';

export class Node<M, P> implements SimulationNodeDatum {

  public id: string;
  public x: number;
  public y: number;

  public model: M;
  public presentation: P;

  public data: any;
  public classes: string[];

  public isMain: boolean;
}
