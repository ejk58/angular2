import {Selection} from 'd3-ng2-service';
import {Node} from './node';

export interface NodePainter<P> {
  drawNodes(graph: Selection<any, any, any, any>, nodeMainGroup: Selection<any, Node<any, P>, any, any>, nodes: Node<any, P>[]): void;
}
