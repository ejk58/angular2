import {Injectable} from '@angular/core';
import {Router, Params} from '@angular/router';

import {MenuItem} from 'primeng/components/common/api';
import {Store} from '@ngrx/store';
import {first} from 'rxjs/operators';

import {TrackingService} from '../services/tracking.service';
import {SplitViewState} from '../services/split-view-state.service';
import * as storeActions from '../store/actions';
import * as fromSelectors from '../store/selectors';
import {SelectorSideIndicator} from './store-selector-side-indicator';
import {PathKey} from '../classes/path-key';
import {Subject} from '../classes/subject';
import {Domain} from '../components/domain/domain';
import { Page } from '../components/page/page';
import { PageMenuCategory } from '../store/reducers';

@Injectable()
export class PageNavigationUtilService {

  public side: string;
  public pageMenu: PageMenuCategory[];

  constructor(private readonly router: Router,
    private readonly trackingService: TrackingService,
    private readonly splitViewState: SplitViewState,
    private readonly selectorSideIndicator: SelectorSideIndicator,
    private readonly store: Store<any>) { }

  public composeNavParams(side: string, destinationPageId: string, filter: any, containerId: string, tabId: number): any {
    let sideParams: Params;
    // note: this is a "synchronous" select
    this.store.select(fromSelectors.getRouterSides).pipe(first()).subscribe(sides => {
      sideParams = sides[side];
    });

    const mandatoryPathKeys: string[] = this.getMandatoryPathKeys(side, destinationPageId);
    const navParams: any = this.constructParams(sideParams, mandatoryPathKeys);

    // add the filter values on top of it
    if (filter) {
      Object.keys(filter).forEach(filterKey => {
        navParams[filterKey] = filter[filterKey];
      });
    }

    if (containerId) {
      navParams.containerId = containerId;
    }
    if (tabId !== undefined && tabId !== null) {
      navParams.tabId = tabId;
    }

    return navParams;
  }

  public openInNewTab(fromSide: string, domainId: string, pageId: string, filter: any, focus: boolean): void {
    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName(fromSide, 'getActiveDomain');
    this.store.select(fromSelectors[indicatedDomainSelector]).pipe(first()).subscribe(activeDomain => {
      const parameters = this.composeNavParams(fromSide, pageId, filter, null, null);

      const urlTree = this.router.createUrlTree(['/main', { outlets: { left: [(domainId ? domainId : activeDomain.domainId), pageId, parameters], right: null } }]);
      const serializedUrl = this.router.serializeUrl(urlTree);
      const win = window.open(`${window.location.pathname}#${serializedUrl}`, '_blank');
      if (focus) {
        win.focus();
      }
    });
  }

  public navigateToPage(side: string, destinationPageId: string, filter: any, containerId: string): void {
    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getActiveDomain');
    this.store.select(fromSelectors[indicatedDomainSelector]).pipe(first()).subscribe(activeDomain => {
      const parameters = this.composeNavParams(side, destinationPageId, filter, containerId, null);

      this.router.navigate(['/main', { outlets: { [side]: [activeDomain.domainId, destinationPageId, parameters] } }]);
    });
  }

  public navigate(side: string, destinationSide: string, destinationPageId: string, filter: any, containerId: string): void {
    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getActiveDomain');
    this.store.select(fromSelectors[indicatedDomainSelector]).pipe(first()).subscribe(activeDomain => {
      const destinationPageIdLocal = destinationPageId ? destinationPageId : activeDomain.initPageId;
      const parameters = this.composeNavParams(side, destinationPageIdLocal, filter, containerId, null);

      if (destinationSide === 'right') {
        this.splitViewState.emitOpen2Screen(true);
        this.store.dispatch(new storeActions.HeaderSelectMenu({ side: 'right', menu: 'none' }));
        if (side === 'left') {
          this.trackingService.trackEvent('klik', 'Tweede scherm/soort:automatisch', destinationPageId, null);
        }
      }

      this.router.navigate(['/main', { outlets: { [destinationSide]: [activeDomain.domainId, destinationPageIdLocal, parameters] } }]);
    });
  }

  public updateBreadcrumb(side: string, widgetId: string, domainId: string, currentPageId: string, newPageId: string, tabId: number): void {
    let pageConfig: Page[];

    // note: this is a "synchronous" select
    const indicatedPageMenuSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getPageConfigState');
    this.store.select(fromSelectors[indicatedPageMenuSelector]).pipe(first()).subscribe(config => pageConfig = config);

    const outlet = {};
    let label: string = null;
    let newLabel: string = null;
    pageConfig.forEach( function(page) {
      if (page.key === currentPageId) {
        label = page.title;
      }
      if (page.key === newPageId) {
        newLabel = page.title;
      }
    });

    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getRouterState');
    this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(first()).subscribe(sideParams => {
      outlet[side] = [domainId, currentPageId, sideParams];
      const breadcrumb = { label: label, routerLink: ['/main', { outlets: outlet}], command: (event) => {
          this.breadcrumbBack(side, event);
        } };
      this.store.dispatch(new storeActions.BreadcrumbAdd({side, breadcrumb, newLabel}));
    });
  }

  public breadcrumbBack(side, event) {
    this.store.dispatch(new storeActions.BreadcrumbRemove({side: side, breadcrumb: event.item}));
  }

  /*
  * @deprecated Deprecated in favor of using navigate method.
  */
  public navToPageSecondScreen(pageId: string, open2Screen: boolean = true, subject?: Subject) {
    this.splitViewState.emitOpen2Screen(open2Screen);
    this.store.dispatch(new storeActions.HeaderSelectMenu({ side: 'right', menu: 'none' }));

    this.trackingService.trackEvent('klik', 'Tweede scherm/soort:zelf', pageId, null);

    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName('left', 'getActiveDomain');
    this.store.select(fromSelectors[indicatedDomainSelector]).pipe(first()).subscribe(activeDomain => {
      if (activeDomain) {
        this.updateSelectedDomain('right', activeDomain);

        if (subject) {
          this.selectDomainAndSubject(activeDomain, pageId, 'left', subject);

          const mandatoryPathKeys = this.getMandatoryPathKeys('left', pageId);
          const subjectModel: Object = this.constructParams(subject.model, mandatoryPathKeys);
          this.updateSubject('right', activeDomain, subjectModel);
        } else {
          this.selectDomain(activeDomain);
        }
      }
    });
  }

  private updateSelectedDomain(side: string, domain: Domain): void {
    this.store.dispatch(new storeActions.LoadActiveDomain({side, domain: domain}));
    this.store.dispatch(new storeActions.LoadSelectedDomain({side, domain: domain}));
  }

  private updateSubject(side: string, domain: Domain, subjectModel: Object): void {
    this.store.dispatch(new storeActions.SubjectLoadSelectedSubject({
      side,
      domain,
      subjectModel
    }));
  }

  private selectDomain(domain: Domain): void {
    this.store.dispatch(new storeActions.SelectDomain({
      side: 'right',
      domain
    }));
  }

  private selectDomainAndSubject(domain: Domain, pageId: string, fromSide: string, subject: Subject): void {
    const mandatoryPathKeys: string[] = this.getMandatoryPathKeys(fromSide, pageId);
    this.store.dispatch(new storeActions.SelectDomainWithSubject({
      side: 'right',
      domain,
      subject,
      params: this.constructParams(subject.model, mandatoryPathKeys)
    }));
  }

  private constructParams(sourceValues: any, mandatoryPathKeys: string[]): any {
    // const params = {}; // TODO-overleg hierdoor verlies je entityNr als je bijv van Klantprofiel -> Compliance gaat
    const {pageId, domainId, ...params} = sourceValues;
    mandatoryPathKeys.forEach(mpk => params[mpk] = sourceValues[mpk]);
    return params;
  }

  private getMandatoryPathKeys(side: string, pageId: string): string[] {
    let mandatoryPathKeys: string[];

    const indicatedPageByKeySelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getPageByKey');
    this.store.select<Page>(fromSelectors[indicatedPageByKeySelector], {key: pageId}).pipe(first()).subscribe(page => {
      mandatoryPathKeys = page.mandatoryPathKeys;
    });

    return mandatoryPathKeys;
  }
}
