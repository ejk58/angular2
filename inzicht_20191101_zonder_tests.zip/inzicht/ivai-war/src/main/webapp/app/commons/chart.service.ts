import {Injectable} from '@angular/core';
import {CurrencyPipe} from '@angular/common';

@Injectable()
export class ChartService {

  readonly chartColors = ['#777c00', '#a90061', '#d6d7b2', '#cce0f1', '#39870c', '#cccccc', '#01689b', '#e17000', '#e5b2cf'];

  constructor(private readonly currencyPipe: CurrencyPipe) { }

  // in case of 2 y axes with different unit of measurements this service-method cannot be used. (for solution see linechart.component)
  tooltip_contents(d, defaultTitleFormat, defaultValueFormat, color)  {
    const c: string = color(d[0].id);
    const formattedValue = defaultValueFormat(d[0].value);
    return `<div style="
        background-color:${c};
        color: white;
        padding-left: 15px;
        padding-right: 15px;
        border-radius: 3px">${formattedValue}</div>`;
  }

  createYAxis(unit: string, tickValues: { [key: number]: string } = {}, label?: string): any {

    const tickValuesPresent = Object.keys(tickValues).length > 0 && tickValues.constructor === Object;

    const yAxis: { [key: string]: any } = {show: true, tick: {outer: false}};
    let formatter = (d) => d;

    if (tickValuesPresent) {
      formatter = (d) => tickValues[d] ? tickValues[d] : d;
      const tickValuesKeys: number[] = Object.keys(tickValues).map(Number);
      yAxis.tick.values = tickValuesKeys;
      yAxis.min = unit === 'PERCENTAGE' ? Math.min(...tickValuesKeys) : undefined;
      yAxis.max = Math.max(...tickValuesKeys);
    } else if (unit === 'MONEY' || unit === 'HISTORYMONEY') {
      formatter = (d) => this.currencyPipe.transform(d, 'EUR', 'symbol', '1.0-0');
    } else if (unit === 'PERCENTAGE') {
      formatter = (d) => d + '%';
    }

    yAxis.tick.format = formatter;

    if (typeof label !== 'undefined') {
      yAxis.label = {
        text: label,
        position: 'inner-middle'
      };
    }

    return yAxis;
  }

  calcYAxisLabelWidthOld(data: any, type: string): number {
    let chartPadding = 0;
    let maxValue = 0;
    data.forEach(value => {
      if (Math.abs(value) > maxValue) {
        maxValue = Math.abs(value);
        chartPadding = 15 + (maxValue.toString().length * 8.6);
        if ( type  === 'HISTORYMONEY' || type  === 'MONEY') {
          chartPadding = chartPadding + 8;
          if ( maxValue > 999) { chartPadding = chartPadding + 9; }
          if ( maxValue > 999999) { chartPadding = chartPadding + 5; }
        }
      }
    });
    return chartPadding;
  }

  /**
   * Calculates the width needed to display all labels on the y axis (max value width, basically)
   * @param data A flat data structure with the values. Example: [100, 200, 4, 30]
   * @param yAxis The y axis object. Used to see if a formatting function is defined for the axis
   */
  calcAxisLabelWidth(data: (string | number | boolean)[], axis: any): number {
    const paddingPerCharacter = 8.6;
    const initialPadding = 15;

    let max = 0;
    const allData = axis.tick.values ? [].concat(...data, ...axis.tick.values) : [].concat(...data);
    allData.forEach(value => {
      const formattedValue = axis.tick.format(value);
      if (formattedValue != null) {
        const characters = ('' + formattedValue).length;
        const length = characters * paddingPerCharacter;
        if (length > max) {
          max = length;
        }
      }
    });

    return initialPadding + max;
  }

}
