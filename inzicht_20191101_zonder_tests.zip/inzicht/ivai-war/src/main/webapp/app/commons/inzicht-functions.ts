/**
 * Returns an array filled with each underlying field of the given object.
 *
 * Example:
 * {
 *   homeAddress: {street: 'Homelane', number: 23},
 *   workAddress: {street: 'Workstreet', number: 95}
 * }
 *
 * would become
 *
 * [
 *   {street: 'Homelane', number: 23},
 *   {street: 'Workstreet', number: 95}
 * ]
 * @param object The object you wish to transform into an array
 */
export function objectFieldsAsArray(object: { [key: string]: any }): any[] {
  return Object.keys(object).map(key => object[key]);
}

/**
 * Returns an array filled with each underlying property's value of the given object.
 *
 * Example object:
 * {
 *   homeAddress: {street: 'Homelane', number: 23},
 *   workAddress: {street: 'Workstreet', number: 95}
 * }
 *
 * Example call: objectPropertiesAsArray(obj, 'street');
 *
 * Gives: ['Homelane', Workstreet']
 * @param object The object you wish to transform into an array
 */
export function objectPropertiesAsArray(object: { [key: string]: { [property: string]: any } }, property: string): any[] {
  return Object.keys(object).map(key => object[key][property]);
}

/**
 * The padStart() method pads the current string with another string (multiple times, if needed) until the resulting string reaches the given length.
 * The padding is applied from the start (left) of the current string.
 * This implementation is based on the String.prototype.padStart polyfill.
 * @param source The source string you'd wish to pad
 * @param targetLength The length of the resulting string once the current string has been padded.
 *        If the value is less than the current string's length, the current string is returned as is.
 * @param padString The string to pad the current string with. If this padding string is too long to stay within the targetLength,
 *        it will be truncated from the right. The default value is " " (U+0020 'SPACE').
 */
export function padStart(source: number | string, targetLength: number, padString: string = ' '): string {
  source = String(source);
  if (source.length >= targetLength) {
    return source;
  } else {
    const diff = targetLength - source.length;
    if (diff > padString.length) {
      padString += padString.repeat(diff / padString.length); // append to original to ensure we are longer than needed
    }
    return padString.slice(0, diff) + String(source);
  }
}

/** The document service we use to get links to documents gives invalid url's which we have to correct before using them. (issue IVAI-9741).
 *  It is not common to do this and normally this is only done on the url parameters or their values.
 *
 * @param url The url string you'd wish to encode the last segment of.
 *
 *  example:
 *  input = https://www.belastingdienst.nl/fncmis/resources/IdMet#.pdf.pdf
 *  output = https://www.belastingdienst.nl/fncmis/resources/IdMet%23.pdf.pdf
 */
export function encodeLastUriSegment(url: string): string {
  const lastSlashIndex = url.lastIndexOf('/');
  const lastSegment = url.substr(lastSlashIndex + 1);
  // minimum of 3 time / and at least one character after last / and no url parameters, i.e. no ? or =
  if (((url.match(/\//g) || []).length > 2) && (url.length > lastSlashIndex + 1) && lastSegment.indexOf('?') === -1 && lastSegment.indexOf('=') === -1) {
    return url.substr(0, lastSlashIndex + 1) + encodeURIComponent(lastSegment);
  }
  return url;
}
