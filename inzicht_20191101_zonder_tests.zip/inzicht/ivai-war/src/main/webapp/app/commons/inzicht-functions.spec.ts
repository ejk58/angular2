import {encodeLastUriSegment} from './inzicht-functions';

describe('Encode the last part of an url', () => {

  it('should encode only the last part of the url', () => {
    const result = encodeLastUriSegment('https://#/#/#/docId#.pdf.pdf');
    expect(result).toEqual('https://#/#/#/docId%23.pdf.pdf');
  });

  it('should not encode the last part of the url when less that 3 slashes', () => {
    const result = encodeLastUriSegment('https://#');
    expect(result).toEqual('https://#');
  });

  it('should not encode the last part of the url when the last / is the the end of the url', () => {
    const result = encodeLastUriSegment('https://#/#$%^&*/##.pdf.pdf/');
    expect(result).toEqual('https://#/#$%^&*/##.pdf.pdf/');
  });

  it('should encode the last part of the url with many special characters', () => {
    const result = encodeLastUriSegment('https://#/, : @ & + $ #');
    expect(result).toEqual('https://#/%2C%20%3A%20%40%20%26%20%2B%20%24%20%23');
  });

  it('should not encode the last part of the url if it contains url parameters', () => {
    const result = encodeLastUriSegment('https://jira/secure/RapidBoard.jspa?rapidView=1798&view=detail');
    expect(result).toEqual('https://jira/secure/RapidBoard.jspa?rapidView=1798&view=detail');
  });

});

