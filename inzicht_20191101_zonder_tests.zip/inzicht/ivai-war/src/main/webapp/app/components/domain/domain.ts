export interface Domain {
  iconName: string;
  index: number;
  initPageId: string;
  name: string;
  pathKeys: Array<any>;
  subjectTypes: Array<any>;
  domainId: string;
}
