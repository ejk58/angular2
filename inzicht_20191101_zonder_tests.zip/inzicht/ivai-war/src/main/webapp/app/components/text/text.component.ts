import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Store} from '@ngrx/store';

import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {Unsubscriber} from '../../commons/unsubscriber';
import {HelpState} from '../../services/help.service';
import {TrackingService} from '../../services/tracking.service';
import {FlexibleTextService, TextElement, TextValues} from '../../services/flexible-text.service';
import * as storeActions from '../../store/actions';

@Component({
  selector: 'i-text',
  templateUrl: './text.component.html',
  styleUrls: ['./text.component.scss'],
  providers: [Unsubscriber]
})
export class TextComponent implements OnInit, OnDestroy {

  @Input() text: string;
  @Input() side: string;
  @Input() data?: any;

  public elements: any[];
  public values: TextValues;

  constructor(private readonly flexibleTextService: FlexibleTextService,
              private readonly trackingService: TrackingService,
              private readonly helpState: HelpState,
              private readonly pageNavigationUtil: PageNavigationUtilService,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    this.values = this.buildTextValues();
    this.elements = this.flexibleTextService.getTextResults(this.text, this.values);
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public hasClickEvent(element: TextElement): boolean {
    return element.type === FlexibleTextService.linkType || element.type === FlexibleTextService.buttonType;
  }

  public handleMouseDown(event: MouseEvent): void {
    // This is to prevent the 'sticky scroll' cursor from engaging on Windows when clicking the middle mouse button
    event.preventDefault();
  }

  public handleMouseUp(event: MouseEvent, element: any): void {
    const openInNewTab = (event.ctrlKey || event.button === 1);
    const focus = event.shiftKey;

    if (element.type === 'LINK') {
      this.followLink(element, openInNewTab, focus);
    } else if (element.type === 'BUTTON') {
      this.executeAction(element);
    }
  }

  public followLink(element: any, openInNewTab: boolean, focus: boolean): void {
    const filter = element['model'];
    const page = element['page'];
    const targetSide = (element['target'] === 'currentSide') ? this.side : 'right';

    if (openInNewTab) {
      this.pageNavigationUtil.openInNewTab(this.side, null, page, filter, focus);
    } else {
      this.pageNavigationUtil.navigate(this.side, targetSide, page, filter, null);
    }
  }

  public executeAction(element: any) {
    const action = element['action'];

    if (action === 'open-domain-menu') {
      setTimeout(() => this.store.dispatch(new storeActions.HeaderSelectMenu({side: this.side, menu: 'domain'})));
    } else if (action === 'open-feedback-panel') {
      this.store.dispatch(new storeActions.HeaderSelectMenu({side: this.side, menu: 'default'}));
      this.store.dispatch(new storeActions.ModalOpen('feedback'));
    } else if (action === 'open-help-panel') {
      this.helpState.emitHelpText(this.helpState.generalHelp);
      this.store.dispatch(new storeActions.HeaderSelectMenu({side: this.side, menu: 'default'}));
      this.store.dispatch(new storeActions.ModalOpen('help'));
      }
  }

  private buildTextValues(): TextValues {
    const values = new TextValues();

    values.side = this.side;
    values.data = this.data;

    return values;
  }
}
