import {Component, Input, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import * as storeActions from '../../store';
import * as fromSelectors from '../../store/selectors';
import {Domain} from './domain';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-domain',
  templateUrl: './domain.component.html',
  styleUrls: ['./domain.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})
export class DomainComponent implements OnInit, OnDestroy {

  @Input() side: string;

  public readonly browserIsIE = /trident\//i.test(window.navigator.userAgent);

  public domainMenu$: Observable<Domain[]>;
  public domainMenuLoading$: Observable<boolean>;
  public domainMenuError$: Observable<number>;
  public username: string;
  public loading: boolean;
  public activeDomainId: string;

  constructor(private readonly store: Store<any>,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    // Scroll top the domainMenu on start
    const domainContainer = document.getElementById('domain');
    setTimeout(() => domainContainer.scrollTop = 0, 300);

    this.domainMenu$ = this.store.select(fromSelectors.getDomainMenu);
    this.domainMenuLoading$ = this.store.select(fromSelectors.getDomainLoading);
    this.domainMenuError$ = this.store.select(fromSelectors.getDomainError);

    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getActiveDomainIdDomain');
    this.store.select(fromSelectors[indicatedDomainSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeDomainId => this.activeDomainId = activeDomainId);
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public selectDomain(domain: Domain): void {
    this.store.dispatch(new storeActions.LoadSelectedDomain({side: this.side, domain: domain}));

    if (domain.subjectTypes.length === 0) {
      this.store.dispatch(new storeActions.SelectDomain({side: this.side, domain: domain, subject: null}));
    }
  }

  public getActiveClass(domain: Domain): string {
    return this.activeDomainId === domain.domainId ? 'domain-active' : '';
  }
}
