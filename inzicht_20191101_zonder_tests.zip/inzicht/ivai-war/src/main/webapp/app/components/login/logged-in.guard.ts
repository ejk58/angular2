import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';

import {Idle} from '@ng-idle/core';

import { AuthenticationService } from '../../services/authentication.service';

@Injectable()
export class LoggedInGuard implements CanActivate {

    constructor(private readonly router: Router,
                private readonly idle: Idle,
                private readonly authService: AuthenticationService) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        if (this.authService.isLoggedIn()) {
            this.idle.watch();
            return true;
        }
        // not logged in so redirect to login page
        this.authService.sendUserName(null);
        this.router.navigate(['/login'], { queryParams: { redirect: state.url, embed: route.queryParamMap.get('embed') }});
        return false;
    }
}
