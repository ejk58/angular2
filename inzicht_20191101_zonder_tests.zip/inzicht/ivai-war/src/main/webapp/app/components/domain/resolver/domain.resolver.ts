import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {Store} from '@ngrx/store';
import * as DomainActions from '../../../store/actions';

@Injectable()
export class DomainResolver implements Resolve<any> {

  constructor(private readonly store: Store<any>) { }

  resolve() {
    this.store.dispatch(new DomainActions.LoadMenu());
  }
}
