import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {Store} from '@ngrx/store';
import {SplitWidth} from '../../classes/split-width';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import * as headerActions from '../../store/actions/header/header.actions';
import * as fromSelectors from '../../store/selectors';
import {SplitViewState} from '../../services/split-view-state.service';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {Unsubscriber} from '../../commons/unsubscriber';
import {Params} from '@angular/router';
import { PageMenuOption, PageMenuCategory } from '../../store/reducers';
import { Page } from '../page/page';
import { first } from 'rxjs/operators';
import { combineLatest } from 'rxjs';

interface PageMenuCategoryWithEnabledStatus extends Omit<PageMenuCategory, 'options'> {
  options: PageMenuOptionWithEnabledStatus[];
}

interface PageMenuOptionWithEnabledStatus extends PageMenuOption {
  enabled: boolean;
}

@Component({
  selector: 'sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  providers: [Unsubscriber]
})
export class SidebarComponent implements OnInit, OnDestroy {

  @Input() side: any;
  @Output() selected: EventEmitter<boolean> = new EventEmitter<boolean>();

  public pageMenu: PageMenuCategoryWithEnabledStatus[];

  public selectedCategory: number;
  public currentPageId: string;
  public splitWidth: SplitWidth;

  constructor(private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly util: PageNavigationUtilService,
              private readonly splitViewState: SplitViewState,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    const routerState$ = this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(this.unsubscriber.takeUntilForUnsubscribe);

    const indicatedPageMenuSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getPageMenuState');
    const pageMenu$ = this.store.select(fromSelectors[indicatedPageMenuSelector]).pipe(first());

    const indicatedPageConfigSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getPageConfigState');
    const pageConfig$ = this.store.select(fromSelectors[indicatedPageConfigSelector]).pipe(first());

    combineLatest(
      routerState$, pageMenu$, pageConfig$
    ).subscribe(([sideParams, menu, pages]) => {
      this.currentPageId = sideParams.pageId;
      this.pageMenu = this.calculatePageMenuWithEnabledStatus(sideParams, menu, pages);
    });

    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(sizes => this.splitWidth = sizes == null ? SplitWidth.default : sizes);
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  private calculatePageMenuWithEnabledStatus(sideParams: Params, menu: PageMenuCategory[], pages: Page[]): PageMenuCategoryWithEnabledStatus[] {
    return menu.map(category => {
      const optionsWithEnabledStatus = category.options.map(option => {
        const page: Page = pages.find(page => page.key === option.key);
        const enabled = page.mandatoryPathKeys.every(pathKey => typeof sideParams[pathKey] !== 'undefined' &&
                                                                       sideParams[pathKey] !== 'undefined' &&
                                                                       sideParams[pathKey] !== 'null' &&
                                                                       sideParams[pathKey] !== null);
        return {...option, enabled};
      });

      return { ...category, options: optionsWithEnabledStatus};
    });
  }

  public toggleMenuCategory(category: number) {
    return (this.selectedCategory === category) ? this.selectedCategory = undefined : this.selectedCategory = category;
  }

  public selectPage(menuOption: PageMenuOption) {
    const selectedPageId: string = menuOption.key;
    this.store.dispatch(new headerActions.HeaderSelectMenu({side: this.side, menu: 'none' }));
    this.util.navigateToPage(this.side, selectedPageId, null, null);
  }

  public splittedToMobileScreen(): boolean {
    return this.splitWidth[this.side] <= this.splitViewState.breakpointMobile;
  }
}
