import { Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { mergeMap, tap } from 'rxjs/operators';
import { Subject } from '../../classes/subject';
import { PageNavigationUtilService } from '../../commons/page-navigation-util.service';
import { Unsubscriber } from '../../commons/unsubscriber';
import { DataTypeService } from '../../services/data-type.service';
import { SubjectService } from '../../services/subject.service';
import { TrackingService } from '../../services/tracking.service';
import {encodeLastUriSegment} from '../../commons/inzicht-functions';

@Component({
  selector: 'i-value',
  templateUrl: './value.component.html',
  styleUrls: ['./value.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})
export class ValueComponent implements OnInit, OnDestroy {

  @Input() type?: string;
  @Input() value?: any;
  @Input() side?: any;
  @Input() row?: any;
  @Input() column?: any;
  @Input() widgetId?: any;
  @Input() containerTabId?: number;
  @Input() domainId?: any;
  @Input() pageId?: any;
  @Input() inner?: boolean;

  public label: string;
  public style: string;
  public hasNoDataWrapping: boolean;

  constructor(private readonly trackingService: TrackingService,
              private readonly subjectService: SubjectService,
              private readonly pageNavigationUtil: PageNavigationUtilService,
              private readonly dataTypeService: DataTypeService,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    if (this.column != null && this.row != null) {
      this.type = (!this.row['ROWTYPE'] || this.column.columnName === 'FIRSTCOL') ? this.column.columnType : this.row['ROWTYPE'];
      this.value = this.row[this.column.columnName];
      this.label = this.column.label;
      this.style = 'value' + (this.column.style == null ? '' : (' ' + this.column.style)) + this.addDefaultStyles(this.row['alignment']);
      this.hasNoDataWrapping = this.column.noDataWrapping;
    } else {
      this.label = '';
      this.style = 'value' + this.addDefaultStyles(null);
      this.hasNoDataWrapping = false;
    }
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public getBaseType(): string {
    return this.dataTypeService.getBaseType(this.type, this.value);
  }

  public getOuterType(): string {
    return this.dataTypeService.getOuterType(this.type);
  }

  public getInnerType(): string {
    return this.dataTypeService.getInnerType(this.type);
  }

  private getDefaultAlignment(): string {
    return this.dataTypeService.getDefaultAlignment(this.type, this.value);
  }

  public getTypeFromSpecified(): string {
    return this.dataTypeService.getTypeFromSpecified(this.value);
  }

  private getValue(): any {
    let value = this.value;

    if (value != null) {
      if (value.hasOwnProperty('value')) {
        value = value.value;
      } else if (this.isFileLinkType()) {
          value = null;
      } else if (this.isAnnotatedType() && value.hasOwnProperty('Waarde')) {
        value = value.Waarde;
      } else if (this.isTrendType() && value.hasOwnProperty('Bedrag')) {
        value = value.Bedrag;
      } else if (this.isSpecifiedType() && value.hasOwnProperty('Waarde')) {
        value = value.Waarde;
      }
    }

    return value;
  }

  private addDefaultStyles(alignmentClass: string): string {
    const baseType = this.dataTypeService.getBaseType(this.type);
    const value = this.getValue();
    const possiblyNegative = DataTypeService.possiblyNegativeBaseTypes.some(possiblyNegativeBaseType => possiblyNegativeBaseType === baseType);

    let styles = ' ' + (alignmentClass ? alignmentClass : this.dataTypeService.getDefaultAlignment(this.type, this.value));

    if (possiblyNegative && !isNaN(value) && value < 0) {
      styles = styles + ' negative';
    }

    if (this.hasClickEvent()) {
      styles = styles + ' click-event';
    }

    if (this.hasDrillDown()) {
      styles = styles + ' drilldown';
    }

    return styles;
  }

  // Event Handling
  public handleMouseDown(event: MouseEvent): void {
    event.preventDefault(); // This is to prevent the 'sticky scroll' cursor from engaging on Windows when clicking the middle mouse button
  }

  public handleMouseUp(event: MouseEvent): void {
    const openInNewTab = (event.ctrlKey || event.button === 1) && !this.isScrollLinkType() && !this.isFileLinkType();

    if (openInNewTab) {
      const focus = event.shiftKey;
      this.openInNewTab(focus);
    } else if (this.hasDrillDown()) {
      this.goToDetailsPage();
    } else if (this.hasPageLink()) {
      this.followPageLink();
    } else if (this.hasSearchLink()) {
      this.followSearchLink();
    } else if (this.hasFileLink()) {
      this.downloadFile();
    } else if (this.hasScrollLink()) {
      this.scrollToWidget();
    }
  }

  private getDrillDownInfo(): Observable<any> {
    return of({
      external: false,
      fromSide: this.side,
      targetSide: this.side,
      pageId: this.getDetailsPage(),
      filter: this.getDetailsFilter()
    });
  }

  private goToDetailsPage(): void {
    this.getDrillDownInfo().subscribe(info => {
      this.trackingService.trackEvent('klik',
        `Klik doorsturen:${info.fromSide}/tab van:${this.pageId}/widget van:${this.widgetId}/tab naar:${info.pageId}`,
        null, null);

      this.pageNavigationUtil.updateBreadcrumb(info.fromSide, this.widgetId, this.domainId, this.pageId, info.pageId, this.containerTabId);
      this.pageNavigationUtil.navigateToPage(info.fromSide, info.pageId, info.filter, null);
    });
  }

  private downloadFile(): void {
    let win: any;
    const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/gi;

    if (this.value != null && this.value.hasOwnProperty('url')) {
      this.value['url'] = encodeLastUriSegment(this.value['url']);
      win = window.open(this.value['url'], '_blank');
    } else if (this.value.match(urlRegex)) {
      win = window.open(this.value, '_blank');
    }
    win.focus();
  }

  private scrollToWidget(): void {
    const container = document.querySelector(`.${this.side} #${this.side}_${this.value.widget}`);
    if (container) {
      container.scrollIntoView(true);
    }
  }

  private openInNewTab(focus: boolean): void {
    let info$: Observable<any>;

    if (this.hasDrillDown()) {
      info$ = this.getDrillDownInfo().pipe(
        tap(info => this.trackingService.trackEvent('klik',
          `Klik doorsturen:${info.fromSide}/tab van:${this.pageId}/widget van:${this.widgetId}/tab naar:${info.pageId}`,
          null, null))
      );
    } else if (this.hasPageLink()) {
      info$ = this.getPageLinkInfo();
    } else if (this.hasSearchLink()) {
      info$ = this.getSearchLinkInfo();
    }

    info$.subscribe(info => {
      this.pageNavigationUtil.openInNewTab(info.fromSide, this.domainId, info.pageId, info.filter, focus);
    });
  }

  private getPageLinkInfo(): Observable<any> {
    // value: waarde die getoond moet worden
    // target: type link (externalLink = url voor in nieuwe tab/window, rightSide = tweede scherm, currentSide = huidige scherm, none = geen link)
    // url: url voor externe link
    // filter: pathkeys voor link naar (huidige of) tweede scherm (ontbrekende pathkeys worden aangevuld met huidige pathkeys)
    // pageId: pagina voor link naar huidige of tweede scherm
    const target = this.value.target;

    if (target === 'externalLink') {
      return of({
        external: true,
        url: this.value.url
      });
    } else {
      const targetSide = (target === 'currentSide') ? this.side : 'right';
      const pageId = this.value.page != undefined ? this.value.page : this.pageId;
      const filter = this.value.filter != undefined ? this.value.filter : {};
      return of({
        external: false,
        fromSide: this.side,
        targetSide,
        pageId,
        filter
      });
    }
  }

  private followPageLink(): void {
    this.getPageLinkInfo().subscribe(info => {
      if (info.external) {
        this.trackingService.trackEvent('klik', 'Open external link', info.url, null);
        const win = window.open(info.url, '_blank');
        win.focus();
      } else {
        if (info.fromSide === info.targetSide) {
          this.trackingService.trackEvent('klik',
            `Klik doorsturen:${this.side}/tab van:${this.pageId}/widget van:${this.widgetId}/tab naar:${info.pageId}`,
            null, null);
        }

        this.pageNavigationUtil.navigate(info.fromSide, info.targetSide, info.pageId, info.filter, null);
      }
    });
  }

  private getSearchLinkInfo(): Observable<any> {
    // value: waarde die getoond moet worden
    // target: type link (alleen rightSide = tweede scherm is van toepassing)
    // filter: pathkeys voor link naar tweede scherm (ontbrekende pathkeys worden aangevuld met huidige pathkeys)
    // pageId: pagina voor link naar tweede scherm
    const pageId = this.value.page != undefined ? this.value.page : this.pageId;
    const filter = this.value.filter != undefined ? this.value.filter : {};
    const domainId: string = this.domainId;
    const filterKeys: string[] = Object.keys(filter);
    const type: string = filterKeys && filterKeys.length > 0 ? filterKeys[0] : '';
    const subjectNr: string = filter && filter[type] ? filter[type] : '';

    return this.subjectService.getSubjects(domainId, type, subjectNr)
      .pipe(
        this.unsubscriber.takeUntilForUnsubscribe,
        mergeMap((subjects: Subject[]) => {
          if (subjects && subjects.length === 1) {
            const subject = subjects[0];
            const modelKeys: string[] = Object.keys(subject.model);
            modelKeys.forEach(key => filter[key] = subject.model[key]);

            return of({
              external: false,
              fromSide: this.side,
              targetSide: 'right',
              pageId: pageId,
              filter: filter
            });
          } else {
            return throwError(`Bij het gebruik van een SearchLink voor ${type} ${subjectNr} is er geen of meer ` +
              `dan 1 zoekresultaat. Hierdoor kan niet worden bepaald met welk zoekresultaat gewerkt moet worden.`);
          }
        })
      );
  }

  // TODO: Improve error handling
  private followSearchLink(): void {
    this.getSearchLinkInfo().subscribe(
      info => {
        this.pageNavigationUtil.navigate(info.fromSide, info.targetSide, info.pageId, info.filter, null);
      }, error => {
        console.log('Bij het gebruik van een SearchLink is de volgende fout opgetreden:');
        console.log(error);
      });
  }

  public isBaseType(): boolean {
    return this.dataTypeService.isBaseType(this.type);
  }

  public isSpecifiedType(): boolean {
    return this.dataTypeService.isSpecifiedType(this.type);
  }

  public isDrillDownType(): boolean {
    return this.dataTypeService.isDrillDownType(this.type);
  }

  public isPageLinkType(): boolean {
    return this.dataTypeService.isPageLinkType(this.type);
  }

  public isSearchLinkType(): boolean {
    return this.dataTypeService.isSearchLinkType(this.type);
  }

  public isAnnotatedType(): boolean {
    return this.dataTypeService.isAnnotatedType(this.type);
  }

  public isFootnotedType(): boolean {
    return this.dataTypeService.isFootnotedType(this.type);
  }

  public isTrendType(): boolean {
    return this.dataTypeService.isTrendType(this.type);
  }

  public isDeltaType(): boolean {
    return this.dataTypeService.isDeltaType(this.type);
  }

  public isFileLinkType(): boolean {
    return this.dataTypeService.isFileLinkType(this.type);
  }

  public isScrollLinkType(): boolean {
    return this.dataTypeService.isScrollLinkType(this.type);
  }

  public hasDrillDown(): boolean {
    return this.isDrillDownType() && this.value.detail;
  }

  public hasValue(): boolean {
    const value = this.getValue();
    return value != null && value !== '';
  }

  public hasPageLink(): boolean {
    return this.isPageLinkType() && this.value && this.value.value && this.value.target && this.value.target !== 'none';
  }

  public hasSearchLink(): boolean {
    return this.isSearchLinkType() && this.value && this.value.value && this.value.target && this.value.target !== 'none';
  }

  public hasAnnotation(): boolean {
    return this.isAnnotatedType() && this.value.Tooltip;
  }

  public hasFileLink(): boolean {
    return this.isFileLinkType() && this.value && this.value.url;
  }

  public hasScrollLink(): boolean {
    return this.isScrollLinkType() && this.value.widget;
  }

  public hasClickEvent(): boolean {
    return this.hasDrillDown() || this.hasPageLink() || this.hasSearchLink() || this.hasFileLink() || this.hasScrollLink();
  }

  public getDetailsPage(): string {
    return this.value.detail;
  }

  public getDetailsFilter(): any {
    return this.value.filter;
  }

  public getAnnotation(): string {
    return this.value.Tooltip;
  }

  public getFootnote(): string {
    return this.value.footnote;
  }

  public getDelta(): string {
    return this.value.delta;
  }

  public getTrendIcon(): string {
    const value = this.value.hasOwnProperty('revision') ? this.value.revision : this.value.Correctie;
    return (value === 1 || value === '1' || value === 'J') ? 'trendicon bd_lens' : '';
  }
}
