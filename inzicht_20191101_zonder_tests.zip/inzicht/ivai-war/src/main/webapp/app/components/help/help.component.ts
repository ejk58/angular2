import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import * as fromSelectors from '../../store/selectors';
import {Store} from '@ngrx/store';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {Unsubscriber} from '../../commons/unsubscriber';
import {Domain} from '../domain/domain';

@Component({
  selector: 'i-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss'],
  providers: [Unsubscriber]
})
export class HelpComponent implements OnInit, OnDestroy {

  @Input() helpTexts: any;

  public activeTab: number = 0;
  public activeDomain: Domain;
  public modalState: string;

  constructor(private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName('left', 'getActiveDomain');
    this.store.select(fromSelectors[indicatedDomainSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeDomain => this.activeDomain = activeDomain);

    this.store.select(fromSelectors.getModalWrapperState)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(modalState => this.modalState = modalState);
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  selectTab(tab: number) {
    this.activeTab = tab;
  }
}
