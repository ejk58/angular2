import {Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild} from '@angular/core';
import {NgForm} from '@angular/forms';

import {Store} from '@ngrx/store';

import {BehaviorSubject, ConnectableObservable, EMPTY, Observable, Subject} from 'rxjs';
import {publishReplay, switchMap, tap} from 'rxjs/operators';

import {TrackingService} from '../../services/tracking.service';
import {FeedbackService} from '../../services/feedback.service';

import * as storeActions from '../../store/actions';
import * as fromSelectors from '../../store/selectors';
import {RouterStateUrl} from '../../store/reducers';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss'],
  providers: [FeedbackService, Unsubscriber]
})
export class FeedbackComponent implements OnChanges, OnInit, OnDestroy {

  @ViewChild('feedbackForm', { static: false }) formCtrl: NgForm;

  @Input() public engaged: boolean = false;
  private readonly engaged$ = new BehaviorSubject<boolean>(this.engaged);

  public formIsSubmitted: Subject<any> = new Subject();
  public submittedSuccesfully: boolean = false;
  public serverErrorOccurred: boolean = false;
  public serverErrorStatus: number;

  public formModal: {
    message?: string;
    feedbackScope?: string;
    feedBackTopic?: string;
  } = {};

  public feedbackScopeList: string[];
  public feedbackTopicList: string[];

  public displayWidgetDropdown: boolean;
  public widgetDropdownOptions: string[];

  private readonly option1PageLeft: string = `Pagina links`;
  private option2SpecificPart: string;
  private readonly option3PageRight: string = `Pagina rechts`;
  private readonly option4SpecificPartRight: string = `Een specifiek onderdeel op de pagina rechts`;
  private readonly option5AllPages: string = `Alle pagina's`;

  private selectedWidgetScope: string;
  private selectedScope: string;

  private activeScreens: any;
  private activeSide: any;

  private activeLeftPageId: string;
  private activeLeftDomainId: string;
  private activeRightPageId: string;
  private activeRightDomainId: string;
  private selectedPageId: string;
  private selectedDomainId: string;
  private activeUrlState: string;

  constructor(private readonly feedbackService: FeedbackService,
              private readonly trackingService: TrackingService,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) {}

  ngOnInit() {
    // static feedBackTopic list
    this.feedbackTopicList = [
      'De getoonde gegevens zijn onjuist, onvolledig of niet actueel.',
      'De snelheid waarmee de applicatie reageert of foutmeldingen die in beeld verschijnen.',
      'Onderdelen van de applicatie of velden die verwarring oproepen.',
      'Gebruikersgemak.',
      'Overige wensen.'
    ];

    // listen to changes in the route, an re-initialize options
    const routerStateSource$: Observable<RouterStateUrl> = this.store.select(fromSelectors.getRouterState);
    const connectableRouterStateSource$ = routerStateSource$.pipe(
      publishReplay(1)
    ) as ConnectableObservable<RouterStateUrl>;

    const routerState$ = this.engaged$.pipe(
      tap(engaged => {
        if (this.submittedSuccesfully && !engaged) {
          this.reset();
        }
      }),
      switchMap(engaged => engaged ? connectableRouterStateSource$ : EMPTY)
    );

    routerState$
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(routerState => {
        this.activeUrlState = routerState.url;
        this.activeScreens = routerState.routerSidesParams;

        // Don't display feedbackScope options if there is no selected Domain
        if (this.displayScopeList()) {
          this.activeLeftPageId = this.activeScreens.left.pageId;
          this.activeLeftDomainId = this.activeScreens.left.domainId;
        }

        if (this.activeScreens.right) {
          this.activeRightPageId = this.activeScreens.right.pageId;
          this.activeRightDomainId = this.activeScreens.right.domainId;

          this.option2SpecificPart = `Een specifiek onderdeel op de pagina links`;

          this.feedbackScopeList = [
            this.option1PageLeft, this.option2SpecificPart, this.option3PageRight, this.option4SpecificPartRight, this.option5AllPages
          ];

        } else {
          this.option2SpecificPart = `Een specifiek onderdeel op de pagina`;

          this.feedbackScopeList = [
            'Deze pagina (als geheel)',
            this.option2SpecificPart,
            this.option5AllPages
          ];
        }

      // renew dropdown options if you have selected it
      if (this.scopeIsRelevantForWidgetDropdown(this.formModal.feedbackScope)) {
        const pageId = this.formModal.feedbackScope === this.option2SpecificPart ? this.activeLeftPageId : this.activeRightPageId;
        this.getWidgetDropdownOptionsForPage(pageId);
      }
    });

    connectableRouterStateSource$.connect();
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (typeof changes.engaged !== 'undefined') {
      this.engaged$.next(changes.engaged.currentValue);
    }
  }

  public displayScopeList(): boolean {
    if (this.activeScreens) {
      const keys: string[] = Object.keys(this.activeScreens);
      return keys.length > 0 && keys.every(k => typeof this.activeScreens[k] !== 'undefined');
    } else {
      return false;
    }
  }

  public selectScope(selectedScope: string): void {
    if (this.scopeIsRelevantForWidgetDropdown(selectedScope)) {
      this.displayWidgetDropdown = true;

      if (selectedScope === this.option2SpecificPart) {
        this.activeSide = this.activeScreens.left;
        this.selectedPageId = this.activeLeftPageId;
        this.selectedDomainId = this.activeLeftDomainId;
        this.selectedScope = this.activeLeftPageId;

      } else if (selectedScope === this.option4SpecificPartRight) {
        this.activeSide = this.activeScreens.right;
        this.selectedPageId = this.activeRightPageId;
        this.selectedDomainId = this.activeRightDomainId;
        this.selectedScope = this.activeRightPageId;
      }
      this.getWidgetDropdownOptionsForPage(this.selectedPageId);
    } else {
      this.displayWidgetDropdown = false;
      this.selectedWidgetScope = null; // forget widget selection

      this.selectedPageId = this.activeLeftPageId;
      this.selectedDomainId = this.activeLeftDomainId;
      this.selectedScope = this.activeLeftPageId;
      this.activeSide = this.activeScreens.left;

      if (selectedScope === this.option5AllPages) {
        this.selectedScope = this.option5AllPages;
        this.selectedDomainId = null;
      }

      if (selectedScope === this.option3PageRight) {
        this.selectedScope = this.activeRightPageId;
        this.selectedDomainId = this.activeRightDomainId;
      }
    }
  }

  public selectWidgetScope(selectOpt?: string): void {
    this.selectedWidgetScope = selectOpt;
  }

  public isDropdownValid(): boolean {
    if (this.displayWidgetDropdown) {
      return this.selectedWidgetScope ? true : false;
    }
    return true;
  }

  public onSubmit(): void {
    this.formIsSubmitted.next(true);
    this.trackingService.trackEvent('klik',
      'Klik feedback versturen:' + this.activeSide, null, null);

    if (this.formCtrl.valid && this.isDropdownValid()) {
      const feedback = {
        remark: this.formModal.message,
        scope: this.selectedScope ? this.selectedScope : 'Geen pagina gekozen', // but scope = page
        domainId: this.selectedDomainId ? this.selectedDomainId : 'Geen klantbeeld gekozen',
        url: this.activeUrlState,
        topic: this.formModal.feedBackTopic,
        widget: this.selectedWidgetScope,
        subjectNr: this.activeSide && this.activeSide.subjectNr ? this.activeSide.subjectNr : null
      };

      this.feedbackService.sendFeedback(feedback)
        .pipe(this.unsubscriber.takeUntilForUnsubscribe)
        .subscribe(
          res => {
            this.submittedSuccesfully = true;
            this.serverErrorOccurred = false;
          },
          err => {
            this.submittedSuccesfully = false;
            this.serverErrorOccurred = true;
            this.serverErrorStatus = err.status;
          });
    }
  }

  public cancelFeedbackForm(): void {
    this.store.dispatch(new storeActions.ModalClose());
    this.reset();
    this.formCtrl.resetForm();
  }

  public sanitizeSelector(selector: string): string {
    if (selector == null || selector.length === 0) {
      return selector;
    } else {
      return selector.replace(/\s/g, '');
    }
  }

  private scopeIsRelevantForWidgetDropdown(feedbackScope: string): boolean {
    return feedbackScope !== undefined && (feedbackScope === this.option2SpecificPart || feedbackScope === this.option4SpecificPartRight);
  }

  private getWidgetDropdownOptionsForPage(pageId: string): void {
    this.feedbackService.getWidgetNames(pageId)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(res => this.widgetDropdownOptions = res.widgets);
  }

  private reset(): void {
    this.submittedSuccesfully = false;
    this.serverErrorOccurred = false;
    this.serverErrorStatus = undefined;
    this.formModal = {};
  }
}
