import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import * as fromSelectors from '../../store/selectors';
import * as storeActions from '../../store/actions';
import {Subject} from '../../classes/subject';
import {first} from 'rxjs/operators';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-relation',
  templateUrl: './relation.component.html',
  styleUrls: ['./relation.component.scss'],
  providers: [Unsubscriber]
})
export class RelationComponent implements OnInit, OnDestroy {

  @Input() side: any;
  @Output() selected: EventEmitter<boolean> = new EventEmitter<boolean>();

  public relations: any;
  public filterValue: string;
  public params: any;
  public selectedSubject: Subject;

  public loading: boolean;
  public errorMessage: string;

  constructor(private readonly router: Router,
              private readonly store: Store<any>,
              private readonly pageNavigationService: PageNavigationUtilService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly unsubscriber: Unsubscriber) {}

  ngOnInit() {
    this.loading = true;
    this.errorMessage = null;
    this.filterValue = '';

    const indicatedRelationsSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRelations');
    this.relations = this.store.select(fromSelectors[indicatedRelationsSelector]);

    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeSubject => this.selectedSubject = activeSubject);

    this.store.select(fromSelectors.getRouterSides)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(routerSides => {
        if (this.side && routerSides && routerSides[this.side]) {
          this.params = routerSides[this.side];
        }
      });
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  // TODO: dispatching RelationSelected actions is possibly redundant. Maybe it is better to dispatch SelectDomainWithSubject directly.
  public switchToRelation(relation: any): void {
    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getActiveDomain');
    this.store.select(fromSelectors[indicatedDomainSelector]).pipe(first()).subscribe(activeDomain => {
      this.store.dispatch(new storeActions.RelationSelected({
        side: this.side,
        domain: activeDomain,
        params: this.params,
        relation
      }));
    });
  }
}



