import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Store} from '@ngrx/store';
import {Idle} from '@ng-idle/core';
import {PageTitleService} from '../../services/page-title.service';
import * as storeActions from '../../store/actions';
import {AuthenticationService} from '../../services/authentication.service';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [Unsubscriber]
})
export class LoginComponent implements OnInit, OnDestroy {
  public model: any = {};
  public loading = false;
  public loginError: string;
  public user: string;
  public roles: any;

  userform: FormGroup;

  constructor(private readonly router: Router,
              private readonly fb: FormBuilder,
              private readonly idle: Idle,
              private readonly authenticationService: AuthenticationService,
              private readonly route: ActivatedRoute,
              private readonly pageTitleService: PageTitleService,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    // Reset the app state if logged-out
    this.pageTitleService.reset();
    this.store.dispatch(new storeActions.DomainReset());
    this.store.dispatch(new storeActions.HeaderReset());
    this.store.dispatch(new storeActions.SubjectReset());

    this.authenticationService.sendUserName(null);
    this.userform = this.fb.group({
      'username': new FormControl('', Validators.required),
      'password': new FormControl('', Validators.required)
    });
    if (!this.authenticationService.triedSso()) {
      this.ssoLogin();
    }
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  login() {
    this.loading = true;
    this.authenticationService.login(this.model.username, this.model.password)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(
        data => {
          this.user = data['username'];
          this.roles = data['role'];
          this.authenticationService.sendUserName(this.user);
          this.goNext();
        },
        error => {
          if (error.status === 401) {
            this.loginError = 'Geen geldige inloggegevens opgegeven';
          } else if (error.status === 403) {
            this.loginError = 'Geen geldige inloggegevens opgegeven';
          } else {
            this.loginError = `Onbekende fout bij het inloggen. Foutcode:${error.status}`;
          }
          this.loading = false;
        });
  }

  ssoLogin() {
    this.authenticationService.sso()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(
        data => {
          this.user = data['username'];
          this.roles = data['role'];
          this.goNext();
        },
        error => {
          this.loginError = 'Geen SSO login mogelijk';
        });
  }

  private goNext() {
    sessionStorage.setItem('username', this.user);
    sessionStorage.setItem('roles', this.roles);
    sessionStorage.removeItem('user_has_logged_out');
    let redirect = '/main';
    if (this.route.snapshot.queryParamMap.has('redirect')) {
      redirect = '/' + this.route.snapshot.queryParamMap.get('redirect');
    }
    this.idle.watch();
    this.router.navigateByUrl(redirect);
  }

  clearFormError() {
    this.loginError = null;
  }
}
