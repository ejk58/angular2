export interface Page {
  key: string;
  type: 'main' | 'detail';
  title: string;
  rows: Array<any>;
  mandatoryPathKeys: string[];
  globalFilterWidget?: string;
  headerWidget?: string;
  label?: string;
}
