import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

import { Notification } from '../../classes/notification';

@Component({
  selector: 'i-notification-list',
  templateUrl: './notification-list.component.html'
})
export class NotificationListComponent implements OnChanges {

  @Input() public domainId: string;
  @Input() public pageId: string;

  public notifications$: Observable<Notification[]>;

  constructor(
    private readonly http: HttpClient
  ) { }

  ngOnChanges(changes: SimpleChanges): void {
    this.notifications$ = of([]);
    this.getNotifications();
  }

  private getNotifications(): void {
    if (this.pageId && this.domainId) {
      this.notifications$ = this.http.get<Notification[]>(`rest/notification?domainId=${this.domainId}&pageId=${this.pageId}`, { withCredentials: true });
    }
  }
}
