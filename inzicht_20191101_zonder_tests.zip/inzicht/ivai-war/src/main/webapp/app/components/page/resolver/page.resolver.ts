import {Injectable} from '@angular/core';
import {Params, Resolve} from '@angular/router';
import {Store} from '@ngrx/store';
import {first} from 'rxjs/operators';
import * as storeActions from '../../../store/actions';
import * as fromSelectors from '../../../store/selectors';
import {PathKey} from '../../../classes/path-key';
import {RouterSidesParams, RouterStateUrl} from '../../../store/reducers';
import {Domain} from '../../domain/domain';

@Injectable()
export class PageResolver implements Resolve<void> {

  private routerStateSelector = this.store.select(fromSelectors.getRouterState);
  private domainSelector = this.store.select(fromSelectors.getDomainState);
  private previousRouterState: RouterStateUrl;

  constructor(private readonly store: Store<any>) { }

  updatePageConfig(side: string, domainId: string) {
    // Load page config and menu on url navigation
    this.store.dispatch(new storeActions.LoadPage({side, domainId}));

    // Update header activeMenu / close on domain select
    this.store.dispatch(new storeActions.HeaderSelectMenu({ side, menu: 'none' }));
  }

  private updateSelectedDomain(side: string, domain: Domain) {
    this.store.dispatch(new storeActions.LoadActiveDomain({ side, domain: domain }));
    this.store.dispatch(new storeActions.LoadSelectedDomain({ side, domain: domain }));
  }

  updateSubject(side: string, domain: Domain, subjectModel: Object) {
    this.store.dispatch(new storeActions.SubjectLoadSelectedSubject({ side, domain: domain, subjectModel }));
  }

  updateRelations(side: string, domainId: string, subjectModel: Object) {
    this.store.dispatch(new storeActions.LoadRelations({ side, domainId, subjectModel }));
  }

  private constructSubjectModel(params: Params, pathKeys: PathKey[]): Object {
    const mandatoryPathKeys: PathKey[] = pathKeys.filter(pathKey => pathKey.mandatory);
    const subjectModel: Object = {};

    mandatoryPathKeys.forEach(pathKey => {
      if (params[pathKey.name]) {
        let parameterValue = params[pathKey.name];
        if (parameterValue === 'null') {
          parameterValue = null;
        } else if (pathKey.type === 'number') {
          parameterValue = Number(parameterValue);
        }
        subjectModel[pathKey.name] = parameterValue;
        // Temporary solution !!! See IVAI-6738 for discussion.
        if (pathKey.type === 'number' && isNaN(parameterValue)) {
          delete subjectModel[pathKey.name];
        }
      }
    });

    return subjectModel;
  }

  resolve(): void {
    // TODO:  Concat the subscriptions to avoid nested statements
    this.routerStateSelector
      .pipe(first())
      .subscribe(routerState => {
        const loadedDomainId: string = routerState.params.domainId;
        const routerSidesParams: RouterSidesParams = routerState.routerSidesParams;

        this.domainSelector
          .pipe(first(domainState => domainState.menuItems && domainState.menuItems.length > 0))
          .subscribe(domainState => {
            Object.keys(routerSidesParams).forEach(side => {
              const previousSideParams: Params = this.previousRouterState ? this.previousRouterState.routerSidesParams[side] : null;
              const activeSideParams: Params = routerSidesParams[side];
              const activeDomain: Domain = domainState.menuItems.find(domain => domain.domainId === activeSideParams.domainId);
              const subjectModel: Object = this.constructSubjectModel(activeSideParams, activeDomain.pathKeys);

              this.updateSelectedDomain(side, activeDomain);
              if (Object.keys(subjectModel).length > 0) {
                this.updateSubject(side, activeDomain, subjectModel);
              }

              if (loadedDomainId) {
                const paramsChanged = JSON.stringify(previousSideParams) !== JSON.stringify(activeSideParams);
                if (paramsChanged) {
                  this.updateRelations(side, activeSideParams.domainId, subjectModel);
                }

                if (domainState[side].active === null) {
                  this.updatePageConfig(side, activeSideParams.domainId);
                }
              }
            });
            // NOTE: set the previous state at the end of the inner sub
            this.previousRouterState = routerState;
          });
      });
  }
}
