import {Component, ElementRef, Input, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {D3, D3Service, Selection} from 'd3-ng2-service';
import {Column} from '../../classes/column';

@Component({
  selector: 'i-sparkline',
  templateUrl: './sparkline.component.html',
  styleUrls: ['./sparkline.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SparklineComponent implements OnInit {

  private static readonly defaultSparklineWidth: number = 80;
  private static readonly defaultSparklineHeight: number = 32;

  @Input() row: any;
  @Input() col: Column;
  @ViewChild('sparklineCanvas', { static: true }) canvasElementRef: ElementRef;

  private readonly d3: D3;
  private canvas: Selection<any, any, any, any>;
  private graph: Selection<any, any, any, any>;

  private sparklineWidth: number = SparklineComponent.defaultSparklineWidth;
  private readonly sparklineHeight: number = SparklineComponent.defaultSparklineHeight;
  private readonly sparklineData: { x: number, y: number }[] = [];

  constructor(private readonly d3Service: D3Service) {
    this.d3 = d3Service.getD3();
  }

  ngOnInit() {
    this.convertToStandardScale(this.row['sparkline']);
    const widthType: string = this.col.width;
    if (widthType.substr(-2) === 'px') {
      this.sparklineWidth = parseInt(widthType, 10);
    }
    this.drawCanvas();
    this.drawSparkline(this.graph);
  }

  private convertToStandardScale(sparkline) {
    for (const sparklineKey in sparkline.sparklineValues) {
      const index: number = parseInt(sparklineKey.match(/\d/g)[0]);
      const linePoint = {
        x: index,
        y: sparkline.sparklineValues[sparklineKey]
      };
      this.sparklineData[index - 1] = linePoint;
    }
  }

  private drawCanvas(): void {
    this.canvas = this.d3.select(this.canvasElementRef.nativeElement)
      .append('svg')
      .attr('preserveAspectRatio', 'xMinYMin meet')
      .attr('viewBox', `0 0 ${this.sparklineWidth} ${this.sparklineHeight}`)
      .style('width', this.sparklineWidth + 'px')
      .style('height', this.sparklineHeight + 'px');
    this.graph = this.canvas.append('g');
  }

  private drawSparkline(graph: Selection<any, any, any, any>): void {
    const scaleX = this.d3.scaleLinear().domain([1, this.sparklineData.length]).range([0, this.sparklineWidth]);
    const scaleY = this.d3.scaleLinear().domain([this.row['sparkline'].minValue, this.row['sparkline'].maxValue]).range([this.sparklineHeight, 0]);
    let startPoint = null;
    this.sparklineData.forEach((point, index) => {
      if (point.y != null) {
        if (startPoint === null) {
          startPoint = point;
        } else {
          const endPoint = point;
          graph.append('line')
            .attr('x1', scaleX(startPoint.x))
            .attr('y1', scaleY(startPoint.y))
            .attr('x2', scaleX(endPoint.x))
            .attr('y2', scaleY(endPoint.y))
            .attr('stroke-dasharray', (endPoint.x - startPoint.x > 1) ? '2,2' : '2,0')
            .attr('class', 'sparkline');
          startPoint = endPoint;
        }
      }
    });
  }

}

