import {Component, OnInit} from '@angular/core';
import {DEFAULT_INTERRUPTSOURCES, Idle} from '@ng-idle/core';
import {AuthenticationService} from './services/authentication.service';
import {environment} from '../environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {

  public title = 'Inzicht';
  svg_path = environment.svg_path;
  public username: any;
  public readonly sessionInactivityTimeInSeconds = 36000;

  constructor(private readonly auth: AuthenticationService, idle: Idle) {
    idle.setIdle(this.sessionInactivityTimeInSeconds);
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    idle.onTimeout.subscribe(() => this.auth.logout());

    this.auth.getUserName().subscribe(userName => {
      if (userName) {
        this.username = userName.text;
      }
    });
  }

  ngOnInit() {
    this.auth.sendUserName(null);
  }

}
