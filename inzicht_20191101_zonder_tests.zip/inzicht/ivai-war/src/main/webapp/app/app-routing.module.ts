import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoggedInGuard} from './components/login/logged-in.guard';
import {BdStylesheetComponent} from './components/bd-stylesheet/bd-stylesheet.component';

import {LoginComponent} from './components/login/login.component';
import {PageComponent} from './components/page/page.component';
import {MainComponent} from './components/main/main.component';

import {DomainResolver} from './components/domain/resolver/domain.resolver';
import {PageResolver} from './components/page/resolver/page.resolver';
import {SystemResolver} from './components/main/resolver/system.resolver';

const routes: Routes = [
  { path: 'style', component: BdStylesheetComponent },

  { path: 'login', component: LoginComponent },
  {
    path: 'main',
    component: MainComponent,
    canActivate: [LoggedInGuard],
    resolve: { DomainResolver, SystemResolver },
    children: [
      {
        path: ':domainId/:pageId',
        component: PageComponent,
        canActivate: [LoggedInGuard],
        resolve: { PageResolver },
        outlet: 'left'
      },
      {
        path: ':domainId/:pageId',
        component: PageComponent,
        canActivate: [LoggedInGuard],
        resolve: { PageResolver },
        outlet: 'right'
      }
    ]
  },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, enableTracing: false })],
  exports: [RouterModule],
  providers: [DomainResolver, PageResolver, SystemResolver]
})
export class InzichtRoutingModule { }
