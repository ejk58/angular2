import {Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation} from '@angular/core';

import {Node} from '../../../classes/nodes/node';
import {NodeSubjectPresentation} from '../../../classes/nodes/node-subject-presentation';

import {Group} from '../model/group';

type Item = {
  label: string,
  value: string
};

type SelectList = {
  groupType: number,
  selectedItems: string[],
  defaultLabel?: string,
  disabled?: boolean,
  items?: Item[]
};

@Component({
  selector: 'i-enterprise-graph-filter',
  templateUrl: './enterprise-graph-filter.component.html',
  styleUrls: ['./enterprise-graph-filter.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EnterpriseGraphFilterComponent implements OnInit {
  @Input() groups: Group[];
  @Input() maxNumberOfSelections: number;
  @Output() selectionChange = new EventEmitter<SelectList>();

  public selectLists: SelectList[] = [];
  public currentSelectedGroup: number;

  ngOnInit(): void {
    if (this.groups) {
      this.initializeGroups();
    }
  }

  public emitSelectedValues(selectList: SelectList): void {
    if (!selectList.disabled) {
      this.currentSelectedGroup = selectList.groupType;
      this.selectionChange.emit({
        groupType: selectList.groupType,
        selectedItems: selectList.selectedItems
      });
    }
  }

  protected initializeGroups(): void {
    this.groups.forEach((group) => {

      const isEnabled = (this.isEntity(group.type) || (group.nodes && group.nodes.length >= 1));
      const items: Item[] = [];
      const selectedItems: string[] = [];

      group.nodes.forEach((node: Node<any, NodeSubjectPresentation>) => {
        const item: Item = {label: node.presentation.name, value: node.id};
        items.push(item);
        if (group.nodes.length <= this.maxNumberOfSelections) {
          selectedItems.push(item.value);
        }
      });

      this.selectLists.push({
        groupType: group.type,
        defaultLabel: group.name,
        disabled: !isEnabled,
        items: items,
        selectedItems: selectedItems
      });
    });
  }

  protected isEntity(groupType: number): boolean {
    return groupType === null || groupType === 0;
  }
}
