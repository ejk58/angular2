import {Component, OnInit} from '@angular/core';
import {CollapsibleTableComponent} from '../collapsible-table/collapsible-table.component';
import {Unsubscriber} from '../../commons/unsubscriber';
import * as _ from 'lodash';

type ColumnValueType = number | string | Date;

@Component({
  selector: 'i-flexible-collapsible-table',
  templateUrl: '../collapsible-table/collapsible-table.component.html',
  styleUrls: ['../collapsible-table/collapsible-table.component.scss'],
  providers: [Unsubscriber]
})
export class FlexibleCollapsibleTableComponent extends CollapsibleTableComponent implements OnInit {

  ngOnInit() {
    if (this.widget.data.length > 2) {
      const groupConfig = this.widget.data.shift(); // First data-row contains column-groups
      const labelConfig = this.widget.data.shift(); // Second data-row contains column-labels
      this.setGroupForColumns(groupConfig);
      this.setLabelForColumns(labelConfig);
    }
    super.ngOnInit();
  }

  private setGroupForColumns(groupConfig) {
    const groupKeys = Object.keys(groupConfig);
    groupKeys.forEach(key => {
      if (this.widget.options.columns[key]) {
        const column = this.widget.options.columns[key];
        const valueField: string = this.getFieldForSortOrValue(column);
        const value: ColumnValueType = _.get(groupConfig, valueField);
        if (value != null) {
          column.group = value;
        }
      }
    });
  }

  private setLabelForColumns(labelConfig) {
    const labelKeys = Object.keys(labelConfig);
    labelKeys.forEach(key => {
      if (this.widget.options.columns[key]) {
        const column = this.widget.options.columns[key];
        const valueField: string = this.getFieldForSortOrValue(column);
        const value: ColumnValueType = _.get(labelConfig, valueField);
        if (value != null) {
          column.label = value;
        } else {
          column.behaviour = 'invisible';
        }
      }
    });
  }
}
