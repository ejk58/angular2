import {Link} from '../../../classes/links/link';
import {LinkSubjectType} from '../../../classes/links/link-subject-type';
import {LinkSubjectPresentation} from '../../../classes/links/link-subject-presentation';
import {LinkFactory} from '../../../classes/links/link-factory';
import {Node} from '../../../classes/nodes/node';
import {NodeSubjectPresentation} from '../../../classes/nodes/node-subject-presentation';

import {NodeType} from './node-type';
import {LinkDirection} from './link-direction';
import {LinkHierarchicalModel} from './link-hierarchical-model';
import {NodeHierarchicalModel} from './node-hierarchical-model';

export class HierarchicalSubjectLinkFactory implements LinkFactory<Node<NodeHierarchicalModel, NodeSubjectPresentation>, LinkHierarchicalModel, LinkSubjectPresentation> {

  private static readonly linkMap: Map<number, {reversedType: number, direction: number, weight: number, visible: boolean}> = new Map([
    [LinkSubjectType.Zelf, {reversedType: LinkSubjectType.Zelf, 'direction': LinkDirection.self, 'weight': 0, 'visible': true}],
    [LinkSubjectType.FiscaalPartner, {reversedType: LinkSubjectType.FiscaalPartner, 'direction': LinkDirection.sibling, 'weight': 20, 'visible': true}],
    [LinkSubjectType.VoorlopigFiscaalPartner, {reversedType: LinkSubjectType.VoorlopigFiscaalPartner, 'direction': LinkDirection.sibling, 'weight': 20, 'visible': true}],
    [LinkSubjectType.Kind, {reversedType: LinkSubjectType.Ouder, 'direction': LinkDirection.parent, 'weight': 2, 'visible': true}],
    [LinkSubjectType.Ouder, {reversedType: LinkSubjectType.Kind, 'direction': LinkDirection.child, 'weight': 2, 'visible': true}],
    [LinkSubjectType.Gehuwd, {reversedType: LinkSubjectType.GehuwdMet, 'direction': LinkDirection.sibling, 'weight': 10, 'visible': false}],
    [LinkSubjectType.GehuwdMet, {reversedType: LinkSubjectType.Gehuwd, 'direction': LinkDirection.sibling, 'weight': 10, 'visible': false}],
    [LinkSubjectType.Samenwonend, {reversedType: LinkSubjectType.SamenwonendMet, 'direction': LinkDirection.sibling, 'weight': 10, 'visible': false}],
    [LinkSubjectType.SamenwonendMet, {reversedType: LinkSubjectType.Samenwonend, 'direction': LinkDirection.sibling, 'weight': 10, 'visible': false}],
    [LinkSubjectType.ExPartnerGehuwd, {reversedType: LinkSubjectType.ExPartnerGehuwd, 'direction': LinkDirection.sibling, 'weight': 5, 'visible': false}],
    [LinkSubjectType.ExPartnerSamenwonend, {reversedType: LinkSubjectType.ExPartnerSamenwonend, 'direction': LinkDirection.sibling, 'weight': 5, 'visible': false}],
    [LinkSubjectType.BroerOfZus, {reversedType: LinkSubjectType.BroerOfZus, 'direction': LinkDirection.sibling, 'weight': 1, 'visible': true}],
    [LinkSubjectType.FirmantDeelnemer, {reversedType: LinkSubjectType.HeeftFirmantDeelnemer, 'direction': LinkDirection.child, 'weight': 2, 'visible': true}],
    [LinkSubjectType.HeeftFirmantDeelnemer, {reversedType: LinkSubjectType.FirmantDeelnemer, 'direction': LinkDirection.parent, 'weight': 2, 'visible': true}],
    [LinkSubjectType.Bestuurder, {reversedType: LinkSubjectType.HeeftBestuurder, 'direction': LinkDirection.child, 'weight': 2, 'visible': true}],
    [LinkSubjectType.HeeftBestuurder, {reversedType: LinkSubjectType.Bestuurder, 'direction': LinkDirection.parent, 'weight': 2, 'visible': true}],
    [LinkSubjectType.Aandeelhouder, {reversedType: LinkSubjectType.HeeftAandeelhouder, 'direction': LinkDirection.child, 'weight': 2, 'visible': true}],
    [LinkSubjectType.HeeftAandeelhouder, {reversedType: LinkSubjectType.Aandeelhouder, 'direction': LinkDirection.parent, 'weight': 2, 'visible': true}],
    [LinkSubjectType.ObFiscaleEenheid, {reversedType: LinkSubjectType.OnderObFiscaleEenheid, 'direction': LinkDirection.group, 'weight': 1, 'visible': false}],
    [LinkSubjectType.OnderObFiscaleEenheid, {reversedType: LinkSubjectType.ObFiscaleEenheid, 'direction': LinkDirection.group, 'weight': 1, 'visible': false}],
    [LinkSubjectType.VpbFiscaleEenheid, {reversedType: LinkSubjectType.OnderVpbFiscaleEenheid, 'direction': LinkDirection.group, 'weight': 1, 'visible': false}],
    [LinkSubjectType.OnderVpbFiscaleEenheid, {reversedType: LinkSubjectType.VpbFiscaleEenheid, 'direction': LinkDirection.group, 'weight': 1, 'visible': false}],
    [LinkSubjectType.ZelfdeAdres, {reversedType: LinkSubjectType.ZelfdeAdres, 'direction': LinkDirection.sibling, 'weight': 0, 'visible': false}],
    [LinkSubjectType.HeeftMeerRelaties, {reversedType: LinkSubjectType.MeerRelaties, 'direction': LinkDirection.parent, 'weight': 3, 'visible': true}],
    [LinkSubjectType.MeerRelaties, {reversedType: LinkSubjectType.HeeftMeerRelaties, 'direction': LinkDirection.child, 'weight': 3, 'visible': true}],
    [LinkSubjectType.OnbekendeRelatie, {reversedType: LinkSubjectType.OnbekendeRelatie, 'direction': LinkDirection.child, 'weight': 0, 'visible': true}]
  ]);

  public build(source: Node<NodeHierarchicalModel, NodeSubjectPresentation>, target: Node<NodeHierarchicalModel, NodeSubjectPresentation>, row: any):
        Link<Node<NodeHierarchicalModel, NodeSubjectPresentation>, LinkHierarchicalModel, LinkSubjectPresentation> {

    const behaviour = this.getBehaviour(source, target, row);
    const model = this.buildModel(row, behaviour);
    const presentation = this.buildPresentation(row);
    const link = this.buildLink(source, target, row, model, presentation);

    this.connectLink(link);

    return link;
  }

  private buildLink(source: Node<NodeHierarchicalModel, NodeSubjectPresentation>, target: Node<NodeHierarchicalModel, NodeSubjectPresentation>, row: any, model: LinkHierarchicalModel, presentation: LinkSubjectPresentation):
        Link<Node<NodeHierarchicalModel, NodeSubjectPresentation>, LinkHierarchicalModel, LinkSubjectPresentation> {

    const type = this.getType(row);
    const direction = HierarchicalSubjectLinkFactory.linkMap.get(type).direction;

    const link = new Link<Node<NodeHierarchicalModel, NodeSubjectPresentation>, LinkHierarchicalModel, LinkSubjectPresentation>();
    if (direction !== LinkDirection.parent) {
      link.source = source;
      link.target = target;
    } else {
      link.source = target;
      link.target = source;
    }
    link.id = link.source.id + '-' + link.target.id;
    link.model = model;
    link.presentation = presentation;
    link.data = row;
    link.classes = ['link', 'link-id-' + link.id, 'link-id-' + link.source.id, 'link-id-' + link.target.id, 'link-type-' + type, ...this.getAdditionalClasses(row, type)];

    return link;
  }

  private buildModel(row: any, behaviour: NodeType): LinkHierarchicalModel {
    const type = this.getType(row);
    const direction = HierarchicalSubjectLinkFactory.linkMap.get(type).direction;
    const weight = HierarchicalSubjectLinkFactory.linkMap.get(type).weight;

    const model = new LinkHierarchicalModel();
    model.behaviour = behaviour;
    model.direction = direction;
    model.weight = weight;
    model.isUnknownType = type === LinkSubjectType.OnbekendeRelatie;
    model.isBadLink = false;
    model.isVisible = HierarchicalSubjectLinkFactory.linkMap.get(type).visible;
    model.possibleCrossingLinks = [];

    return model;
  }

  private buildPresentation(row: any): LinkSubjectPresentation {
    const type = this.getType(row);
    const direction = HierarchicalSubjectLinkFactory.linkMap.get(type).direction;
    const percentage = row['perc_betrokkenheid'];

    const presentation = new LinkSubjectPresentation();
    presentation.type = (direction !== LinkDirection.parent) ? type : HierarchicalSubjectLinkFactory.linkMap.get(type).reversedType;
    presentation.direction = direction;
    presentation.percentage = percentage;
    presentation.isLabeled = (type === LinkSubjectType.Aandeelhouder || type === LinkSubjectType.HeeftAandeelhouder);
    presentation.isPartnerLink = (type === LinkSubjectType.FiscaalPartner || type === LinkSubjectType.VoorlopigFiscaalPartner);
    presentation.isVisible = HierarchicalSubjectLinkFactory.linkMap.get(type).visible;
    presentation.possibleCrossingLinks = [];

    return presentation;
  }

  private connectLink(link: Link<Node<NodeHierarchicalModel, NodeSubjectPresentation>, LinkHierarchicalModel, LinkSubjectPresentation>) {
    const direction = link.model.direction;
    const source = link.source;
    const target = link.target;

    if (link.model.behaviour === NodeType.node && direction !== LinkDirection.group) {
      if (direction === LinkDirection.sibling) {
        source.model.siblingLinks.push(link);
        target.model.siblingLinks.push(link);
      } else {
        source.model.childLinks.push(link);
        target.model.parentLinks.push(link);
      }
    } else {
      source.model.groupLinks.push(link);
    }

    const type = link.presentation.type;
    this.setRelationOnNode(source, target, type);
    this.setRelationOnNode(target, source, HierarchicalSubjectLinkFactory.linkMap.get(type).reversedType);
  }

  private setRelationOnNode(node: Node<NodeHierarchicalModel, any>, linkedNode: Node<NodeHierarchicalModel, any>, type: number): void {

    if (linkedNode != null && linkedNode.isMain) {
      if (type === LinkSubjectType.FiscaalPartner || type === LinkSubjectType.VoorlopigFiscaalPartner) {
        node.presentation.isFiscalPartner = true;
        node.classes.push('node-fiscaal-partner');
      }

      if (type === LinkSubjectType.Gehuwd || type === LinkSubjectType.GehuwdMet) {
        node.presentation.isMarried = true;
        node.classes.push('node-gehuwd-partner');
      }

      if (type === LinkSubjectType.Samenwonend || type === LinkSubjectType.SamenwonendMet) {
        node.presentation.isLivingTogether = true;
        node.classes.push('node-samenwonend-partner');
      }

      if (type === LinkSubjectType.ExPartnerGehuwd || type === LinkSubjectType.ExPartnerSamenwonend) {
        node.presentation.isExPartner = true;
        node.classes.push('node-ex-partner');
      }

      if (type === LinkSubjectType.Kind) {
        node.presentation.isParent = true;
        node.classes.push('node-ouder');
      }

      if (type === LinkSubjectType.Ouder) {
        node.presentation.isChild = true;
        node.classes.push('node-kind');
      }
    }
  }

  private getBehaviour(source: Node<NodeHierarchicalModel, NodeSubjectPresentation>, target: Node<NodeHierarchicalModel, NodeSubjectPresentation>, row: any): number {
    const type = this.getType(row);

    const isGroupLink = (type === LinkSubjectType.ObFiscaleEenheid || type === LinkSubjectType.OnderObFiscaleEenheid ||
        type === LinkSubjectType.VpbFiscaleEenheid || type === LinkSubjectType.OnderVpbFiscaleEenheid);
    const isConnectedToGroupNode = (source.model.behaviour === NodeType.group || target.model.behaviour === NodeType.group);

    return (isGroupLink || isConnectedToGroupNode) ? NodeType.group : NodeType.node;
  }

  private getType(row: any): number {
    return HierarchicalSubjectLinkFactory.linkMap.has(row['type']) ? row['type'] : LinkSubjectType.OnbekendeRelatie;
  }

  private getAdditionalClasses(row: any, type: number): string[] {
    const classes = [];

    if (type === LinkSubjectType.FiscaalPartner || type === LinkSubjectType.VoorlopigFiscaalPartner) {
      classes.push('link-primary');
    }

    if (type === LinkSubjectType.Kind || type === LinkSubjectType.Ouder || type === LinkSubjectType.BroerOfZus ||
        type === LinkSubjectType.Gehuwd || type === LinkSubjectType.GehuwdMet ||
        type === LinkSubjectType.Samenwonend || type === LinkSubjectType.SamenwonendMet) {
      classes.push('link-straight');
    }

    if (type === LinkSubjectType.FirmantDeelnemer || type === LinkSubjectType.HeeftFirmantDeelnemer ||
        type === LinkSubjectType.Aandeelhouder || type === LinkSubjectType.HeeftAandeelhouder ||
        type === LinkSubjectType.ObFiscaleEenheid || type === LinkSubjectType.OnderObFiscaleEenheid ||
        type === LinkSubjectType.VpbFiscaleEenheid || type === LinkSubjectType.OnderVpbFiscaleEenheid) {
      classes.push('link-smalldash');
    }

    if (type === LinkSubjectType.Bestuurder || type === LinkSubjectType.HeeftBestuurder) {
      classes.push('link-bigdash');
    }

    if (type === LinkSubjectType.MeerRelaties || type === LinkSubjectType.HeeftMeerRelaties) {
      classes.push('link-mixeddash');
    }

    if (!HierarchicalSubjectLinkFactory.linkMap.get(type).visible) {
      classes.push('link-invisible');
    }

    if (type === LinkSubjectType.OnbekendeRelatie) {
      classes.push('link-unknown');
    }

    return classes;
  }
}
