import { Component, Input, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { D3Service, D3 } from 'd3-ng2-service';
import { TrackingService } from '../../services/tracking.service';

@Component({
  selector: 'i-social-graph-legend',
  templateUrl: './social-graph-legend.component.html',
  styleUrls: ['./social-graph-legend.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SocialGraphLegendComponent {

  @Input() widgetId: string;
  @Input() side: string;
  @Input() subjectIsPerson: boolean;

  @ViewChild('socialGraphLegend', { static: true }) legendElementRef: ElementRef;

  private readonly d3: D3;

  private visible: boolean;

  constructor(private readonly d3Service: D3Service, private readonly trackingService: TrackingService) {
    this.d3 = d3Service.getD3();
    this.visible = false;
  }

  public getButtonArrow() {
    return this.visible ? 'bd_keyboard_arrow_up bd-30' : 'bd_keyboard_arrow_down bd-30';
  }

  public toggleLegend(event: any) {
    this.visible = !this.visible;

    if (this.visible) {
      this.trackingService.trackEvent('klik',
        'Klik legenda open:' + this.side + '/widget:' + this.widgetId,
        null, null);

      this.d3.select(this.legendElementRef.nativeElement).style('display', 'block');
    } else {
      this.d3.select(this.legendElementRef.nativeElement).style('display', 'none');
    }
  }
}
