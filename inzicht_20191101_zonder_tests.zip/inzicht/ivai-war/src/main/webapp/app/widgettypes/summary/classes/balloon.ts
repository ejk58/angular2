export class Balloon {

  public left: number = 60;
  public top: number = 40;
  public disabled: boolean = false;

  constructor(public color: BalloonColor, public content: string, public contentType: BalloonContentType) {
  }
}

export enum BalloonColor {
  invisible = 'invisible', normal = 'normal', alert = 'alert'
}

export enum BalloonContentType {
  number = 'number', text = 'text', convenantText = 'convenant-text', label = 'label'
}
