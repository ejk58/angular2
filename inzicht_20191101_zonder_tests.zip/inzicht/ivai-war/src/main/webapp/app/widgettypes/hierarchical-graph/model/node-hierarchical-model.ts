import {Link} from '../../../classes/links/link';
import {Node} from '../../../classes/nodes/node';

import {NodeType} from './node-type';
import {LinkDirection} from './link-direction';
import {LinkHierarchicalModel} from './link-hierarchical-model';

export class NodeHierarchicalModel {

  public x: number;
  public y: number;

  public parentLinks: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>[];
  public childLinks: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>[];
  public siblingLinks: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>[];
  public groupLinks: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>[];
  public loopLinks: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>[];

  public behaviour: NodeType;
  public visible: boolean;
  public level: number;
  public index: number;

  public isPriority: boolean;

  public isConnected(): boolean {
    return this.parentLinks.length > 0 || this.childLinks.length > 0 || this.siblingLinks.length > 0 || this.groupLinks.length > 0 || this.loopLinks.length > 0;
  }

  public addLink(link: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>): void {
    const behaviour = link.model.behaviour;
    const direction = link.model.direction;

    if (behaviour === NodeType.group) {
      this.groupLinks.push(link);
    } else if ((direction === LinkDirection.child && link.source.model === this) || (direction === LinkDirection.parent && link.target.model === this)) {
      this.childLinks.push(link);
    } else if ((direction === LinkDirection.child && link.target.model === this) || (direction === LinkDirection.parent && link.source.model === this)) {
      this.parentLinks.push(link);
    } else if (direction === LinkDirection.sibling) {
      this.siblingLinks.push(link);
    }
  }

  public hideLoopLink(link: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>): void {
    this.parentLinks = this.parentLinks.filter(parentLink => parentLink !== link);
    this.childLinks = this.childLinks.filter(childLink => childLink !== link);
    this.siblingLinks = this.siblingLinks.filter(siblingLink => siblingLink !== link);
    this.loopLinks.push(link);
  }
}
