import { Component, Input } from '@angular/core';

@Component({
  selector: 'i-notification',
  templateUrl: './notification.component.html'
})
export class NotificationComponent {

  @Input() widget: any;

  constructor() { }
}
