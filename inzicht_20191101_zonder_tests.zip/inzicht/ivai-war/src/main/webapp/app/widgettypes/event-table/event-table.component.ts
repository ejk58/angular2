import {Component, OnInit} from '@angular/core';
import {TableComponent} from '../table/table.component';
import {objectFieldsAsArray} from '../../commons/inzicht-functions';

@Component({
  selector: 'i-event-table',
  templateUrl: '../table/table.component.html',
  styleUrls: ['../table/table.component.scss']
})
export class EventTableComponent extends TableComponent implements OnInit {
  private summaryColumns: any[] = [];

  ngOnInit() {
    this.prepareData();
    super.ngOnInit();
  }

  public filterRows(value: any, filterMode: string) {
    super.filterRows(value, filterMode);
    if (this.dt.filters['global']) {
      setTimeout(() => {
        this.filterGroups();
      }, this.dt.filterDelay);
    }
  }

  private filterGroups() {
    let keys: number[] = [];
    if (this.dt.filteredValue && this.dt.filteredValue.length > 0) {
      this.dt.filteredValue.forEach((dataRow) => {
        if (dataRow.parent === null) {
          if (keys.indexOf(dataRow.sleutel) === -1) {
            keys.push(dataRow.sleutel);
          }
        } else {
          if (keys.indexOf(dataRow.parent) === -1) {
            keys.push(dataRow.parent);
          }
        }
      });
    }
    this.dt.filteredValue = this.dt._value.filter((dataRow) => (keys.indexOf(dataRow.sleutel) !== -1) || (keys.indexOf(dataRow.parent) !== -1));
  }

  private prepareData(): void {
    this.identifyAndSortSummaryItems();
    const parentRows = this.widget.data.filter(dataRow => dataRow.parent == null);
    parentRows.forEach(parentRow => {
      this.updateDataRow(parentRow, 0);
      const detailRows = this.getDetailRows(parentRow);
      this.addDetailRowsIfNecessary(detailRows);
      detailRows.forEach((detailRow, index) => {
        this.updateDataRow(detailRow, index + 1);
      });
    });
  }

  private identifyAndSortSummaryItems(): void {
    this.summaryColumns = objectFieldsAsArray(this.widget.options.columns).filter(column => column.summaryColumnItem != null);
    this.summaryColumns.sort((item1, item2) => item1.summaryColumnItem - item2.summaryColumnItem);
  }

  private addDetailRowsIfNecessary(detailRows: any): void {
    for (let i = detailRows.length + 1; i < this.summaryColumns.length; i++) {
      if (detailRows[detailRows.length - 1][this.summaryColumns[i].columnName]) {
        const index = this.widget.data.findIndex(dataRow => dataRow === detailRows[detailRows.length - 1]);
        this.widget.data.splice(index + 1, 0, this.createDummyRow(detailRows));
      }
    }
  }

  private createDummyRow(detailRows: any[]): any {
    const copiedRow = JSON.parse(JSON.stringify(detailRows[detailRows.length - 1]));
    const visibleColumns = objectFieldsAsArray(this.widget.options.columns).filter(column => column.behaviour === 'visible');
    visibleColumns.forEach((column) => {
      if (column.columnType === 'ASSPECIFIED') {
        copiedRow[column.columnName].value = null;
      } else {
        copiedRow[column.columnName] = null;
      }
    });
    detailRows.push(copiedRow);
    return copiedRow;
  }

  private updateDataRow(row: any, index: number): void {
    row.summarycolumn = {
      'Waarde': (index < this.summaryColumns.length) ? row[this.summaryColumns[index].columnName] : null,
      'Meeteenheid': (index < this.summaryColumns.length) ? this.summaryColumns[index].columnType : ''
    };
    row.opmaak = (index === 0) ? 'event-header-row' : 'event-detail-row';
  }

  private getDetailRows(parentRow: any) {
    return this.widget.data.filter(dataRow => dataRow.parent === parentRow.sleutel);
  }

}
