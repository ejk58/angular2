import { DetailItem } from './detail-item';

export class DetailSection {
  public title: string;
  public itemList: DetailItem[] = [];
  public sectionNumber: number;
}
