import {Balloon} from './balloon';

export class Icon {
  public name: string = null;
  public balloons: Balloon[] = [];
  public extraCssClass: string = '';
  public personWithFiscalPartner: boolean = false;
  public imageHeight: number = 140;
  public imageFromFile: boolean = false;

  constructor(name: string) {
    this.name = name;
  }
}
