import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Store} from '@ngrx/store';
import {LegendGroup} from './legend-group';
import {LegendItem} from './legend-item';
import * as fromSelectors from '../../store/selectors';
import {Event, EventService, LegendEvent} from '../../services/event.service';
import {Side} from '../../commons/side';
import {Column} from '../../classes/column';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-legend',
  templateUrl: './legend.component.html',
  styleUrls: ['./legend.component.scss'],
  providers: [Unsubscriber]
})
export class LegendComponent implements OnDestroy, OnInit {

  @Input() side: Side;
  @Input() widgetId: string;
  @Input() widget: any;

  public activeSides: any;
  public params: any;
  public legendGroups: LegendGroup[] = [];

  private hasEventListeners: boolean;

  constructor(private readonly eventService: EventService,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit(): void {
    this.store.select(fromSelectors.getRouterSides)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(routerSides => {
        this.activeSides = routerSides;
        this.params = this.activeSides[this.side];
      });
    this.createLegendGroups();

    this.eventService.hasListeners(this.widget.name, this.side, LegendEvent.enableItem, LegendEvent.disableItem)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(hasListeners => this.hasEventListeners = hasListeners);
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public isInteractive(item: LegendItem): boolean {
    return this.hasEventListeners && item.column.color != null;
  }

  public toggleLegendItem(item: LegendItem): void {
    if (this.isInteractive(item)) {
      const type = item.active ? LegendEvent.disableItem : LegendEvent.enableItem;
      const ev = new Event(type, item.column.label);
      this.eventService.broadcast(this.widget.name, this.side, ev);

      item.active = !item.active;
    }
  }

  private createLegendGroups(): void {
    Object.keys(this.widget.options.columns)
      .filter(column => Column.isVisible(this.widget.options.columns[column].behaviour))
      .forEach(column => {
        const group = this.widget.options.columns[column].group;
        if (group) {
          let legendGroup = this.legendGroups.find(legendGroup => legendGroup.group === group);
          if (!legendGroup) {
            legendGroup = new LegendGroup(group, []);
            this.legendGroups.push(legendGroup);
          }
          this.addItemsToLegendGroup(legendGroup, column);
        }
      });
  }

  private addItemsToLegendGroup(legendGroup, column) {
    this.widget.data.forEach(row => {
      legendGroup.items.push(new LegendItem(row, this.widget.options.columns[column]));
    });
  }
}
