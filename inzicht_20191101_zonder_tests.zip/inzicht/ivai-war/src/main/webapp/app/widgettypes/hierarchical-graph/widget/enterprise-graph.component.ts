import {Component, Input, OnInit, AfterViewInit, ViewChild, ElementRef, ViewEncapsulation} from '@angular/core';
import {D3Service, Selection} from 'd3-ng2-service';
import {PageNavigationUtilService} from '../../../commons/page-navigation-util.service';
import {SubjectIconProvider} from '../../../commons/subject-icon-provider';

import {Node} from '../../../classes/nodes/node';
import {NodePainter} from '../../../classes/nodes/node-painter';
import {NodeSubjectPainter} from '../../../classes/nodes/node-subject-painter';
import {NodeGroupPainter} from '../../../classes/nodes/node-group-painter';
import {NodeSubjectPresentation} from '../../../classes/nodes/node-subject-presentation';
import {LinkSubjectType} from '../../../classes/links/link-subject-type';
import {LinkSubjectPresentation} from '../../../classes/links/link-subject-presentation';
import {LinkRelationHierarchicalPainter} from '../../../classes/links/link-relation-hierarchical-painter';

import {HierarchicalSubjectNodeFactory} from '../model/hierarchical-subject-node-factory';
import {HierarchicalSubjectLinkFactory} from '../model/hierarchical-subject-link-factory';
import {BruteForceGridLayoutManager} from '../layout-manager/brute-force-grid-layout-manager';
import {GroupGridLayoutManager} from '../layout-manager/group-grid-layout-manager';
import {AbstractHierarchicalGraph} from './abstract-hierarchical-graph.component';
import {NodeType} from '../model/node-type';
import {Group} from '../model/group';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';

@Component({
  selector: 'i-enterprise-graph',
  templateUrl: '../hierarchical-graph.component.html',
  styleUrls: ['../hierarchical-graph.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EnterpriseGraphComponent extends AbstractHierarchicalGraph<NodeSubjectPresentation, LinkSubjectPresentation> {

  private static readonly groupMainPrefix = 'group-main-';
  private static readonly groupPrefix = 'group-';
  private static readonly linkRelationTypePrefix = 'link-type-';
  private static readonly groupFilterClass = 'group-filter';

  protected groupPainter: NodePainter<NodeSubjectPresentation>;

  protected groupsGroup: Selection<any, any, any, any>;
  protected groupTooltipGroup: Selection<any, any, any, any>;

  private profilePageId: string;
  private relationPageId: string;

  constructor(d3Service: D3Service,
      protected readonly pageNavigationUtilService: PageNavigationUtilService,
      protected readonly subjectIconProvider: SubjectIconProvider) {

    super(d3Service);

    this.legendType = 'enterprise';
    this.filterType = 'enterprise';
  }

  public changeLinkVisibility(linkFilter: any): void {
    const elementStyleList = [
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.FiscaalPartner, key: 'opacity', value: linkFilter.familyLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.VoorlopigFiscaalPartner, key: 'opacity', value: linkFilter.familyLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Ouder, key: 'opacity', value: linkFilter.familyLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Kind, key: 'opacity', value: linkFilter.familyLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.BroerOfZus, key: 'opacity', value: linkFilter.familyLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Bestuurder, key: 'opacity', value: linkFilter.managerLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftBestuurder, key: 'opacity', value: linkFilter.managerLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.FirmantDeelnemer, key: 'opacity', value: linkFilter.shareholderLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftFirmantDeelnemer, key: 'opacity', value: linkFilter.shareholderLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Aandeelhouder + ' .link-line', key: 'opacity', value: linkFilter.shareholderLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftAandeelhouder + ' .link-line', key: 'opacity', value: linkFilter.shareholderLink ? '1' : '0'},
      // {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.ObFiscaleEenheid, key: 'opacity', value: linkFilter.shareholderLink ? '1' : '0'},
      // {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.VpbFiscaleEenheid, key: 'opacity', value: linkFilter.shareholderLink ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Aandeelhouder + ' .link-percentage', key: 'opacity', value: linkFilter.shareholderPercentage ? '1' : '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftAandeelhouder + ' .link-percentage', key: 'opacity', value: linkFilter.shareholderPercentage ? '1' : '0'}];
    this.changeStyles(elementStyleList);
  }

  public changeFilterSelection(selectionFilter: any): void {
    const groupType = selectionFilter.groupType;
    const nodeIds = selectionFilter.selectedItems;

    this.removeAllFilterClasses();
    if (nodeIds != null && nodeIds.length > 0) {
      this.setNewFilterClasses(nodeIds.map((nodeId: string): string => '.group-' + groupType + '-' + nodeId));
    }
  }

  public setGroupPainter(groupPainter: NodePainter<NodeSubjectPresentation>): void {
    this.groupPainter = groupPainter;
  }

  protected buildGroups(): void {
    this.allGroups.push(new Group(null, 'Entiteit'));
    this.allGroups.push(new Group(LinkSubjectType.ObFiscaleEenheid, 'Fiscale eenheden OB'));
    this.allGroups.push(new Group(LinkSubjectType.VpbFiscaleEenheid, 'Fiscale eenheden VPB'));
  }

  protected joinGroups(): void {
    this.allGroups
      .filter(group => group.type != null)
      .forEach(group => this.allNodes
        .filter(node => node.presentation.hasGroupType(group.type))
        .forEach(node => {
          this.joinGridNodesAndLinksToGroup(node, group);
          group.nodes.push(node);
        }));
  }

  private joinGridNodesAndLinksToGroup(node: Node<NodeHierarchicalModel, NodeSubjectPresentation>, group: Group): void {
    const groupClass = EnterpriseGraphComponent.groupPrefix + group.type + '-' + node.id;
    const groupNodes = [node];

    node.classes.push(EnterpriseGraphComponent.groupFilterClass);
    node.classes.push(groupClass);
    node.classes.push(EnterpriseGraphComponent.groupMainPrefix + group.type + '-' + node.id);

    node.model.groupLinks
      .filter(link => link.presentation.type === group.type)
      .forEach(link => {
        link.target.classes.push(groupClass);
        groupNodes.push(link.target);
      });

    groupNodes
      .forEach(groupNode => groupNode.model.childLinks
        .filter(link => groupNodes.some(targetNode => targetNode === link.target))
        .forEach(link => link.classes.push(groupClass)));
  }

  protected initializeComponent(): void {
    this.setNodeFactory(new HierarchicalSubjectNodeFactory());
    this.setLinkFactory(new HierarchicalSubjectLinkFactory());

    const layoutManager = new BruteForceGridLayoutManager(AbstractHierarchicalGraph.nodeRadius,
        AbstractHierarchicalGraph.horizontalStep, AbstractHierarchicalGraph.verticalStep);
    layoutManager.setOptimizationThreshold(this.maxOptimizedRows);
    this.setGridLayoutManager(layoutManager);
  }

  protected initializePainters(): void {
    this.setNodePainter(new NodeSubjectPainter(this.topMargin, this.leftMargin, this.nodeTooltipGroup, this.subjectIconProvider,
      (node: Node<any, any>): void => this.pageNavigationUtilService.navigate(this.side, 'right', this.profilePageId, node.data.model, null),
      (node: Node<any, any>): void => this.pageNavigationUtilService.navigate(this.side, 'right', this.relationPageId, node.data.model, null)));
    this.setGroupPainter(new NodeGroupPainter(this.topMargin, this.leftMargin, this.groupTooltipGroup, this.subjectIconProvider,
      (node: Node<any, any>): void => this.pageNavigationUtilService.navigate(this.side, 'right', this.profilePageId, node.data.model, null),
      (node: Node<any, any>): void => this.pageNavigationUtilService.navigate(this.side, 'right', this.relationPageId, node.data.model, null)));
      this.setLinkPainter(new LinkRelationHierarchicalPainter(this.topMargin, this.leftMargin));
  }

  protected initializeStyles(): void {
    const styleList = [
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.FiscaalPartner, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.VoorlopigFiscaalPartner, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Kind, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Ouder, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Gehuwd, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.GehuwdMet, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Samenwonend, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.SamenwonendMet, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.ExPartnerGehuwd, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.ExPartnerSamenwonend, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.BroerOfZus, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.ZelfdeAdres, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftMeerRelaties, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.MeerRelaties, key: 'opacity', value: '0'},

      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Bestuurder, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftBestuurder, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.FirmantDeelnemer, key: 'opacity', value: '1'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftFirmantDeelnemer, key: 'opacity', value: '1'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Aandeelhouder + ' .link-line', key: 'opacity', value: '1'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftAandeelhouder + ' .link-line', key: 'opacity', value: '1'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.Aandeelhouder + ' .link-percentage', key: 'opacity', value: '1'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.HeeftAandeelhouder + ' .link-percentage', key: 'opacity', value: '1'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.ObFiscaleEenheid, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.OnderObFiscaleEenheid, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.VpbFiscaleEenheid, key: 'opacity', value: '0'},
      {selector: '.' + EnterpriseGraphComponent.linkRelationTypePrefix + LinkSubjectType.OnderVpbFiscaleEenheid, key: 'opacity', value: '0'}];
    this.changeStyles(styleList);
  }

  protected initializeLegendAndFilters(): void {
    const subjectRow = this.subject == null ? null :  this.subject.data;
    const subject = (subjectRow == null ? null : {'type': subjectRow['type'], 'name': subjectRow['naam']});

    setTimeout(() => {
      this.initialLegendSettings = {
        'subject': subject
      };
    });
  }

  protected buildGrid(): void {
    const gridLayout = this.gridLayoutManager.build(this.gridNodes.filter(node => node.model.behaviour === NodeType.node));

    this.grid = gridLayout.nodes;
    this.maxLevel = gridLayout.maxLevel;
    this.maxRowSize = gridLayout.maxRowSize;

    const groupGridLayoutManager = new GroupGridLayoutManager(AbstractHierarchicalGraph.nodeRadius,
      AbstractHierarchicalGraph.horizontalStep, AbstractHierarchicalGraph.verticalStep, this.maxLevel, this.maxRowSize);
    groupGridLayoutManager.build(this.gridNodes.filter(node => node.model.behaviour === NodeType.group));

    this.gridLinks.forEach(link => link.presentation.possibleCrossingLinks = link.model.possibleCrossingLinks);
  }

  protected drawBasicSvg(): void {
    super.drawBasicSvg();

    this.groupsGroup = this.graph.append('g').classed('node-group', true);
    this.groupTooltipGroup = this.graph.append('g').classed('group-tooltip-group', true);
  }

  protected drawLinks(): void {
    this.linkPainter.drawLinks(this.graph, this.linksGroup, this.gridLinks.filter(link => link.model.behaviour === NodeType.node));
  }

  protected drawNodes(): void {
    this.nodePainter.drawNodes(this.graph, this.nodesGroup, this.gridNodes.filter(node => node.model.behaviour === NodeType.node));
    this.groupPainter.drawNodes(this.graph, this.groupsGroup, this.gridNodes.filter(node => node.model.behaviour === NodeType.group));
  }

  private removeAllFilterClasses(): void {
    const elementClassList = [];

    for (let index = 0; index < 4; index++) {
      const groupClassName = this.createFilterGroupClassName(index);
      elementClassList.push({selector: '.' + groupClassName, name: groupClassName, present: false});
    }

    this.changeClasses(elementClassList);
  }

  private setNewFilterClasses(groupIds: string[]): void {
    const elementClassList = [];

    groupIds.forEach((groupId, index) => {
      const groupClassName = this.createFilterGroupClassName(index);
      elementClassList.push({selector: groupId, name: groupClassName, present: true});
    });

    this.changeClasses(elementClassList);
  }

  private createFilterGroupClassName(index: number): string {
    return (!isNaN(index) && index >= 0) ? ('group-nr' + (index % 4 + 1)) : '';
  }
}
