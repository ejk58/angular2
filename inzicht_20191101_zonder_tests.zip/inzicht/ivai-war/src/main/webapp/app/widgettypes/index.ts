import {ContainerComponent} from './container/container.component';
import {TableComponent} from './table/table.component';
import {SocialGraphComponent} from './social-graph/social-graph.component';
import {TimelineComponent} from './timeline/timeline.component';
import {SocialGraphLegendComponent} from './social-graph/social-graph-legend.component';
import {FamilyTreeGraphComponent} from './hierarchical-graph/widget/familytree-graph.component';
import {EnterpriseGraphComponent} from './hierarchical-graph/widget/enterprise-graph.component';
import {EnterpriseGraphLegendComponent} from './hierarchical-graph/legend/enterprise-graph-legend.component';
import {EnterpriseGraphFilterComponent} from './hierarchical-graph/filter/enterprise-graph-filter.component';
import {FamilyTreeGraphLegendComponent} from './hierarchical-graph/legend/familytree-graph-legend.component';
import {WidgetComponent} from '../components/widget/widget.component';
import {CollapsibleTableComponent} from './collapsible-table/collapsible-table.component';
import {LineBarChartComponent} from './linebarchart/linebarchart.component';
import {ListComponent} from './list/list.component';
import {SummaryButtonComponent} from './summary/summary-button/summary-button.component';
import {SummaryIconComponent} from './summary/summary-icon/summary-icon.component';
import {SummaryDescriptionComponent} from './summary/summary-description/summary-description.component';
import {SummaryDetailComponent} from './summary/summary-detail/summary-detail.component';
import {SummaryAddressComponent} from './summary/widgets/address.component';
import {SummaryPersonComponent} from './summary/widgets/person.component';
import {SummaryFamilyComponent} from './summary/widgets/family.component';
import {SummaryEarningsComponent} from './summary/widgets/earnings.component';
import {SummaryEconomicActivitiesComponent} from './summary/widgets/economic-activities.component';
import {SummaryFiscalActivitiesComponent} from './summary/widgets/fiscal-activities.component';
import {SummaryRecountComponent} from './summary/widgets/recount.component';
import {SummarySubHeaderComponent} from './summary/summary-subheader/summary-sub-header.component';
import {SummaryCorePropertyComponent} from './summary/summary-core-property/summary-core-property.component';
import {LinkComponent} from './link/link.component';
import {DataDrivenCompositionComponent} from './data-driven-composition/data-driven-composition.component';
import {MarkedDomainsComponent} from './marked-domains/marked-domains.component';
import {CompositionComponent} from './composition/composition.component';
import {SingleValueFilterComponent} from './single-value-filter/single-value-filter.component';
import {SelectableLineChartComponent} from './linechart/selectable-linechart.component';
import {ComplianceGraphComponent} from './compliance-graph/compliance-graph.component';
import {ComplianceGraphLegendComponent} from './compliance-graph/compliance-graph-legend.component';
import {NotificationComponent} from './notification/notification.component';
import {InvisibleComponent} from './invisible/invisible.component';
import {LegendComponent} from './legend/legend.component';
import {FlexibleCollapsibleTableComponent} from './flexible-collapsible-table/flexible-collapsible-table.component';
import {CollapsibleWidgetTableComponent} from './collapsible-widget-table/collapsible-widget-table.component';
import {EventTableComponent} from './event-table/event-table.component';

export const list = [
  WidgetComponent,
  ContainerComponent,
  DataDrivenCompositionComponent,
  CompositionComponent,
  MarkedDomainsComponent,
  TableComponent,
  SocialGraphComponent,
  TimelineComponent,
  SocialGraphLegendComponent,
  FamilyTreeGraphComponent,
  EnterpriseGraphComponent,
  EnterpriseGraphLegendComponent,
  EnterpriseGraphFilterComponent,
  FamilyTreeGraphLegendComponent,
  ComplianceGraphComponent,
  ComplianceGraphLegendComponent,
  SingleValueFilterComponent,
  CollapsibleTableComponent,
  LineBarChartComponent,
  SelectableLineChartComponent,
  ListComponent,
  SummaryAddressComponent,
  SummaryButtonComponent,
  SummaryPersonComponent,
  SummaryIconComponent,
  SummaryDescriptionComponent,
  SummaryDetailComponent,
  SummaryEarningsComponent,
  SummaryFamilyComponent,
  SummaryEconomicActivitiesComponent,
  SummaryFiscalActivitiesComponent,
  SummaryRecountComponent,
  SummarySubHeaderComponent,
  SummaryCorePropertyComponent,
  LinkComponent,
  NotificationComponent,
  InvisibleComponent,
  LegendComponent,
  FlexibleCollapsibleTableComponent,
  CollapsibleWidgetTableComponent,
  EventTableComponent
];

