import { GroupType } from './group-type';

export class Group {

  public name: string;
  public type: GroupType;
  public key: string;
  public visible: boolean;
  public nodes: any[];
  public annotation: string;

  constructor(name: string, type: string, key: string) {
    this.type = this.findGroupType(type);
    this.name = name;
    this.key = key != null ? key : name.replace(/\s/g, '');
    this.visible = true;
    this.nodes = [];
  }

  public isSameGroup(name: string, type: string): boolean {
    const groupType = this.findGroupType(type);
    return this.name === name && (this.type === groupType || this.type === GroupType.Unknown || groupType === GroupType.Unknown);
  }

  public isSameKey(key: string): boolean {
    return this.key === key;
  }

  public getType(): string {
    return this.type === GroupType.Unknown ? null : this.type.toString();
  }

  public addNode(node: any): void {
    this.nodes.push(node);
  }

  public setType(type: string) {
    if (this.type === GroupType.Unknown) {
      this.type = this.findGroupType(type);
    }
  }

  private findGroupType(type: string): GroupType {
    let groupType = GroupType.Unknown;

    if (type === 'LINE') {
      groupType = GroupType.Line;
    } else if (type === 'BAR') {
      groupType = GroupType.Bar;
    } else if (type === 'POINT') {
      groupType = GroupType.Point;
    } else if (type === 'AREA') {
      groupType = GroupType.Area;
    } else if (type === 'SPLINE') {
      groupType = GroupType.Spline;
    } else if (type === 'AREASPLINE') {
      groupType = GroupType.AreaSpline;
    }

    return groupType;
  }
}
