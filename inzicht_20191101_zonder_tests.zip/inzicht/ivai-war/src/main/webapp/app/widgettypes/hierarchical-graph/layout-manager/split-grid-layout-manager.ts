import {Node} from '../../../classes/nodes/node';

import {GridLayoutManager} from './grid-layout-manager';
import {AbstractGridLayoutManager} from './abstract-grid-layout-manager';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';

export class SplitGridLayoutManager extends AbstractGridLayoutManager implements GridLayoutManager {

  private static readonly defaultOptimizationThreshold = 500;

  private static readonly longHorizontalDistanceScoreModifier: number = 1000;
  private static readonly longVerticalDistanceScoreModifier: number = 1;
  private static readonly crossedLinksScoreWeight: number = 25;
  private static readonly crossedNodesScoreWeight: number = 200;

  private optimizationThreshold: number = SplitGridLayoutManager.defaultOptimizationThreshold;

  public setOptimizationThreshold(threshold: number): void {
    this.optimizationThreshold = threshold != null ? threshold : this.optimizationThreshold;
  }

protected buildGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    this.buildEmptyGrid(nodes, grid);
    this.fillGridWithDividerSpaces(grid);
    this.fillGridWithRelationNodes(nodes, grid);
    this.fillGridWithSpaces(grid, 3);
    this.linkNodesToGrid(grid);
  }

  protected improveGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    let newPenalty = this.calculatePenalty(grid, nodes);
    let penalty = newPenalty + 1;
    let count = 0;

    if (nodes.length <= this.optimizationThreshold) {
      while (count < 20 && newPenalty < penalty) {
        penalty = newPenalty;
        newPenalty = this.rearrangeNodesInGrid(grid, nodes);
        count++;
      }
    }

    this.trimEmptyColumnsFromGrid(grid);
    this.linkNodesToGrid(grid);
  }

  private fillGridWithDividerSpaces(grid: Node<NodeHierarchicalModel, any>[][]): void {
    grid.forEach(gridRow => gridRow.push(null));
  }

  private fillGridWithRelationNodes(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    nodes.forEach(node => {
      if (node.model.isPriority) {
        grid[node.model.level].unshift(node);
      } else {
        grid[node.model.level].push(node);
      }
    });
  }

  private rearrangeNodesInGrid(grid: Node<NodeHierarchicalModel, any>[][], nodeList: Node<NodeHierarchicalModel, any>[]): number {
    let level, index, subIndex;
    let newPenalty;
    const maxLevel = grid.length;
    const maxRowSize = grid[0].length;
    let penalty = this.calculatePenalty(grid, nodeList);

    for (level = 0; level < maxLevel; level++) {
      const personDivider = this.findDivider(grid[level], true);
      for (index = 0; index < personDivider; index++) {
        for (subIndex = 0; subIndex < personDivider; subIndex++) {
          if (subIndex !== index) {
            this.shiftNodesInGrid(grid, level, index, subIndex);
            newPenalty = this.calculatePenalty(grid, nodeList);

            if (newPenalty <= penalty) {
              penalty = newPenalty;
            } else {
              this.shiftNodesInGrid(grid, level, subIndex, index);
            }
          }
        }
      }

      const businessDivider = this.findDivider(grid[level], false);
      for (index = businessDivider; index < maxRowSize; index++) {
        for (subIndex = businessDivider; subIndex < maxRowSize; subIndex++) {
          if (subIndex !== index) {
            this.shiftNodesInGrid(grid, level, index, subIndex);
            newPenalty = this.calculatePenalty(grid, nodeList);

            if (newPenalty <= penalty) {
              penalty = newPenalty;
            } else {
              this.shiftNodesInGrid(grid, level, subIndex, index);
            }
          }
        }
      }
    }

    return penalty;
  }

  private calculatePenalty(grid: Node<NodeHierarchicalModel, any>[][], nodes: Node<NodeHierarchicalModel, any>[]): number {
    let penalty = 0;

    for (let index = 0; index < nodes.length; index++) {
      const node = nodes[index];
      for (let childIndex = 0; childIndex < node.model.childLinks.length; childIndex++) {
        const relation = node.model.childLinks[childIndex];
        penalty = penalty +
          this.calculateLinkDistancePenalty(relation, SplitGridLayoutManager.longVerticalDistanceScoreModifier) +
          this.calculateCrossedLinksPenalty(relation, SplitGridLayoutManager.crossedLinksScoreWeight) +
          this.calculateLongVerticalLinksPenalty(relation, grid, SplitGridLayoutManager.crossedNodesScoreWeight);
      }

      for (let siblingIndex = 0; siblingIndex < node.model.siblingLinks.length; siblingIndex++) {
        const relation = node.model.siblingLinks[siblingIndex];
        penalty = penalty +
          this.calculateLinkDistancePenalty(relation, SplitGridLayoutManager.longHorizontalDistanceScoreModifier);
      }
    }

    return penalty;
  }

  private findDivider(gridRow: Node<NodeHierarchicalModel, any>[], personSide: boolean): number {
    let lastPersonIndex = -1;

    for (let index = 0; index < gridRow.length; index++) {
      const node = gridRow[index];

      if (node != null) {
        if (node.model.isPriority) {
          lastPersonIndex = index;
        } else {
          return personSide ? index - 1 : (lastPersonIndex + 2);
        }
      }
    }

    return personSide ? gridRow.length : (lastPersonIndex + 2);
  }
}
