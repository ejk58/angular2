import {Node} from '../../../classes/nodes/node';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';
import {Link} from '../../../classes/links/link';

import {Grid} from '../model/grid';
import {GridLayoutManager} from './grid-layout-manager';
import {LinkHierarchicalModel} from '../model/link-hierarchical-model';

export abstract class AbstractGridLayoutManager implements GridLayoutManager {

  protected readonly horizontalGap: number;
  protected readonly verticalGap: number;

  constructor(protected readonly nodeRadius: number,
      protected readonly horizontalStep: number,
      protected readonly verticalStep: number) {

    this.horizontalGap = this.horizontalStep - (this.nodeRadius * 2);
    this.verticalGap = this.verticalStep - (this.nodeRadius * 2);
  }

  public build(nodes: Node<NodeHierarchicalModel, any>[]): Grid {
    const grid: Node<NodeHierarchicalModel, any>[][] = [];

    if (nodes && nodes.length > 0) {
      this.prepareNodesForGrid(nodes);
      this.buildGrid(nodes, grid);
      this.improveGrid(nodes, grid);
      this.cleanGrid(grid);
      this.calculateNodesInGrid(nodes);
    }

    return this.buildResponse(grid);
  }

  protected prepareNodesForGrid(nodes: Node<NodeHierarchicalModel, any>[]): void {
    this.setLevelsForNodes(nodes);
    this.adjustLevelsForHorizontalRelations(nodes);
    this.adjustLevelsForNonPriorityNodes(nodes);
    this.determinePossibleCrossingLinks(nodes);
  }

  protected buildGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    this.buildEmptyGrid(nodes, grid);
    this.fillGridWithNodes(nodes, grid);
    this.fillGridWithSpaces(grid, 2);
    this.linkNodesToGrid(grid);
  }

  protected abstract improveGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void;

  protected cleanGrid(grid: Node<NodeHierarchicalModel, any>[][]): void {
    this.trimEmptyColumnsFromGrid(grid);
    this.linkNodesToGrid(grid);
  }

  protected calculateNodesInGrid(nodes: Node<NodeHierarchicalModel, any>[]): void {
    nodes.forEach(node => {
      node.model.x = this.calculateXCoordinate(node);
      node.model.y = this.calculateYCoordinate(node);

      node.x = node.model.x;
      node.y = node.model.y;
    });
  }

  protected buildResponse(grid: Node<NodeHierarchicalModel, any>[][]): Grid {
    const maxLevel = grid.length;
    const maxRowSize = maxLevel > 0 ? grid[0].length : 0;
    const minWidth = maxRowSize * this.horizontalStep - this.horizontalGap;
    const minHeight = maxLevel * this.verticalStep - this.verticalGap;

    return new Grid(grid, minWidth, minHeight, maxLevel, maxRowSize);
  }

  protected setLevelsForNodes(nodes: Node<NodeHierarchicalModel, any>[]): void {
    nodes
      .filter(node => node.model.level == null)
      .forEach(node => this.determineLevelFromParentNodes(node));
  }

  protected determineLevelFromParentNodes(node: Node<NodeHierarchicalModel, any>): number {
    if (node.model.level == null) {
      node.model.level = node.model.parentLinks
        .reduce((level, parentLink) => Math.max(level, this.determineLevelFromParentNodes(parentLink.source) + 1), 0);
    }

    return node.model.level;
  }

  protected adjustLevelsForNonPriorityNodes(nodes: Node<NodeHierarchicalModel, any>[]): void {
    nodes
      .filter(node => !node.model.isPriority && node.model.siblingLinks.length === 0)
      .forEach(node => this.determineLevelFromChildNodes(node));
  }

  protected determineLevelFromChildNodes(node: Node<NodeHierarchicalModel, any>): number {
    const maximumLevel = node.model.childLinks
      .reduce((level: number, childLink) => (level == null ? (this.determineLevelFromChildNodes(childLink.target) - 1) : Math.min(level, this.determineLevelFromChildNodes(childLink.target) - 1)), null);

    node.model.level = Math.max(node.model.level, maximumLevel);
    return node.model.level;
  }

  protected adjustLevelsForHorizontalRelations(nodes: Node<NodeHierarchicalModel, any>[]): void {
    nodes.forEach((node: Node<NodeHierarchicalModel, any>): void => {
      const level = node.model.siblingLinks
        .map(siblingLink => (siblingLink.target === node ? siblingLink.source : siblingLink.target))
        .reduce((level, siblingLinkNode) => Math.max(siblingLinkNode.model.level, level), node.model.level);

      if (level > node.model.level) {
        node.model.level = level;
        node.model.childLinks.forEach(childLink => this.determineLevelForSiblingChildNodes(childLink.target, level + 1));
      }
    });
  }

  protected determineLevelForSiblingChildNodes(node: Node<NodeHierarchicalModel, any>, level: number): void {
    node.model.level = Math.max(node.model.level, level);
    node.model.childLinks.forEach(childLink => this.determineLevelForSiblingChildNodes(childLink.target, level + 1));
  }

  protected determinePossibleCrossingLinks(nodes: Node<NodeHierarchicalModel, any>[]): void {
    nodes.forEach(node => {
      node.model.childLinks
        .filter(link => link.model.weight > 0)
        .forEach(link => this.determinePossibleCrossingLinksForLink(nodes, link));
    });
  }

  protected buildEmptyGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    const maxLevel = this.findMaximumLevelInNodes(nodes);

    for (let level = 0; level < maxLevel; level++) {
      grid.push([]);
    }
  }

  protected linkNodesToGrid(grid: Node<NodeHierarchicalModel, any>[][]): void {
    grid.forEach((gridRow, level) => {
      for (let index = 0; index < gridRow.length; index++) {
        if (grid[level][index] != null) {
          grid[level][index].model.index = index;
        }
      }
    });
  }

  protected fillGridWithNodes(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    nodes.forEach(node => grid[node.model.level].push(node));
  }

  protected fillGridWithSpaces(grid: Node<NodeHierarchicalModel, any>[][], extraRowSize: number): void {
    const maxRowSize = this.findMaximumRowSizeInGrid(grid) + extraRowSize;

    grid.forEach((gridRow, level) => {
      while (grid[level].length < maxRowSize) {
        if ((maxRowSize - grid[level].length) % 2 === 0) {
          grid[level].splice(0, 0, null);
        } else {
          grid[level].splice(grid[level].length, 0, null);
        }
      }
    });
  }

  protected trimEmptyColumnsFromGrid(grid: Node<NodeHierarchicalModel, any>[][]): Node<NodeHierarchicalModel, any>[][] {
    const firstColumnEmpty = this.findEmptyColumn(grid, 0);
    if (firstColumnEmpty) {
      grid.forEach(gridRow => gridRow.shift());
    }

    const lastColumnEmpty = this.findEmptyColumn(grid, grid[0].length - 1);
    if (lastColumnEmpty) {
      grid.forEach(gridRow => gridRow.pop());
    }

    return (firstColumnEmpty || lastColumnEmpty) ? this.trimEmptyColumnsFromGrid(grid) : grid;
  }

  public calculateXCoordinate(node: Node<NodeHierarchicalModel, any>): number {
    return isNaN(node.model.index) ? 0 : (node.model.index * this.horizontalStep + this.nodeRadius);
  }

  public calculateYCoordinate(node: Node<NodeHierarchicalModel, any>): number {
    return isNaN(node.model.level) ? 0 : (node.model.level * this.verticalStep + this.nodeRadius);
  }

  protected determinePossibleCrossingLinksForLink(nodes: Node<NodeHierarchicalModel, any>[], link: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>): void {
    const source = link.source;
    const target = link.target;

    nodes
      .filter(node => node !== source && node.model.level < target.model.level)
      .map(node => node.model.childLinks)
      .forEach(childLinks => childLinks
          .filter(childLink => childLink.model.isVisible && childLink.model.weight > 0 && childLink.target !== target && childLink.target.model.level > source.model.level)
          .forEach(childLink => link.model.possibleCrossingLinks.push(childLink)));
  }

  protected calculateLinkDistancePenalty(link: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>, weight: number): number {
    const source = link.source;
    const target = link.target;
    return Math.abs(target.model.index - source.model.index) * link.model.weight * weight;
  }

  protected calculateCrossedLinksPenalty(link: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>, weight: number): number {
    const node = link.source;
    const linkedNode = link.target;
    let crossedLinksCount = 0;

    for (let index = 0; index < link.model.possibleCrossingLinks.length; index++) {
      const source = link.model.possibleCrossingLinks[index].source;
      const target = link.model.possibleCrossingLinks[index].target;

      if ((source.model.index < node.model.index) && (target.model.index > linkedNode.model.index)) {
        crossedLinksCount++;
      } else if ((source.model.index > node.model.index) && (target.model.index < linkedNode.model.index)) {
        crossedLinksCount++;
      }
    }

    return crossedLinksCount * weight;
  }

  protected calculateLongVerticalLinksPenalty(link: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>,
      grid: Node<NodeHierarchicalModel, any>[][], weight: number): number {
    const node = link.source;
    const relatedNode = link.target;
    let crossedNodesCount = 0;

    for (let level = node.model.level + 1; level < relatedNode.model.level; level++) {
      const lineIndex = node.model.index + (relatedNode.model.index - node.model.index) * (level - node.model.level) / (relatedNode.model.level - node.model.level);
      const index = Math.round(lineIndex);

      if ((Math.abs(lineIndex - index) < 0.4) && (grid[level][index] !== null)) {
        crossedNodesCount++;
      }
    }

    return crossedNodesCount * weight;
  }

  protected findMaximumLevelInNodes(nodes: Node<NodeHierarchicalModel, any>[]): number {
    return nodes.reduce((maxLevel: number, node: Node<NodeHierarchicalModel, any>): number => Math.max(maxLevel, node.model.level + 1), 0);
  }

  protected findMaximumRowSizeInGrid(grid: Node<NodeHierarchicalModel, any>[][]): number {
    return grid
      .map(gridRow => gridRow.length)
      .reduce((maxSize, rowSize) => Math.max(maxSize, rowSize), 0);
  }

  protected findEmptyColumn(grid: Node<NodeHierarchicalModel, any>[][], index: number): boolean {
    return grid.reduce((isEmptyColumn, gridRow) => isEmptyColumn && gridRow[index] == null, true);
  }

  protected swapNodesInGrid(grid: Node<NodeHierarchicalModel, any>[][], level: number, index: number, otherIndex: number): void {
    const node = grid[level][index];
    const otherNode = grid[level][otherIndex];

    grid[level][index] = otherNode;
    grid[level][otherIndex] = node;

    if (node !== null) {
      node.model.index = otherIndex;
    }

    if (otherNode !== null) {
      otherNode.model.index = index;
    }
  }

  protected shiftNodesInGrid(grid: Node<NodeHierarchicalModel, any>[][], level: number, startIndex: number, endIndex: number): void {
    const direction = (startIndex < endIndex ? 1 : -1);
    const node = grid[level][startIndex];
    let index = startIndex;

    while (index !== endIndex) {
      const otherNode = grid[level][index + direction];
      grid[level][index] = otherNode;

      if (otherNode !== null) {
        otherNode.model.index = index;
      }

      index = index + direction;
    }

    grid[level][endIndex] = node;

    if (node !== null) {
      node.model.index = endIndex;
    }
  }
}
