import { Component, Input, OnInit, AfterViewInit, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { D3Service, D3, Selection } from 'd3-ng2-service';
import { Node } from './node';
import { Home } from './home';
import { Link } from './link';

@Component({
  selector: 'i-social-graph',
  templateUrl: './social-graph.component.html',
  styleUrls: ['./social-graph.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SocialGraphComponent implements OnInit, AfterViewInit {

  private static readonly aspectRatio: number = 0.5;
  private static readonly borderHeight: number = 10;
  private static readonly nodeArea: number = Node.auraRadius + SocialGraphComponent.borderHeight;
  private static readonly outsideDeltaX: number = SocialGraphComponent.nodeArea * 2;

  @Input() widgetId: string;
  @Input() side: string;
  @Input() widget: any;

  @ViewChild('socialGraphCanvas', { static: false }) canvasElementRef: ElementRef;

  public zoomCanvas: Selection<any, any, any, any>;
  public zoomElement: Selection<any, any, any, any>;
  public size: {width: number; height: number};
  public subjectIsPerson: boolean;

  private readonly d3: D3;
  private canvas: Selection<any, any, any, any>;
  private graph: Selection<any, any, any, any>;

  private subject: Node;
  private partner: Node;
  private home: Home;
  private sameAddress: Node[];
  private otherAddress: Node[];
  private nodes: Node[];
  private links: Link[];

  private width: number;
  private height: number;

  constructor(private readonly d3Service: D3Service) {
    this.d3 = d3Service.getD3();
  }

  ngOnInit() {
    this.initializeVariables();

    if (this.widget.data.length > 0) {
      this.buildRelationDiagram();
    }
  }

  ngAfterViewInit() {
    if (this.widget.data.length > 0) {
      this.drawBasicCanvas();
      this.drawHome();
      this.drawLinks();
      this.drawNodes();
      this.drawTextBoxes();
      this.enableZoomAndPan();
    }
  }

  private initializeVariables(): void {
    this.subject = null;
    this.partner = null;
    this.home = null;
    this.sameAddress = [];
    this.otherAddress = [];
    this.nodes = [];
    this.links = [];

    this.widget.data.forEach((row: any) => {
      let node = this.findNode(row);

      if (node == null) {
        node = new Node(row, this.nodes.length);
        this.nodes.push(node);

        if (node.isSubject) {
          this.sameAddress.unshift(node);
          this.home = new Home(row);
        } else if (node.isSameAddress || node.isMasked) {
          this.sameAddress.push(node);
        } else {
          this.otherAddress.push(node);
        }
      } else {
        node.merge(row);
      }

      if (node.isSubject) {
        this.subject = node;
      } else if (node.isFiscalPartner) {
        this.partner = node;
      }

      if (node.isSameAddress) {
        if (this.home == null || !this.home.isAvailable) {
          this.home = new Home(row);
        }
      }
    });

    this.nodes.forEach((node: Node): void => {
      if (node.isRelated) {
        const link = new Link(this.subject, node);
        this.links.push(link);
      }

      if (this.partner != null && node.isPartnersChild) {
        const link = new Link(this.partner, node);
        this.links.push(link);
      }
    });

    this.sameAddress.sort((node: Node, otherNode: Node): number => {
      return node.rank - otherNode.rank;
    });

    this.otherAddress.sort((node: Node, otherNode: Node): number => {
      return node.rank - otherNode.rank;
    });

    this.subjectIsPerson = !this.subject || this.subject.isNaturalPerson;
  }

  private findNode(row: any): Node {
    if (row['finr_relatie'] != null) {
      const rowSubjectNr = row['finr_relatie'];
      const matchingNodes = this.nodes.filter((node: Node): boolean => rowSubjectNr === node.subjectNr);
      return (matchingNodes.length <= 0 ? null : matchingNodes[0]);
    }

    return null;
  }

  private buildRelationDiagram(): void {
    this.home.radius = Math.max(Home.minimumRadius,
        Math.floor(this.sameAddress.length * SocialGraphComponent.nodeArea / Math.PI) + SocialGraphComponent.nodeArea);
    this.home.innerRadius = this.home.radius - SocialGraphComponent.nodeArea;
    this.home.vipRadius = this.home.radius;
    this.height = this.home.radius * 2 + SocialGraphComponent.nodeArea * 2 + 40;

    const maxOutsideNodesPerColumn = Math.floor(this.home.radius / SocialGraphComponent.nodeArea) + 1;
    const outsideNodesPerColumn = (maxOutsideNodesPerColumn % 2) === 0 ? maxOutsideNodesPerColumn : (maxOutsideNodesPerColumn - 1);
    const outsideNodeColumnCount = Math.floor((this.otherAddress.length + outsideNodesPerColumn - 1) / outsideNodesPerColumn);
    const outsideWidth = outsideNodeColumnCount * SocialGraphComponent.nodeArea * 2;
    const calculatedWidth = this.home.radius * 2 + outsideWidth + 80;
    const aspectRatioWidth = Math.floor(this.height / SocialGraphComponent.aspectRatio);
    const widthDelta = Math.floor((Math.max(calculatedWidth, aspectRatioWidth) - calculatedWidth) / 2);

    this.width = Math.max(calculatedWidth, aspectRatioWidth);
    this.home.x = Math.floor((calculatedWidth - outsideWidth - 60) / 2) + widthDelta;
    this.home.y = this.home.radius + SocialGraphComponent.nodeArea + 20;

    const homeAngle = Math.PI * 2 / this.sameAddress.length;
    this.sameAddress.forEach((node, index) => {
      const radius = (!node.isMasked ? this.home.innerRadius : this.home.vipRadius);
      node.x = Math.floor(Math.cos(Math.PI * 2 - homeAngle * index) * radius) + this.home.x;
      node.y = Math.floor(Math.sin(Math.PI * 2 - homeAngle * index) * radius) + this.home.y;
    });

    const outsideX = this.home.x + this.home.radius + SocialGraphComponent.nodeArea;
    this.otherAddress.forEach((node, index) => {
      const columnIndex = Math.floor(index / outsideNodesPerColumn);
      const rowIndex = index % outsideNodesPerColumn;
      const nodesInColumn = Math.min(this.otherAddress.length - (outsideNodesPerColumn * columnIndex), outsideNodesPerColumn);
      const outsideY = this.home.y - nodesInColumn * SocialGraphComponent.nodeArea;

      node.x = outsideX + columnIndex * SocialGraphComponent.outsideDeltaX;
      node.y = outsideY + rowIndex * SocialGraphComponent.nodeArea * 2 + SocialGraphComponent.nodeArea;
    });
  }

  private drawBasicCanvas(): void {
    this.canvas = this.d3.select(this.canvasElementRef.nativeElement)
      .append('svg')
      .attr('preserveAspectRatio', 'xMinYMin meet')
      .attr('viewBox', '0 0 ' + this.width + ' ' + this.height)
      .classed('social-graph-svg', true);

    this.graph = this.canvas
      .append('g');
  }

  private drawHome(): void {
    this.home.draw(this.graph);
  }

  private drawLinks(): void {
    this.links.forEach((link: Link): void => {
      link.draw(this.graph);
    });
  }

  private drawNodes(): void {
    this.nodes.forEach((node: Node): void => {
      node.drawIcon(this.graph);
    });
  }

  private drawTextBoxes(): void {
    this.nodes.forEach((node: Node): void => {
      node.drawTextBox(this.graph);
    });
  }

  private enableZoomAndPan(): void {
    setTimeout(() => {
      this.zoomCanvas = this.canvas;
      this.zoomElement = this.graph;
      this.size = {width: this.width, height: this.height};
    });
  }
}
