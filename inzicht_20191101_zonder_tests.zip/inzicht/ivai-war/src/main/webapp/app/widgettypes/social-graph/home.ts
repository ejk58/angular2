import { Selection } from 'd3-ng2-service';

export class Home {

  public static readonly minimumRadius: number = 200;
  public static readonly addressHeight: number = 45;
  public static readonly addressLineHeight: number = 20;
  public static readonly color: string = '#E5F0F9';

  public isAvailable: boolean;

  public address: string;
  public city: string;

  public x: number;
  public y: number;
  public radius: number;
  public innerRadius: number;
  public vipRadius: number;

  constructor(row: any) {
    this.address = (row['straat_huisnr_relatie'] == null) ? '' : row['straat_huisnr_relatie'];
    this.city = (row['pc_plaats_relatie'] == null) ? '' : row['pc_plaats_relatie'];

    this.isAvailable = (this.address !== '');

    this.x = 0;
    this.y = 0;
    this.radius = Home.minimumRadius;
    this.innerRadius = Home.minimumRadius;
    this.vipRadius = Home.minimumRadius;
  }

  public draw(graph: Selection<any, any, any, any>): void {
    const homeGroup = graph.append('g');
    homeGroup.append('circle')
      .attr('id', 'RelationAddressHouse')
      .attr('cx', this.x)
      .attr('cy', this.y)
      .attr('r', this.radius)
      .attr('class', 'home');

    const address = homeGroup.append('text')
      .attr('class', 'person-address')
      .attr('x', this.x)
      .attr('y', this.y + this.radius + Home.addressLineHeight)
      .attr('fill', 'black');
    address.append('tspan')
      .attr('id', 'RelationAddressStreet')
      .attr('x', this.x)
      .attr('dy', Home.addressLineHeight)
      .attr('text-anchor', 'middle')
      .text(this.address);
    address.append('tspan')
      .attr('id', 'RelationAddressCity')
      .attr('x', this.x)
      .attr('dy', Home.addressLineHeight)
      .attr('text-anchor', 'middle')
      .text(this.city);
  }
}
