import {Component, Input} from '@angular/core';

import {PageNavigationUtilService} from '../../../commons/page-navigation-util.service';

@Component({
  selector: 'i-summary-button',
  templateUrl: './summary-button.component.html',
  styleUrls: ['./summary-button.component.scss']
})
export class SummaryButtonComponent {

  @Input() summaryPageId: string;
  @Input() summaryPageLabel: string;
  @Input() side: string;

  constructor(private readonly pageNavigationUtil: PageNavigationUtilService) {
  }

  navigate(): void {
    this.pageNavigationUtil.navigate(this.side, this.side, this.summaryPageId, null, null);
  }
}
