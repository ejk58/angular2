import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import * as fromSelectors from '../../store/selectors';
import {Store} from '@ngrx/store';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-link',
  templateUrl: './link.component.html',
  styleUrls: ['./link.component.scss'],
  providers: [Unsubscriber]
})
export class LinkComponent implements OnInit, OnDestroy {
  @Input() widgetId: string;
  @Input() side: string;
  @Input() widget: any;
  @Input() params: any;

  public links: any[] = [];
  ktaEnvironment: any;

  constructor(private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) {}

  public ngOnInit(): void {
    this.store.select(fromSelectors.getSystemKtaEnvironmentState)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(configurationData => {
        this.ktaEnvironment = configurationData;
        this.setKtaVariables();
      });
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public goToLink(index: number): void {
    const newWindow = window.open(this.links[index].url, '_blank');
    newWindow.focus();
  }

  private setKtaVariables(): void {
    if (this.widget.options.columns.LINK != null) {
      this.links.push({
        'text': this.widget.options.columns.LINK.label,
        'buttonLabel': this.widget.options.columns.LINKLABEL.label,
        'url': this.widget.data[0]['LINK']
      });
    }
  }

}
