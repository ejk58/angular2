import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'i-composition',
  templateUrl: './composition.component.html',
  styleUrls: ['./composition.component.scss']
})
export class CompositionComponent {

  @Input() side: string;
  @Input() widgetId: string;
  @Input() widget: any;
  @Input() filter: any;
  @Output() hasData: EventEmitter<any> = new EventEmitter<any>();

  public widgets: any[];
  public compositionGridColumns: {[widgetName: string]: number} = {};

  private emptyWidgets: string[];

  constructor() {}

  ngOnInit() {
    this.emptyWidgets = [];
    this.widgets = this.widget.options.widgets;

    // see if there's a compositionGridColumns configured
    if (this.widget.options.compositionGridColumns) {
      this.compositionGridColumns = JSON.parse(this.widget.options.compositionGridColumns);
    }

    // always fill the compositionGridColumns with a default of 4, being a full row, for each widget
    this.widgets.forEach(widget => {
      if (typeof this.compositionGridColumns[widget.name] === 'undefined') {
        this.compositionGridColumns[widget.name] = 4;
      }
    });
  }

  changeDataStatus(e) {
    if (!e.hasData) {
      this.emptyWidgets.push(e.id);
      if (this.emptyWidgets.length === this.widgets.length) {
        this.hasData.emit({id: this.widgetId, hasData: false});
      }
    }
  }
}
