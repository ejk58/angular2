import { DetailSection } from './detail-section';

export class Detail {
  public type: string;
  public hasHeader: boolean = false;
  public isActive: boolean = true;
  public message: string;
  public footerText: string;
  public title: string;
  public personIsDead: boolean;
  public sectionList: DetailSection[] = [];
}
