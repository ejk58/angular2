import {Link} from '../../../classes/links/link';
import {Node} from '../../../classes/nodes/node';

import {NodeHierarchicalModel} from './node-hierarchical-model';

export class LinkHierarchicalModel {

  public x: number;
  public y: number;

  public behaviour: number;
  public direction: number;
  public weight: number;

  public isUnknownType: boolean;
  public isBadLink: boolean;
  public isVisible: boolean;

  public possibleCrossingLinks: Link<Node<NodeHierarchicalModel, any>, LinkHierarchicalModel, any>[];
}
