import {Component, OnInit} from '@angular/core';
import {TableComponent} from '../table/table.component';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-collapsible-widget-table',
  templateUrl: './collapsible-widget-table.component.html',
  styleUrls: ['./collapsible-widget-table.component.scss'],
  providers: [Unsubscriber]
})
export class CollapsibleWidgetTableComponent extends TableComponent implements OnInit {

  public collapseWidget: string;
  public filterColumn: string;
  private expandedRows: {[i: number]: boolean} = {};

  ngOnInit() {
    super.ngOnInit();
    this.collapseWidget = this.widget.options.collapseWidget;
    this.filterColumn = Object.keys(this.widget.options.columns).find(key => this.widget.options.columns[key].columnType === 'FILTER');

    if (this.haveGroupAttributes) {
      this.columnGroups.unshift({
        columnType: null,
        label: null,
        span: 1,
        sticky: Object.keys(this.columns).some(c => this.columns[c].sticky)
      });
    }
  }

  public toggleExpandRow(i: number): void {
    if (this.isExpanded(i)) {
      this.expandedRows[i] = false;
    } else {
      this.expandedRows = {};
      setTimeout(() => this.expandedRows[i] = true, 0);
    }
  }

  public isExpanded(i: number): boolean {
    return this.expandedRows[i];
  }

}
