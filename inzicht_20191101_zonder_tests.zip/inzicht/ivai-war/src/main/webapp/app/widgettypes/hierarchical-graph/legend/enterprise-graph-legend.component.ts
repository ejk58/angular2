import {Component, Input, Output, OnInit, OnChanges, ViewEncapsulation, EventEmitter, OnDestroy} from '@angular/core';
import {SubjectIconProvider} from '../../../commons/subject-icon-provider';
import {SubjectType} from '../../../commons/subject-type';
import {TrackingService} from '../../../services/tracking.service';
import {SplitViewState} from '../../../services/split-view-state.service';
import {SplitWidth} from '../../../classes/split-width';
import {Unsubscriber} from '../../../commons/unsubscriber';

@Component({
  selector: 'i-enterprise-graph-legend',
  templateUrl: './enterprise-graph-legend.component.html',
  styleUrls: ['./enterprise-graph-legend.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})
export class EnterpriseGraphLegendComponent implements OnInit, OnDestroy, OnChanges {

  private static readonly SidePanelWidth: number = 500;

  @Input() widgetId: string;
  @Input() side: string;
  @Input() settings: any;

  @Output() filterChange = new EventEmitter<any>();

  public aandeelhouder: boolean = true;
  public aandeelhouderPercentage: boolean = true;
  public bestuurder: boolean = false;
  public relatie2deGraad: boolean = false;
  public visible: boolean;
  public sidePanelVisible: boolean = true;
  public splitWidth: SplitWidth = SplitWidth.default;
  public breakpointWidth: number;

  public subject: {type: number, name: string};

  constructor(private readonly splitViewState: SplitViewState,
              private readonly subjectIconProvider: SubjectIconProvider,
              private readonly trackingService: TrackingService,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit(): void {
    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(splitWidth => this.splitWidth = splitWidth != null ? splitWidth : SplitWidth.default);
    this.breakpointWidth = this.splitViewState.breakpointResponsive + EnterpriseGraphLegendComponent.SidePanelWidth;
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  ngOnChanges(): void {
    if (this.settings) {
      this.subject = this.settings.subject;
    }
  }

  public getButtonArrow(): string {
    return this.visible ? 'bd_keyboard_arrow_up bd-30' : 'bd_keyboard_arrow_down bd-30';
  }

  public getSubjectIcon(): string {
    return this.subjectIconProvider.getMainSubjectCharacter(this.subject ? this.subject.type : SubjectType.OnbekendSubject);
  }

  public toggleLegend(event: any): void {
    this.visible = !this.visible;

    if (this.visible) {
      this.trackingService.trackEvent('klik',
        'Klik legenda open:' + this.side + '/widget:' + this.widgetId,
        null, null);
    }
  }

  public toggleSidePanel(): void {
    this.sidePanelVisible = !this.sidePanelVisible;
  }

  public toggleFilter(name: string): void {
    this[name] = !this[name];

    this.filterChange.emit({
      'shareholderPercentage': this.aandeelhouderPercentage,
      'shareholderLink': this.aandeelhouder,
      'managerLink': this.bestuurder,
      'familyLink': this.relatie2deGraad
    });
  }
}
