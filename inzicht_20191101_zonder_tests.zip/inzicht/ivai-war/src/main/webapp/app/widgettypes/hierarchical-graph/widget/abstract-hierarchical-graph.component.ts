import {AfterViewInit, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {D3, D3Service, Selection} from 'd3-ng2-service';

import {Node} from '../../../classes/nodes/node';
import {NodeFactory} from '../../../classes/nodes/node-factory';
import {NodePainter} from '../../../classes/nodes/node-painter';
import {Link} from '../../../classes/links/link';
import {LinkFactory} from '../../../classes/links/link-factory';
import {LinkPainter} from '../../../classes/links/link-painter';
import {Group} from '../model/group';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';
import {LinkHierarchicalModel} from '../model/link-hierarchical-model';
import {GridLayoutManager} from '../layout-manager/grid-layout-manager';
import {LinkDirection} from '../model/link-direction';

export abstract class AbstractHierarchicalGraph<P, R> implements OnInit, AfterViewInit {

  protected static readonly defaultMaxAllowedRows: number = 500;
  protected static readonly defaultMaxOptimizedRows: number = 500;
  protected static readonly aspectRatio: number = 0.5;
  protected static readonly nodeRadius: number = 100;

  protected static readonly minimumWidth = 400;
  protected static readonly topMargin = 100;
  protected static readonly bottomMargin = 100;
  protected static readonly leftMargin = 50;
  protected static readonly rightMargin = 50;
  protected static readonly horizontalGap = 10;
  protected static readonly verticalGap = 80;
  protected static readonly horizontalStep = AbstractHierarchicalGraph.nodeRadius * 2 + AbstractHierarchicalGraph.horizontalGap;
  protected static readonly verticalStep = AbstractHierarchicalGraph.nodeRadius * 2 + AbstractHierarchicalGraph.verticalGap;

  @Input() widgetId: string;
  @Input() side: string;
  @Input() widget: any;

  @ViewChild('hierarchicalGraphCanvas', { static: false }) canvasElementRef: ElementRef;

  public zoomCanvas: Selection<any, any, any, any>;
  public zoomElement: Selection<any, any, any, any>;
  public size: {width: number; height: number};
  public subject: Node<NodeHierarchicalModel, P> = null;
  public home: {x: number, y: number};
  public maxAllowedRows: number;
  public maxOptimizedRows: number;
  public hasTooManyRows: boolean = false;
  public hasBadLinks: boolean = false;
  public hasUnconnectedNodes: boolean = false;
  public hasUnknownLinks: boolean = false;

  protected readonly d3: D3;
  protected canvas: Selection<any, any, any, any>;
  protected graph: Selection<any, any, any, any>;
  protected linksGroup: Selection<any, any, any, any>;
  protected nodesGroup: Selection<any, any, any, any>;
  protected nodeTooltipGroup: Selection<any, any, any, any>;

  protected nodeFactory: NodeFactory<NodeHierarchicalModel, P>;
  protected linkFactory: LinkFactory<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>;
  protected gridLayoutManager: GridLayoutManager;
  protected nodePainter: NodePainter<P>;
  protected linkPainter: LinkPainter<R>;

  protected allGroups: Group[];
  protected allNodes: Node<NodeHierarchicalModel, P>[];
  protected gridNodes: Node<NodeHierarchicalModel, P>[];
  protected allLinks: Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>[];
  protected gridLinks: Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>[];
  protected grid: Node<NodeHierarchicalModel, P>[][];

  protected maxLevel: number;
  protected maxRowSize: number;
  protected width: number;
  protected height: number;
  protected leftMargin: number;
  protected topMargin: number;

  protected legendType: string;
  protected filterType: string;
  protected initialLegendSettings: any;

  constructor(protected readonly d3Service: D3Service) {
    this.d3 = d3Service.getD3();
  }

  ngOnInit() {
    this.initializeComponent();
    this.initializeVariables();

    if (this.widget.data.length > 0 && !this.hasTooManyRows) {
      this.prepareNodeStructure();
      this.buildGrid();
    }
  }

  ngAfterViewInit() {
    if (this.widget.data.length > 0 && !this.hasTooManyRows) {
      this.drawGraph();
    }
  }

  public setNodeFactory(nodeFactory: NodeFactory<NodeHierarchicalModel, P>): void {
    this.nodeFactory = nodeFactory;
  }

  public setLinkFactory(linkFactory: LinkFactory<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>): void {
    this.linkFactory = linkFactory;
  }

  public setGridLayoutManager(gridLayoutManager: GridLayoutManager): void {
    this.gridLayoutManager = gridLayoutManager;
  }

  public setNodePainter(nodePainter: NodePainter<P>): void {
    this.nodePainter = nodePainter;
  }

  public setLinkPainter(linkPainter: LinkPainter<R>): void {
    this.linkPainter = linkPainter;
  }

  protected abstract initializeComponent(): void;

  protected initializeVariables(): void {
    this.maxAllowedRows = (this.widget.options.maxAllowedRows ? +this.widget.options.maxAllowedRows : AbstractHierarchicalGraph.defaultMaxAllowedRows);
    this.maxOptimizedRows = (this.widget.options.maxOptimizedRows ? this.widget.options.maxOptimizedRows : AbstractHierarchicalGraph.defaultMaxOptimizedRows);
    this.hasTooManyRows = (this.widget.data.length > this.maxAllowedRows);
    this.maxLevel = 0;
    this.maxRowSize = 1;

    this.allGroups = [];
    this.allNodes = [];
    this.gridNodes = [];
    this.allLinks = [];
    this.gridLinks = [];
    this.grid = [];
  }

  protected prepareNodeStructure(): void {
    this.buildGroups();
    this.buildPresentNodes();
    this.buildUnknownNodes();
    this.buildLinks();

    this.filterGridNodes();
    this.filterGridLinks();

    this.joinGroups();
    this.solveProblems();
    this.findMainSubject();
  }

  protected buildGroups(): void {
    // No groups on this level
  }

  protected buildPresentNodes(): void {
    this.widget.data
      .filter(row => row['source'] === row['target'])
      .forEach(row => this.allNodes.push(this.nodeFactory.build(row)));
  }

  protected buildUnknownNodes(): void {
    this.widget.data
      .filter(row => row['source'] !== row['target'])
      .map(row => [row['source'], row['target']])
      .reduce((nodeIds, nodeId) => nodeIds.concat(nodeId), [])
      .filter((nodeId, index, array) => index === array.indexOf(nodeId))
      .filter(nodeId => this.findNode(nodeId) == null)
      .forEach(nodeId => this.allNodes.push(this.nodeFactory.build({source: nodeId, naam: '?'})));
  }

  protected buildLinks(): void {
    this.widget.data
      .filter(row => row['source'] !== row['target'])
      .forEach(row => {
        const source = this.findNode(row['source']);
        const target = this.findNode(row['target']);

        if (source != null && target != null) {
          this.allLinks.push(this.linkFactory.build(source, target, row));
        }
      });
  }

  protected filterGridNodes(): void {
    this.gridNodes = this.allNodes.filter(node => node.model.isConnected() || node.isMain);
    this.hasUnconnectedNodes = this.allNodes.length > this.gridNodes.length;
  }

  protected filterGridLinks(): void {
    this.gridLinks = this.allLinks.filter(link => this.gridNodes.indexOf(link.source) !== -1 && this.gridNodes.indexOf(link.target) !== -1);
    this.hasUnknownLinks = this.allLinks.some(link => link.model.isUnknownType);
  }

  protected joinGroups(): void {
    // No groups on this level
  }

  protected solveProblems(): void {
    this.gridNodes.forEach(node =>  this.removeWeakSiblingsForNode(node));
    this.gridNodes.forEach(node =>  this.solveLoopsForNode(node));
    this.gridNodes.forEach(node =>  this.solveLevelConflictsForNode(node));
  }

  protected findMainSubject(): void {
    this.gridNodes
      .filter(node => node.isMain)
      .forEach(node => this.subject = node);
  }

  protected findNode(id: string): Node<NodeHierarchicalModel, P> {
    for (let index = 0; index < this.allNodes.length; index++) {
      if (this.allNodes[index].id === id) {
        return this.allNodes[index];
      }
    }

    return null;
  }

  protected findLink(newLink: Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>):
      Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R> {
    const direction = newLink.model.direction;

    for (let index = 0; index < this.allLinks.length; index++) {
      const link = this.allLinks[index];

      if ((direction !== LinkDirection.sibling && link.hasMatchingLink(newLink.source, newLink.target)) ||
          (direction === LinkDirection.sibling && link.hasMatchingNodes(newLink.source, newLink.target))) {
        return link;
      }
    }

    return null;
  }

  private removeWeakSiblingsForNode(node: Node<NodeHierarchicalModel, P>): void {
    if (node.model.parentLinks.length > 0 || node.model.childLinks.length > 0) {
      const weakLinks = [];

      for (let index = 0; index < node.model.siblingLinks.length; index++) {
        const siblingLink = node.model.siblingLinks[index];
        const siblingNode = siblingLink.getOtherNode(node);

        if (siblingLink.model.weight === 0 && (siblingNode.model.parentLinks.length > 0 || siblingNode.model.childLinks.length > 0)) {
          weakLinks.push(siblingLink);
        }
      }

      for (let index = 0; index < weakLinks.length; index++) {
        const weakLink = weakLinks[index];
        weakLink.source.model.siblingLinks = weakLink.source.model.siblingLinks.filter(link => link !== weakLink);
        weakLink.target.model.siblingLinks = weakLink.target.model.siblingLinks.filter(link => link !== weakLink);
      }
    }
  }


  private solveLoopsForNode(node: Node<NodeHierarchicalModel, P>): void {
    let loopPath = this.findLoop([node]);
    while (loopPath != null) {
      this.hasBadLinks = true;
      this.removeWeakestLink(loopPath);
      loopPath = this.findLoop([node]);
    }
  }

  private solveLevelConflictsForNode(node: Node<NodeHierarchicalModel, P>): void {
    const siblingNodes = this.findNodesOnSameLevel([node]);
    siblingNodes.shift();

    if (siblingNodes.length > 0) {
      let conflictPath = this.findLevelConflict([node], siblingNodes);
      while (conflictPath != null) {
        this.hasBadLinks = true;
        this.removeWeakestLink(conflictPath);
        conflictPath = this.findLevelConflict([node], siblingNodes);
      }
    }
  }

  private findNodesOnSameLevel(path: Node<NodeHierarchicalModel, P>[]): Node<NodeHierarchicalModel, P>[] {
    const tailNode = path[path.length - 1];
    const siblingLinks = tailNode.model.siblingLinks;

    for (let index = 0; index < siblingLinks.length; index++) {
      const nextNode = siblingLinks[index].getOtherNode(tailNode);

      if (!path.some(node => node === nextNode)) {
        path = this.findNodesOnSameLevel(path.concat([nextNode]));
      }
    }

    return path;
  }

  private findLoop(path: Node<NodeHierarchicalModel, P>[]): Node<NodeHierarchicalModel, P>[] {
    const tailNode = path[path.length - 1];
    const childLinks = tailNode.model.childLinks;

    for (let index = 0; index < childLinks.length; index++) {
      const nextNode = childLinks[index].getOtherNode(tailNode);
      const loopNode = this.findNodeInPath(path, nextNode);
      const nextPath = path.concat([nextNode]);
      const loopPath = loopNode ? nextPath.slice(path.indexOf(nextNode)) : this.findLoop(nextPath);

      if (loopPath != null) {
        return loopPath;
      }
    }

    return null;
  }

  private findLevelConflict(path: Node<NodeHierarchicalModel, P>[], siblingNodes: Node<NodeHierarchicalModel, P>[]): Node<NodeHierarchicalModel, P>[] {
    const tailNode = path[path.length - 1];
    const childLinks = tailNode.model.childLinks;

    for (let index = 0; index < childLinks.length; index++) {
      const nextNode = childLinks[index].getOtherNode(tailNode);
      const conflictNode = this.findNodeInPath(siblingNodes, nextNode);
      const nextPath = path.concat([nextNode]);
      const conflictPath = conflictNode ? nextPath : this.findLevelConflict(nextPath, siblingNodes);

      if (conflictPath != null) {
        return conflictPath;
      }
    }

    return null;
  }

  private removeWeakestLink(path: Node<NodeHierarchicalModel, P>[]): void {
    const links = this.getLinksFromPath(path);
    const weakestLink = this.findWeakestLink(links);

    if (!weakestLink.model.isBadLink) {
      weakestLink.model.isBadLink = true;
      weakestLink.classes.push('link-error');
    }

    weakestLink.source.model.hideLoopLink(weakestLink);
    weakestLink.target.model.hideLoopLink(weakestLink);
  }

  private getLinksFromPath(path: Node<NodeHierarchicalModel, P>[]): Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>[] {
    return path
      .map((node, index, nodes) => node.model.childLinks
          .filter(link => index < (nodes.length - 1) && link.hasMatchingNodes(node, nodes[index + 1])))
      .map(links => links.length > 0 ? links[0] : null)
      .filter(link => link != null);
  }

  private findNodeInPath(path: Node<NodeHierarchicalModel, P>[], node: Node<NodeHierarchicalModel, P>): boolean {
    return path.some(pathNode => pathNode === node);
  }

  private findWeakestLink(links: Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>[]): Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R> {
    return links.reduce((weakestLink, link) => link.model.weight < weakestLink.model.weight ? link : weakestLink, links[0]);
  }

  protected buildGrid(): void {
    const gridLayout = this.gridLayoutManager.build(this.gridNodes);

    this.grid = gridLayout.nodes;
    this.maxLevel = gridLayout.maxLevel;
    this.maxRowSize = gridLayout.maxRowSize;
  }

  protected drawGraph(): void {
    this.calculateCanvasDimensions();
    this.drawBasicSvg();
    this.initializePainters();

    this.drawLinks();
    this.drawNodes();

    this.initializeStyles();
    this.initializeLegendAndFilters();

    this.enableZoomAndPan();
  }

  protected calculateCanvasDimensions(): void {
    const minimumWidth = this.maxRowSize * AbstractHierarchicalGraph.horizontalStep - AbstractHierarchicalGraph.horizontalGap +
      AbstractHierarchicalGraph.leftMargin +
      AbstractHierarchicalGraph.rightMargin;
    const minimumHeight = this.maxLevel * AbstractHierarchicalGraph.verticalStep - AbstractHierarchicalGraph.verticalGap +
      AbstractHierarchicalGraph.topMargin +
      AbstractHierarchicalGraph.bottomMargin;

    this.width = Math.max(minimumWidth, Math.floor(minimumHeight / AbstractHierarchicalGraph.aspectRatio), AbstractHierarchicalGraph.minimumWidth);
    this.height = Math.max(minimumHeight, Math.floor(this.width * AbstractHierarchicalGraph.aspectRatio));
    this.leftMargin = (this.width > minimumWidth) ?
      (AbstractHierarchicalGraph.leftMargin + Math.floor((this.width - minimumWidth) / 2)) : AbstractHierarchicalGraph.leftMargin;
    this.topMargin = AbstractHierarchicalGraph.topMargin;
  }

  protected drawBasicSvg(): void {
    this.canvas = this.d3.select(this.canvasElementRef.nativeElement)
      .append('svg')
      .attr('preserveAspectRatio', 'xMinYMin meet')
      .attr('viewBox', '0 0 ' + this.width + ' ' + this.height)
      .classed('hierarchical-graph', true);

    this.graph = this.canvas.append('g');
    this.linksGroup = this.graph.append('g').classed('link-group', true);
    this.nodesGroup = this.graph.append('g').classed('node-group', true);
    this.nodeTooltipGroup = this.graph.append('g').classed('node-tooltip-group', true);
  }

  protected drawLinks(): void {
   this.linkPainter.drawLinks(this.graph, this.linksGroup, this.gridLinks);
  }

  protected drawNodes(): void {
    this.nodePainter.drawNodes(this.graph, this.nodesGroup, this.gridNodes);
  }

  protected abstract initializePainters(): void;

  protected abstract initializeStyles(): void;

  protected abstract initializeLegendAndFilters(): void;

  protected enableZoomAndPan(): void {
    setTimeout(() => {
      this.zoomCanvas = this.canvas;
      this.zoomElement = this.graph;
      this.size = {width: this.width, height: this.height};
      this.home = this.subject == null ? null : {'x': this.subject.x + this.leftMargin, 'y': this.subject.y + this.topMargin };
    });
  }

  protected changeStyles(elementStyleList: {selector: string, key: string, value: number | string}[]): void {
    elementStyleList.forEach(elementStyle => {
      this.d3.select(this.canvasElementRef.nativeElement)
        .selectAll(elementStyle.selector)
        .transition()
        .style(elementStyle.key, elementStyle.value);
    });
  }

  protected changeClasses(elementClassList: {selector: string, name: string, present: boolean}[]): void {
    elementClassList.forEach(elementClass => {
      this.d3.select(this.canvasElementRef.nativeElement)
        .selectAll(elementClass.selector)
        .classed(elementClass.name, elementClass.present);
    });
  }
}
