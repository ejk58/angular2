import {Node} from '../../../classes/nodes/node';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';

export class Grid {

  constructor (public nodes: Node<NodeHierarchicalModel, any>[][],
      public minWidth: number,
      public minHeight: number,
      public maxLevel: number,
      public maxRowSize: number) {

  }
}
