import {Component, Input} from '@angular/core';

@Component({
  selector: 'i-summary-core-property',
  templateUrl: './summary-core-property.component.html',
  styleUrls: ['./summary-core-property.component.scss']
})
export class SummaryCorePropertyComponent {
  @Input() coreProperty: string;
}
