import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import * as fromSelectors from '../../store/selectors';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {Store} from '@ngrx/store';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-marked-domains',
  templateUrl: './marked-domains.component.html',
  styleUrls: ['./marked-domains.component.scss'],
  providers: [Unsubscriber]
})
export class MarkedDomainsComponent implements OnInit, OnDestroy {

  @Input() widget: any;
  @Input() side: string;
  @Input() widgetId: string;

  private pageMenu: any;

  constructor(private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly util: PageNavigationUtilService,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  public ngOnInit(): void {
    const indicatedPageMenuSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getPageMenuState');
    this.store.select(fromSelectors[indicatedPageMenuSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(menu => this.pageMenu = menu);
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  goToDomain(domain): void {
    this.pageMenu.forEach(page => {
      page.options.forEach(option => {
        if (option.label.toLowerCase() === domain.toLowerCase()) {
          this.util.navigateToPage(this.side, option.key, null, null);
          return;
        }
      });
    });
  }

  domainExists(domain): boolean {
    return this.pageMenu.some(page =>
      page.options.some(option => option.label.toLowerCase() === domain.toLowerCase())
    );
  }
}
