export enum LinkDirection {
  self = 0,
  child = 1,
  parent = 2,
  sibling = 3,
  group = 4
}
