export class DetailItem {
  public label: string;
  public column: string;
  public value: number | string;
  public style: string;
  public valueList: string[] = [];
  public sinceDate: string;
}
