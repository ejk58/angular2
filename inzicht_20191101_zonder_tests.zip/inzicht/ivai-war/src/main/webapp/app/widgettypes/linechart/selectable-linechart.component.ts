import {
  AfterViewInit,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import {XYDataElement} from './xy-data-element';
import {Column} from '../../classes/column';
import {Unsubscriber} from '../../commons/unsubscriber';
import {D3, D3Service} from 'd3-ng2-service';
import {ChartService} from '../../commons/chart.service';
import {TrackingService} from '../../services/tracking.service';
import {SplitViewState} from '../../services/split-view-state.service';
import * as c3 from 'c3';


@Component({
  selector: 'i-selectable-linechart',
  templateUrl: './selectable-linechart.component.html',
  styleUrls: ['./selectable-linechart.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})

export class SelectableLineChartComponent implements OnInit, OnDestroy, AfterViewInit {
  private readonly d3: D3;
  public selLineColumns: { [k: string]: any } = {};
  public selLineData = [];

  private defaultChartHeightPx: number = 480;
  private pointRadius: number = 3;
  private chartHeightPx;
  private chartPaddingLeft = 100;
  private chartPaddingRight = 20;
  private readonly chartPaddingTop = 30;

  @Input() side: string;
  @Input() widgetId: string;
  @Input() data: any;
  @Input() columns: any;
  @Input() options: any;
  @ViewChild('lineChartCanvas', {static: false}) canvasElementRef: ElementRef;

  private readonly dataSet: any = {};
  private axis: any = {};
  private xyUnitOfMeasurementPerLabel: any = {};
  private groupColumnNames: string[];
  private coordinatesColumnNames: string[];
  public allDataSets = [];

  private showExtraYAxis = false;
  private yAxisColored = false;
  private showLegends = true;
  private legends: string[] = [];
  private selectedOption1: string = '';
  private selectedOption2: string = '';

  constructor(private readonly d3Service: D3Service,
              private readonly chartService: ChartService,
              protected readonly trackingService: TrackingService,
              private readonly splitViewState: SplitViewState,
              private readonly unsubscriber: Unsubscriber) {
    this.d3 = d3Service.getD3();
  }

  static createXAxis(xAxisUnit: string): any {
    const xAxis = {};
    if (xAxisUnit === 'DATE') {
      xAxis['type'] = 'timeseries';
      xAxis['tick'] = {};
      xAxis['tick']['format'] = '%e %b %y';
      xAxis['tick']['rotate'] = 0;
    } else {
      xAxis['type'] = 'category';
      xAxis['tick'] = {};
      xAxis['tick']['centered'] = true;
    }
    return xAxis;
  }

  ngOnInit() {
    this.initializeVariables();

    this.showLegends = false;
    if (this.options['defaultValueFirstDropdown']) {
      this.selectedOption1 = this.options['defaultValueFirstDropdown'];
    }
    if (this.options['defaultValueSecondDropdown']) {
      this.selectedOption2 = this.options['defaultValueSecondDropdown'];

    }
    this.recreateColumns();
    this.createDataArray();

    this.columns = this.selLineColumns;
    this.data = this.selLineData;
    this.showExtraYAxis = true;
    this.yAxisColored = true;

    if (this.data.length > 0) {
      this.groupColumnNames = Object.keys(this.columns).filter(columnName => this.columns[columnName].columnType === 'GROUP');
      this.coordinatesColumnNames = Object.keys(this.columns).filter(columnName => this.columns[columnName].columnType === 'COORDINATES');

      this.createDataset();
      this.createAxes();
    }
  }

  private initializeVariables(): void {
    this.chartHeightPx = this.options.chartHeightPx ? this.options.chartHeightPx : this.defaultChartHeightPx;
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  ngAfterViewInit() {
    if (this.data.length > 0) {
      this.drawLinechart();
    }
  }

  private createDataArray(): void {
    let legend: string;
    let xvalue: number;
    let xtype: string;
    let yvalue: number;
    let ytype: string;
    Object.keys(this.data).forEach(dataKey => {
      Object.keys(this.columns).forEach(columnKey => {
        // TODO zodra client 1 weg is een nieuw columnType maken zodat dit robuuster kan. b.v. columnType = 'SET' .
        if (this.columns[columnKey]['columnType'] === 'STRING' && this.columns[columnKey]['columnName'].toLowerCase() === 'post') {
          legend = this.data[dataKey][this.columns[columnKey]['columnName']];
          this.legends.push(legend);
        } else if (this.columns[columnKey]['columnType'] === 'HISTORYMONEY') {
          Object.keys(this.data[dataKey][this.columns[columnKey]['columnName']]).forEach(subColumnKey => {
            if (subColumnKey === 'Jaar')  {
              xvalue = this.data[dataKey][this.columns[columnKey]['columnName']][subColumnKey];
              xtype = 'YEAR';
            } else if (subColumnKey === 'Waarde') {
              yvalue = this.data[dataKey][this.columns[columnKey]['columnName']][subColumnKey];
              ytype = SelectableLineChartComponent.getDataType(this.data[dataKey]['SOORT_DATA']);
              const xyDataElement: XYDataElement = new XYDataElement(legend, xvalue, yvalue, xtype, ytype);
              this.allDataSets.push(xyDataElement);
            }
          });
        }
      });
    });

    this.selLineData = this.filterDataSets();
  }

  private static getDataType(soortData: string): string {
    switch (soortData) {
      case 'bedrag': {
        return 'MONEY';
      }
      case 'percentage': {
        return 'PERCENTAGE';
      }
      case 'getal': {
        return 'NUMBER';
      }
      default: {
        return 'STRING';
      }
    }
  }

  onChangeChartName1(selectOpt?: any) {
    this.trackingService.trackEvent('filter',
      'Filter:' + this.side + '/widget:' + this.widgetId +
      'soort:/1=' + selectOpt + '/2=' + this.selectedOption2, null, null);
    this.selectedOption1 = selectOpt;
    this.filterDataSetsAndRedrawChart();
  }

  onChangeChartName2(selectOpt?: any) {
    this.trackingService.trackEvent('filter',
      'Filter:' + this.side + '/widget:' + this.widgetId +
      'soort:/1=' + this.selectedOption1 + '/2=' + selectOpt, null, null);
    this.selectedOption2 = selectOpt;
    this.filterDataSetsAndRedrawChart();
  }

  getLegends(selectBox: string): string[] {
    if (selectBox === 'first') {
      return this.legends.filter(f => f !== this.selectedOption2);
    } else if (selectBox === 'second') {
      return this.legends.filter(f => f !== this.selectedOption1);
    } else {
      return this.legends;
    }
  }

  private filterDataSets(): any {
    const set1 = this.allDataSets.filter(item => item.setName === this.selectedOption1);
    const set2 = this.allDataSets.filter(item => item.setName === this.selectedOption2);
    return [ ...set1, ...set2];
  }

  private filterDataSetsAndRedrawChart(): void {
    this.data = this.filterDataSets();
    if (this.data.length > 0) {
      this.createDataset();
      this.createAxes();
      this.drawLinechart();
    }
  }

  private recreateColumns(): void {
    this.selLineColumns['setName'] = new Column('setName', 'GROUP', 'Group');
    this.selLineColumns['XYVALUE'] = new Column('XYVALUE', 'COORDINATES', null);
    this.selLineColumns['XYVALUE']['composite'] = true;
  }

  private createDataset(): void {
    const xs: any = {};
    const columns: any[] = [];
    const axes: any = {};
    this.xyUnitOfMeasurementPerLabel = {};
    let groupNr = 1;

    for (let index = 0; index < this.data.length; index++) {
      let groupLabel = null;
      for (const columnName of this.groupColumnNames) {
        groupLabel = this.data[index][columnName];
        if (!xs.hasOwnProperty(groupLabel)) {
          const group = 'x' + groupNr;
          xs[groupLabel] = group;
          columns[group] = [group];
          columns[groupLabel] = [groupLabel];

          if (groupNr % 2 === 0 && this.showExtraYAxis) {
            axes[groupLabel] = 'y2';
          } else {
            axes[groupLabel] = 'y';
          }

          groupNr++;
        }
      }

      for (const columnName of this.coordinatesColumnNames) {
        columns[xs[groupLabel]].push(this.data[index][columnName]['X-value']);
        columns[groupLabel].push(this.data[index][columnName]['Y-value']);
        this.updateXYUnitOfMeasurement(groupLabel, columnName, this.data[index]);
      }
    }

    this.dataSet['xs'] = xs;
    this.dataSet['axes'] = axes;
    this.dataSet['columns'] = [];
    Object.keys(columns).forEach(key => {
      this.dataSet['columns'].push(columns[key]);
    });
  }

  private createAxes(): void {
    if (this.showExtraYAxis) {
      this.chartPaddingRight = 80;
    }

    const xAxisUnit = this.getUnitOfMeasurement('x');
    const yAxisUnit = this.getUnitOfMeasurement('y');
    const xAxis = SelectableLineChartComponent.createXAxis(xAxisUnit);
    const yAxis = this.chartService.createYAxis(yAxisUnit);
    this.chartPaddingLeft = this.chartService.calcYAxisLabelWidthOld(this.dataSet.columns[1], yAxisUnit);

    this.axis = {x: xAxis, y: yAxis};
    if (this.showExtraYAxis) {
      const y2AxisUnit = this.getUnitOfMeasurement('y2');
      this.axis['y2'] = this.chartService.createYAxis(y2AxisUnit);
      this.axis['y2']['show'] = true;
    }
  }

  private drawLinechart(): void {
    const linechart = c3.generate({
      bindto: this.d3.select(this.canvasElementRef.nativeElement),
      padding: {
        left: this.chartPaddingLeft,
        right: this.chartPaddingRight,
        top: this.chartPaddingTop
      },
      data: this.dataSet,
      axis: this.axis,
      tooltip: {
        grouped: false,
        // we need config from c3js to get tooltip_format_value
        contents: function (d, defaultTitleFormat, defaultValueFormat, color) {
          const config = this.config;
          const valueFormat = config.tooltip_format_value || defaultValueFormat;
          let tooltipContent;
          for (let i = 0; i < d.length; i++) {
            if (!(d[i] && (d[i].value || d[i].value === 0))) {
              continue;
            }
            const formattedValue = valueFormat(d[i].value, d[i].ratio, d[i].id, d[i].index);
            const tooltipBackgroundColor = this.levelColor ? this.levelColor(d[i].value) : color(d[i].id);

            tooltipContent = `<div style="
                    background-color:${tooltipBackgroundColor};
                    color: white;
                    padding-left: 15px;
                    padding-right: 15px;
                    border-radius: 3px">${formattedValue}</div>`;
          }
          return tooltipContent;
        }
      },
      legend: {
        show: this.showLegends,
        position: 'inset',
        inset: {
          anchor: 'top-left',
          x: 0,
          y: -this.chartPaddingTop,
          step: 1
        }
      },
      line: {
        connectNull: true
      },
      point: {
        r: this.pointRadius
      },
      size: {
        height: this.chartHeightPx
      },
      color: {
        pattern: this.chartService.chartColors
      },
      zoom: {
        enabled: false
      },
      grid: {
        x: {
          show: false
        },
        y: {
          show: true
        }
      }
    });

    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(sizes => {
        if (sizes != null) {
          linechart.resize();
        }
      });
  }

  private updateXYUnitOfMeasurement(groupLabel: string, coordinateLabel: string, data: any): void {
    this.xyUnitOfMeasurementPerLabel[groupLabel] = {
      xUnity: data[coordinateLabel]['X-type'],
      yUnity: data[coordinateLabel]['Y-type']
    };
  }

  private getUnitOfMeasurement(axisName: string): string {
    switch (axisName) {
      case 'x':
        return this.xyUnitOfMeasurementPerLabel[Object.keys(this.xyUnitOfMeasurementPerLabel)[0]]['xUnity'];
      case 'y':
        return this.xyUnitOfMeasurementPerLabel[Object.keys(this.xyUnitOfMeasurementPerLabel)[0]]['yUnity'];
      case 'y2':
        if (this.xyUnitOfMeasurementPerLabel[Object.keys(this.xyUnitOfMeasurementPerLabel)[1]]) {
          return this.xyUnitOfMeasurementPerLabel[Object.keys(this.xyUnitOfMeasurementPerLabel)[1]]['yUnity'];
        } else {
          return 'NUMBER';
        }
      default:
        return 'NUMBER';
    }
  }
}
