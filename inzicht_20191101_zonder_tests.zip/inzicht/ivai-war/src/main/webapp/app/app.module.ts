import {LOCALE_ID, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {CurrencyPipe, DatePipe, DecimalPipe, registerLocaleData} from '@angular/common';
import localeNl from '@angular/common/locales/nl';

import {ButtonModule} from 'primeng/button';
import {CheckboxModule} from 'primeng/checkbox';
import {RadioButtonModule} from 'primeng/radiobutton';
import {DropdownModule} from 'primeng/dropdown';
import {InputSwitchModule} from 'primeng/inputswitch';
import {MultiSelectModule} from 'primeng/multiselect';
import {ToggleButtonModule} from 'primeng/togglebutton';
import {PaginatorModule} from 'primeng/paginator';
import {AccordionModule} from 'primeng/accordion';
import {SharedModule} from 'primeng/shared';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import {SidebarModule} from 'primeng/sidebar';
import {MenuModule} from 'primeng/menu';
import {DialogModule} from 'primeng/dialog';
import {PanelMenuModule} from 'primeng/panelmenu';
import {InputTextModule} from 'primeng/inputtext';
import {TableModule} from 'primeng/components/table/table';
import {TooltipModule} from 'primeng/components/tooltip/tooltip';

import {StoreModule} from '@ngrx/store';
import {EffectsModule} from '@ngrx/effects';
import {RouterStateSerializer, StoreRouterConnectingModule} from '@ngrx/router-store';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';

import {ClickOutsideModule} from 'ng-click-outside';
import {AngularSplitModule} from 'angular-split';
import {NgPipesModule} from 'ngx-pipes';
import {D3Service} from 'd3-ng2-service';
import {CookieService} from 'ngx-cookie-service';
import {NgIdleModule} from '@ng-idle/core';

import {AppComponent} from './app.component';
import {InzichtRoutingModule} from './app-routing.module';
import {FocusDirective} from './directives/focus.directive';
import {AutofocusDirective} from './directives/autofocus.directive';
import {PageNavigationUtilService} from './commons/page-navigation-util.service';
import {SelectorSideIndicator} from './commons/store-selector-side-indicator';
import {LoggedInGuard} from './components/login/logged-in.guard';
import {NotificationListComponent} from './components/notification-list/notification-list.component';

import * as widgets from './widgettypes';
import * as components from './components';
import * as services from './services';
import * as pipes from './pipes';
import * as fromInzichtStore from './store';
import {ChartService} from './commons/chart.service';
import {ExcelExportUtil} from './commons/excel-export-util';
import {SubjectIconProvider} from './commons/subject-icon-provider';
import {SvgIconProvider} from './commons/svg-icon-provider';

// the second parameter 'nl' is optional
registerLocaleData(localeNl, 'nl');

@NgModule({
  declarations: [
    AppComponent,
    FocusDirective,
    AutofocusDirective,
    ...components.list,
    ...widgets.list,
    ...pipes.list,
    NotificationListComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    InzichtRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AngularSplitModule.forRoot(),
    NgPipesModule,
    ClickOutsideModule,
    BrowserAnimationsModule,
    ButtonModule,
    CheckboxModule,
    DropdownModule,
    InputSwitchModule,
    MultiSelectModule,
    ToggleButtonModule,
    TableModule,
    PaginatorModule,
    AccordionModule,
    SharedModule,
    RadioButtonModule,
    OverlayPanelModule,
    BreadcrumbModule,
    SidebarModule,
    MenuModule,
    DialogModule,
    BreadcrumbModule,
    OverlayPanelModule,
    PanelMenuModule,
    TooltipModule,
    InputTextModule,
    StoreModule.forRoot({}),
    StoreModule.forFeature('inzichtStore', fromInzichtStore.reducers),
    StoreRouterConnectingModule.forRoot(),
    EffectsModule.forRoot([...fromInzichtStore.effects]),
    StoreDevtoolsModule.instrument(),
    NgIdleModule.forRoot()
  ],
  providers: [
    {provide: LOCALE_ID, useValue: 'nl-NL'},
    {provide: RouterStateSerializer, useClass: fromInzichtStore.CustomSerializer},
    D3Service,
    ChartService,
    SubjectIconProvider,
    SvgIconProvider,
    CookieService,
    LoggedInGuard,
    ...services.list,
    ...pipes.list,
    CurrencyPipe,
    DecimalPipe,
    DatePipe,
    PageNavigationUtilService,
    ExcelExportUtil,
    SelectorSideIndicator
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
