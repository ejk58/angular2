package nl.belastingdienst.iva.inzicht.service.subject;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SubjectResponse {

    @XmlElement(name = ResponseKey.MODEL)
    private DataMap model;

    @XmlElement(name = ResponseKey.PRESENTATION)
    private DataMap presentation;

    public void setModel(DataMap model) {
        this.model = model;
    }

    public void setPresentation(DataMap presentation) {
        this.presentation = presentation;
    }
}
