package nl.belastingdienst.iva.inzicht.domain;

public class MessageUtils {

    private MessageUtils() {
        throw new UnsupportedOperationException();
    }
    
    public static String createMessage(MessageType type, String message) {
        return type.getLabel() + ", message = " + message;
    }
    
    public static String createDuration(long duration) {
        return duration <= 120000L ? (Long.toString(duration) + " ms.") : (Long.toString(duration / 1000) + " s.");
    }
}
