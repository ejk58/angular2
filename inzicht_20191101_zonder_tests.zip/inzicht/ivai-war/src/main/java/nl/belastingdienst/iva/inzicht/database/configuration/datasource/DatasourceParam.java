package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_DATASOURCE_PARAM")
public class DatasourceParam {

    @Id
    private Integer id;
    private String key;
    private String value;
    
    public DatasourceParam() {
        // Default constructor
    }
    
    public DatasourceParam(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getId() {
        return this.id;
    }
    
    public String getKey() {
        return this.key;
    }
    
    public String getValue() {
        return this.value;
    }
}
