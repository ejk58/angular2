package nl.belastingdienst.iva.inzicht.engine.condition;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class AnyQueryValueEqualsCondition implements Condition {

	public static final String NAME = "AnyQueryValueEquals";

	private String queryValueKey;
	private String value;
	
	public AnyQueryValueEqualsCondition(String queryValueKey, String value) {
		this.queryValueKey = queryValueKey;
		this.value = value;
	}
	
	@Override
	public boolean test(RestCallContext restCallContext) {
		MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
		List<?> queryValueValues = queryValues.get(this.queryValueKey);
		return queryValueValues == null ? false : queryValueValues.stream().anyMatch(queryValueValue -> this.value.equals(queryValueValue));
	}

	@Override
	public String getCondition() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.queryValueKey + RulesEngineKey.PARAMETERSEPARATOR + this.value + RulesEngineKey.PARAMETEREND;
	}
}
