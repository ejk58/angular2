package nl.belastingdienst.iva.inzicht.domain.vip;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class VipUtils {

    public static final String VIP_MASK = "######";

    private static final String VIP_COLUMNNAME = "vip_ind";
    private static final String VIP_OLDCOLUMNNAME = "IS_VIP";
    private static final Integer VIP_FLAG = 1;

    private VipUtils() {
        throw new UnsupportedOperationException();
    }
    
    public static boolean detectVipMaskRow(DataMap dataMap) {
        return dataMap.containsKey(VIP_COLUMNNAME) && VIP_FLAG.equals(dataMap.get(VIP_COLUMNNAME)) ||
                dataMap.containsKey(VIP_OLDCOLUMNNAME) && VIP_FLAG.equals(dataMap.get(VIP_OLDCOLUMNNAME));
    }
}
