package nl.belastingdienst.iva.inzicht.domain.query;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;

public enum QueryParameterType {
    
    FISCALNUMBER("fiscalnumber", QueryValueKey.FISCALNR, true) {
        @Override
        public boolean validate(String value) {
            return StringUtils.isNotEmpty(value) && StringUtils.isNumeric(value) && (value.length() <= 9);
        }
    },
    ENTITYNUMBER("entitynumber", QueryValueKey.ENTITYNR, true) {
        @Override
        public boolean validate(String value) {
            return StringUtils.isNotEmpty(value) && StringUtils.isNumeric(value);
        }
    },
	NUMBER("number", null, true) {
		@Override
		public boolean validate(String value) {
			return StringUtils.isNotEmpty(value) && StringUtils.isNumeric(value);
		}
	},
    DATE("date", null, true) {
        private transient Pattern datePattern = Pattern.compile("\\d{4}-[01]\\d-[0-3]\\d");
        private transient ThreadLocal<SimpleDateFormat> dateParser = ThreadLocal.withInitial(() -> {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            simpleDateFormat.setLenient(false);
            return simpleDateFormat;
        });
        
        @Override
        public boolean validate(String value) {
            boolean valid = StringUtils.isNotEmpty(value) && (value.length() == 10);
            
            if (valid) {
                Matcher dateMatcher = datePattern.matcher(value);
                valid = dateMatcher.matches();
            }
            
            if (valid) {
                try {
                    this.dateParser.get().parse(value);
                    return true;
                } catch (ParseException exception) {
                    return false;
                }                
            }
            
            return valid;
        }
    },
	YEAR("year", null, true) {
		@Override
		public boolean validate(String value) {
			return StringUtils.isNotEmpty(value) && StringUtils.isNumeric(value) && (Integer.parseInt(value) < 10000);
		}
	},
	STRING("string", null, true),
	RESTSTRING("reststring", null, true),
    LISTOFNUMBERS("list-of-numbers", null, false) {
	    @Override
        public boolean validate(String value) {
            return QueryParameterType.NUMBER.validate(value);
        }
    },
	LISTOFSTRINGS("list-of-strings", null, false),
	CONFIG("config", null, true),
	FILTER("filter", null, true);

	private String name;
	private String permissionKey;
	private boolean singleValue;
	
	private QueryParameterType(String name, String permissionKey, boolean singleValue) {
		this.name = name;
		this.permissionKey = permissionKey;
		this.singleValue = singleValue;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getPermissionKey() {
		return this.permissionKey;
	}
	
	public boolean isSingleValue() {
		return this.singleValue;
	}
	
	public boolean isConfigurationValue() {
		return this == CONFIG;
	}
	
	public boolean isPermissionValue() {
		return this.permissionKey != null;
	}
	
	public boolean validate(String value) {
		return StringUtils.isNotEmpty(value);
	}
	
    public boolean validateAll(List<String> valueList) {
        return (valueList == null) ? false : valueList.stream().allMatch(this::validate);
    }
    
	public static QueryParameterType findType(String parameterType) {
		for (QueryParameterType type : QueryParameterType.values()) {
			if (type.name.equalsIgnoreCase(parameterType)) {
				return type;
			}
		}
		
		return null;
	}
}
