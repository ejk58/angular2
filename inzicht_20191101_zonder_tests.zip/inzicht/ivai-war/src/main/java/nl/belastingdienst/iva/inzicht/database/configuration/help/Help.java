package nl.belastingdienst.iva.inzicht.database.configuration.help;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

@Entity
@Table(name = "CONF_HELP")
public class Help {

    @Id
    private int id;

    private String key;
    private String title;
    private String content;

    @JsonIgnore
    public Integer getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}
