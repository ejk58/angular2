package nl.belastingdienst.iva.inzicht.configuration;

import java.util.List;
import java.util.Map;
import java.util.Set;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;

public interface Configuration {

    Set<DomainRole> getApplicationRoles();

    Map<String, Object> getKeyValueMap();
    Object getValue(String key);
    String getValueAsString(String key);
    Integer getValueAsNumber(String key);
    Boolean getValueAsBoolean(String key);

    Map<String, AttributeGroup> getAttributeGroupMap();
    AttributeGroup getAttributeGroup(String attributeGroupKey);
    Map<String, RuleGroup> getRuleGroupMap();
    RuleGroup getRuleGroup(String ruleGroupKey);
    
    List<String> getDomainKeys();
    Domain findDomain(String domainKey);
    List<Domain> findDomainsPerRole(DomainRole role);

    Page findPage(String pageKey);
    List<Page> findPagesByDomain(String domainKey);

    Widget findWidget(String widgetName);
    
    Datasource getTeradataDatasource();
    Datasource getMihProxyDatasource();
    Datasource getJiraFeedbackDatasource();
}
