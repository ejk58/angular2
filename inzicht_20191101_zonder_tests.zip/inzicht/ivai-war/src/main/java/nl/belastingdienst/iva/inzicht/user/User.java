package nl.belastingdienst.iva.inzicht.user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class User {

    private String name;
    private Set<String> roles;
    private String ltpaToken;

    public User(String name, Set<String> roles, String ltpaToken) {
        this.name = name;
        this.roles = roles == null ? Collections.<String>emptySet() : new HashSet<>(roles);
        this.ltpaToken = ltpaToken;
    }

    public String getName() {
        return this.name;
    }

    public List<String> getRoles() {
        return new ArrayList<>(this.roles);
    }

    public String getLtpaToken() {
        return this.ltpaToken;
    }
    
    public boolean hasName(String name) {
        return this.name == null ? false : this.name.equals(name);
    }

    public boolean hasRole(String role) {
        return this.roles.contains(role);
    }

    @Override
    public int hashCode() {
        return (this.name == null) ? 0 : this.name.hashCode();
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        
        if (object == null || getClass() != object.getClass() || this.name == null) {
            return false;
        }
        
        User otherUser = (User) object;
        return this.name.equals(otherUser.name);
    }
}
