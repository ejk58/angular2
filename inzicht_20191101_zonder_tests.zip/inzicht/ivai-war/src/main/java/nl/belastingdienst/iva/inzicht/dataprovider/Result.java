package nl.belastingdienst.iva.inzicht.dataprovider;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;

public class Result {

	private DataMap[] data;
	
	public Result() {
		this.data = DomainUtils.emptyDataMapArray();
	}

	public Result(DataMap[] data) {
		this.data = data;
	}

	public DataMap[] getData() {
		return data;
	}

	public void setData(DataMap[] data) {
		this.data = data;
	}
	
	public void addData(DataMap[] data) {
		int dataSize = this.data.length;
		int newDataSize = this.data.length + data.length;
		DataMap[] newData = new DataMap[newDataSize];
		
		for (int index = 0; index < newDataSize; index++) {
			newData[index] = (index < dataSize ? this.data[index] : data[index - dataSize]);
		}
		
		this.data = newData;
	}
}
