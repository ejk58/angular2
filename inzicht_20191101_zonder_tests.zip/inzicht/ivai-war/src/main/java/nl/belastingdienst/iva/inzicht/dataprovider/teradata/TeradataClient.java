package nl.belastingdienst.iva.inzicht.dataprovider.teradata;

import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractHttpServiceClient;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProviderClient;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.dataprovider.sql.SqlQuery;
import nl.belastingdienst.iva.inzicht.dataprovider.sql.SqlQueryFactory;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.JsonDataMapParser;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContextFactory;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;

@Typed(TeradataClient.class)
public class TeradataClient extends AbstractHttpServiceClient implements DataProviderClient {

	private static final String DATASOURCENAME = "Teradata";
	private static final String DATAPATH = "results/[0]/data";
	private static final String QUERYPREFIX = "{\"rowLimit\": \"0\", \"query\": \"";
	private static final String QUERYPOSTFIX = "\"}";
    
    private static final Logger logger = Logger.getLogger(TeradataClient.class);

    @Inject
    private RestCallContextFactory restCallContextFactory;
    
    @Inject
    private SqlQueryFactory sqlQueryFactory;
    
    @Inject
    private ConfigurationFactory configurationFactory;

    @Inject
    private JsonDataMapParser jsonDataMapParser;
    
    @Override
    public Result retrieveData(QueryInterface query, RestCallContext restCallContext) {
        SqlQuery sqlQuery = prepareQuery(query, restCallContext);
        String resultSet = postQuery(sqlQuery, restCallContext);
        return new Result(processResultSet(resultSet));
    }

    public Result retrieveDataAsMultiMap(QueryInterface query, Configuration configuration, MultivaluedMap<String, String> queryValues) {
    	RestCallContext restCallContext = this.restCallContextFactory.getRestCallContext(RestServiceType.NONE, queryValues, configuration);
    	return retrieveData(query, restCallContext);
    }

    public JsonNode retrieveDataAsJson(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Configuration configuration = this.configurationFactory.getConfiguration();
    	RestCallContext restCallContext = this.restCallContextFactory.getRestCallContext(RestServiceType.NONE, queryValues, configuration);
        SqlQuery sqlQuery = prepareQuery(query, restCallContext);
        String resultSet = postQuery(sqlQuery, restCallContext);
        return extractResultSet(resultSet);
    }

    private SqlQuery prepareQuery(QueryInterface query, RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        Datasource datasource = query.hasDatasource() ? query.getDatasource() : configuration.getTeradataDatasource(); 
        Map<String, String> configurationValues = this.sqlQueryFactory.buildConfigurationValues(datasource, configuration);
        return this.sqlQueryFactory.getSqlQuery(datasource, query, queryValues, configurationValues);
    }

    private String postQuery(SqlQuery sqlQuery, RestCallContext restCallContext) {
        Datasource datasource = sqlQuery.getDatasource();

        if (datasource.getBoolean(DatasourceKey.QUERYEXPLAINMONITOR)) {
        	explainTeradataQuery(sqlQuery, restCallContext);
        }
        
        return callTeradataQuery(sqlQuery, restCallContext, true);
    }
    
    private DataMap[] processResultSet(String response) {
    	return this.jsonDataMapParser.parseJsonResult(DATASOURCENAME, DATAPATH, response);
    }

    private JsonNode extractResultSet(String response) {
    	return this.jsonDataMapParser.extractJsonResult(DATASOURCENAME, DATAPATH, response);
    }

    private String callTeradataQuery(SqlQuery sqlQuery, RestCallContext restCallContext, boolean retryOnTimeout) {
        Datasource datasource = sqlQuery.getDatasource();
        String requestUrl = datasource.getValue(DatasourceKey.RESTURL);
        String query = QUERYPREFIX + sqlQuery.getQuery() + QUERYPOSTFIX;
        String queryDescription = "(query = '" + query + "')";
        CloseableHttpClient httpClient = datasource.getHttpClient();
        HttpPost httpPost = createPostRequest(datasource, requestUrl, query, restCallContext);
        long slowExecutionThreshold = datasource.getNumber(DatasourceKey.SLOWEXECUTIONTIME);
        String result = null;

        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
            long before = System.currentTimeMillis();
        	
            handleHttpStatusCode(response, DATASOURCENAME, queryDescription);
           	result = EntityUtils.toString(response.getEntity());
           	
            long duration = System.currentTimeMillis() - before;
            if (duration > slowExecutionThreshold) {
                logger.warn(MessageUtils.createMessage(MessageType.WARNING, "Slow query (" + duration + "ms) on Teradata " + queryDescription));
            }
        } catch (SocketTimeoutException exception) {
        	if (retryOnTimeout) {
        		logger.warn(MessageUtils.createMessage(MessageType.WARNING, "Retry for query on Teradata after time-out exception " + 
        				ExceptionUtils.getExceptionsForMessage(exception) + " " + queryDescription));
        		result = callTeradataQuery(sqlQuery, restCallContext, false);
        	} else {
        		handleException(exception, DATASOURCENAME, queryDescription);
        	}
        } catch (Exception exception) {
       		handleException(exception, DATASOURCENAME, queryDescription);
        }

        return result;
    }

    private boolean explainTeradataQuery(SqlQuery sqlQuery, RestCallContext restCallContext) {
        Datasource datasource = sqlQuery.getDatasource();
        String requestUrl = datasource.getValue(DatasourceKey.RESTURL);
        String query = QUERYPREFIX + "EXPLAIN " + sqlQuery.getQuery() + QUERYPOSTFIX;
        String queryDescription = "(explain query = '" + query + "')";
        CloseableHttpClient httpClient = datasource.getHttpClient();
        HttpPost httpPost = createPostRequest(datasource, requestUrl, query, restCallContext);

        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
            handleHttpStatusCode(response, DATASOURCENAME, queryDescription);
           	String result = EntityUtils.toString(response.getEntity());
           	return monitorExplainResult(queryDescription, result);
        } catch (Exception exception) {
    		logger.warn(MessageUtils.createMessage(MessageType.WARNING, "Failed to run the explain-query on Teradata with exception " + 
    				ExceptionUtils.getExceptionsForMessage(exception) + " " + queryDescription));
        }
        
        return false;
    }
    
    private boolean monitorExplainResult(String queryDescription, String result) {
       	DataMap[] explanation = processResultSet(result);
        String fullExplanation = explanation == null ? "" : 
        		Arrays.asList(explanation).stream().map(explanationRow -> (String) explanationRow.get("Explanation")).collect(Collectors.joining(" "));
        boolean allAmpWarning = fullExplanation.indexOf("all-AMP") >= 0;
        
        if (allAmpWarning) {
        	logger.warn(MessageUtils.createMessage(MessageType.WARNING, "The Teradata-query is probably not single-amp " + 
        			queryDescription + " with explanation: " + fullExplanation));
        }

        return allAmpWarning;
    }
}
