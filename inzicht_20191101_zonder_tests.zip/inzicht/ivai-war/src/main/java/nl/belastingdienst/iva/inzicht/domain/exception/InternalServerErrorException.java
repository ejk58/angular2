package nl.belastingdienst.iva.inzicht.domain.exception;

import javax.ejb.ApplicationException;

@ApplicationException
public class InternalServerErrorException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    
    public InternalServerErrorException(String message) {
        super(message);
    }
    
    public InternalServerErrorException(String message, Throwable exception) {
        super(message, exception);
    }
}
