package nl.belastingdienst.iva.inzicht.dataprovider.internal;

import javax.inject.Inject;
import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.dataprovider.DataProviderClient;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.JsonDataMapParser;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class InternalClient implements DataProviderClient {

    @Inject
    private InternalQueryFactory internalQueryFactory;
    
    @Inject
    private JsonDataMapParser jsonDataMapParser;
    
    @Override
    public Result retrieveData(QueryInterface query, RestCallContext restCallContext) {
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        String resultQuery = this.internalQueryFactory.getInternalQuery(query, queryValues);
    	return new Result(processResult(resultQuery)); 
    }

    private DataMap[] processResult(String resultQuery) {
        DataMap[] result;
        
        if (resultQuery == null) {
            result = createEmptyResult();
        } else if (resultQuery.startsWith("{") || resultQuery.startsWith("[")) {
            result = parseJsonResult(resultQuery);
        } else {
            result = splitStringResult(resultQuery);
        }

        return result;
    }
    
    private DataMap[] splitStringResult(String response) {
        DataMap result = new DataHashMap();
        String[] parameterList = response.split(";");

        for (String parameter : parameterList) {
            int index = parameter.indexOf(':');
            if (index > 0) {
                String key = parameter.substring(0, index).trim();
                String value = parameter.substring(index + 1).trim();
                result.put(key, value);
            }
        }
        
        return DomainUtils.inArray(result);
    }
    
    private DataMap[] parseJsonResult(String response) {
    	return this.jsonDataMapParser.parseJsonResult("internal (no datasource)", response);
    }
    
    private DataMap[] createEmptyResult() {
        return DomainUtils.emptyDataMapArray();
    }
}
