package nl.belastingdienst.iva.inzicht.domain.key;

public class ResponseKey {

    public static final String NAME = "name";
    public static final String TYPE = "type";
    public static final String MODEL = "model";
    public static final String PRESENTATION = "presentation";
    public static final String TITLE = "title";
    public static final String LABEL = "label";
    public static final String REMARK = "remark";
    public static final String OPTIONS = "options";
    public static final String COLUMNS = "columns";
    public static final String WIDGETS = "widgets";
    public static final String HELPTEXTS = "helpTexts";
    public static final String DESCRIPTION = "description";
    public static final String DESCRIPTIONMORE = "descriptionMore";
    public static final String DATA = "data";
    public static final String REFRESHINFO = "refreshInfo";
    public static final String CONTENT = "content";
    public static final String COLUMNNAME = "columnName";
    public static final String COLUMNTYPE = "columnType";
    public static final String BEHAVIOUR = "behaviour";
    public static final String FILTER = "filter";
    public static final String MASKABLE = "maskable";
    public static final String COMPOSITE = "composite";

    public static final String ITEMSPERPAGE = "itemsPerPage";
    public static final String VISIBLE = "visible";
    
    public static final String DOMAINS = "domains";
    public static final String ATTRIBUTES = "attributes";
    public static final String DOMAINID = "domainId";
    public static final String PATHKEYS = "pathKeys";
    public static final String MANDATORYPATHKEYS = "mandatoryPathKeys";
    public static final String SUBJECTTYPES = "subjectTypes";
    public static final String INITIALPAGEID = "initPageId";
    public static final String ICONNAME = "iconName";
    public static final String KEY = "key";
    public static final String MACHINENAME = "machineName";
    public static final String INDEX = "index";
    public static final String IMPORTANT = "important";

    public static final String MENUOPTIONS = "menuOptions";
    public static final String PAGES = "pages";
    public static final String ROWS = "rows";
    
    public static final String SUBJECTNR = "subjectNr";
    public static final String RELATIONTYPE = "relationType";
    public static final String TAXYEARS = "taxYears";
    public static final String MAIN = "main";
    public static final String VIP = "vip";
    public static final String IMPORTANTDOMAINS = "importantDomains";
    public static final String UWBCODES = "uwbCodes";
    public static final String ICON = "icon";
    public static final String ISMAIN = "isMain";

    public static final String VERSION = "version";
    public static final String CONFIGURATION = "configuration";
    public static final String USER = "user";
    public static final String USERNAME = "username";
    public static final String ROLE = "role";
    public static final String PERMISSION = "permission";
    public static final String SERVERNAME = "serverName";
    public static final String COMPONENTS = "components";
    public static final String ALIVE = "alive";

    public static final String TEXT = "text";
    public static final String COLOR = "color";
    public static final String BACKGROUNDCOLOR = "backgroundColor";
    
    private ResponseKey() {
        throw new UnsupportedOperationException();
    }
}
