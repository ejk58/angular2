package nl.belastingdienst.iva.inzicht.dataprovider.teradata;

import java.util.List;

import javax.enterprise.inject.Typed;
import javax.ws.rs.core.MultivaluedMap;

import org.codehaus.jackson.JsonNode;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@Typed(TeradataVipCheckClient.class)
public class TeradataVipCheckClient extends TeradataClient {

    private static final String VIPCOLUMN = "vip"; 
    private static final String VIPINDICATOR = "1"; 
	
    public boolean isNotVip(RestCallContext restCallContext) {
    	MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        Configuration configuration = restCallContext.getConfiguration();
    	QueryInterface query = getVipQuery(configuration);
        JsonNode data = retrieveDataAsJson(query, queryValues);
        List<String> vipData = data.findValuesAsText(VIPCOLUMN);
        return !vipData.isEmpty() && !VIPINDICATOR.equals(vipData.get(0));
    }
    
    private QueryInterface getVipQuery(Configuration configuration) {
    	String viewName = configuration.getValueAsString(ConfigurationKey.TERADATAVIPVIEWNAME);
    	String query = configuration.getValueAsString(ConfigurationKey.TERADATAVIPSQLQUERY);
        return new TeradataQuery(viewName, query);
    }
}
