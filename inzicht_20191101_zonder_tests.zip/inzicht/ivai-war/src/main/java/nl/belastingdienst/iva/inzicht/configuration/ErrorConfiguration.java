package nl.belastingdienst.iva.inzicht.configuration;

import java.util.Collections;
import java.util.List;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;

public class ErrorConfiguration extends DefaultConfiguration implements Configuration {

    public ErrorConfiguration() {
        setAttributeGroupMap(Collections.<String, AttributeGroup>emptyMap());
        setRuleGroupMap(Collections.<String, RuleGroup>emptyMap());
        setDomainKeyList(Collections.<String>emptyList());
        setDomainMap(Collections.<String, Domain>emptyMap());
        setDomainsPerRoleMap(Collections.<DomainRole, List<Domain>>emptyMap());
        setPageMap(Collections.<String, Page>emptyMap());
        setPagesByDomainMap(Collections.<String, List<Page>>emptyMap());
        setWidgetMap(Collections.<String, Widget>emptyMap());
    }
}
