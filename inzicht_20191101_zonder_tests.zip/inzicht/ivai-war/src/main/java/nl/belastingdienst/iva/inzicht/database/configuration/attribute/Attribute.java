package nl.belastingdienst.iva.inzicht.database.configuration.attribute;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_ATTRIBUTE")
public class Attribute {

    @Id
	private Integer id;
	
	private String key;
	private Integer index;
	private String value;
	
	public Integer getId() {
		return this.id;
	}
	
	public String getKey() {
		return this.key;
	}
	
	public Integer getIndex() {
		return this.index;
	}
	
	public String getValue() {
		return this.value;
	}
}
