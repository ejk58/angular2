package nl.belastingdienst.iva.inzicht.engine.condition;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class AndCondition implements Condition {

	private List<? extends Condition> conditions;

	public AndCondition(List<? extends Condition> conditions) {
		this.conditions = conditions;
	}
	
	@Override
	public boolean test(RestCallContext restCallContext) {
		return !this.conditions.isEmpty() && this.conditions.stream().allMatch(condition -> condition.test(restCallContext));
	}
	
	@Override
	public String getCondition() {
		return this.conditions.stream().map(Condition::getCondition).collect(Collectors.joining(" " + RulesEngineKey.ANDCONDITIONOPERATOR + " "));
	}
}
