package nl.belastingdienst.iva.inzicht.dataprovider;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;

import javax.ws.rs.core.MediaType;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.AbstractHttpMessage;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.CredentialsType;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.GatewayTimeoutException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.User;

public abstract class AbstractHttpServiceClient {

	private static final String HTTPHEADER_COOKIE = "Cookie";
	private static final String ACCEPTHEADER_TERADATA = "application/vnd.com.teradata.rest-v1.0+json";
	
	public HttpGet createGetRequest(Datasource datasource, String requestUrl, RestCallContext restCallContext) {
        HttpGet getRequest = new HttpGet(requestUrl);
        return addHeaders(getRequest, datasource, restCallContext);
    }

	public HttpPost createPostRequest(Datasource datasource, String requestUrl, String payload, RestCallContext restCallContext) {
		HttpPost postRequest = new HttpPost(requestUrl);
		
		try {
			postRequest.setEntity(new StringEntity(payload, datasource.getValue(DatasourceKey.TERADATASCHEMA) == null ? HTTP.UTF_8 : HTTP.UTF_16));
		} catch (UnsupportedEncodingException exception) {
	        String message = "Failed to encode the payload for the post-request with an encoding exception " + 
	                ExceptionUtils.getExceptionsForMessage(exception) + 
	                " (requestUrl = " + requestUrl + ", payload = " + payload + ")";
	        throw new InternalServerErrorException(message, exception);
		}
		
		return addHeaders(postRequest, datasource, restCallContext);
	}
	
	private <T extends AbstractHttpMessage> T addHeaders(T httpRequest, Datasource datasource, RestCallContext restCallContext) {
        CredentialsType credentialsType = CredentialsType.findCredentialsType(datasource.getValue(DatasourceKey.CREDENTIALSTYPE));
        String wsaAddress = datasource.getValue(DatasourceKey.WSAADDRESSHEADER);

        httpRequest.setHeader(HttpHeaders.ACCEPT, datasource.getValue(DatasourceKey.TERADATASCHEMA) == null ? MediaType.APPLICATION_JSON : ACCEPTHEADER_TERADATA);
        httpRequest.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON + (datasource.getValue(DatasourceKey.TERADATASCHEMA) == null ? "" : ";charset=utf-16"));
        
        if (credentialsType != null && credentialsType.isHttpHeader()) {
            String credentialsValue = datasource.getValue(DatasourceKey.CREDENTIALSVALUE);
            httpRequest.setHeader(credentialsType.getKey(), credentialsValue);
        }

        if (credentialsType != null && credentialsType.isCookie()) {
            if (credentialsType == CredentialsType.LTPATOKEN || credentialsType == CredentialsType.LTPA2TOKEN) {
            	if (restCallContext == null || restCallContext.getUser() == null) {
                    String message = "Failed to create an LTPA-token cookie for  " + datasource.getKey() + " due to missing user data.";
                    throw new InternalServerErrorException(message);
            	}
            	
            	User user = restCallContext.getUser();
                String credentialsKey = credentialsType.getKey();
                String credentialsValue = user.getLtpaToken();
                httpRequest.setHeader(HTTPHEADER_COOKIE, credentialsKey + "=" + credentialsValue);
            }
        }

        if (wsaAddress != null) {
            httpRequest.setHeader("X_WSA_ADDRESS_X", wsaAddress);
        }
		
		return httpRequest;
	}
	
	public void handleHttpStatusCode(HttpResponse response, String datasourceName, String requestDescription) {
		int statusCode = response.getStatusLine().getStatusCode();
		String reasonPhrase = response.getStatusLine().getReasonPhrase();
		
		if (statusCode >= 400) {
			try {
				String message = "Failed to retrieve data from " + datasourceName + " with status code " + statusCode + 
						", reason '" + reasonPhrase + "', and response '" + EntityUtils.toString(response.getEntity()) + "' " + 
						requestDescription;
	            throw new BadGatewayException(message);
			} catch (ParseException | IOException | IllegalArgumentException exception) {
				String message = "Failed to retrieve data from " + datasourceName + " with status code " + statusCode + 
						", reason '" + reasonPhrase + "', and a response that could not be decoded " + requestDescription;
	            throw new BadGatewayException(message);
			}
		}
	}

	public void handleException(Exception exception, String datasourceName, String requestDescription) {
		if (exception instanceof ConnectException) {
	        String message = "Failed to connect to " + datasourceName + " with an exception " + 
	                ExceptionUtils.getExceptionsForMessage(exception) + " " + requestDescription;
	        throw new BadGatewayException(message, exception);
		} else if (exception instanceof SocketTimeoutException) {
			String message = "Failed to retrieve data from " + datasourceName + " with a time-out exception " + 
					ExceptionUtils.getExceptionsForMessage(exception) + " " + requestDescription;
			throw new GatewayTimeoutException(message, exception);
		} else if (exception instanceof IOException) {
			String message = "Failed to retrieve data from " + datasourceName + " with an I/O exception " + 
					ExceptionUtils.getExceptionsForMessage(exception) + " " + requestDescription;
			throw new BadGatewayException(message, exception);
		} else if (exception instanceof BadGatewayException) {
			throw (BadGatewayException) exception;
		} else if (exception instanceof InternalServerErrorException) {
			throw (InternalServerErrorException) exception;
		} else {
	        String message = "Failed to retrieve data from " + datasourceName + " with an unexpected exception " + 
	                ExceptionUtils.getExceptionsForMessage(exception) + " " + requestDescription;
	        throw new InternalServerErrorException(message, exception);
		}
	}
}
