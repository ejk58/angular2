package nl.belastingdienst.iva.inzicht.service.feedback;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageWidget;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.jira.Feedback;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.jira.JiraFeedbackClient;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/feedback")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class FeedbackService extends AbstractRestService {

    @Inject
    private JiraFeedbackClient jiraFeedbackClient;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    public Response saveFeedback(Feedback feedback) {
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.FEEDBACKSAVESERVICE);
        
        try {
	        this.jiraFeedbackClient.run(feedback, restCallContext);
        	return buildResponse(restCallContext);
        } catch (Exception exception) {
        	return handleException(exception, restCallContext);
        }
    }
    
    @GET
    @Path("/widgets")
    @Produces({MediaType.APPLICATION_JSON})
    public Response getWidgetNames(@Context UriInfo uriInfo) {
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.FEEDBACKLOADSERVICE, uriInfo.getQueryParameters());

        try {
            Page page = restCallContext.findPage();
            DataMap response = new DataHashMap();
            response.put(ResponseKey.WIDGETS, getWidgetNames(page));
            restCallContext.setResponse(response);
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
    
    private List<String> getWidgetNames(Page page) {
    	List<String> widgetNames = new ArrayList<>();
    	
    	for (PageWidget pageWidget : page.getPageWidgets()) {
    		Widget widget = pageWidget.getWidget();
    		if (!widget.getType().endsWith("Filter")) {
    			widgetNames.add(widget.getTitle() != null ? widget.getTitle() : widget.getName());
    		} else {
        		widgetNames.addAll(getInnerWidgetNames(widget));
    		}
    	}
    	
		return widgetNames;
	}
    
    private List<String> getInnerWidgetNames(Widget widget) {
    	List<String> widgetNames = new ArrayList<>();

    	for (Widget innerWidget : widget.getWidgetList()) {
    		if (!innerWidget.getType().endsWith("Filter")) {
    			widgetNames.add(innerWidget.getTitle() != null ? innerWidget.getTitle() : innerWidget.getName());
    		} else {
        		widgetNames.addAll(getInnerWidgetNames(innerWidget));
    		}
    	}
    	
    	return widgetNames;
    }
}
