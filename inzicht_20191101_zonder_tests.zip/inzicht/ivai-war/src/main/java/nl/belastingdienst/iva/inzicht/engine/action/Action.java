package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public interface Action {

	Flow execute(RestCallContext restCallContext);
	String getAction();
}
