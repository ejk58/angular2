package nl.belastingdienst.iva.inzicht.service.widget;

import java.util.List;

import javax.enterprise.inject.Typed;

import nl.belastingdienst.iva.inzicht.database.configuration.help.Help;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.WidgetAttribute;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.WidgetColumn;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.WidgetHelp;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@Typed(WidgetMapper.class)
public class WidgetMapper {

    public DataMap map(Widget widget, Result result) {
    	DataMap[] data = result.getData();
        DataMap widgetResponse = new DataHashMap();

        widgetResponse.put(ResponseKey.NAME, widget.getName());
        widgetResponse.put(ResponseKey.TYPE, widget.getType());
        widgetResponse.put(ResponseKey.OPTIONS, mapOptions(widget));
        widgetResponse.put(ResponseKey.DATA, data);

        return widgetResponse;
    }

    private DataMap mapOptions(Widget widget) {
        List<WidgetAttribute> widgetAttributes = widget.getAttributeList();
        DataMap options = new DataHashMap();
        
        options.put(ResponseKey.TITLE, widget.getTitle());
        options.put(ResponseKey.LABEL, widget.getTitle());
        options.put(ResponseKey.DESCRIPTION, widget.getDescription());
        options.put(ResponseKey.DESCRIPTIONMORE, widget.getDescriptionMore());
        options.put(ResponseKey.COLUMNS, mapColumns(widget.getColumnList()));
        options.put(ResponseKey.HELPTEXTS, mapHelpTexts(widget.getHelpList()));
        options.put(ResponseKey.WIDGETS, mapWidgets(widget.getWidgetList()));
        options.put(ResponseKey.REFRESHINFO, widget.getRefreshInfoMap());

        for (WidgetAttribute widgetAttribute : widgetAttributes) {
            options.put(widgetAttribute.getKey(), widgetAttribute.getValue());
        }

        if (!options.containsKey(ResponseKey.ITEMSPERPAGE)) {
            options.put(ResponseKey.ITEMSPERPAGE, 0);
        }
        
        return options;
    }
    
    private DataMap mapColumns(List<WidgetColumn> widgetColumns) {
        DataMap columns = new DataHashMap();

        for (WidgetColumn widgetColumn : widgetColumns) {
            QueryColumn queryColumn = widgetColumn.getQueryColumn();
            DataMap column = new DataHashMap();
            String columnName = queryColumn == null ? widgetColumn.getLabel() : queryColumn.getDestinationKey();
            
            column.put(ResponseKey.COLUMNNAME, columnName);
            column.put(ResponseKey.COLUMNTYPE, widgetColumn.getType());
            column.put(ResponseKey.LABEL, widgetColumn.getLabel());
            column.put(ResponseKey.DESCRIPTION, widgetColumn.getDescription());
            column.put(ResponseKey.BEHAVIOUR, widgetColumn.getBehaviour());
            column.put(ResponseKey.FILTER, widgetColumn.getFilter());
            column.put(ResponseKey.MASKABLE, queryColumn == null ? false : queryColumn.isMaskable());
            column.put(ResponseKey.COMPOSITE, queryColumn == null ? false : queryColumn.isComposite());
            
            widgetColumn.getColumnAttributes().forEach(attribute -> column.put(attribute.getKey(), attribute.getValue()));
            columns.put(columnName, column);
        }

        return columns;
    }

    private DataMap[] mapWidgets(List<Widget> widgetList) {
        return (widgetList == null || widgetList.isEmpty()) ? DomainUtils.emptyDataMapArray() : widgetList.stream().map((Widget widget) -> {
                DataMap result = new DataHashMap();

                result.put(ResponseKey.NAME, widget.getName());
                result.put(ResponseKey.TITLE, widget.getTitle());
                result.put(ResponseKey.VISIBLE, widget.isVisible());
                
                return result;
            }).toArray(DataMap[]::new);
    }

    private DataMap[] mapHelpTexts(List<WidgetHelp> widgetHelpList) {
        return (widgetHelpList == null || widgetHelpList.isEmpty()) ? DomainUtils.emptyDataMapArray() : widgetHelpList.stream().map((WidgetHelp widgetHelp) -> {
                Help help = widgetHelp.getHelp();
                DataMap result = new DataHashMap();
    
                result.put(ResponseKey.TITLE, help.getTitle());
                result.put(ResponseKey.CONTENT, help.getContent());
                
                return result;
            }).toArray(DataMap[]::new);
    }
}
