package nl.belastingdienst.iva.inzicht.configuration.query;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public interface ColumnMapper {

	String getKey();
	Object getValue(DataMap sourceDataMap);
}
