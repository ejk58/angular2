package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

import javax.ws.rs.core.HttpHeaders;

public enum CredentialsType {

    LOGINPASSWORD("LOGINPASSWORD", CredentialsTransport.HTTPHEADER, HttpHeaders.AUTHORIZATION),
    APIKEY("APIKEY", CredentialsTransport.HTTPHEADER, "x-api-key"),
    URLPARAMETER("URLPARAMETER", CredentialsTransport.URLPARAMETER, null),
    LTPATOKEN("LTPATOKEN", CredentialsTransport.COOKIE, "LtpaToken"),
    LTPA2TOKEN("LTPA2TOKEN", CredentialsTransport.COOKIE, "LtpaToken2");
    
    private String name;
    private CredentialsTransport credentialsTransport;
    private String key;
    
    private CredentialsType(String name, CredentialsTransport credentialsTransport, String key) {
        this.name = name;
        this.credentialsTransport = credentialsTransport;
        this.key = key;
    }

    public CredentialsTransport getCredentialsTransport() {
        return this.credentialsTransport;
    }
    
    public String getKey() {
        return this.key;
    }
    
    public boolean isHttpHeader() {
        return this.credentialsTransport == CredentialsTransport.HTTPHEADER;
    }

    public boolean isUrlParameter() {
        return this.credentialsTransport == CredentialsTransport.URLPARAMETER;
    }

    public boolean isCookie() {
        return this.credentialsTransport == CredentialsTransport.COOKIE;
    }
    
    public static CredentialsType findCredentialsType(String credentialsTypeName) {
        for (CredentialsType credentialsType : values()) {
            if (credentialsType.name.equals(credentialsTypeName)) {
                return credentialsType;
            }
        }
        
        return null;
    }
    
    public static CredentialsType getCredentialsType(String credentialsTypeName, String datasourceName) {
    	CredentialsType credentialsType = findCredentialsType(credentialsTypeName);

    	if (credentialsType == null) {
    		throw new IllegalStateException("The credentials type '" + credentialsTypeName + "' for datasource '" + datasourceName + "' is not supported.");
    	}
    	
    	return credentialsType;
    }
}
