package nl.belastingdienst.iva.inzicht.service.relation;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainPathKey;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/relation")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class RelationService extends AbstractRestService {

    private static final List<String> OLDQUERYDOMAINLIST = Arrays.asList("niet_winst", "di", "documenten", "zaakadministratie");
    private static final Integer MAIN_FLAG = 1;
    
    @Inject
    private DataProvider dataprovider;

    @GET
    @Produces({ MediaType.APPLICATION_JSON })
    public Response getRelations(@Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.RELATIONSERVICE, queryValues);
        
        try {
            validateRestCallParameters(restCallContext);
            checkRequiredRoles(restCallContext);
            
            DataMap response = new DataHashMap();
            Status status = Status.OK;
            DataMap subjectResponse = getSubject(restCallContext);
            
            if (!subjectResponse.isEmpty()) {
                response.put("subject", subjectResponse);
                response.put("relations", getRelations(restCallContext));
            } else {
                status = Status.NOT_FOUND;
            }
            
            return buildResponse(status, response, restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
    
    private void validateRestCallParameters(RestCallContext restCallContext) {
        if (restCallContext.getDomainKey() != null) {
            throw new BadRequestException("The domain-key is missing from this rest-call.");
        }
        
        if (!restCallContext.hasMandatoryPathKeys()) {
            throw new BadRequestException("Not all mandatory path-keys are supplied in this rest-call.");
        }
    }
    
    private DataMap getSubject(RestCallContext restCallContext) {
        DataMap subject = DomainUtils.emptyDataMap(); 
        Result result = retrieveSubject(restCallContext);
        DataMap[] data = result.getData();
        		
        if (data.length == 1) {
            if (OLDQUERYDOMAINLIST.contains(restCallContext.getDomainKey())) {
                subject = buildSubjectFromOldWizardQuery(data[0]);
            } else {
                subject = data[0]; 
            }
        }
        
        return subject;
    }

    private DataMap[] getRelations(RestCallContext restCallContext) {
        DataMap[] relations = DomainUtils.emptyDataMapArray();
        Result result = retrieveRelations(restCallContext);
        DataMap[] data = result.getData();

        if (data.length > 0) {
            if (OLDQUERYDOMAINLIST.contains(restCallContext.getDomainKey())) {
                relations = buildRelationsFromOldWizardQuery(restCallContext, data);
            } else {
                relations = data;
            }
        }
        
        return relations;
    }
    
    private Result retrieveSubject(RestCallContext restCallContext) {
        Domain domain = restCallContext.findDomain();
        Query query = domain.getSearchVipQuery();
        return this.dataprovider.retrieveData(query, restCallContext);
    }
    
    private Result retrieveRelations(RestCallContext restCallContext) {
        boolean vip = RoleUtils.isVipUser(restCallContext);
        Domain domain = restCallContext.findDomain();
        Query query = vip ? domain.getWizardVipQuery() : domain.getWizardNoVipQuery();
        return this.dataprovider.retrieveData(query, restCallContext);
    }
    
    private DataMap buildSubjectFromOldWizardQuery(DataMap data) {
        DataMap response = data;
        
        response.remove("vip");
        
        return response;
    }
    
    private DataMap[] buildRelationsFromOldWizardQuery(RestCallContext restCallContext, DataMap[] data) {
        Map<String, DataMap> relations = new HashMap<>();

        for (DataMap dataRow : data) {
            String subjectNr = dataRow.getAsString("SUBJECTNR");
            
            if (!relations.containsKey(subjectNr)) {
                DataMap subjectDataMap = new DataHashMap();
                subjectDataMap.put(ResponseKey.PATHKEYS, buildPathKeysFromOldWizardQuery(restCallContext, dataRow));
                subjectDataMap.put(ResponseKey.NAME, dataRow.getAsString("NAME"));
                subjectDataMap.put(ResponseKey.DESCRIPTION, dataRow.getAsString("RELATIONTYPE"));
                subjectDataMap.put(ResponseKey.ICON, null);
                subjectDataMap.put(ResponseKey.ISMAIN, MAIN_FLAG.equals(dataRow.get("IS_MAIN")));
                relations.put(subjectNr, subjectDataMap);
            }
        }
        
        return DomainUtils.inArray(relations.values());
    }
    
    private DataMap buildPathKeysFromOldWizardQuery(RestCallContext restCallContext, DataMap dataRow) {
        Domain domain = restCallContext.findDomain();
        List<DomainPathKey> mandatoryPathKeys = domain.getMandatoryPathKeys();
        DataMap pathKeys = new DataHashMap();
        
        for (DomainPathKey mandatoryPathKey : mandatoryPathKeys) {
            String key = mandatoryPathKey.getName();
            String value = mandatoryPathKey.getPrimary() ? dataRow.getAsString(key.toUpperCase()) : restCallContext.getFirstQueryValue(key); 
            pathKeys.put(key, value);
        }
        
        return pathKeys;
    }
}
