package nl.belastingdienst.iva.inzicht.service.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.enterprise.inject.Typed;

import nl.belastingdienst.iva.inzicht.configuration.domain.DomainComparator;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageDomain;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@Typed(DomainMapper.class)
public class DomainMapper {

    private DomainComparator domainComparator = new DomainComparator();
    
    public DataMap map(Set<Domain> domainSet) {
        List<Domain> domainList = new ArrayList<>(domainSet);
        DataMap domainResponse = new DataHashMap();
        List<DataMap> domainResponseList = new ArrayList<>();

        Collections.sort(domainList, this.domainComparator);
        for (Domain domain : domainList) {
            if (!domain.getPageDomains().isEmpty()) {
                DataMap domainDataMap = new DataHashMap();

                domainDataMap.put(ResponseKey.DOMAINID, domain.getKey());
                domainDataMap.put(ResponseKey.NAME, domain.getName());
                domainDataMap.put(ResponseKey.ICONNAME, domain.getIconName());
                domainDataMap.put(ResponseKey.PATHKEYS, domain.getPathKeys());
                domainDataMap.put(ResponseKey.SUBJECTTYPES, domain.getSubjectTypes());
                domainDataMap.put(ResponseKey.INITIALPAGEID, getInitialPageId(domain));
                domainDataMap.put(ResponseKey.INDEX, domain.getIndex());
                
                domainResponseList.add(domainDataMap);
            }
        }
        
        domainResponse.put(ResponseKey.DOMAINS, domainResponseList);
        
        return domainResponse;
    }
    
    private String getInitialPageId(Domain domain) {
        PageDomain pageDomain = domain.getPageDomains().get(0);
        Page page = pageDomain.getPage();
        return page.getKey();
    }
}
