package nl.belastingdienst.iva.inzicht.dataprovider.rest;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractHttpServiceClient;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProviderClient;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.JsonDataMapParser;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@Typed(RestServiceClient.class)
public class RestServiceClient extends AbstractHttpServiceClient implements DataProviderClient {

	private static final String DATASOURCENAME = "rest-service";
	
	@Inject
	private RestQueryFactory restQueryFactory;
	
    @Inject
    private JsonDataMapParser jsonDataMapParser;
	
    @Override
    public Result retrieveData(QueryInterface query, RestCallContext restCallContext) {
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();        
        RestQuery restQuery = this.restQueryFactory.getRestQuery(query, queryValues);
        String response = callRestService(restQuery, restCallContext);
        return new Result(processResponse(restQuery, response));
    }

    public DataMap[] retrieveDataAsMultiMap(Datasource datasource, QueryInterface query, RestCallContext restCallContext) {
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();        
        RestQuery restQuery = this.restQueryFactory.getRestQuery(datasource, query, queryValues);
        String response = callRestService(restQuery, restCallContext);
        return processResponse(restQuery, response);
    }

    private String callRestService(RestQuery restQuery, RestCallContext restCallContext) {
        String requestUrl = restQuery.getRequestUrl();
        String requestDescription = "(request-url = '" + requestUrl + "')";
        Datasource datasource = restQuery.getDatasource();
        CloseableHttpClient httpClient = datasource.getHttpClient();
        HttpGet httpGet = createGetRequest(datasource, requestUrl, restCallContext);
        String result = null;
        
        try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
        	handleHttpStatusCode(response, DATASOURCENAME, requestDescription);
           	result = EntityUtils.toString(response.getEntity());
        } catch (Exception exception) {
        	handleException(exception, DATASOURCENAME, requestDescription);
        }

        return result;
    }

    private DataMap[] processResponse(RestQuery restQuery, String response) {
    	String basePath = restQuery.getBasePath();
    	return this.jsonDataMapParser.parseJsonResult(DATASOURCENAME, basePath, response);
    }
}
