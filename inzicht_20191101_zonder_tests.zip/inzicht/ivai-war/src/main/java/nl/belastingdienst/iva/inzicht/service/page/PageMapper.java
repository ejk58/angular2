package nl.belastingdienst.iva.inzicht.service.page;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.enterprise.inject.Typed;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainMenuGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageAttribute;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageDomain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PagePathKey;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageWidget;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@Typed(PageMapper.class)
public class PageMapper {

	public DataMap map(Domain domain, List<Page> pageList) {
		DataMap pageResponse = new DataHashMap();

		pageResponse.put(ResponseKey.MENUOPTIONS, mapMenuGroups(domain));
		pageResponse.put(ResponseKey.PAGES, mapPages(pageList));

		return pageResponse;
	}

	private DataMap[] mapMenuGroups(Domain domain) {
		SortedSet<Integer> menuGroupIndexSet = getMenuGroupIndexSet(domain);
		List<DataMap> domains = new ArrayList<>();

		for (int menuGroupIndex : menuGroupIndexSet) {
			DataMap menuGroup = new DataHashMap();
			DomainMenuGroup domainMenuGroup = getMenuGroupByIndex(domain, menuGroupIndex);

			menuGroup.put(ResponseKey.TITLE, domainMenuGroup == null ? null : domainMenuGroup.getTitle());
			menuGroup.put(ResponseKey.ICONNAME, domainMenuGroup == null ? null : domainMenuGroup.getIconName());
			menuGroup.put(ResponseKey.OPTIONS, mapMenuItems(domain, menuGroupIndex));

			domains.add(menuGroup);
		}

		return DomainUtils.inArray(domains);
	}

	private DataMap[] mapMenuItems(Domain domain, int index) {
		List<PageDomain> pageDomains = domain.getPageDomains();
		List<DataMap> menuItems = new ArrayList<>();

		for (PageDomain pageDomain : pageDomains) {
			if (pageDomain.getGroupIndex() != null && pageDomain.getGroupIndex() == index) {
				Page page = pageDomain.getPage();
				String pageTitle = page.getTitle();
				DataMap menuItem = new DataHashMap();

				menuItem.put(ResponseKey.LABEL, pageTitle);
				menuItem.put(ResponseKey.KEY, page.getKey());
				menuItem.put(ResponseKey.IMPORTANT, false);
				menuItem.put(ResponseKey.INDEX, pageDomain.getMemberIndex());

				menuItems.add(menuItem);
			}
		}

		return DomainUtils.inArray(menuItems);
	}

	private SortedSet<Integer> getMenuGroupIndexSet(Domain domain) {
		SortedSet<Integer> menuGroupIndexSet = new TreeSet<>();

		List<PageDomain> pageDomains = domain.getPageDomains();
		for (PageDomain pageDomain : pageDomains) {
			if (pageDomain.getGroupIndex() != null) {
				menuGroupIndexSet.add(pageDomain.getGroupIndex());
			}
		}

		return menuGroupIndexSet;
	}

	private DomainMenuGroup getMenuGroupByIndex(Domain domain, int index) {
		List<DomainMenuGroup> domainMenuGroups = domain.getMenuGroups();

		for (DomainMenuGroup domainMenuGroup : domainMenuGroups) {
			if (domainMenuGroup.getIndex() == index) {
				return domainMenuGroup;
			}
		}

		return null;
	}

	private DataMap[] mapPages(List<Page> pageList) {
		List<DataMap> mappedPageList = new ArrayList<>();

		for (Page page : pageList) {
			mappedPageList.add(mapPage(page));
		}

		return DomainUtils.inArray(mappedPageList);
	}

	private DataMap mapPage(Page page) {
		List<String> mandatoryPathKeys = page.getMandatoryPathKeys().stream().map(PagePathKey::getName).collect(Collectors.toList());
		DataMap mappedPage = new DataHashMap();

		mappedPage.put(ResponseKey.KEY, page.getKey());
		mappedPage.put(ResponseKey.TYPE, page.getType());
		mappedPage.put(ResponseKey.TITLE, page.getTitle());
		mappedPage.put(ResponseKey.ROWS, mapPageRows(page));
		mappedPage.put(ResponseKey.MANDATORYPATHKEYS, mandatoryPathKeys);

		for (PageAttribute pageAttribute : page.getAttributeList()) {
			mappedPage.put(pageAttribute.getKey(), pageAttribute.getValue());
		}

		return mappedPage;
	}

	private PageItem[][] mapPageRows(Page page) {
		Map<Integer, PageItem[]> pageColumnMap = makePageColumnMap(page.getPageWidgets());
		PageItem[][] pageColumns = new PageItem[pageColumnMap.size()][];
		Iterator<Integer> rowIndexes = pageColumnMap.keySet().iterator();
		int index = 0;
		while (rowIndexes.hasNext()) {
			Integer rowIndex = rowIndexes.next();
			PageItem[] pageColumn = pageColumnMap.get(rowIndex);
			pageColumns[index] = pageColumn;
			index++;
		}
		return pageColumns;
	}

	private Map<Integer, PageItem[]> makePageColumnMap(List<PageWidget> columns) {
		Map<Integer, PageItem[]> pageColumnMap = new HashMap<>();
		for (PageWidget column : columns) {
			if (pageColumnMap.containsKey(column.getRowIndex())) {
				PageItem[] pageColumns = pageColumnMap.get(column.getRowIndex());
				PageItem[] newPageColumns = Arrays.copyOf(pageColumns, pageColumns.length + 1);
				newPageColumns[pageColumns.length] = new PageItem(column.getWidget(), column.getGridColumns());
				pageColumnMap.put(column.getRowIndex(), newPageColumns);
			} else {
				pageColumnMap.put(column.getRowIndex(),
						new PageItem[]{ new PageItem(column.getWidget(), column.getGridColumns()) });
			}
		}
		return pageColumnMap;
	}
}
