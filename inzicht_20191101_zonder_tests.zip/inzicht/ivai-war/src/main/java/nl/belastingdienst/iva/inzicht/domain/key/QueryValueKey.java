package nl.belastingdienst.iva.inzicht.domain.key;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class QueryValueKey {
    
    public static final String DOMAINKEY = "domainId";
    public static final String PAGEKEY = "pageId";
    public static final String WIDGETKEY = "widgetId";
    public static final String USERNAME = "userName";
    public static final String NOCACHE = "noCache";

    public static final String SUBJECTNR = "subjectNr";
    public static final String FISCALNR = "fiscalNr";
    public static final String ENTITYNR = "entityNr";

    public static final String EVENT = "event";
    public static final String RELOADCONFIGURATION = "reloadConfig";
    
    public static final Set<String> SYSTEMKEYS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(DOMAINKEY, PAGEKEY, WIDGETKEY, USERNAME, NOCACHE)));

    private QueryValueKey() {
        throw new UnsupportedOperationException();
    }

}
