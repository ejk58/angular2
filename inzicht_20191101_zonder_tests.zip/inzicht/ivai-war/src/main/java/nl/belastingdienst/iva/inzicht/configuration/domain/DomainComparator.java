package nl.belastingdienst.iva.inzicht.configuration.domain;

import java.util.Comparator;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;

public class DomainComparator implements Comparator<Domain> {

    @Override
    public int compare(Domain domain, Domain otherDomain) {
        return getIndexFromDomain(domain) - getIndexFromDomain(otherDomain);
    }

    private int getIndexFromDomain(Domain domain) {
        return (domain == null || domain.getIndex() == null) ? 0 : domain.getIndex();
    }
}
