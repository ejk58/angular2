package nl.belastingdienst.iva.inzicht.restcallcontext;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;

public abstract class EngineRestCallContext extends AbstractRestCallContext {

	private Result result;
	private Object response;
	
    public EngineRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration, long beginTime) {
    	super(serviceType, queryValues, configuration, beginTime);

        this.result = new Result();
        this.response = null;
    }

	@Override
	public Result getResult() {
		return this.result;
	}
	
	@Override
	public Object getResponse() {
		return this.response;
	}
	
	@Override
	public DataMap[] getData() {
		return this.result == null ? DomainUtils.emptyDataMapArray() : this.result.getData();
	}

	@Override
	public void setResult(Result result) {
        this.result = result;
    }
	
	@Override
	public void setResponse(Object response) {
		this.response = response;
	}
	
	@Override
	public void addRowsToResult(DataMap[] data) {
		this.result.addData(data);
	}
}
