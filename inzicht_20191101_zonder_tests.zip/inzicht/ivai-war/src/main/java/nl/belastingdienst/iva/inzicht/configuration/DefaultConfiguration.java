package nl.belastingdienst.iva.inzicht.configuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;

public class DefaultConfiguration implements Configuration {

    private Map<String, Object> keyValueMap;
    
    private Map<String, AttributeGroup> attributeGroupMap;
    private Map<String, RuleGroup> ruleGroupMap;

    private List<String> domainKeyList;
    private Map<String, Domain> domainMap;
    private Map<DomainRole, List<Domain>> domainsPerRoleMap;

    private Map<String, Page> pageMap;
    private Map<String, List<Page>> pagesByDomainMap;

    private Map<String, Widget> widgetMap;
    
    private DataHashMap configurationDetails;
    private Datasource teradataDatasource;
    private Datasource mihProxyDatasource;
    private Datasource jiraFeedbackDatasource;

    public DefaultConfiguration() {
        this.keyValueMap = new HashMap<>();
        this.configurationDetails = new DataHashMap();
        
        this.keyValueMap.put(ConfigurationKey.CONFIGURATIONDETAILS, this.configurationDetails);
    }

    @Override
    public Set<DomainRole> getApplicationRoles() {
        return this.domainsPerRoleMap.keySet();
    }

    @Override
    public Map<String, Object> getKeyValueMap() {
        return Collections.unmodifiableMap(this.keyValueMap);
    }

    @Override
    public Map<String, AttributeGroup> getAttributeGroupMap() {
        return Collections.unmodifiableMap(this.attributeGroupMap);
    }

    @Override
    public AttributeGroup getAttributeGroup(String attributeGroupKey) {
        return this.attributeGroupMap.get(attributeGroupKey);
    }

    @Override
    public Map<String, RuleGroup> getRuleGroupMap() {
        return Collections.unmodifiableMap(this.ruleGroupMap);
    }

    @Override
    public RuleGroup getRuleGroup(String ruleGroupKey) {
        return this.ruleGroupMap.get(ruleGroupKey);
    }

    @Override
    public Object getValue(String key) {
        return this.keyValueMap.get(key);
    }

    @Override
    public String getValueAsString(String key) {
        Object value = this.keyValueMap.get(key);
        return value == null ? null : value.toString();
    }

    @Override
    public Integer getValueAsNumber(String key) {
        Object value = this.keyValueMap.get(key);
        return value == null ? null : (value instanceof Integer ? (Integer) value : Integer.parseInt(value.toString())); 
    }

    @Override
    public Boolean getValueAsBoolean(String key) {
        Object value = this.keyValueMap.get(key);
        return value == null ? null : DomainUtils.isTrue(value.toString()); 
    }

    @Override
    public List<String> getDomainKeys() {
        return this.domainKeyList;
    }

    @Override
    public Domain findDomain(String domainKey) {
        return this.domainMap.get(domainKey);
    }

    @Override
    public List<Domain> findDomainsPerRole(DomainRole role) {
        return this.domainsPerRoleMap.get(role);
    }

    @Override
    public Page findPage(String pageKey) {
        return this.pageMap.get(pageKey);
    }

    @Override
    public List<Page> findPagesByDomain(String domainKey) {
        return this.pagesByDomainMap.get(domainKey);
    }

    @Override
    public Widget findWidget(String widgetName) {
        return this.widgetMap.get(widgetName);
    }
    
    @Override
    public Datasource getTeradataDatasource() {
        return this.teradataDatasource;
    }
    
    @Override
    public Datasource getMihProxyDatasource() {
        return this.mihProxyDatasource;
    }
    
    @Override
    public Datasource getJiraFeedbackDatasource() {
    	return this.jiraFeedbackDatasource;
    }
    
    public Map<String, Widget> getWidgetMap() {
    	return this.widgetMap == null ? Collections.<String, Widget>emptyMap() : this.widgetMap;
    }

    @Override
    public String toString() {
    	StringBuilder configurationBuilder = new StringBuilder();

    	configurationBuilder.append("Inzicht configuration:\n\n");
        for (Domain domain : this.domainMap.values()) {
        	configurationBuilder.append(domain.toString(""));
            configurationBuilder.append("\n");
        }
    	
    	List<String> keyList = new ArrayList<>(this.keyValueMap.keySet());
        Collections.sort(keyList);
        for (String key : keyList) {
            configurationBuilder.append(key);
            configurationBuilder.append(" = ");
            configurationBuilder.append(keyValueMap.get(key));
            configurationBuilder.append("\n");
        }
        
    	return configurationBuilder.toString();
    }

    void setValues(Map<String, ? extends Object> values) {
        this.keyValueMap.putAll(values);
    }
    
    void setValue(String key, Object value) {
        this.keyValueMap.put(key, value);
    }
    
    void setDefaultValue(String key, Object value) {
        if (!this.keyValueMap.containsKey(key)) {
            this.keyValueMap.put(key, value);
        }
    }

    void setAttributeGroupMap(Map<String, AttributeGroup> attributeGroupMap) {
    	this.attributeGroupMap = attributeGroupMap;
    }
    
    void setRuleGroupMap(Map<String, RuleGroup> ruleGroupMap) {
    	this.ruleGroupMap = ruleGroupMap;
    }
    
    void setDomainKeyList(List<String> domainKeyList) {
        this.domainKeyList = domainKeyList;
    }

    void setDomainMap(Map<String, Domain> domainMap) {
        this.domainMap = domainMap;
    }

    void setDomainsPerRoleMap(Map<DomainRole, List<Domain>> domainsPerRoleMap) {
        this.domainsPerRoleMap = domainsPerRoleMap;
    }

    void setPageMap(Map<String, Page> pageMap) {
        this.pageMap = pageMap;
    }

    void setPagesByDomainMap(Map<String, List<Page>> pagesByDomainMap) {
        this.pagesByDomainMap = pagesByDomainMap;
    }

    void setWidgetMap(Map<String, Widget> widgetMap) {
        this.widgetMap = widgetMap;
    }
    
    void setTeradataDatasource(Datasource teradataDatasource) {
        this.teradataDatasource = teradataDatasource;
    }
    
    void setMihProxyDatasource(Datasource mihProxyDatasource) {
        this.mihProxyDatasource = mihProxyDatasource;
    }
    
    void setJiraFeedbackDatasource(Datasource jiraFeedbackDatasource) {
    	this.jiraFeedbackDatasource = jiraFeedbackDatasource;
    }
    
    void addConfigurationDetails(String key, Object value) {
        this.configurationDetails.put(key, value);
    }
}
