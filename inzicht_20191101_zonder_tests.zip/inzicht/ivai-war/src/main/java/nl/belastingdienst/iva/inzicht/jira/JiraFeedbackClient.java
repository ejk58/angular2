package nl.belastingdienst.iva.inzicht.jira;

import java.io.IOException;
import java.util.Date;

import javax.inject.Inject;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractHttpServiceClient;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.jira.Feedback;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class JiraFeedbackClient extends AbstractHttpServiceClient {
	
	private static final String DATASOURCENAME = "Jira rest-service";
	
	@Inject
	private JiraIssueMapper jiraIssueMapper;
	
	private ObjectMapper objectMapper;
	
	public JiraFeedbackClient() {
		this.objectMapper = new ObjectMapper();
	}

	public JiraFeedbackClient( ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	public void run(Feedback feedback, RestCallContext restCallContext) {
		DataMap jiraIssue = createIssue(feedback, restCallContext);		
		submit(jiraIssue, restCallContext);
	}
	
	public DataMap createIssue(Feedback feedback, RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
        String userName = restCallContext.getUserName();
        String environment = configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKENVIRONMENT);
		
        feedback.setUsername(userName);
        feedback.setCreated(new Date());
        feedback.setSummary(environment + ": Te beoordelen");
    	
		return this.jiraIssueMapper.map(feedback, configuration);		
	}
	
	public void submit(DataMap jiraIssue, RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
		Datasource jiraFeedbackDatasource = configuration.getJiraFeedbackDatasource();
		String restUrl = getIssueRestUrl(jiraFeedbackDatasource);
        String requestDescription = "(Jira-url = '" + restUrl + "')";
      	String jsonIssue = convertJiraIssue(jiraIssue);
        CloseableHttpClient httpClient = jiraFeedbackDatasource.getHttpClient();
        HttpPost httpPost = createPostRequest(jiraFeedbackDatasource, restUrl, jsonIssue, null);

        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
        	handleHttpStatusCode(response, DATASOURCENAME, requestDescription);
        } catch (IOException exception) {
        	handleException(exception, DATASOURCENAME, requestDescription);
        }
	}
	
    @Override
	public void handleHttpStatusCode(HttpResponse response, String datasourceName, String requestDescription) {
		int statusCode = response.getStatusLine().getStatusCode();
		
		if (statusCode == 401) {
			throw new InternalServerErrorException("Failed to authorize for the Jira environment or given project with status code 401.");
 		} else if (statusCode >= 400) {
			try {
				String jiraErrorResponse = EntityUtils.toString(response.getEntity());
				String message = "Received status code " + statusCode + " while submitting Jira-issue: " + jiraErrorResponse;
				throw new BadGatewayException(message);
			} catch (IOException exception) {
				String message = "Received status code " + statusCode + " while submitting Jira-issue and failed to parse the error response.";
				throw new BadGatewayException(message);
			}
		}
	}
    
    private String getIssueRestUrl(Datasource jiraFeedbackDatasource) {
		String restUrl = jiraFeedbackDatasource.getValue(DatasourceKey.RESTURL);
		return restUrl + "/api/2/issue";
    }
    
    private String convertJiraIssue(DataMap jiraIssue) {
        try {
        	return this.objectMapper.writeValueAsString(jiraIssue);
        } catch (IOException exception) {
        	String message = "Failed to convert the feedback '" + jiraIssue.toString() + "' to JSON with an IO-exception: " + exception.getMessage();
        	throw new InternalServerErrorException(message);
        }
    }
}
