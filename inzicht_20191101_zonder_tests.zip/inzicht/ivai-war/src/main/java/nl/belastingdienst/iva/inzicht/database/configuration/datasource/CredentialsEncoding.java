package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

import org.apache.commons.codec.binary.Base64;

public enum CredentialsEncoding {

    PLAINTEXT("PLAINTEXT") {
        @Override
        public String encodeCredentials(String credentials) {
            return credentials;
        }
    },
    BASE64("BASE64") {
        @Override
        public String encodeCredentials(String credentials) {
            byte[] credentialsBytes = credentials.getBytes();
            byte[] encodedCredBytes = Base64.encodeBase64(credentialsBytes, false);
            return "Basic " + new String(encodedCredBytes);
        }
    };
    
    private String name;
    
    private CredentialsEncoding(String name) {
        this.name = name;
    }
    
    public abstract String encodeCredentials(String credentials);
    
    public static CredentialsEncoding findCredentialsEncoding(String credentialsEncodingName) {
        for (CredentialsEncoding credentialsEncoding : values()) {
            if (credentialsEncoding.name.equals(credentialsEncodingName)) {
                return credentialsEncoding;
            }
        }
        
        return null;
    }

    public static CredentialsEncoding getCredentialsEncoding(String credentialsEncodingName, String datasourceName) {
    	CredentialsEncoding credentialsEncoding = findCredentialsEncoding(credentialsEncodingName);

    	if (credentialsEncoding == null) {
    		throw new IllegalStateException("The credentials encoding '" + credentialsEncodingName + "' for datasource '" + datasourceName + "' is not supported.");
    	}
    	
    	return credentialsEncoding;
    }
}
