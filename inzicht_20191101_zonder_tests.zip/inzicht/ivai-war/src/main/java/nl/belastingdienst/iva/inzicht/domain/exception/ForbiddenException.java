package nl.belastingdienst.iva.inzicht.domain.exception;

import javax.ejb.ApplicationException;

@ApplicationException
public class ForbiddenException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ForbiddenException(String message) {
        super(message);
    }
}
