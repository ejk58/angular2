package nl.belastingdienst.iva.inzicht.database.notification;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "NOTIFICATION_SCHEDULE")
@NamedQuery(name = Notification.QUERY_GETNOTIFICATION, query = "SELECT m FROM Notification m " +
  "JOIN FETCH m.notificationMessage " +
  "WHERE m.page = :page " +
  "AND m.domain = :domain " +
  "AND m.start < CURRENT_TIMESTAMP " +
  "AND m.end > CURRENT_TIMESTAMP " +
  "ORDER BY m.priority")
public class Notification {

  public static final String QUERY_GETNOTIFICATION = "Notification.getNotification";

  @Id
  @Column(name = "id")
  private Integer id;

  @Column(name = "domain")
  private String domain;

  @Column(name = "page")
  private String page;

  @Column(name = "start")
  @Temporal(TemporalType.TIMESTAMP)
  private Date start;

  @Column(name = "end")
  @Temporal(TemporalType.TIMESTAMP)
  private Date end;

  @Column(name = "priority")
  private Integer priority;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "NOTIFICATION_ID")
  private NotificationMessage notificationMessage;

  public String getMessage() {
    return this.notificationMessage.getMessage();
  }

  public String getType() {
    return this.notificationMessage.getType();
  }
}
