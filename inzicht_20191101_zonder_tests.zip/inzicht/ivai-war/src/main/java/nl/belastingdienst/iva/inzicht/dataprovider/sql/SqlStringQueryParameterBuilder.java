package nl.belastingdienst.iva.inzicht.dataprovider.sql;

import java.util.function.Function;

public class SqlStringQueryParameterBuilder implements Function<String, String> {

    @Override
    public String apply(String value) {
        return (value == null) ? null : ("'" + value.replaceAll("'","''") + "'");
    }
}
