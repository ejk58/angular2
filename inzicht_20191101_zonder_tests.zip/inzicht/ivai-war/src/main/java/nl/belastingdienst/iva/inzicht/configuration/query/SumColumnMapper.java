package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class SumColumnMapper implements ColumnMapper {

    private List<ColumnMapper> partialColumnMappers;
    private String destinationKey;
	
	public SumColumnMapper(List<ColumnMapper> partialColumnMappers, String destinationKey) {
		this.partialColumnMappers = partialColumnMappers;
		this.destinationKey = destinationKey;
	}

	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public Long getValue(DataMap sourceDataMap) {
        Long result = 0L;
        
        for (ColumnMapper columnMapper : this.partialColumnMappers) {
        	Object value = columnMapper.getValue(sourceDataMap);

        	if (value instanceof Integer) {
        		result = result + (Integer) value;
        	} else if (value instanceof Long) {
        		result = result + (Long) value;
        	}
        }
        
		return result;
	}
}
