package nl.belastingdienst.iva.inzicht.domain;

import java.io.IOException;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;

import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;

public class JsonDataMapParser {

	private static final String ARRAYPATHELEMENT = "[0]";
	private static final String DIVIDER = "/";

	private ObjectMapper jsonObjectMapper;
    private JsonFactory jsonFactory;
    
    public JsonDataMapParser() {
        this.jsonObjectMapper = new ObjectMapper();
        this.jsonFactory = new JsonFactory();
    }
    
    public JsonDataMapParser(ObjectMapper objectMapper) {
        this.jsonObjectMapper = objectMapper;
        this.jsonFactory = new JsonFactory();
    }

    public DataMap[] parseJsonResult(String sourceDescription, String response) {
    	return parseJsonResult(sourceDescription, null, response);
    }

    public DataMap[] parseJsonResult(String sourceDescription, String basePath, String response) {
        DataMap[] result = DomainUtils.emptyDataMapArray();

        try {
            JsonParser jsonParser = this.jsonFactory.createJsonParser(response);
            JsonNode rootNode = this.jsonObjectMapper.readTree(jsonParser);
            JsonNode dataNode = traversePath(rootNode, basePath);

	        if (dataNode.isValueNode() || dataNode.isObject()) {
	        	result = DomainUtils.inArray(this.jsonObjectMapper.readValue(dataNode, DataHashMap.class));
	        } else if (dataNode.isArray()) {
                result = this.jsonObjectMapper.readValue(dataNode, DataHashMap[].class);
            }
        } catch (IOException exception) {
            String message = "Failed to parse the " + sourceDescription + " response with exception " + 
            		ExceptionUtils.getExceptionsForMessage(exception) +
                    " (cause = '" + exception.getCause() + 
                    "', message = '" + exception.getMessage() + 
                    "', response = '" + response + "')";
            throw new InternalServerErrorException(message, exception);
        }
    
        return result;
    }

    public JsonNode extractJsonResult(String sourceDescription, String basePath, String response) {
        try {
            JsonParser jsonParser = this.jsonFactory.createJsonParser(response);
            JsonNode rootNode = this.jsonObjectMapper.readTree(jsonParser);
            return traversePath(rootNode, basePath);
        } catch (IOException exception) {
            String message = "Failed to extract a node from the " + sourceDescription + " response with exception " + 
            		ExceptionUtils.getExceptionsForMessage(exception) +
                    " (cause = '" + exception.getCause() + 
                    "', message = '" + exception.getMessage() + 
                    "', response = '" + response + "')";
            throw new InternalServerErrorException(message, exception);
        }
    }
    
    private JsonNode traversePath(JsonNode rootNode, String path) {
    	JsonNode dataNode = rootNode;
    	
    	if (path != null && !path.isEmpty()) {
    		String[] pathElements = path.split(DIVIDER);
    		int index = 0;
    		
    		while (!dataNode.isMissingNode() && index < pathElements.length) {
    			dataNode = ARRAYPATHELEMENT.equals(pathElements[index]) ? dataNode.path(0) : dataNode.path(pathElements[index]);    			
    			index++;
    		}
    	}
    	
    	return dataNode;
    }
}
