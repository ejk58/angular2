package nl.belastingdienst.iva.inzicht.database.configuration.query;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "CONF_QUERY_COLUMN")
public class QueryColumn {

    private static final String TYPE_VIPFILTER = "VIPFILTER";
    private static final String TYPE_VIPMASK = "VIPMASK";
    private static final String TYPE_VIPTAG = "VIPTAG";
    
    @Id
    private Integer id;

    private Integer index;
    private String name;
    private String alias;
    private String value;
    private String key;
    private String type;
    private boolean maskable;

    @Column(name = "COMPOSITE_COLUMN_ID")
    @OneToMany(fetch = FetchType.EAGER)
    @OrderBy(value = "index")
    private List<QueryColumn> columns;

    @Transient
    private boolean partial;
    
    public Integer getId() {
        return this.id;
    }

    public List<QueryColumn> getColumns() {
        return Collections.unmodifiableList(this.columns);
    }

    public Integer getIndex() {
        return this.index;
    }

    public String getName() {
        return this.name;
    }

    public String getAlias() {
        return this.alias;
    }

    public String getValue() {
        return this.value;
    }

    public String getKey() {
		return this.key;
	}

	public String getType() {
		return this.type;
	}

	public boolean isMaskable() {
        return this.maskable;
    }
    
    public boolean isPartial() {
    	return this.partial;
    }
    
    public boolean isComposite() {
        return (this.columns != null) && !columns.isEmpty();
    }
    
    public boolean isValue() {
    	return this.value != null;
    }
    
    public boolean isVipFilter() {
        return TYPE_VIPFILTER.equals(this.type);
    }
    
    public boolean isVipMask() {
        return TYPE_VIPMASK.equals(this.type);
    }
    
    public boolean isVipTag() {
        return TYPE_VIPTAG.equals(this.type);
    }
    
    public String getSourceKey() {
    	return this.alias == null ? this.name : this.alias;
    }
    
    public String getDestinationKey() {
		return this.key == null ? getSourceKey() : this.key;
    }
    
    public void setPartial(boolean partial) {
    	this.partial = partial;
    }
    
    public void determinePartialColumns() {
    	if (isComposite()) {
	    	for (QueryColumn column : this.columns) {
	    		column.setPartial(true);
	    	}
    	}
    }
}
