package nl.belastingdienst.iva.inzicht.jira;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.jira.Feedback;
import nl.belastingdienst.iva.inzicht.domain.jira.IssueType;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.JiraIssueKey;

public class JiraIssueMapper {

	private static final String DESCRIPTIONITEMFORMAT = "*%s*: %s%n";
	
	public DataMap map(Feedback feedback, Configuration configuration) {
		IssueType issueType = IssueType.STORY;
		AttributeGroup jiraFeedbackEpicLinksGroup = configuration.getAttributeGroup(ConfigurationKey.JIRAFEEDBACKEPICLINKSGROUP);
		String epicLink = jiraFeedbackEpicLinksGroup.getAttributeMap().get(feedback.getDomainId());

        DataMap jiraIssue = new DataHashMap();
        jiraIssue.put(JiraIssueKey.PROJECT, DomainUtils.inMap(JiraIssueKey.ID, configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKPROJECT)));
        jiraIssue.put(JiraIssueKey.TYPE, DomainUtils.inMap(JiraIssueKey.ID, issueType.getId()));
        jiraIssue.put(JiraIssueKey.SUMMARY, feedback.getSummary());
        jiraIssue.put(JiraIssueKey.DESCRIPTION, makeDescription(feedback));
        jiraIssue.put(JiraIssueKey.FIXVERSIONS, deduceFixVersions(configuration, feedback.getTopic()));
        jiraIssue.put(JiraIssueKey.LABELS, new String[] {(configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKENVIRONMENT))});

		if (issueType.isEpicLinkSupported() && epicLink != null) {
			jiraIssue.put(configuration.getValueAsString(ConfigurationKey.JIRAEPICLINKFIELDNAME), epicLink);
		}
        
		return DomainUtils.inMap(JiraIssueKey.ISSUE, jiraIssue);
	}
	
	private DataMap[] deduceFixVersions(Configuration configuration, String topic) {
		AttributeGroup fixVersionAttributeGroup = configuration.getAttributeGroup(ConfigurationKey.JIRAFEEDBACKTOPICFIXVERSIONSGROUP);
		String fixVersionIdForTopic = fixVersionAttributeGroup.getAttributeMap().get(topic);
		return fixVersionIdForTopic == null ? DomainUtils.emptyDataMapArray() : DomainUtils.inArray(DomainUtils.inMap("id", fixVersionIdForTopic));
	}

	private String makeDescription(Feedback feedback) {
		StringBuilder description = new StringBuilder();
		
		if (feedback.getScope() != null) {
			description.append(String.format(DESCRIPTIONITEMFORMAT, "Scope", feedback.getScope()));
		}
		
		if (feedback.getTopic() != null) {
			description.append(String.format(DESCRIPTIONITEMFORMAT, "Topic", feedback.getTopic()));
		}
		
		if (feedback.getRemark() != null) {
			if (description.length() > 0) {
				description.append(String.format("%n"));
			}
			description.append(String.format("%s%n%n", feedback.getRemark()));
		}
		
		if (feedback.getWidget() != null) {
			description.append(String.format(DESCRIPTIONITEMFORMAT, "Widget", feedback.getWidget()));
		}

		description.append(String.format(DESCRIPTIONITEMFORMAT, "Url", feedback.getUrl()));
		description.append(String.format(DESCRIPTIONITEMFORMAT, "Verstuurd door", feedback.getUsername()));
		
		return description.toString();
	}
}
