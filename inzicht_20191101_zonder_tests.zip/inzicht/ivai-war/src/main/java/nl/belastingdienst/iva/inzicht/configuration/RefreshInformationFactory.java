package nl.belastingdienst.iva.inzicht.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataRefreshInfoClient;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class RefreshInformationFactory {

	@Inject
	private TeradataRefreshInfoClient teradataRefreshInfoClient;
	
    public Map<String, List<DataMap>> createWidgetRefreshInformation(DefaultConfiguration newConfiguration) {
    	DataMap[] refreshInfoArray = this.teradataRefreshInfoClient.retrieveRefreshInfo(newConfiguration);
    	Map<String, List<DataMap>> refreshInfoMap = new HashMap<>();

    	for (DataMap refreshInfoWithView : refreshInfoArray) {
    		String viewName = refreshInfoWithView.getAsString("viewName").trim().toLowerCase();
    	    List<DataMap> refreshInfoList = getRefreshInfoListForViewName(refreshInfoMap, viewName);
    	    DataMap refreshInfoElement = buildRefreshInfoElement(refreshInfoWithView);
    	    refreshInfoList.add(refreshInfoElement);
    	    refreshInfoMap.put(viewName, refreshInfoList);
    	}
    	
    	return refreshInfoMap;
    }
    
    private List<DataMap> getRefreshInfoListForViewName(Map<String, List<DataMap>> refreshInformationMap, String viewName) {
	    List<DataMap> refreshInfo = refreshInformationMap.get(viewName);
	    
	    if (refreshInfo == null) {
	    	refreshInfo = new ArrayList<>();
	    }

	    return refreshInfo;
    }
    
    private DataMap buildRefreshInfoElement(DataMap refreshInfoWithView) {
	    DataMap refreshInfoElement = new DataHashMap();
	    
	    refreshInfoElement.put("source", refreshInfoWithView.getAsString("source"));
	    refreshInfoElement.put("refreshDate", refreshInfoWithView.get("refreshDate"));

	    return refreshInfoElement;
    }
}
