package nl.belastingdienst.iva.inzicht.domain.key;

public class DatasourceKey {

    public static final String CREDENTIALSNAME = "credentialsName";
    public static final String CREDENTIALSMAPPING = "credentialsMappingJAAS";
    public static final String CREDENTIALSTYPE = "credentialsType";
    public static final String CREDENTIALSENCODING = "credentialsEncoding";
    public static final String CREDENTIALSVALUE = "credentialsValue";

    public static final String RESTURL = "restUrl";
    public static final String TERADATASCHEMA = "teradataSchema";
    public static final String TRUSTALLCERTIFICATES = "trustAllCertificates";
    public static final String ACCEPTHEADER = "acceptHeader";
    public static final String WSAADDRESSHEADER = "wsaAddressHeader";
    
    public static final String CONNECTTIMEOUT = "connectTimeout";
    public static final String READTIMEOUT = "readTimeout";
    public static final String REQUESTTIMEOUT = "requestTimeout";
    public static final String SLOWEXECUTIONTIME = "slowQueryThreshold";
    public static final String QUERYEXPLAINMONITOR = "queryExplainMonitor";
    
    private DatasourceKey() {
        throw new UnsupportedOperationException();
    }
}
