package nl.belastingdienst.iva.inzicht.configuration.datasource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.login.LoginException;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;

public class DatasourceParser {

    private static final Logger logger = Logger.getLogger(DatasourceParser.class);

    public Map<String, Datasource> parse(List<Datasource> datasourceList) {
    	Map<String, Datasource> datasourceMap = new HashMap<>();
    	
    	for (Datasource datasource : datasourceList) {
    		parseDatasource(datasource);
    		createHttpClientIfNeeded(datasource);
            datasourceMap.put(datasource.getKey(), datasource);
    	}
    	
    	return datasourceMap;
    }

    private void parseDatasource(Datasource datasource) {
    	try {
    		datasource.buildParameterMap();
        } catch (LoginException | IllegalStateException exception) {
			String key = datasource.getKey();
			String message = "Failed to extract the credentials for datasource " + key + " with the exception " + 
					exception.getClass().getSimpleName() + ": " + exception.getMessage();
            logger.error(MessageUtils.createMessage(MessageType.ERROR, message));
        }
    }
    
    private void createHttpClientIfNeeded(Datasource datasource) {
    	String restUrl = datasource.getValue(DatasourceKey.RESTURL);
    	if (restUrl != null) {
    		CloseableHttpClient httpClient = createHttpClient(datasource);
    		datasource.setHttpClient(httpClient);
    	}
    }
    
    private CloseableHttpClient createHttpClient(Datasource datasource) {
		HttpClientBuilder httpClientBuilder = HttpClients.custom()
				.useSystemProperties()
				.disableAutomaticRetries()
				.setDefaultRequestConfig(createRequestConfig(datasource));
		
		if (datasource.getBoolean(DatasourceKey.TRUSTALLCERTIFICATES)) {
			httpClientBuilder.setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);
			String message = "The datasource " + datasource.getKey() + " is set to trust all certificates!";
			logger.warn(MessageUtils.createMessage(MessageType.WARNING, message));
		}
		
		return httpClientBuilder.build();
    }
    
    private RequestConfig createRequestConfig(Datasource datasource) {
    	RequestConfig.Builder requestConfigBuilder = RequestConfig.custom();
    	
    	if (datasource.getValue(DatasourceKey.CONNECTTIMEOUT) != null) {
    		requestConfigBuilder.setConnectTimeout(datasource.getNumber(DatasourceKey.CONNECTTIMEOUT));
    	}
    	
    	if (datasource.getValue(DatasourceKey.READTIMEOUT) != null) {
    		requestConfigBuilder.setSocketTimeout(datasource.getNumber(DatasourceKey.READTIMEOUT));
    	}
    	
    	if (datasource.getValue(DatasourceKey.REQUESTTIMEOUT) != null) {
    		requestConfigBuilder.setConnectionRequestTimeout(datasource.getNumber(DatasourceKey.REQUESTTIMEOUT));
    	}
    	
    	return requestConfigBuilder.build();
    }
}
