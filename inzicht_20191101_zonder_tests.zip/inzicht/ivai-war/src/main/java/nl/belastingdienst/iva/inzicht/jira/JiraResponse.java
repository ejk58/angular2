package nl.belastingdienst.iva.inzicht.jira;

import java.util.HashMap;
import java.util.Map;

public class JiraResponse {

	private String[] errorMessages;
	private Map<String, String> errors;
	
	public JiraResponse() {
		this.errors = new HashMap<>();
	}
	
	public JiraResponse(String[] errorMessages, Map<String, String> errors) {
		this.errorMessages = errorMessages;
		this.errors = errors;
	}
	
	public String[] getErrorMessages() {
		return errorMessages;
	}
	
	public void setErrorMessages(String[] errorMessages) {
		this.errorMessages = errorMessages;
	}
	
	public Map<String, String> getErrors() {
		return errors;
	}
	
	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}
	
	public boolean hasErrors() {
		return !this.errors.isEmpty();
	}
}
