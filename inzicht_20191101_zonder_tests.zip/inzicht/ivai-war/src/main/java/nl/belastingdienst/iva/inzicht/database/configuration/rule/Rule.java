package nl.belastingdienst.iva.inzicht.database.configuration.rule;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_RULE")
public class Rule {

    @Id
	private Integer id;
	
	private Integer index;
	private String value;
	
	public Integer getId() {
		return this.id;
	}

	public Integer getIndex() {
		return this.index;
	}
	
	public String getValue() {
		return this.value;
	}
}
