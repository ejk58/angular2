package nl.belastingdienst.iva.inzicht.domain.query;

import java.util.List;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryFilter;
import nl.belastingdienst.iva.inzicht.database.configuration.query.ResultMapper;

public interface QueryInterface {

    String getKey();
    QueryType getType();
    String getViewName();
    String getQueryTemplate();
    List<QueryColumn> getQueryColumns();
    List<QueryFilter> getQueryFilters();
    Datasource getDatasource();
    String getVipFilterColumnKey();
    String getVipMaskColumnKey();
    String getVipTagColumnKey();
    List<String> getMaskableColumnKeys();
    ResultMapper getResultMapper();
    boolean hasDatasource();
}
