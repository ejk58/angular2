package nl.belastingdienst.iva.inzicht.domain.key;

public class ConfigurationKey {

    public static final String GENERALGROUP = "GENERAL";
    
    public static final String CONFIGURATIONUPDATETIME = "configurationUpdateTime"; 
    public static final String CONFIGURATIONUPDATEDURATION = "configurationUpdateDuration"; 
    public static final String CONFIGURATIONLOADTIME = "configurationLoadTime";
    public static final String CONFIGURATIONNEWSETTINGSAVAILABLE = "configurationNewSettingsAvailable";
    public static final String CONFIGURATIONDETAILS = "configurationDetails"; 
    public static final String CONFIGURATIONRELOADALLOWED = "configurationReloadAllowed"; 
    public static final String CONFIGURATIONSTATUS = "configurationStatus"; 

    public static final String USERCACHEACCESSIBLE = "userCacheAccessible";
    public static final String SOURCEREFRESHINFORMATIONAVAILABLE = "sourceRefreshInformationAvailable";
    
    public static final String JIRAFEEDBACKPROJECT = "jiraFeedbackProject";
    public static final String JIRAFEEDBACKENVIRONMENT = "jiraFeedbackEnvironment";
    public static final String JIRAEPICLINKFIELDNAME = "jiraEpicLinkFieldName";
    public static final String JIRAFEEDBACKEPICLINKSGROUP = "JIRA_FEEDBACK_EPIC_LINKS";
    public static final String JIRAFEEDBACKTOPICFIXVERSIONSGROUP = "JIRA_FEEDBACK_TOPIC_FIX_VERSIONS";
    
    public static final String MIHSUBJECTVIPRESTQUERY = "mihSubjectVipRestQuery";
    public static final String MIHENTITYVIPRESTQUERY = "mihEntityVipRestQuery";
    public static final String TERADATAVIPSQLQUERY = "teradataVipSqlQuery";
    public static final String TERADATAVIPVIEWNAME = "teradataVipViewName";
    public static final String ACCESSPERMISSIONPROVIDER = "accessPermissionProvider";
    public static final String RESULTPERMISSIONPROVIDER = "resultPermissionProvider";
    public static final String PERMISSIONCACHEACCESSIBLE = "permissionCacheAccessible";
    public static final String PERMISSIONCACHEEXPIRATIONAGE = "permissionCacheExpirationAge";
    public static final String PERMISSIONCACHESIZE = "permissionCacheSize";
    
    private ConfigurationKey() {
        throw new UnsupportedOperationException();
    }
}
