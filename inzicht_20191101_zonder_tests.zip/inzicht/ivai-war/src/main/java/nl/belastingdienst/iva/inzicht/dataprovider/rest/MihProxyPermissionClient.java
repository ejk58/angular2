package nl.belastingdienst.iva.inzicht.dataprovider.rest;

import java.util.Collections;
import java.util.List;

import javax.enterprise.inject.Typed;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.vip.Permission;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@Typed(MihProxyPermissionClient.class)
public class MihProxyPermissionClient extends RestServiceClient {

    private static final String PERMISSIONKEY = "toegestaan"; 
    private static final String CONTACTIMPORTANCEKEY = "contactImportances";
    
    public Permission getPermission(RestCallContext restCallContext, String key) {
        Configuration configuration = restCallContext.getConfiguration();
        QueryInterface mihVipRestQuery = getVipQuery(configuration, key);
        Datasource datasource = configuration.getMihProxyDatasource();
        DataMap[] response = retrieveDataAsMultiMap(datasource, mihVipRestQuery, restCallContext);
        return new Permission(getPermissionAccess(response), getContactImportances(response));
    }

    private QueryInterface getVipQuery(Configuration configuration, String key) {
        if (QueryValueKey.FISCALNR.equals(key)) {
        	return new MihVipRestQuery(configuration.getValueAsString(ConfigurationKey.MIHSUBJECTVIPRESTQUERY));
        } else if (QueryValueKey.ENTITYNR.equals(key)) {
        	return new MihVipRestQuery(configuration.getValueAsString(ConfigurationKey.MIHENTITYVIPRESTQUERY));
        }

    	return null; 
    }
    
    private boolean getPermissionAccess(DataMap[] response) {
    	return Boolean.TRUE.equals(response[0].get(PERMISSIONKEY));
    }
    
    @SuppressWarnings("unchecked")
	private List<String> getContactImportances(DataMap[] response) {
    	Object contactImportances = response[0].get(CONTACTIMPORTANCEKEY);
    	return contactImportances instanceof List ? (List<String>) contactImportances : Collections.emptyList();
    }
}
