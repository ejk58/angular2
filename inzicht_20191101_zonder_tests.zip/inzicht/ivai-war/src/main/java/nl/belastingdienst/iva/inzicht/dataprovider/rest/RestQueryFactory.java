package nl.belastingdienst.iva.inzicht.dataprovider.rest;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractQueryFactory;
import nl.belastingdienst.iva.inzicht.dataprovider.DefaultValueQueryParameterBuilder;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;

public class RestQueryFactory extends AbstractQueryFactory {

    public RestQueryFactory() {
        registerParameterBuilder(QueryParameterType.STRING, new DefaultValueQueryParameterBuilder());
        registerParameterBuilder(QueryParameterType.LISTOFSTRINGS, new DefaultValueQueryParameterBuilder());
    }
    
    public RestQuery getRestQuery(Datasource datasource, QueryInterface query, MultivaluedMap<String, String> queryValues) {
        String basePath = query.getViewName();
        List<QueryResultColumn> columns = mapColumns(query.getQueryColumns());
        
        String requestUrl = query.getQueryTemplate();
        requestUrl = addBaseUrl(requestUrl, datasource);
        requestUrl = addParameters(requestUrl, datasource, queryValues);
        
        return new RestQuery(datasource, requestUrl, basePath, columns);
    }
    
    public RestQuery getRestQuery(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Datasource datasource = query.getDatasource();
        return getRestQuery(datasource, query, queryValues);
    }
    
    private String addBaseUrl(String requestUrl, Datasource datasource) {
        return datasource.getValue(DatasourceKey.RESTURL) + requestUrl;
    }
    
    private String addParameters(String requestUrl, Datasource datasource, MultivaluedMap<String, String> queryValues) {
        MultivaluedMap<String, String> encodedQueryValues = encodeQueryValues(queryValues);
        return replaceParameters(requestUrl, encodedQueryValues, datasource.getParameterMap());
    }
    
    private MultivaluedMap<String, String> encodeQueryValues(MultivaluedMap<String, String> queryValues) {
        MultivaluedMap<String, String> result = new MultiValuedHashMap<>();
        
        try {
            for (Entry<String, List<String>> queryValue : queryValues.entrySet()) { 
                List<String> originalValues = queryValue.getValue();
                List<String> encodedValues = new ArrayList<>();
                
                for (String originalValue : originalValues) {
                    String encodedValue = (originalValue == null ? null : URLEncoder.encode(originalValue, "UTF-8"));
                    encodedValues.add(encodedValue == null ? null : encodedValue.replace("+", "%20"));
                }

                result.put(queryValue.getKey(), encodedValues);
            }
        } catch (UnsupportedEncodingException exception) {
            String message = "Failed to encode the query-parameters with the exception " + ExceptionUtils.getExceptionsForMessage(exception);
            throw new InternalServerErrorException(message, exception);
        }
        
        return result;
    }
}
