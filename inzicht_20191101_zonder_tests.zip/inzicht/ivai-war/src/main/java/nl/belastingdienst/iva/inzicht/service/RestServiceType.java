package nl.belastingdienst.iva.inzicht.service;

public enum RestServiceType {
	DOMAINSERVICE("DomainService/getDomains"),
	PAGESERVICE("PageService/getAllPages"),
	WIDGETSERVICE("WidgetService/getWidget"),
	RELATIONSERVICE("RelationService/getRelations"),
	SUBJECTSERVICE("SubjectService/getSubject"),
	
	EVENTSAVESERVICE("EventService/saveEvent"),
	FEEDBACKLOADSERVICE("FeedbackService/getWidgets"),
	FEEDBACKSAVESERVICE("FeedbackService/saveFeedback"),
	NOTIFICATIONSERVICE("NotificationService/getNotifications"),

	ALIVESERVICE("SystemService/isAlive"),
	SYSTEMSERVICE("SystemService/getStatus"),
	WIZARDSERVICE("WizardService/getSubjects"),
	
	NONE("None");	
	
	private String name;
	
	private RestServiceType(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
