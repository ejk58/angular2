package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.apache.http.impl.client.CloseableHttpClient;

import com.ibm.websphere.security.NotImplementedException;
import com.ibm.wsspi.security.auth.callback.Constants;
import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandlerFactory;

import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;

@Entity
@Table(name = "CONF_DATASOURCE")
@NamedQuery(name = Datasource.QUERY_GETDATASOURCES, query = "SELECT d FROM Datasource d ORDER BY d.key")
public class Datasource {

    public static final String QUERY_GETDATASOURCES = "Datasource.getDatasources"; 
    
    @Id
    private Integer id;
    private String key;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "DATASOURCE_ID")
    private List<DatasourceParam> parameterList;

    @Transient
    private Map<String, String> parameterMap;
    
    @Transient
    private CloseableHttpClient httpClient;

    public Integer getId() {
        return this.id;
    }
    
    public String getKey() {
        return this.key;
    }
    
    public List<DatasourceParam> getParameterList() {
        return Collections.unmodifiableList(this.parameterList);
    }
    
    public Map<String, String> getParameterMap() {
        return (this.parameterMap == null) ? Collections.<String, String>emptyMap() : Collections.unmodifiableMap(this.parameterMap);
    }
    
    public boolean hasParameterMap() {
        return (this.parameterMap != null) && (this.parameterMap.size() > 0);
    }
    
    public String getValue(String key) {
        return this.parameterMap.get(key);
    }

    public Integer getNumber(String key) {
        String value = this.parameterMap.get(key);
        return (value == null) ? null : Integer.parseInt(value);
    }
    
    public boolean getBoolean(String key) {
        String value = this.parameterMap.get(key);
        return DomainUtils.TRUE_ITEM.equalsIgnoreCase(value);
    }
    
    public CloseableHttpClient getHttpClient() {
    	return this.httpClient;
    }
    
    @Override
    public int hashCode() {
        return this.key.hashCode();
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        
        Datasource otherDatasource = (Datasource) object;
        return this.key.equals(otherDatasource.key);
    }

    public void buildParameterMap() throws LoginException {
    	if (this.parameterMap == null) {
    		try {
    			createParameterMap();
    			enhanceParameterMap();
    		} finally {
    			lockParameterMap();
    		}
    	}
    }
    
    public void setHttpClient(CloseableHttpClient httpClient) {
    	this.httpClient = httpClient;
    }
    
    private void createParameterMap() {
        this.parameterMap = new HashMap<>();
        
        for (DatasourceParam parameter : this.parameterList) {
        	this.parameterMap.put(parameter.getKey(), parameter.getValue());
        }
    }
    
    private void enhanceParameterMap() throws LoginException {
        if (this.parameterMap.containsKey(DatasourceKey.CREDENTIALSTYPE) && this.parameterMap.containsKey(DatasourceKey.CREDENTIALSMAPPING)) {
            this.parameterMap.put(DatasourceKey.CREDENTIALSVALUE, getPasswordFromWebsphere());
        }
    }
    
    private void lockParameterMap() {
    	this.parameterMap = Collections.unmodifiableMap(this.parameterMap);
    }
    
    private String getPasswordFromWebsphere() throws LoginException {
    	String credentialsTypeKey = this.parameterMap.get(DatasourceKey.CREDENTIALSTYPE);
    	String credentialsEncodingKey = this.parameterMap.get(DatasourceKey.CREDENTIALSENCODING);
    	String credentialsMappingKey = this.parameterMap.get(DatasourceKey.CREDENTIALSMAPPING);
    	String datasourceKey = this.key;

    	CredentialsType credentialsType = CredentialsType.getCredentialsType(credentialsTypeKey, datasourceKey);
        CredentialsEncoding credentialsEncoding = CredentialsEncoding.getCredentialsEncoding(credentialsEncodingKey, datasourceKey);
        PasswordCredential passwordCredential = getCredentials(credentialsMappingKey);
        return encodeCredentials(credentialsType, credentialsEncoding, passwordCredential);
    }
    
    private PasswordCredential getCredentials(String credentialsAlias) throws LoginException {
        Map<String, String> map = new HashMap<>();
        map.put(Constants.MAPPING_ALIAS, credentialsAlias);
        
        CallbackHandler callbackHandler = getCallbackHandler(map);
        LoginContext loginContext = new LoginContext("DefaultPrincipalMapping", callbackHandler);
        loginContext.login();
        Subject subject = loginContext.getSubject();
        Set<?> credentials = subject.getPrivateCredentials();
        return (PasswordCredential) credentials.iterator().next();
    }
    
    private String encodeCredentials(CredentialsType credentialsType, CredentialsEncoding credentialsEncoding, PasswordCredential passwordCredential) {
    	String credentialsValue = (credentialsType == CredentialsType.LOGINPASSWORD) ? 
    			(passwordCredential.getUserName() + ":" + new String(passwordCredential.getPassword())) : 
   				new String(passwordCredential.getPassword());
    	
        return credentialsEncoding.encodeCredentials(credentialsValue);
    }
    
    private CallbackHandler getCallbackHandler(Map<String, String> map) {
        try {
            return WSMappingCallbackHandlerFactory.getInstance().getCallbackHandler(map, null);
        } catch (NotImplementedException exception) {
            throw new IllegalStateException(exception); 
        }
    }
}
