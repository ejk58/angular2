package nl.belastingdienst.iva.inzicht.database.configuration.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import nl.belastingdienst.iva.inzicht.user.RoleType;

@Entity
@Table(name = "CONF_DOMAIN_ROLE")
public class DomainRole {

    @Id
    private Integer id;
    private Integer type;
    private String role;
    private Boolean vipAccess;

    public Integer getId() {
        return this.id;
    }

    public Integer getType() {
        return this.type;
    }
    
    public String getRole() {
        return this.role;
    }
    
    public RoleType getRoleType() {
        return RoleType.findRoleType(this.type);
    }
    
    public boolean hasVipAccess() {
        return this.vipAccess != null && this.vipAccess;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + this.role.hashCode();
        result = prime * result + this.type.hashCode();
        result = prime * result + this.vipAccess.hashCode();
        return result;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        
        DomainRole otherDomainRole = (DomainRole) object;
        return this.type.equals(otherDomainRole.type) && this.role.equals(otherDomainRole.role) && this.vipAccess.equals(otherDomainRole.vipAccess);
    }

    @Override
    public String toString() {
        RoleType roleType = getRoleType();
        return roleType + " = " + this.role;
    }
}
