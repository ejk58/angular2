package nl.belastingdienst.iva.inzicht.user;

import java.util.List;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class RoleUtils {
    public static final String INZICHT_USER_ROLE = "inzicht.user";

    private RoleUtils() {
        throw new UnsupportedOperationException();
    }

    public static boolean isAuthorizedUser(RestCallContext restCallContext) {
        return isAuthorizedUser(restCallContext.getUser(), restCallContext.getAuthorizedRoles());
    }
    
    public static boolean isAuthorizedUser(User user, List<DomainRole> authorizedRoles) {
        for (DomainRole authorizedRole : authorizedRoles) {
            if (hasRole(user, authorizedRole)) {
                return true;
            }
        }

        return false;
    }

    public static boolean isVipUser(RestCallContext restCallContext) {
        return isVipUser(restCallContext.getUser(), restCallContext.getAuthorizedRoles());
    }
    
    public static boolean isVipUser(User user, List<DomainRole> authorizedRoles) {
        for (DomainRole authorizedRole : authorizedRoles) {
            if (authorizedRole.hasVipAccess() && hasRole(user, authorizedRole)) {
                return true;
            }
        }

        return false;
    }
    
    public static boolean hasRole(User user, DomainRole role) {
        return (role.getRoleType() == RoleType.USER && user.hasName(role.getRole())) || 
                (role.getRoleType() == RoleType.ROLE && user.hasRole(role.getRole()));
    }
}
