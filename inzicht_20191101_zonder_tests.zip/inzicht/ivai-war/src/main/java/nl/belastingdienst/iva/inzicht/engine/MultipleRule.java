package nl.belastingdienst.iva.inzicht.engine;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class MultipleRule implements RuleInterface {

	private String name;
	private List<? extends RuleInterface> rules;

	public MultipleRule(String name, List<? extends RuleInterface> rules) {
		this.name = name;
		this.rules = rules;
	}
	
	@Override
	public Flow apply(RestCallContext restCallContext) {
		for (RuleInterface rule : this.rules) {
			Flow flow = rule.apply(restCallContext);
			if (flow != Flow.CONTINUE) {
				return flow;
			}
		}
		
		return Flow.CONTINUE;
	}
	
	@Override
	public String getRule() {
		return this.name + RulesEngineKey.GROUPSTART + this.rules.stream().map(RuleInterface::getRule).collect(Collectors.joining(",\n")) + RulesEngineKey.GROUPEND;
	}
	
	public String getName() {
		return this.name;
	}
}
