package nl.belastingdienst.iva.inzicht.domain.exception;

import javax.ejb.ApplicationException;

@ApplicationException
public class BadRequestException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    
    public BadRequestException(String message) {
        super(message);
    }
}
