package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

public enum CredentialsTransport {
	URLPARAMETER,
	HTTPHEADER,
	COOKIE;
}
