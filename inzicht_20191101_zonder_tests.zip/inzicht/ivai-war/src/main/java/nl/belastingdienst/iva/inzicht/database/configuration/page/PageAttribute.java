package nl.belastingdienst.iva.inzicht.database.configuration.page;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

@Entity
@Table(name = "CONF_PAGE_ATTRIBUTE")
public class PageAttribute {

    @Id
    private int id;

    private String key;
    private String value;

    @JsonIgnore
    public int getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }    
}
