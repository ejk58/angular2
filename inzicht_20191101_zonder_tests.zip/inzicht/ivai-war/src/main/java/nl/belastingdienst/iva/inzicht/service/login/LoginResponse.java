package nl.belastingdienst.iva.inzicht.service.login;

import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@XmlRootElement(name = "roles")
@XmlAccessorType(XmlAccessType.FIELD)
public class LoginResponse {

    @XmlElement(name = ResponseKey.ROLE)
    private Set<String> roles = new HashSet<>();

    @XmlElement(name = ResponseKey.USERNAME)
    private String username;

    public Set<String> getRoles() {
        return roles;
    }

    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }

    public void addRole(String role) {
        this.roles.add(role);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
