package nl.belastingdienst.iva.inzicht.service.page;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/page")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class PageService extends AbstractRestService {

    @Inject
    private PageMapper pageMapper;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{domainKey}")
    public Response getAllPages(@PathParam("domainKey") String domainKey, @Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        queryValues.add(QueryValueKey.DOMAINKEY, domainKey);
        
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.PAGESERVICE, queryValues);
        
        try {
//            validateFiscalNumber(restCallContext);
            checkRequiredRoles(restCallContext);

            Domain domain = restCallContext.findDomain();
            Configuration configuration = restCallContext.getConfiguration();
            List<Page> pages = configuration.findPagesByDomain(domainKey);
            
            if (pages == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            
            restCallContext.setResponse(this.pageMapper.map(domain, pages));
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
}
