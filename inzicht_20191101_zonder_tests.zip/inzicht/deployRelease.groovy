@Library("GENERIC") _
    pipelineDeployArtifactFromNexus {
	deploymentId = "inzicht"
	integrationPipeline = "inzicht-test"
	packageChoices = "inzicht"
	applicationVersionChoices = "3.28.0\n3.27.0\n3.26.1\n3.26.0\n3.25.0"
	asVersionChoices = "n.v.t"
	environmentChoices = "tst\nont\nacc\nprd"
	streetChoices = "str11/productie\nstr12/opleiding\nstr13\nstr14"
}
