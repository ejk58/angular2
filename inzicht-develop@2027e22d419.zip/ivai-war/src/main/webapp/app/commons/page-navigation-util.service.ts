import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';

import {TrackingService} from '@inzicht/services/tracking.service';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import * as storeActions from '@inzicht/store/actions';
import * as fromSelectors from '@inzicht/store/selectors';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import {Subject} from '@inzicht/classes/subject';
import {Domain} from '@inzicht/classes/domain';
import {Side} from '@inzicht/commons/side';
import {Page} from '@inzicht/classes/page';


@Injectable()
export class PageNavigationUtilService {

  constructor(private readonly router: Router,
    private readonly trackingService: TrackingService,
    private readonly splitViewState: SplitViewState,
    private readonly selectorSideIndicator: SelectorSideIndicator,
    private readonly store: Store) { }

  public openInNewTab(fromSide: string, domainId: string, pageId: string, filter: any, focus: boolean): void {
    if (domainId == null) {
      domainId = this.store.selectSync(fromSelectors.getActiveDomainId(fromSide));
    }

    const parameters = this.composeNavParams(fromSide as Side, pageId, filter);

    const urlTree = this.router.createUrlTree(['/main', { outlets: { left: [domainId, pageId, parameters], right: null } }]);
    const serializedUrl = this.router.serializeUrl(urlTree);
    const win = window.open(`${window.location.pathname}#${serializedUrl}`, '_blank');
    if (focus) {
      win.focus();
    }
  }

  public navigateToPage(side: string, destinationPageId: string, filter: any): void {
    const domainId = this.store.selectSync(fromSelectors.getActiveDomainId(side));
    const parameters = this.composeNavParams(side as Side, destinationPageId, filter);
    this.router.navigate(['/main', { outlets: { [side]: [domainId, destinationPageId, parameters] } }]);
  }

  public navigateToDomain(destinationSide: string, destinationDomainId: string, destinationPageId: string, filter: any): void {
    if (destinationSide === 'right') {
      this.splitViewState.emitOpen2Screen(true);
    }

    this.router.navigate(['/main', { outlets: { [destinationSide]: [destinationDomainId, destinationPageId, filter] } }]);
  }

  public navigate(side: string, destinationSide: string, destinationPageId: string, filter: any): void {
    const activeDomain = this.store.selectSync(fromSelectors.getActiveDomain(side));
    const destinationPageIdLocal = destinationPageId ? destinationPageId : activeDomain.initPageId;
    const parameters = this.composeNavParams(side as Side, destinationPageIdLocal, filter);

    if (side === 'left' && destinationSide === 'right') {
      this.splitViewState.emitOpen2Screen(true);
      this.store.dispatch(storeActions.headerSelectMenu({ side: 'right', menu: 'none' }));
      this.trackingService.trackEvent('klik', 'Tweede scherm/soort:automatisch', destinationPageId, null);
    }

    this.router.navigate(['/main', { outlets: { [destinationSide]: [activeDomain.domainId, destinationPageIdLocal, parameters] } }]);
  }

  public updateBreadcrumb(side: string, widgetId: string, domainId: string, currentPageId: string, newPageId: string): void {
    const pages: { [key: string]: Page } = this.store.selectSync(fromSelectors.getPagesInDomain, {'domainId': domainId});
    const label = pages[currentPageId].title;
    const newLabel = pages[newPageId].title;
    const outlet = {};

    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getRouterState');
    const sideParams = this.store.selectSync(fromSelectors[indicatedRouterStateSelector]);
    outlet[side] = [domainId, currentPageId, sideParams];
    const breadcrumb = {
      label: label,
      routerLink: ['/main', {outlets: outlet}],
      command: (event) => this.breadcrumbBack(side, event)
    };
    this.store.dispatch(storeActions.breadcrumbAdd({side, breadcrumb, newLabel}));
  }

  public breadcrumbBack(side, event) {
    this.store.dispatch(storeActions.breadcrumbRemove({side: side, breadcrumb: event.item}));
  }

  /*
  * @deprecated Deprecated in favor of using navigate method.
  */
  public navToPageSecondScreen(pageId: string, open2Screen: boolean = true, subject?: Subject) {
    this.splitViewState.emitOpen2Screen(open2Screen);
    this.store.dispatch(storeActions.headerSelectMenu({ side: 'right', menu: 'none' }));

    this.trackingService.trackEvent('klik', 'Tweede scherm/soort:zelf', pageId, null);

    const activeDomain = this.store.selectSync(fromSelectors.getActiveDomain('left'));
    if (activeDomain) {
      if (subject) {
        this.selectDomainAndSubject(activeDomain, pageId, 'left', subject);

        const mandatoryPathKeys = this.getMandatoryPathKeys(activeDomain.domainId, pageId);
        const subjectModel: Object = this.constructParams(subject.model, mandatoryPathKeys);
        this.updateSubject('right', activeDomain, subjectModel);
      } else {
        this.selectDomain(activeDomain);
      }
    }
  }

  private composeNavParams(side: Side, destinationPageId: string, filter: any): any {
    const sideParams = this.store.selectSync(fromSelectors.getRouterSides)[side];
    const mandatoryPathKeys: string[] = this.getMandatoryPathKeys(sideParams.domainId, destinationPageId);
    const navParams: any = this.constructParams(sideParams, mandatoryPathKeys);

    // add the filter values on top of it (only when not null)
    if (filter) {
      Object.keys(filter)
        .filter(filterKey => filter[filterKey] !== null)
        .forEach(filterKey => navParams[filterKey] = filter[filterKey]);
    }

    return navParams;
  }

  private updateSubject(side: Side, domain: Domain, subjectModel: Object): void {
    this.store.dispatch(storeActions.subjectLoad({
      side,
      domain,
      subjectModel
    }));
  }

  private selectDomain(domain: Domain): void {
    this.store.dispatch(storeActions.selectDomainWithoutSubject({
      side: 'right',
      domain
    }));
  }

  private selectDomainAndSubject(domain: Domain, pageId: string, fromSide: Side, subject: Subject): void {
    const mandatoryPathKeys: string[] = this.getMandatoryPathKeys(domain.domainId, pageId);
    this.store.dispatch(storeActions.selectDomainWithSubject({
      side: 'right',
      domain,
      subject,
      params: this.constructParams(subject.model, mandatoryPathKeys)
    }));
  }

  private constructParams(sourceValues: any, mandatoryPathKeys: string[]): any {
    // const params = {}; // TODO-overleg hierdoor verlies je entityNr als je bijv van Klantprofiel -> Compliance gaat
    const {pageId, domainId, ...params} = sourceValues;
    mandatoryPathKeys.forEach(mpk => params[mpk] = sourceValues[mpk]);
    return params;
  }

  private getMandatoryPathKeys(domainId: string, pageId: string): string[] {
    const page: Page = this.store.selectSync(fromSelectors.getPageInDomain, {'domainId': domainId, 'pageId': pageId});
    return page.mandatoryPathKeys;
  }
}
