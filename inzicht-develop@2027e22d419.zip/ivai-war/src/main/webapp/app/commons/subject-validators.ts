import {Message} from '@inzicht/classes/message';

export class SubjectValidator {

  public checkValidSubjectNr(nr: any): boolean {
    nr = (nr == null) ? null : nr.replace(/[\./,]/g, '');
    if (nr != null && !isNaN(nr) && nr.length <= 9) {
      let checksum = 0;

      while (nr.length < 9) {
        nr = `0${nr}`;
      }
      for (let i = 0; i < 8; i++) {
        checksum += (nr.charAt(i) * (9 - i));
      }
      checksum -= nr.charAt(8);

      return checksum % 11 === 0;
    } else {
      return false;
    }
  }

  public checkValidEntityNr(nr: any): boolean {
    nr = (nr == null) ? null : nr.replace(/[\./,]/g, '');
    return (nr != null && !isNaN(nr));
  }

  public getErrorCode(httpStatusCode: number, subjectType: string, subjectNumber: any): number {
    switch (httpStatusCode) {
      case 400:
        return this.getErrorCodeForHttpStatus400(subjectType, subjectNumber);
      case 401:
        return this.getErrorCodeForHttpStatus401();
      case 403:
        return this.getErrorCodeForHttpStatus403();
      case 404:
        return this.getErrorCodeForHttpStatus404(subjectType, subjectNumber);
      case 500:
        return this.getErrorCodeForHttpStatus500(subjectType, subjectNumber);
      default:
        return this.getDefaultErrorCode(httpStatusCode);
    }
  }

  private getErrorCodeForInvalidSearchValue(subjectType: string, searchValue: string): number {
    if (subjectType === 'subjectNr' && !this.checkValidSubjectNr(searchValue)) {
      return Message.invalidSubjectNrCode;
    }

    if (subjectType === 'entityNr' && !this.checkValidEntityNr(searchValue)) {
      return Message.invalidEntityNrCode;
    }

    return undefined;
  }

  private getErrorCodeForHttpStatus400(subjectType: string, searchValue: any): number {
    const errorCode = this.getErrorCodeForInvalidSearchValue(subjectType, searchValue);
    return errorCode ? errorCode : Message.invalidSearchValueCode;
  }

  private getErrorCodeForHttpStatus401(): number {
    return Message.notAuthorizedCode;
  }

  private getErrorCodeForHttpStatus403(): number {
    return Message.forbiddenCode;
  }

  private getErrorCodeForHttpStatus404(subjectType: string, searchValue: any): number {
    const errorCode = this.getErrorCodeForInvalidSearchValue(subjectType, searchValue);
    return errorCode ? errorCode : Message.noResultsCode;
  }

  private getErrorCodeForHttpStatus500(subjectType: string, searchValue: any): number {
    const errorCode = this.getErrorCodeForInvalidSearchValue(subjectType, searchValue);
    return errorCode ? errorCode : Message.internalServerErrorCode;
  }

  private getDefaultErrorCode(httpStatusCode: number): number {
    return httpStatusCode;
  }
}
