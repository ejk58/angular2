import {createAction, union} from '@ngrx/store';

export const loadRelations = createAction(
  '[Relations Menu] Load Menu',
  (payload: {side: string, domainId: string, subjectModel: Object}) => ({payload})
);

export const loadRelationsSuccess = createAction(
  '[Relations Menu] Load Menu Success',
  (payload: {side: string; list: any}) => ({payload})
);

export const loadRelationsFailed = createAction(
  '[Relations Menu] Load Menu Failed',
  (payload: any) => ({payload})
);

export const resetRelations = createAction(
  '[Relations Menu] Reset'
);

const actions = union({
  loadRelations,
  loadRelationsSuccess,
  loadRelationsFailed,
  resetRelations
});

export type RelationsActionsUnion = typeof actions;

