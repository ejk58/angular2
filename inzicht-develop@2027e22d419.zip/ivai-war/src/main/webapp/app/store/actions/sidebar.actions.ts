import {createAction, union} from '@ngrx/store';

export const sidebarOpen = createAction(
  '[SIDEBAR] Open',
  (payload: { type: string, widgetTitle?: string, widgetId?: string, side?: string }) => ({payload})
);

export const sidebarClose = createAction(
  '[SIDEBAR] Close'
);

const actions = union({
  SidebarOpen: sidebarOpen,
  SidebarClose: sidebarClose
});

export type SidebarActionsUnion = typeof actions;

