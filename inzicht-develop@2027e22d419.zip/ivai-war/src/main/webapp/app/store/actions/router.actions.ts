import {createAction, union} from '@ngrx/store';
import {NavigationExtras} from '@angular/router';
import {Domain} from '@inzicht/classes/domain';

export const go = createAction(
  '[Router] Go',
  (payload: {
    path: any[];
    query?: object;
    extras?: NavigationExtras;
  }) => ({payload})
);

export const goTo = createAction(
  '[Router] Go To',
  (payload: {
    side: string,
    domainId: string;
    pageId: string;
    params: any;
  }) => ({payload})
);

export const navigateWithoutParams = createAction(
  '[Router] Navigate Without Params',
  (payload: {
    side: string,
    domainId: string;
    initPageId: string;
  }) => ({payload})
);

export const navigateWithParams = createAction(
  '[Router] Navigate With Params',
  (payload: {
    side: string,
    domain: Domain,
    pageId?: string,
    params: any
  }) => ({payload})
);

export const back = createAction(
  '[Router] Back'
);

export const forward = createAction(
  '[Router] Forward'
);

const actions = union({
  go,
  goTo,
  navigateWithoutParams,
  navigateWithParams,
  back,
  forward
});

export type RouterActionsUnion = typeof actions;
