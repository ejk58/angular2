import {createAction, union} from '@ngrx/store';
import {Domain} from '@inzicht/classes/domain';

export const loadConfig = createAction(
  '[CONFIG] Load Config'
);

export const loadConfigSuccess = createAction(
  '[CONFIG] Load Config Success',
  (payload: {'domains': {[key: string]: Domain}, 'menuItems': Domain[]}) => ({payload})
);

export const loadConfigFailed = createAction(
  '[CONFIG] Load Config Failed',
  (payload: any) => ({payload})
);

export const resetConfig = createAction(
  '[CONFIG] Reset Config'
);

const actions = union({
  loadConfig,
  loadConfigSuccess,
  loadConfigFailed,
  resetConfig
});

export type ConfigActionsUnion = typeof actions;
