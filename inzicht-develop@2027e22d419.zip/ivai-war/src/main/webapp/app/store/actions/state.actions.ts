import {createAction, union} from '@ngrx/store';
import {Side} from '@inzicht/commons/side';
import {Domain} from '@inzicht/classes/domain';

export type StateActionPayload = {
  side: Side,
  domain?: Domain,
  domainId?: string,
  pageId?: string,
  widgetId?: string,
  subject?: any,
  state?: {[key: string]: any}
  params?: any
}

export const selectDomainWithoutSubject = createAction(
  '[Domain] Select Without Subject',
  (payload: StateActionPayload) => ({payload})
);

export const selectDomainWithSubject = createAction(
  '[Domain] Select With Subject',
  (payload: StateActionPayload) => ({payload})
);

export const setDomainState = createAction(
  '[STATE] Set Domain State',
  (payload: StateActionPayload) => ({payload})
);

export const updateDomainState = createAction(
  '[STATE] Update Domain State',
  (payload: StateActionPayload) => ({payload})
);

export const setPageState = createAction(
  '[STATE] Set Page State',
  (payload: StateActionPayload) => ({payload})
);

export const updatePageState = createAction(
  '[STATE] Update Page State',
  (payload: StateActionPayload) => ({payload})
);

export const setWidgetState = createAction(
  '[STATE] Set Widget State',
  (payload: StateActionPayload) => ({payload})
);

export const updateWidgetState = createAction(
  '[STATE] Update Widget State',
  (payload: StateActionPayload) => ({payload})
);

export const clearState = createAction(
  '[STATE] Clear State',
  (payload: StateActionPayload) => ({payload})
);

const actions = union({
  selectDomainWithoutSubject,
  selectDomainWithSubject,
  setDomainState,
  updateDomainState,
  setPageState,
  updatePageState,
  setWidgetState,
  updateWidgetState,
  clearState
});

export type StateActionsUnion = typeof actions;
