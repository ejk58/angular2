import {createAction, union} from '@ngrx/store';

export const headerSelectMenu = createAction(
  '[HEADER] Select Menu',
  (payload: {side: string; menu: string; }) => ({payload})
);

export const headerReset = createAction(
  '[HEADER] Reset'
);

const actions = union({
  headerSelectMenu,
  headerReset
});

export type HeaderActionsUnion = typeof actions;

