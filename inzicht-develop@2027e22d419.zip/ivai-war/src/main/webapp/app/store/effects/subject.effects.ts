import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {of} from 'rxjs';
import {catchError, ignoreElements, map, mergeMap, tap} from 'rxjs/operators';
import {SubjectActionsUnion, subjectFind, subjectFindSuccess, subjectFindFailed, subjectLoad, subjectSelect, subjectLoadFailed} from '@inzicht/store/actions/index';
import {PageTitleService} from '@inzicht/services/page-title.service';
import {Subject} from '@inzicht/classes/subject';
import {SubjectPresentation} from '@inzicht/classes/subject-presentation';
import {SubjectPresentationLabel} from '@inzicht/classes/subject-presentation-label';

@Injectable()
export class SubjectEffects {
  constructor(
    private readonly action$: Actions<SubjectActionsUnion>,
    private readonly http: HttpClient,
    private readonly pageTitleService: PageTitleService) { }

  findSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(subjectFind.type),
      mergeMap((action) => {
        const domainId = action.payload.domain.domainId;
        const domainName = action.payload.domain.name;
        const side = action.payload.side;
        const subjectSearchType = action.payload.searchType.type;
        const subjectSearchKey = action.payload.searchKey;
        const url = `rest/subject/find?domainId=${domainId}&${subjectSearchType}=${subjectSearchKey}`;

        return this.http
          .get(url, {withCredentials: true})
          .pipe(map((subjects: Subject[]) => {
            return subjectFindSuccess({
              side: side,
              domainId: domainId,
              domainName: domainName,
              subjects: subjects,
              subjectSearchKey: subjectSearchKey,
              type: subjectSearchType,
              err: (subjects.length > 0 ? undefined : 404)
            });
          }))
          .pipe(catchError((error: HttpErrorResponse) => {
            return of(subjectFindFailed({
              side: side,
              domainId: domainId,
              domainName: domainName,
              subjects: undefined,
              subjectSearchKey: subjectSearchKey,
              type: subjectSearchType,
              err: error.status
            }));
          }));
      }));
  });

  // This effect will be triggered only for url navigation
  loadSubject$ = createEffect(() => {
    return this.action$.pipe(
      ofType(subjectLoad.type),
      mergeMap((action) => {
        const domainId = action.payload.domain.domainId;
        const side = action.payload.side;
        const subjectModel = action.payload.subjectModel;
        const urlParameters = Object.keys(subjectModel).map(modelKey => `&${modelKey}=${subjectModel[modelKey]}`).join('');
        const url = `rest/subject/get?domainId=${domainId}${urlParameters}`;

        return this.http
          .get(url, {withCredentials: true})
          .pipe(map((subjectResponse: Subject) => {
            const subject = subjectResponse ? subjectResponse : this.createErrorSubject(subjectModel);
            return subjectSelect({side, subject: subject});
          }))
          .pipe(catchError((error: HttpErrorResponse) => {
            console.error(error);
            const subject = this.createErrorSubject(subjectModel);
            return of(subjectLoadFailed({side, subject: subject}));
          }));
      }));
  });

  selectSubject$ = createEffect(() => this.action$.pipe(
    ofType(subjectSelect.type),
    tap((action) => this.setPageTitle(action.payload.side, action.payload.subject)),
    ignoreElements()
  ), {dispatch: false});

  loadSubjectFailed$ = createEffect(() => this.action$.pipe(
    ofType(subjectLoadFailed.type),
    tap((action) => this.setPageTitle(action.payload.side, action.payload.subject)),
    ignoreElements()
  ), {dispatch: false});

  private createErrorSubject(subjectModel: Object): Subject {
    const label: SubjectPresentationLabel = new SubjectPresentationLabel('FOUT', 'white', 'red');
    const presentation: SubjectPresentation = new SubjectPresentation('???', '???', 'Er is een fout opgetreden', label);
    return new Subject(presentation, subjectModel);
  }

  private setPageTitle(side: string, subject: Subject): void {
    if (side === 'left' && subject && subject.model) {
      const pageTitleNr = subject.model['subjectNr'] ? subject.model['subjectNr'] : subject.model['entityNr'];
      this.pageTitleService.update(pageTitleNr, subject.presentation.name);
    }
  }
}
