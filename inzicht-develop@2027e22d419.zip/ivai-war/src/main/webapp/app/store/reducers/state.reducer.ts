import {StateActionsUnion, setDomainState, updateDomainState, setPageState, updatePageState, setWidgetState, updateWidgetState, clearState} from '@inzicht/store/actions/state.actions';
import {SubjectActionsUnion, subjectFindSuccess, subjectFindFailed} from '@inzicht/store/actions/subject.actions';
import {GlobalActionsUnion, logout} from '@inzicht/store/actions/multi-state.actions';
import {DynamicSideIndicator} from '@inzicht/commons/dynamic-side-indicator';
import {SubjectValidator} from '@inzicht/commons/subject-validators';

const sideIndicator = new DynamicSideIndicator();
const subjectValidator = new SubjectValidator();

export interface MainState {
  [key: string]: any;
  errorCode: number;
}

export interface SideState {
  domains: { [key: string]: any; };
  pages: { [key: string]: any; };
  widgets: { [key: string]: any; };
  errorCode: number;
}

export interface State {
  left: SideState;
  right: SideState;
  main: MainState;
}

export const initialState: State = {
  'left': { 'domains': {}, 'pages': {}, 'widgets': {}, 'errorCode': 0 },
  'right': { 'domains': {}, 'pages': {}, 'widgets': {}, 'errorCode': 0 },
  'main': { 'errorCode': 0 }
};

function reduceSetComponentState(state: State, componentType: string, componentKey: string, action: any): State {
  const { updateSide, staticSide } = sideIndicator.getSides(action.payload.side);
  const componentId = action.payload[componentKey];
  const newComponentState = action.payload.state;
  const newSideState = {...state[updateSide], [componentType]: {...state[updateSide][componentType], [componentId]: newComponentState}};

  return {
    'left': updateSide === 'left' ? newSideState : state[staticSide],
    'right': updateSide === 'right' ? newSideState : state[staticSide],
    'main': state['main']
  };
}

function reduceUpdateComponentState(state: State, componentType: string, componentKey: string, action: any): State {
  const { updateSide, staticSide } = sideIndicator.getSides(action.payload.side);
  const componentId = action.payload[componentKey];
  const oldComponentState = state[updateSide][componentType][componentId] ? state[updateSide][componentType][componentId] : {};
  const newComponentState = {...oldComponentState, ...action.payload.state};
  const newSideState = {...state[updateSide], [componentType]: {...state[updateSide][componentType], [componentId]: newComponentState}};

  return {
    'left': updateSide === 'left' ? newSideState : state[staticSide],
    'right': updateSide === 'right' ? newSideState : state[staticSide],
    'main': state['main']
  };
}

function reduceSetDomainState(state: State, action: any): State {
  return reduceSetComponentState(state, 'domains', 'domainId', action);
}

function reduceUpdateDomainState(state: State, action: any): State {
  return reduceUpdateComponentState(state, 'domains', 'domainId', action);
}

function reduceLoadSearchResultsInDomainState(state: State, action: any): State {
  const errorCode = action.payload.err ? subjectValidator.getErrorCode(action.payload.err, action.payload.type, action.payload.subjectSearchKey) : 0;
  const newSearchResults = {
    'subjects': action.payload.subjects,
    'subjectSearchKey': action.payload.subjectSearchKey,
    'errorCode': errorCode
  };
  const newPayload = {
    'side': action.payload.side,
    'domainId': action.payload.domainId,
    'state': { 'searchResults': newSearchResults }
  };

  return reduceUpdateComponentState(state, 'domains', 'domainId', { 'payload': newPayload });
}

function reduceSetPageState(state: State, action: any): State {
  return reduceSetComponentState(state, 'pages', 'pageId', action);
}

function reduceUpdatePageState(state: State, action: any): State {
  return reduceUpdateComponentState(state, 'pages', 'pageId', action);
}

function reduceSetWidgetState(state: State, action: any): State {
  return reduceSetComponentState(state, 'widgets', 'widgetId', action);
}

function reduceUpdateWidgetState(state: State, action: any): State {
  return reduceUpdateComponentState(state, 'widgets', 'widgetId', action);
}

function reduceClearState(state: State, action: any): State {
  const { updateSide, staticSide } = sideIndicator.getSides(action.payload.side);

  return {
    'left': updateSide === 'left' ? initialState[updateSide] : state[staticSide],
    'right': updateSide === 'right' ? initialState[updateSide] : state[staticSide],
    'main': state['main']
  };
}

function reduceResetState(): State {
  return initialState;
}

export function stateReducer(state = initialState, action: StateActionsUnion | SubjectActionsUnion | GlobalActionsUnion): State {
  switch (action.type) {
    case setDomainState.type: return reduceSetDomainState(state, action);
    case updateDomainState.type: return reduceUpdateDomainState(state, action);
    case subjectFindSuccess.type: return reduceLoadSearchResultsInDomainState(state, action);
    case subjectFindFailed.type: return reduceLoadSearchResultsInDomainState(state, action);
    case setPageState.type: return reduceSetPageState(state, action);
    case updatePageState.type: return reduceUpdatePageState(state, action);
    case setWidgetState.type: return reduceSetWidgetState(state, action);
    case updateWidgetState.type: return reduceUpdateWidgetState(state, action);
    case clearState.type: return reduceClearState(state, action);
    case logout.type: return reduceResetState();
    default: return state;
  }
}
