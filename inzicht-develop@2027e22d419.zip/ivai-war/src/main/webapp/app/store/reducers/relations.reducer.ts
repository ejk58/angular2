import {DynamicSideIndicator} from '@inzicht/commons/dynamic-side-indicator';
import {RelationsActionsUnion, loadRelations, loadRelationsFailed, loadRelationsSuccess, resetRelations} from '@inzicht/store/actions/relation.actions';

const sideGenerator = new DynamicSideIndicator();

export interface RelationsState {
  left?: {
    loading: boolean;
    error?: string;
    list: any;
  };
  right?: {
    loading: boolean;
    error?: string;
    list: any;
  };
}

export const initialRelationsState: RelationsState = {
  left: {
    loading: false,
    list: [],
  },
  right: {
    loading: false,
    list: []
  }
};

function relationsLoad(state: RelationsState, action) {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: true,
      list: state[updateSide].list
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      error: state[staticSide].error,
      list: state[staticSide].list
    }
  };
}

function relationsLoadSuccess(state: RelationsState, action) {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: false,
      list: action.payload.list
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      error: state[staticSide].error,
      list: state[staticSide].list
    }
  };
}

function relationsLoadFailed(state: RelationsState, action) {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    [updateSide]: {
      loading: false,
      error: action.payload.error.status,
      list: []
    },
    [staticSide]: {
      loading: state[staticSide].loading,
      error: state[staticSide].error,
      list: state[staticSide].list
    }
  };
}

export function relationsdReducer(state = initialRelationsState, action: RelationsActionsUnion): RelationsState {
  switch (action.type) {
    case loadRelations.type: return relationsLoad(state, action);
    case loadRelationsSuccess.type: return relationsLoadSuccess(state, action);
    case loadRelationsFailed.type: return relationsLoadFailed(state, action);
    case resetRelations.type: return initialRelationsState;
    default: return state;
  }
}
