import {SubjectActionsUnion, subjectFind, subjectFindSuccess, subjectFindFailed, subjectLoad, subjectLoadFailed, subjectSelect, subjectClear, subjectReset} from '@inzicht/store/actions/index';
import {GlobalActionsUnion, logout} from '@inzicht/store/actions/multi-state.actions';
import {DynamicSideIndicator} from '@inzicht/commons/dynamic-side-indicator';
import {Subject} from '@inzicht/classes/subject';

const sideGenerator = new DynamicSideIndicator();

export interface SubjectState {
  loading: boolean;
  left?: {
    selected: Subject;
  };
  right?: {
    selected: Subject;
  };
}

export const initialSubjectState: SubjectState = {
  loading: false,
  left: {
    selected: null
  },
  right: {
    selected: null
  }
};

function loadSubjectFailed(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    [updateSide]: {
      selected: action.payload.subject
    },
    [staticSide]: {
      selected: state[staticSide].selected
    }
  };
}

function selectSubject(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    [updateSide]: {
      selected: action.payload.subject
    },
    [staticSide]: {
      selected: state[staticSide].selected
    }
  };
}

function clearSubject(state: SubjectState, action): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    [updateSide]: {
      selected: null
    },
    [staticSide]: {
      selected: state[staticSide].selected
    }
  };
}

export function subjectReducer(state = initialSubjectState, action: SubjectActionsUnion | GlobalActionsUnion): SubjectState {
  switch (action.type) {
    case subjectFind.type: return { ...state,  loading: true };
    case subjectFindSuccess.type: return { ...state,  loading: false };
    case subjectFindFailed.type: return { ...state,  loading: false };
    case subjectLoad.type: return { ...state,  loading: true };
    case subjectLoadFailed.type: return loadSubjectFailed(state, action);
    case subjectSelect.type: return selectSubject(state, action);
    case subjectClear.type: return clearSubject(state, action);
    case subjectReset.type: return initialSubjectState;
    case logout.type: return initialSubjectState;
    default: return state;
  }
}
