import {HttpError} from '@inzicht/commons/http-error';
import {ReleaseNote} from '@inzicht/commons/release-note';
import {ReleaseNotesActionsUnion, loadReleaseNotes, loadReleaseNotesFailed, loadReleaseNotesSuccess} from '@inzicht/store/actions';
import {GlobalActionsUnion, logout} from '@inzicht/store/actions/multi-state.actions';

export interface ReleaseNotesState {
  error?: HttpError;
  loading: boolean;
  releaseNotes: ReleaseNote[];
}

export const initialReleaseNotesState = {
  'loading': false,
  'releaseNotes': []
};

function loadNewReleaseNotes() {
  return {
    'error': undefined,
    'loading': true,
    'releaseNotes': []
  };
}

function setReleaseNotes(action) {
  return {
    'loading': false,
    'releaseNotes': action.payload.releaseNotes
  };
}

function setReleaseNotesError(action) {
  return {
    'error': {'statusCode': action.payload.status, 'statusText': action.payload.statusText, 'message': action.payload.message},
    'loading': false,
    'releaseNotes': []
  };
}

export function releaseNotesReducer(state = initialReleaseNotesState, action: ReleaseNotesActionsUnion | GlobalActionsUnion): ReleaseNotesState {
  switch (action.type) {
    case loadReleaseNotes.type: return loadNewReleaseNotes();
    case loadReleaseNotesSuccess.type: return setReleaseNotes(action);
    case loadReleaseNotesFailed.type: return setReleaseNotesError(action);
    case logout.type: return initialReleaseNotesState;
    default: return state;
  }
}
