import {SystemActionsUnion, systemLoad, systemConfigurationLoadFailed, systemConfigurationLoadSuccess, systemVersionLoadFailed, systemVersionLoadSuccess} from '@inzicht/store/actions/system.actions';

export interface SystemState {
  errorCode?: number;
  version: string;
  configurationUpdateTime: string;
  ktaEnvironment: string;
  hierarchicalGraphMaxRows: number;
  tablePaginatorPositionBothThreshold: number;
  widgetDataExpirationTimeInMilliseconds: number;
  jiraAttachmentsAvailable: boolean;
  jiraAttachmentsMaxFileSize: number;
  jiraAttachmentsFileLimit: number;
}

export const initialSystemState = {
  version: 'unknown',
  configurationUpdateTime: '',
  ktaEnvironment: '',
  hierarchicalGraphMaxRows: 500,
  tablePaginatorPositionBothThreshold: 25,
  widgetDataExpirationTimeInMilliseconds: 60000,
  jiraAttachmentsAvailable: false,
  jiraAttachmentsMaxFileSize: 256000,
  jiraAttachmentsFileLimit: 3
};


export function systemReducer(state = initialSystemState, action: SystemActionsUnion): SystemState {
  switch (action.type) {
    case systemLoad.type:
      return {...state};

    case systemVersionLoadSuccess.type:
      return {...state, version: action.payload};

    case systemVersionLoadFailed.type:
      return {...state, errorCode: (action.payload && action.payload.status ? action.payload.status : -1)};

    case systemConfigurationLoadSuccess.type:
      return {...state,
              configurationUpdateTime: action.payload.configurationUpdateTime,
              ktaEnvironment: action.payload.ktaEnvironment,
              hierarchicalGraphMaxRows: +action.payload.hierarchicalGraphMaxRows,
              tablePaginatorPositionBothThreshold: +action.payload.tablePaginatorPositionBothThreshold,
              widgetDataExpirationTimeInMilliseconds: +action.payload.widgetDataExpirationTimeInMilliseconds,
              jiraAttachmentsAvailable: action.payload.jiraAttachmentsAvailable === 'true',
              jiraAttachmentsMaxFileSize: +action.payload.jiraAttachmentsMaxFileSize,
              jiraAttachmentsFileLimit: +action.payload.jiraAttachmentsFileLimit

      };

    case systemConfigurationLoadFailed.type:
      return {...state, errorCode: (action.payload && action.payload.status ? action.payload.status : -1)};

    default:
      return state;
  }
}
