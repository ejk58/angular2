import {inject, TestBed} from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {CookieService} from 'ngx-cookie-service';
import {TrackingService} from './tracking.service';


describe('TrackingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        TrackingService, CookieService
      ]
    });
  });

  describe('trackEvent', () => {
    it('should create a POST with the right contents',
      inject([TrackingService, HttpTestingController, CookieService], (trackingService: TrackingService, httpMock: HttpTestingController, cookieService: CookieService) => {
        trackingService
          .trackEvent('hetType', 'deValue1', 'deValue2', 'hetSubject');

        const request = httpMock.expectOne('rest/event');
        // verify it is a POST
        expect(request.request.method).toEqual('POST');
        // verify body
        expect(request.request.body['subjectNumber']).toEqual('hetSubject');
        expect(request.request.body['type']).toEqual('hetType');
        expect(request.request.body['value1']).toEqual('deValue1');
        expect(request.request.body['value2']).toEqual('deValue2');
        expect(request.request.body['trackingid'].length).toEqual(8);
        expect(request.request.body['url']).toBeDefined();
      }));
  });

  describe('trackEvent error', () => {
    beforeEach(() => {
      spyOn(console, 'error');
    });
    it('should create an error on the console',
      inject([TrackingService, HttpTestingController, CookieService], (trackingService: TrackingService, httpMock: HttpTestingController, cookieService: CookieService) => {
        trackingService
          .trackEvent(null, null, null, null);

        httpMock.expectOne('rest/event').error(new ErrorEvent('error'));
        expect(console.error).toHaveBeenCalledTimes(1);
        expect(console.error).toHaveBeenCalledWith('Failed to store the event in the database with the error: Http failure response for rest/event: 0 ');
      }));
  });

});
