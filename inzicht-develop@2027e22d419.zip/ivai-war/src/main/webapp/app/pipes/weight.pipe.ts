import { Pipe, PipeTransform } from '@angular/core';
import {DecimalPipe} from '@angular/common';

@Pipe({
  name: 'weight'
})
export class WeightPipe implements PipeTransform {

  constructor(private readonly dp: DecimalPipe) { }

  transform(value: any): string {
    if ( isNaN(value) ) {
      return value;
    } else {
      return '<span class="weight">' + this.dp.transform(value, '1.0-3') + ' kg</span>';
    }
  }
}
