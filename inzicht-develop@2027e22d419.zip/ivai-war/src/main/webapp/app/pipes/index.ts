import {IdPipe} from '@inzicht/pipes/id.pipe';
import {TrendStringPipe} from '@inzicht/pipes/trend-string.pipe';
import {MoneyPipe} from '@inzicht/pipes/money.pipe';
import {TrendMoneyPipe} from '@inzicht/pipes/trend-money.pipe';
import {WeightPipe} from '@inzicht/pipes/weight.pipe';
import {PercentagePipe} from '@inzicht/pipes/percentage.pipe';
import {ReplaceVarsPipe} from '@inzicht/pipes/replace-vars.pipe';
import {TextWithPlaceholdersPipe} from '@inzicht/pipes/text-with-placeholders.pipe';
import {ComplianceLightPipe} from '@inzicht/pipes/compliance-light.pipe';
import {SubjectFilterPipe} from '@inzicht/pipes/subject-filter.pipe';
import {InzichtDatePipe} from '@inzicht/pipes/inzicht-date.pipe';
import {DateTimePipe} from '@inzicht/pipes/date-time.pipe';
import {PlusSignPipe} from '@inzicht/pipes/plus-sign.pipe';
import {BooleanPipe} from '@inzicht/pipes/boolean.pipe';
import {FileSizePipe} from '@inzicht/pipes/file-size.pipe';

export const list = [
  IdPipe,
  TrendStringPipe,
  MoneyPipe,
  TrendMoneyPipe,
  PercentagePipe,
  WeightPipe,
  ComplianceLightPipe,
  ReplaceVarsPipe,
  TextWithPlaceholdersPipe,
  SubjectFilterPipe,
  InzichtDatePipe,
  DateTimePipe,
  PlusSignPipe,
  BooleanPipe,
  FileSizePipe
];
