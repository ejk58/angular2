import {Pipe, PipeTransform} from '@angular/core';
import {TextParser} from '@inzicht/components/text/text-parser';

@Pipe({
  name: 'textWithPlaceholders'
})
export class TextWithPlaceholdersPipe implements PipeTransform {

  private textParser: TextParser;

  constructor() {
    this.textParser = new TextParser();
  }

  transform(text: any, label: string): string {
    if (typeof text == 'string' && text.indexOf('#') > -1) {
      text = this.replacePlaceholder(text, label);
    }

    return text;
  }

  private replacePlaceholder(text: string, label: string): string {
    const replacementLabel = (label != null) ? label : ' ';
    const textBlocks = this.textParser.parse(text);
    const cleanText = textBlocks.map(textBlock => textBlock.plainText ? textBlock.text : replacementLabel).join('');
    return cleanText;
  }
}
