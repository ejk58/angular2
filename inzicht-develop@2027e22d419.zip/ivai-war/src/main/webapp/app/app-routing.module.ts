import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoggedInGuard} from '@inzicht/components/login/logged-in.guard';
import {BdStylesheetComponent} from '@inzicht/components/bd-stylesheet/bd-stylesheet.component';

import {LoginComponent} from '@inzicht/components/login/login.component';
import {PageComponent} from '@inzicht/components/page/page.component';
import {MainComponent} from '@inzicht/components/main/main.component';
import {DeepLinkComponent} from '@inzicht/components/deep-link/deep-link.component';

import {DomainResolver} from '@inzicht/components/domain/resolver/domain.resolver';
import {PageResolver} from '@inzicht/components/page/resolver/page.resolver';
import {SystemResolver} from '@inzicht/components/main/resolver/system.resolver';

const routes: Routes = [
  { path: 'style', component: BdStylesheetComponent },
  { path: 'login', component: LoginComponent },
  {
    path: 'main',
    component: MainComponent,
    canActivate: [LoggedInGuard],
    resolve: { DomainResolver, SystemResolver },
    children: [
      {
        path: ':domainId/:pageId',
        component: PageComponent,
        canActivate: [LoggedInGuard],
        resolve: { PageResolver },
        outlet: 'left'
      },
      {
        path: ':domainId/:pageId',
        component: PageComponent,
        canActivate: [LoggedInGuard],
        resolve: { PageResolver },
        outlet: 'right'
      }
    ]
  },
  {
    path: 'deep/:domainId/:pageId',
    component: DeepLinkComponent,
    canActivate: [LoggedInGuard],
    resolve: { DomainResolver }
  },
  {
    path: 'deep/:domainId',
    component: DeepLinkComponent,
    canActivate: [LoggedInGuard],
    resolve: { DomainResolver }
  },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, enableTracing: false, relativeLinkResolution: 'legacy' })],
  exports: [RouterModule],
  providers: [DomainResolver, PageResolver, SystemResolver]
})
export class InzichtRoutingModule { }
