import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';

import {Store} from '@ngrx/store';
import {combineLatest, Observable} from 'rxjs';
import {catchError, map} from 'rxjs/operators';

import * as fromSelectors from '@inzicht/store/selectors';

interface Viewmodel {
  version: string,
  currentRoute: string;
}

@Component({
  selector: 'i-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  vm$!: Observable<Viewmodel>;

  constructor(private readonly route: ActivatedRoute,
              private readonly store: Store) {}

  ngOnInit() {
    const version$: Observable<string> = this.store.select(fromSelectors.getSystemVersionState);
    const currentRoute$: Observable<Params> = this.route.params;

    this.vm$ = combineLatest([version$, currentRoute$])
      .pipe(map(value => {
        return {
          version: value[0],
          currentRoute: this.route.snapshot.url[0].path
        };
      }), catchError((error): Observable<Viewmodel> => {
        console.error(`Error processing router changes (${error})`);
        return null;
      }));
  }
}
