export type NewSizes = {newLeftSize: number, newRightSize: number};
