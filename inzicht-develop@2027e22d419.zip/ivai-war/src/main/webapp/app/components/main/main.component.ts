import {AfterViewChecked, ChangeDetectorRef, Component, HostListener, OnInit, OnDestroy} from '@angular/core';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import * as fromSelectors from '@inzicht/store/selectors';
import {HelpState} from '@inzicht/services/help.service';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import * as storeActions from '@inzicht/store/actions';
import {TrackingService} from '@inzicht/services/tracking.service';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {Subject} from '@inzicht/classes/subject';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {Domain} from '@inzicht/classes/domain';
import {first} from 'rxjs/operators';
import {NewSizes} from '@inzicht/components/main/new-sizes';

@Component({
  selector: 'i-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
  providers: [Unsubscriber]
})
export class MainComponent implements OnInit, OnDestroy, AfterViewChecked {

  public readonly browserIsIE = /trident\//i.test(window.navigator.userAgent);

  public screenSizePx: number = window.innerWidth;
  public mobileSreenSizePx = 320;
  public mobileBreakpointPx = 400;
  public leftSize = 100;
  public rightSize = 0;
  public horizontal = 'horizontal';
  public initDragHandle = true;
  public sidebarState: any;
  public contextText: string;
  public displayHelp: boolean = false;
  public displayFeedback: boolean = false;
  public activeDomain: Domain;
  public activeDomainRight: Domain;
  public selectedSubjectLeft: Subject;
  public selectedSubjectRight: Subject;

  @HostListener('window:resize', ['$event']) onResize(): void {
    this.screenSizePx = window.innerWidth;
    if (this.screenSizePx < this.mobileBreakpointPx) {

      this.mobileSreenSizePx = this.screenSizePx;
      if (this.leftSize > 0) {
        this.leftSize = 100;
        this.rightSize = 0;
      }
    } else {
      this.mobileSreenSizePx = this.splitViewState.breakpointMobile;
    }
  }

  constructor(private readonly changeDetectorRef: ChangeDetectorRef,
              private readonly router: Router,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService,
              private readonly helpState: HelpState,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly pageNavigationUtilService: PageNavigationUtilService,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit(): void {
    // initially open domain menu
    this.store.select(fromSelectors.getActiveDomain('left'))
      .pipe(first())
      .subscribe({
        next: activeDomain => {
          if (activeDomain === null) {
            this.store.dispatch(storeActions.headerSelectMenu({ side: 'left', menu: 'domain' }));
          }
        },
        error: error => console.error(`Error occurred while getting left active domain (${error})`)
      });

    this.store.select(fromSelectors.getActiveDomain('left'))
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeDomain => this.activeDomain = activeDomain,
        error: error => console.error(`Error occurred while getting left active domain (${error})`)
      });

    this.store.select(fromSelectors.getActiveDomain('right'))
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeDomain => {
          this.activeDomainRight = activeDomain;
          this.updateDragHandle();
        },
        error: error => console.error(`Error occurred while getting right active domain (${error})`)
      });

    const indicatedSelectedSubjectSelectorLeft = this.selectorSideIndicator.indicatedSelectorName('left', 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelectorLeft])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeSubject => this.selectedSubjectLeft = activeSubject,
        error: error => console.error(`Error occurred while getting left active subject (${error})`)
      });

    const indicatedSelectedSubjectSelectorRight = this.selectorSideIndicator.indicatedSelectorName('right', 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelectorRight])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: activeSubject => this.selectedSubjectRight = activeSubject,
        error: error => console.error(`Error occurred while getting right active subject (${error})`)
      });

    this.store.select(fromSelectors.getSidebarState)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: sidebarState => {
          this.sidebarState = sidebarState;
          switch (this.sidebarState.type) {
            case 'help': {
              this.displayHelp = true;
              this.displayFeedback = false;
              break;
            }
            case 'feedback': {
              this.displayHelp = false;
              this.displayFeedback = true;
              break;
            }
            default: {
              this.displayHelp = false;
              this.displayFeedback = false;
              break;
            }
          }
        },
        error: error => console.error(`Error while getting sidebar state from store (${error})`)
      });
    const helpTexts = this.helpState.generalHelp;
    this.helpState.emitHelpText(helpTexts);

    if (this.screenSizePx < this.mobileBreakpointPx) {
      this.mobileSreenSizePx = this.screenSizePx;
      this.leftSize = 100;
      this.rightSize = 0;
    }

    this.helpState.listenHelpText()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: text => this.contextText = text,
        error: error => console.error(`Error while handling help text change (${error})`)
      });

    this.splitViewState.listenOpen2Screen()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: open2Screen => {
          if (open2Screen) {
            this.splitScreensInHalf();
            this.splitViewState.emitOpen2Screen(false);
          }
        }, error: error => console.error(`Error while handling the opening of the second screen (${error})`)
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  ngAfterViewChecked(): void {
    if (this.initDragHandle) {
      const splitGutter: HTMLElement = document.querySelector('div.as-split-gutter');
      splitGutter.classList.add('dragBarWidth');

      const newElDiv = document.createElement('div');
      const newElBlock = document.createElement('div');
      const newElBar = document.createElement('div');
      const newElBar2 = document.createElement('div');

      newElDiv.classList.add('drag-handle');
      newElBlock.classList.add('handle-block');
      newElBar.classList.add('handle-bar');
      newElBar2.classList.add('handle-bar');

      if (this.browserIsIE) {
        newElDiv.classList.add('drag-handle-iefix');
      }

      newElBlock.appendChild(newElBar);
      newElBlock.appendChild(newElBar2);
      newElDiv.appendChild(newElBlock);
      splitGutter.appendChild(newElDiv);

      this.initDragHandle = false;
    }
  }

  convertPercToPx(sizeInPercentage: number): number {
    const sizeInPx = ((this.screenSizePx / 100) * sizeInPercentage);
    return Math.round(sizeInPx);
  }

  public onGutterClick(): void {
    this.loadSecondPageOnUserEvent();
    this.updateScreenSplitOnUserEvent(50, 50);
  }

  public onDragStart(): void {
    this.loadSecondPageOnUserEvent();
  }

  public onDragEnd(e: { gutterNum: number, sizes: number[] }): void {
    const eventLeftSize = e.sizes[0];
    const eventRightSize = e.sizes[1];
    const eventLeftSizePx = this.convertPercToPx(eventLeftSize);
    const eventRightSizePx = this.convertPercToPx(eventRightSize);

    let newSizes: NewSizes = {newLeftSize: eventLeftSize, newRightSize: eventRightSize};

    if (this.screenSizePx < this.mobileBreakpointPx) {
      newSizes = this.calculateNewSizesWhenScreenSizeLessThanMobileBreakpoint(eventLeftSize);
    } else {
      if (eventLeftSizePx < this.mobileSreenSizePx) {
        newSizes = this.calculateNewSizesWhenLeftSizeLessThanMobileScreenSize(eventLeftSize);
      }
      if (eventRightSizePx < this.mobileSreenSizePx) {
        newSizes = this.calculateNewSizesWhenRightSizeLessThanMobileScreenSize(eventRightSize);
      }
    }

    this.updateScreenSplitOnUserEvent(newSizes.newLeftSize, newSizes.newRightSize);
  }

  splitScreensInHalf(): void {
    this.leftSize = 50;
    this.rightSize = 50;
    const sizesInPx = { left: this.convertPercToPx(this.leftSize), right: this.convertPercToPx(this.rightSize) };
    this.splitViewState.emitSizes(sizesInPx);
  }

  wasClosed(): void {
    this.leftSize = 100;
    this.rightSize = 0;
    const sizesInPx = { left: this.convertPercToPx(this.leftSize), right: this.convertPercToPx(this.rightSize) };
    this.splitViewState.emitSizes(sizesInPx);
    this.store.dispatch(storeActions.subjectClear({side: 'right', subject: null}));
    this.router.navigate(['/main', {outlets: {right: null}}]);
  }

  closeHelpAndFeedback(): void {
    this.store.dispatch(storeActions.sidebarClose());
  }

  private loadSecondPageOnUserEvent(): void {
    if (this.activeDomainRight === null) {
      const initPageId: string = this.activeDomain ? this.activeDomain.initPageId : null;
      this.pageNavigationUtilService.navToPageSecondScreen(initPageId, false, this.selectedSubjectLeft);
    }
  }

  private updateScreenSplitOnUserEvent(leftSize: number, rightSize: number): void {
    setTimeout(() => {
      const sizesInPx = {left: this.convertPercToPx(leftSize), right: this.convertPercToPx(rightSize)};
      this.trackingService.trackEvent('klik', `Scherm aanpassen/left:${leftSize} - right:${rightSize}`, null, null);

      this.leftSize = leftSize;
      this.rightSize = rightSize;
      this.splitViewState.emitSizes(sizesInPx);
      this.changeDetectorRef.detectChanges();
    });
  }

  private updateDragHandle(): void {
    const dragHandle: HTMLElement = document.querySelector('div.drag-handle');

    if (dragHandle) {
      if (this.activeDomainRight != null) {
        dragHandle.classList.add('drag-handle-filled');
      } else {
        dragHandle.classList.remove('drag-handle-filled');
      }
    }
  }

  private calculateNewSizesWhenScreenSizeLessThanMobileBreakpoint(eventLeftSize: number): NewSizes {
    let newLeftSize: number;
    let newRightSize: number;
    if (eventLeftSize > this.leftSize) {
      newLeftSize = 100;
      newRightSize = 0;
    } else {
      newLeftSize = 0;
      newRightSize = 100;
    }
    return {newLeftSize, newRightSize};
  }

  private calculateNewSizesWhenLeftSizeLessThanMobileScreenSize(eventLeftSize: number): NewSizes {
    let newLeftSize: number;
    let newRightSize: number;
    if (eventLeftSize > this.leftSize) {
      newLeftSize = 320 / (this.screenSizePx / 100);
      newRightSize = 100 - newLeftSize;
    } else {
      newLeftSize = 0;
      newRightSize = 100;
    }
    return {newLeftSize, newRightSize};
  }

  private calculateNewSizesWhenRightSizeLessThanMobileScreenSize(eventRightSize: number): NewSizes {
    let newLeftSize: number;
    let newRightSize: number;
    if (eventRightSize > this.rightSize) {
      newRightSize = 320 / (this.screenSizePx / 100);
      newLeftSize = 100 - newRightSize;
    } else {
      newLeftSize = 100;
      newRightSize = 0;
    }
    return {newLeftSize, newRightSize};
  }
}
