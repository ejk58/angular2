import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {Store} from '@ngrx/store';

import * as systemActions from '@inzicht/store/actions/system.actions';

@Injectable()
export class SystemResolver implements Resolve<any> {

  constructor(private readonly store: Store) { }

  resolve(): void {
    this.store.dispatch(systemActions.systemLoad());
  }
}
