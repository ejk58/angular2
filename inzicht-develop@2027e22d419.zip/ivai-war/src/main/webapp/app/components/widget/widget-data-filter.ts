import {yyyyMmDdToDate, matchToYyyyMmDd} from '@inzicht/commons/inzicht-functions';
import * as _ from 'lodash-es';


export class WidgetColumnFilter {

  private static comparators: Map<string, (columnValue: any, filterValue: any) => boolean> = new Map([
    ['ignores', () => true],
    ['equals', (columnValue, filterValue) => filterValue == null || columnValue === filterValue],
    ['differsFrom', (columnValue, filterValue) => filterValue == null || columnValue !== filterValue],
    ['isSmallerThan', (columnValue, filterValue) => filterValue == null || columnValue < filterValue],
    ['isSmallerThanOrEquals', (columnValue, filterValue) => filterValue == null || (columnValue != null && columnValue <= filterValue)],
    ['isLargerThan', (columnValue, filterValue) => filterValue == null || columnValue > filterValue],
    ['isLargerThanOrEquals', (columnValue, filterValue) => filterValue == null || (columnValue != null && columnValue >= filterValue)],
  ]);

  public column: string;
  public operator: string;
  public filterKey: string;

  constructor(filter: {'column': string, 'operator': string, 'filterKey': string}) {
    this.column = filter.column;
    this.operator = filter.operator;
    this.filterKey = filter.filterKey;
  }

  public getComparator(): ((columnValue: any, filterValue: any) => boolean) {
    return WidgetColumnFilter.comparators.get(this.operator);
  }
}


export class WidgetDataFilter {

  public extractWidgetColumnFilters(rawData: any): WidgetColumnFilter[] {
    let widgetColumnFilters = [];

    if (rawData.options.clientDataFilters) {
      try {
        const filters = JSON.parse(rawData.options.clientDataFilters);
        widgetColumnFilters = filters.map(filter => new WidgetColumnFilter(filter));
      } catch (error) {
        console.error(error);
        widgetColumnFilters = [];
      }
    } else {
      widgetColumnFilters = [];
    }

    return widgetColumnFilters;
  }

  public filterWidgetData(routerState: any, filter: any, widgetColumnFilters: WidgetColumnFilter[], rawData: any): any {
    const widgetData = _.cloneDeep(rawData);

    widgetColumnFilters.forEach(widgetColumnFilter => {
      const column = widgetColumnFilter.column;
      const columnType = (column && rawData.options.columns[column]) ? rawData.options.columns[column].columnType : 'UNKNOWN';
      const comparator = widgetColumnFilter.getComparator();
      const filterKey = widgetColumnFilter.filterKey;
      const filterValue = (filter && filter[filterKey]) ? this.convertFilterValueByColumnType(columnType, filter[filterKey]) : this.convertFilterValueByColumnType(columnType, routerState[filterKey]);
      const firstDataRowIndex = this.getFirstDataRowIndex(rawData);

      widgetData.data = widgetData.data.filter((dataRow, index) => index < firstDataRowIndex || comparator(column ? dataRow[column] : null, filterValue));
    });

    return widgetData;
  }

  private convertFilterValueByColumnType(columnType: string, filterValue: any): any {
    let convertedFilterValue = filterValue;

    if (columnType === 'DATE' && matchToYyyyMmDd(filterValue)) {
      convertedFilterValue = yyyyMmDdToDate(convertedFilterValue);
    }

    return convertedFilterValue;
  }

  private getFirstDataRowIndex(rawData: any): number {
    let firstDataRowIndex = 0;

    if (rawData.type === 'FlexibleTable') {
      firstDataRowIndex = 1;
    } else if (rawData.type === 'FlexibleCollapsibleTable') {
      firstDataRowIndex = 2;
    }

    return firstDataRowIndex;
  }
}
