import {DOCUMENT} from '@angular/common';
import {Component, ElementRef, Inject, OnInit, OnDestroy, ViewChild, ViewChildren, QueryList} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';

import {Store} from '@ngrx/store';
import {first, filter} from 'rxjs/operators';
import {MenuItem} from 'primeng/api/menuitem';

import {Page} from '@inzicht/classes/page';
import {Side} from '@inzicht/commons/side';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import {TrackingService} from '@inzicht/services/tracking.service';
import {WidgetService} from '@inzicht/services/widget.service';
import * as storeActions from '@inzicht/store/actions';
import * as fromSelectors from '@inzicht/store/selectors';
import {WidgetComponent} from '@inzicht/components/widget/widget.component';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {WidgetDefinition} from '@inzicht/classes/widget-definition';

@Component({
  selector: 'i-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.scss'],
  providers: [Unsubscriber]
})

export class PageComponent implements OnInit, OnDestroy {

  private static readonly autoScrollTimeout = 2500;

  public page: Page;
  public widgetsRows: WidgetDefinition[][];
  public side: Side;
  public breadcrumbs: MenuItem[];
  public showBreadcrumb: boolean = false;
  public domainId: string;
  public pageId: string;
  public globalFilterOnPage: boolean;
  public globalFilterLoaded: boolean;
  public globalWidgetId: string;
  public headerOnPage: boolean;
  public headerData: any;
  public headerKeys: any;
  public scrollTop: number;
  public offsetTop: number;

  private boundPageScrollFunction = this.pageScrollEventHandler.bind(this);
  private scrollTimer: number = -1;

  @ViewChild('pageElement', {read: ElementRef, static: true}) pageElementRef: ElementRef;
  @ViewChildren(WidgetComponent) widgetComponents: QueryList<WidgetComponent>;

  private prevRouterState: Params;

  private widgetDataExpirationTimeInMilliseconds: number;

  constructor(@Inject(DOCUMENT) document,
              private readonly route: ActivatedRoute,
              public readonly util: PageNavigationUtilService,
              private readonly trackingService: TrackingService,
              private readonly widgetService: WidgetService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) {
  }

  ngOnInit(): void {
    this.setWidgetDataExpirationTimeInMilliseconds();

    this.route.params
      .pipe(first())
      .subscribe({
        next: params => {
          this.side = (this.route.outlet) as Side;
          this.trackingService.trackEvent('url', window.location.href.substring(30, window.location.href.length - 1), null, null);
        },
        error: error => console.error(`Error while initializing page based on router params (${error})`)
      });

    this.store.select(fromSelectors.getRouterSideState(this.side))
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe({
        next: routerState => {
          if (routerState !== undefined) {
            const domainIdChanged = this.prevRouterState === undefined || this.prevRouterState.domainId !== routerState.domainId;
            const pageIdChanged = this.prevRouterState === undefined || this.prevRouterState.pageId !== routerState.pageId;

            const changedRouteKeys = this.prevRouterState === undefined ? [] : Object.keys({ ...this.prevRouterState, ...routerState}).filter(key => this.prevRouterState[key] !== routerState[key]);
            const routerKeysChanged: boolean = this.prevRouterState === undefined || changedRouteKeys.length > 0;

            if (domainIdChanged || pageIdChanged) {
              this.processDomainOrPageChange(routerState);
              this.store.dispatch(storeActions.widgetCleanup(this.widgetDataExpirationTimeInMilliseconds));
            } else if (routerKeysChanged) {
              this.processRouteKeysChange(changedRouteKeys);
            }
            this.prevRouterState = routerState;
          }
        },
        error: error => console.error(`Error occurred while handling router state (${error})`)
      });

    this.addPageScrollEvent(this.boundPageScrollFunction);
  }

  ngOnDestroy(): void {
    this.removePageScrollEvent(this.boundPageScrollFunction);
    this.unsubscriber.unsubscribe();
  }

  afterGlobalFilterLoaded(globalFilterState: number): void {
    this.globalFilterLoaded = globalFilterState === 0;
  }

  private processDomainOrPageChange(routerState: Params): void {
    this.domainId = routerState.domainId;
    this.pageId = routerState.pageId;

    this.store.select(fromSelectors.getPageInDomain, {'domainId': this.domainId, 'pageId': this.pageId})
      .pipe(filter(page => page != null), first())
      .subscribe({
        next: page => {
          this.resetPageBeforeNewPageLoad();

          setTimeout(() => {
            this.page = page;
            this.widgetsRows = this.page.rows;
            this.setGlobalFilters();
            this.setHeader();
            this.setBreadcrumbs();
            this.setTimeoutForOriginalScrollPosition();
            this.setScrollPositionToTopWithoutAnimation();
          });
        },
        error: error => console.error(`Error while handling page config state (${error})`)
      });
  }

  private processRouteKeysChange(changedRouteKeys: string[]): void {
    this.widgetComponents.forEach(widget => widget.reloadWidget());
    this.setHeader();
  }

  private resetPageBeforeNewPageLoad(): void {
    this.page = null;
    this.widgetsRows = [];
    this.globalFilterOnPage = false;
    this.globalFilterLoaded = false;
    this.headerOnPage = false;
  }

  private setGlobalFilters(): void {
    this.globalFilterOnPage = false;
    this.globalFilterLoaded = false;

    if (this.page.globalFilterWidget) {
      this.globalFilterOnPage = true;
      this.globalWidgetId = this.page.globalFilterWidget;
    }
  }

  private setHeader(): void {
    if (this.page.headerWidget) {
      this.widgetService.getWidget(this.page.headerWidget, this.side, null)
        .subscribe({
          next: widget => {
            if (widget.error) {
              this.headerData = null;
            } else {
              this.headerData = widget.widgetData.data[0];
              if (this.headerData) {
                this.headerOnPage = true;
                this.headerKeys = Object.keys(this.headerData);
              }
            }
          },
          error: error => console.error(`Error occurred while getting header widget info (${error})`)
        });
    }
  }

  private setBreadcrumbs(): void {
    this.breadcrumbs = [];
    this.showBreadcrumb = false;
    if (this.page.type.toLowerCase() === 'detail') {
      const indicatedBreadcrumbSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getBreadcrumbState');
      this.store.select(fromSelectors[indicatedBreadcrumbSelector])
        .pipe(this.unsubscriber.takeUntilForUnsubscribe)
        .subscribe({
          next: breadcrumbs => {
            this.breadcrumbs = breadcrumbs as MenuItem[];
            this.showBreadcrumb = this.breadcrumbs.length > 1;
          },
          error: error => console.error(`Error occurred while getting breadcrumb info (${error})`)
        });
    } else {
      this.store.dispatch(storeActions.breadcrumbReset({side: this.side, breadcrumb: null}));
    }
  }

  private setTimeoutForOriginalScrollPosition(): void {
    const initialPageState = this.store.selectSync(fromSelectors.getPageState(this.side, this.pageId));
    if (initialPageState && initialPageState.scrollTop) {
      setTimeout(() => {
        if (this.scrollTop === 0) {
          const pageElement = this.getPageElement();
          pageElement.scrollTop = initialPageState.scrollTop;
        }
      }, PageComponent.autoScrollTimeout);
    }
  }

  private setScrollPositionToTopWithoutAnimation(): void {
    const pageElement = this.getPageElement();
    const pageClassName = pageElement.className;

    pageElement.className = pageClassName + ' initializing';
    pageElement.scrollTop = 0;
    pageElement.className = pageClassName;
  }

  private addPageScrollEvent(scrollHandler): void {
    const pageElement = this.getPageElement() as HTMLInputElement;
    pageElement.addEventListener('scroll', scrollHandler);
  }

  private removePageScrollEvent(scrollHandler): void {
    const pageElement = this.getPageElement() as HTMLInputElement;
    pageElement.removeEventListener('scroll', scrollHandler);
  }

  private pageScrollEventHandler(e): void {
    this.scrollTop = e.target.scrollTop;
    this.offsetTop = e.target.offsetTop;

    if (this.scrollTimer !== -1) {
      window.clearTimeout(this.scrollTimer);
    }

    this.scrollTimer = window.setTimeout(() => {
      this.store.dispatch(storeActions.updatePageState({ 'side': this.side, 'pageId': this.pageId, 'state': { 'scrollTop': this.scrollTop } }));
    }, 500);
  }

  public scrollToTop(): void {
    const pageElement = this.getPageElement();
    pageElement.scrollTop = 0;
    this.trackingService.trackEvent('klik', 'Klik tab omhoog: ' + this.side, null, null);
  }

  public isScrollToTopButtonVisible(): boolean {
    return this.scrollTop > 90;
  }

  public isPageFilterFixed(): boolean {
    return this.scrollTop > 50;
  }

  private getPageElement(): Element {
    const pageClassName = 'page-' + this.side;
    return document.getElementsByClassName(pageClassName)[0];
  }

  public getPageTopMargin(): number {
    return (this.page && this.page.globalFilterWidget && this.isPageFilterFixed()) ? this.offsetTop + 90 : 0;
  }

  private setWidgetDataExpirationTimeInMilliseconds(): void {
    this.widgetDataExpirationTimeInMilliseconds = this.store.selectSync(fromSelectors.getSystemProperty('widgetDataExpirationTimeInMilliseconds'));
  }
}
