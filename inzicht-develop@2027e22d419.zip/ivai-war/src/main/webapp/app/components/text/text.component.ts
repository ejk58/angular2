import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnChanges} from '@angular/core';
import {Store} from '@ngrx/store';
import {PageNavigationUtilService} from '@inzicht/commons/page-navigation-util.service';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {HelpState} from '@inzicht/services/help.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import * as storeActions from '@inzicht/store/actions';
import * as storeSelectors from '@inzicht/store/selectors';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import {TextParser} from './text-parser';
import {Block, BlockArgument, BlockType} from './block';

@Component({
  selector: 'i-text',
  templateUrl: './text.component.html',
  styleUrls: ['./text.component.scss'],
  providers: [Unsubscriber],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class TextComponent implements OnChanges, OnDestroy {

  @Input() text: string;
  @Input() side: string;
  @Input() widget?: any;

  public blocks: Block[];
  public components: Block[];

  private textParser: TextParser;

  constructor(private readonly pageNavigationUtil: PageNavigationUtilService,
              private readonly store: Store,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly helpState: HelpState,
              private readonly trackingService: TrackingService,
              private readonly unsubscriber: Unsubscriber) {
    this.textParser = new TextParser();
  }

  ngOnChanges(): void {
    this.blocks = [];
    this.components = [];

    this.parseText();
    this.fillText();
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public handleAction(action: [Block, MouseEvent]): void {
    const [component, event] = action;
    const openInNewTab = (event.ctrlKey || event.button === 1);
    const focus = event.shiftKey;

    if (component.type === BlockType.linkType) {
      this.followLink(component, openInNewTab, focus);
    } else if (component.type === BlockType.buttonType) {
      this.executeAction(component);
    }
  }

  public followLink(component: Block, openInNewTab: boolean, focus: boolean): void {
    const filter = component['model'];
    const page = component['page'] as string;
    const targetSide = (component['target'] === 'currentSide') ? this.side : 'right';

    if (openInNewTab) {
      this.pageNavigationUtil.openInNewTab(this.side, null, page, filter, focus);
    } else {
      this.pageNavigationUtil.navigate(this.side, targetSide, page, filter);
    }
  }

  public executeAction(component: Block): void {
    const action = component['action'];

    if (action === 'open-domain-menu') {
      setTimeout(() => this.store.dispatch(storeActions.headerSelectMenu({side: this.side, menu: 'domain'})));
    } else if (action === 'open-feedback-panel') {
      this.openFeedbackPanel();
    } else if (action === 'open-help-panel') {
      this.openHelpPanel();
    }
  }

  private openHelpPanel(): void {
    if (this.widget) {
      const helpTexts = this.widget ? {'title': this.widget.options.helpTitle, texts: this.widget.options.helpTexts} : this.helpState.generalHelp;
      this.helpState.emitHelpText(helpTexts);
    } else {
      this.helpState.emitHelpText(this.helpState.generalHelp);
    }

    this.store.dispatch(storeActions.sidebarOpen({type: 'help'}));
  }

  private openFeedbackPanel(): void {
    const feedbackOptions = { type: 'feedback' };
    if (this.widget) {
      feedbackOptions['widgetId'] = this.widget.id;
      feedbackOptions['widgetTitle'] = this.widget.options.title;
      feedbackOptions['side'] = this.side;
    }

    this.store.dispatch(storeActions.sidebarOpen(feedbackOptions));
  }

  private parseText(): void {
    this.blocks = this.textParser.parse(this.text);
  }

  private fillText(): void {
    this.components = this.blocks.map(block => this.mapComponentBlock(block));
  }

  private mapBlock(block: Block): BlockArgument {
    return (BlockType.componentTypes.some(componentType => block.type === componentType)) ?
      this.mapComponentBlock(block) : this.mapInnerBlock(block);
  }

  private mapComponentBlock(block: Block): Block {
    const result = this.copyBlock(block);
    const textFromValue = (result.text == null && BlockType.elementTypes.some(elementType => block.type === elementType));

    result.text =  textFromValue ? this.reduceBlock(result) : result.text;
    result.style = 'text text-' + block.type.toLowerCase() + (block.style === '' ? '' : (' ' + block.style));

    return result;
  }

  private mapInnerBlock(block: Block): BlockArgument {
    return this.reduceBlock(this.copyBlock(block));
  }

  private copyBlock(block: Block): Block {
    const result = new Block(block.type, block.startIndex, block.endIndex);

    for (const key of Object.keys(block)) {
      const value = block[key];

      if (Array.isArray(value)) {
        result[key] = value.map(val => this.mapBlock(val)) as Block[];
      } else if (value != null && typeof value === 'object') {
        result[key] = this.mapBlock(value);
      } else {
        result[key] = value;
      }
    }

    return result;
  }

  private reduceBlock(block: Block): BlockArgument {
    let result: BlockArgument = block;

    if (block.type === BlockType.contextType) {
      result = this.reduceContextBlock(result);
    } else if (block.type === BlockType.dataType) {
      result = this.reduceDataBlock(result);
    } else if (block.type === BlockType.environmentType) {
      result = this.reduceEnvironmentBlock(result);
    } else if (block.type === BlockType.sumType) {
      result = this.reduceSumBlock(result);
    } else if (block.type === BlockType.coalesceType) {
      result = this.reduceCoalesceBlock(result);
    }

    return result;
  }

  private reduceContextBlock(block: Block): BlockArgument {
    const key = block['key'] as string;
    let result = null;

    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    const sideParams = this.store.selectSync(storeSelectors[indicatedRouterStateSelector]);

    result = sideParams[key] ? sideParams[key] : null;

    return result;
  }

  private reduceDataBlock(block: Block): BlockArgument {
    const column = block['column'] as string;
    const row = block['row'] as number;
    const fallback = block['fallback'] as string;
    const data = this.widget ? this.widget.data : null;
    let result = null;

    if (row != null && data != null && data.length > row && column != null && data[row].hasOwnProperty(column)) {
      result = data[row][column];
    } else {
      if (this.widget == null) {
        console.error(`Error: A ${block['type']} block tries to retrieve information from a widget but this text component is not connected to one.`);
      } else if (row == null || column == null) {
        console.error(`Error: A ${block['type']} block tries to retrieve information from widget ${this.widget.name}, but misses a column "${column}" and/or a row ${row}.`);
      }
    }

    return (result != null || fallback == null) ? result : fallback;
  }

  private reduceEnvironmentBlock(block: Block): BlockArgument {
    const key = block['key'] as string;
    let result = null;

    if (key === 'username') {
      result = sessionStorage.getItem('username');
    } else if (key === 'version') {
      result = this.store.selectSync(storeSelectors.getSystemVersionState);
    } else if (key === 'date') {
      result = new Date().getMilliseconds();
    } else {
      console.error(`Error: A ${block['type']} block tries to access environment-information with the unsupported key "${key}".`);
    }

    return result;
  }

  private reduceSumBlock(block: Block): number {
    const input = +block['input'];
    const delta = block['delta'] != null ? +block['delta'] : 1;
    let result = null;

    if (block['input'] != null && !isNaN(input) && !isNaN(delta)) {
      result = input + delta;
    } else if (block['input'] != null) {
      console.error(`Error: A ${block['type']} block tries to add two values "${input}" and "${delta}" that are not numeric.`);
    }

    return result;
  }

  private reduceCoalesceBlock(block: Block): BlockArgument {
    const input = block['input'];
    const fallback = block['fallback'];

    return input != null ? input : fallback;
  }
}
