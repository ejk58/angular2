import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';

import {Store} from '@ngrx/store';
import {combineLatest, Observable} from 'rxjs';
import {catchError, distinctUntilChanged, map} from 'rxjs/operators';

import {SplitWidth} from '@inzicht/classes/split-width';
import {AuthenticationService} from '@inzicht/services/authentication.service';
import {SplitViewState} from '@inzicht/services/split-view-state.service';
import {SelectorSideIndicator} from '@inzicht/commons/store-selector-side-indicator';
import * as storeActions from '@inzicht/store/actions';
import * as fromSelectors from '@inzicht/store/selectors';
import {HelpState} from '@inzicht/services/help.service';
import {TrackingService} from '@inzicht/services/tracking.service';
import {Subject} from '@inzicht/classes/subject';
import {Unsubscriber} from '@inzicht/commons/unsubscriber';
import {Domain} from '@inzicht/classes/domain';

interface ViewModel {
  activeDomain: Domain,
  selectedSubject: Subject,
  currentRoute: string,
  splitWidth: SplitWidth
}

@Component({
  selector: 'i-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [Unsubscriber]
})
export class HeaderComponent implements OnInit, OnDestroy {
  vm$!: Observable<ViewModel>;

  @Input() side: any;
  @Output() secondScreenActive: EventEmitter<boolean> = new EventEmitter<boolean>();

  public readonly accountMenuOptions = [
    { label: 'Feedback', icon: 'bd_chat_bubble_outline', command: this.openFeedbackInSidebar.bind(this), selected: false },
    { label: 'Uitloggen', icon: 'bd_lock_open', command: this.logout.bind(this), selected: false }
  ];

  public view: any;
  public username: any;
  public loading: boolean;
  public selectedSubject: Subject;
  private headerState: string;

  constructor(private readonly route: ActivatedRoute,
              private readonly auth: AuthenticationService,
              public readonly splitViewState: SplitViewState,
              private readonly helpState: HelpState,
              private readonly trackingService: TrackingService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    const indicatedHeaderSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getActiveMenu');
    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedSubject');

    const getActiveDomain$: Observable<Domain> = this.store.select(fromSelectors.getActiveDomain(this.side));
    const getHeaderState$: Observable<string> = this.store.select(fromSelectors[indicatedHeaderSelector]);
    const getSelectedSubject$: Observable<Subject> = this.store.select(fromSelectors[indicatedSelectedSubjectSelector]);
    const getCurrentRoute$: Observable<Params> = this.route.params;
    const getSplitWidth$: Observable<SplitWidth> = this.splitViewState.listenSizes();

    this.vm$ = combineLatest([
      getActiveDomain$,
      getHeaderState$,
      getSelectedSubject$,
      getCurrentRoute$,
      getSplitWidth$
    ]).pipe(
      distinctUntilChanged(),
      this.unsubscriber.takeUntilForUnsubscribe,
      map((combined) => {
        const activeDomain: Domain = combined[0];
        const headerState = combined[1];
        const selectedSubject = combined[2];
        const currentRoute = combined[3];
        const splitWidth = (combined[4] != null) ? combined[4] : SplitWidth.default;

        this.headerState = headerState;
        this.selectedSubject = selectedSubject;

        return {
          activeDomain: activeDomain,
          selectedSubject: selectedSubject,
          currentRoute: this.route.snapshot.url[0].path,
          splitWidth: splitWidth
        };
      }), catchError((error): Observable<ViewModel> => {
        console.error(`Error occurred while getting information (${error})`);
        return null;
      }));
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public isDomainSelected(activeDomain: Domain): boolean {
    return activeDomain !== null;
  }

  public isDomainMenuOpened(): boolean {
    return this.side && this.headerState === 'domain';
  }

  public isPageMenuOpened(): boolean {
    return this.side && this.headerState === 'page';
  }

  public isRelationMenuOpened(): boolean {
    return this.side && this.headerState === 'relation';
  }

  public isSubjectMenuOpened(): boolean {
    return this.side && this.headerState === 'subject';
  }

  public isAccountMenuOpened(): boolean {
    return this.side && this.headerState === 'account';
  }

  public selectAccountOption(index: number): void {
    for (let i = 0; i < this.accountMenuOptions.length; i++) {
      this.accountMenuOptions[i].selected = false;
    }
    this.accountMenuOptions[index].selected = true;
    this.accountMenuOptions[index].command();
  }

  private openFeedbackInSidebar(): void {
    this.trackingService.trackEvent('klik',
      `Klik feedback:${this.side}`, null, null);
    this.store.dispatch(storeActions.sidebarOpen({type: 'feedback'}));
    this.switchMenu('default');
  }

  public switchMenu(selectedMenu: string): void {
    const menuChanged = selectedMenu !== this.headerState;
    const menuClicked = selectedMenu !== 'default'; // clicking the same button twice toggles the menu

    if (menuChanged) {
      this.store.dispatch(storeActions.headerSelectMenu({ side: this.side, menu: selectedMenu }));
      if (this.selectedSubject && menuClicked) {
        this.trackingService.trackEvent('klik',
          `Klik ${selectedMenu}:${this.side}/open met icoon`,
          null, this.selectedSubject['subjectNr']);
      }
    } else if (menuClicked) {
      this.store.dispatch(storeActions.headerSelectMenu({ side: this.side, menu: 'default' }));
    }
  }

  public closeSecondScreen() {
    let subject: string;
    if (this.selectedSubject) {
      subject = this.selectedSubject['subjectNr'];
    }
    this.trackingService.trackEvent('klik',
      `Klik close:${this.side}/icoon close`,
      null, subject);
    this.secondScreenActive.emit(true);
  }

  logout() {
    this.auth.logout();
  }

  openHelpInSidebar() {
    const helpTexts = this.helpState.generalHelp;
    let subject: string;
    if (this.selectedSubject) {
      subject = this.selectedSubject['subjectNr'];
    }
    this.switchMenu('default');
    this.trackingService.trackEvent('klik',
      `Klik help:${this.side}/manier: icoon help`,
      null, subject);
    this.helpState.emitHelpText(helpTexts);
    this.store.dispatch(storeActions.sidebarOpen({type: 'help'}));
  }

  onClickedOutside(e: Event, currentRoute: string) {
    if (currentRoute !== 'login') {
      this.switchMenu('default');
    }
  }
}
