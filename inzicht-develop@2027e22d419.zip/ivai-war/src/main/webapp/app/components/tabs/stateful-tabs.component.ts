import { Component, ChangeDetectionStrategy, Input, OnInit } from '@angular/core';

import * as storeActions from '@inzicht/store/actions';
import * as fromSelectors from '@inzicht/store/selectors';
import { Store } from '@ngrx/store';

import { TabsComponent } from '@inzicht/components/tabs/tabs.component';
import { Side } from '@inzicht/commons/side';


@Component({
  selector: 'i-stateful-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StatefulTabsComponent extends TabsComponent implements OnInit {

  @Input() side: Side;
  @Input() name: string;

  constructor(private readonly store: Store) {
    super();
  }

  ngOnInit(): void {
    if (this.side && this.name) {
      const initialWidgetState = this.store.selectSync(fromSelectors.getWidgetState(this.side, this.name));
      if (initialWidgetState && initialWidgetState.selectedTab) {
        this.autoSelectTab(initialWidgetState.selectedTab);
      }
    }
  }

  public autoSelectTab(i: number): void {
    super.selectTab(i, true);
  }

  public selectTab(i: number): void {
    super.selectTab(i, false);
    this.storeCurrentTab();
  }

  private storeCurrentTab(): void {
    this.store.dispatch(storeActions.updateWidgetState({ 'side': this.side, 'widgetId': this.name, 'state': { 'selectedTab': this.activeTab } }));
  }
}
