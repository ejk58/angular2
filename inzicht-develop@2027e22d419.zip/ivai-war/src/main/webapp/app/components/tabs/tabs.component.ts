import { Component, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';

import TabSelectionEvent from '@inzicht/commons/tab-selection-event';
import {sanitizeSelector} from '@inzicht/commons/inzicht-functions';

@Component({
  selector: 'i-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TabsComponent {

  @Input() tabs: string[] = [];
  @Input() disabledTabs: number[] = [];
  @Input() limitMaxWidth: boolean = false;

  @Output() selected: EventEmitter<TabSelectionEvent> = new EventEmitter<TabSelectionEvent>();

  public activeTab: number = 0;

  public selectTab(i: number, auto: boolean = false): void {
    this.activeTab = i;
    const event = {
      tab: i,
      auto: auto
    };
    this.selected.emit(event);
  }

  public displayTabLabel(tab: string | number): string {
    if (typeof tab === 'string') {
      return tab.charAt(0).toUpperCase() + tab.slice(1);
    } else {
      return `${tab}`;
    }
  }

  public isDisabled(i: number): boolean {
    return this.disabledTabs.some(dt => dt === i);
  }

  public sanitizeSelector(selector: string): string {
    return sanitizeSelector(selector);
  }
}
