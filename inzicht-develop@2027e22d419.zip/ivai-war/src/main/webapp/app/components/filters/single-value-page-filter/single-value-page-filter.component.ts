import {Component, EventEmitter, Input, Output} from '@angular/core';

import {Filter} from '@inzicht/components/filters/filter';

@Component({
  selector: 'i-single-value-page-filter',
  templateUrl: './single-value-page-filter.component.html',
  styleUrls: ['./single-value-page-filter.component.scss']
})
export class SingleValuePageFilterComponent {

  @Input() filter: Filter;

  @Output() selected: EventEmitter<string | number> = new EventEmitter<string | number>();

  public internalSelection: string | number;
  private separator: string = '<br>';

  public onChange(): void {
    this.selected.emit(this.internalSelection);
  }

  public containsSeparator(): boolean {
    return this.filter.options.some(option => option.label.toString().includes(this.separator));
  }

  public selectedLabel(selection: string): string {
    const selectedLabel = this.filter.options.find(option => option.value === selection).label;
    return selectedLabel.replace(this.separator, '-');
  }

  public splitOptionLabel(label: string): string[] {
    return label.includes(this.separator) ? label.split(this.separator) : [label, '-'];
  }
}
