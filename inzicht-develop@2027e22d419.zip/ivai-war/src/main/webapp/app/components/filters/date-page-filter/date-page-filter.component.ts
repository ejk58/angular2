import {Component, EventEmitter, Input, Output} from '@angular/core';

import {Filter} from '@inzicht/components/filters/filter';

@Component({
  selector: 'i-date-page-filter',
  templateUrl: './date-page-filter.component.html',
  styleUrls: ['./date-page-filter.component.scss']
})
export class DatePageFilterComponent {

  @Input() filter: Filter;

  @Output() selected: EventEmitter<Date> = new EventEmitter<Date>();

  public internalSelection: Date;
  public today: Date;
  public yearRange: string = `2000:${new Date().getFullYear()}`;
  public firstDayOfWeek: number = 1;

  constructor() {
    this.today = new Date();
  }

  public onChange(): void {
    this.selected.emit(this.internalSelection);
  }

}
