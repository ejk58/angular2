import {FilterValue} from '@inzicht/components/filters/filter-value';

export class FilterOption {
  label: string;
  value: FilterValue;
}
