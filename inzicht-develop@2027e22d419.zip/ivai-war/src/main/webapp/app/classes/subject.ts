import {SubjectPresentation} from '@inzicht/classes/subject-presentation';
import {SubjectNavigation} from '@inzicht/classes/subject-navigation';

export class Subject {
  constructor(public presentation: SubjectPresentation, public model: Object, public navigation?: SubjectNavigation) {}
}
