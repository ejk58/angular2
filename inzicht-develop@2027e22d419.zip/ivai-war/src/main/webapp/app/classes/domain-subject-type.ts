export interface DomainSubjectType {
  name: string;
  type: string;
}
