export class Column {
  public readonly columnName: string;
  public readonly columnType: string;
  public readonly label: string;
  public readonly behaviour: string;
  public readonly filter: string;

  public readonly composite: boolean;
  public readonly maskable: boolean;

  // Column attributes
  public readonly width?: string;
  public readonly style?: string;

  constructor(name: string, type: string, label: string, behaviour: string = 'visible') {
    this.columnName = name;
    this.columnType = type;
    this.label = label;
    this.behaviour = behaviour;
  }

  public static isVisible(behaviour: string): boolean {
    return behaviour !== 'invisible';
  }

  public static isSummable(behaviour: string): boolean {
    return behaviour === 'summable';
  }
}
