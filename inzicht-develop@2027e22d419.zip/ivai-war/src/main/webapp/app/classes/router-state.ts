export interface RouterState {
  domainId: string,
  entityNr: string,
  pageId: string,
  subjectNr: string
}
