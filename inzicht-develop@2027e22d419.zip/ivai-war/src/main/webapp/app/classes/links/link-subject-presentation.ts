import {Link} from '@inzicht/classes/links/link';

export class LinkSubjectPresentation {

  public type: number;
  public direction: number;
  public percentage: number;
  public economicInterest: string;

  public possibleCrossingLinks: Link<any, any, any>[];

  public isLabeled: boolean;
  public isPartnerLink: boolean;
  public isCurvedLink: boolean;
  public isPercentageLink: boolean;
  public isEconomicInterestLink: boolean;
  public isTypedLink: boolean;
  public isVisible: boolean;
}
