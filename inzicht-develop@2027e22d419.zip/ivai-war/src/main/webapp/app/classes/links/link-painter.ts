import * as d3 from 'd3';

import {Link} from '@inzicht/classes/links/link';
import {Node} from '@inzicht/classes/nodes/node';

export interface LinkPainter<P> {
  drawLinks(graph: d3.Selection<any, any, any, any>, linkMainGroup: d3.Selection<any, Link<Node<any, any>, any, P>, any, any>, links: Link<Node<any, any>, any, P>[]): void;
}
