export interface FilterWidget {
  name: string,
  data: Array<FilterWidgetData>,
  options: FilterWidgetOptions,
  type: FilterType
}

export interface FilterWidgetData {
  Filter: {
    label: string,
    value: string,
    count?: number
  }
}

// TODO Replace Any and object
interface FilterWidgetOptions {
  columns: FilterWidgetColumns,
  description: string,
  filterKey: string,
  helpTexts: Array<any>,
  refreshInfo: Array<any>,
  title: string,
  widgets: Array<any>,
  type: string,
  forcedSelection: string,
  unfilteredOption: string
}

// TODO Replace Any
interface FilterWidgetColumns {
  Filter: {
    behaviour: string,
    columnName: string,
    columnType: string,
    composite: boolean,
    description: string,
    filter: any
    label: string,
    maskable: boolean
  }
}

enum FilterType {
  MultiValuePageFilter = 'MultiValuePageFilter',
  SingleValuePageFilter = 'SingleValuePageFilter',
  DatePageFilter = 'DatePageFilter'
}
