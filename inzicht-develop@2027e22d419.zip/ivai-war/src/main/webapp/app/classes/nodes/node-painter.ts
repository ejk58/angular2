import * as d3 from 'd3';

import {Node} from '@inzicht/classes/nodes/node';

export interface NodePainter<P> {
  drawNodes(graph: d3.Selection<any, any, any, any>, nodeMainGroup: d3.Selection<any, Node<any, P>, any, any>, nodes: Node<any, P>[]): void;
}
