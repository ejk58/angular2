import * as d3 from 'd3';

import {getClassesFromList} from '@inzicht/commons/inzicht-functions';

import {NodePainter} from '@inzicht/classes/nodes/node-painter';
import {Node} from '@inzicht/classes/nodes/node';
import {NodeSubjectPresentation} from '@inzicht/classes/nodes/node-subject-presentation';
import {NodeSubjectPainter} from '@inzicht/classes/nodes/node-subject-painter';

export class NodeDualSubjectPainter extends NodeSubjectPainter implements NodePainter<NodeSubjectPresentation> {

  protected drawNewNodes(graph: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>, newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .attr('class', node => getClassesFromList(node.classes) + ' node-design-subject')
      .classed('node-filter-person', node => node.presentation.isPerson)
      .classed('node-filter-business', node => !node.presentation.isPerson)
      .attr('transform', node => `translate(${node.x},${node.y})`);

    this.drawSameEnitity(newNodeGroups);
    this.drawSameAddress(newNodeGroups);
    this.drawPersonSubjectIcon(newNodeGroups);
    this.drawDefaultSubjectIcon(newNodeGroups);
    this.drawAge(newNodeGroups);
    this.drawPossibleHeir(newNodeGroups);
    this.drawInheritanceRejected(newNodeGroups);
    this.drawLabels(newNodeGroups);
    this.drawEventAura(newNodeGroups, graph);
  }

  protected drawDefaultSubjectIcon(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-background', true)
      .classed('node-relation-married', node => node.presentation.isMarried)
      .classed('node-relation-livingtogether', node => node.presentation.isLivingTogether)
      .classed('node-relation-expartner', node => node.presentation.isExPartner)
      .classed('node-type-filter-person', node => node.presentation.isPerson && node.presentation.personType === node.presentation.type)
      .classed('node-type-filter-business', node => !node.presentation.isPerson || node.presentation.personType !== node.presentation.type)
      .text(node => this.subjectIconProvider.getMainSubjectIcon(node.presentation.type));

    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-filter-person', node => node.presentation.isPerson && node.presentation.personType === node.presentation.type)
      .classed('node-type-filter-business', node => !node.presentation.isPerson || node.presentation.personType !== node.presentation.type)
      .text(node => node.isMain ? this.subjectIconProvider.getMainSubjectIcon(node.presentation.type) : this.subjectIconProvider.getNormalSubjectIcon(node.presentation.type));
  }

  protected drawPersonSubjectIcon(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(node => node.presentation.personType != null && node.presentation.personType !== node.presentation.type)
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-background', true)
      .classed('node-relation-married', node => node.presentation.isMarried)
      .classed('node-relation-livingtogether', node => node.presentation.isLivingTogether)
      .classed('node-relation-expartner', node => node.presentation.isExPartner)
      .classed('node-type-filter-person', true)
      .text(node => this.subjectIconProvider.getMainSubjectIcon(node.presentation.personType));

    newNodeGroups.filter(node => node.presentation.personType != null && node.presentation.personType !== node.presentation.type)
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-filter-person', true)
      .text(node => node.isMain ? this.subjectIconProvider.getMainSubjectIcon(node.presentation.personType) :
        this.subjectIconProvider.getNormalSubjectIcon(node.presentation.personType));
  }
}
