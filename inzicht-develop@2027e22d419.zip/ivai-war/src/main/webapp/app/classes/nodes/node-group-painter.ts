import * as d3 from 'd3';

import {SubjectIconProvider} from '@inzicht/commons/subject-icon-provider';
import {makeFittingLabel, getClassesFromList} from '@inzicht/commons/inzicht-functions';

import {NodePainter} from '@inzicht/classes/nodes/node-painter';
import {Node} from '@inzicht/classes/nodes/node';
import {NodeSubjectPresentation} from '@inzicht/classes/nodes/node-subject-presentation';
import {TooltipPainter} from '@inzicht/classes/nodes/tooltip-painter';

export class NodeGroupPainter implements NodePainter<NodeSubjectPresentation> {

  public static readonly nodeRadius = 200;
  public static readonly imageRadius = 30;
  public static readonly labelHeight = 20;

  protected static readonly rectangleWidth = 200;

  constructor(protected readonly subjectIconProvider: SubjectIconProvider,
      protected tooltipPainter: TooltipPainter<NodeSubjectPresentation>) {

  }

  public drawNodes(graph: d3.Selection<any, any, any, any>, nodeMainGroup: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>, nodes: Node<any, NodeSubjectPresentation>[]): void {
    const nodeGroups = nodeMainGroup.selectAll('g.node')
      .data(nodes, (node: Node<any, NodeSubjectPresentation>) => node.id);

    this.drawNewNodes(graph, nodeGroups.enter().append('g'));
    this.updateExistingNodes(nodeGroups);
    this.removeObsoleteNodes(nodeGroups.exit());
  }

  protected drawNewNodes(graph: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>, newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .attr('class', node => getClassesFromList(node.classes) + ' node node-design-group')
      .attr('transform', node => `translate(${node.x},${node.y})`);

    newNodeGroups
      .append('rect')
      .classed('node-background', true)
      .attr('x', Math.floor(-NodeGroupPainter.rectangleWidth / 2))
      .attr('y', Math.floor(-NodeGroupPainter.labelHeight * 3 / 2))
      .attr('width', NodeGroupPainter.rectangleWidth)
      .attr('height', NodeGroupPainter.labelHeight * 3)
      .attr('rx', 2)
      .attr('ry', 2);

    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', -Math.floor(NodeGroupPainter.labelHeight / 2))
      .classed('node-name-label', true)
      .text(node => makeFittingLabel(node.presentation.name, 18));

    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(NodeGroupPainter.labelHeight / 2))
      .classed('node-number-label', true)
      .text(node => node.presentation.subjectNr);

    newNodeGroups
      .append('rect')
      .classed('node-aura', true)
      .attr('x', Math.floor(-NodeGroupPainter.rectangleWidth / 2))
      .attr('y', -(NodeGroupPainter.labelHeight * 2 + 5))
      .attr('width', NodeGroupPainter.rectangleWidth)
      .attr('height', Math.floor(NodeGroupPainter.labelHeight * 7 / 2) + 5)
      .on('mouseover', node => this.handleMouseOverEvent(node))
      .on('mouseout', () => this.handleMouseOutEvent());
  }

  protected updateExistingNodes(existingNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    existingNodeGroups
      .attr('transform', node => `translate(${node.x},${node.y})`);
  }

  protected removeObsoleteNodes(obsoleteNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    obsoleteNodeGroups.remove();
  }

  protected handleMouseOverEvent(node: Node<any, NodeSubjectPresentation>): void {
    if (this.tooltipPainter != null) {
      this.tooltipPainter.showTooltip(node);
    }
  }

  protected handleMouseOutEvent(): void {
    if (this.tooltipPainter != null) {
      this.tooltipPainter.hideTooltip();
    }
  }
}
