import * as d3 from 'd3';

import {SubjectIconProvider} from '@inzicht/commons/subject-icon-provider';
import {SubjectType} from '@inzicht/commons/subject-type';
import {makeFittingLabel, getClassesFromList} from '@inzicht/commons/inzicht-functions';

import {NodePainter} from '@inzicht/classes/nodes/node-painter';
import {Node} from '@inzicht/classes/nodes/node';
import {NodeSubjectPresentation} from '@inzicht/classes/nodes/node-subject-presentation';
import {TooltipPainter} from '@inzicht/classes/nodes/tooltip-painter';

export class NodeSubjectPainter implements NodePainter<NodeSubjectPresentation> {

  public static readonly nodeRadius = 100;
  public static readonly imageRadius = 30;
  public static readonly labelHeight = 20;

  constructor(protected readonly subjectIconProvider: SubjectIconProvider,
      protected tooltipPainter: TooltipPainter<NodeSubjectPresentation>) {

  }

  public drawNodes(graph: d3.Selection<any, any, any, any>, nodeMainGroup: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>, nodes: Node<any, NodeSubjectPresentation>[]): void {
    const nodeGroups = nodeMainGroup.selectAll('g.node')
      .data(nodes, (node: Node<any, NodeSubjectPresentation>) => node.id);

    this.drawNewNodes(graph, nodeGroups.enter().append('g'));
    this.updateExistingNodes(nodeGroups);
    this.removeObsoleteNodes(nodeGroups.exit());
  }

  protected drawNewNodes(graph: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>, newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .attr('class', node => getClassesFromList(node.classes) + ' node node-design-subject')
      .attr('transform', node => `translate(${node.x},${node.y})`);

    this.drawSameEnitity(newNodeGroups);
    this.drawSameAddress(newNodeGroups);
    this.drawSubjectIcon(newNodeGroups);
    this.drawAge(newNodeGroups);
    this.drawLabels(newNodeGroups);
    this.drawEventAura(newNodeGroups, graph);
  }

  protected updateExistingNodes(existingNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    existingNodeGroups
      .attr('transform', node => `translate(${node.x},${node.y})`);
  }

  protected removeObsoleteNodes(obsoleteNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    obsoleteNodeGroups.remove();
  }

  protected handleMouseOverEvent(graph: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>, node: Node<any, NodeSubjectPresentation>): void {
    if (this.tooltipPainter != null) {
      this.tooltipPainter.showTooltip(node);
    }

    graph.selectAll('.link-id-' + node.id).classed('link-highlight', true);
  }

  protected handleMouseOutEvent(graph: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>, node: Node<any, NodeSubjectPresentation>): void {
    if (this.tooltipPainter != null) {
      this.tooltipPainter.hideTooltip();
    }

    graph.selectAll('.link-id-' + node.id).classed('link-highlight', false);
  }

  protected drawSameEnitity(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(d => d.presentation.isSameEntity)
      .append('circle')
      .attr('cx', 0)
      .attr('cy', -NodeSubjectPainter.imageRadius + 1)
      .attr('r', NodeSubjectPainter.imageRadius + 6)
      .classed('node-same-entity', true);
  }

  protected drawSameAddress(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(node => node.presentation.isSameAddress)
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(-2 * NodeSubjectPainter.imageRadius) + 3)
      .classed('node-same-address', true)
      .text(SubjectIconProvider.locationIcon);
  }

  protected drawSubjectIcon(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .classed('node-type-background', true)
      .classed('node-relation-married', node => node.presentation.isMarried)
      .classed('node-relation-livingtogether', node => node.presentation.isLivingTogether)
      .classed('node-relation-expartner', node => node.presentation.isExPartner)
      .text(node => this.subjectIconProvider.getMainSubjectIcon(node.presentation.type));

    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('node-type', true)
      .text(node => node.isMain ? this.subjectIconProvider.getMainSubjectIcon(node.presentation.type) : this.subjectIconProvider.getNormalSubjectIcon(node.presentation.type));
  }

  protected drawAge(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(node => node.presentation.age != null && !node.presentation.isMasked)
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(-NodeSubjectPainter.imageRadius) + 5)
      .classed('node-age-label', true)
      .text(node => node.presentation.age);
  }

  protected drawPossibleHeir(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(node => node.presentation.isPossibleHeir)
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(-NodeSubjectPainter.imageRadius) + 21.3)
      .classed('node-is-mogelijke-erfgenaam', true)
      .text(SubjectIconProvider.isPossibleHeirIcon);
  }

  protected drawInheritanceRejected(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups.filter(node => node.presentation.inheritanceRejected)
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(-NodeSubjectPainter.imageRadius) + 21.3)
      .classed('node-heeft-erfenis-verworpen', true)
      .text(SubjectIconProvider.inheritanceRejectedIcon);
  }

  protected drawLabels(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', NodeSubjectPainter.labelHeight + 2)
      .classed('node-name-label', true)
      .text(node => {
        const maxNameLength = 18 - (node.presentation.state == null ? 0 : node.presentation.state.length);
        return makeFittingLabel(node.presentation.name, maxNameLength);
      })
      .append('tspan')
      .classed('node-state-label', true)
      .text(node => (node.presentation.state == null || node.presentation.state === '') ? '' : node.presentation.state);

    newNodeGroups.filter(d => d.presentation.type !== SubjectType.MeerDan20PersonenOpAdres)
      .append('text')
      .attr('x', 0)
      .attr('y', NodeSubjectPainter.labelHeight * 2 + 2)
      .classed('node-number-label', true)
      .text(node => node.presentation.subjectNr);
  }

  protected drawEventAura(newNodeGroups: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>, graph: d3.Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .append('circle')
      .classed('node-aura', true)
      .attr('cx', 0)
      .attr('cy', 0)
      .attr('r', NodeSubjectPainter.nodeRadius)
      .on('mouseover', (event, node) => this.handleMouseOverEvent(graph, node))
      .on('mouseout', (event, node) => this.handleMouseOutEvent(graph, node));
  }
}
