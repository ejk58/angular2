export interface PageMenuCategory {
  title: string;
  iconName: string;
  options: PageMenuOption[];
}

export interface PageMenuOption {
  important: boolean;
  index: number;
  key: string;
  label: string;
}
