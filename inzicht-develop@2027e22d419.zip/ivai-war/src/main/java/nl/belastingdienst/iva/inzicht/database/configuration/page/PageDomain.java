package nl.belastingdienst.iva.inzicht.database.configuration.page;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;

@Entity
@Table(name = "CONF_PAGE_DOMAIN")
public class PageDomain {

    @Id
    private Integer id;

    @Column(name = "GROUP_INDEX")
    private Integer groupIndex;

    @Column(name = "MEMBER_INDEX")
    private Integer memberIndex;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "DOMAIN_ID")
    private Domain domain;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PAGE_ID")
    private Page page;

    public Integer getId() {
        return id;
    }
    
    public Integer getGroupIndex() {
		return groupIndex;
	}

	public Integer getMemberIndex() {
		return memberIndex;
	}

	public Domain getDomain() {
        return domain;
    }

	public Page getPage() {
        return page;
    }
}
