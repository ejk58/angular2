package nl.belastingdienst.iva.inzicht.dataprovider.teradata;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.enterprise.inject.Typed;
import javax.ws.rs.core.MultivaluedMap;

import org.codehaus.jackson.JsonNode;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Typed(TeradataVipCheckClient.class)
public class TeradataVipCheckClient extends TeradataClient {

	private static final Permission DEFAULTPERMISSION = new Permission(true);
    private static final String VIPCOLUMN = "vip"; 
    private static final String VIPINDICATOR = "1"; 
    private static final List<String> VIPCATEGORIES = Arrays.asList("VIP");

    public Permission getPermission(RestCallContext restCallContext, String key) {
    	Permission permission = DEFAULTPERMISSION;

    	if (QueryValueKey.FISCALNR.equals(key)) {    			
	    	boolean restrictedSubject = !isNotVip(restCallContext);
	    	boolean userAccess = RoleUtils.isVipUser(restCallContext) || !restrictedSubject;
	    	List<String> categories = restrictedSubject ? VIPCATEGORIES : Collections.emptyList();
	    	permission = new Permission(userAccess, categories);
    	}
    	
    	return permission;
    }
    
    public boolean isNotVip(RestCallContext restCallContext) {
    	MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        Configuration configuration = restCallContext.getConfiguration();
    	QueryInterface query = getVipQuery(configuration);
        JsonNode data = retrieveDataAsJson(query, queryValues);
        List<String> vipData = data.findValuesAsText(VIPCOLUMN);
        return !vipData.isEmpty() && !VIPINDICATOR.equals(vipData.get(0));
    }
    
    private QueryInterface getVipQuery(Configuration configuration) {
    	String viewName = configuration.getValueAsString(ConfigurationKey.TERADATAVIPVIEWNAME);
    	String query = configuration.getValueAsString(ConfigurationKey.TERADATAVIPSQLQUERY);
        return new TeradataQuery(viewName, query);
    }
}
