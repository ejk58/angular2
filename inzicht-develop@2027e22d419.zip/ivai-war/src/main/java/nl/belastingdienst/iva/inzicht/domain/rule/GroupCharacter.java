package nl.belastingdienst.iva.inzicht.domain.rule;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum GroupCharacter {

	PARENTHESES("(", ")"),
	BRACKETS("[", "]"),
	CURLYBRACES("{", "}");
	
	public static final List<GroupCharacter> ALL = Collections.unmodifiableList(Arrays.asList(values()));
	
	private String startCharacter;
	private String endCharacter;
	
	private GroupCharacter(String startCharacter, String endCharacter) {
		this.startCharacter = startCharacter;
		this.endCharacter = endCharacter;
	}

	public String getStartCharacter() {
		return this.startCharacter;
	}

	public String getEndCharacter() {
		return this.endCharacter;
	}
}
