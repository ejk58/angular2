package nl.belastingdienst.iva.inzicht.engine;

import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public interface RuleInterface {

	Flow apply(RestCallContext restCallContext);
	String getRule();
}
