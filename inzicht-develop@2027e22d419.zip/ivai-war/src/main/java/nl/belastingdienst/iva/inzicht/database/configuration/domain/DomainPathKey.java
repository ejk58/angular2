package nl.belastingdienst.iva.inzicht.database.configuration.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_DOMAIN_PATHKEY")
public class DomainPathKey {

    @Id
    private Integer id;
    private String key;
    private String name;
    private String title;
    private String type;

    private Integer index;
    private Boolean primary;
    private Boolean mandatory;
    
    public Integer getId() {
        return id;
    }

    public String getKey() {
        return key;
    }
    
    public String getName() {
        return name;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getType() {
        return type;
    }
    
    public Integer getIndex() {
        return index;
    }

    public Boolean getPrimary() {
        return primary;
    }

    public Boolean getMandatory() {
        return mandatory;
    }
}
