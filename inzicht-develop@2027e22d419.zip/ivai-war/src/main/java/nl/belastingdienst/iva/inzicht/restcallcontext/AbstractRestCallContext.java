package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainPathKey;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotFoundException;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;

public abstract class AbstractRestCallContext implements RestCallContext{

	private RestServiceType serviceType;
    private MultivaluedMap<String, String> queryValues;
    private Configuration configuration;
    
    private long beginTime;

    public AbstractRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration, long beginTime) {
        this.serviceType = serviceType;
        this.queryValues = queryValues;
        this.configuration = configuration;
        this.beginTime = beginTime;

        this.queryValues.remove(QueryValueKey.USERNAME);
        this.queryValues.remove(QueryValueKey.NOCACHE);
    }

    @Override
    public RestServiceType getServiceType() {
        return this.serviceType;
    }

    @Override
    public String getServiceName() {
        return this.serviceType.getName();
    }

    @Override
    public MultivaluedMap<String, String> getQueryValues() {
        return this.queryValues;
    }
    
    @Override
    public Configuration getConfiguration() {
        return this.configuration;
    }
    
    @Override
    public String getDomainKey() {
        return this.queryValues.getFirst(QueryValueKey.DOMAINKEY);
    }

    @Override
    public String getPageKey() {
        return this.queryValues.getFirst(QueryValueKey.PAGEKEY);
    }
    
    @Override
    public String getWidgetKey() {
        return this.queryValues.getFirst(QueryValueKey.WIDGETKEY);
    }

    @Override
    public String getUserName() {
    	return this.queryValues.getFirst(QueryValueKey.USERNAME);
    }
    
    @Override
    public long getBeginTime() {
        return this.beginTime;
    }
    
    @Override
    public long getElapsedTime() {
        return System.currentTimeMillis() - this.beginTime;
    }
    
    @Override
    public String getFirstQueryValue(String key) {
        return this.queryValues.getFirst(key);
    }
    
    @Override
    public boolean hasDomainPathKeys() {
        Set<String> keys = this.queryValues.keySet();

        for (String key : keys) {
            if (!QueryValueKey.SYSTEMKEYS.contains(key)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean hasMandatoryPathKeys() {
        String domainKey = getDomainKey();
        Domain domain = this.configuration.findDomain(domainKey);
        return domain != null && checkMandatoryPathKeys(domain); 
    }

    @Override
    public Domain findDomain() {
        String domainKey = getDomainKey();
        Domain domain = this.configuration.findDomain(domainKey);
        return checkUnfoundItem("domain", domainKey, domain);
    }
    
    @Override
    public Page findPage() {
        String pageKey = getPageKey();
        Page page = this.configuration.findPage(pageKey);
        return checkUnfoundItem("page", pageKey, page);
    }

    @Override
    public Widget findWidget() {
        String widgetKey = getWidgetKey();
        Widget widget = this.configuration.findWidget(widgetKey);
        return checkUnfoundItem("widget", widgetKey, widget);
    }

    @Override
	public void addQueryValue(String key, String value) {
   		this.queryValues.putSingle(key, value);
    }

    private boolean checkMandatoryPathKeys(Domain domain) {
        List<DomainPathKey> pathKeys = domain.getPathKeys();
        for (DomainPathKey pathKey : pathKeys) {
            if (pathKey.getMandatory() && !this.queryValues.containsKey(pathKey.getName())) {
                return false;
            }
        }
        
        return true;
    }
    
    private <T> T checkUnfoundItem(String item, String key, T definition) {
        if (definition == null) {
            throw (key == null || DomainUtils.isUndefined(key)) ?
                new BadRequestException("The " + item + " " + key + " is not defined.") :
                new NotFoundException("The " + item + " " + key + " is not found.");
        }
        
        return definition;
    }
    
    @Override
    public String toString() {
        StringBuilder queryValuesBuilder = new StringBuilder();
        
        for (Entry<String, List<String>> queryValue : this.queryValues.entrySet()) {
            if (queryValuesBuilder.length() > 0) {
                queryValuesBuilder.append(", ");
            }
            
            String key = queryValue.getKey();
            List<String> values = queryValue.getValue();
            
            for (String value : values) {
                queryValuesBuilder.append(key);
                queryValuesBuilder.append(" = ");
                queryValuesBuilder.append(value == null ? MessageUtils.UNKNOWN : value);
            }
        }
        
        return queryValuesBuilder.toString();
    }
}
