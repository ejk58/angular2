package nl.belastingdienst.iva.inzicht.service.domain;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;
import nl.belastingdienst.iva.inzicht.user.User;

@Stateless
@Path("/domains")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class DomainService extends AbstractRestService {
    
    @Inject
    private ConfigurationFactory configurationFactory;
    
    @Inject
    private DomainResponseMapper domainResponseMapper;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getDomains() {
        Configuration configuration = this.configurationFactory.getConfiguration();
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.DOMAINSERVICE);

        try {
            Set<Domain> domainSet = new HashSet<>();
            Set<DomainRole> roles = configuration.getApplicationRoles();
            User user = restCallContext.getUser();

            for (DomainRole role : roles) {
                if (RoleUtils.hasRole(user, role)) {
                    List<Domain> domainList = configuration.findDomainsByRole(role);
                    domainSet.addAll(domainList);
                }
            }

            restCallContext.setResponse(this.domainResponseMapper.map(domainSet, configuration));
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
}
