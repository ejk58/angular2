package nl.belastingdienst.iva.inzicht.database.configuration.query;

import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.DatasourceJPA;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryType;

@Entity
@Table(name = "CONF_QUERY")
@NamedQuery(name = Query.QUERY_GETQUERIES, query = "SELECT q FROM Query q " + 
        "LEFT JOIN FETCH q.queryColumns " + 
        "LEFT JOIN FETCH q.queryFilters " + 
        "LEFT JOIN FETCH q.queryAttributes " + 
        "LEFT JOIN FETCH q.datasource " + 
        "ORDER BY q.key")
public class Query implements QueryInterface {

    public static final String QUERY_GETQUERIES = "Query.getQuery";
	
    @Id
    private Integer id;

    private Integer type;
    private String viewName;
    private String queryTemplate;
    private String key;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "QUERY_ID")
    @OrderBy(value = "index")
    private List<QueryColumn> queryColumns;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "QUERY_ID")
    private List<QueryFilter> queryFilters;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "QUERY_ID")
    @OrderBy(value = "key")
    private List<QueryAttribute> queryAttributes;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "DATASOURCE_ID")
    private DatasourceJPA datasource;

    @Transient
    private String vipFilterColumnKey;

    @Transient
    private String vipMaskColumnKey;

    @Transient
    private String vipTagColumnKey;

    @Transient
    private List<String> maskableColumnKeys;

    @Transient
    private ResultMapper resultMapper;
    
    public Integer getId() {
        return this.id;
    }
    
    @Override
    public QueryType getType() {
		return QueryType.findQueryType(type);
	}

    @Override
	public String getViewName() {
		return this.viewName;
	}

    @Override
	public String getQueryTemplate() {
        return this.queryTemplate;
    }
	
    @Override
	public String getKey() {
        return this.key;
    }

    @Override
    public List<QueryColumn> getQueryColumns() {
		return this.queryColumns;
	}
	
    @Override
	public List<QueryFilter> getQueryFilters() {
		return this.queryFilters;
	}
	
    public List<QueryAttribute> getQueryAttributes() {
        return this.queryAttributes;
    }

    @Override
	public Datasource getDatasource() {
        return this.datasource.getDatasource();
    }
    
    @Override
    public String getVipFilterColumnKey() {
        return this.vipFilterColumnKey;
    }
    
    @Override
    public String getVipMaskColumnKey() {
        return this.vipMaskColumnKey;
    }
	
    @Override
    public String getVipTagColumnKey() {
        return this.vipTagColumnKey;
    }
	
    @Override
    public List<String> getMaskableColumnKeys() {
        return this.maskableColumnKeys != null ? this.maskableColumnKeys : Collections.<String>emptyList();
    }
    
    @Override
	public ResultMapper getResultMapper() {
		return this.resultMapper;
	}
	
    @Override
    public boolean hasDatasource() {
        return this.datasource != null;
    }
    
    public void setVipFilterColumnKey(String vipFilterColumnKey) {
        this.vipFilterColumnKey = vipFilterColumnKey;
    }
	
    public void setVipMaskColumnKey(String vipMaskColumnKey) {
        this.vipMaskColumnKey = vipMaskColumnKey;
    }
    
    public void setVipTagColumnKey(String vipTagColumnKey) {
        this.vipTagColumnKey = vipTagColumnKey;
    }
    
    public void setMaskableColumnKeys(List<String> maskableColumnKeys) {
        this.maskableColumnKeys = maskableColumnKeys;
    }
    
	public void setResultMapper(ResultMapper resultMapper) {
		this.resultMapper = resultMapper;
	}

	public String getQueryAttributeValue(String key) {
		for (QueryAttribute queryAttribute : this.queryAttributes) {
			if (queryAttribute.hasKey(key)) {
				return queryAttribute.getValue();
			}
		}
		
		return null;
	}

	@Override
	public int hashCode() {
		return this.key == null ? 0 : this.key.hashCode();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		
		if ((object == null) || (getClass() != object.getClass())) {
			return false;
		}
		
		Query otherQuery = (Query) object;
		return this.key == null ? otherQuery.key == null : this.key.equals(otherQuery.key);
	}
}
