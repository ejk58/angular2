package nl.belastingdienst.iva.inzicht.database.configuration.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageDomain;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;

@Entity
@Table(name = "CONF_DOMAIN")
@NamedQuery(name = Domain.QUERY_GETDOMAINS, query = "SELECT d FROM Domain d " + 
        "LEFT JOIN FETCH d.attributes " + 
        "LEFT JOIN FETCH d.roles " + 
        "LEFT JOIN FETCH d.pathKeys " + 
        "LEFT JOIN FETCH d.menuGroups " + 
        "LEFT JOIN FETCH d.subjectTypes " + 
        "LEFT JOIN FETCH d.subjectQuery " + 
        "LEFT JOIN FETCH d.relationVipQuery " + 
        "LEFT JOIN FETCH d.relationNoVipQuery " + 
        "LEFT JOIN FETCH d.searchVipQuery " + 
        "LEFT JOIN FETCH d.searchNoVipQuery " + 
        "ORDER BY d.key")
public class Domain {

    public static final String QUERY_GETDOMAINS = "Domain.getDomains";

    @Id
    private Integer id;
    private String key;
    private String name;
    private String iconName;
    private Integer index;

    @ElementCollection(fetch = FetchType.EAGER)
    @Column(name = "VALUE")
    @MapKeyColumn(name = "KEY")
    @CollectionTable(name = "CONF_DOMAIN_ATTRIBUTE", joinColumns = @JoinColumn(name = "DOMAIN_ID"))
    private Map<String, String> attributes = new HashMap<>();

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "groupIndex ASC, memberIndex ASC")
    private List<PageDomain> pageDomains = new ArrayList<>();
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "DOMAIN_ID")
    private List<DomainRole> roles = new ArrayList<>();

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "index ASC")
    private List<DomainPathKey> pathKeys = new ArrayList<>();

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "index ASC")
    private List<DomainMenuGroup> menuGroups = new ArrayList<>();

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "DOMAIN_ID")
    @OrderBy(value = "name ASC")
    private List<DomainSubjectType> subjectTypes = new ArrayList<>();

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SUBJECT_QUERY_ID")
    private Query subjectQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RELATION_VIP_QUERY_ID")
    private Query relationVipQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RELATION_NOVIP_QUERY_ID")
    private Query relationNoVipQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SEARCH_VIP_QUERY_ID")
    private Query searchVipQuery;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SEARCH_NOVIP_QUERY_ID")
    private Query searchNoVipQuery;

    @Transient
    private DataMap domainMap;

    public Integer getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public String getIconName() {
        return iconName;
    }

    public Integer getIndex() {
        return index;
    }
    
    public List<PageDomain> getPageDomains() {
		return Collections.unmodifiableList(this.pageDomains);
	}

    public List<DomainRole> getRoles() {
        return Collections.unmodifiableList(this.roles);
    }

    public List<DomainPathKey> getPathKeys() {
        return Collections.unmodifiableList(this.pathKeys);
    }

    public List<DomainMenuGroup> getMenuGroups() {
        return Collections.unmodifiableList(this.menuGroups);
    }

    public List<DomainSubjectType> getSubjectTypes() {
        return Collections.unmodifiableList(this.subjectTypes);
    }

    public Query getSubjectQuery() {
        return this.subjectQuery;
    }

    public Query getRelationVipQuery() {
        return this.relationVipQuery;
    }

    public Query getRelationNoVipQuery() {
        return this.relationNoVipQuery;
    }

    public Query getSearchVipQuery() {
        return this.searchVipQuery;
    }

    public Query getSearchNoVipQuery() {
        return this.searchNoVipQuery;
    }

    public DataMap getDomainMap() {
        return this.domainMap == null ? DomainUtils.emptyDataMap() : this.domainMap;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public List<DomainPathKey> getMandatoryPathKeys() {
        List<DomainPathKey> mandatoryPathKeys = new ArrayList<>();
        
        for (DomainPathKey pathKey : getPathKeys()) {
            if (Boolean.TRUE.equals(pathKey.getMandatory())) {
                mandatoryPathKeys.add(pathKey);
            }
        }
        
        return mandatoryPathKeys;
    }
    
    @Override
    public int hashCode() {
        return this.key.hashCode();
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }

        if (object == null || getClass() != object.getClass()) {
            return false;
        }

        Domain otherDomain = (Domain) object;
        return this.key.equals(otherDomain.key);
    }
    
    public void setDomainMap(DataMap domainMap) {
        this.domainMap = domainMap;
    }
    
    public void linkDomain() {
        for (PageDomain pageDomain : this.pageDomains) {
        	Page page = pageDomain.getPage();
        	page.linkDomain(this);
        }
    }
}
