package nl.belastingdienst.iva.inzicht.database.configuration;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.DatasourceJPA;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;

public class ConfigurationDao {

    @PersistenceContext(unitName = "ivai-pu-inzicht")
    private EntityManager entityManager;

    public List<AttributeGroup> getAttributeGroups() {
        TypedQuery<AttributeGroup> query = entityManager.createNamedQuery(AttributeGroup.QUERY_GETATTRIBUTEGROUPS, AttributeGroup.class);
        return query.getResultList();	
    }

    public List<DatasourceJPA> getDatasources() {
        TypedQuery<DatasourceJPA> query = entityManager.createNamedQuery(DatasourceJPA.QUERY_GETDATASOURCES, DatasourceJPA.class);
        return query.getResultList();
    }

    public List<Domain> getDomains() {
        TypedQuery<Domain> query = entityManager.createNamedQuery(Domain.QUERY_GETDOMAINS, Domain.class);
        return query.getResultList();
    }

    public List<Page> getPages() {
        TypedQuery<Page> query = entityManager.createNamedQuery(Page.QUERY_GETPAGES, Page.class);
        return query.getResultList();
    }

    public List<Widget> getWidgets() {
        TypedQuery<Widget> query = entityManager.createNamedQuery(Widget.QUERY_GETWIDGETS, Widget.class);
        return query.getResultList();
    }
    
    public List<RuleGroup> getRuleGroups() {
        TypedQuery<RuleGroup> query = entityManager.createNamedQuery(RuleGroup.QUERY_GETRULEGROUPS, RuleGroup.class);
        return query.getResultList();
    }

    public List<Query> getQueries() {
        TypedQuery<Query> query = entityManager.createNamedQuery(Query.QUERY_GETQUERIES, Query.class);
        return query.getResultList();
    }
}
