package nl.belastingdienst.iva.inzicht.service.releasenote;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.releasenote.ReleaseNote;
import nl.belastingdienst.iva.inzicht.domain.releasenote.ReleaseNoteComparator;
import nl.belastingdienst.iva.inzicht.domain.releasenote.VersionComparator;
import nl.belastingdienst.iva.inzicht.releasenote.ReleaseNoteFactory;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/releasenote")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class ReleaseNoteService extends AbstractRestService {

	private static final String LATESTVERSION = "latest";
	
    @Inject
    private ReleaseNoteFactory releaseNoteFactory;

	@Inject
	private ReleaseNoteMapper releaseNoteMapper;
	
	@Inject
	private ReleaseNoteComparator releaseNoteComparator;
	
	@Inject
	private VersionComparator versionComparator;
	
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getReleaseNotes(@Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.RELEASENOTESERVICE, queryValues);
        
        try {
        	List<ReleaseNote> releaseNotes = getReleaseNotes();
        	releaseNotes = filterReleaseNotes(restCallContext, releaseNotes);
        	releaseNotes = sortReleaseNotes(releaseNotes);
        	List<DataMap> response = mapReleaseNotes(releaseNotes);
            restCallContext.setResponse(response);
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }

    private List<ReleaseNote> getReleaseNotes() {
    	return this.releaseNoteFactory.getReleaseNotes();
    }

    private List<ReleaseNote> filterReleaseNotes(RestCallContext restCallContext, List<ReleaseNote> releaseNotes) {
    	MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
    	
    	String version = queryValues.getFirst("version");
    	releaseNotes = (version == null) ? releaseNotes : filterReleaseNotesByVersion(version, releaseNotes);

    	return filterReleaseNotesByUser(restCallContext, releaseNotes);
    }

    private List<ReleaseNote> sortReleaseNotes(List<ReleaseNote> releaseNotes) {
    	Collections.sort(releaseNotes, this.releaseNoteComparator);
    	return releaseNotes;
    }
    
    private List<DataMap> mapReleaseNotes(List<ReleaseNote> releaseNotes) {
    	return this.releaseNoteMapper.map(releaseNotes);
    }

    private List<ReleaseNote> filterReleaseNotesByVersion(String version, List<ReleaseNote> releaseNotes) {
    	return LATESTVERSION.equalsIgnoreCase(version) ? 
                filterReleaseNotesByLatestVersion(releaseNotes) : 
                filterReleaseNotesByGivenVersion(version, releaseNotes);
    }

    private List<ReleaseNote> filterReleaseNotesByLatestVersion(List<ReleaseNote> releaseNotes) {
    	Optional<String> latestVersion = releaseNotes.stream()
    			.map(ReleaseNote::getVersion)
    			.distinct()
    			.sorted(this.versionComparator)
    			.findFirst();

    	return latestVersion.isPresent() ? 
    			filterReleaseNotesByGivenVersion(latestVersion.get(), releaseNotes) : 
    			Collections.<ReleaseNote>emptyList();
    }

    private List<ReleaseNote> filterReleaseNotesByGivenVersion(String version, List<ReleaseNote> releaseNotes) {
    	return releaseNotes.stream()
    			.filter(notes -> version.equals(notes.getVersion()))
    			.collect(Collectors.toList());
    }
    
    private List<ReleaseNote> filterReleaseNotesByUser(RestCallContext restCallContext, List<ReleaseNote> releaseNotes) {
    	List<Domain> domains = RoleUtils.getDomains(restCallContext);
    	List<String> domainKeys = domains.stream().map(Domain::getKey).collect(Collectors.toList());
    	
    	return releaseNotes.stream()
    			.filter(notes -> notes.getDomainKey() == null || domainKeys.stream().anyMatch(domainKey -> domainKey.equals(notes.getDomainKey())))
    			.collect(Collectors.toList());
    }
}
