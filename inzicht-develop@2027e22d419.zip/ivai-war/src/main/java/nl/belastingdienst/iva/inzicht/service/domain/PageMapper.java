package nl.belastingdienst.iva.inzicht.service.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.inject.Typed;

import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageAttribute;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PagePathKey;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageWidget;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.service.domain.PageItem;

@Typed(PageMapper.class)
public class PageMapper {

    public DataMap mapToPage(Page page) {
        List<String> mandatoryPathKeys = page.getMandatoryPathKeys().stream().map(PagePathKey::getName).collect(Collectors.toList());
        DataMap mappedPage = new DataHashMap();

        mappedPage.put(ResponseKey.KEY, page.getKey());
        mappedPage.put(ResponseKey.TYPE, page.getType());
        mappedPage.put(ResponseKey.TITLE, page.getTitle());
        mappedPage.put(ResponseKey.ROWS, mapPageRows(page));
        mappedPage.put(ResponseKey.MANDATORYPATHKEYS, mandatoryPathKeys);

        for (PageAttribute pageAttribute : page.getAttributeList()) {
            mappedPage.put(pageAttribute.getKey(), pageAttribute.getValue());
        }

        return mappedPage;
    }
    
    public DataMap mapToMenuItem(Page page, Integer memberIndex) {
        String pageTitle = page.getTitle();
        DataMap menuItem = new DataHashMap();

        menuItem.put(ResponseKey.LABEL, pageTitle);
        menuItem.put(ResponseKey.KEY, page.getKey());
        menuItem.put(ResponseKey.IMPORTANT, false);
        menuItem.put(ResponseKey.INDEX, memberIndex);
        
        return menuItem;
    }
    
    private List<List<PageItem>> mapPageRows(Page page) {
        List<PageWidget> pageWidgetList = page.getPageWidgets();
        List<List<PageItem>> mappedPageRows = new ArrayList<>();
        List<PageItem> mappedRow = null;
        Integer previousRowIndex = null;
        
        for (PageWidget pageWidget : pageWidgetList) {
            Integer rowIndex = pageWidget.getRowIndex();
            
            if (!rowIndex.equals(previousRowIndex)) {
                mappedRow = new ArrayList<>();
                mappedPageRows.add(mappedRow);
                previousRowIndex = rowIndex;
            }
            
            mappedRow.add(new PageItem(pageWidget.getWidget(), pageWidget.getGridColumns()));
        }
        
        return mappedPageRows;
    }
}
