package nl.belastingdienst.iva.inzicht.dataprovider.teradata;

public class TeradataResult {

	String response;
	boolean fullAmpQuery;

	public String getResponse() {
		return response;
	}

	public boolean isFullAmpQuery() {
		return fullAmpQuery;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public void setFullAmpQuery(boolean fullAmpQuery) {
		this.fullAmpQuery = fullAmpQuery;
	}
}
