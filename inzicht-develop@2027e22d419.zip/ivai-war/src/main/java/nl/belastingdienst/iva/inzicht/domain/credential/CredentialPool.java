package nl.belastingdienst.iva.inzicht.domain.credential;

@FunctionalInterface
public interface CredentialPool {
    Credential getCredential();
}
