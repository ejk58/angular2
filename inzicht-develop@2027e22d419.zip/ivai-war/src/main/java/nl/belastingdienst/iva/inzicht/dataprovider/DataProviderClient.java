package nl.belastingdienst.iva.inzicht.dataprovider;

import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@FunctionalInterface
public interface DataProviderClient {

    Result retrieveData(QueryInterface query, RestCallContext restCallContext);
}
