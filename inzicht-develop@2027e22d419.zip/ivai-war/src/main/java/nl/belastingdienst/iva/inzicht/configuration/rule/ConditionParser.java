package nl.belastingdienst.iva.inzicht.configuration.rule;

import java.util.ArrayList;
import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.domain.rule.GroupCharacter;
import nl.belastingdienst.iva.inzicht.domain.rule.RuleUtils;
import nl.belastingdienst.iva.inzicht.engine.RulesEngine;
import nl.belastingdienst.iva.inzicht.engine.condition.Condition;
import nl.belastingdienst.iva.inzicht.engine.condition.ConditionFactory;

public class ConditionParser {

	private ConditionFactory conditionFactory;
	
	public ConditionParser(RulesEngine rulesEngine) {
		this.conditionFactory = rulesEngine.getConditionFactory();
	}
	
	public Condition parse(String startCondition) {
		String condition = startCondition.trim();
		String operator = findFirstOperator(condition, 0);
		return (operator == null) ? parseSingleCondition(condition) : parseMultipleCondition(condition, operator);
	}
	
	private Condition parseSingleCondition(String startCondition) {
		String condition = startCondition.trim();

		if (condition.startsWith(RulesEngineKey.NOTCONDITIONOPERATOR)) {
			return this.conditionFactory.getCondition(RulesEngineKey.NOTCONDITIONOPERATOR, parseSingleCondition(condition.substring(1)));
		} else if (condition.startsWith(RulesEngineKey.GROUPSTART)) {
			int index = condition.lastIndexOf(RulesEngineKey.GROUPEND);
			return parse(condition.substring(RulesEngineKey.GROUPSTART.length(), index));
		}
		
		return this.conditionFactory.getCondition(condition);
	}
	
	private Condition parseMultipleCondition(String condition, String operator) {
		int index = 0;
		List<Condition> conditionList = new ArrayList<>();
		
		while (index >= 0) {
			int nextOperatorIndex = findNextOperatorIndex(condition, operator, index);
			String singleCondition = nextOperatorIndex < 0 ? condition.substring(index) : condition.substring(index, nextOperatorIndex);
			conditionList.add(parse(singleCondition));
			index = (nextOperatorIndex >= 0) ? nextOperatorIndex + operator.length() : -1; 
		}

		return this.conditionFactory.getCondition(operator, conditionList);
	}
	
	private String findFirstOperator(String condition, int startIndex) {
		int index = startIndex;
		
		while (index < condition.length()) {
			if (RuleUtils.findAtIndex(condition, RulesEngineKey.ANDCONDITIONOPERATOR, index)) {
				return RulesEngineKey.ANDCONDITIONOPERATOR;
			} 
				
			if (RuleUtils.findAtIndex(condition, RulesEngineKey.ORCONDITIONOPERATOR, index)) {
				return RulesEngineKey.ORCONDITIONOPERATOR;
			} 
			
			if (RuleUtils.findGroupStartAtIndex(condition, GroupCharacter.ALL, index)) {
				index = RuleUtils.getEndOfGroupIndex(condition, GroupCharacter.ALL, index);
			} else {
				index++;
			}
		}
		
		return null;
	}
	
	private int findNextOperatorIndex(String condition, String operator, int startIndex) {
		int index = startIndex;
		
		while ((index < condition.length()) && !RuleUtils.findAtIndex(condition, operator, index)) {
			if (RuleUtils.findGroupStartAtIndex(condition, GroupCharacter.ALL, index)) {
				index = RuleUtils.getEndOfGroupIndex(condition, GroupCharacter.ALL, index);
			} else {
				index++;
			}
		}

		return (index < condition.length()) ? index : -1;
	}
}
