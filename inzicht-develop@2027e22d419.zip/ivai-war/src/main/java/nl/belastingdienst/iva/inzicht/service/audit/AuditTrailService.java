package nl.belastingdienst.iva.inzicht.service.audit;

import java.util.Date;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.database.audittrail.AuditTrail;
import nl.belastingdienst.iva.inzicht.domain.Version;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@RolesAllowed({ RoleUtils.INZICHT_USER_ROLE })
public class AuditTrailService {

	private static final Logger logger = LoggerFactory.getLogger(AuditTrailService.class);

	@PersistenceContext(unitName = "ivai-pu-inzicht")
	private EntityManager entityManager;

	public void logSubjectSearch(RestCallContext restCallContext) {
		String userName = restCallContext.getUserName();
		String subjectNr = restCallContext.getFirstQueryValue(QueryValueKey.SUBJECTNR);
		String entityNr = restCallContext.getFirstQueryValue(QueryValueKey.ENTITYNR);

		AuditTrail auditTrail = new AuditTrail();
		auditTrail.setSubjectNumber(restCallContext.toString());
		auditTrail.setCreated(new Date());
		auditTrail.setUsername(userName);
		auditTrail.setVersion(Version.INSTANCE.getVersion());

		StringBuilder warning = new StringBuilder("User: '"  + userName + "' retrieved data ");
		if (subjectNr != null) {
		    warning.append("for BSN: '" + subjectNr + "' ");
		} else if (entityNr != null) {
		    warning.append("for Entity: '" + entityNr + "' ");
		}

		warning.append("using Inzicht view: '" + restCallContext.getDomainKey() + "'");
		logger.warn(warning.toString());
		this.entityManager.persist(auditTrail);
	}
}
