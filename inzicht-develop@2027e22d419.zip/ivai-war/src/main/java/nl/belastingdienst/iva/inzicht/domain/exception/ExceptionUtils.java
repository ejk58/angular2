package nl.belastingdienst.iva.inzicht.domain.exception;

public class ExceptionUtils {

    private ExceptionUtils() {
        throw new UnsupportedOperationException();
    }
    
    public static String getExceptionsForMessage(Throwable exception) {
        Throwable cause = exception;
        StringBuilder exceptionBuilder = new StringBuilder();
        
        exceptionBuilder.append(cause.getClass().getSimpleName());
        while (cause.getCause() != null) {
            cause = cause.getCause();
            exceptionBuilder.append(" > ");
            exceptionBuilder.append(cause.getClass().getSimpleName());
        }       
        
        return exceptionBuilder.toString();
    }
}
