package nl.belastingdienst.iva.inzicht.user;

import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.security.auth.Subject;
import javax.security.auth.login.CredentialExpiredException;
import javax.servlet.http.Cookie;

import com.ibm.websphere.security.WSSecurityException;
import com.ibm.websphere.security.auth.WSSubject;
import com.ibm.websphere.security.cred.WSCredential;
import com.ibm.websphere.security.web.WebSecurityHelper;
import com.ibm.ws.webservices.engine.encoding.Base64;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class UserFactory {

    public User getUser() {
        return this.buildUser();
    }
    
    public DataMap getStatus() {
        return createStatus();
    }
    
    private User buildUser() {
        try {
            String name = WSSubject.getCallerPrincipal();
            Set<String> roles = extractRoles();
            String ltpaToken = extractWebsphereLtpaToken();
            
            if (name == null) {
                String message = "The username could not be retrieved.";
                throw new InternalServerErrorException(message);
            }

            return new User(name, roles, ltpaToken);
        } catch (InternalServerErrorException exception) {
        	throw exception;
        } catch (CredentialExpiredException exception) {
            String message = "The credentials seem to be expired with the message: " + exception.getMessage();
            throw new InternalServerErrorException(message, exception);
        } catch (Exception exception) {
            String message = "The credentials could not be retrieved with the message: " + exception.getMessage();
            throw new InternalServerErrorException(message, exception);
        }
    }

    private Set<String> extractRoles() throws WSSecurityException, CredentialExpiredException {
        Set<String> subjectRoles = new HashSet<>();
        Pattern rolePattern = Pattern.compile("[Cc][Nn]=(.*?),");
        WSCredential credentials = getCredential();

        List<?> credentialList = credentials.getGroupIds();
        ListIterator<?> credentialIterator = credentialList.listIterator();
        while (credentialIterator.hasNext()) {
            String credential = (String) credentialIterator.next();
            Matcher roleMatcher = rolePattern.matcher(credential);
            if (roleMatcher.find()) {
                subjectRoles.add(roleMatcher.group(1));
            }
        }

        return subjectRoles;
    }

    private String extractWebsphereLtpaToken() throws WSSecurityException, CredentialExpiredException {
        WSCredential credentials = getCredential();
        byte[] token = credentials.getCredentialToken();

        if (credentials.isUnauthenticated()) {
            throw new InternalServerErrorException("User is unauthenticated, and cannot provide a LTPA-token.");
        }

        if (token == null) {
            throw new InternalServerErrorException("A LTPA-token is not available.");
        }

        return Base64.encode(token);
    }
    
    private String extractLibertyLtpaToken() throws Exception {
        Cookie ssoCookie = WebSecurityHelper.getSSOCookieFromSSOToken();

        if (ssoCookie == null) {
            throw new InternalServerErrorException("A SSO-cookie is not available.");
        }

        return ssoCookie.getValue();
    }

    private WSCredential getCredential() throws WSSecurityException {
        Subject subject = WSSubject.getCallerSubject();
        Set<WSCredential> credentialsSet = subject.getPublicCredentials(WSCredential.class);

        if (credentialsSet.size() > 1) {
            throw new InternalServerErrorException("Found " + credentialsSet.size() + " credentials, but expected only a single credential.");
        }

        if (credentialsSet.isEmpty()) {
            throw new InternalServerErrorException("Found no credentials, but expected a single credential.");
        }

        return credentialsSet.iterator().next();
    }

    private DataMap createStatus() {
        return DomainUtils.emptyDataMap();
    }
}
