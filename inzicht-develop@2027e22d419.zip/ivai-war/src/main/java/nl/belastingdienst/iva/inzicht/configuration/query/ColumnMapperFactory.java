package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.Attribute;
import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;
import nl.belastingdienst.iva.inzicht.domain.query.QueryType;

public class ColumnMapperFactory {

    private static final String TYPE_COORDINATES = "COORDINATES";
    private static final String TYPE_CONCAT = "CONCAT";
    private static final String TYPE_TRANSLATE = "TRANSLATE";
    private static final String TYPE_JSON = "JSON";
    
    private static final String TYPE_COORDINATES_XTYPE = "X-type";
    private static final String TYPE_COORDINATES_XVALUE = "X-value";
    private static final String TYPE_COORDINATES_YTYPE = "Y-type";
    private static final String TYPE_COORDINATES_YVALUE = "Y-value";

    private static final String TYPE_JSON_PAYLOADKEY = "jsonPayload";
    
    private Map<String, AttributeGroup> attributeGroupMap;

    public ColumnMapperFactory(Map<String, AttributeGroup> attributeGroupMap) {
        this.attributeGroupMap = attributeGroupMap;        
    }
    
    public ColumnMapper getColumnMapper(Query query, QueryColumn column) {
        ColumnMapper columnMapper;

        if (column.isComposite()) {
            columnMapper = createCompositeColumnMapper(query, column);
        } else if (column.isValue()) {
            columnMapper = createValueColumnMapper(column);
        } else if (query.getType() == QueryType.REST) {
            columnMapper = createNestedColumnMapper(column);
        } else {
            columnMapper = createSimpleColumnMapper(column);
        }
        
        return columnMapper;
    }
    
    private ColumnMapper createCompositeColumnMapper(Query query, QueryColumn column) {
        ColumnMapper columnMapper;
        
        if (TYPE_COORDINATES.equalsIgnoreCase(column.getType())) {
            columnMapper = createCoordinatesColumnMapper(query, column);
        } else if (TYPE_CONCAT.equalsIgnoreCase(column.getType())) {
            columnMapper = createConcatColumnMapper(query, column);
        } else if (TYPE_TRANSLATE.equalsIgnoreCase(column.getType())) {
            columnMapper = createTranslateColumnMapper(query, column);
        } else if (TYPE_JSON.equalsIgnoreCase(column.getType())) {
            columnMapper = createJsonColumnMapper(query, column);
        } else {
            columnMapper = createObjectColumnMapper(query, column);
        }
        
        return columnMapper;
    }
    
    private ColumnMapper createObjectColumnMapper(Query query, QueryColumn column) {
        return new ObjectColumnMapper(createInnerColumnMappers(query, column), column.getDestinationKey());
    }
    
    private ColumnMapper createCoordinatesColumnMapper(Query query, QueryColumn column) {
        List<ColumnMapper> innerColumnMappers = createInnerColumnMappers(query, column);
    
        for (QueryColumn innerColumn : column.getColumns()) {
            if (TYPE_COORDINATES_XVALUE.equals(innerColumn.getKey())) {
                innerColumnMappers.add(new ValueColumnMapper(innerColumn.getType(), TYPE_COORDINATES_XTYPE));
            } else if (TYPE_COORDINATES_YVALUE.equals(innerColumn.getKey())) {
                innerColumnMappers.add(new ValueColumnMapper(innerColumn.getType(), TYPE_COORDINATES_YTYPE));
            }
        }
        
        return new ObjectColumnMapper(innerColumnMappers, column.getDestinationKey());
    }
    
    private ColumnMapper createConcatColumnMapper(Query query, QueryColumn column) {
        return new ConcatColumnMapper(createInnerColumnMappers(query, column), column.getDestinationKey());
    }
    
    private ColumnMapper createTranslateColumnMapper(Query query, QueryColumn column) {
        ColumnMapper innerColumnMapper = createInnerColumnMapper(query, column);
        String attributeGroupKey = column.getValue();
        AttributeGroup translationGroup = this.attributeGroupMap.get(attributeGroupKey); 
        Map<String, String> translationMap = translationGroup == null ? Collections.<String, String>emptyMap() : translationGroup.getAttributeMap();
        
        return new TranslateColumnMapper(innerColumnMapper, column.getDestinationKey(), translationMap); 
    }
    
    private ColumnMapper createJsonColumnMapper(Query query, QueryColumn column) {
        ColumnMapper payloadColumnMapper = createInnerColumnMapper(query, column);
        String attributeGroupKey = (column.getValue() != null ? column.getValue() : query.getQueryAttributeValue(TYPE_JSON_PAYLOADKEY));
        AttributeGroup attributeGroup = this.attributeGroupMap.get(attributeGroupKey); 
        List<Attribute> attributeList = (attributeGroup == null ? Collections.<Attribute>emptyList() : attributeGroup.getAttributeList());
        
        return new JsonColumnMapper(payloadColumnMapper, column.getDestinationKey(), attributeList); 
    }
    
    private ColumnMapper createValueColumnMapper(QueryColumn column) {
        return new ValueColumnMapper(column.getValue(), column.getDestinationKey());
    }
    
    private ColumnMapper createNestedColumnMapper(QueryColumn column) {
        return new NestedColumnMapper(column.getSourceKey(), column.getDestinationKey());
    }
    
    private ColumnMapper createSimpleColumnMapper(QueryColumn column) {
        return new SimpleColumnMapper(column.getSourceKey(), column.getDestinationKey());
    }

    private List<ColumnMapper> createInnerColumnMappers(Query query, QueryColumn column) {
        List<ColumnMapper> innerColumnMappers = new ArrayList<>();
        
        for (QueryColumn innerColumn : column.getColumns()) {
            innerColumnMappers.add(getColumnMapper(query, innerColumn));
        }

        return innerColumnMappers;
    }

    private ColumnMapper createInnerColumnMapper(Query query, QueryColumn column) {
        List<ColumnMapper> innerColumnMappers = createInnerColumnMappers(query, column);
        
        return innerColumnMappers.isEmpty() ? new ValueColumnMapper(null, column.getDestinationKey()) : innerColumnMappers.get(0);
    }
}    
