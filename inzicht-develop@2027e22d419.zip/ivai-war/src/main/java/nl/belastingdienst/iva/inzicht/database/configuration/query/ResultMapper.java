package nl.belastingdienst.iva.inzicht.database.configuration.query;

import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

@FunctionalInterface
public interface ResultMapper {
	
	List<DataMap> map(List<DataMap> sourceData);
}
