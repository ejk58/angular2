package nl.belastingdienst.iva.inzicht.permission;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.dataprovider.rest.MihProxyPermissionClient;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataVipCheckClient;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.permission.Permission;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContextFactory;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class PermissionFactory {

	private static final Permission DEFAULTPERMISSION = new Permission(true);
    private static final String MIHPROVIDER = "MIH";
    private static final long DEFAULTCACHEEXPIRATIONAGE = 3600000L;

    private static final Logger logger = LoggerFactory.getLogger(PermissionFactory.class);

    @Inject
    private ConfigurationFactory configurationFactory;

    @Inject
    private RestCallContextFactory restCallContextFactory;

    @Inject
    private TeradataVipCheckClient teradataVipCheckClient;

    @Inject
    private MihProxyPermissionClient mihProxyPermissionClient;

    private PermissionCache permissionCache;
    private long cacheExpirationAge;

    public PermissionFactory() {
        this.permissionCache = new PermissionCache();
        this.cacheExpirationAge = DEFAULTCACHEEXPIRATIONAGE;
    }

    @Schedule(minute = "*/10", hour = "*", persistent = false)
    public void clean() {
        updateExpirationAge();
        cleanPermissionCache();
    }

    public Permission getPermission(RestCallContext restCallContext, QueryParameterType parameterType, String parameterValue) {
    	Permission permission = DEFAULTPERMISSION;

    	if (parameterType.isPermissionValue() && parameterValue != null) {
            RestCallContext permissionRestCallContext = createPermissionRestCallContext(restCallContext, parameterType, parameterValue);
            permission = getFromCacheOrProvider(PermissionType.ACCESS, permissionRestCallContext, parameterType);
        }

        return permission;
    }

    public Permission getPermission(RestCallContext restCallContext, String fiscalNr) {
    	Permission permission = DEFAULTPERMISSION;

    	if (fiscalNr != null) {
            RestCallContext permissionRestCallContext = createPermissionRestCallContext(restCallContext, QueryParameterType.FISCALNUMBER, fiscalNr);
            permission = getFromCacheOrProvider(PermissionType.RESULT, permissionRestCallContext, QueryParameterType.FISCALNUMBER);
        }

        return permission;
    }

    public boolean getAccess(RestCallContext restCallContext, QueryParameterType parameterType, String parameterValue) {
    	Permission permission = getPermission(restCallContext, parameterType, parameterValue);
    	return permission.getAccess();
    }

    public boolean getAccess(RestCallContext restCallContext, String fiscalNr) {
    	Permission permission = getPermission(restCallContext, fiscalNr);
    	return permission.getAccess();
    }

    public DataMap getStatus() {
        return createStatus();
    }

    public boolean getCacheAvailable(RestCallContext restCallContext) {
        Configuration configuration = this.configurationFactory.getConfiguration();
        return DomainUtils.isTrue(configuration.getValueAsString(ConfigurationKey.PERMISSIONCACHEACCESSIBLE)) && (restCallContext.getUserName() != null);
    }

    private Permission getFromCacheOrProvider(PermissionType permissionType, RestCallContext restCallContext, QueryParameterType parameterType) {
    	Permission permission = null;

    	if (getCacheAvailable(restCallContext)) {
    		permission = getFromCache(permissionType, restCallContext, parameterType);
    	}

        if (permission == null) {
            permission = getFromProvider(permissionType, restCallContext, parameterType);
        }

       	return permission;
    }

    private Permission getFromCache(PermissionType permissionType, RestCallContext restCallContext, QueryParameterType parameterType) {
        Configuration configuration = this.configurationFactory.getConfiguration();
        String permissionProvider = configuration.getValueAsString(permissionType.getConfigurationKey());
        PermissionCacheKey cacheKey = createPermissionCacheKey(permissionProvider, restCallContext, parameterType);
        return this.permissionCache.retrieve(cacheKey);
    }

    private Permission getFromProvider(PermissionType permissionType, RestCallContext restCallContext, QueryParameterType parameterType) {
        Configuration configuration = this.configurationFactory.getConfiguration();
        String permissionProvider = configuration.getValueAsString(permissionType.getConfigurationKey());
        Permission permission;

        if (MIHPROVIDER.equalsIgnoreCase(permissionProvider)) {
            permission = getMihProxyPermission(restCallContext, parameterType);
        } else {
            permission = getTeradataPermission(restCallContext, parameterType);
        }

        if (getCacheAvailable(restCallContext)) {
            PermissionCacheKey cacheKey = createPermissionCacheKey(permissionProvider, restCallContext, parameterType);
            this.permissionCache.store(cacheKey, permission);
        }

        return permission;
    }

    private Permission getMihProxyPermission(RestCallContext restCallContext, QueryParameterType parameterType) {
    	return this.mihProxyPermissionClient.getPermission(restCallContext, parameterType.getPermissionKey());
    }

    private Permission getTeradataPermission(RestCallContext restCallContext, QueryParameterType parameterType) {
    	return this.teradataVipCheckClient.getPermission(restCallContext, parameterType.getPermissionKey());
    }

    private void updateExpirationAge() {
        Configuration configuration = this.configurationFactory.getConfiguration();
        this.cacheExpirationAge = configuration.getValueAsNumber(ConfigurationKey.PERMISSIONCACHEEXPIRATIONAGE);
    }

    private void cleanPermissionCache() {
        logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Starting the cleaning of the permission cache."));

        long startTime = System.currentTimeMillis();
        try {
            this.permissionCache.clean(this.cacheExpirationAge);

            logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Cleaned the permission cache in " +
                    MessageUtils.createDuration(System.currentTimeMillis() - startTime)));
        } catch (Exception exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Cleaning the permission cache throws an exception " +
                    ExceptionUtils.getExceptionsForMessage(exception)), exception);
        }
    }

    private RestCallContext createPermissionRestCallContext(RestCallContext restCallContext, QueryParameterType parameterType, String parameterValue) {
        MultiValuedHashMap<String, String> queryValues = new MultiValuedHashMap<>();
        queryValues.putAll(restCallContext.getQueryValues());
        queryValues.putSingle(parameterType.getPermissionKey(), parameterValue);
        return this.restCallContextFactory.getRestCallContext(restCallContext, queryValues);
    }

    private PermissionCacheKey createPermissionCacheKey(String permissionProvider, RestCallContext restCallContext, QueryParameterType parameterType) {
        String domainKey = restCallContext.getDomainKey();
    	String userName = restCallContext.getUserName();
    	String key = parameterType.getPermissionKey();
    	String value = restCallContext.getFirstQueryValue(key);

    	return new PermissionCacheKey(permissionProvider, domainKey, userName, key, value);
    }

    private DataMap createStatus() {
        DataMap status = new DataHashMap();

        status.put(ResponseKey.CACHEEXPIRATIONAGE, MessageUtils.createDuration(this.cacheExpirationAge));
        status.put(ResponseKey.CACHESIZE, this.permissionCache.getSize());

        return status;
    }
}
