package nl.belastingdienst.iva.inzicht.domain.releasenote;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class VersionComparator implements Comparator<String> {

	private static final Pattern VERSIONPATTERN = Pattern.compile("\\d+(\\.\\d+)*");
	
	@Override
	public int compare(String version, String otherVersion) {
		List<Integer> versionElements = splitVersion(version);
		List<Integer> otherVersionElements = splitVersion(otherVersion);
		
		int result = compareVersionElements(versionElements, otherVersionElements);
		
		if (result == 0) {
			result = compareVersionSizes(versionElements, otherVersionElements);
		}
		
		return result;
	}
	
	private int compareVersionElements(List<Integer> versionElements, List<Integer> otherVersionElements) {
		int maxIndex = Math.min(versionElements.size(), otherVersionElements.size());
		int index = 0;
		int result = 0;
		
		while (result == 0 && index < maxIndex) {
			result = otherVersionElements.get(index) - versionElements.get(index);
			index++;
		}
		
		return result;
	}
	
	private int compareVersionSizes(List<Integer> versionElements, List<Integer> otherVersionElements) {
		return otherVersionElements.size() - versionElements.size();
	}
	
	private List<Integer> splitVersion(String version) {
		List<Integer> versionElements = Collections.emptyList();

		if (version != null && checkVersion(version)) {
			versionElements = Arrays.stream(version.split("\\."))
					.map(Integer::parseUnsignedInt)
					.collect(Collectors.toList());
		}
		
		return versionElements;
	}
	
	private boolean checkVersion(String version) {
		Matcher matcher = VERSIONPATTERN.matcher(version);
		return matcher.matches();
	}
}
