package nl.belastingdienst.iva.inzicht.domain.permission;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

public class Permission implements Serializable {

    private static final long serialVersionUID = 1L;

	private boolean access;
	private List<String> categories;

	public Permission(boolean access, List<String> categories) {
		this.access = access;
		this.categories = categories;
	}

	public Permission(boolean access) {
		this(access, Collections.emptyList());
	}

	public boolean getAccess() {
		return this.access;
	}

	public List<String> getCategories() {
		return this.categories;
	}
}
