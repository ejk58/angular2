package nl.belastingdienst.iva.inzicht.dataprovider;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;

import javax.ws.rs.core.MediaType;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.AbstractHttpMessage;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.credential.Credential;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialTransport;
import nl.belastingdienst.iva.inzicht.domain.credential.CredentialType;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.GatewayTimeoutException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.exception.MissingTeradataViewException;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.User;

public abstract class AbstractHttpClient {

    private static final String ACCEPTHEADER_DEFAULT = MediaType.APPLICATION_JSON;
    private static final String CONTENTTYPEHEADER_DEFAULT = MediaType.APPLICATION_JSON;
    private static final String ENCODINGCHARSET_DEFAULT = HTTP.UTF_8;
    
    private static final String HTTPHEADER_COOKIE = "Cookie";

    protected HttpGet createGetRequest(Datasource datasource, String requestUrl, RestCallContext restCallContext) {
        HttpGet getRequest = new HttpGet(requestUrl);
        addHeaders(getRequest, datasource, restCallContext);

        return getRequest;
    }

    protected HttpPost createPostRequest(Datasource datasource, String requestUrl, String payload, RestCallContext restCallContext) {
    	String datasourceCharset = datasource.getValue(DatasourceKey.ENCODINGCHARSET);
        String charset = datasourceCharset == null ? ENCODINGCHARSET_DEFAULT : datasourceCharset;

        HttpPost postRequest = new HttpPost(requestUrl);
        addHeaders(postRequest, datasource, restCallContext);

        try {
            postRequest.setEntity(new StringEntity(payload, charset));
        } catch (UnsupportedEncodingException exception) {
            String message = "Failed to encode the payload for the post-request with an encoding exception " +
                    ExceptionUtils.getExceptionsForMessage(exception) + " (requestUrl = " + requestUrl + ", payload = " + payload + ")";
            throw new InternalServerErrorException(message, exception);
        }

        return postRequest;
    }

    protected HttpPost createPostRequest(Datasource datasource, String requestUrl, HttpEntity payload, RestCallContext restCallContext) {
        HttpPost postRequest = new HttpPost(requestUrl);
        addCredentialHeader(postRequest, datasource, restCallContext);
        addAcceptHeader(postRequest, datasource);

        postRequest.setEntity(payload);
        return postRequest;
    }

    protected void handleHttpStatusCode(HttpResponse response, String datasourceName, String requestDescription) {
        int statusCode = response.getStatusLine().getStatusCode();
        String reasonPhrase = response.getStatusLine().getReasonPhrase();

        if (statusCode >= 400) {
            try {
            	String responseMessage = EntityUtils.toString(response.getEntity());
                String message = "Failed to retrieve data from " + datasourceName + " with status code " + statusCode + ", reason '" + 
                        reasonPhrase + "', and response '" + responseMessage + "' " + requestDescription;
                throw buildExceptionForHttpResponse(statusCode, message);
            } catch (ParseException | IOException | IllegalArgumentException exception) {
                String message = "Failed to retrieve data from " + datasourceName + " with status code " + statusCode +
                        ", reason '" + reasonPhrase + "', and a response that could not be decoded " + requestDescription;
                throw new BadGatewayException(message);
            }
        }
    }
    
    protected RuntimeException buildExceptionForHttpResponse(int statusCode, String message) {
    	return new BadGatewayException(message);
    }

    protected void handleException(Exception exception, String datasourceName, String requestDescription) {
        if (exception instanceof ConnectException) {
            String message = "Failed to connect to " + datasourceName + " with an exception " +
                    ExceptionUtils.getExceptionsForMessage(exception) + " " + requestDescription;
            throw new BadGatewayException(message, exception);
        } else if (exception instanceof SocketTimeoutException) {
            String message = "Failed to retrieve data from " + datasourceName + " with a time-out exception " +
                    ExceptionUtils.getExceptionsForMessage(exception) + " " + requestDescription;
            throw new GatewayTimeoutException(message, exception);
        } else if (exception instanceof IOException) {
            String message = "Failed to retrieve data from " + datasourceName + " with an I/O exception " +
                    ExceptionUtils.getExceptionsForMessage(exception) + " " + requestDescription;
            throw new BadGatewayException(message, exception);
        } else if (exception instanceof BadGatewayException) {
            throw (BadGatewayException) exception;
        } else if (exception instanceof InternalServerErrorException) {
            throw (InternalServerErrorException) exception;
        } else if (exception instanceof MissingTeradataViewException) {
            throw (MissingTeradataViewException) exception;
        } else {
            String message = "Failed to retrieve data from " + datasourceName + " with an unexpected exception " +
                    ExceptionUtils.getExceptionsForMessage(exception) + " " + requestDescription;
            throw new InternalServerErrorException(message, exception);
        }
    }

    private void addHeaders(AbstractHttpMessage httpRequest, Datasource datasource, RestCallContext restCallContext) {
        addCredentialHeader(httpRequest, datasource, restCallContext);
        addAcceptHeader(httpRequest, datasource);
        addContentTypeHeader(httpRequest, datasource);
        addWsaAddressHeader(httpRequest, datasource);
    }

    private <T extends AbstractHttpMessage> void addCredentialHeader(T httpRequest, Datasource datasource, RestCallContext restCallContext) {
        Credential credential = datasource.getCredential();

        if (credential != null) {
            CredentialType credentialType = credential.getType();
            CredentialTransport credentialTransport = credential.getTransport();

            if (datasource.getValue(DatasourceKey.CREDENTIALSPOOLSIZE) != null && restCallContext != null) {
                restCallContext.addQueryValue("datasourceLogin", credential.getName());
            }

            if (credentialTransport == CredentialTransport.HTTPHEADER) {
                addCredentialHeaderForHttpHeader(httpRequest, datasource, credential);
            }

            if (credentialTransport == CredentialTransport.COOKIE) {
                addCredentialHeaderForCookie(httpRequest, datasource, restCallContext, credentialType);
            }
        }
    }

    private <T extends AbstractHttpMessage> void addCredentialHeaderForHttpHeader(T httpRequest, Datasource datasource, Credential credential) {
        String headerName = datasource.getValue(DatasourceKey.CREDENTIALSHEADER);
        String headerValue = new String(credential.getValue());
        httpRequest.setHeader(headerName, headerValue);
    }

    private void addCredentialHeaderForCookie(AbstractHttpMessage httpRequest, Datasource datasource, 
            RestCallContext restCallContext, CredentialType credentialType) {
        if (credentialType == CredentialType.LTPATOKEN || credentialType == CredentialType.LTPA2TOKEN) {
            if (restCallContext == null || restCallContext.getUser() == null) {
                String message = "Failed to create an LTPA-token cookie for  " + datasource.getKey() + " due to missing user data.";
                throw new InternalServerErrorException(message);
            }

            User user = restCallContext.getUser();
            String cookieName = datasource.getValue(DatasourceKey.COOKIENAME);
            String cookieValue = user.getLtpaToken();
            httpRequest.setHeader(HTTPHEADER_COOKIE, cookieName + "=" + cookieValue);
        }
    }

    private void addAcceptHeader(AbstractHttpMessage httpRequest, Datasource datasource) {
    	String accept = datasource.getValue(DatasourceKey.ACCEPTHEADER);
    	
    	if (accept == null) {
         	httpRequest.setHeader(HttpHeaders.ACCEPT, ACCEPTHEADER_DEFAULT);
    	} else if (!DomainUtils.EMPTY_ITEM.equals(accept)) {
         	httpRequest.setHeader(HttpHeaders.ACCEPT, accept);
        }
    }

    private void addContentTypeHeader(AbstractHttpMessage httpRequest, Datasource datasource) {
    	String contentType = datasource.getValue(DatasourceKey.CONTENTTYPEHEADER);
    	
    	if (contentType == null) {
            httpRequest.setHeader(HttpHeaders.CONTENT_TYPE, CONTENTTYPEHEADER_DEFAULT);
    	} else if (!DomainUtils.EMPTY_ITEM.equals(contentType)) {
            httpRequest.setHeader(HttpHeaders.CONTENT_TYPE, contentType);
        } 
    }

    private void addWsaAddressHeader(AbstractHttpMessage httpRequest, Datasource datasource) {
        String wsaAddress = datasource.getValue(DatasourceKey.WSAADDRESSHEADER);

        if (wsaAddress != null && !DomainUtils.EMPTY_ITEM.equals(wsaAddress)) {
            httpRequest.setHeader("X_WSA_ADDRESS_X", wsaAddress);
        }
    }
}
