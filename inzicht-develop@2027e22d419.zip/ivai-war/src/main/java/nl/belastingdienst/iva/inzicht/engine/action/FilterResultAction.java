package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class FilterResultAction implements Action {

	public static final String NAME = "FilterResult";

	private List<String> resultColumns;
	private String operator;
	private String value;

	public FilterResultAction(List<String> resultColumns, String operator, String value) {
		if (!operator.equals("equals") && !operator.equals("notStartsWith")) {
			throw new UnsupportedOperationException("The operator for the FilterResult-action must be 'equals' or 'notStartsWith', other operators ('" + operator + "') are not yet supported.");
		}

		if (value == null) {
			throw new IllegalArgumentException("The FilterResult-action is given a null-value, but is must have a non-empty value.");
		}

		this.resultColumns = resultColumns;
		this.operator = operator;
		this.value = value;
	}

	@Override
	public Flow execute(RestCallContext restCallContext) {
		Result result = restCallContext.getResult();
		List<DataMap> data = result.getData();
		List<DataMap> filterData = new ArrayList<>();
		
		for (DataMap dataRow : data) {
			Object resultRowValue = DomainUtils.getFromNestedMap(dataRow, this.resultColumns);
			
            switch (this.operator) {
                case "equals":
                	if (this.value.equals(resultRowValue)) {
                		filterData.add(dataRow);
                	}
                	break;
                case "notStartsWith":
                	if (resultRowValue == null || !resultRowValue.toString().startsWith(this.value)) {
                		filterData.add(dataRow);
                	}
                	break;
            }
		}

		result.setData(DomainUtils.inArray(filterData));
		restCallContext.setResult(result);

		return Flow.CONTINUE;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.resultColumns.stream().collect(Collectors.joining("/")) + RulesEngineKey.PARAMETERSEPARATOR + this.operator + RulesEngineKey.PARAMETERSEPARATOR + this.value + RulesEngineKey.PARAMETEREND;
	}
}
