package nl.belastingdienst.iva.inzicht.database.configuration.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_DOMAIN_MENUGROUP")
public class DomainMenuGroup {

    @Id
    private Integer id;
    private Integer index;
    private String title;
    private String iconName;
    
    public Integer getId() {
        return id;
    }
    
    public Integer getIndex() {
        return index;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getIconName() {
        return iconName;
    }
}
