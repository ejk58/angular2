package nl.belastingdienst.iva.inzicht.monitor;

import nl.belastingdienst.iva.inzicht.domain.MessageUtils;

public class Monitor {

	Long maximumAvailableMemory;
	Long allocatedTotalMemory;
	Long allocatedFreeMemory;
	
	public Long getMaximumAvailableMemory() {
		return this.maximumAvailableMemory;
	}
	
	public void setMaximumAvailableMemory(Long maximumAvailableMemory) {
		this.maximumAvailableMemory = maximumAvailableMemory == Long.MAX_VALUE ? null : maximumAvailableMemory;
	}
	
	public Long getAllocatedTotalMemory() {
		return this.allocatedTotalMemory;
	}
	
	public void setAllocatedTotalMemory(Long allocatedTotalMemory) {
		this.allocatedTotalMemory = allocatedTotalMemory;
	}
	
	public Long getAllocatedFreeMemory() {
		return this.allocatedFreeMemory;
	}
	
	public void setAllocatedFreeMemory(Long allocatedFreeMemory) {
		this.allocatedFreeMemory = allocatedFreeMemory;
	}
	
	public Long getAllocatedUsedMemory() {
		return this.allocatedTotalMemory - this.allocatedFreeMemory;
	}
	
	public Long getPresumablyFreeMemory() {
		return this.maximumAvailableMemory == null ? null : (this.maximumAvailableMemory - getAllocatedUsedMemory());
	}
	
	public Integer getPresumablyFreePercentage() {
		Long presumablyFreeMemory = getPresumablyFreeMemory();
		return presumablyFreeMemory == null ? null : (int) ((presumablyFreeMemory * 100) / this.maximumAvailableMemory);
	}

	@Override
	public String toString() {
		Long presumablyFreeMemory = getPresumablyFreeMemory();
		
		return "maximumAvailableMemory = " + (this.maximumAvailableMemory == null ? MessageUtils.UNKNOWN : MessageUtils.createSize(this.maximumAvailableMemory)) + 
				", allocatedTotalMemory = " + MessageUtils.createSize(this.allocatedTotalMemory) + 
				", allocatedFreeMemory = " + MessageUtils.createSize(this.allocatedFreeMemory) + 
				", allocatedUsedMemory = " + MessageUtils.createSize(getAllocatedUsedMemory()) + 
				", presumablyFreeMemory = " + (presumablyFreeMemory == null ? MessageUtils.UNKNOWN : MessageUtils.createSize(presumablyFreeMemory));
	}
}
