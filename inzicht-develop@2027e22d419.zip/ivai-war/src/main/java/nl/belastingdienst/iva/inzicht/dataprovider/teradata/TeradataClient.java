package nl.belastingdienst.iva.inzicht.dataprovider.teradata;

import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.stream.Collectors;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractHttpClient;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProviderClient;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.dataprovider.sql.SqlQuery;
import nl.belastingdienst.iva.inzicht.dataprovider.sql.SqlQueryFactory;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.JsonMapper;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.datasource.HttpDatasource;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.exception.MissingTeradataViewException;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContextFactory;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;

@Typed(TeradataClient.class)
public class TeradataClient extends AbstractHttpClient implements DataProviderClient {

	private static final String DATASOURCENAME = "Teradata";
	private static final String DATAPATH = "results/[0]/data";
	private static final String QUERYPREFIX = "{\"rowLimit\": \"0\", \"query\": \"";
	private static final String QUERYPOSTFIX = "\"}";
    private static final String MISSINGOBJECTMARKER = "\"error\" : \"3807\"";

    private static final Logger logger = LoggerFactory.getLogger(TeradataClient.class);

    @Inject
    private RestCallContextFactory restCallContextFactory;

    @Inject
    private SqlQueryFactory sqlQueryFactory;

    @Inject
    private ConfigurationFactory configurationFactory;

    @Inject
    private JsonMapper jsonMapper;

    @Override
    public Result retrieveData(QueryInterface query, RestCallContext restCallContext) {
        SqlQuery sqlQuery = prepareQuery(query, restCallContext);
        TeradataResult result = postQuery(sqlQuery, restCallContext);
        return new Result(processResultSet(result), processMetadata(result));
    }

    public Result retrieveDataAsMultiMap(QueryInterface query, Configuration configuration, MultivaluedMap<String, String> queryValues) {
    	RestCallContext restCallContext = this.restCallContextFactory.getRestCallContext(RestServiceType.NONE, queryValues, configuration);
    	return retrieveData(query, restCallContext);
    }

    public JsonNode retrieveDataAsJson(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Configuration configuration = this.configurationFactory.getConfiguration();
    	RestCallContext restCallContext = this.restCallContextFactory.getRestCallContext(RestServiceType.NONE, queryValues, configuration);
        SqlQuery sqlQuery = prepareQuery(query, restCallContext);
        TeradataResult result = postQuery(sqlQuery, restCallContext);
        return extractResultSet(result);
    }

    private SqlQuery prepareQuery(QueryInterface query, RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        Datasource datasource = query.hasDatasource() ? query.getDatasource() : configuration.getTeradataDatasource();
        return this.sqlQueryFactory.getSqlQuery(datasource, query, queryValues, configuration);
    }

    private TeradataResult postQuery(SqlQuery sqlQuery, RestCallContext restCallContext) {
        Datasource datasource = sqlQuery.getDatasource();
        boolean queryExplainMonitor = datasource.getBoolean(DatasourceKey.QUERYEXPLAINMONITOR);
        boolean retryOnTimeout = datasource.getBoolean(DatasourceKey.RETRYONTIMEOUT);
        TeradataResult result = new TeradataResult();

        if (queryExplainMonitor) {
        	explainTeradataQuery(sqlQuery, restCallContext, result);
        }

        callTeradataQuery(sqlQuery, restCallContext, retryOnTimeout, result);
        return result;
    }

    private DataMap[] processResultSet(TeradataResult result) {
    	return this.jsonMapper.mapToDataMapArray(DATASOURCENAME, DATAPATH, result.getResponse());
    }

    private JsonNode extractResultSet(TeradataResult result) {
    	return this.jsonMapper.mapToJsonNode(DATASOURCENAME, DATAPATH, result.getResponse());
    }

    private DataMap processMetadata(TeradataResult result) {
    	DataMap metadata = new DataHashMap();

    	if (result.isFullAmpQuery()) {
    		metadata.put(Result.ALLAMPTERADATAQUERY, true);
    	}

    	return metadata;
    }

    private void callTeradataQuery(SqlQuery sqlQuery, RestCallContext restCallContext, boolean retryOnTimeout, TeradataResult result) {
        Datasource datasource = sqlQuery.getDatasource();
        String requestUrl = datasource.getValue(DatasourceKey.RESTURL);
        String query = QUERYPREFIX + sqlQuery.getQuery() + QUERYPOSTFIX;
        String queryDescription = "(query = '" + query + "')";
        CloseableHttpClient httpClient = getHttpClientFromDatasource(datasource);
        HttpPost httpPost = createPostRequest(datasource, requestUrl, query, restCallContext);
        long slowExecutionThreshold = datasource.getNumber(DatasourceKey.SLOWEXECUTIONTIME);

        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
            long before = System.currentTimeMillis();

            handleHttpStatusCode(response, DATASOURCENAME, queryDescription);
           	result.setResponse(EntityUtils.toString(response.getEntity()));

            long duration = System.currentTimeMillis() - before;
            if (duration > slowExecutionThreshold) {
                logger.warn(MessageUtils.createMessage(MessageType.WARNING, "Slow query (" + duration + "ms) on Teradata " + queryDescription));
            }
        } catch (SocketTimeoutException exception) {
        	if (retryOnTimeout) {
        		logger.warn(MessageUtils.createMessage(MessageType.WARNING, "Retry for query on Teradata after time-out exception " +
        				ExceptionUtils.getExceptionsForMessage(exception) + " " + queryDescription));
        		callTeradataQuery(sqlQuery, restCallContext, false, result);
        	} else {
        		handleException(exception, DATASOURCENAME, queryDescription);
        	}
        } catch (Exception exception) {
       		handleException(exception, DATASOURCENAME, queryDescription);
        }
    }

    private void explainTeradataQuery(SqlQuery sqlQuery, RestCallContext restCallContext, TeradataResult result) {
        Datasource datasource = sqlQuery.getDatasource();
        String requestUrl = datasource.getValue(DatasourceKey.RESTURL);
        String query = QUERYPREFIX + "EXPLAIN " + sqlQuery.getQuery() + QUERYPOSTFIX;
        String queryDescription = "(explain query = '" + query + "')";
        CloseableHttpClient httpClient = getHttpClientFromDatasource(datasource);
        HttpPost httpPost = createPostRequest(datasource, requestUrl, query, restCallContext);

        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
            handleHttpStatusCode(response, DATASOURCENAME, queryDescription);
            TeradataResult monitorResult = new TeradataResult();
           	monitorResult.setResponse(EntityUtils.toString(response.getEntity()));
           	result.setFullAmpQuery(monitorExplainResult(queryDescription, monitorResult));
        } catch (Exception exception) {
    		logger.warn(MessageUtils.createMessage(MessageType.WARNING, "Failed to run the explain-query on Teradata with exception " +
    				ExceptionUtils.getExceptionsForMessage(exception) + " " + queryDescription));
        }
    }

    private boolean monitorExplainResult(String queryDescription, TeradataResult monitorResult) {
       	DataMap[] explanation = processResultSet(monitorResult);
        String fullExplanation = explanation == null ? "" :
        		Arrays.asList(explanation).stream().map(explanationRow -> (String) explanationRow.get("Explanation")).collect(Collectors.joining(" "));
        boolean allAmpWarning = fullExplanation.indexOf("all-AMP") >= 0;

        if (allAmpWarning) {
        	logger.warn(MessageUtils.createMessage(MessageType.WARNING, "The Teradata-query is probably not single-amp " +
        			queryDescription + " with explanation: " + fullExplanation));
        }

        return allAmpWarning;
    }

    @Override
    protected RuntimeException buildExceptionForHttpResponse(int statusCode, String message) {
    	return (statusCode == 420 && message.contains(MISSINGOBJECTMARKER)) ? new MissingTeradataViewException(message) : new BadGatewayException(message);
    }

    @Override
    protected void handleException(Exception exception, String datasourceName, String requestDescription) {
      if (exception instanceof MissingTeradataViewException) {
        throw (MissingTeradataViewException) exception;
      } else {
    	  super.handleException(exception, datasourceName, requestDescription);
      }
    }

    private CloseableHttpClient getHttpClientFromDatasource(Datasource datasource) {
        if (!(datasource instanceof HttpDatasource)) {
            String message = "The datasource " + datasource.getKey() + " cannot be used to access a Teradata datasource.";
            throw new InternalServerErrorException(message);
        }

        HttpDatasource restDatasource = (HttpDatasource) datasource;
        return restDatasource.getHttpClient();
    }
}
