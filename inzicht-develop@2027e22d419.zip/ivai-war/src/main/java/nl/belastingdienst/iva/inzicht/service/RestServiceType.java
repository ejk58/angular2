package nl.belastingdienst.iva.inzicht.service;

public enum RestServiceType {
	DOMAINSERVICE("DomainService/getDomains"),
	PAGESERVICE("PageService/getAllPages"),
	WIDGETSERVICE("WidgetService/getWidget"),
	RELATIONSERVICE("RelationService/getRelations"),

	SUBJECTGETSERVICE("SubjectService/getSubject"),
    SUBJECTFINDSERVICE("SubjectService/findSubject"),

	EVENTSAVESERVICE("EventService/saveEvent"),
	FEEDBACKSAVESERVICE("FeedbackService/saveFeedback"),
	NOTIFICATIONSERVICE("NotificationService/getNotifications"),
	RELEASENOTESERVICE("ReleaseNoteService/getReleaseNotes"),

	ALIVESERVICE("SystemService/isAlive"),
	SYSTEMSERVICE("SystemService/getStatus"),

	NONE("None");

	private String name;

	private RestServiceType(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
