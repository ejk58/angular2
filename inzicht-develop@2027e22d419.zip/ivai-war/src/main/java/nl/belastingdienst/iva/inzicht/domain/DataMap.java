package nl.belastingdienst.iva.inzicht.domain;

import java.io.Serializable;
import java.util.Map;

public interface DataMap extends Map<String, Object>, Serializable {

    public String getAsString(String key);

    public int getIndex(String key);

    public void put(int index, String key, Object value);

    public void putMany(String key, Object... values);
}
