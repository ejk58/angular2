package nl.belastingdienst.iva.inzicht.configuration.rule;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.RulesEngine;
import nl.belastingdienst.iva.inzicht.engine.action.Action;
import nl.belastingdienst.iva.inzicht.engine.action.ActionFactory;

public class ActionParser {

	private static final String ACTIONOPERATORREGEX = "\\" +  RulesEngineKey.ACTIONOPERATOR;
	
	@Inject
	private ActionFactory actionFactory;
	
	public ActionParser(RulesEngine rulesEngine) {
		this.actionFactory = rulesEngine.getActionFactory();
	}

	public Action parse(String action) {
		String[] actions = action.split(ACTIONOPERATORREGEX);
		return actions.length > 1 ? parseMultipleAction(actions) : parseSingleAction(action.trim());
	}
	
	private Action parseMultipleAction(String[] actions) {
		List<Action> actionList = new ArrayList<>();
		for (String action : actions) {
			actionList.add(parseSingleAction(action.trim()));	
		}

		return this.actionFactory.getAction(actionList);
	}
	
	private Action parseSingleAction(String action) {
		return this.actionFactory.getAction(action);
	}
}
