package nl.belastingdienst.iva.inzicht.database.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import java.util.Date;

public class EventDao {

	private static final Logger logger = LoggerFactory.getLogger(EventDao.class);

	@PersistenceContext(unitName = "ivai-pu-inzicht")
	private EntityManager entityManager;

	public void saveEvent(Event event) {
		try {
			event.setCreated(new Date());
			this.entityManager.persist(event);
		} catch (PersistenceException exception) {
			logger.error("Failed to save an event (" + event + ") to the database with exception " + exception.getClass() + ": " + exception.getMessage() + ".");
		}
	}
}
