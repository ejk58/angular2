package nl.belastingdienst.iva.inzicht.engine.condition;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class QueryValuePresentCondition implements Condition {

	public static final String NAME = "QueryValuePresent";
	
	private String queryValueKey;
	
	public QueryValuePresentCondition(String queryValueKey) {
		this.queryValueKey = queryValueKey;
	}
	
	@Override
	public boolean test(RestCallContext restCallContext) {
		MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues(); 
		return queryValues.containsKey(this.queryValueKey) && queryValues.getFirst(this.queryValueKey) != null;
	}

	@Override
	public String getCondition() {
		return NAME + RulesEngineKey.PARAMETERSTART + queryValueKey + RulesEngineKey.PARAMETEREND;
	}
}
