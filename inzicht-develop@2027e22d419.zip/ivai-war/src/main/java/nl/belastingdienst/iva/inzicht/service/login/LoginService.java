package nl.belastingdienst.iva.inzicht.service.login;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;
import nl.belastingdienst.iva.inzicht.user.User;
import nl.belastingdienst.iva.inzicht.user.UserFactory;

@Path("/security")
public class LoginService {

    private static final Logger logger = LoggerFactory.getLogger(LoginService.class);

    @Context
    private HttpServletRequest httpServletRequest;

    @Inject
    private UserFactory userFactory;

    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(LoginRequest loginRequest) {
        try {
            if (this.httpServletRequest.getUserPrincipal() != null) {
                this.httpServletRequest.logout();
            }
            httpServletRequest.login(loginRequest.getUsername(), loginRequest.getPassword());

        } catch (Exception exception) {
        	String message = MessageUtils.createMessage(MessageType.WARNING,
        			"Failed to authenticate the user '" + loginRequest.getUsername() + "' with wrong credentials.");
        	logger.warn(message);
            return Response.status(Response.Status.FORBIDDEN).build();
        }

        if (!this.httpServletRequest.isUserInRole(RoleUtils.INZICHT_USER_ROLE)) {
        	String message = MessageUtils.createMessage(MessageType.WARNING,
        			"Failed to authorize the user '" + loginRequest.getUsername() + "' due to missing access rights.");
        	logger.warn(message);
            return Response.status(Response.Status.FORBIDDEN).build();
        }

        logger.info(createLoginMessage());

        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setUsername(loginRequest.getUsername());
        loginResponse.addRole(RoleUtils.INZICHT_USER_ROLE);

        return Response.ok(loginResponse).build();
    }

    @POST
    @Path("/logout")
    @Produces({MediaType.TEXT_PLAIN})
    public Response logout() throws ServletException {
        if (this.httpServletRequest.getUserPrincipal() != null) {
            logger.info(createLogoutMessage());
        }

        this.httpServletRequest.logout();
        return Response.ok("U bent uitgelogd").build();
    }

    public String createLoginMessage() {
        User user = this.userFactory.getUser();
        String username = user.getName();
        String roles = MessageUtils.createRoles(user);

        return MessageUtils.createMessage(MessageType.MESSAGE,
                "User '" + username + "' logged in, service = LoginService/login, roles = [" + roles + "].");
    }

    public String createLogoutMessage() {
        User user = this.userFactory.getUser();
        String username = user.getName();

        return MessageUtils.createMessage(MessageType.MESSAGE, "User '" + username + "' logged out, service = LoginService/logout.");
    }
}
