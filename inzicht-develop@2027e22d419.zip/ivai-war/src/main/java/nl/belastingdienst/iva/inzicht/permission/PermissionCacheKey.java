package nl.belastingdienst.iva.inzicht.permission;

import nl.belastingdienst.iva.inzicht.domain.DomainUtils;

public class PermissionCacheKey {

    private String permissionProvider;
    private String domainKey;
    private String userName;
    private String key;
    private String value;
    
    private long moment;
    private int hashCode;

    public PermissionCacheKey(String permissionProvider, String domainKey, String userName, String key, String value) {
        if (checkCacheKeyElements(permissionProvider, userName, key, value)) {
        	String message = "Permission-provider ('" + permissionProvider + "'), domain ('" + domainKey + "'), " + 
                    "username ('" + userName + "') and parameter-key ('" + key + "')/value ('" + value + "') are mandatory, " + 
        	        "these values cannot be null in the permission cache.";
            throw new NullPointerException(message);
        }

        this.permissionProvider = permissionProvider;
        this.domainKey = domainKey;
        this.userName = userName;
        this.key = key;
        this.value = value;

        this.moment = System.currentTimeMillis();
        this.hashCode = calculateHashCode(permissionProvider, domainKey, userName, key, value);
    }
    
    public long getMoment() {
        return this.moment;
    }
    
	@Override
    public int hashCode() {
        return this.hashCode;
    }
    
    @Override
    public boolean equals(Object otherObject) {
        if (this == otherObject) {
            return true;
        }
        
        if ((otherObject == null) || (this.getClass() != otherObject.getClass())) {
            return false;
        }
        
        return equals((PermissionCacheKey) otherObject);
    }
    
    public boolean equals(PermissionCacheKey otherPermissionCacheKey) {
        return otherPermissionCacheKey != null &&
                this.permissionProvider.equals(otherPermissionCacheKey.permissionProvider) &&
                (this.domainKey == null ? otherPermissionCacheKey.domainKey == null : this.domainKey.equals(otherPermissionCacheKey.domainKey)) && 
                this.userName.equals(otherPermissionCacheKey.userName) && 
                this.key.equals(otherPermissionCacheKey.key) && 
                this.value.equals(otherPermissionCacheKey.value);
    }
    
    private int calculateHashCode(String permissionProvider, String domainKey, String userName, String key, String value) {
        final int prime = 31;
        int result = 1;
        result = prime * result + permissionProvider.hashCode();
        result = prime * result + (domainKey == null ? 0 : domainKey.hashCode());
        result = prime * result + userName.hashCode();
        result = prime * result + key.hashCode();
        result = prime * result + value.hashCode();
        return result;
    }
    
    private boolean checkCacheKeyElements(String permissionProvider, String userName, String key, String value) {
    	return permissionProvider == null || key == null || value == null || 
    			userName == null || DomainUtils.UNKNOWN_ITEM.equals(userName) || DomainUtils.UNKNOWN_ITEM.equals(value);
    }
}
