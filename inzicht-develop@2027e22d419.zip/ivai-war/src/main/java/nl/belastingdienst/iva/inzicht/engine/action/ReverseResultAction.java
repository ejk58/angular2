package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class ReverseResultAction implements Action {

	public static final String NAME = "ReverseResult";

	@Override
	public Flow execute(RestCallContext restCallContext) {
		Result result = restCallContext.getResult();
		List<DataMap> data = new ArrayList<>();
		data.addAll(result.getData());
		Collections.reverse(data);
		result.setData(DomainUtils.inArray(data));
		restCallContext.setResult(result);
		
		return Flow.CONTINUE;
	}
	
	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + RulesEngineKey.PARAMETEREND;
	}
}
