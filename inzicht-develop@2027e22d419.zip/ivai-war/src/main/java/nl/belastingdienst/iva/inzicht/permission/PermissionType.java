package nl.belastingdienst.iva.inzicht.permission;

import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;

public enum PermissionType {
    ACCESS(ConfigurationKey.ACCESSPERMISSIONPROVIDER),
    RESULT(ConfigurationKey.RESULTPERMISSIONPROVIDER);
    
    String configurationKey;
    
    private PermissionType(String configurationKey) {
        this.configurationKey = configurationKey;
    }

    public String getConfigurationKey() {
        return this.configurationKey;
    }
}
