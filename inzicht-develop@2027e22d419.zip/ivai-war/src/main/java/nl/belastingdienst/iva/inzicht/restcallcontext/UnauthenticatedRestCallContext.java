package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.Collections;
import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.User;

public class UnauthenticatedRestCallContext extends EngineRestCallContext {

    public UnauthenticatedRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration, long beginTime) {
        super(serviceType, queryValues, configuration, beginTime);
    }

	@Override
	public User getUser() {
		return null;
	}

	@Override
	public List<DomainRole> getAuthorizedRoles() {
		return Collections.emptyList();
	}
}
