package nl.belastingdienst.iva.inzicht.configuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataRefreshInfoClient;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.GatewayTimeoutException;

public class RefreshInformationFactory {

    private static final Logger logger = LoggerFactory.getLogger(RefreshInformationFactory.class);

	@Inject
	private TeradataRefreshInfoClient teradataRefreshInfoClient;

	private Map<String, DataMap[]> refreshInformation;

	public RefreshInformationFactory() {
		this.refreshInformation = Collections.emptyMap();
	}

    public Map<String, DataMap[]> createRefreshInformation(Configuration configuration) {
    	try {
    		List<DataMap> refreshInformationData = retrieveRefreshInformation(configuration);
    		Map<String, List<DataMap>> refreshInformationMap = mapRefreshInformation(refreshInformationData);
    		Map<String, DataMap[]> newRefreshInformation = convertRefreshInformation(refreshInformationMap);
    		this.refreshInformation = newRefreshInformation;
        } catch (BadGatewayException | GatewayTimeoutException exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Refreshing the source refresh information throws a time-out exception " +
                    ExceptionUtils.getExceptionsForMessage(exception)));
    	} catch (Exception exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Refreshing the source refresh information throws an exception " +
                    ExceptionUtils.getExceptionsForMessage(exception)), exception);
    	}

    	return this.refreshInformation;
    }

    private List<DataMap> retrieveRefreshInformation(Configuration configuration) {
    	return this.teradataRefreshInfoClient.retrieveRefreshInfo(configuration);
    }

    private Map<String, List<DataMap>> mapRefreshInformation(List<DataMap> refreshInformationData) {
    	Map<String, List<DataMap>> refreshInformationMap = new HashMap<>();

    	for (DataMap refreshInformationWithView : refreshInformationData) {
    		String viewName = refreshInformationWithView.getAsString("viewName").trim().toLowerCase();
    	    List<DataMap> refreshInformationForViewName = getRefreshInformationForViewName(refreshInformationMap, viewName);
    	    DataMap refreshInformationElement = buildRefreshInformationElement(refreshInformationWithView);
    	    refreshInformationForViewName.add(refreshInformationElement);
    	    refreshInformationMap.put(viewName, refreshInformationForViewName);
    	}

    	return refreshInformationMap;
    }

    private Map<String, DataMap[]> convertRefreshInformation(Map<String, List<DataMap>> refreshInformationMap) {
    	Map<String, DataMap[]> newRefreshInformation = new HashMap<>();

    	for (Map.Entry<String, List<DataMap>>refreshInformationElement : refreshInformationMap.entrySet()) {
    		String viewName = refreshInformationElement.getKey();
    		List<DataMap> refreshInformationForViewName = getRefreshInformationForViewName(refreshInformationMap, viewName);
    		newRefreshInformation.put(viewName, refreshInformationForViewName.toArray(DomainUtils.emptyDataMapArray()));
    	}

    	return newRefreshInformation;
    }

    private List<DataMap> getRefreshInformationForViewName(Map<String, List<DataMap>> refreshInformationMap, String viewName) {
	    return refreshInformationMap.getOrDefault(viewName, new ArrayList<>());
    }

    private DataMap buildRefreshInformationElement(DataMap refreshInfoWithView) {
	    DataMap refreshInfoElement = new DataHashMap();

	    refreshInfoElement.put("source", refreshInfoWithView.getAsString("source"));
	    refreshInfoElement.put("refreshDate", refreshInfoWithView.get("refreshDate"));

	    return refreshInfoElement;
    }
}
