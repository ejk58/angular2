package nl.belastingdienst.iva.inzicht.configuration.attribute;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;

public class AttributeGroupParser {

	private Map<String, AttributeGroup> attributeGroupMap;
	
	public AttributeGroupParser(List<AttributeGroup> attributeGroupList) {
		this.attributeGroupMap = new HashMap<>();
		
		for (AttributeGroup attributeGroup : attributeGroupList) {
			this.attributeGroupMap.put(attributeGroup.getKey(), attributeGroup);
		}
	}
	
	public Map<String, AttributeGroup> getAttributeGroupMap() {
		return this.attributeGroupMap;
	}
}
