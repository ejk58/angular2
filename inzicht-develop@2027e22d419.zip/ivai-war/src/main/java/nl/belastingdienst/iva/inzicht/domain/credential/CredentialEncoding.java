package nl.belastingdienst.iva.inzicht.domain.credential;

import org.apache.commons.codec.binary.Base64;

public enum CredentialEncoding {

    PLAINTEXT("PLAINTEXT") {
        @Override
        public String encodeCredential(String credential) {
            return credential;
        }
    },
    BASE64("BASE64") {
        @Override
        public String encodeCredential(String credential) {
            byte[] credentialBytes = credential.getBytes();
            byte[] encodedBytes = Base64.encodeBase64(credentialBytes, false);
            return "Basic " + new String(encodedBytes);
        }
    };
    
    private String name;
    
    private CredentialEncoding(String name) {
        this.name = name;
    }
    
    public abstract String encodeCredential(String credential);
    
    public static CredentialEncoding findCredentialEncoding(String credentialEncodingName) {
        for (CredentialEncoding credentialEncoding : values()) {
            if (credentialEncoding.name.equals(credentialEncodingName)) {
                return credentialEncoding;
            }
        }
        
        return null;
    }
}
