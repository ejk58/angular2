package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.engine.RuleInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class ApplyRulesAction implements Action {

	public static final String NAME = "ApplyRules";
	
	private String ruleGroupName;
	
	public ApplyRulesAction(String ruleGroupName) {
		this.ruleGroupName = ruleGroupName;
	}

	@Override
	public Flow execute(RestCallContext restCallContext) {
		RuleInterface rule = getRule(restCallContext.getConfiguration());
		Flow flow = rule.apply(restCallContext);
		return flow == Flow.QUIT ? Flow.QUIT : Flow.CONTINUE;
	}
	
	private RuleInterface getRule(Configuration configuration) {
		RuleGroup ruleGroup = configuration.getRuleGroup(this.ruleGroupName);
		return ruleGroup.getRule();
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.ruleGroupName + RulesEngineKey.PARAMETEREND;
	}
}
