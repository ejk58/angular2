package nl.belastingdienst.iva.inzicht.domain;

import javax.xml.stream.Location;

public class XmlMapperException extends Exception {

    private static final long serialVersionUID = 1L;

    private int lineNumber;
    private int columnNumber;
    private int characterOffset;
    
    public XmlMapperException(String message) {
        super(message);
    }
    
    public XmlMapperException(String message, Location location) {
        this(message);
        this.lineNumber = location.getLineNumber();
        this.columnNumber = location.getColumnNumber();
        this.characterOffset = location.getCharacterOffset();
    }

    public int getLineNumber() {
        return this.lineNumber;
    }

    public int getColumnNumber() {
        return this.columnNumber;
    }

    public int getCharacterOffset() {
        return this.characterOffset;
    }
}
