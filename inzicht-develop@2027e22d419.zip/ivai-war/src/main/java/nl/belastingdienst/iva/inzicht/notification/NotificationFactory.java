package nl.belastingdienst.iva.inzicht.notification;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.inzicht.database.notification.Notification;
import nl.belastingdienst.iva.inzicht.database.notification.NotificationDao;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class NotificationFactory {

    private static final Logger logger = LoggerFactory.getLogger(NotificationFactory.class);

    @Inject
    private NotificationDao notificationDao;

	@Inject
	private NotificationComparator notificationComparator;

	private List<Notification> notifications;

	public NotificationFactory() {
		createEmptyNotifications();
	}

    @PostConstruct
    public void initialize() {
        loadNewNotifications();
    }

    @Schedule(minute = "*/2", hour = "*", persistent = false)
    public void update() {
    	loadNewNotifications();
    }

    public List<Notification> getNotifications() {
        return this.notifications;
    }

    public List<Notification> filterNotifications(String domainKey, String pageKey) {
        return notifications.stream()
        		.filter(notification -> domainKey == null || domainKey.equals(notification.getDomainKey()))
        		.filter(notification -> pageKey == null || pageKey.equals(notification.getPageKey()))
        		.sorted(this.notificationComparator)
        		.collect(Collectors.toList());
    }

    public DataMap getStatus() {
        return createStatus();
    }

    private void createEmptyNotifications() {
    	this.notifications = Collections.emptyList();
    }

    private void loadNewNotifications() {
        logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Starting the update of the notifications cache."));
        long startTime = System.currentTimeMillis();

    	try {
    		this.notifications = this.notificationDao.getNotificationMessages();

            logger.info(MessageUtils.createMessage(MessageType.MESSAGE, "Updated the notification cache in " +
                    MessageUtils.createDuration(System.currentTimeMillis() - startTime)));
    	} catch (Exception exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Refreshing the notifications throws an exception " +
                    ExceptionUtils.getExceptionsForMessage(exception)), exception);
    	}
    }

    private DataMap createStatus() {
        DataMap status = new DataHashMap();

        status.put(ResponseKey.CACHESIZE, this.notifications.size());

        return status;
    }
}
