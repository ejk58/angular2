package nl.belastingdienst.iva.inzicht.engine;

public enum Flow {
	CONTINUE("CONTINUE"),
	BREAK("BREAK"),
	QUIT("QUIT");

	private String name;
	
	private Flow(String name) {
		this.name= name;
	}

	public String getName() {
		return this.name();
	}
	
	public static Flow findFlow(String flowName) {
		for (Flow flow : values()) {
			if (flow.name.equals(flowName)) {
				return flow;
			}
		}
		
		return null;
	}
	
	public static Flow getNextFlow(Flow flow, Flow otherFlow) {
		if (flow == Flow.QUIT || otherFlow == Flow.QUIT) {
			return Flow.QUIT;
		} else if (flow == Flow.BREAK || otherFlow == Flow.BREAK) {
			return Flow.BREAK;
		}
		
		return Flow.CONTINUE;
	}
}
