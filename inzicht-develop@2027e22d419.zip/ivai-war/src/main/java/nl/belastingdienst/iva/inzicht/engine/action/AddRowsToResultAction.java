package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class AddRowsToResultAction implements Action {

	public static final String NAME = "AddRowsToResult";

	private String rows;
	private DataMap[] resultRows;
	
	public AddRowsToResultAction(String rows, DataMap[] resultRows) {
		this.rows = rows;
		this.resultRows = resultRows;
	}
	
	@Override
	public Flow execute(RestCallContext restCallContext) {
		restCallContext.addRowsToResult(buildRows());
		return Flow.CONTINUE;
	}
	
	private DataMap[] buildRows() {
		DataMap[] newRows = new DataMap[this.resultRows.length];
		
		for (int index = 0; index < this.resultRows.length; index++) {
			newRows[index] = new DataHashMap(this.resultRows[index]);
		}
		
		return newRows;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.rows + RulesEngineKey.PARAMETEREND;
	}
}
