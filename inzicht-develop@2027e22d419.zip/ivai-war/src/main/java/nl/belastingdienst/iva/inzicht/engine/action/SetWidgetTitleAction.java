package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

public class SetWidgetTitleAction implements Action {

	public static final String NAME = "SetWidgetTitle";

	private String title;

	public SetWidgetTitleAction(String title) {
		this.title = title;
	}

	@Override
	public Flow execute(RestCallContext restCallContext) {
	    Object widgetResponse = restCallContext.getResponse();

	    if (widgetResponse instanceof DataMap) {
	        DataMap widgetMap = (DataMap) widgetResponse;
	        Object optionsResponse = widgetMap.get(ResponseKey.OPTIONS);

	        if (optionsResponse instanceof DataMap) {
	            DataMap optionsMap = (DataMap) optionsResponse;
	            optionsMap.put(ResponseKey.TITLE, this.title);
	        }
	    }

		return Flow.CONTINUE;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.title + RulesEngineKey.PARAMETEREND;
	}
}
