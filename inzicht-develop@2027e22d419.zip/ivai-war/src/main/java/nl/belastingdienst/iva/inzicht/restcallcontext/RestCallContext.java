package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.dataprovider.Result;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.User;

public interface RestCallContext {

	RestServiceType getServiceType();
	String getServiceName();
	MultivaluedMap<String, String> getQueryValues();
	Configuration getConfiguration();
	User getUser();
	List<DomainRole> getAuthorizedRoles();

	QueryInterface getQuery();
	Result getResult();
	Object getResponse();

    long getBeginTime();
    long getElapsedTime();
    String getFirstQueryValue(String key);
    String getUserName();
    List<DataMap> getData();

    void setQuery(QueryInterface query);
	void setResult(Result result);
	void setResponse(Object response);
	
    void addQueryValue(String key, String value);
    void addRowsToResult(DataMap[] resultRows);
    
    String getDomainKey();
    String getPageKey();
    String getWidgetKey();
    
    boolean hasDomainPathKeys();
    boolean hasMandatoryPathKeys();

    Domain findDomain();
    Page findPage();
    Widget findWidget();
}
