package nl.belastingdienst.iva.inzicht.domain.releasenote;

import java.util.Date;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;

public class ReleaseNote {

	private static final String ALLDOMAINS = "Algemeen";

	private Date releaseDate;
	private String version;
	private Domain domain;
	private String type;
	private String description;
	
	public ReleaseNote(Date releaseDate, String version, Domain domain, String type, String description) {
		this.releaseDate = releaseDate;
		this.version = version;
		this.domain = domain;
		this.type = type;
		this.description = description;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}
	
	public String getVersion() {
		return version;
	}
	
	public String getDomainKey() {
		return domain == null ? null : domain.getKey();
	}
	
	public String getDomainName() {
		return domain == null ? ALLDOMAINS : domain.getName();
	}
	
	public Integer getDomainIndex() {
		return domain == null ? null : domain.getIndex();
	}
	
	public String getType() {
		return type;
	}
	
	public String getDescription() {
		return description;
	}
}
