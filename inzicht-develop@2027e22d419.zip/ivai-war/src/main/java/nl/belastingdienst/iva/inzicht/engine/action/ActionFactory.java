package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.JsonMapper;
import nl.belastingdienst.iva.inzicht.domain.widget.WidgetMapper;
import nl.belastingdienst.iva.inzicht.engine.AbstractRuleFactory;

public class ActionFactory extends AbstractRuleFactory<Action> {

	private Map<String, Function<List<String>, Action>> actionBuilderMap;
	
    @Inject
    private DataProvider dataProvider;
    
	@Inject
	private JsonMapper jsonMapper;

    @Inject
    private WidgetMapper widgetMapper;

	public ActionFactory() {
		initialize();
	}
	
	public Action getAction(List<Action> actionList) {
		if (actionList == null || actionList.isEmpty()) {
			throw new IllegalArgumentException("The list of actions for a multiple-action cannot be empty in the action-factory.");
		}
		
		return new MultipleAction(actionList);
	}

	public Action getAction(String description) {
		return super.get(description);
	}
	
	@Override
	protected Action build(String name, List<String> parameters) {
		Function<List<String>, Action> actionBuilder = this.actionBuilderMap.get(name);
		
		if (actionBuilder == null) {
			throw new IllegalArgumentException("The action '" + name + "' is unrecognized in the action-factory.");
		}
		
		return actionBuilder.apply(parameters);
	}
	
	private void initialize() {
		this.actionBuilderMap = new HashMap<>();
		
		this.actionBuilderMap.put(ApplyRulesAction.NAME, (List<String> parameters) -> { 
			String ruleName = getParameter(parameters, 0); 
			return new ApplyRulesAction(ruleName);
		});
		
        this.actionBuilderMap.put(AddFilterToQueryAction.NAME, (List<String> parameters) -> { 
            String filter = getParameter(parameters, 0);
            return new AddFilterToQueryAction(filter);
        });

		this.actionBuilderMap.put(AddQueryValueAction.NAME, (List<String> parameters) -> { 
			String key = getParameter(parameters, 0);
			String value = parameters.size() < 2 ? null : getParameter(parameters, 1);
			return new AddQueryValueAction(key, value);
		});

		this.actionBuilderMap.put(AddRowsToResultAction.NAME, (List<String> parameters) -> { 
			String rows = getParameter(parameters, 0);
			DataMap[] resultRows = this.jsonMapper.mapToDataMapArray("AddRowsToResult-action rows", rows);
			return new AddRowsToResultAction(rows, resultRows);
		});

		this.actionBuilderMap.put(DoNothingAction.NAME, (List<String> parameters) -> new DoNothingAction());

        this.actionBuilderMap.put(ExecuteQueryAction.NAME, (List<String> parameters) -> new ExecuteQueryAction(this.dataProvider));

		this.actionBuilderMap.put(ExecuteWidgetQueryAction.NAME, (List<String> parameters) -> new ExecuteWidgetQueryAction(this.dataProvider));

		this.actionBuilderMap.put(FlowAction.NAME, (List<String> parameters) -> { 
			String flowName = getParameter(parameters, 0);
			return new FlowAction(flowName);
		});
		
        this.actionBuilderMap.put(LoadWidgetQueryAction.NAME, (List<String> parameters) -> new LoadWidgetQueryAction());

        this.actionBuilderMap.put(MapWidgetAction.NAME, (List<String> parameters) -> new MapWidgetAction(this.widgetMapper));

        this.actionBuilderMap.put(RemoveNoValueDetailPageAction.NAME, (List<String> parameters) -> {
			String resultColumnDescription = getParameter(parameters, 0);
			List<String> resultColumn = Arrays.asList(resultColumnDescription.split("/"));
			return new RemoveNoValueDetailPageAction(resultColumn);
		});
        
		this.actionBuilderMap.put(ReverseResultAction.NAME, (List<String> parameters) -> new ReverseResultAction());

		this.actionBuilderMap.put(FilterResultAction.NAME, (List<String> parameters) -> {
			String resultColumnDescription = getParameter(parameters, 0);
			String operator = getParameter(parameters, 1);
			String value = getParameter(parameters, 2);
			List<String> resultColumn = Arrays.asList(resultColumnDescription.split("/"));
			return new FilterResultAction(resultColumn, operator, value);
		});
		
        this.actionBuilderMap.put(SetWidgetAttributeAction.NAME, (List<String> parameters) -> { 
            String key = getParameter(parameters, 0);
            String value = parameters.size() < 2 ? null : getParameter(parameters, 1);
            return new SetWidgetAttributeAction(key, value);
        });

        this.actionBuilderMap.put(SetWidgetDescriptionAction.NAME, (List<String> parameters) -> { 
            String description = getParameter(parameters, 0);
            return new SetWidgetDescriptionAction(description);
        });

        this.actionBuilderMap.put(SetWidgetTitleAction.NAME, (List<String> parameters) -> { 
            String title = getParameter(parameters, 0);
            return new SetWidgetTitleAction(title);
        });

        this.actionBuilderMap.put(SortResultByNumberColumnAction.NAME, (List<String> parameters) -> {
			String resultColumnDescription = getParameter(parameters, 0);
			List<String> resultColumn = Arrays.asList(resultColumnDescription.split("/"));
			return new SortResultByNumberColumnAction(resultColumn);
		});
		
		this.actionBuilderMap.put(ThrowExceptionAction.NAME, (List<String> parameters) -> { 
			String exceptionName = getParameter(parameters, 0);
			String message = getParameter(parameters, 1);
			return new ThrowExceptionAction(exceptionName, message);
		});
	}
}
