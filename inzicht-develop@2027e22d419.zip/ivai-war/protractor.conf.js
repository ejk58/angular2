const { join } = require('path');
const { removeSync } = require('fs-extra');
const { blue } = require('chalk');
const SpecReporter = require('jasmine-spec-reporter').SpecReporter;
const HtmlReporter2 = require('protractor-beautiful-reporter');

// Disable SSL authentication. This is needed to run test(s) on openshift 4.3 with Selenium Grid.
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

exports.config = {
    baseUrl: 'https://inzicht.str11.ont.belastingdienst.nl/inzicht/#/login',
    disableChecks: true,
    framework: 'jasmine2',
    jasmineNodeOpts: {
        showColors: true,
        defaultTimeoutInterval: 180000,
        isVerbose: true,
        includeStackTrace: true,
        print: function () {
        }
    },
    SELENIUM_PROMISE_MANAGER: false,
    specs: [
        './src/test/e2e/**/*.e2e-spec.ts'
    ],
    multiCapabilities: [
        {
            browserName: 'chrome',
            logName: 'chrome-latest',
            'goog:chromeOptions': {
                'w3c': false,
                args: ["--headless", "--disable-gpu", "--disable-infobars", "--disable-extensions", "--ignore-certificate-errors", "--no-sandbox", "--disable-dev-shm-usage"],
            },
            // Allow different spec-files to run in parallel.
            shardTestFiles: true,
            // Maximum number of browser instances that can run in parallel
            maxInstances: 12
        }
    ],
    // OpenShift Selenium Grid Server
    seleniumAddress: 'https://selenium-hub-wd-selenium-grid.apps.cn01.chp.belastingdienst.nl/wd/hub',

    /**
     * A callback function called once configs are read but before any
     * environment setup. This will only run once, and before onPrepare.
     * */
    beforeLaunch: function () {
        const tmpReports = join(process.cwd(), './src/test/e2e/reports/e2e-tests');
        const tmpImages = join(process.cwd(), './src/test/e2e/reports/.tmp');

        console.log(blue('\n################################################################################'));
        console.log(blue('Removing the '+ tmpReports +' folder.'));
        console.log(blue('Removing the '+ tmpImages +' folder.'));
        console.log(blue('################################################################################\n'));

        removeSync(tmpReports);
        removeSync(tmpImages);
    },

    /**
     * A callback function called once protractor is ready and available, and
     * before the specs are executed. If multiple capabilities are being run,
     * this will run once per capability.
     */
    onPrepare: function () {
        require('ts-node').register({
            project: './src/test/e2e/tsconfig.e2e.json'
        });

        jasmine.getEnv().addReporter(new SpecReporter({
            spec: {
                displayStacktrace: 'raw',
                displayFailuresSummary: false,
                displayPendingSummary: false,
                displayPendingSpec: true,
                displaySpecDuration: true
            }
        }));

        jasmine.getEnv().addReporter(new HtmlReporter2({
            baseDirectory: './src/test/e2e/reports/e2e-tests/',
            docTitle: 'Inzicht V2 E2E test report'
        }).getJasmine2Reporter());

        //image-comparison config
        const protractorImageComparison = require('protractor-image-comparison');
        browser.protractorImageComparison = new protractorImageComparison({
            baselineFolder: './src/test/e2e/baseline/',
            screenshotPath: './src/test/e2e/reports/.tmp/',
            autoSaveBaseline: true,
            ignoreTransparentPixel: true,
            disableCSSAnimation: true,
            hideScrollBars: false
        });

        // const processedConfig = browser.getProcessedConfig();
        // browser.browserName = processedConfig.capabilities.browserName.toLowerCase();
        // browser.logName = processedConfig.capabilities.logName;
        //
        // if (!('platformName' in processedConfig.capabilities)) {
            browser.driver.manage().window().setSize(1366, 768);
        // }
    },

    /**
     * A callback function called once tests are finished. onComplete can
     * optionally return a promise, which Protractor will wait for before
     * shutting down webdriver.
     */
    onComplete: function () {
        browser.driver.close();
        browser.driver.quit();
    }
}