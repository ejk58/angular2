@Library("GENERIC") _
    pipelineDeployArtifactFromNexus {
	deploymentId = "inzicht"
	integrationPipeline = "inzicht-test"
	packageChoices = "inzicht"
	applicationVersionChoices = "3.82.0\n3.81.0\n3.80.0\n3.79.0\n3.78.0"
	asVersionChoices = "n.v.t"
	environmentChoices = "tst\nont\nacc\nprd"
	streetChoices = "str11/productie\nstr12/opleiding\nstr13\nstr14"
}
