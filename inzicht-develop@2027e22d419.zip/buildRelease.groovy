@Library("GENERIC") _
    pipelineRelease {
	deploymentId = "inzicht"
	deployPipeline = "inzicht_deploy_release"
	integrationPipeline = "inzicht-test"
	environmentChoices = "ont\ntst\nacc"
	streetChoices = "str11\nstr12\nstr13\nstr14"
}
