DROP TABLE DG_I_P_40ANA_INZ.p_inz_relaties_historie;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_relaties_historie,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   ingangsjaar SMALLINT,
   vervaljaar SMALLINT,
   relatiesoort_bes VARCHAR(60) CHARACTER SET UNICODE CASESPECIFIC,
   ingang_d DATE FORMAT 'YY/MM/DD',
   verval_d DATE FORMAT 'YY/MM/DD',
   finr_relatie INTEGER,
   naam_relatie VARCHAR(512) CHARACTER SET UNICODE CASESPECIFIC,
   overlijden_partner_ind BYTEINT,
   relatieisvip_ind BYTEINT,
   naamswijzigingen VARCHAR(2000) CHARACTER SET UNICODE CASESPECIFIC COMPRESS,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
