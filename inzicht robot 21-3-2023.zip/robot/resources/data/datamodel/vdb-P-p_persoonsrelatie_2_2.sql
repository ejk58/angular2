REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_persoonsrelatie_2_2
  (
  IN finr VARCHAR(64),
  IN periode_begin_d DATE,
  IN periode_eind_d DATE
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL *
      FROM DG_I_P_40ANA_INZ.v_persoonsrelatie_2
      WHERE finr = :finr
        AND periode_begin_d = COALESCE(:periode_begin_d,CURRENT_DATE)
        AND periode_eind_d = COALESCE(:periode_eind_d,CURRENT_DATE)
        AND bron_doel_relsrt_id = 0
      ORDER BY finr_bron_relsrt_beschrijving,
        begin_d DESC;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_persoonsrelatie_2_2 TO PUBLIC;
