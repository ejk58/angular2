REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_6',), ("
  (
  IN finr VARCHAR(11)
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL CASE WHEN is_openstaand_ind = 1 THEN 'Ja' ELSE 'Nee' END AS openstaande_vordering_label,
    is_openstaand_ind AS openstaande_vordering_value,
    COUNT(openstaande_vordering_label) AS openstaande_vordering_count
      FROM DG_I_P_40ANA_INZ.v_vordering_1
      WHERE finr = :finr
      GROUP BY openstaande_vordering_label, openstaande_vordering_value
      ORDER BY openstaande_vordering_label;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_6 TO PUBLIC;
