REPLACE VIEW DG_I_P_40ANA_INZ.v_vordering_gebeurtenis_1_1 AS
   SELECT
     t_vordering_bedragsmutatie.vordering_id,
     t_vordering_bedragsmutatie.finr,
     'Bedragsmutatie: ' || t_vordering_bedragsmutatie.bedragsmutatiesoort_oms AS "omschrijving",
     t_vordering_bedragsmutatie.belasting_open_eur + t_vordering_bedragsmutatie.boete_open_eur +
     t_vordering_bedragsmutatie.revisierente_open_eur + t_vordering_bedragsmutatie.heffingsrente_open_eur AS "open_bedrag_eur",
     t_vordering_bedragsmutatie.invorderingsrente_open_eur AS "open_rente_eur",
     t_vordering_bedragsmutatie.invorderingskosten_open_eur AS "open_kosten_eur",
     open_bedrag_eur + open_rente_eur + open_kosten_eur AS "open_saldo_eur",
     t_vordering_bedragsmutatie.belasting_mutatie_eur +t_vordering_bedragsmutatie.boete_mutatie_eur +t_vordering_bedragsmutatie.revisierente_mutatie_eur
     +t_vordering_bedragsmutatie.heffingsrente_mutatie_eur +t_vordering_bedragsmutatie.invorderingskosten_mutatie_eur 
     +t_vordering_bedragsmutatie.invorderingsrente_mutatie_eur AS "bedrag_eur",
     substring(CASE WHEN t_vordering_bedragsmutatie.belasting_mutatie_eur <> 0 THEN '<br>Belasting: ?' || cast(t_vordering_bedragsmutatie.belasting_mutatie_eur AS varchar(50)) ELSE '' END || 
     
     CASE WHEN t_vordering_bedragsmutatie.boete_mutatie_eur <> 0 THEN 
     '<br>Boete: ?' || cast (t_vordering_bedragsmutatie.boete_mutatie_eur AS varchar(50)) ELSE '' END || 
     
     CASE WHEN t_vordering_bedragsmutatie.revisierente_mutatie_eur <> 0 THEN 
     '<br>Revisierente: ?' || cast (t_vordering_bedragsmutatie.revisierente_mutatie_eur AS varchar(50)) ELSE '' END || 
     
     CASE WHEN t_vordering_bedragsmutatie.heffingsrente_mutatie_eur <> 0 THEN 
     '<br>Heffingsrente: ?' ||cast(t_vordering_bedragsmutatie.heffingsrente_mutatie_eur AS varchar(50)) ELSE '' END || 
     
     CASE WHEN t_vordering_bedragsmutatie.invorderingskosten_mutatie_eur <> 0 THEN 
     '<br>Kosten: ?' || cast(t_vordering_bedragsmutatie.invorderingskosten_mutatie_eur AS varchar(50)) ELSE '' END || 
     
     CASE WHEN t_vordering_bedragsmutatie.invorderingsrente_mutatie_eur <> 0 THEN 
     '<br>Invorderingsrente: ?' || cast(t_vordering_bedragsmutatie.invorderingsrente_mutatie_eur AS varchar(50)) ELSE '' END,5) AS "uitgesplitst_bedrag",
     t_vordering_bedragsmutatie.rekeningnr_klant,
     t_vordering_bedragsmutatie.rekeningnr_belastingdienst,
     t_vordering_bedragsmutatie.verrekend_met_vordering AS "vorderingnr_verr_met",
     null AS "automatisch_betalen_ind",
     t_vordering_bedragsmutatie.afb_soort_subcode AS "subcode",
     t_vordering_bedragsmutatie.subcode_oms,
     t_vordering_bedragsmutatie.valuta_d,
     t_vordering_bedragsmutatie.volgordenr,
     CASE WHEN t_vordering_bedragsmutatie.belasting_open_eur = 0 
     AND t_vordering_bedragsmutatie.boete_open_eur = 0 
     AND t_vordering_bedragsmutatie.revisierente_open_eur = 0 
     AND t_vordering_bedragsmutatie.heffingsrente_open_eur = 0 
     AND t_vordering_bedragsmutatie.invorderingskosten_open_eur = 0 
     AND t_vordering_bedragsmutatie.invorderingsrente_open_eur = 0 
     THEN cast(1 AS byteint) 
     ELSE cast(0 AS byteint) 
     END AS "volledig_afgeboekt_ind",
     cast(t_vordering_bedragsmutatie.bedragsmutatie_dt AS date) AS "gebeurtenis_d",
     t_vordering_bedragsmutatie.bedragsmutatie_dt AS "gebeurtenis_dt"
   FROM
     DG_I_P_40ANA_INZ.T_VORDERING_BEDRAGSMUTATIE AS t_vordering_bedragsmutatie; 
