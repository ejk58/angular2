REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_inz_entiteit_proc(IN entitynr INTEGER)
  dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for
  SEL segment, klantcoordinator, kantoor FROM DG_I_P_50PRO_INZ.p_inz_entiteit WHERE entiteitnr = :entitynr;
open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_inz_entiteit_proc TO PUBLIC;
