CREATE JOIN INDEX DG_I_P_40ANA_INZ.t_persoonsadres_ji_adres_id,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_persoonsadres.ROWID,DG_I_P_40ANA_INZ.t_persoonsadres.adres_id 
 FROM DG_I_P_40ANA_INZ.t_persoonsadres 
PRIMARY INDEX (adres_id); 
