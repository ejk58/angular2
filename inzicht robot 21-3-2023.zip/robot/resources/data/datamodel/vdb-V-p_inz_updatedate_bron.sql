/****************************************************
Copy Object Script for VIEW: p_inz_updatedate_bron
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_updatedate_bron AS 
SELECT t1.id, t1.codeblok AS "viewname", t1.bron, t1.verversdatum,
 t1.created_dt 
FROM DG_I_P_40ANA_INZ.M_INZ_UPDATEDATE_BRON AS t1; 
