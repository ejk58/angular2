DROP TABLE DG_I_P_40ANA_INZ.p_inz_invord_motorrtg;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_invord_motorrtg,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   aantal_objecten INTEGER,
   waarde_eur DECIMAL(18,0),
   waarde_partner_eur DECIMAL(18,0),
   verhaalswaarde_totaal_eur DECIMAL(18,0),
   verhaalswaarde_bp_eur DECIMAL(18,0),
   verhaalswaarde_partner_eur DECIMAL(18,0),
   executiewaarde_eur DECIMAL(18,0),
   aantal_met_verplichting INTEGER,
   executiewaarde_met_vpln_eur DECIMAL(18,0),
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
