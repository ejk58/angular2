REPLACE VIEW DG_I_P_40ANA_INZ.v_fiscale_afspraak_geb_1_5 AS
  SELECT t_fiscale_afspraak.finr,
    t_fiscale_afspraak.vermoedelijke_schenking_d,
    t_fiscale_afspraak.finr_schenker,
    t_fiscale_afspraak.behandelaar_user_id,
    t_fiscale_afspraak.reden_muteren,
    v_fiscale_afspraak_geb_1_4."gebeurtenis_type" AS "laatste_actie",
    100 * DENSE_RANK() OVER (PARTITION BY t_fiscale_afspraak.finr
    ORDER BY t_fiscale_afspraak.vermoedelijke_schenking_d,
      t_fiscale_afspraak.fiscale_afspraak_id DESC) AS "volgorde",
      1 AS "niveau",
      CAST(NULL AS INT) AS "parent",
      CAST(NULL AS DATE) AS "gebeurtenis_d",
      CAST(NULL AS VARCHAR(50)) AS "gebeurtenis_type",
      CAST(NULL AS DATE) AS "verval_d",
      CAST(NULL AS VARCHAR(256)) AS "details",
      CAST(NULL AS BYTEINT) AS "status_einde",
      CAST(NULL AS BYTEINT) AS "laatste_stand_ind",
      CAST(NULL AS VARCHAR(50)) AS "tooltip"
    FROM DG_I_P_40ANA_INZ.T_FISCALE_AFSPRAAK AS t_fiscale_afspraak LEFT JOIN DG_I_P_40ANA_INZ."v_fiscale_afspraak_geb_1_4" AS v_fiscale_afspraak_geb_1_4 ON (t_fiscale_afspraak.fiscale_afspraak_id = v_fiscale_afspraak_geb_1_4."fiscale_afspraak_id" AND t_fiscale_afspraak.finr = v_fiscale_afspraak_geb_1_4."finr" AND v_fiscale_afspraak_geb_1_4."laatste_stand_ind" = 1) 
