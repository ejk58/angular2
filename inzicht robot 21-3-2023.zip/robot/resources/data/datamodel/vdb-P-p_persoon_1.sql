REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_persoon_1
(
IN finr varchar(11)
)
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for

SEL *
FROM DG_I_P_40ANA_INZ.t_persoon
WHERE finr = :finr;

open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_persoon_1 TO PUBLIC;
