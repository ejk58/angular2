/****************************************************
Copy Object Script for VIEW: P_INZ_OV
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.P_INZ_OV AS LOCKING ROW FOR ACCESS (
 SELECT * 
 FROM DG_I_P_40ANA_INZ.P_INZ_OV
); 
