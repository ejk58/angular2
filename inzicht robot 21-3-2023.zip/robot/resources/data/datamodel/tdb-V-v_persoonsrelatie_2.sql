REPLACE VIEW DG_I_P_40ANA_INZ.v_persoonsrelatie_2 AS
  SELECT DISTINCT eerste.bronpersoon_id AS "finr",
    vierde.doelpersoon_id AS "bron_bsn",
    100 AS "bron_icoontype",
    
    CASE
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 0 AND vierde.relatiesoort_id = 0 THEN 'Reflexief'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 0 AND vierde.relatiesoort_id = 1 THEN 'Ouder'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 0 AND vierde.relatiesoort_id IN (2, 502) THEN 'Partner'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 0 AND vierde.relatiesoort_id = 501 THEN 'Kind'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 1 AND vierde.relatiesoort_id = 1 THEN 'Grootouder van'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 1 AND vierde.relatiesoort_id = 501 AND derde.bronpersoon_id <> vierde.doelpersoon_id THEN 'Broer/zus'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 501 AND vierde.relatiesoort_id = 501 THEN 'Kleinkind'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 1 AND derde.relatiesoort_id = 501 AND vierde.relatiesoort_id = 501 AND tweede.bronpersoon_id <> derde.doelpersoon_id THEN 'Neef/nicht'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 1 AND derde.relatiesoort_id = 1 AND vierde.relatiesoort_id = 501 AND tweede.doelpersoon_id <> vierde.doelpersoon_id THEN 'Oom/tante'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 501 AND derde.relatiesoort_id = 501 AND vierde.relatiesoort_id = 501 THEN 'Achterkleinkind'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 1 AND derde.relatiesoort_id = 1 AND vierde.relatiesoort_id = 1 THEN 'Overgrootouder'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 501 AND vierde.relatiesoort_id IN (2, 502) THEN 'Partner van kind'
      WHEN eerste.relatiesoort_id IN (2, 502) AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 0 AND vierde.relatiesoort_id = 1 THEN 'Ouder van partner'
      WHEN eerste.relatiesoort_id IN (2, 502) AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 1 AND vierde.relatiesoort_id = 501 AND eerste.doelpersoon_id <> vierde.doelpersoon_id THEN 'Broer/zus van partner'
      WHEN eerste.relatiesoort_id IN (2, 502) AND tweede.relatiesoort_id = 1 AND derde.relatiesoort_id = 501 AND vierde.relatiesoort_id = 501 AND eerste.doelpersoon_id <>vierde.bronpersoon_id THEN 'Neef/nicht van partner'
      WHEN eerste.relatiesoort_id IN (2, 502) AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 1 AND vierde.relatiesoort_id = 1 THEN 'Grootouder van partner'
      WHEN eerste.relatiesoort_id IN (2, 502) AND tweede.relatiesoort_id = 1 AND derde.relatiesoort_id = 1 AND vierde.relatiesoort_id = 1 THEN 'Overgrootouder van partner'
      WHEN eerste.relatiesoort_id =0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 0 AND vierde.relatiesoort_id = 5021 THEN 'Kind van partner'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 0 AND derde.relatiesoort_id = 5021 AND vierde.relatiesoort_id = 501 THEN 'Kleinkind van partner'
      WHEN eerste.relatiesoort_id = 0 AND tweede.relatiesoort_id = 5021 AND derde.relatiesoort_id = 501 AND vierde.relatiesoort_id = 501 THEN 'Achterkleinkind van partner' ELSE NULL
    END AS "finr_bron_relsrt_beschrijving",
      greatest(eerste.bestaat_van_d, vierde.bestaat_van_d) AS "begin_d",
      least(eerste.bestaat_tot_d, vierde.bestaat_tot_d) AS "eind_d",
      begin_d."datum" AS "periode_begin_d",
      eind_d."datum" AS "periode_eind_d",
      t_persoon.naam AS "bron_naam",
      (CAST(COALESCE(t_persoon.bestaat_tot_d,CURRENT_DATE) AS INTEGER) - CAST(t_persoon.bestaat_van_d AS INTEGER))/10000 AS "bron_leeftijd",
      
    CASE
      WHEN t_persoon.bestaat_tot_d IS NULL THEN 0 ELSE 1
    END AS "bron_is_overleden_ind",
      t_persoon.is_afgeschermd_ind AS "bron_is_afgeschermd_ind",
      bron_doel.doelpersoon_id AS "doel_bsn",
      bron_doel.relatiesoort_id AS "bron_doel_relsrt_id"
    FROM DG_I_P_40ANA_INZ."t_datum" AS begin_d INNER JOIN DG_I_P_40ANA_INZ."t_datum" AS eind_d ON (eind_d."datum" >= begin_d."datum") INNER JOIN DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS eerste ON (eerste.bestaat_van_d < eind_d."datum" AND eerste.bestaat_tot_d > begin_d."datum") INNER JOIN DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS tweede ON (eerste.doelpersoon_id = tweede.bronpersoon_id AND eerste.relatiesoort_id IN (0, 1, 2, 502, 501) AND tweede.relatiesoort_id IN (0, 1, 2, 502, 501, 5021) AND tweede.bestaat_van_d < eind_d."datum" AND tweede.bestaat_tot_d > begin_d."datum") INNER JOIN DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS derde ON (tweede.doelpersoon_id = derde.bronpersoon_id AND derde.relatiesoort_id IN (0, 1, 2, 502, 501,5021) AND derde.bestaat_van_d < eind_d."datum" AND derde.bestaat_tot_d > begin_d."datum") INNER JOIN DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS vierde ON (derde.doelpersoon_id = vierde.bronpersoon_id AND vierde.relatiesoort_id IN (0, 1, 2, 502, 501, 5021) AND vierde.bestaat_van_d < eind_d."datum" AND vierde.bestaat_tot_d > begin_d."datum") INNER JOIN DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS bron_doel ON (vierde.doelpersoon_id = bron_doel.bronpersoon_id AND bron_doel.relatiesoort_id IN (0, 501,2, 502)) INNER JOIN DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon ON (vierde.doelpersoon_id = t_persoon.finr)
    WHERE "finr_bron_relsrt_beschrijving" IS NOT NULL 
