REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_1_5 AS 
SELECT v_vpb_aangifte_bewering_1_4."finr", v_vpb_aangifte_bewering_1_4."rsin_aangegevene",
 max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 1 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_1", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 1 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_1", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 1 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_1", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 1 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_1", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 2 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_2", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 2 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_2", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 2 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_2", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 2 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_2", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 3 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_3", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 3 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_3", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 3 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_3", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 3 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_3", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 4 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_4", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 4 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_4", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 4 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_4", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 4 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_4", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 5 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_5", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 5 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_5", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 5 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_5", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 5 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_5", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 6 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_6", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 6 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_6", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 6 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_6", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 6 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_6", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 7 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_7", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 7 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_7", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 7 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_7", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 7 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_7", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 8 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_8", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 8 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_8", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 8 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_8", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 8 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_8", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 9 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_9", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 9 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_9", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 9 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_9", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 9 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_9", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 10 THEN v_vpb_aangifte_bewering_1_4."rsin_aangever" 
end) AS "rsin_aangever_10", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 10 THEN v_vpb_aangifte_bewering_1_4."aangifte_volgnummer" 
end) AS "aangifte_volgnummer_10", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 10 THEN cast(extract(year FROM v_vpb_aangifte_bewering_1_4."tijdvak_begin_d") AS varchar(4)) 
end) AS "belastingjaar_10", max(
CASE 
 WHEN v_vpb_aangifte_bewering_1_4."volgorde" = 10 THEN cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_begin_d" AS format 'DD-MM-YYYY') AS varchar(25)) || ' t/m ' || cast(cast(v_vpb_aangifte_bewering_1_4."tijdvak_eind_d" AS format 'DD-MM-YYYY') AS varchar(25)) 
end) AS "tijdvak_10" 
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_1_4" AS v_vpb_aangifte_bewering_1_4 
group by v_vpb_aangifte_bewering_1_4."finr", v_vpb_aangifte_bewering_1_4."rsin_aangegevene" 
