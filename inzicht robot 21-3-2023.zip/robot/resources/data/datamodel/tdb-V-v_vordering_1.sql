REPLACE VIEW DG_I_P_40ANA_INZ.v_vordering_1 AS
   SELECT
     t_vordering.vordering_id,
     t_vordering.finr,
     t_vordering.middel,
     t_vordering.vordering_nr AS "aanslagnr",
     oreplace(t_vordering.vordering_nr,'.','') AS "aanslagnr_compact",
     t_vordering.vorderingstype,
     t_vordering.periode,
     t_vordering.tijdvak_cd,
     t_vordering.dagtekening_d,
     t_vordering.vordering_verval_d,
     t_vordering.advies,
     t_vordering_statustransitie.nieuwe_status_oms AS "laatste_status",
     CASE WHEN t_vordering.advies is not null THEN 1 
     ELSE 0 END AS "dm_geselecteerd_ind",
     t_vordering.betalingskenmerk,
     t_vordering.aanslagnr_na_aangifte,
     t_vordering.kenteken,
     CASE WHEN vordering_eur > 0 AND bedrag_open_eur > 0 THEN 1 
     ELSE 0 
     END AS "is_openstaand_ind",
     t_vordering.vordering_eur,
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id in ('AANSL','AANG') 
     THEN t_vordering_bedragsmutatie.belasting_open_eur  END),0) AS "belasting_eur",
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id in ('AANSL','AANG') 
     THEN t_vordering_bedragsmutatie.heffingsrente_open_eur  END),0) AS "heffingsrente_eur",
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id in ('AANSL','AANG') 
     THEN t_vordering_bedragsmutatie.boete_open_eur  END),0) AS "boete_eur",
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id in ('AANSL','AANG') 
     THEN t_vordering_bedragsmutatie.revisierente_open_eur END), 0) AS "revisierente_eur",
     coalesce(t_vordering_bedragsmutatie_open.belasting_open_eur +t_vordering_bedragsmutatie_open.boete_open_eur +t_vordering_bedragsmutatie_open.revisierente_open_eur 
     +t_vordering_bedragsmutatie_open.heffingsrente_open_eur, 0) AS "bedrag_open_eur",
     coalesce(t_vordering_bedragsmutatie_open.invorderingskosten_open_eur, 0) AS "kosten_open_eur",
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id like 'VERR%' THEN t_vordering_bedragsmutatie.belasting_mutatie_eur +t_vordering_bedragsmutatie.boete_mutatie_eur 
     +t_vordering_bedragsmutatie.revisierente_mutatie_eur +t_vordering_bedragsmutatie.heffingsrente_mutatie_eur +t_vordering_bedragsmutatie.invorderingskosten_mutatie_eur 
     +t_vordering_bedragsmutatie.invorderingsrente_mutatie_eur END),0) AS "verrekend_af_eur",
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id like 'BET%' OR t_vordering_bedragsmutatie.soort_id like 'UITBET' THEN
     t_vordering_bedragsmutatie.belasting_mutatie_eur +t_vordering_bedragsmutatie.boete_mutatie_eur
     +t_vordering_bedragsmutatie.revisierente_mutatie_eur +t_vordering_bedragsmutatie.heffingsrente_mutatie_eur +t_vordering_bedragsmutatie.invorderingskosten_mutatie_eur
     +t_vordering_bedragsmutatie.invorderingsrente_mutatie_eur END),0) AS "betaald_af_eur",
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id like 'VERM_%' THEN t_vordering_bedragsmutatie.belasting_mutatie_eur +t_vordering_bedragsmutatie.boete_mutatie_eur 
     +t_vordering_bedragsmutatie.revisierente_mutatie_eur +t_vordering_bedragsmutatie.heffingsrente_mutatie_eur +t_vordering_bedragsmutatie.invorderingskosten_mutatie_eur 
     +t_vordering_bedragsmutatie.invorderingsrente_mutatie_eur END),0) AS "verminderd_af_eur",
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id like 'ONIN%' THEN t_vordering_bedragsmutatie.belasting_mutatie_eur +t_vordering_bedragsmutatie.boete_mutatie_eur 
     +t_vordering_bedragsmutatie.revisierente_mutatie_eur +t_vordering_bedragsmutatie.heffingsrente_mutatie_eur +t_vordering_bedragsmutatie.invorderingskosten_mutatie_eur 
     +t_vordering_bedragsmutatie.invorderingsrente_mutatie_eur END),0) AS "oninbaar_af_eur",
     coalesce(SUM(CASE WHEN t_vordering_bedragsmutatie.soort_id like 'BETRENT' OR t_vordering_bedragsmutatie.soort_id like 'VERGRENT'
     THEN t_vordering_bedragsmutatie.invorderingsrente_mutatie_eur END),0) AS "invord_rente_af_eur"
   FROM
     DG_I_P_40ANA_INZ.T_VORDERING AS t_vordering left JOIN 
     DG_I_P_40ANA_INZ.T_VORDERING_STATUSTRANSITIE AS t_vordering_statustransitie
      on
      (
        t_vordering.vordering_id = t_vordering_statustransitie.vordering_id
        AND t_vordering.finr = t_vordering_statustransitie.finr
        AND t_vordering_statustransitie.volgordenr = 1
     ) left JOIN 
     DG_I_P_40ANA_INZ.T_VORDERING_BEDRAGSMUTATIE AS t_vordering_bedragsmutatie
      on
      (
        t_vordering.vordering_id = t_vordering_bedragsmutatie.vordering_id
        AND t_vordering.finr = t_vordering_bedragsmutatie.finr
     ) left JOIN 
     DG_I_P_40ANA_INZ.T_VORDERING_BEDRAGSMUTATIE AS t_vordering_bedragsmutatie_open
      on
      (
        t_vordering.vordering_id = t_vordering_bedragsmutatie_open.vordering_id
        AND t_vordering.finr = t_vordering_bedragsmutatie_open.finr
        AND t_vordering_bedragsmutatie_open.volgordenr = 1
     )
   group by
     t_vordering.kenteken,
     t_vordering.aanslagnr_na_aangifte,
     t_vordering.betalingskenmerk,
     t_vordering.dagtekening_d,
     t_vordering.tijdvak_cd,
     t_vordering.vordering_verval_d,
     t_vordering.periode,
     t_vordering.vordering_eur,
     t_vordering.vordering_nr,
     t_vordering.vorderingstype,
     t_vordering.middel,
     t_vordering.finr,
     t_vordering.vordering_id,
     t_vordering_bedragsmutatie_open.belasting_open_eur,
     t_vordering_bedragsmutatie_open.boete_open_eur,
     t_vordering_bedragsmutatie_open.revisierente_open_eur,
     t_vordering_bedragsmutatie_open.heffingsrente_open_eur,
     t_vordering_bedragsmutatie_open.invorderingskosten_open_eur,
     t_vordering.advies,
     t_vordering_statustransitie.nieuwe_status_oms 
