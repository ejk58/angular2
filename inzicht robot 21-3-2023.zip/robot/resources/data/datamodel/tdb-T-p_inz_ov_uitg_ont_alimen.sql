DROP TABLE DG_I_P_40ANA_INZ.p_inz_ov_uitg_ont_alimen;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ov_uitg_ont_alimen,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   finr_ex INTEGER,
   finr_ex_hidden INTEGER,
   niveau SMALLINT,
   opmaak VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
   volgorde INTEGER,
   sleutel INTEGER,
   parent INTEGER,
   waarde_eur DECIMAL(18,0),
   omschrijving VARCHAR(260) CHARACTER SET UNICODE NOT CASESPECIFIC,
   exisvip_ind BYTEINT,
   created_dt TIMESTAMP(6),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
