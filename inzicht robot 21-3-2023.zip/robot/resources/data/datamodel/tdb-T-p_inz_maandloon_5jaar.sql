DROP TABLE DG_I_P_40ANA_INZ.p_inz_maandloon_5jaar;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_maandloon_5jaar,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   belastingplichtige_eur DECIMAL(18,0),
   partner_eur DECIMAL(18,0),
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
