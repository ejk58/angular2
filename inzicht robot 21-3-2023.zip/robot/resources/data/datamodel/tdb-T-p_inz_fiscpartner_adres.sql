DROP TABLE DG_I_P_40ANA_INZ.p_inz_fiscpartner_adres;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_fiscpartner_adres,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   finr_fiscale_partner INTEGER,
   code SMALLINT,
   nr VARCHAR(2) CHARACTER SET UNICODE CASESPECIFIC,
   waarde VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   fpisvip_ind BYTEINT)
PRIMARY INDEX (finr,belastingjaar); 
