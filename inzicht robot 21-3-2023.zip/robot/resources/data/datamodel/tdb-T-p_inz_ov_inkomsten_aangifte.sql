DROP TABLE DG_I_P_40ANA_INZ.p_inz_ov_inkomsten_aangifte;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ov_inkomsten_aangifte,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   niveau SMALLINT,
   opmaak VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
   volgorde INTEGER,
   sleutel INTEGER,
   parent INTEGER,
   waarde_eur DECIMAL(18,0),
   omschrijving VARCHAR(245) CHARACTER SET UNICODE NOT CASESPECIFIC,
   created_dt TIMESTAMP(6),
   releasenr VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX (finr,belastingjaar); 
