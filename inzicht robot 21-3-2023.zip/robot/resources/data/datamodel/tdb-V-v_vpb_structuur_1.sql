REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_structuur_1 AS 
SELECT t_vpb_structuur.id, t_vpb_structuur.naam 
FROM DG_I_P_40ANA_INZ.T_VPB_STRUCTUUR AS t_vpb_structuur 
