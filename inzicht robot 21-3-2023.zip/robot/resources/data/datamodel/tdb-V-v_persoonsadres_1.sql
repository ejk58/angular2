REPLACE VIEW DG_I_P_40ANA_INZ.v_persoonsadres_1 AS
  SELECT t_persoonsadres.finr,
    t_persoonsadres.persoonsadressoort_cd,
    t_persoonsadres.persoonsadressoort,
    t_persoonsadres.bestaat_van_d,
    
    CASE
      WHEN t_persoonsadres.persoonsadressoort_cd IN ('1', '7') THEN LEAST(COALESCE(t_persoon.bestaat_tot_d,t_persoonsadres.bestaat_tot_d), t_persoonsadres.bestaat_tot_d) ELSE t_persoonsadres.bestaat_tot_d
    END AS "bestaat_tot_d",
      COALESCE(t_adres.adresregel_1 ||' ','') || COALESCE(t_adres.adresregel_2 || ' ','') || COALESCE(t_adres.adresregel_3 || ' ', '') AS "adres",
      t_persoon.is_natuurlijk_persoon_ind
    FROM DG_I_P_40ANA_INZ.T_PERSOONSADRES AS t_persoonsadres INNER JOIN DG_I_P_40ANA_INZ.T_ADRES AS t_adres ON (t_adres.adres_id = t_persoonsadres.adres_id) INNER JOIN DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon ON (t_persoon.finr = t_persoonsadres.finr); 
