REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_3
  (
  IN finr VARCHAR(11)
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL advies AS advies_label,
    advies AS advies_value,
    COUNT(finr) AS advies_count
      FROM DG_I_P_40ANA_INZ.v_vordering_1
      WHERE finr = :finr
      GROUP BY advies_label, advies_value
      ORDER BY advies_label;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_3 TO PUBLIC;
