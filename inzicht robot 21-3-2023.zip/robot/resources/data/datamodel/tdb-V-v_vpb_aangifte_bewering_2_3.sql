REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_2_3 AS 
SELECT t_vpb_aangifte_pers_relatie.rsin_aangever, t_vpb_aangifte_pers_relatie.aangifte_volgnummer,
 t_vpb_aangifte_pers_relatie.rsin_aangegevene, v_vpb_aangifte_bewering_2_2."structuur_id",
 v_vpb_aangifte_bewering_2_2."onderdeel_id", v_vpb_aangifte_bewering_2_2."rubriek_id",
 v_vpb_aangifte_bewering_2_2."element_id", 0 AS "id", null AS "parent_id",
 1 AS "niveau", 0 AS "volgorde", 0 AS "is_afgeschermd_ind", 
 v_vpb_aangifte_bewering_2_2."waarde_1_element_naam" AS "waarde_1",
     CAST(null AS VARCHAR(6)) AS "waarde_type_1",
     v_vpb_aangifte_bewering_2_2."waarde_2_element_naam" AS "waarde_2",
     CAST(null AS VARCHAR(6)) AS "waarde_type_2",
     v_vpb_aangifte_bewering_2_2."waarde_3_element_naam" AS "waarde_3",
     CAST(null AS VARCHAR(6)) AS "waarde_type_3",
     v_vpb_aangifte_bewering_2_2."waarde_4_element_naam" AS "waarde_4",
     CAST(null AS VARCHAR(6)) AS "waarde_type_4",
     v_vpb_aangifte_bewering_2_2."waarde_5_element_naam" AS "waarde_5",
     CAST(null AS VARCHAR(6)) AS "waarde_type_5"
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_2_2" AS v_vpb_aangifte_bewering_2_2 inner JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_PERS_RELATIE AS t_vpb_aangifte_pers_relatie 
 on (1 = 1) 
