CREATE JOIN INDEX DG_I_P_40ANA_INZ.t_vordering_st_ji_vordering_id,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_vordering_statustransitie.ROWID,
DG_I_P_40ANA_INZ.t_vordering_statustransitie.vordering_id 
 FROM DG_I_P_40ANA_INZ.t_vordering_statustransitie 
PRIMARY INDEX (vordering_id); 
