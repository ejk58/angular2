REPLACE VIEW DG_I_P_40ANA_INZ.v_persoon_2 AS
   SELECT
     t_persoon.finr,
     CASE WHEN t_persoon.is_natuurlijk_persoon_ind = 1 THEN 
     t_persoon.finr ELSE null END AS "bsn",
     CASE WHEN t_persoon.is_natuurlijk_persoon_ind = 0 THEN 
     t_persoon.finr ELSE null END AS "rsin",
     t_persoon.naam,
     v_persoon_2_1."naam_hist",
     Coalesce(v_persoon_2_1."naam_hist_ind",0) AS "naam_hist_ind",
     CASE WHEN t_persoon.is_natuurlijk_persoon_ind = 1 THEN 
     t_persoon.bestaat_van_d ELSE null END AS "geboortedatum",
     CASE WHEN t_persoon.is_natuurlijk_persoon_ind = 0 THEN 
     t_persoon.bestaat_van_d ELSE null END AS "oprichtingsdatum",
     CASE WHEN t_persoon.is_natuurlijk_persoon_ind = 1 THEN 
     t_persoon.bestaat_tot_d ELSE null END AS "overlijdensdatum",
     CASE WHEN t_persoon.is_natuurlijk_persoon_ind = 0 THEN 
     t_persoon.bestaat_tot_d ELSE null END AS "opheffingsdatum",
     t_persoon.is_natuurlijk_persoon_ind
   FROM
     DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon left JOIN 
     DG_I_P_40ANA_INZ."v_persoon_2_1" AS v_persoon_2_1
      on
      (
        t_persoon.finr = v_persoon_2_1."finr"
     )
    WHERE
     t_persoon.segment NOT IN ('GO') 
