DROP TABLE DG_I_P_40ANA_INZ.p_inz_vastgoedobjecten;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_vastgoedobjecten,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   finr_relatie INTEGER,
   relatiesoort VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   objectnr VARCHAR(30) CHARACTER SET UNICODE CASESPECIFIC,
   bron VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   koopdatum_d DATE FORMAT 'YY/MM/DD',
   verkoopdatum_d DATE FORMAT 'YY/MM/DD',
   woz_waarde_woz_eur DECIMAL(14,0),
   gebruik VARCHAR(300) CHARACTER SET UNICODE CASESPECIFIC,
   eigendom INTEGER,
   perceel VARCHAR(500) CHARACTER SET UNICODE CASESPECIFIC,
   aantal_pers INTEGER,
   behandeljaar_ind BYTEINT,
   relatieisvip_ind BYTEINT,
   laatstbekend_ind BYTEINT,
   erf_5jaar_ind BYTEINT,
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   created_dt TIMESTAMP(0))
PRIMARY INDEX (finr); 
