DROP TABLE DG_I_P_40ANA_INZ.p_inz_relaties;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_relaties,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   relatiesoort INTEGER,
   relatiesoort_bes VARCHAR(60) CHARACTER SET UNICODE CASESPECIFIC,
   finr_relatie INTEGER,
   naam_relatie VARCHAR(512) CHARACTER SET UNICODE CASESPECIFIC,
   geboortedatum_relatie_d DATE FORMAT 'YY/MM/DD',
   loon_eur DECIMAL(11,0),
   relatieisvip_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC COMPRESS '&releas')
PRIMARY INDEX (finr); 
