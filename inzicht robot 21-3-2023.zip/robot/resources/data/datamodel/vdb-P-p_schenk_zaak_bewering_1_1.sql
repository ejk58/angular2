REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_schenk_zaak_bewering_1_1
  (
  IN finr VARCHAR(10),
  IN rol_binnen_schenking VARCHAR(10)
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL vrijstelling,
     jaar,
     schenking_d,
     schenker_finr,
     schenker_naam,
     ontvanger_finr,
     ontvanger_naam,     
     aanslagsoort,
     aanslag_d,
     is_afgeschermd_ind
      FROM DG_I_P_40ANA_INZ.v_schenk_zaak_bewering_1
      WHERE finr = :finr
        AND rol_binnen_schenking = :rol_binnen_schenking
      ORDER BY jaar, schenking_d, ontvanger_finr, schenker_finr;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_schenk_zaak_bewering_1_1 TO PUBLIC;
