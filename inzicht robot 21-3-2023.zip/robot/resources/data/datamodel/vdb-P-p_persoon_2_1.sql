REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_persoon_2_1
(
IN finr varchar(11)
)
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for

SEL naam,
 naam_hist,
 naam_hist_ind,
   bsn,
   rsin,
   geboortedatum,
   oprichtingsdatum,
 overlijdensdatum,
 opheffingsdatum,
 is_natuurlijk_persoon_ind
FROM DG_I_P_40ANA_INZ.v_persoon_2
WHERE finr = :finr;
open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_persoon_2_1 TO PUBLIC;
