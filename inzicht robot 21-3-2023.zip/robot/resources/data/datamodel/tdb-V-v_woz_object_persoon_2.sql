REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_persoon_2 AS
   SELECT distinct
     t_persoonsrelatie.bronpersoon_id AS "finr",
     begin_d."datum" AS "periode_begin_d",
     eind_d."datum" AS "periode_eind_d",
     t_persoonsrelatie.doelpersoon_id AS "relatie_finr",
     t_persoonsrelatie.relatiesoort_id AS "type_relatie_tot_bp_id",
     CASE WHEN t_persoonsrelatie.relatiesoort_id = 0 THEN 'Belastingplichtige' 
          WHEN t_persoonsrelatie.relatiesoort_id = 501 THEN 'Kind'
       END AS "type_relatie_tot_bp",
     t_woz_object_persoon.woz_objectnr,
     t_woz_object_hist.aanduiding,
     CAST('? ' || ltrim(rtrim(rtrim(ltrim(ltrim(oreplace(oreplace(oreplace(cast(cast(t_woz_object_waarde.vastgestelde_waarde_eur
     AS format 'G999999999999999999D999999') AS varchar(254)),'.','|'),',','.'),'|',','),'.000'),'0'),'0'),',')) 
     || ' (' ||cast(t_woz_object_waarde.waardepeil_d AS date format 'DD-MM-YYYY')|| ')' AS varchar(25)) AS "waarde_met_peildatum",
     CASE WHEN t_woz_object_waarde.waarde_details IS NOT NULL THEN 
     'Deze waarde is gewijzigd n.a.v. een bezwaar, beroep en / of ambtshalve vermindering. Eerdere waarden waren: '|| t_woz_object_waarde.waarde_details 
     ELSE NULL END AS "waarde_details",
     CASE WHEN t_woz_object_waarde.waarde_details IS NOT NULL THEN 1 ELSE 0
     END AS "waarde_details_ind",
     t_woz_object_persoon.type_relatie_tot_woz_object,
     t_woz_object_persoon.bestaat_van_d AS "relatie_tot_woz_object_begin_d",
     CASE WHEN YEAR(t_woz_object_persoon.bestaat_tot_d) = 9999 THEN NULL ELSE t_woz_object_persoon.bestaat_tot_d END AS "relatie_tot_woz_object_eind_d",
     CASE WHEN t_woz_object_persoon.bestaat_van_d = '2011-01-01' OR t_woz_object_persoon.bestaat_van_d = '2009-01-01' THEN 1 
     ELSE 0 
     END AS "bestaat_van_kleiner_gelijk_ind",
     'Data beschikbaar vanaf ' || 
     CASE WHEN t_woz_object_persoon.bestaat_van_d = '2009-01-01' OR t_woz_object_persoon.bestaat_van_d = '2011-01-01' THEN to_char(t_woz_object_persoon.bestaat_van_d, 'DD-MM-YYYY') 
     ELSE NULL 
     END AS "bestaat_van_kleiner_gelijk",
     greatest(begin_d."datum",t_woz_object_persoon.bestaat_van_d) AS "greatest_begin_d",
     CASE WHEN t_persoonsrelatie.relatiesoort_id = 0 THEN 'currentSide'  
         ELSE 'none' 
     END AS "currentside",
     cast(CASE WHEN YEAR(t_woz_object_persoon.bestaat_tot_d) = 9999 THEN eind_d."datum" 
     ELSE least(eind_d."datum",t_woz_object_persoon.bestaat_tot_d) END AS varchar(10)) AS "peildatum_text"
   FROM
     DG_I_P_40ANA_INZ."t_datum" AS begin_d inner JOIN 
     DG_I_P_40ANA_INZ."t_datum" AS eind_d
      on
      (
        eind_d."datum" >= begin_d."datum"
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS t_persoonsrelatie
      on
      (
        t_persoonsrelatie.bestaat_van_d < eind_d."datum"
        AND t_persoonsrelatie.bestaat_tot_d > begin_d."datum"
        AND t_persoonsrelatie.relatiesoort_id IN (0,501)
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon
      on
      (
        t_persoon.finr = t_persoonsrelatie.doelpersoon_id
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_PERSOON AS t_woz_object_persoon
      on
      (
        t_woz_object_persoon.finr = t_persoon.finr
        AND t_woz_object_persoon.bestaat_van_d < t_persoonsrelatie.bestaat_tot_d
        AND t_woz_object_persoon.bestaat_tot_d > t_persoonsrelatie.bestaat_van_d
        AND t_woz_object_persoon.bestaat_van_d < eind_d."datum"
        AND t_woz_object_persoon.bestaat_tot_d > begin_d."datum"
        AND (t_persoonsrelatie.relatiesoort_id IN (0)
        OR (t_persoonsrelatie.relatiesoort_id = 501
        AND t_woz_object_persoon.bestaat_tot_d < add_months(t_persoon.bestaat_van_d,18*12)))
     ) left JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_HIST AS t_woz_object_hist
      on
      (
        t_woz_object_hist.woz_objectnr = t_woz_object_persoon.woz_objectnr
        AND t_woz_object_hist.ingang_d <= least(eind_d."datum", t_woz_object_persoon.bestaat_tot_d)
        AND t_woz_object_hist.verval_d >= least(eind_d."datum", t_woz_object_persoon.bestaat_tot_d)
     ) left JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_WAARDE AS t_woz_object_waarde
      on
      (
        t_woz_object_waarde.woz_objectnr = t_woz_object_persoon.woz_objectnr
        AND t_woz_object_waarde.bestaat_van_d <= least(eind_d."datum", t_woz_object_persoon.bestaat_tot_d)
        AND t_woz_object_waarde.bestaat_tot_d > least(eind_d."datum", t_woz_object_persoon.bestaat_tot_d)
     ); 
