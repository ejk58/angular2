REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_klantbeeld_persoonsgegevens_1_2 (
IN finr varchar(11)
)
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for
SEL adres_volgens_gemeente,
 vestigingsadres,
 np_ind
FROM DG_I_P_50PRO_INZ.v_klantbeeld_persoonsgegevens_1
WHERE finr = :finr;
open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_klantbeeld_persoonsgegevens_1_2 TO PUBLIC;
