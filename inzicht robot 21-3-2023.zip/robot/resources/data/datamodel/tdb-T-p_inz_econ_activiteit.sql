DROP TABLE DG_I_P_40ANA_INZ.p_inz_econ_activiteit;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_econ_activiteit,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   volgnr SMALLINT,
   handelsnaam VARCHAR(72) CHARACTER SET UNICODE CASESPECIFIC,
   branche_cd VARCHAR(200) CHARACTER SET UNICODE NOT CASESPECIFIC FORMAT 'X(4)',
   branche_omschr VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC FORMAT 'X(60)',
   branche_cd_en_omschr VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC FORMAT 'X(67)',
   ingang_d DATE FORMAT 'yyyy-mm-dd',
   verval_d DATE FORMAT 'yyyy-mm-dd',
   vestiging_begin_d DATE FORMAT 'yyyy-mm-dd',
   vestiging_eind_d DATE FORMAT 'yyyy-mm-dd',
   actief_ind BYTEINT,
   laatste_stand_ind BYTEINT,
   aantal_activiteiten SMALLINT,
   actief_sinds_d DATE FORMAT 'yyyy-mm-dd',
   laatst_actief_d DATE FORMAT 'yyyy-mm-dd',
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   kvknr VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX (finr); 
