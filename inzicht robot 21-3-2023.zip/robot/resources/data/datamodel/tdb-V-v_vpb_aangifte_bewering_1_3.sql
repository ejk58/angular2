REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_1_3 AS 
SELECT "v_vpb_aangifte_bewering_1_1"."finr", "v_vpb_aangifte_bewering_1_1"."rsin_aangegevene",
 "v_vpb_aangifte_bewering_1_1"."rsin_aangever", "v_vpb_aangifte_bewering_1_1"."aangifte_volgnummer",
 "v_vpb_aangifte_bewering_1_1"."tijdvak_begin_d", "v_vpb_aangifte_bewering_1_1"."tijdvak_eind_d" 
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_1_1" AS v_vpb_aangifte_bewering_1_1 
union all 
SELECT "v_vpb_aangifte_bewering_1_2"."finr", "v_vpb_aangifte_bewering_1_2"."rsin_aangegevene",
 "v_vpb_aangifte_bewering_1_2"."rsin_aangever", "v_vpb_aangifte_bewering_1_2"."aangifte_volgnummer",
 "v_vpb_aangifte_bewering_1_2"."tijdvak_begin_d", "v_vpb_aangifte_bewering_1_2"."tijdvak_eind_d" 
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_1_2" AS v_vpb_aangifte_bewering_1_2 
