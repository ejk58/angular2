REPLACE VIEW DG_I_P_40ANA_INZ.v_persoon_1_1 AS 
SELECT t_vpb_aangifte.rsin_aangever, t_vpb_aangifte.volgnummer 
FROM DG_I_P_40ANA_INZ.T_VPB_AANGIFTE AS t_vpb_aangifte 
WHERE 1 = 1 
qualify 1 = row_number() over (partition by t_vpb_aangifte.rsin_aangever,
 t_vpb_aangifte.tijdvak_begin_d, t_vpb_aangifte.tijdvak_eind_d 
ORDER BY t_vpb_aangifte.volgnummer desc) 
