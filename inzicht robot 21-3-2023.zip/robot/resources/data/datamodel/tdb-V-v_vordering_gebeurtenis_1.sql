REPLACE VIEW DG_I_P_40ANA_INZ.v_vordering_gebeurtenis_1 AS
   SELECT
     v_vordering_gebeurtenis_1_1."vordering_id",
     v_vordering_gebeurtenis_1_1."finr",
     v_vordering_gebeurtenis_1_1."omschrijving",
     CAST(NULL AS DATE) AS "dagtekening_d",
     v_vordering_gebeurtenis_1_1."open_bedrag_eur",
     v_vordering_gebeurtenis_1_1."open_rente_eur",
     v_vordering_gebeurtenis_1_1."open_kosten_eur",
     v_vordering_gebeurtenis_1_1."open_saldo_eur",
     v_vordering_gebeurtenis_1_1."bedrag_eur",
     v_vordering_gebeurtenis_1_1."uitgesplitst_bedrag",
     v_vordering_gebeurtenis_1_1."rekeningnr_klant",
     v_vordering_gebeurtenis_1_1."rekeningnr_belastingdienst",
     v_vordering_gebeurtenis_1_1."vorderingnr_verr_met",
     v_vordering_gebeurtenis_1_1."automatisch_betalen_ind",
     v_vordering_gebeurtenis_1_1."subcode",
     v_vordering_gebeurtenis_1_1."subcode_oms",
     v_vordering_gebeurtenis_1_1."gebeurtenis_d",
     v_vordering_gebeurtenis_1_1."valuta_d",
     v_vordering_gebeurtenis_1_1."volgordenr",
     v_vordering_gebeurtenis_1_1."volledig_afgeboekt_ind",
     v_vordering_gebeurtenis_1_1."gebeurtenis_dt"
   FROM
     DG_I_P_40ANA_INZ."v_vordering_gebeurtenis_1_1" AS v_vordering_gebeurtenis_1_1
   union all 
   SELECT
     v_vordering_gebeurtenis_1_2."vordering_id",
     v_vordering_gebeurtenis_1_2."finr",
     v_vordering_gebeurtenis_1_2."omschrijving",
     CAST(v_vordering_gebeurtenis_1_2."dagtekening_d" AS DATE) AS "dagtekening_d",
     v_vordering_gebeurtenis_1_2."open_bedrag_eur",
     v_vordering_gebeurtenis_1_2."open_rente_eur",
     v_vordering_gebeurtenis_1_2."open_kosten_eur",
     v_vordering_gebeurtenis_1_2."open_saldo_eur",
     null AS "bedrag_eur",
     cast(NULL AS VARCHAR(200)) AS "uitgesplitst_bedrag",
     cast(NULL AS VARCHAR(50)) AS "rekeningnr_klant",
     cast(NULL AS VARCHAR(50)) AS "rekeningnr_belastingdienst",
     cast(NULL AS VARCHAR(25)) AS "vorderingnr_verr_met",
     null AS "automatisch_betalen_ind",
     cast(NULL AS VARCHAR(4)) AS "subcode",
     cast(NULL AS VARCHAR(50)) AS "subcode_oms",
     v_vordering_gebeurtenis_1_2."gebeurtenis_d",
     null AS "valuta_d",
     v_vordering_gebeurtenis_1_2."volgordenr",
     v_vordering_gebeurtenis_1_2."volledig_afgeboekt_ind",
     v_vordering_gebeurtenis_1_2."gebeurtenis_dt"
   FROM
     DG_I_P_40ANA_INZ."v_vordering_gebeurtenis_1_2" AS v_vordering_gebeurtenis_1_2 
