DROP TABLE DG_I_P_40ANA_INZ.p_inz_ob_suppleties_overz;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ob_suppleties_overz,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   subnummer SMALLINT,
   belastingjaar SMALLINT,
   tijdvak VARCHAR(25) CHARACTER SET UNICODE CASESPECIFIC,
   ontvangst_dt TIMESTAMP(6),
   versch_omz_bel_eur DECIMAL(10,0),
   voorbelasting_eur DECIMAL(10,0),
   klein_ond_regeling_eur SMALLINT,
   nu_versch_bedr_eur DECIMAL(10,0),
   eerder_versch_bedr_eur DECIMAL(10,0),
   teverrekenenbedrag_eur DECIMAL(9,0),
   behandelwijze VARCHAR(25) CHARACTER SET UNICODE CASESPECIFIC,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(7) CHARACTER SET UNICODE CASESPECIFIC COMPRESS '2020.39')
PRIMARY INDEX (finr); 
