DROP TABLE DG_I_P_40ANA_INZ.p_inz_inkomen_srt_lbtabel_aggr;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_inkomen_srt_lbtabel_aggr,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   peil0_jaar SMALLINT,
   srt_lbtabel VARCHAR(20) CHARACTER SET UNICODE CASESPECIFIC,
   bruto_inkomen_peil1 DECIMAL(18,0),
   bruto_inkomen_peil0 DECIMAL(18,0),
   bruto_inkomen_peil_1 DECIMAL(18,0),
   bruto_inkomen_peil_2 DECIMAL(18,0),
   bruto_inkomen_peil_3 DECIMAL(18,0),
   bruto_inkomen_peil_4 DECIMAL(18,0),
   bruto_inkomen_peil_5 DECIMAL(18,0),
   bruto_inkomen_peil_6 DECIMAL(18,0),
   created_dt VARCHAR(30) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX (finr)
INDEX (finr,peil0_jaar); 
