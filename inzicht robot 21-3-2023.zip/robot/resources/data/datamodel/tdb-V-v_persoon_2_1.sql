REPLACE VIEW DG_I_P_40ANA_INZ.v_persoon_2_1 AS
   SELECT
     t_persoon_hist_prev.finr,
     substring(cast(XMLAGG(
     '<br>' || cast(t_persoon_hist.ingang_d AS format 'DD-MM-YYYY') || ': ' 
     || coalesce(t_persoon_hist_prev.naam,'-') || ' > ' || coalesce(t_persoon_hist.naam,'-') 
     ORDER BY t_persoon_hist.ingang_d desc) AS varchar(2000)),5) AS "naam_hist",
     1 AS "naam_hist_ind"
   FROM
     DG_I_P_40ANA_INZ.T_PERSOON_HIST AS t_persoon_hist_prev inner JOIN 
     DG_I_P_40ANA_INZ.T_PERSOON_HIST AS t_persoon_hist
      on
      (
        t_persoon_hist_prev.finr = t_persoon_hist.finr
        AND t_persoon_hist_prev.verval_d = t_persoon_hist.ingang_d
        AND coalesce(t_persoon_hist_prev.naam,'null') <> coalesce(t_persoon_hist.naam,'null')
     )
   group by
     t_persoon_hist_prev.finr 
