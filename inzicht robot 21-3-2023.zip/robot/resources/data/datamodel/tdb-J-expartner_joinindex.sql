CREATE JOIN INDEX DG_I_P_40ANA_INZ.expartner_joinindex,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.p_inz_ex_partners.finr,DG_I_P_40ANA_INZ.p_inz_ex_partners.finr_ex,
DG_I_P_40ANA_INZ.p_inz_ex_partners.belastingjaar,DG_I_P_40ANA_INZ.p_inz_ex_partners.verval_d,
DG_I_P_40ANA_INZ.p_inz_ex_partners.naam_ex,DG_I_P_40ANA_INZ.p_inz_ex_partners.geboortedatum_ex_d,
DG_I_P_40ANA_INZ.p_inz_ex_partners.overlijden_actueel_ex_d,
DG_I_P_40ANA_INZ.p_inz_ex_partners.geslacht_ex,DG_I_P_40ANA_INZ.p_inz_ex_partners.burgelijke_staat_ex,
DG_I_P_40ANA_INZ.p_inz_ex_partners.finr_fiscale_partner,DG_I_P_40ANA_INZ.p_inz_ex_partners.leeftijd_ex,
DG_I_P_40ANA_INZ.p_inz_ex_partners.vip_ind,DG_I_P_40ANA_INZ.p_inz_ex_partners.exisvip_ind,
DG_I_P_40ANA_INZ.p_inz_ex_partners.created_dt,DG_I_P_40ANA_INZ.p_inz_ex_partners.releasenr 
 FROM DG_I_P_40ANA_INZ.p_inz_ex_partners 
WHERE NOT (DG_I_P_40ANA_INZ.p_inz_ex_partners.finr_fiscale_partner IS NULL)
PRIMARY INDEX (belastingjaar,finr_fiscale_partner); 
