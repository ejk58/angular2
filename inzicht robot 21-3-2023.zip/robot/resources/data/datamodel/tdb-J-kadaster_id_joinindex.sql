CREATE JOIN INDEX DG_I_P_40ANA_INZ.kadaster_id_joinindex,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.p_inz_vg_kadaster.finr,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.objectnr,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.kadaster_id,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.mutatie_d,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.gemeente,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.kad_sectie,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.recht,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.perceelnr,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.appartementsrecht,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.cultuurcode_obb,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.grootte,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.soortgrootte,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.koopjaar,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.koopsom,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.hypotheek_schuldeiser,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.object_bes,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.link_akte,DG_I_P_40ANA_INZ.p_inz_vg_kadaster.created_dt,
DG_I_P_40ANA_INZ.p_inz_vg_kadaster.releasenr 
 FROM DG_I_P_40ANA_INZ.p_inz_vg_kadaster 
PRIMARY INDEX (kadaster_id); 
