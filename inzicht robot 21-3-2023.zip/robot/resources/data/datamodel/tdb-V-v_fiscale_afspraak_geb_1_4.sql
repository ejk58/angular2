REPLACE VIEW DG_I_P_40ANA_INZ.v_fiscale_afspraak_geb_1_4 AS
  SELECT v_fiscale_afspraak_geb_1_3."fiscale_afspraak_id",
    v_fiscale_afspraak_geb_1_3."finr",
    CAST(NULL AS DATE) AS "vermoedelijke_schenking_d",
    CAST(NULL AS VARCHAR(11)) AS "finr_schenker",
    CAST(NULL AS VARCHAR(7)) AS "behandelaar_user_id",
    CAST(NULL AS VARCHAR(50)) AS "laatste_actie",
    CAST(NULL AS VARCHAR(256)) AS "reden_muteren",
    parent + ROW_NUMBER() OVER (PARTITION BY v_fiscale_afspraak_geb_1_3."fiscale_afspraak_id", v_fiscale_afspraak_geb_1_3."finr", v_fiscale_afspraak_geb_1_3."vermoedelijke_schenking_d"
    ORDER BY COALESCE(v_fiscale_afspraak_geb_1_3."gebeurtenis_d", v_fiscale_afspraak_geb_1_3."besluit_ontvangst_d") DESC) AS "volgorde",
      2 AS "niveau",
      100 * DENSE_RANK() OVER (PARTITION BY v_fiscale_afspraak_geb_1_3."finr"
    ORDER BY v_fiscale_afspraak_geb_1_3."vermoedelijke_schenking_d",
      v_fiscale_afspraak_geb_1_3."fiscale_afspraak_id" DESC) AS "parent",
      v_fiscale_afspraak_geb_1_3."gebeurtenis_d",
      v_fiscale_afspraak_geb_1_3."gebeurtenis_type",
      v_fiscale_afspraak_geb_1_3."verval_d",
      v_fiscale_afspraak_geb_1_3."details",
      
    CASE
      WHEN v_fiscale_afspraak_geb_1_3."gebeurtenis_type" = 'Klantreactie' THEN 1
      WHEN v_fiscale_afspraak_geb_1_3."gebeurtenis_type" IN ('UDA geannuleerd', 'Definitief buiten bewaking') THEN 2 ELSE 0
    END AS "status_einde",
      
    CASE
      WHEN ROW_NUMBER() OVER (PARTITION BY v_fiscale_afspraak_geb_1_3."fiscale_afspraak_id",v_fiscale_afspraak_geb_1_3."finr"
    ORDER BY COALESCE(v_fiscale_afspraak_geb_1_3."gebeurtenis_d",v_fiscale_afspraak_geb_1_3."besluit_ontvangst_d") DESC) = 1 THEN 1 ELSE 0
    END AS "laatste_stand_ind",
      
    CASE
      WHEN v_fiscale_afspraak_geb_1_3."gebeurtenis_type" LIKE ANY ('Herinnering%','Aanmaning%') THEN 'besluitdatum: <br>' || CAST(CAST(v_fiscale_afspraak_geb_1_3."besluit_ontvangst_d" AS DATE FORMAT 'DD-MM-YYYY') AS VARCHAR(10))
      WHEN v_fiscale_afspraak_geb_1_3."gebeurtenis_type" LIKE 'Uitstelverzoek%' THEN 'Ontvangstdatum: <br>' || CAST(CAST(v_fiscale_afspraak_geb_1_3."besluit_ontvangst_d" AS DATE FORMAT 'DD-MM-YYYY') AS VARCHAR(10)) ELSE NULL
    END AS "tooltip"
    FROM DG_I_P_40ANA_INZ."v_fiscale_afspraak_geb_1_3" AS v_fiscale_afspraak_geb_1_3 
