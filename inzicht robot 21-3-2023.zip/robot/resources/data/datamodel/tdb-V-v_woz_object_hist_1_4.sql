REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_hist_1_4 AS
   SELECT
     t_woz_object_hist.woz_objectnr,
     t_datum_begin."datum" AS "begin_d",
     t_datum_einde."datum" AS "eind_d",
     substring(cast(XMLAGG(
     '<br>' || cast(t_woz_object_hist.ingang_d AS format 'DD-MM-YYYY') || ': ' 
     || coalesce(cast(t_woz_object_hist_prev.grondoppervlakte_m2 AS varchar(17)) || ' m?','-') 
     || ' > ' || coalesce(cast(t_woz_object_hist.grondoppervlakte_m2 AS varchar(17)) || ' m?','-')
     ORDER BY t_woz_object_hist.ingang_d desc) AS varchar(2000)),5) AS "grondoppervlakte_hist"
   FROM
     DG_I_P_40ANA_INZ."t_datum" AS t_datum_begin inner JOIN 
     DG_I_P_40ANA_INZ."t_datum" AS t_datum_einde
      on
      (
        t_datum_einde."datum" >= t_datum_begin."datum"
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_HIST AS t_woz_object_hist
      on
      (
        t_woz_object_hist.ingang_d >= t_datum_begin."datum"
        AND t_woz_object_hist.ingang_d <= t_datum_einde."datum"
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_HIST AS t_woz_object_hist_prev
      on
      (
        t_woz_object_hist_prev.woz_objectnr = t_woz_object_hist.woz_objectnr
        AND t_woz_object_hist_prev.verval_d = t_woz_object_hist.ingang_d
        AND coalesce(t_woz_object_hist_prev.grondoppervlakte_m2,'null') <> coalesce(t_woz_object_hist.grondoppervlakte_m2,'null')
     )
   group by(
     t_datum_begin."datum",
     t_datum_einde."datum",
     t_woz_object_hist.woz_objectnr
   
 ) 
