REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_hist_1 AS
   SELECT
     v_woz_object_hist_1_1."woz_objectnr",
     v_woz_object_hist_1_1."begin_d",
     v_woz_object_hist_1_1."eind_d",
     v_woz_object_hist_1_1."datum_begin_geldigheid_object",
     v_woz_object_hist_1_1."bestaat_van_kleiner_gelijk_ind",
     v_woz_object_hist_1_1."bestaat_van_kleiner_gelijk",
     v_woz_object_hist_1_1."datum_eind_geldigheid_object",
     v_woz_object_hist_1_1."aanduiding",
     v_woz_object_hist_1_2."aanduiding_hist",
     CASE WHEN v_woz_object_hist_1_2."aanduiding_hist" is null THEN 0 ELSE 1 END AS "bevat_aanduiding_hist_ind",
     v_woz_object_hist_1_1."gebruikscode",
     v_woz_object_hist_1_3."gebruikscode_hist",
     CASE WHEN v_woz_object_hist_1_3."gebruikscode_hist" is null THEN 0 ELSE 1 END AS "bevat_gebruikscode_hist_ind",
     v_woz_object_hist_1_1."grondoppervlakte",
     v_woz_object_hist_1_4."grondoppervlakte_hist",
     CASE WHEN v_woz_object_hist_1_4."grondoppervlakte_hist" is null THEN 0 ELSE 1 END AS "bevat_grondoppervlakte_hist_ind"
   FROM
     DG_I_P_40ANA_INZ."v_woz_object_hist_1_1" AS v_woz_object_hist_1_1 left JOIN 
     DG_I_P_40ANA_INZ."v_woz_object_hist_1_2" AS v_woz_object_hist_1_2
      on
      (
        v_woz_object_hist_1_2."woz_objectnr" = v_woz_object_hist_1_1."woz_objectnr"
        AND v_woz_object_hist_1_2."begin_d" = v_woz_object_hist_1_1."begin_d"
        AND v_woz_object_hist_1_2."eind_d" = v_woz_object_hist_1_1."eind_d"
     ) left JOIN 
     DG_I_P_40ANA_INZ."v_woz_object_hist_1_3" AS v_woz_object_hist_1_3
      on
      (
        v_woz_object_hist_1_3."woz_objectnr" = v_woz_object_hist_1_1."woz_objectnr"
        AND v_woz_object_hist_1_3."begin_d" = v_woz_object_hist_1_1."begin_d"
        AND v_woz_object_hist_1_3."eind_d" = v_woz_object_hist_1_1."eind_d"
     ) left JOIN 
     DG_I_P_40ANA_INZ."v_woz_object_hist_1_4" AS v_woz_object_hist_1_4
      on
      (
        v_woz_object_hist_1_4."woz_objectnr" = v_woz_object_hist_1_1."woz_objectnr"
        AND v_woz_object_hist_1_4."begin_d" = v_woz_object_hist_1_1."begin_d"
        AND v_woz_object_hist_1_4."eind_d" = v_woz_object_hist_1_1."eind_d"
     ) 
