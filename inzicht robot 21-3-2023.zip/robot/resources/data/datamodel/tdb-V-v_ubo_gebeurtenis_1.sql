REPLACE VIEW DG_I_P_40ANA_INZ.v_ubo_gebeurtenis_1 AS
  SELECT v_ubo_gebeurtenis_1_1."finr",
    v_ubo_gebeurtenis_1_1."persoon",
    v_ubo_gebeurtenis_1_1."is_afgeschermd_ind",
    v_ubo_gebeurtenis_1_1."gebeurtenistype",
    v_ubo_gebeurtenis_1_1."gebeurtenis_d",
    v_ubo_gebeurtenis_1_1."is_significant_ind",
    v_ubo_gebeurtenis_1_1."details",
    v_ubo_gebeurtenis_1_1."finr_relatie"
    FROM DG_I_P_40ANA_INZ."v_ubo_gebeurtenis_1_1" AS v_ubo_gebeurtenis_1_1 UNION ALL
  SELECT v_ubo_gebeurtenis_1_2."finr",
    v_ubo_gebeurtenis_1_2."persoon",
    v_ubo_gebeurtenis_1_2."is_afgeschermd_ind",
    v_ubo_gebeurtenis_1_2."gebeurtenistype",
    v_ubo_gebeurtenis_1_2."gebeurtenis_d",
    v_ubo_gebeurtenis_1_2."is_significant_ind",
    v_ubo_gebeurtenis_1_2."details",
    v_ubo_gebeurtenis_1_2."finr_relatie"
    FROM DG_I_P_40ANA_INZ."v_ubo_gebeurtenis_1_2" AS v_ubo_gebeurtenis_1_2 UNION ALL
  SELECT v_ubo_gebeurtenis_1_3."finr",
    v_ubo_gebeurtenis_1_3."persoon",
    v_ubo_gebeurtenis_1_3."is_afgeschermd_ind",
    v_ubo_gebeurtenis_1_3."gebeurtenistype",
    v_ubo_gebeurtenis_1_3."gebeurtenis_d",
    v_ubo_gebeurtenis_1_3."is_significant_ind",
    v_ubo_gebeurtenis_1_3."details",
    v_ubo_gebeurtenis_1_3."finr_relatie"
    FROM DG_I_P_40ANA_INZ."v_ubo_gebeurtenis_1_3" AS v_ubo_gebeurtenis_1_3 UNION ALL
  SELECT v_ubo_gebeurtenis_1_4."finr",
    v_ubo_gebeurtenis_1_4."persoon",
    v_ubo_gebeurtenis_1_4."is_afgeschermd_ind",
    v_ubo_gebeurtenis_1_4."gebeurtenistype",
    v_ubo_gebeurtenis_1_4."gebeurtenis_d",
    v_ubo_gebeurtenis_1_4."is_significant_ind",
    v_ubo_gebeurtenis_1_4."details",
    v_ubo_gebeurtenis_1_4."finr_relatie"
    FROM DG_I_P_40ANA_INZ."v_ubo_gebeurtenis_1_4" AS v_ubo_gebeurtenis_1_4; 
