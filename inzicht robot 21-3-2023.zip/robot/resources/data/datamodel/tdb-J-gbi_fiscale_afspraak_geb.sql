CREATE JOIN INDEX DG_I_P_40ANA_INZ.gbi_fiscale_afspraak_geb,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_fiscale_afspraak_gebeurtenis.ROWID,
DG_I_P_40ANA_INZ.t_fiscale_afspraak_gebeurtenis.finr 
 FROM DG_I_P_40ANA_INZ.t_fiscale_afspraak_gebeurtenis 
PRIMARY INDEX (finr); 
