/****************************************************
Copy Object Script for VIEW: p_inz_bankrekening_detail
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_bankrekening_detail AS
SELECT * FROM DG_I_P_40ANA_INZ.p_inz_bankrekening_detail; 
