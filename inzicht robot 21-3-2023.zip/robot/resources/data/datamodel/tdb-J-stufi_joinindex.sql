CREATE JOIN INDEX DG_I_P_40ANA_INZ.stufi_joinindex,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.p_inz_stufi.finr,DG_I_P_40ANA_INZ.p_inz_stufi.belastingjaar,
DG_I_P_40ANA_INZ.p_inz_stufi.begin_d,DG_I_P_40ANA_INZ.p_inz_stufi.eind_d,
DG_I_P_40ANA_INZ.p_inz_stufi.bron,DG_I_P_40ANA_INZ.p_inz_stufi.indicatie_grl_totaal,
DG_I_P_40ANA_INZ.p_inz_stufi.soort_opleiding,DG_I_P_40ANA_INZ.p_inz_stufi.status_stufi,
DG_I_P_40ANA_INZ.p_inz_stufi.toegekende_beurs,DG_I_P_40ANA_INZ.p_inz_stufi.studieschuld_eur,
DG_I_P_40ANA_INZ.p_inz_stufi.finr_fiscale_partner,DG_I_P_40ANA_INZ.p_inz_stufi.studieschuldduo_ind,
DG_I_P_40ANA_INZ.p_inz_stufi.vip_ind,DG_I_P_40ANA_INZ.p_inz_stufi.created_dt,
DG_I_P_40ANA_INZ.p_inz_stufi.releasenr 
 FROM DG_I_P_40ANA_INZ.p_inz_stufi 
WHERE NOT (DG_I_P_40ANA_INZ.p_inz_stufi.finr_fiscale_partner IS NULL)
PRIMARY INDEX (belastingjaar,finr_fiscale_partner); 
