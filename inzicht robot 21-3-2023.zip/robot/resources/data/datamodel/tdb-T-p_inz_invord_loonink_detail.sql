DROP TABLE DG_I_P_40ANA_INZ.p_inz_invord_loonink_detail;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_invord_loonink_detail,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   finr_partner INTEGER,
   volgorde INTEGER,
   persoon_ind VARCHAR(40) CHARACTER SET UNICODE CASESPECIFIC,
   finr_werkgever INTEGER,
   naam_werkgever VARCHAR(1536) CHARACTER SET UNICODE CASESPECIFIC,
   inhpllbnummer VARCHAR(108) CHARACTER SET UNICODE CASESPECIFIC,
   begin_tijdvak_d DATE FORMAT 'YY/MM/DD',
   eind_tijdvak_d DATE FORMAT 'YY/MM/DD',
   bruto_maandloon_eur INTEGER,
   netto_maandloon_eur INTEGER,
   uitb_vakantietoeslag_maand_eur INTEGER,
   opgebouwd_vakantietoeslag_eur INTEGER,
   extra_loon_opgebouwd DECIMAL(18,0) COMPRESS 0.,
   uitb_extra_salaris_maand_eur INTEGER,
   netto_maandloon_incl_vaktoes_eur INTEGER,
   verhaalswaarde_maand_eur INTEGER,
   tooltip VARCHAR(1536) CHARACTER SET UNICODE CASESPECIFIC,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
