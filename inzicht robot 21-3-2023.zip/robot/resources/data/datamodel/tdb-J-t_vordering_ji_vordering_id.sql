CREATE JOIN INDEX DG_I_P_40ANA_INZ.t_vordering_ji_vordering_id,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_vordering.ROWID,DG_I_P_40ANA_INZ.t_vordering.vordering_id 
 FROM DG_I_P_40ANA_INZ.t_vordering 
PRIMARY INDEX (vordering_id); 
