/****************************************************
Copy Object Script for VIEW: p_inz_jaarinkomen
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_jaarinkomen AS
SELECT * FROM DG_I_P_40ANA_INZ.p_inz_jaarinkomen; 
