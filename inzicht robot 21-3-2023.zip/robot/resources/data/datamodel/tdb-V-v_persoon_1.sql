REPLACE VIEW DG_I_P_40ANA_INZ.v_persoon_1 AS 
SELECT "v_persoon_1_3"."finr", "v_persoon_1_3"."rsin_aangegevene",
 "v_persoon_1_3"."naam", "v_persoon_1_3"."volgorde" 
FROM DG_I_P_40ANA_INZ."v_persoon_1_3" AS v_persoon_1_3 
union all 
SELECT v_persoon_1_4."finr", v_persoon_1_4."rsin_aangegevene",
 v_persoon_1_4."naam", v_persoon_1_4."volgorde" 
FROM DG_I_P_40ANA_INZ."v_persoon_1_4" AS v_persoon_1_4 
