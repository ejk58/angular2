REPLACE VIEW DG_I_P_40ANA_INZ.v_vordering_gebeurtenis_1_2 AS
   SELECT
     t_vordering_status.vordering_id,
     t_vordering_status.finr,
     'Status: ' || t_vordering_status.nieuwe_status_oms AS "omschrijving",
     t_vordering_status.dagtekening_d,
     t_vordering_status.belasting_open_eur + t_vordering_status.boete_open_eur +
     t_vordering_status.heffingsrente_open_eur + t_vordering_status.revisierente_open_eur AS "open_bedrag_eur",
     t_vordering_status.rente_open_eur AS "open_rente_eur",
     t_vordering_status.kosten_open_eur AS "open_kosten_eur",
     open_bedrag_eur + open_kosten_eur + open_rente_eur AS "open_saldo_eur",
     10000+t_vordering_status.volgordenr AS "volgordenr",
     cast(0 AS byteint) AS "volledig_afgeboekt_ind",
     cast(t_vordering_status.statustransitie_dt AS date) AS "gebeurtenis_d",
     t_vordering_status.statustransitie_dt AS "gebeurtenis_dt"
   FROM
     DG_I_P_40ANA_INZ.T_VORDERING_STATUSTRANSITIE AS t_vordering_status; 
