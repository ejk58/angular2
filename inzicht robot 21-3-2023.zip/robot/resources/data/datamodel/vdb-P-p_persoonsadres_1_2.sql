REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_persoonsadres_1_2',), ("
  (IN finr VARCHAR(11)
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL finr,
      adres,
      greatest(bestaat_van_d,
      CAST(CAST(YEAR(CURRENT_DATE)- 16 AS CHAR(4)) || '-01-01' AS DATE)) AS ingang_d,
      
      CASE
        WHEN EXTRACT(YEAR
      FROM bestaat_tot_d) = 9999 THEN CAST(NULL AS DATE) ELSE bestaat_tot_d
      END AS eind_d,
        
      CASE
        WHEN ingang_d = CAST(CAST(YEAR(CURRENT_DATE)- 16 AS CHAR(4)) || '-01-01' AS DATE)
      THEN 1 ELSE 0
      END AS kleiner_gelijk_ind
      FROM DG_I_P_40ANA_INZ.v_persoonsadres_1
      WHERE finr = :finr
        AND bestaat_tot_d > CAST(CAST(YEAR(CURRENT_DATE)- 16 AS CHAR(4)) || '-01-01' AS DATE)
        AND persoonsadressoort_cd = '1'
        AND is_natuurlijk_persoon_ind = 1
      ORDER BY bestaat_tot_d DESC;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_persoonsadres_1_2 TO PUBLIC;
