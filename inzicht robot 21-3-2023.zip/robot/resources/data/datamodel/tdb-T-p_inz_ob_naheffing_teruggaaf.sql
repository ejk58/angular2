DROP TABLE DG_I_P_40ANA_INZ.p_inz_ob_naheffing_teruggaaf;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ob_naheffing_teruggaaf,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   subnummer SMALLINT,
   belastingjaar SMALLINT,
   tijdvak_cd BYTEINT,
   tijdvak_bes VARCHAR(20) CHARACTER SET UNICODE CASESPECIFIC,
   soort VARCHAR(15) CHARACTER SET UNICODE CASESPECIFIC,
   nummer VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   dagtekening DATE FORMAT 'YY/MM/DD',
   bedrag_eur DECIMAL(18,0),
   belasting_eur DECIMAL(18,0),
   belastingrente_eur DECIMAL(18,0),
   boete_eur DECIMAL(18,0),
   reden_cd SMALLINT,
   reden_bes VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   besluitsoort_cd SMALLINT,
   besluitsoort_bes VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
