DROP TABLE DG_I_P_40ANA_INZ.p_inz_np_burgerstaat_events;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_np_burgerstaat_events,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   finr_partner INTEGER,
   burgerl_staat_event VARCHAR(20) CHARACTER SET UNICODE CASESPECIFIC,
   datum_burgerl_staat_event DATE FORMAT 'YY/MM/DD',
   belastingjaar SMALLINT)
PRIMARY INDEX (finr,belastingjaar)
INDEX (finr_partner); 
