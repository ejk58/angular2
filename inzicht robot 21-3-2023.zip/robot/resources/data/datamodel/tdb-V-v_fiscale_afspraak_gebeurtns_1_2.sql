REPLACE VIEW DG_I_P_40ANA_INZ.v_fiscale_afspraak_gebeurtns_1_2 AS 
SELECT t_fiscale_afspraak_gebeurtenis.finr, t_fiscale_afspraak_gebeurtenis.gebeurtenis_d,
 t_fiscale_afspraak_gebeurtenis.gebeurtenis_type, t_fiscale_afspraak_gebeurtenis.details,
 parent + row_number() over (partition by t_fiscale_afspraak_gebeurtenis.finr,t_fiscale_afspraak_gebeurtenis.aanleiding_d
 ORDER BY coalesce(t_fiscale_afspraak_gebeurtenis.gebeurtenis_d, t_fiscale_afspraak_gebeurtenis.besluit_ontvangst_d) desc) AS "volgorde",
 100 * dense_rank() over (partition by t_fiscale_afspraak_gebeurtenis.finr ORDER BY t_fiscale_afspraak_gebeurtenis.aanleiding_d desc) AS "parent",
 2 AS "niveau", CASE WHEN t_fiscale_afspraak_gebeurtenis.gebeurtenis_type LIKE ANY ('Klantreactie','Definitief buiten bewaking') THEN 1 
 WHEN t_fiscale_afspraak_gebeurtenis.gebeurtenis_type = 'UDA geannuleerd' 
 THEN 2 ELSE 0 END AS "status_einde",
 CASE WHEN row_number() over (partition by t_fiscale_afspraak_gebeurtenis.finr,t_fiscale_afspraak_gebeurtenis.aanleiding_d
 ORDER BY COALESCE(t_fiscale_afspraak_gebeurtenis.gebeurtenis_d,t_fiscale_afspraak_gebeurtenis.besluit_ontvangst_d) desc) = 1
 THEN 1 ELSE 0 END AS "laatste_stand_ind",
 CASE WHEN t_fiscale_afspraak_gebeurtenis.gebeurtenis_type LIKE ANY ('Herinnering%','Aanmaning%')
 THEN 'besluitdatum: <br>' || cast(cast(t_fiscale_afspraak_gebeurtenis.besluit_ontvangst_d AS DATE FORMAT 'MM-DD-YYYY') AS VARCHAR(10))
 WHEN t_fiscale_afspraak_gebeurtenis.gebeurtenis_type LIKE 'Uitstelverzoek%' THEN 'Ontvangstdatum: <br>' || cast(cast(t_fiscale_afspraak_gebeurtenis.besluit_ontvangst_d AS DATE FORMAT 'MM-DD-YYYY') AS VARCHAR(10)) 
 ELSE NULL END AS "tooltip" 
FROM DG_I_P_40ANA_INZ.T_FISCALE_AFSPRAAK_GEBEURTENIS AS t_fiscale_afspraak_gebeurtenis 
