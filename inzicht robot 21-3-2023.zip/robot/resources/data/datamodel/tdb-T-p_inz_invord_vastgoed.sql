DROP TABLE DG_I_P_40ANA_INZ.p_inz_invord_vastgoed;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_invord_vastgoed,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   aantal_objecten INTEGER,
   waarde_eur DECIMAL(18,0),
   verhaalswaarde_totaal_eur DECIMAL(18,0),
   verhaalswaarde_bp_eur DECIMAL(18,0),
   verhaalswaarde_partner_eur DECIMAL(18,0),
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   executiewaarde_eur DECIMAL(18,0),
   openstaande_schuld_eur DECIMAL(18,0),
   aantal_hypotheken INTEGER,
   woz_waarde_totaal_eur DECIMAL(18,0),
   waarde_partner_eur DECIMAL(18,0))
PRIMARY INDEX (finr); 
