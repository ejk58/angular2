REPLACE VIEW DG_I_P_50PRO_INZ.p_inz_invord_maand_vt AS LOCKING ROW FOR ACCESS SELECT * FROM DG_I_P_40ANA_INZ.p_inz_invord_maand_vt 
