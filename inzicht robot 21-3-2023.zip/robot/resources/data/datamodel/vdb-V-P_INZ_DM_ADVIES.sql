/****************************************************
Copy Object Script for VIEW: p_inz_dm_advies
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.P_INZ_DM_ADVIES AS
SELECT * FROM DG_I_P_40ANA_INZ.P_INZ_DM_ADVIES 
