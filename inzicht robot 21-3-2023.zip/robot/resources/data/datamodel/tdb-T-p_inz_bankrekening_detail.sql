DROP TABLE DG_I_P_40ANA_INZ.p_inz_bankrekening_detail;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_bankrekening_detail,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   rekeningnr VARCHAR(60) CHARACTER SET UNICODE CASESPECIFIC,
   rekid INTEGER,
   rekening_label VARCHAR(50) CHARACTER SET UNICODE CASESPECIFIC,
   valuta VARCHAR(3) CHARACTER SET UNICODE CASESPECIFIC,
   land_cd VARCHAR(2) CHARACTER SET UNICODE CASESPECIFIC,
   soort VARCHAR(4) CHARACTER SET UNICODE CASESPECIFIC,
   saldo_bedr DECIMAL(16,0),
   saldo_eur DECIMAL(16,0),
   opbrengst_bedr DECIMAL(16,0),
   opbrengst_eur DECIMAL(16,0),
   bronbelasting_bedr DECIMAL(16,0),
   bronbelasting_eur DECIMAL(16,0),
   opbr_bronbel_bedr DECIMAL(16,0),
   opbr_bronbel_eur DECIMAL(16,0),
   tooltip VARCHAR(500) CHARACTER SET UNICODE CASESPECIFIC,
   volgorde INTEGER,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(7) CHARACTER SET UNICODE CASESPECIFIC COMPRESS '2019.25')
PRIMARY INDEX (finr,belastingjaar,rekid); 
