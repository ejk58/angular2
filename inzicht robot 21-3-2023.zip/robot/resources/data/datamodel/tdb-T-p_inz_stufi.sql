DROP TABLE DG_I_P_40ANA_INZ.p_inz_stufi;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_stufi,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   begin_d DATE FORMAT 'YY/MM/DD',
   eind_d DATE FORMAT 'YY/MM/DD',
   bron VARCHAR(30) CHARACTER SET UNICODE CASESPECIFIC,
   indicatie_grl_totaal VARCHAR(70) CHARACTER SET UNICODE CASESPECIFIC,
   soort_opleiding VARCHAR(30) CHARACTER SET UNICODE CASESPECIFIC,
   status_stufi VARCHAR(50) CHARACTER SET UNICODE CASESPECIFIC,
   toegekende_beurs DECIMAL(18,0),
   studieschuld_eur DECIMAL(18,0),
   finr_fiscale_partner INTEGER,
   studieschuldduo_ind BYTEINT,
   vip_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr)
INDEX (belastingjaar,finr_fiscale_partner); 
