REPLACE VIEW DG_I_P_40ANA_INZ.v_dac6_disclosure_1 AS
 SELECT distinct
     CAST(t_dac6_disclosure_person.finr AS VARCHAR(16)) AS "finr",
     t_dac6_disclosure.id,
     CAST('DAC6' AS VARCHAR(4)) AS "type",
     t_dac6_disclosure.disclosure_version_d AS "submission_d",
     t_dac6_disclosure.arrangement_id,
     t_dac6_disclosure.implementing_d,
     t_dac6_disclosure.marketable_arrangement AS "arrangement_type",
     t_dac6_disclosure.hallmark_ids,
     t_dac6_disclosure.hallmark_descriptions AS "hallmark_description",
     CAST(t_dac6_disclosure.disclosure_name AS VARCHAR(200)) AS "disclosure_name",
     t_dac6_disclosure.amount_bedr,
     t_dac6_disclosure.currency_cd,
     CAST(CASE WHEN t_dac6_disclosure.initial_disclosure_ma_ind = 1 THEN 'Yes'
     ELSE 'No'
     END AS VARCHAR(3)) AS "initial",
     t_dac6_disclosure.version,
     t_dac6_disclosure.reason,
     CASE WHEN t_dac6_disclosure.nexus_cd like 'INEX%' THEN 'Intermediary: ' || '<br>' 
     WHEN t_dac6_disclosure.nexus_cd like 'RTNEX%' THEN 'Relevant Taxpayer: ' || '<br>' 
     ELSE ''
     END
     ||
     t_dac6_disclosure_person_2.name AS "discloser",
     '<b>Name:</b> '    || coalesce(t_dac6_disclosure_person_2.name,'N/A')  || '<br>' || 
     '<b>TIN:</b> '    || coalesce(t_dac6_disclosure_person_2.tin,'N/A')  || '<br>' || 
     '<b>Issued by:</b> '    || coalesce(t_dac6_disclosure_person_2.tin_issued_by,'N/A')  || '<br>' || 
     '<b>Street:</b> '     || coalesce(t_dac6_disclosure_person_2.street_house_identifier,'N/A') || '<br>' || 
     '<b>Postal Code:</b> '    || coalesce(t_dac6_disclosure_person_2.post_cd,'N/A')  || '<br>' || 
     '<b>City:</b> '     || coalesce(t_dac6_disclosure_person_2.city,'N/A')  || '<br>' || 
     '<b>Email Address:</b> '  || coalesce(t_dac6_disclosure_person_2.email_address,'N/A')  || '<br>' || 
     '<b>Country:</b> '    || coalesce(t_dac6_disclosure_person_2.country_cd,'N/A')  || '<br>' || 
     '<b>Residing Country:</b> ' || coalesce(t_dac6_disclosure_person_2.residing_countries,'N/A') AS "discloser_information",
     t_dac6_disclosure_person_2.capacity AS "discloser_capacity",
     t_dac6_disclosure.disclosure_description AS "summary",
     t_dac6_disclosure.dac6_dl_other_info AS "d1_other_info",
     t_dac6_disclosure.national_provisions
   FROM
     DG_I_P_40ANA_INZ.T_DAC6_DISCLOSURE_PERSON AS t_dac6_disclosure_person inner JOIN 
     DG_I_P_40ANA_INZ.T_DAC6_DISCLOSURE AS t_dac6_disclosure
      on
      (
        t_dac6_disclosure_person.disclosure_id = t_dac6_disclosure.id
        AND lower(t_dac6_disclosure_person.role_type) LIKE ANY ('relevanttaxpayer', 'affectedperson', 'associatedenterprise')
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_DAC6_DISCLOSURE_PERSON AS t_dac6_disclosure_person_2
      on
      (
        t_dac6_disclosure.id = t_dac6_disclosure_person_2.disclosure_id
        AND t_dac6_disclosure_person_2.role_type = 'DisclosingPerson'
     ) 
