REPLACE VIEW DG_I_P_40ANA_INZ.v_schenk_zaak_bewering_1_1 AS
  SELECT t_schenk_zaak.ontvanger_finr AS "finr",
    t_schenk_zaak.ontvanger_finr,
    t_schenk_zaak.schenker_finr,
    CAST(NULL AS VARCHAR(256)) AS "ontvanger_naam",
    t_schenk_zaak.schenker_naam,
    CAST(
    CASE
      WHEN SUBSTR(schenking.waarde,9,10) <> '00' THEN SUBSTR(schenking.waarde,1,10) ELSE NULL
    END AS DATE) AS "schenking_d",
      CAST(SUBSTR(schenking.waarde, 1,4) AS INTEGER) AS "jaar",
      t_schenk_zaak.dagtekening_d AS "aanslag_d",
      t_schenk_zaak.soort AS "aanslagsoort",
      CAST(
    CASE
      WHEN vrijstelling.structuur_element_id = 'IndEenmVerhoogdeVrijst' THEN 'Eenmalig verhoogde vrijstelling'
      WHEN vrijstelling.structuur_element_id = 'IndVerhoogdeVrijstFinancDureStudie' THEN 'Dure studie vrijstelling'
      WHEN vrijstelling.structuur_element_id = 'IndEenmVerhoogdeVrijstEW' THEN 'Eigen woning vrijstelling' ELSE NULL
    END AS VARCHAR(50)) AS "vrijstelling",
      CAST('ontvanger' AS VARCHAR(10)) AS "rol_binnen_schenking",
      t_persoon.is_afgeschermd_ind
    FROM DG_I_P_40ANA_INZ.T_SCHENK_ZAAK AS t_schenk_zaak INNER JOIN DG_I_P_40ANA_INZ.T_SCHENK_ZAAK_BEWERING AS schenking ON (t_schenk_zaak.id = schenking.zaak_id AND schenking.structuur_element_id = 'DatumSchenking') INNER JOIN DG_I_P_40ANA_INZ.T_SCHENK_ZAAK_BEWERING AS vrijstelling ON (t_schenk_zaak.id = vrijstelling.zaak_id AND schenking.zaak_rubriek_id = vrijstelling.zaak_rubriek_parent_id AND vrijstelling.structuur_rubriek_id = 'GebruikVrijstelling' AND vrijstelling.waarde_getal = 1) LEFT JOIN DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon ON (t_schenk_zaak.schenker_finr = t_persoon.finr); 
