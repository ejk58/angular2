/****************************************************
Copy Object Script for VIEW: p_inz_finr_woz_adresmutaties
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_finr_woz_adresmutaties AS LOCKING ROW FOR ACCESS SELECT * FROM DG_I_P_40ANA_INZ.p_inz_finr_woz_adresmutaties 
