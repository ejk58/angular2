DROP TABLE DG_I_P_40ANA_INZ.t_woz_object_hist;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.t_woz_object_hist,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   woz_objectnr VARCHAR(15) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
   ingang_d DATE FORMAT 'yyyy-mm-dd' NOT NULL,
   verval_d DATE FORMAT 'yyyy-mm-dd' NOT NULL,
   gebruikscode VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC COMPRESS ('recreatiewoning en overige woningen','woning dienend tot hoofdverblijf','niet-woning','sluimerend WOZ-object','terrein','boerderij','niet-woning deels in gebruik als woning','woning met praktijkruimte'),
   grondoppervlakte_m2 INTEGER NOT NULL,
   aanduiding VARCHAR(200) CHARACTER SET UNICODE NOT CASESPECIFIC,
   created_dt VARCHAR(30) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL COMPRESS '&dt. &ts.')
PRIMARY INDEX (woz_objectnr); 
