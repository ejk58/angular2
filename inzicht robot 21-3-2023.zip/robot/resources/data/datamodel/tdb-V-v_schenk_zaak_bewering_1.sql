REPLACE VIEW DG_I_P_40ANA_INZ.v_schenk_zaak_bewering_1 AS
  SELECT "v_schenk_zaak_bewering_1_2"."finr",
    "v_schenk_zaak_bewering_1_2"."ontvanger_finr",
    "v_schenk_zaak_bewering_1_2"."schenker_finr",
    "v_schenk_zaak_bewering_1_2"."ontvanger_naam",
    "v_schenk_zaak_bewering_1_2"."schenker_naam",
    "v_schenk_zaak_bewering_1_2"."schenking_d",
    "v_schenk_zaak_bewering_1_2"."jaar",
    "v_schenk_zaak_bewering_1_2"."aanslag_d",
    "v_schenk_zaak_bewering_1_2"."aanslagsoort",
    "v_schenk_zaak_bewering_1_2"."vrijstelling",
    "v_schenk_zaak_bewering_1_2"."rol_binnen_schenking",
    "v_schenk_zaak_bewering_1_2"."is_afgeschermd_ind"
    FROM DG_I_P_40ANA_INZ."v_schenk_zaak_bewering_1_2" AS v_schenk_zaak_bewering_1_2 UNION ALL
  SELECT "v_schenk_zaak_bewering_1_1"."finr",
    "v_schenk_zaak_bewering_1_1"."ontvanger_finr",
    "v_schenk_zaak_bewering_1_1"."schenker_finr",
    "v_schenk_zaak_bewering_1_1"."ontvanger_naam",
    "v_schenk_zaak_bewering_1_1"."schenker_naam",
    "v_schenk_zaak_bewering_1_1"."schenking_d",
    "v_schenk_zaak_bewering_1_1"."jaar",
    "v_schenk_zaak_bewering_1_1"."aanslag_d",
    "v_schenk_zaak_bewering_1_1"."aanslagsoort",
    "v_schenk_zaak_bewering_1_1"."vrijstelling",
    "v_schenk_zaak_bewering_1_1"."rol_binnen_schenking",
    "v_schenk_zaak_bewering_1_1"."is_afgeschermd_ind"
    FROM DG_I_P_40ANA_INZ."v_schenk_zaak_bewering_1_1" AS v_schenk_zaak_bewering_1_1; 
