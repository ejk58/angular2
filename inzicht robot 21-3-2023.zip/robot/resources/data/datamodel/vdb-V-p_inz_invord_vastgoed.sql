/****************************************************
Copy Object Script for VIEW: p_inz_invord_vastgoed
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_invord_vastgoed AS SELECT * FROM DG_I_P_40ANA_INZ.p_inz_invord_vastgoed 
