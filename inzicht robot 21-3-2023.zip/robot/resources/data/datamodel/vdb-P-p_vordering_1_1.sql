REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_1
  (
  IN finr VARCHAR(11),
  IN vordering_id VARCHAR(25)
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL betalingskenmerk,
    aanslagnr,
    aanslagnr_na_aangifte,
    kenteken,
    belasting_eur,
    heffingsrente_eur,
    boete_eur,
    revisierente_eur
      FROM DG_I_P_40ANA_INZ.v_vordering_1
      WHERE finr = :finr AND vordering_id = :vordering_id
      ORDER BY dagtekening_d desc,
      vordering_id;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_1 TO PUBLIC;
