CREATE JOIN INDEX DG_I_P_40ANA_INZ.t_dac6_disclosure_person_finr,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_dac6_disclosure_person.ROWID,DG_I_P_40ANA_INZ.t_dac6_disclosure_person.finr 
 FROM DG_I_P_40ANA_INZ.t_dac6_disclosure_person 
WHERE NOT (DG_I_P_40ANA_INZ.t_dac6_disclosure_person.finr IS NULL)
PRIMARY INDEX (finr); 
