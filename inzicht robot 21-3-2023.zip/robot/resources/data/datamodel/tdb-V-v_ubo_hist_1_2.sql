REPLACE VIEW DG_I_P_40ANA_INZ.v_ubo_hist_1_2 AS
  SELECT t_ubo_hist.persoon_id AS "finr",
    COALESCE(t_persoon.is_afgeschermd_ind,0) AS "is_afgeschermd_ind",
    t_ubo_hist.ingang_d,
    t_ubo_hist.verval_d,
    t_ubo_hist.bsn_tin,
    t_ubo_hist.bsn_ind,
    t_persoon.finr AS "rsin",
    t_ubo_hist.kvknr,
    t_persoon.naam AS "naam_onderneming",
    t_ubo_hist.naam AS "naam_ubo",
    t_ubo_hist.aard_belang,
    t_ubo_hist.aandeel_belang,
    t_ubo_hist.is_kvk_afgeschermd_ind,
    t_ubo_hist.adres,
    t_land.land AS "buitenland",
    
    CASE
      WHEN t_ubo_geb.gebeurtenis_d = CAST('9999-12-31' AS DATE) THEN CAST(NULL AS DATE) ELSE t_ubo_geb.gebeurtenis_d
    END AS "geboorte_d",
      t_ubo_geb_overlijden.gebeurtenis_d AS "overlijden_d",
      
    CASE
      WHEN t_maatschappelijke_act.ubo_gegevens_in_onderzoek_d IS NULL THEN 0 ELSE 1
    END AS "in_onderzoek_ind",
      CAST(
    CASE
      WHEN t_maatschappelijke_act.ubo_gegevens_in_onderzoek_d IS NOT NULL THEN 'In onderzoek <br>sinds: '|| CAST(CAST(t_maatschappelijke_act.ubo_gegevens_in_onderzoek_d AS DATE FORMAT 'DD-MM-YYYY') AS VARCHAR(10)) ELSE NULL
    END AS VARCHAR(40)) AS "in_onderzoek_tooltip"
    FROM DG_I_P_40ANA_INZ.T_UBO_HIST AS t_ubo_hist INNER JOIN DG_I_P_40ANA_INZ.T_MAATSCHAPPELIJKE_ACT AS t_maatschappelijke_act ON (t_maatschappelijke_act.kvknr = t_ubo_hist.kvknr) INNER JOIN DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon ON (t_persoon.finr = t_maatschappelijke_act.finr) LEFT JOIN DG_I_P_40ANA_INZ.T_UBO_GEBEURTENIS AS t_ubo_geb ON (t_ubo_hist.persoon_id = t_ubo_geb.persoon_id AND t_ubo_hist.kvknr = t_ubo_geb.kvknr AND t_ubo_geb.gebeurtenistype = 'Geboorte') LEFT JOIN DG_I_P_40ANA_INZ.T_LAND AS t_land ON (t_ubo_hist.buitenland_cd = t_land.land_cd) LEFT JOIN DG_I_P_40ANA_INZ.T_UBO_GEBEURTENIS AS t_ubo_geb_overlijden ON (t_ubo_hist.persoon_id = t_ubo_geb_overlijden.persoon_id AND t_ubo_hist.kvknr = t_ubo_geb_overlijden.kvknr AND t_ubo_geb_overlijden.gebeurtenistype = 'Overlijden') 
