REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_waarde_1_1
(
IN woz_objectnr varchar(12),
IN ingangsdatum date,
IN einddatum date
)
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for

SEL woz_objectnr,
  waardepeil_d,
  toestandspeil_d,
  ingangsdatum,
  einddatum,
  vastgestelde_waarde_eur,
  waarde_details,
  waarde_details_ind
FROM DG_I_P_50PRO_INZ.v_woz_object_waarde_1
WHERE woz_objectnr = :woz_objectnr
  AND ingangsdatum <= coalesce(:ingangsdatum,current_date)
  AND ingangsdatum <= coalesce(:einddatum,current_date)
  AND coalesce(:ingangsdatum,current_date) < einddatum
  AND einddatum < coalesce(:einddatum,current_date)
  OR
  woz_objectnr = :woz_objectnr
  AND ingangsdatum >= coalesce(:ingangsdatum,current_date)
  AND ingangsdatum <= coalesce(:einddatum,current_date)
  AND coalesce(:ingangsdatum,current_date) < einddatum
  AND einddatum < coalesce(:einddatum,current_date)  
  OR
  woz_objectnr = :woz_objectnr
  AND ingangsdatum >= coalesce(:ingangsdatum,current_date)
  AND ingangsdatum <= coalesce(:einddatum,current_date)
  AND coalesce(:ingangsdatum,current_date) < einddatum
  AND einddatum >= coalesce(:einddatum,current_date)  
  OR
  woz_objectnr = :woz_objectnr
  AND ingangsdatum <= coalesce(:ingangsdatum,current_date)
  AND ingangsdatum <= coalesce(:einddatum,current_date)
  AND coalesce(:ingangsdatum,current_date) < einddatum
  AND einddatum > coalesce(:einddatum,current_date)  
ORDER BY ingangsdatum desc;

open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_waarde_1_1 TO PUBLIC;
