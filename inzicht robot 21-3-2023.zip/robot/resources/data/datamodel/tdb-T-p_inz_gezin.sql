DROP TABLE DG_I_P_40ANA_INZ.p_inz_gezin;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_gezin,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   finr_relatie INTEGER,
   naam_relatie VARCHAR(512) CHARACTER SET UNICODE CASESPECIFIC,
   relatiesoort_bes VARCHAR(60) CHARACTER SET UNICODE CASESPECIFIC,
   fiscale_partner_ind SMALLINT,
   kind_ind SMALLINT,
   volwassene_ind SMALLINT,
   op_adres_20plus_ind SMALLINT,
   relatieisvip_ind BYTEINT,
   peil_d DATE FORMAT 'YY/MM/DD')
PRIMARY INDEX (finr,belastingjaar)
INDEX (finr_relatie); 
