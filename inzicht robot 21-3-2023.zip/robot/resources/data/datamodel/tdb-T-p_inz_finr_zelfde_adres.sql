DROP TABLE DG_I_P_40ANA_INZ.p_inz_finr_zelfde_adres;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_finr_zelfde_adres,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   adreskey INTEGER,
   adres VARCHAR(240) CHARACTER SET UNICODE CASESPECIFIC,
   ingangjaar SMALLINT NOT NULL,
   vervaljaar SMALLINT NOT NULL,
   finr_adresgenoot INTEGER,
   ingang_d DATE FORMAT 'YY/MM/DD',
   verval_d DATE FORMAT 'YY/MM/DD',
   naam_adresgenoot VARCHAR(512) CHARACTER SET UNICODE CASESPECIFIC,
   relatiesoort_bes VARCHAR(500) CHARACTER SET UNICODE CASESPECIFIC,
   geboorte_oprichting_d_adresgnt DATE FORMAT 'YY/MM/DD',
   overlijden_opheffing_d_adresgnt DATE FORMAT 'YY/MM/DD',
   adresgenootisvip_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
