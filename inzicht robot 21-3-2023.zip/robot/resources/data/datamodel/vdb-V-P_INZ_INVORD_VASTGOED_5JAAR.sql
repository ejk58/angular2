/****************************************************
Copy Object Script for VIEW: p_inz_invord_vastgoed_5jaar
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.P_INZ_INVORD_VASTGOED_5JAAR AS LOCKING ROW FOR ACCESS SELECT * FROM DG_I_P_40ANA_INZ.P_INZ_INVORD_VASTGOED_5JAAR; 
