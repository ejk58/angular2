/****************************************************
Copy Object Script for VIEW: p_inz_ob_omzet
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.P_INZ_OB_OMZET AS
SELECT * FROM DG_I_P_40ANA_INZ.P_INZ_OB_OMZET; 
