REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_1_2 AS 
SELECT cast(v_vpb_aangifte_bewering_1_1."rsin_aangegevene" AS varchar(11)) AS "finr",
 v_vpb_aangifte_bewering_1_1."rsin_aangegevene", v_vpb_aangifte_bewering_1_1."rsin_aangever",
 v_vpb_aangifte_bewering_1_1."aangifte_volgnummer", v_vpb_aangifte_bewering_1_1."tijdvak_begin_d",
 v_vpb_aangifte_bewering_1_1."tijdvak_eind_d" 
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_1_1" AS v_vpb_aangifte_bewering_1_1 
WHERE v_vpb_aangifte_bewering_1_1."rsin_aangegevene" <> v_vpb_aangifte_bewering_1_1."rsin_aangever" 
 AND v_vpb_aangifte_bewering_1_1."rsin_aangegevene" NOT LIKE '%_FE_VPB' 
