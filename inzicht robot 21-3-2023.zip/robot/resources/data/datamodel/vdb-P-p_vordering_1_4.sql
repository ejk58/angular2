REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_4
  (
  IN finr VARCHAR(11)
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL laatste_status AS laatste_status_label,
    laatste_status AS laatste_status_value,
    COUNT(finr) AS laatste_status_count
      FROM DG_I_P_40ANA_INZ.v_vordering_1
      WHERE finr = :finr
      GROUP BY laatste_status_label, laatste_status_value
      ORDER BY laatste_status_label;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_4 TO PUBLIC;
