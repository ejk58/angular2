REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_waarde_1 AS
   SELECT distinct
     t_woz_object_waarde.woz_objectnr,
     t_woz_object_waarde.bestaat_van_d AS "ingangsdatum",
     t_woz_object_waarde.bestaat_tot_d - 1 AS "einddatum",
     t_woz_object_waarde.waardepeil_d,
     t_woz_object_waarde.toestandspeil_d,
     t_woz_object_waarde.vastgestelde_waarde_eur,
     CASE WHEN t_woz_object_waarde.waarde_details IS NOT NULL THEN 
     'Deze waarde is gewijzigd n.a.v. een bezwaar, beroep en / of ambtshalve vermindering. Eerdere waarden waren: '|| t_woz_object_waarde.waarde_details 
     ELSE NULL 
     END AS "waarde_details",
     CASE WHEN t_woz_object_waarde.waarde_details IS NOT NULL THEN 1
     ELSE 0
     END AS "waarde_details_ind"
   FROM
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_WAARDE AS t_woz_object_waarde; 
