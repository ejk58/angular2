REPLACE VIEW DG_I_P_40ANA_INZ.v_fiscale_afspraak_geb_1_2 AS
  SELECT t_fiscale_afspraak_gebeurtenis.fiscale_afspraak_id,
    t_fiscale_afspraak_gebeurtenis.finr,
    t_fiscale_afspraak.vermoedelijke_schenking_d,
    t_fiscale_afspraak_gebeurtenis.gebeurtenis_d,
    t_fiscale_afspraak_gebeurtenis.gebeurtenis_type,
    t_fiscale_afspraak_gebeurtenis.besluit_ontvangst_d,
    t_fiscale_afspraak_gebeurtenis.verval_d,
    t_fiscale_afspraak_gebeurtenis.details
    FROM DG_I_P_40ANA_INZ.T_FISCALE_AFSPRAAK_GEBEURTENIS AS t_fiscale_afspraak_gebeurtenis LEFT JOIN DG_I_P_40ANA_INZ.T_FISCALE_AFSPRAAK AS t_fiscale_afspraak ON (t_fiscale_afspraak_gebeurtenis.fiscale_afspraak_id = t_fiscale_afspraak.fiscale_afspraak_id AND t_fiscale_afspraak_gebeurtenis.finr = t_fiscale_afspraak.finr) 
