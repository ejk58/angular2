REPLACE VIEW DG_I_P_40ANA_INZ.v_ubo_gebeurtenis_1_4 AS
   SELECT
     t_ubo_geb.persoon_id AS "finr",
     t_persoon.naam || ' (RSIN: ' || t_persoon.finr || ' / KVK: ' || t_ubo_geb.kvknr || ')' AS "persoon",
     t_persoon.is_afgeschermd_ind,
     t_ubo_geb.gebeurtenistype,
     t_ubo_geb.gebeurtenis_d,
     1 AS "is_significant_ind",
     CASE WHEN t_ubo_geb.gebeurtenistype in ('Toevoeging','Verwijdering') 
     THEN 
      '<span class="font-bold">Aard belang: </span>' || t_ubo_hist.aard_belang || coalesce(' (' || t_ubo_hist.aandeel_belang || ')','') 
     ELSE 
      t_ubo_hist.naam || ' is overleden.' 
     END AS "details",
     t_persoon.finr AS "finr_relatie"
   FROM
     DG_I_P_40ANA_INZ.T_UBO_GEBEURTENIS AS t_ubo_geb inner JOIN 
     DG_I_P_40ANA_INZ.T_MAATSCHAPPELIJKE_ACT AS t_maatschappelijke_act
      on
      (t_maatschappelijke_act.kvknr = t_ubo_geb.kvknr
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon
      on
      (t_persoon.finr = t_maatschappelijke_act.finr
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_UBO_HIST AS t_ubo_hist
      on
      (t_ubo_hist.persoon_id = t_ubo_geb.persoon_id
        AND t_ubo_hist.kvknr = t_ubo_geb.kvknr
        AND t_ubo_hist.ingang_d <= t_ubo_geb.gebeurtenis_d
        AND t_ubo_hist.verval_d >= t_ubo_geb.gebeurtenis_d)
   WHERE
     t_ubo_geb.gebeurtenistype IN ('Toevoeging','Verwijdering','Overlijden'); 
