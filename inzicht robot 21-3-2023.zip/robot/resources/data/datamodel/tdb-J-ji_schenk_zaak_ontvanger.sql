CREATE JOIN INDEX DG_I_P_40ANA_INZ.ji_schenk_zaak_ontvanger,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_schenk_zaak.ROWID,DG_I_P_40ANA_INZ.t_schenk_zaak.ontvanger_finr 
 FROM DG_I_P_40ANA_INZ.t_schenk_zaak 
PRIMARY INDEX (ontvanger_finr); 
