DROP TABLE DG_I_P_40ANA_INZ.p_inz_ob_invoer_xjaar;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ob_invoer_xjaar,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   subnummer SMALLINT,
   omschrijving VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
   peil0_jaar SMALLINT,
   peil0_eur DECIMAL(18,0),
   peil_1_eur DECIMAL(18,0),
   peil_2_eur DECIMAL(18,0),
   peil_3_eur DECIMAL(18,0),
   peil_4_eur DECIMAL(18,0),
   peil_5_eur DECIMAL(18,0),
   peil_6_eur DECIMAL(18,0),
   peil_7_eur DECIMAL(18,0),
   volgorde INTEGER,
   opmaak VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
   detail_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX (finr); 
