REPLACE VIEW DG_I_P_40ANA_INZ.v_klantbeeld_zoekresultaat_1 AS
    
   SELECT
     "v_klantbeeld_zoekresultaat_1_1"."zoeksleutel",
     "v_klantbeeld_zoekresultaat_1_1"."zoeksleuteltype",
     "v_klantbeeld_zoekresultaat_1_1"."subject_title",
     "v_klantbeeld_zoekresultaat_1_1"."label",
     "v_klantbeeld_zoekresultaat_1_1"."background_color",
     "v_klantbeeld_zoekresultaat_1_1"."name",
     "v_klantbeeld_zoekresultaat_1_1"."finr",
     "v_klantbeeld_zoekresultaat_1_1"."woz_objectnr",
     "v_klantbeeld_zoekresultaat_1_1"."initpageid"
   FROM
     DG_I_P_40ANA_INZ."v_klantbeeld_zoekresultaat_1_1" AS v_klantbeeld_zoekresultaat_1_1
   union all 
   SELECT
     "v_klantbeeld_zoekresultaat_1_2"."zoeksleutel",
     "v_klantbeeld_zoekresultaat_1_2"."zoeksleuteltype",
     "v_klantbeeld_zoekresultaat_1_2"."subject_title",
     "v_klantbeeld_zoekresultaat_1_2"."label",
     "v_klantbeeld_zoekresultaat_1_2"."background_color",
     "v_klantbeeld_zoekresultaat_1_2"."name",
     "v_klantbeeld_zoekresultaat_1_2"."finr",
     "v_klantbeeld_zoekresultaat_1_2"."woz_objectnr",
     "v_klantbeeld_zoekresultaat_1_2"."initpageid"
   FROM
     DG_I_P_40ANA_INZ."v_klantbeeld_zoekresultaat_1_2" AS v_klantbeeld_zoekresultaat_1_2
    
   union all 
   SELECT
     "v_klantbeeld_zoekresultaat_1_3"."zoeksleutel",
     "v_klantbeeld_zoekresultaat_1_3"."zoeksleuteltype",
     "v_klantbeeld_zoekresultaat_1_3"."subject_title",
     "v_klantbeeld_zoekresultaat_1_3"."label",
     "v_klantbeeld_zoekresultaat_1_3"."background_color",
     "v_klantbeeld_zoekresultaat_1_3"."name",
     "v_klantbeeld_zoekresultaat_1_3"."finr",
     "v_klantbeeld_zoekresultaat_1_3"."woz_objectnr",
     "v_klantbeeld_zoekresultaat_1_3"."initpageid"
   FROM
     DG_I_P_40ANA_INZ."v_klantbeeld_zoekresultaat_1_3" AS v_klantbeeld_zoekresultaat_1_3; 
