REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_2_1 AS 
SELECT t_vpb_structuur_element_1.structuur_id, t_vpb_structuur_element_1.onderdeel_id,
 t_vpb_structuur_element_1.rubriek_id, t_vpb_structuur_element_1.id AS "element_id",
 t_vpb_structuur_element_2.id AS "waarde_element_id", coalesce(t_vpb_structuur_element_2.horizontale_naam,
 t_vpb_structuur_element_2.verticale_naam) AS "waarde_element_naam",
 t_vpb_structuur_element_2.volgorde_in_elementenset AS "waarde_volgorde_in_elementenset" 
FROM DG_I_P_40ANA_INZ.T_VPB_STRUCTUUR_ELEMENT AS t_vpb_structuur_element_1 inner JOIN DG_I_P_40ANA_INZ.T_VPB_STRUCTUUR_ELEMENT AS t_vpb_structuur_element_2 
 on (t_vpb_structuur_element_2.structuur_id = t_vpb_structuur_element_1.structuur_id 
 AND t_vpb_structuur_element_2.onderdeel_id = t_vpb_structuur_element_1.onderdeel_id 
 AND t_vpb_structuur_element_2.rubriek_id = t_vpb_structuur_element_1.rubriek_id 
 AND t_vpb_structuur_element_2.verticale_positie = t_vpb_structuur_element_1.verticale_positie 
 AND t_vpb_structuur_element_2.is_multi_regel_ind = 1) 
WHERE t_vpb_structuur_element_1.is_multi_regel_ind = 1 
