REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_2_2 AS 
SELECT v_vpb_aangifte_bewering_2_1."structuur_id", v_vpb_aangifte_bewering_2_1."onderdeel_id",
 v_vpb_aangifte_bewering_2_1."element_id", v_vpb_aangifte_bewering_2_1."rubriek_id",
 max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 1 THEN v_vpb_aangifte_bewering_2_1."waarde_element_id" 
end) AS "waarde_1_element_id", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 1 THEN v_vpb_aangifte_bewering_2_1."waarde_element_naam" 
end) AS "waarde_1_element_naam", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 2 THEN v_vpb_aangifte_bewering_2_1."waarde_element_id" 
end) AS "waarde_2_element_id", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 2 THEN v_vpb_aangifte_bewering_2_1."waarde_element_naam" 
end) AS "waarde_2_element_naam", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 3 THEN v_vpb_aangifte_bewering_2_1."waarde_element_id" 
end) AS "waarde_3_element_id", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 3 THEN v_vpb_aangifte_bewering_2_1."waarde_element_naam" 
end) AS "waarde_3_element_naam", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 4 THEN v_vpb_aangifte_bewering_2_1."waarde_element_id" 
end) AS "waarde_4_element_id", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 4 THEN v_vpb_aangifte_bewering_2_1."waarde_element_naam" 
end) AS "waarde_4_element_naam", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 5 THEN v_vpb_aangifte_bewering_2_1."waarde_element_id" 
end) AS "waarde_5_element_id", max(
CASE 
 WHEN v_vpb_aangifte_bewering_2_1."waarde_volgorde_in_elementenset" = 5 THEN v_vpb_aangifte_bewering_2_1."waarde_element_naam" 
end) AS "waarde_5_element_naam" 
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_2_1" AS v_vpb_aangifte_bewering_2_1 
group by v_vpb_aangifte_bewering_2_1."structuur_id", v_vpb_aangifte_bewering_2_1."onderdeel_id",
 v_vpb_aangifte_bewering_2_1."rubriek_id", v_vpb_aangifte_bewering_2_1."element_id" 
