REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_persoon_2_1
(
IN finr varchar(64),
IN periode_begin_d date,
IN periode_eind_d date,
IN type_relatie_tot_woz_object varchar(24)

)
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for

SEL woz_objectnr,
  type_relatie_tot_bp AS wie,
  relatie_finr AS bsn,
  relatie_tot_woz_object_begin_d AS begindatum,
  relatie_tot_woz_object_eind_d AS einddatum,
 bestaat_van_kleiner_gelijk_ind,
 bestaat_van_kleiner_gelijk,
  aanduiding AS aanduiding,
  waarde_met_peildatum,
  waarde_details,
  waarde_details_ind,
  cast(greatest_begin_d AS varchar(10)),
  peildatum_text,
  currentside
FROM DG_I_P_40ANA_INZ.v_woz_object_persoon_2
WHERE finr = :finr
  AND periode_begin_d = coalesce(:periode_begin_d,current_date)
  AND periode_eind_d = coalesce(:periode_eind_d,current_date)
  AND type_relatie_tot_woz_object = :type_relatie_tot_woz_object
  AND type_relatie_tot_bp_id in (0,501,1004) 
ORDER BY relatie_finr, woz_objectnr, type_relatie_tot_woz_object,relatie_tot_woz_object_begin_d;

open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_persoon_2_1 TO PUBLIC;
