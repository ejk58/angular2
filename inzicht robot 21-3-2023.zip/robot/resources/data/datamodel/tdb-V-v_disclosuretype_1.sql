REPLACE VIEW DG_I_P_40ANA_INZ.v_disclosuretype_1 AS
   SELECT
     t_dac6_disclosure_person.finr,
     cast('DAC6' AS varchar(4)) AS "type",
     count(distinct t_dac6_disclosure_person.disclosure_id) AS "number_of_disclosures",
     MIN(CASE WHEN t_dac6_disclosure.disclosure_version_d > current_date - 90 THEN 'Ja' ELSE 'Nee' END) AS "disclosed_in_past_3_months"
   FROM
     DG_I_P_40ANA_INZ.T_DAC6_DISCLOSURE_PERSON AS t_dac6_disclosure_person inner JOIN 
     DG_I_P_40ANA_INZ.T_DAC6_DISCLOSURE AS t_dac6_disclosure
      on
      (
        t_dac6_disclosure_person.disclosure_id = t_dac6_disclosure.id
     )
   WHERE
     lower(t_dac6_disclosure_person.role_type) LIKE ANY ('relevanttaxpayer', 'affectedperson', 'associatedenterprise')
     AND t_dac6_disclosure_person.finr IS NOT NULL 
   group by
     t_dac6_disclosure_person.finr 
