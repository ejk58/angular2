DROP TABLE DG_I_P_40ANA_INZ.p_inz_ob_lev_kwartaal;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ob_lev_kwartaal,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   subnummer SMALLINT,
   belastingjaar SMALLINT,
   rubriek VARCHAR(100) CHARACTER SET UNICODE CASESPECIFIC,
   col_1_eur DECIMAL(12,0),
   col_2_eur DECIMAL(12,0),
   col_3_eur DECIMAL(12,0),
   col_4_eur DECIMAL(12,0),
   totaal_eur DECIMAL(12,0),
   col_1_corr_ind BYTEINT,
   col_2_corr_ind BYTEINT,
   col_3_corr_ind BYTEINT,
   col_4_corr_ind BYTEINT,
   niveau SMALLINT,
   volgorde INTEGER,
   opmaak VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   meeteenheid VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   sleutel INTEGER,
   parent INTEGER,
   created_dt TIMESTAMP(6),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr,belastingjaar,niveau,volgorde); 
