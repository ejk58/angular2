REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_vordering_gebeurtenis_1_4',), ("
  (
  IN finr VARCHAR(11),
  IN vordering_id VARCHAR(25)
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL omschrijving,
    dagtekening_d,
    gebeurtenis_d,
    open_bedrag_eur,
    open_kosten_eur,
    open_saldo_eur,
    CASE 
    WHEN volledig_afgeboekt_ind = 1 THEN 'large' ELSE 'small' END AS symbol_size,
    CASE
    WHEN volledig_afgeboekt_ind = 1 THEN U&'#2714' UESCAPE '#' ELSE null END AS symbol,
    CASE 
    WHEN row_number() over (ORDER BY gebeurtenis_d desc, volgordenr asc) = 1 THEN 'none' ELSE 'solid' END AS top_line,
    CASE 
    WHEN row_number() over (ORDER BY gebeurtenis_d asc, volgordenr desc) = 1 THEN 'none' ELSE 'solid' END AS bottom_line,    
    CAST(gebeurtenis_d AS DATE FORMAT 'YYYY-MM-DD') || volgordenr AS event_id
      FROM DG_I_P_40ANA_INZ.v_vordering_gebeurtenis_1
      WHERE finr = :finr AND vordering_id = :vordering_id
      ORDER BY gebeurtenis_dt DESC,
        volgordenr DESC;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_vordering_gebeurtenis_1_4 TO PUBLIC;
