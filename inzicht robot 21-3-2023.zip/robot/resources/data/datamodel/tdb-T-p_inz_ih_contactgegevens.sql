DROP TABLE DG_I_P_40ANA_INZ.p_inz_ih_contactgegevens;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ih_contactgegevens,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   gegevensjaar_consulent SMALLINT,
   naam_consulent VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   becon_nr INTEGER,
   telefoonnummer_consulent VARCHAR(20) CHARACTER SET UNICODE CASESPECIFIC,
   becon_verval_d DATE FORMAT 'YY/MM/DD',
   gegevensjaar_bp SMALLINT,
   telefoonnummer_bp VARCHAR(20) CHARACTER SET UNICODE CASESPECIFIC,
   voornamen_bp VARCHAR(765) CHARACTER SET UNICODE CASESPECIFIC,
   aanschrijfnaam_bp VARCHAR(1536) CHARACTER SET UNICODE CASESPECIFIC,
   gegevensjaar_vertegenwoordiger SMALLINT,
   telefoonnummer_vertegenwoordiger VARCHAR(20) CHARACTER SET UNICODE CASESPECIFIC,
   naam_vertegenwoordiger VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   naam_bewindvoerder VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   adres_bewindvoerder VARCHAR(180) CHARACTER SET UNICODE CASESPECIFIC,
   postcode_plaats_bewindvoerder VARCHAR(180) CHARACTER SET UNICODE CASESPECIFIC,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
