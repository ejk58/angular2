REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_vordering_gebeurtenis_1_2',), ("
  (
  IN finr VARCHAR(11),
  IN vordering_id VARCHAR(25)
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL gebeurtenis_d,
    CAST(gebeurtenis_d AS DATE FORMAT 'YYYY-MM-DD') || volgordenr AS event_id
      FROM DG_I_P_40ANA_INZ.v_vordering_gebeurtenis_1
      WHERE finr = :finr AND vordering_id = :vordering_id
      ORDER BY gebeurtenis_dt DESC,
        volgordenr DESC;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_vordering_gebeurtenis_1_2 TO PUBLIC;
