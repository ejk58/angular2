REPLACE VIEW DG_I_P_50PRO_INZ.p_inz_risicobeheersing AS LOCKING ROW FOR ACCESS SELECT * FROM DG_I_P_40ANA_INZ.p_inz_risicobeheersing 
