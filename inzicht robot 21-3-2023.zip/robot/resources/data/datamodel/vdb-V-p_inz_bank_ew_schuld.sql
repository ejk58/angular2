/****************************************************
Copy Object Script for VIEW: p_inz_bank_ew_schuld
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_bank_ew_schuld AS
SELECT * FROM DG_I_P_40ANA_INZ.p_inz_bank_ew_schuld; 
