/****************************************************
Copy Object Script for VIEW: p_inz_ih_ew
****************************************************/
 
CREATE VIEW DG_I_P_50PRO_INZ.P_INZ_IH_EW AS SELECT * FROM DG_I_P_40ANA_INZ.P_INZ_IH_EW; 
