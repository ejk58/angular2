REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_2',), ("
  (
  IN finr VARCHAR(11),
  IN middelen VARCHAR(50),
  IN adviezen VARCHAR(64),
  IN laatste_statussen VARCHAR(50),
  IN openstaande_vorderingen INT
 )
  DYNAMIC RESULT SETS 1
  BEGIN 
    DECLARE c1 CURSOR WITH RETURN ONLY TO CLIENT FOR
    SEL aanslagnr_compact,
   middel,
   vorderingstype,
 vordering_id,
   periode,
   tijdvak_cd,
   dagtekening_d,
   vordering_verval_d,
   advies,
   laatste_status,
 is_openstaand_ind,
   vordering_eur,
   kenteken,
   bedrag_open_eur,
   kosten_open_eur,
   verrekend_af_eur,
   betaald_af_eur,
   verminderd_af_eur,
   oninbaar_af_eur,
   invord_rente_af_eur
      FROM DG_I_P_40ANA_INZ.v_vordering_1
      WHERE finr = :finr
        AND (COALESCE(:middelen,'') = ''
      OR instr(:middelen||',',middel||',') > 0)
        AND (COALESCE(:adviezen,'') = ''
      OR instr(:adviezen||',',advies||',') > 0)
        AND (COALESCE(:laatste_statussen,'') = ''
      OR instr(:laatste_statussen||',',laatste_status||',') > 0)
        AND (COALESCE(:openstaande_vorderingen,'') = ''
      OR instr(:openstaande_vorderingen||',',is_openstaand_ind||',') > 0)
      ORDER BY dagtekening_d DESC,
       vordering_id;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_vordering_1_2 TO PUBLIC;
