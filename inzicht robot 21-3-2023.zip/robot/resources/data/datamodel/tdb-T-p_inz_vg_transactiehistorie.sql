DROP TABLE DG_I_P_40ANA_INZ.p_inz_vg_transactiehistorie;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_vg_transactiehistorie,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   objectnr VARCHAR(30) CHARACTER SET UNICODE CASESPECIFIC,
   niveau BYTEINT,
   volgorde DECIMAL(20,0),
   sleutel DECIMAL(20,0),
   parent DECIMAL(20,0),
   periode VARCHAR(25) CHARACTER SET UNICODE CASESPECIFIC,
   finr_eigenaar INTEGER,
   naam_eigenaar VARCHAR(1536) CHARACTER SET UNICODE CASESPECIFIC,
   aandeel_eigenaar SMALLINT,
   relatie_beschrijving VARCHAR(100) CHARACTER SET UNICODE CASESPECIFIC,
   op_adres_jn VARCHAR(3) CHARACTER SET UNICODE CASESPECIFIC,
   verkoopbedrag_eur DECIMAL(12,0),
   meer_kadastrale_objecten_ind BYTEINT,
   eigenaarisvip_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   aankoopbedrag_eur DECIMAL(12,0),
   transactie_d DATE FORMAT 'YY/MM/DD')
PRIMARY INDEX (finr,objectnr); 
