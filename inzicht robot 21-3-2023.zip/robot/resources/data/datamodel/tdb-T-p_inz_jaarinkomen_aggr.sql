DROP TABLE DG_I_P_40ANA_INZ.p_inz_jaarinkomen_aggr;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_jaarinkomen_aggr,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   peil0_jr INTEGER,
   ontvanger VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
   peil0_eur DECIMAL(15,2),
   peil_1_eur DECIMAL(15,2),
   peil_2_eur DECIMAL(15,2),
   peil_3_eur DECIMAL(15,2),
   peil_4_eur DECIMAL(15,2),
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
