/****************************************************
Copy Object Script for VIEW: p_inz_kvk_functionaris
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.P_INZ_KVK_FUNCTIONARIS AS LOCKING ROW FOR ACCESS SELECT * FROM DG_I_P_40ANA_INZ.P_INZ_KVK_FUNCTIONARIS; 
