/****************************************************
Copy Object Script for VIEW: p_inz_ob_invoer_detail
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_ob_invoer_detail AS
SELECT 
   finr,
   subnummer,
   leverancier,
   land,
   goederencode,
   douane_waarde_eur,
   ob_waarde_eur,
   goederenprijs_eur,
   brutomassa,
   nettomassa,
   omschrijving,
   invoer_maand,
   jaar,
   tijdvakcode,
   tijdvak_bes,
   tijdvak,
   ob_tv_maand,
   volgorde,
   opmaak,
   created_dt,
   releasenr
FROM DG_I_P_40ANA_INZ.p_inz_ob_invoer_detail; 
