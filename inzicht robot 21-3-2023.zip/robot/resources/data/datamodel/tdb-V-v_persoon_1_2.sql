REPLACE VIEW DG_I_P_40ANA_INZ.v_persoon_1_2 AS 
SELECT v_persoon_1_1."rsin_aangever", v_persoon_1_1."volgnummer" 
FROM DG_I_P_40ANA_INZ."v_persoon_1_1" AS v_persoon_1_1 
WHERE 1 = 1 
qualify row_number() over (partition by v_persoon_1_1."rsin_aangever" 
ORDER BY v_persoon_1_1."volgnummer" desc) <= 10 
