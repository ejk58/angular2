DROP TABLE DG_I_P_40ANA_INZ.p_inz_finr_relaties_verhaal;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_finr_relaties_verhaal,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   relatiesoort INTEGER,
   relatiesoort_bes VARCHAR(180) CHARACTER SET UNICODE CASESPECIFIC,
   finr_relatie INTEGER,
   ingang_d DATE FORMAT 'YY/MM/DD',
   verval_d DATE FORMAT 'YY/MM/DD',
   naam VARCHAR(1536) CHARACTER SET UNICODE CASESPECIFIC,
   leeftijd_jr INTEGER,
   inkomen_maand_eur INTEGER,
   verhaal_vt_eur INTEGER,
   banktegoeden_eur DECIMAL(11,0),
   motorrijtuigen_eur DECIMAL(11,0),
   roerende_zaken_eur DECIMAL(11,0),
   open_massaal_eur DECIMAL(18,0),
   open_beginfase_eur DECIMAL(18,0),
   open_beslag_eur DECIMAL(18,0),
   open_uitstel_eur DECIMAL(18,0),
   open_insolventie_eur DECIMAL(18,0),
   relatie_is_vip_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   verhaalsmogelijkheden_ind BYTEINT,
   schulden_ind BYTEINT)
PRIMARY INDEX (finr); 
