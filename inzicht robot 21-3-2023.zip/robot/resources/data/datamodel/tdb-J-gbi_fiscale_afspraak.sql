CREATE JOIN INDEX DG_I_P_40ANA_INZ.gbi_fiscale_afspraak,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_fiscale_afspraak.ROWID,DG_I_P_40ANA_INZ.t_fiscale_afspraak.finr 
 FROM DG_I_P_40ANA_INZ.t_fiscale_afspraak 
PRIMARY INDEX (finr); 
