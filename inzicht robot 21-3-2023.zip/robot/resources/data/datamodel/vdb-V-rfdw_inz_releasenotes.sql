/****************************************************
Copy Object Script for VIEW: rfdw_inz_releasenotes
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.rfdw_inz_releasenotes AS LOCKING ROW FOR ACCESS SELECT * FROM DG_I_P_40ANA_INZ.rfdw_inz_releasenotes 
