REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_hist_1_1
(
IN woz_objectnr varchar(12),
IN periode_begin_d date, 
IN periode_eind_d date
)
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for

SEL woz_objectnr, 
 datum_begin_geldigheid_object,
 bestaat_van_kleiner_gelijk_ind,
    bestaat_van_kleiner_gelijk,
 datum_eind_geldigheid_object,
 aanduiding,
 null AS aanduiding_hist,
 0 AS bevat_aanduiding_hist_ind,
 gebruikscode,
 null AS gebruikscode_hist,
 0 AS bevat_gebruikscode_hist_ind,
 grondoppervlakte,
 null AS grondoppervlakte_hist,
 0 AS bevat_grondoppervlakte_hist_ind
FROM DG_I_P_40ANA_INZ.v_woz_object_hist_1
WHERE woz_objectnr = :woz_objectnr
 AND eind_d = coalesce(:periode_eind_d,current_date)
 AND begin_d = coalesce(:periode_begin_d,current_date);

open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_hist_1_1 TO PUBLIC;
