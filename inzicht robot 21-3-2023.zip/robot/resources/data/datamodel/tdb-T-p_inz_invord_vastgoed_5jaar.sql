DROP TABLE DG_I_P_40ANA_INZ.p_inz_invord_vastgoed_5jaar;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_invord_vastgoed_5jaar,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   saldo_hypotheek_eur DECIMAL(13,0),
   woz_waarde_eur DECIMAL(13,0),
   created_dt TIMESTAMP(6),
   releasenr VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX (finr); 
