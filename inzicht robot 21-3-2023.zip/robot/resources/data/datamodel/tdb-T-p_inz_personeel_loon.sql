DROP TABLE DG_I_P_40ANA_INZ.p_inz_personeel_loon;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_personeel_loon,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   jaar_kwartaal INTEGER,
   aantal_personeel INTEGER,
   loonaangifte_eur DECIMAL(15,0),
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(7) CHARACTER SET UNICODE CASESPECIFIC COMPRESS '2019.11')
PRIMARY INDEX (finr); 
