REPLACE VIEW DG_I_P_40ANA_INZ.v_fiscale_afspraak_geb_1_3 AS
  SELECT v_fiscale_afspraak_geb_1_2."fiscale_afspraak_id",
    v_fiscale_afspraak_geb_1_2."finr",
    v_fiscale_afspraak_geb_1_2."vermoedelijke_schenking_d",
    v_fiscale_afspraak_geb_1_2."gebeurtenis_d",
    v_fiscale_afspraak_geb_1_2."gebeurtenis_type",
    v_fiscale_afspraak_geb_1_2."besluit_ontvangst_d",
    v_fiscale_afspraak_geb_1_2."verval_d",
    v_fiscale_afspraak_geb_1_2."details"
    FROM DG_I_P_40ANA_INZ."v_fiscale_afspraak_geb_1_2" AS v_fiscale_afspraak_geb_1_2 UNION ALL
  SELECT v_fiscale_afspraak_geb_1_1."fiscale_afspraak_id",
    v_fiscale_afspraak_geb_1_1."finr",
    v_fiscale_afspraak_geb_1_1."vermoedelijke_schenking_d",
    v_fiscale_afspraak_geb_1_1."gebeurtenis_d",
    v_fiscale_afspraak_geb_1_1."gebeurtenis_type",
    v_fiscale_afspraak_geb_1_1."besluit_ontvangst_d",
    v_fiscale_afspraak_geb_1_1."verval_d",
    v_fiscale_afspraak_geb_1_1."details"
    FROM DG_I_P_40ANA_INZ."v_fiscale_afspraak_geb_1_1" AS v_fiscale_afspraak_geb_1_1 
