REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_persoon_1 AS
   SELECT
     t_woz_object_persoon.woz_objectnr,
     t_persoon_hist.finr,
     t_persoon_hist.naam,
     t_woz_object_persoon.type_relatie_tot_woz_object,
     t_woz_object_persoon.bestaat_van_d AS "begin_d",
     CASE WHEN year(t_woz_object_persoon.bestaat_tot_d) = 9999 THEN null ELSE (t_woz_object_persoon.bestaat_tot_d - 1) END AS "eind_d",
     least(eind_d."datum",t_woz_object_persoon.bestaat_tot_d) AS "peil_d",
     begin_d."datum" AS "periode_begin_d",
     eind_d."datum" AS "periode_eind_d",
     CASE WHEN t_woz_object_persoon.bestaat_van_d = '2011-01-01' OR t_woz_object_persoon.bestaat_van_d = '2009-01-01' THEN 1 
     ELSE 0 
     END AS "bestaat_van_kleiner_gelijk_ind",
     'Data beschikbaar vanaf ' || 
     CASE WHEN t_woz_object_persoon.bestaat_van_d = '2009-01-01' OR t_woz_object_persoon.bestaat_van_d = '2011-01-01' THEN to_char(t_woz_object_persoon.bestaat_van_d, 'DD-MM-YYYY') 
     ELSE NULL 
     END AS "bestaat_van_kleiner_gelijk",
     t_persoon.is_afgeschermd_ind
   FROM
     DG_I_P_40ANA_INZ."t_datum" AS begin_d cross JOIN 
     DG_I_P_40ANA_INZ."t_datum" AS eind_d inner JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_PERSOON AS t_woz_object_persoon
      on
      (
        t_woz_object_persoon.bestaat_van_d < eind_d."datum"
        AND t_woz_object_persoon.bestaat_tot_d > begin_d."datum"
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_PERSOON_HIST AS t_persoon_hist
      on
      (
        t_persoon_hist.finr = t_woz_object_persoon.finr
        AND t_persoon_hist.ingang_d <= least(eind_d."datum",t_woz_object_persoon.bestaat_tot_d)
        AND t_persoon_hist.verval_d > least(eind_d."datum",t_woz_object_persoon.bestaat_tot_d)
     )inner JOIN 
     DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon
      on
      (
        t_persoon.finr = t_woz_object_persoon.finr
     ); 
