REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_persoonsadres_1_1',), ("
  (
  IN finr VARCHAR(11),
  IN jaar INT
 )
  DYNAMIC RESULT SETS 1
  BEGIN
    DECLARE c1 CURSOR WITH RETURN ONLY FOR
    SEL finr,
      adres,
      persoonsadressoort AS adressoort,
      greatest(bestaat_van_d,
      CAST(CAST(:jaar - 30 AS CHAR(4)) || '-01-01' AS DATE),CAST('2001-01-01' AS DATE)) AS ingang_d,
      
      CASE
        WHEN EXTRACT(YEAR
      FROM bestaat_tot_d) = 9999 THEN CAST(NULL AS DATE) ELSE bestaat_tot_d
      END AS eind_d,
        
      CASE
        WHEN ingang_d = greatest(CAST(CAST(:jaar - 30 AS CHAR(4)) || '-01-01' AS DATE),CAST('2001-01-01' AS DATE))
      THEN 1 ELSE 0
      END AS kleiner_gelijk_ind
      FROM DG_I_P_40ANA_INZ.v_persoonsadres_1
      WHERE finr = :finr
        AND bestaat_tot_d > CAST(CAST(:jaar - 30 AS CHAR(4)) || '-01-01' AS DATE)
        AND persoonsadressoort_cd IN ('1','2','7')
        AND is_natuurlijk_persoon_ind = 1
      ORDER BY bestaat_tot_d DESC;
    OPEN c1;
  END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_persoonsadres_1_1 TO PUBLIC;
