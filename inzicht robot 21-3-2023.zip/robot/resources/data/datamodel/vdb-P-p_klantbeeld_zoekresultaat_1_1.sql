REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_klantbeeld_zoekresultaat_1_1',), (" (IN zoeksleutel varchar(15), IN zoeksleuteltype varchar(32))
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for
SEL subject_title, 
  label,
  background_color,
  name,
  finr,
  woz_objectnr AS wozobjectNr,
  initpageid AS initPageId
FROM DG_I_P_40ANA_INZ.v_klantbeeld_zoekresultaat_1
WHERE lower(oreplace(:zoeksleutel,' ','')) = zoeksleutel
AND zoeksleuteltype = :zoeksleuteltype;
open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_klantbeeld_zoekresultaat_1_1 TO PUBLIC;
