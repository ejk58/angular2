DROP TABLE DG_I_P_40ANA_INZ.p_inz_erf_relatie;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_erf_relatie,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   finr_relatie INTEGER,
   naam VARCHAR(512) CHARACTER SET UNICODE NOT CASESPECIFIC,
   leeftijd_relatie INTEGER,
   geboortedatum_relatie_d DATE FORMAT 'yyyy-mm-dd',
   graad SMALLINT,
   overlijdensdatum_relatie_d DATE FORMAT 'yyyy-mm-dd',
   type_relatie VARCHAR(130) CHARACTER SET UNICODE NOT CASESPECIFIC,
   verworpen_ind BYTEINT,
   ingang_d DATE FORMAT 'yyyy-mm-dd',
   verval_d DATE FORMAT 'yyyy-mm-dd',
   hetzelfde_adres_ind BYTEINT,
   highlight_ind BYTEINT,
   volgorde SMALLINT,
   reden_einde_beeindigen_relatie VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
   vip_ind BYTEINT,
   relatieisvip_ind BYTEINT,
   created_dt CHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL COMPRESS '&dt. &ts.     ',
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
