DROP TABLE DG_I_P_40ANA_INZ.p_inz_igu_renseignementen;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_igu_renseignementen,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar INTEGER,
   naam_betaler VARCHAR(210) CHARACTER SET UNICODE NOT CASESPECIFIC,
   inkomenscategorie_cd INTEGER,
   inkomenscategorie_oms VARCHAR(165) CHARACTER SET UNICODE NOT CASESPECIFIC,
   begindatumgeldigheid_d DATE FORMAT 'yyyy-mm-dd',
   einddatumgeldigheid_d DATE FORMAT 'yyyy-mm-dd',
   landnaam VARCHAR(210) CHARACTER SET UNICODE NOT CASESPECIFIC,
   brutobedrag_bdr DECIMAL(21,0),
   valutacodebrutobedrag VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC,
   bedraginhouding_bdr DECIMAL(21,0),
   valutainhouding VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC,
   brutobedrag_eur DECIMAL(21,0),
   bedraginhouding_eur DECIMAL(21,0),
   wisselkoers DECIMAL(8,4),
   widget VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
   volgorde INTEGER,
   volgnummer INTEGER,
   opmaak VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
   sleutel INTEGER,
   parent INTEGER,
   niveau INTEGER,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
