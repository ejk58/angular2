REPLACE VIEW DG_I_P_40ANA_INZ.v_persoonsrelatie_1_1 AS 
SELECT t_persoonsrelatie_hoofd_bron.bronpersoon_id AS "finr", t_adres_hoofd.adresregel_1 AS "finr_woonadres_regel_1",
 t_adres_hoofd.adresregel_2 AS "finr_woonadres_regel_2", t_adres_hoofd.adresregel_3 AS "finr_woonadres_regel_3",
 CASE 
 WHEN t_persoonsrelatie_hoofd_bron.bronpersoon_id = t_persoonsrelatie_hoofd_bron."doelpersoon_id" THEN 'Is erflater' 
 ELSE t_persoonsrelatiesrt_hoofd_bron.beschrijving || ' erflater' 
END AS "finr_bron_relsrt_beschrijving", t_persoonsrelatie_hoofd_bron.doelpersoon_id AS "bron_bsn",
 t_persoon_bron.naam AS "bron_naam", 100 AS "bron_icoontype",
 (cast(coalesce(t_persoon_bron.bestaat_tot_d,current_date) AS integer) - cast(t_persoon_bron.bestaat_van_d AS integer))/10000 AS "bron_leeftijd",
 CASE 
 WHEN t_persoon_bron.bestaat_tot_d is null THEN 0 
 ELSE 1 
END AS "bron_is_overleden_ind", t_persoon_bron.is_afgeschermd_ind AS "bron_is_afgeschermd_ind",
 CASE 
 WHEN t_persoonsadres_bron.adres_id is null THEN 0 
 ELSE 1 
END AS "bron_woont_op_zelfde_adres_ind", coalesce(t_persoonsrelatie_hoofd_bron.doel_is_mogelijke_erfgenaam_ind,
 0) AS "bron_is_mogelijke_erfgenaam_ind", coalesce(t_persoonsrelatie_hoofd_bron.doel_heeft_erfenis_verworpen_ind,
 0) AS "bron_heeft_erfenis_verworpen_ind", min(
CASE 
 WHEN t_persoonsrelatie_bron_doel.relatiesoort_id = 2010 THEN 1004 
 ELSE t_persoonsrelatie_bron_doel.relatiesoort_id 
end) AS "bron_doel_relsrt_id", t_persoonsrelatie_bron_doel.doelpersoon_id AS "doel_bsn" 
FROM DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS t_persoonsrelatie_hoofd_bron inner JOIN DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS t_persoonsrelatie_bron_doel 
 on (t_persoonsrelatie_bron_doel.bronpersoon_id = t_persoonsrelatie_hoofd_bron.doelpersoon_id 
 AND t_persoonsrelatie_bron_doel.relatiesoort_id IN (0,1,501,2010)) inner JOIN DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS t_persoonsrelatie_hoofd_doel 
 on (t_persoonsrelatie_hoofd_doel.bronpersoon_id = t_persoonsrelatie_hoofd_bron.bronpersoon_id 
 AND t_persoonsrelatie_hoofd_doel.doelpersoon_id = t_persoonsrelatie_bron_doel.doelpersoon_id 
 AND (t_persoonsrelatie_hoofd_doel.relatiesoort_id = 0 
 OR (t_persoonsrelatie_hoofd_doel.relatiesoort_id >= 2000 
 AND t_persoonsrelatie_hoofd_doel.relatiesoort_id <= 2024))) inner JOIN DG_I_P_40ANA_INZ.T_PERSOONSRELATIESOORT AS t_persoonsrelatiesrt_hoofd_bron 
 on (t_persoonsrelatiesrt_hoofd_bron.id = t_persoonsrelatie_hoofd_bron.relatiesoort_id) inner JOIN DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon_hoofd 
 on (t_persoon_hoofd.finr = t_persoonsrelatie_hoofd_bron.bronpersoon_id) inner JOIN DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon_bron 
 on (t_persoon_bron.finr = t_persoonsrelatie_hoofd_bron.doelpersoon_id) left JOIN DG_I_P_40ANA_INZ.T_PERSOONSADRES AS t_persoonsadres_hoofd 
 on (t_persoonsadres_hoofd.finr = t_persoonsrelatie_hoofd_bron.bronpersoon_id 
 AND t_persoonsadres_hoofd.persoonsadressoort_cd = '1' 
 AND t_persoonsadres_hoofd.bestaat_van_d <= coalesce(t_persoon_hoofd.bestaat_tot_d,
 date '9999-12-31') 
 AND t_persoonsadres_hoofd.bestaat_tot_d >= coalesce(t_persoon_hoofd.bestaat_tot_d + 1,
 date '9999-12-31')) left JOIN DG_I_P_40ANA_INZ.T_PERSOONSADRES AS t_persoonsadres_bron 
 on (t_persoonsadres_bron.finr = t_persoonsrelatie_hoofd_bron.doelpersoon_id 
 AND t_persoonsadres_bron.adres_id = t_persoonsadres_hoofd.adres_id 
 AND t_persoonsadres_bron.persoonsadressoort_cd = t_persoonsadres_hoofd.persoonsadressoort_cd 
 AND t_persoonsadres_bron.bestaat_van_d <= coalesce(t_persoon_hoofd.bestaat_tot_d,
 date '9999-12-31') 
 AND t_persoonsadres_bron.bestaat_tot_d >= coalesce(t_persoon_hoofd.bestaat_tot_d + 1,
 date '9999-12-31')) left JOIN DG_I_P_40ANA_INZ.T_ADRES AS t_adres_hoofd 
 on (t_adres_hoofd.adres_id = t_persoonsadres_hoofd.adres_id) 
WHERE t_persoonsrelatie_hoofd_bron.relatiesoort_id = 0 
 OR (t_persoonsrelatie_hoofd_bron.relatiesoort_id >= 2000 
 AND t_persoonsrelatie_hoofd_bron.relatiesoort_id <= 2024) 
group by t_persoonsrelatie_hoofd_bron.bronpersoon_id, "finr_woonadres_regel_1",
 "finr_woonadres_regel_2", "finr_woonadres_regel_3", "finr_bron_relsrt_beschrijving",
 "bron_bsn", "bron_naam", "bron_icoontype", "bron_leeftijd", "bron_is_overleden_ind",
 "bron_is_afgeschermd_ind", "bron_woont_op_zelfde_adres_ind",
 "bron_is_mogelijke_erfgenaam_ind", "bron_heeft_erfenis_verworpen_ind",
 "doel_bsn" 
