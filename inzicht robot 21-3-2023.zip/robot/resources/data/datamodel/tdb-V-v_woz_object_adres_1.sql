REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_adres_1 AS
   SELECT distinct
     t_woz_object_adres.woz_objectnr,
     t_woz_object_adres.bestaat_van_d,
     t_woz_object_adres.bestaat_tot_d,
     t_woz_object_adres.straatnaam || ' ' ||t_woz_object_adres.huisnummer || ', ' 
     ||t_woz_object_adres.postcode || ' ' || t_woz_object_adres.woonplaats AS "adres",
     CASE WHEN t_woz_object_adres.bestaat_van_d = '2011-01-01' OR t_woz_object_adres.bestaat_van_d = '2009-01-01' THEN 1
     ELSE 0
     END AS "bestaat_van_kleiner_gelijk_ind",
     'Data beschikbaar vanaf ' || 
     CASE WHEN t_woz_object_adres.bestaat_van_d = '2009-01-01' OR t_woz_object_adres.bestaat_van_d = '2011-01-01' THEN to_char(t_woz_object_adres.bestaat_van_d, 'DD-MM-YYYY')
     ELSE NULL 
     END AS "bestaat_van_kleiner_gelijk"
   FROM
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_ADRES AS t_woz_object_adres 
