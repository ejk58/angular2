DROP TABLE DG_I_P_40ANA_INZ.p_inz_vervoersmiddelen_5jaar;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_vervoersmiddelen_5jaar,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   cataloguswaarde_eur DECIMAL(11,0),
   executiewaarde_eur DECIMAL(11,0),
   executiewaarde_groep_cd BYTEINT,
   motorrijtuigen_type VARCHAR(150) CHARACTER SET UNICODE CASESPECIFIC,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
