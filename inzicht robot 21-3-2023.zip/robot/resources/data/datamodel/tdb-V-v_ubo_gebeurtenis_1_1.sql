REPLACE VIEW DG_I_P_40ANA_INZ.v_ubo_gebeurtenis_1_1 AS
   SELECT
     t_persoonsrelatie.bronpersoon_id AS "finr",
     t_ubo_hist.naam || ' (' || t_ubo_hist.persoon_id || ')' AS "persoon",
     coalesce(t_persoon.is_afgeschermd_ind,0) AS "is_afgeschermd_ind",
     CAST('Wijziging' AS VARCHAR(64)) AS "gebeurtenistype",
     t_ubo_hist.ingang_d AS "gebeurtenis_d",
     CASE WHEN (t_ubo_hist.buitenland_cd is not null AND t_ubo_hist_prev.buitenland_cd is null)
      OR t_ubo_hist.aard_belang <> t_ubo_hist_prev.aard_belang
      OR t_ubo_hist.aandeel_belang <> t_ubo_hist_prev.aandeel_belang
      OR t_ubo_hist.is_kvk_afgeschermd_ind <> t_ubo_hist_prev.is_kvk_afgeschermd_ind
     THEN 1
     ELSE 0
     END AS "is_significant_ind",
     SUBSTR(
     CASE WHEN t_ubo_hist.aard_belang <> t_ubo_hist_prev.aard_belang 
      OR t_ubo_hist.aandeel_belang <> t_ubo_hist_prev.aandeel_belang
     THEN '<br><br><span class="font-bold">Aard belang oud: </span>' || t_ubo_hist_prev.aard_belang || 
      COALESCE(' (' || t_ubo_hist_prev.aandeel_belang || ')','') || 
      '<br><span class="font-bold">Aard belang nieuw : </span>' || t_ubo_hist.aard_belang || 
      COALESCE(' (' || t_ubo_hist.aandeel_belang || ')','')
     ELSE '' 
     END ||
     CASE WHEN t_ubo_hist.is_kvk_afgeschermd_ind <> t_ubo_hist_prev.is_kvk_afgeschermd_ind  
     THEN '<br><br><span class="font-bold">Is afgeschermd oud: </span>' || CASE WHEN t_ubo_hist.is_kvk_afgeschermd_ind = 1 THEN 'Ja' ELSE 'Nee' END || 
      '<br><span class="font-bold">Is afgeschermd nieuw: </span>' || CASE WHEN t_ubo_hist.is_kvk_afgeschermd_ind = 1 THEN 'Ja' ELSE 'Nee' END  
     ELSE '' 
     END ||
     CASE WHEN t_ubo_hist.naam <> t_ubo_hist_prev.naam  
     THEN '<br><br><span class="font-bold">Naam oud: </span>' || t_ubo_hist_prev.naam || 
      '<br><span class="font-bold">Naam nieuw: </span>' || t_ubo_hist.naam  
     ELSE '' 
     END ||
     CASE WHEN t_ubo_hist.adres <> t_ubo_hist_prev.adres  
     THEN '<br><br><span class="font-bold">Adres oud: </span>' || t_ubo_hist_prev.adres || 
      '<br><span class="font-bold">Adres nieuw: </span>' || t_ubo_hist.adres  
     ELSE ''
     END
    ,9) AS "details",
     t_ubo_hist.persoon_id AS "finr_relatie"
   FROM
     DG_I_P_40ANA_INZ.T_PERSOONSRELATIE AS t_persoonsrelatie inner JOIN 
     DG_I_P_40ANA_INZ.T_UBO_HIST AS t_ubo_hist
      on
      (t_ubo_hist.persoon_id = t_persoonsrelatie.doelpersoon_id
        AND t_ubo_hist.ingang_d >= t_persoonsrelatie.bestaat_van_d
        AND t_ubo_hist.verval_d <= t_persoonsrelatie.bestaat_tot_d
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_UBO_HIST AS t_ubo_hist_prev
      on
      (t_ubo_hist_prev.persoon_id = t_ubo_hist.persoon_id
        AND t_ubo_hist_prev.kvknr = t_ubo_hist.kvknr
        AND t_ubo_hist_prev.verval_d = t_ubo_hist.ingang_d
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_MAATSCHAPPELIJKE_ACT AS t_maatschappelijke_act
      on
      (t_maatschappelijke_act.kvknr = t_ubo_hist.kvknr
        AND t_maatschappelijke_act.finr = t_persoonsrelatie.bronpersoon_id
     ) left JOIN 
     DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon on
      (t_persoon.finr = t_persoonsrelatie.doelpersoon_id)
   WHERE t_persoonsrelatie.relatiesoort_id = 1231; 
