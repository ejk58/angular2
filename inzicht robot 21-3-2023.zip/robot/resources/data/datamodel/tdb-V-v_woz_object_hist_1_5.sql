REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_hist_1_5 AS
   SELECT
     t_woz_object.woz_objectnr,
     t_begin."datum" AS "begin_d",
     t_eind."datum" AS "eind_d",
     t_woz_object_hist.aanduiding,
     t_woz_object.bestaat_van_d AS "datum_begin_geldigheid_object",
     CASE WHEN t_woz_object.bestaat_tot_d = date '9999-12-31' THEN null ELSE t_woz_object.bestaat_tot_d END AS "datum_eind_geldigheid_object",
     UPPER(SUBSTR(t_woz_object_hist.gebruikscode,1,1))|| SUBSTR(t_woz_object_hist.gebruikscode,2,49) AS "gebruikscode",
     substring(cast(XMLAGG('<br>' || cast(v_woz_object_hist_1_2."ingang_d" AS format 'DD-MM-YYYY') || ': ' || UPPER(SUBSTR(v_woz_object_hist_1_2."gebruikscode",1,1))
     || SUBSTR(v_woz_object_hist_1_2."gebruikscode",2,49) ORDER BY v_woz_object_hist_1_2."ingang_d") AS varchar(2000)),5) AS "gebruikscode_hist",
     CASE WHEN gebruikscode_hist is not null THEN 1 ELSE 0 END AS "bevat_gebruikscode_hist_ind",
     t_woz_object_waarde.vastgestelde_waarde_eur AS "woz_waarde",
     t_woz_object_hist.grondoppervlakte_m2 AS "grondoppervlakte",
     eind_d AS "peil_d"
   FROM
     DG_I_P_40ANA_INZ."t_datum" AS t_begin cross JOIN 
     DG_I_P_40ANA_INZ."t_datum" AS t_eind cross JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT AS t_woz_object inner JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_HIST AS t_woz_object_hist
      on
      (
        t_woz_object_hist.woz_objectnr = t_woz_object.woz_objectnr
        AND t_woz_object_hist.ingang_d <= t_eind."datum"
        AND t_woz_object_hist.verval_d > t_eind."datum"
     ) left JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_WAARDE AS t_woz_object_waarde
      on
      (
        t_woz_object_waarde.woz_objectnr = t_woz_object.woz_objectnr
        AND t_woz_object_waarde.bestaat_van_d <= t_eind."datum"
        AND t_woz_object_waarde.bestaat_tot_d > t_eind."datum"
     ) left JOIN 
     DG_I_P_40ANA_INZ."v_woz_object_hist_1_2" AS v_woz_object_hist_1_2
      on
      (
        v_woz_object_hist_1_2."woz_objectnr" = t_woz_object.woz_objectnr
        AND v_woz_object_hist_1_2."verval_d_next" >= t_begin."datum"
        AND v_woz_object_hist_1_2."ingang_d" <= t_eind."datum"
     )
   group by
     t_woz_object.woz_objectnr,
     t_begin."datum",
     t_eind."datum",
     t_woz_object.bestaat_van_d,
     t_woz_object.bestaat_tot_d,
     t_woz_object_hist.gebruikscode,
     t_woz_object_waarde.vastgestelde_waarde_eur,
     "peil_d",
     t_woz_object_hist.grondoppervlakte_m2,
     t_woz_object_hist.aanduiding; 
