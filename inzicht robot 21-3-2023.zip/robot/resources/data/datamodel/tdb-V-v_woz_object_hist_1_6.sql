REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_hist_1_6 AS
   SELECT
     t_woz_object.woz_objectnr,
     t_begin."datum" AS "begin_d",
     t_eind."datum" AS "eind_d",
     substring(cast(XMLAGG('<br>' || cast(v_woz_object_hist_1_4."ingang_d" AS format 'DD-MM-YYYY') || ': ' || cast(v_woz_object_hist_1_4."grondoppervlakte_m2" AS varchar(10)) || ' m?' ORDER BY v_woz_object_hist_1_4."ingang_d")
     AS varchar(2000)),5) AS "grondoppervlakte_hist",
     CASE WHEN grondoppervlakte_hist is not null THEN 1 ELSE 0 END AS "bevat_grondoppervlakte_hist_ind"
   FROM
     DG_I_P_40ANA_INZ."t_datum" AS t_begin cross JOIN 
     DG_I_P_40ANA_INZ."t_datum" AS t_eind cross JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT AS t_woz_object inner JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_HIST AS t_woz_object_hist
      on
      (
        t_woz_object_hist.woz_objectnr = t_woz_object.woz_objectnr
        AND t_woz_object_hist.ingang_d <= t_eind."datum"
        AND t_woz_object_hist.verval_d > t_eind."datum"
     ) left JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_WAARDE AS t_woz_object_waarde
      on
      (
        t_woz_object_waarde.woz_objectnr = t_woz_object.woz_objectnr
        AND t_woz_object_waarde.bestaat_van_d <= t_eind."datum"
        AND t_woz_object_waarde.bestaat_tot_d > t_eind."datum"
     ) left JOIN 
     DG_I_P_40ANA_INZ."v_woz_object_hist_1_4" AS v_woz_object_hist_1_4
      on
      (
        v_woz_object_hist_1_4."woz_objectnr" = t_woz_object.woz_objectnr
        AND v_woz_object_hist_1_4."verval_d_prev" >= t_begin."datum"
        AND v_woz_object_hist_1_4."ingang_d" <= t_eind."datum"
     )
   group by
     t_woz_object.woz_objectnr,
     t_eind."datum",
     t_woz_object.bestaat_van_d,
     t_woz_object.bestaat_tot_d,
     t_woz_object_hist.gebruikscode,
     t_woz_object_waarde.vastgestelde_waarde_eur,
     t_woz_object_hist.grondoppervlakte_m2,
     t_begin."datum",
     t_woz_object.aanduiding; 
