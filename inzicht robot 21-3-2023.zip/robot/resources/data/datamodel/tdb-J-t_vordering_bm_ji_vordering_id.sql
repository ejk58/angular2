CREATE JOIN INDEX DG_I_P_40ANA_INZ.t_vordering_bm_ji_vordering_id,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_vordering_bedragsmutatie.ROWID,DG_I_P_40ANA_INZ.t_vordering_bedragsmutatie.vordering_id 
 FROM DG_I_P_40ANA_INZ.t_vordering_bedragsmutatie 
PRIMARY INDEX (vordering_id); 
