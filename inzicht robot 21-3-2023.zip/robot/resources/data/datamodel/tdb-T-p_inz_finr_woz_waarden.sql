DROP TABLE DG_I_P_40ANA_INZ.p_inz_finr_woz_waarden;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_finr_woz_waarden,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr DECIMAL(11,0),
   finr_relatie INTEGER,
   relatie_code VARCHAR(30) CHARACTER SET UNICODE CASESPECIFIC,
   woz_objectnr DECIMAL(12,0),
   object_bes VARCHAR(500) CHARACTER SET UNICODE CASESPECIFIC,
   peil0_jaar SMALLINT,
   peil1_eur DECIMAL(12,0),
   peil0_eur DECIMAL(12,0),
   peil_1_eur DECIMAL(12,0),
   peil_2_eur DECIMAL(12,0),
   peil_3_eur DECIMAL(12,0),
   peil_4_eur DECIMAL(12,0),
   peil_5_eur DECIMAL(12,0),
   peil_6_eur DECIMAL(12,0),
   peil_7_eur DECIMAL(12,0),
   peil_8_eur DECIMAL(12,0),
   peil_9_eur DECIMAL(12,0),
   variatie_ind BYTEINT,
   volgnummer INTEGER,
   relatieisvip_ind BYTEINT,
   actueel_ind BYTEINT,
   overleden_ind BYTEINT,
   overleden_info_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr)
INDEX (finr,woz_objectnr); 
