DROP TABLE DG_I_P_40ANA_INZ.p_inz_vpb_fiscale_winst;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_vpb_fiscale_winst,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   onderneming_sleutel SMALLINT,
   naam_ondern_recent VARCHAR(256) CHARACTER SET UNICODE CASESPECIFIC,
   belastingjaar SMALLINT,
   fiscale_winst_eur DECIMAL(18,0),
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(7) CHARACTER SET UNICODE CASESPECIFIC COMPRESS '2019.43')
PRIMARY INDEX (finr); 
