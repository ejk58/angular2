REPLACE VIEW DG_I_P_40ANA_INZ.v_persoon_1_4 AS 
SELECT t_persoon.finr, t_persoon.finr AS "rsin_aangegevene", CAST(coalesce(t_persoon.naam || ' ',
 '') || '(' || t_persoon.finr || ')' AS VARCHAR(256)) AS "naam",
 2 AS "volgorde" 
FROM DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon 
