REPLACE VIEW DG_I_P_40ANA_INZ.v_klantbeeld_zoekresultaat_1_3 AS
   SELECT
     distinct lower(oreplace(t_woz_object_adres.postcode || t_woz_object_adres.huisnummer,'-','')) AS "zoeksleutel",
     'postcodehuisnr' AS "zoeksleuteltype",
     t_woz_object.woz_objectnr AS "subject_title",
     'WOZ-objectnr' AS "label",
     '#A90061' AS "background_color",
     t_woz_object.aanduiding AS "name",
     cast(null AS varchar(11)) AS "finr",
     t_woz_object.woz_objectnr,
     cast('vastgoed-wozdetails' AS varchar(20)) AS "initpageid"
   FROM
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT AS t_woz_object inner JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_ADRES AS t_woz_object_adres
      on
      (
        t_woz_object.woz_objectnr = t_woz_object_adres.woz_objectnr
     ); 
