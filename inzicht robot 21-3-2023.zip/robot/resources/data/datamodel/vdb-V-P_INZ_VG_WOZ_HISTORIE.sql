/****************************************************
Copy Object Script for VIEW: p_inz_vg_woz_historie
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.P_INZ_VG_WOZ_HISTORIE AS
SELECT * FROM DG_I_P_40ANA_INZ.P_INZ_VG_WOZ_HISTORIE; 
