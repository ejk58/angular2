DROP TABLE DG_I_P_40ANA_INZ.p_inz_bank_ew_schuld;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_bank_ew_schuld,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   finr_relatie INTEGER,
   relatie_code VARCHAR(30) CHARACTER SET UNICODE CASESPECIFIC,
   belastingjaar SMALLINT,
   rekeningnummer VARCHAR(50) CHARACTER SET UNICODE CASESPECIFIC,
   saldo_eur DECIMAL(12,2),
   type_lening VARCHAR(100) CHARACTER SET UNICODE CASESPECIFIC,
   bank VARCHAR(500) CHARACTER SET UNICODE CASESPECIFIC,
   rente_eur DECIMAL(9,2),
   ingangsdatum DATE FORMAT 'YY/MM/DD',
   einddatum DATE FORMAT 'YY/MM/DD',
   annuitair VARCHAR(5) CHARACTER SET UNICODE CASESPECIFIC,
   andere_rekeninghouders VARCHAR(100) CHARACTER SET UNICODE CASESPECIFIC,
   vip_ind BYTEINT,
   relatieisvip_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   boeterente_eur DECIMAL(9,2))
PRIMARY INDEX (finr,belastingjaar)
INDEX (belastingjaar); 
