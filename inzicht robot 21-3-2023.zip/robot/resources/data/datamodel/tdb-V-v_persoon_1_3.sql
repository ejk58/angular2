REPLACE VIEW DG_I_P_40ANA_INZ.v_persoon_1_3 AS 
SELECT distinct v_persoon_1_2."rsin_aangever" AS "finr", t_vpb_aangifte_pers_relatie.rsin_aangegevene,
 CAST(
CASE 
 WHEN t_vpb_aangifte_pers_relatie.rsin_aangegevene like '%_FE_VPB' THEN 'Fiscale eenheid' 
 ELSE coalesce(t_persoon.naam || ' ','') || '(' || t_persoon.finr || ')' 
END AS VARCHAR(256)) AS "naam", CAST(
CASE 
 WHEN t_vpb_aangifte_pers_relatie.rsin_aangegevene like '%_FE_VPB' THEN 1 
 ELSE 3 
END AS SMALLINT) AS "volgorde" 
FROM DG_I_P_40ANA_INZ."v_persoon_1_2" AS v_persoon_1_2 inner JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_PERS_RELATIE AS t_vpb_aangifte_pers_relatie 
 on (t_vpb_aangifte_pers_relatie.rsin_aangever = v_persoon_1_2."rsin_aangever" 
 AND t_vpb_aangifte_pers_relatie.aangifte_volgnummer = v_persoon_1_2."volgnummer") left JOIN DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon 
 on (t_vpb_aangifte_pers_relatie.rsin_aangegevene = t_persoon.finr) 
WHERE t_vpb_aangifte_pers_relatie.rsin_aangever <> t_vpb_aangifte_pers_relatie.rsin_aangegevene 
