REPLACE VIEW DG_I_P_50PRO_INZ.v_woz_object_persoon_2 AS 
LOCKING ROW FOR ACCESS 
SELECT * 
FROM DG_I_P_40ANA_INZ.v_woz_object_persoon_2 ; 
