DROP TABLE DG_I_P_40ANA_INZ.p_inz_ent_relaties_actueel;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ent_relaties_actueel,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   entiteitnr INTEGER,
   is_np_ind BYTEINT,
   np_nnp VARCHAR(3) CHARACTER SET UNICODE CASESPECIFIC,
   concernstructuur_ind BYTEINT,
   finr_relatie INTEGER,
   entiteitnr_relatie INTEGER,
   relatiesoort INTEGER,
   type_relatie VARCHAR(60) CHARACTER SET UNICODE CASESPECIFIC,
   naam_relatie VARCHAR(512) CHARACTER SET UNICODE CASESPECIFIC,
   geboorte_oprichting_d_relatie DATE FORMAT 'YY/MM/DD',
   overlijden_opheffing_d_relatie DATE FORMAT 'YY/MM/DD',
   in_entiteit_vanaf_d_relatie DATE FORMAT 'YY/MM/DD',
   vestiging_plaats_relatie VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   perc_betrokkenheid SMALLINT,
   rechtsvorm VARCHAR(60) CHARACTER SET UNICODE CASESPECIFIC,
   rechtsvorm_soort SMALLINT,
   is_fe_vpb_ind SMALLINT,
   is_fe_ob_ind SMALLINT,
   grafisch_jn VARCHAR(6) CHARACTER SET UNICODE NOT CASESPECIFIC,
   tooltip_grafisch VARCHAR(200) CHARACTER SET UNICODE NOT CASESPECIFIC,
   convenant VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
   relatieisvip_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (entiteitnr)
INDEX (entiteitnr,relatiesoort); 
