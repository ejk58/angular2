/****************************************************
Copy Object Script for VIEW: p_inz_ob_invoer_kwartaal
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_ob_invoer_kwartaal AS
  SELECT 
   finr,
   subnummer,
   omschrijving,
   belastingjaar,
   q1_eur,
   q2_eur,
   q3_eur,
   q4_eur,
   opmaak,
   volgorde,
   detail_ind,
   created_dt,
   releasenr
FROM DG_I_P_40ANA_INZ.p_inz_ob_invoer_kwartaal; 
