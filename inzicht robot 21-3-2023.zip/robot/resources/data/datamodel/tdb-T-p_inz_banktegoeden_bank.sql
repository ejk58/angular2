DROP TABLE DG_I_P_40ANA_INZ.p_inz_banktegoeden_bank;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_banktegoeden_bank,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   valutajaar SMALLINT,
   naam_instelling VARCHAR(500) CHARACTER SET UNICODE CASESPECIFIC,
   rekening_soort VARCHAR(32) CHARACTER SET UNICODE CASESPECIFIC,
   aantal_rekeningen INTEGER,
   saldo_eur DECIMAL(18,0),
   rente_eur DECIMAL(18,0),
   invorderbaar_bedrag_eur DECIMAL(18,0),
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
