DROP TABLE DG_I_P_40ANA_INZ.p_inz_ew_transacties;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_ew_transacties,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   woz_objectnr DECIMAL(14,0),
   vervreemdingsd_d DATE FORMAT 'YY/MM/DD',
   vervreemdings_moment VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   overwaarde_eur DECIMAL(18,0),
   _parent SMALLINT,
   sleutel SMALLINT,
   niveau SMALLINT,
   volgorde SMALLINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
