/****************************************************
Copy Object Script for VIEW: p_inz_ob_verw_kwartaal
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_ob_verw_kwartaal AS 
SELECT
   finr,
   subnummer,
   belastingjaar,
   rubriek,
   col_1_eur,
   col_2_eur,
   col_3_eur,
   col_4_eur,
   col_1_corr_ind,
   col_2_corr_ind,
   col_3_corr_ind,
   col_4_corr_ind,
   niveau,
   volgorde,
   opmaak,
   meeteenheid,
   sleutel,
   parent,
   created_dt,
   releasenr
FROM 
  DG_I_P_40ANA_INZ.p_inz_ob_verw_kwartaal; 
