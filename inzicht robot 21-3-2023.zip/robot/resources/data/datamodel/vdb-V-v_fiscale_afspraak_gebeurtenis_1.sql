REPLACE VIEW DG_I_P_50PRO_INZ.v_fiscale_afspraak_gebeurtenis_1 AS 
LOCKING ROW FOR ACCESS 
SELECT * 
FROM DG_I_P_40ANA_INZ.v_fiscale_afspraak_gebeurtenis_1 
