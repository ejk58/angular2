DROP TABLE DG_I_P_40ANA_INZ.t_woz_object_waarde;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.t_woz_object_waarde,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   woz_objectnr VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
   bestaat_van_d DATE FORMAT 'yyyy-mm-dd' NOT NULL,
   bestaat_tot_d DATE FORMAT 'yyyy-mm-dd' NOT NULL,
   waardepeil_d DATE FORMAT 'yyyy-mm-dd' NOT NULL,
   toestandspeil_d DATE FORMAT 'yyyy-mm-dd' NOT NULL,
   vastgestelde_waarde_eur DECIMAL(18,0) NOT NULL,
   waarde_details VARCHAR(300) CHARACTER SET UNICODE NOT CASESPECIFIC,
   created_dt VARCHAR(30) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL COMPRESS '&dt. &ts.')
PRIMARY INDEX (woz_objectnr); 
