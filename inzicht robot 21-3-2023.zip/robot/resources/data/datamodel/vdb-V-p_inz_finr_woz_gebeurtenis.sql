/****************************************************
Copy Object Script for VIEW: p_inz_finr_woz_gebeurtenis
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_finr_woz_gebeurtenis AS 
SELECT * 
FROM DG_I_P_40ANA_INZ.p_inz_finr_woz_gebeurtenis; 
