REPLACE VIEW DG_I_P_40ANA_INZ.v_fiscale_afspraak_gebeurtns_1_1 AS 
SELECT t_fiscale_afspraak_gebeurtenis.finr,
 MAX(COALESCE(t_fiscale_afspraak_gebeurtenis.fiscale_afspraak_id,CAST(t_fiscale_afspraak_gebeurtenis.aanleiding_d AS VARCHAR(25)))) AS "fiscale_afspraak_id", 
 100 * dense_rank() over (partition by t_fiscale_afspraak_gebeurtenis.finr ORDER BY t_fiscale_afspraak_gebeurtenis.aanleiding_d desc) AS "volgorde", 
 MAX(1) AS "niveau" FROM DG_I_P_40ANA_INZ.T_FISCALE_AFSPRAAK_GEBEURTENIS AS t_fiscale_afspraak_gebeurtenis 
 group by t_fiscale_afspraak_gebeurtenis.finr, t_fiscale_afspraak_gebeurtenis.aanleiding_d 
