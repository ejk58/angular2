DROP TABLE DG_I_P_40ANA_INZ.p_inz_row_pgb_inkomst;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_row_pgb_inkomst,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   budgethouder VARCHAR(512) CHARACTER SET UNICODE NOT CASESPECIFIC,
   finr_budgethouder INTEGER,
   finr_budgethouder_hidden INTEGER,
   relatiesoort_bes VARCHAR(60) CHARACTER SET UNICODE NOT CASESPECIFIC,
   peil0_jaar SMALLINT,
   peil1_eur DECIMAL(12,0),
   peil0_eur DECIMAL(12,0),
   peil_1_eur DECIMAL(12,0),
   peil_2_eur DECIMAL(12,0),
   peil_3_eur DECIMAL(12,0),
   peil_4_eur DECIMAL(12,0),
   peil_5_eur DECIMAL(12,0),
   peil_6_eur DECIMAL(12,0),
   peil_7_eur DECIMAL(12,0),
   peil_8_eur DECIMAL(12,0),
   volgorde INTEGER,
   opmaak VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
   sleutel INTEGER,
   parent INTEGER,
   niveau SMALLINT,
   budgethouderisvip_ind BYTEINT,
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   created_dt TIMESTAMP(0))
PRIMARY INDEX (finr); 
