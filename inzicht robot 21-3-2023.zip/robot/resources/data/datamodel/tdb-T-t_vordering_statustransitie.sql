DROP TABLE DG_I_P_40ANA_INZ.t_vordering_statustransitie;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.t_vordering_statustransitie,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   vordering_id VARCHAR(25) CHARACTER SET UNICODE CASESPECIFIC NOT NULL,
   finr VARCHAR(11) CHARACTER SET UNICODE CASESPECIFIC NOT NULL,
   nieuwe_status_oms VARCHAR(50) CHARACTER SET UNICODE CASESPECIFIC NOT NULL COMPRESS ('Diversen','Aanmaning','Aanmaning ontvanger','Beslag roerend goed','Besluit Breed Moratorium','blokkade aangebracht','Beslag opdracht','Beslag onder derden','Beslag onroerend goed','is dit iets van BVB?','BVB WAARSCHUWING','CBT gestopt','CBT gestart','Dwangbevel deurwaarder','Dwangbevel bedrijfsvereniging','D? blokkering','Dynamisch Monitoren','Dwangbevel massaal','Dwangbevel vervallen','Faillissement','Faillissementsvordering','Geweigerde overschrijving Bank','Herhaalde beslag opdracht','Herrinering','??','Kortlopend uitstel','Loonvordering','Natuurlijke personen minnelijke schuldsanering','Overheidsvordering gestopt','Overheidsvordering gestart','Oninbaar','Ontvanger','Voorstel oninbaar lijden','Oninbaarlijden terugdraaien','Overheidsvordering','Internationale invordering - uitgaand verzoek','Schuldsanering natuurlijke personen','Antwoord ontvangen verzoek rekeningnummer','Verzoek rekeningnummer','Herhaald verzoek rekeningnummer ','Uitstel verleend','Uitstel verl i.v.m. ingediend bezw- of beroepschr','Uitstel vervallen','Uitstel i.v.m. Corona ','Is dit uitval?','Tenuitvoerlegging vervallen','Uitstel/betalingsregeling toeslagen','Uitstel i.v.m. verzoek om afschrijving','Vordering','Verzoek om afschrijving','Executoriale verkoop roerende zaken','Verjaard','Vordering onder bank ','Vordering onder derden ','Voorlopige teruggaaf'),
   belasting_open_eur DECIMAL(16,2) NOT NULL,
   boete_open_eur DECIMAL(16,2) NOT NULL,
   heffingsrente_open_eur DECIMAL(16,2) NOT NULL,
   revisierente_open_eur DECIMAL(16,2) NOT NULL,
   kosten_open_eur DECIMAL(16,2) NOT NULL,
   rente_open_eur DECIMAL(16,2) NOT NULL,
   dagtekening_d DATE FORMAT 'YY/MM/DD',
   statustransitie_dt TIMESTAMP(6) NOT NULL,
   volgordenr SMALLINT,
   created_dt VARCHAR(30) CHARACTER SET UNICODE CASESPECIFIC COMPRESS '22-10-2021 12:49:21')
PRIMARY INDEX (finr); 
