DROP TABLE DG_I_P_40ANA_INZ.p_inz_invord_maand_vt;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_invord_maand_vt,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   aantal_objecten INTEGER,
   waarde_eur DECIMAL(18,0),
   waarde_partner_eur DECIMAL(18,0),
   verhaalswaarde_totaal_eur DECIMAL(18,0),
   verhaalswaarde_bp_eur DECIMAL(18,0),
   verhaalswaarde_partner_eur DECIMAL(18,0),
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC)
PRIMARY INDEX (finr); 
