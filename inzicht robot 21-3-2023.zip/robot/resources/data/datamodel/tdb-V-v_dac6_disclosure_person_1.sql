REPLACE VIEW DG_I_P_40ANA_INZ.v_dac6_disclosure_person_1 AS
   SELECT
     t_dac6_disclosure_person.disclosure_id,
     CASE WHEN lower(t_dac6_disclosure_person.role_type) like ('associatedenterprise') 
         THEN CAST('RelevantTaxPayer' AS VARCHAR(20)) 
         ELSE t_dac6_disclosure_person.role_type END AS "role_type",
     CAST(t_dac6_disclosure_person.id AS INT) AS "id",
     CAST(t_dac6_disclosure_person.associated_taxpayer_id AS INT) AS "parent_id",
     CASE WHEN lower(t_dac6_disclosure_person.role_type) like ('associatedenterprise') 
         THEN 2 
         ELSE 1 END AS "niveau",
     CAST(t_dac6_disclosure_person.id AS INT) AS "volgorde",
     CASE WHEN lower(t_dac6_disclosure_person.role_type) like ('associatedenterprise') 
         THEN CAST(null AS VARCHAR(200))
         ELSE t_dac6_disclosure_person.name END AS "name",
     CASE WHEN lower(t_dac6_disclosure_person.role_type) like ('associatedenterprise') 
         THEN CAST(null AS VARCHAR(400))
         ELSE 
         '<b>Name:</b> '    || coalesce(t_dac6_disclosure_person.name,'N/A') || '<br>' || 
              '<b>TIN:</b> '    || coalesce(t_dac6_disclosure_person.tin,'N/A')  || '<br>' || 
              '<b>Issued by:</b> '    || coalesce(t_dac6_disclosure_person.tin_issued_by,'N/A')  || '<br>' || 
              '<b>Street:</b> '     || coalesce(t_dac6_disclosure_person.street_house_identifier,'N/A') || '<br>' || 
              '<b>Postal Code:</b> '    || coalesce(t_dac6_disclosure_person.post_cd,'N/A') || '<br>' || 
              '<b>City:</b> '     || coalesce(t_dac6_disclosure_person.city,'N/A')  || '<br>' || 
              '<b>Email Address:</b> '      || coalesce(t_dac6_disclosure_person.email_address,'N/A')  || '<br>' || 
              '<b>Country:</b> '    || coalesce(t_dac6_disclosure_person.country_cd,'N/A')  || '<br>' || 
              '<b>Residing Country:</b> '    || coalesce(t_dac6_disclosure_person.residing_countries,'N/A') END AS "additional_information",
     CASE WHEN lower(t_dac6_disclosure_person.role_type) like ('associatedenterprise') 
         THEN CAST(null AS VARCHAR(200))
         ELSE t_dac6_disclosure_person.tin END AS "tin",
     CASE WHEN lower(t_dac6_disclosure_person.role_type) like ('associatedenterprise') 
         THEN 0
         ELSE
         CASE WHEN t_dac6_disclosure_person.country_cd = 'NL' AND t_dac6_disclosure_person.tin is not null THEN 1 
              ELSE 0 
              END
         END AS "dutch_tin_ind",
     t_dac6_disclosure_person.taxpayer_implementing_d,
     CASE WHEN lower(t_dac6_disclosure_person.role_type) like ('associatedenterprise') 
         THEN t_dac6_disclosure_person.name 
         ELSE CAST(null AS VARCHAR(200)) END AS "associated_enterprise_name",
     CASE WHEN lower(t_dac6_disclosure_person.role_type) like ('associatedenterprise') 
         THEN 
         '<b>Name:</b> '    || coalesce(t_dac6_disclosure_person.name,'N/A') || '<br>' || 
              '<b>TIN:</b> '    || coalesce(t_dac6_disclosure_person.tin,'N/A')  || '<br>' || 
              '<b>Issued by:</b> '    || coalesce(t_dac6_disclosure_person.tin_issued_by,'N/A')  || '<br>' || 
              '<b>Street:</b> '     || coalesce(t_dac6_disclosure_person.street_house_identifier,'N/A') || '<br>' || 
              '<b>Postal Code:</b> '    || coalesce(t_dac6_disclosure_person.post_cd,'N/A') || '<br>' || 
              '<b>City:</b> '     || coalesce(t_dac6_disclosure_person.city,'N/A')  || '<br>' || 
              '<b>Email Address:</b> '      || coalesce(t_dac6_disclosure_person.email_address,'N/A')  || '<br>' || 
              '<b>Country:</b> '    || coalesce(t_dac6_disclosure_person.country_cd,'N/A')  || '<br>' || 
              '<b>Residing Country:</b> '    || coalesce(t_dac6_disclosure_person.residing_countries,'N/A')
     ELSE
     CAST(null AS VARCHAR(200)) END AS "associated_enterprise_info",
     t_dac6_disclosure_person.affectedperson_ind,
     t_dac6_disclosure_person.capacity
   FROM
     DG_I_P_40ANA_INZ.T_DAC6_DISCLOSURE_PERSON AS t_dac6_disclosure_person inner JOIN 
     DG_I_P_40ANA_INZ.T_DAC6_DISCLOSURE AS t_dac6_disclosure
      on
      (
        t_dac6_disclosure_person.disclosure_id = t_dac6_disclosure.id
     )
   WHERE
     lower(t_dac6_disclosure_person.role_type) LIKE ANY ('relevanttaxpayer','intermediary','affectedperson','associatedenterprise') 
