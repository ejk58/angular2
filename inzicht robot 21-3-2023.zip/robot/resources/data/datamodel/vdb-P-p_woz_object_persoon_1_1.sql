REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_persoon_1_1
(
IN type_relatie_tot_woz_object varchar(24),
IN woz_objectnr varchar(12),
IN begin_d date,
IN eind_d date
)
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for

SEL naam AS naam_gebruiker,
  finr AS bsn,
  begin_d AS begindatum,
  eind_d AS einddatum,
  peil_d AS peildatum,
 bestaat_van_kleiner_gelijk_ind,
 bestaat_van_kleiner_gelijk,
 is_afgeschermd_ind
FROM DG_I_P_40ANA_INZ.v_woz_object_persoon_1
WHERE type_relatie_tot_woz_object = :type_relatie_tot_woz_object
  AND woz_objectnr = :woz_objectnr
  AND periode_begin_d = coalesce(:begin_d,current_date)
  AND periode_eind_d = coalesce(:eind_d,current_date) 
ORDER BY finr, begin_d desc;
open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_persoon_1_1 TO PUBLIC;
