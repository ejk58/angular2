REPLACE VIEW DG_I_P_40ANA_INZ.v_woz_object_hist_1_1 AS
   SELECT
     t_woz_object.woz_objectnr,
     t_datum_begin."datum" AS "begin_d",
     t_datum_eind."datum" AS "eind_d",
     t_woz_object.bestaat_van_d AS "datum_begin_geldigheid_object",
     CASE WHEN t_woz_object.bestaat_van_d = '2011-01-01' 
     OR t_woz_object.bestaat_van_d = '2009-01-01' 
     THEN 1 
     ELSE 0 
     END AS "bestaat_van_kleiner_gelijk_ind",
     'Data beschikbaar vanaf ' || 
     CASE WHEN t_woz_object.bestaat_van_d  = '2009-01-01' 
     OR t_woz_object.bestaat_van_d  = '2011-01-01'  
     THEN to_char(t_woz_object.bestaat_van_d, 'DD-MM-YYYY') 
     ELSE NULL 
     END AS "bestaat_van_kleiner_gelijk",
     CASE WHEN year(t_woz_object.bestaat_tot_d) = 9999 THEN null ELSE t_woz_object.bestaat_tot_d END AS "datum_eind_geldigheid_object",
     coalesce(t_woz_object_hist.aanduiding,' ') AS "aanduiding",
     coalesce(t_woz_object_hist.gebruikscode,' ') AS "gebruikscode",
     coalesce(cast(t_woz_object_hist.grondoppervlakte_m2 AS varchar(17)) || ' m?',' ') AS "grondoppervlakte"
   FROM
     DG_I_P_40ANA_INZ."t_datum" AS t_datum_begin inner JOIN 
     DG_I_P_40ANA_INZ."t_datum" AS t_datum_eind
      on
      (
        1 = 1
     ) inner JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT AS t_woz_object
      on
      (
        1 = 1
     ) left JOIN 
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT_HIST AS t_woz_object_hist
      on
      (
        t_woz_object_hist.woz_objectnr = t_woz_object.woz_objectnr
        AND t_woz_object_hist.ingang_d <= t_datum_eind."datum"
        AND t_woz_object_hist.verval_d > t_datum_eind."datum"
     ) 
