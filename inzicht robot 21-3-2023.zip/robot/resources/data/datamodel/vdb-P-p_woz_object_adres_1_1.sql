REPLACE PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_adres_1_1 (
IN woz_objectnr varchar(12),
IN periode_begin_d date, 
IN periode_eind_d date
)
dynamic result sets 1
BEGIN
DECLARE c1 cursor with return only for
SEL adres, 
bestaat_van_d AS begindatum, 
CASE WHEN extract(year FROM bestaat_tot_d) = 9999 THEN null ELSE bestaat_tot_d END AS einddatum,
bestaat_van_kleiner_gelijk_ind,
bestaat_van_kleiner_gelijk
FROM DG_I_P_50PRO_INZ.v_woz_object_adres_1
WHERE woz_objectnr = :woz_objectnr
AND bestaat_van_d <= coalesce(:periode_eind_d,current_date)
AND bestaat_tot_d >= coalesce(:periode_begin_d,current_date);
open c1;
END; 

GRANT ALL ON PROCEDURE DG_I_P_50PRO_INZ.p_woz_object_adres_1_1 TO PUBLIC;
