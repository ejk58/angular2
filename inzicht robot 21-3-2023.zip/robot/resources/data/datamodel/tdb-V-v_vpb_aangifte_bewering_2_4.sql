REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_2_4 AS 
SELECT t_vpb_aangifte_pers_relatie.rsin_aangever, t_vpb_aangifte_pers_relatie.aangifte_volgnummer,
 t_vpb_aangifte_pers_relatie.rsin_aangegevene, v_vpb_aangifte_bewering_2_2."structuur_id",
 v_vpb_aangifte_bewering_2_2."onderdeel_id", v_vpb_aangifte_bewering_2_2."rubriek_id",
 v_vpb_aangifte_bewering_2_2."element_id", t_vpb_aangifte_bewering_1.waarde_regelnummer AS "id",
 null AS "parent_id", 1 AS "niveau", t_vpb_aangifte_bewering_1.waarde_regelnummer AS "volgorde",
 coalesce(t_persoon_aangegevene.is_afgeschermd_ind,0) AS "is_afgeschermd_ind",
 t_vpb_aangifte_bewering_1.waarde AS "waarde_1",
     t_vpb_aangifte_bewering_1.waarde_type AS "waarde_type_1",
     t_vpb_aangifte_bewering_2.waarde AS "waarde_2",
     t_vpb_aangifte_bewering_2.waarde_type AS "waarde_type_2",
     t_vpb_aangifte_bewering_3.waarde AS "waarde_3",
     t_vpb_aangifte_bewering_3.waarde_type AS "waarde_type_3",
     t_vpb_aangifte_bewering_4.waarde AS "waarde_4",
     t_vpb_aangifte_bewering_4.waarde_type AS "waarde_type_4",
     t_vpb_aangifte_bewering_5.waarde AS "waarde_5",
     t_vpb_aangifte_bewering_5.waarde_type AS "waarde_type_5" 
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_2_2" AS v_vpb_aangifte_bewering_2_2 inner JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_PERS_RELATIE AS t_vpb_aangifte_pers_relatie 
 on (1 = 1) left JOIN DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon_aangegevene 
 on (t_persoon_aangegevene.finr = t_vpb_aangifte_pers_relatie.rsin_aangegevene) inner JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_1 
 on (t_vpb_aangifte_bewering_1.rsin_aangegevene = t_vpb_aangifte_pers_relatie.rsin_aangegevene 
 AND t_vpb_aangifte_bewering_1.rsin_aangever = t_vpb_aangifte_pers_relatie.rsin_aangever 
 AND t_vpb_aangifte_bewering_1.aangifte_volgnummer = t_vpb_aangifte_pers_relatie.aangifte_volgnummer 
 AND t_vpb_aangifte_bewering_1.element_id = v_vpb_aangifte_bewering_2_2."waarde_1_element_id") left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_2 
 on (t_vpb_aangifte_bewering_2.rsin_aangegevene = t_vpb_aangifte_pers_relatie.rsin_aangegevene 
 AND t_vpb_aangifte_bewering_2.rsin_aangever = t_vpb_aangifte_pers_relatie.rsin_aangever 
 AND t_vpb_aangifte_bewering_2.aangifte_volgnummer = t_vpb_aangifte_pers_relatie.aangifte_volgnummer 
 AND t_vpb_aangifte_bewering_2.element_id = v_vpb_aangifte_bewering_2_2."waarde_2_element_id" 
 AND t_vpb_aangifte_bewering_2.waarde_regelnummer = t_vpb_aangifte_bewering_1.waarde_regelnummer) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_3 
 on (t_vpb_aangifte_bewering_3.rsin_aangegevene = t_vpb_aangifte_pers_relatie.rsin_aangegevene 
 AND t_vpb_aangifte_bewering_3.rsin_aangever = t_vpb_aangifte_pers_relatie.rsin_aangever 
 AND t_vpb_aangifte_bewering_3.aangifte_volgnummer = t_vpb_aangifte_pers_relatie.aangifte_volgnummer 
 AND t_vpb_aangifte_bewering_3.element_id = v_vpb_aangifte_bewering_2_2."waarde_3_element_id" 
 AND t_vpb_aangifte_bewering_3.waarde_regelnummer = t_vpb_aangifte_bewering_1.waarde_regelnummer) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_4 
 on (t_vpb_aangifte_bewering_4.rsin_aangegevene = t_vpb_aangifte_pers_relatie.rsin_aangegevene 
 AND t_vpb_aangifte_bewering_4.rsin_aangever = t_vpb_aangifte_pers_relatie.rsin_aangever 
 AND t_vpb_aangifte_bewering_4.aangifte_volgnummer = t_vpb_aangifte_pers_relatie.aangifte_volgnummer 
 AND t_vpb_aangifte_bewering_4.element_id = v_vpb_aangifte_bewering_2_2."waarde_4_element_id" 
 AND t_vpb_aangifte_bewering_4.waarde_regelnummer = t_vpb_aangifte_bewering_1.waarde_regelnummer) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_5 
 on (t_vpb_aangifte_bewering_5.rsin_aangegevene = t_vpb_aangifte_pers_relatie.rsin_aangegevene 
 AND t_vpb_aangifte_bewering_5.rsin_aangever = t_vpb_aangifte_pers_relatie.rsin_aangever 
 AND t_vpb_aangifte_bewering_5.aangifte_volgnummer = t_vpb_aangifte_pers_relatie.aangifte_volgnummer 
 AND t_vpb_aangifte_bewering_5.element_id = v_vpb_aangifte_bewering_2_2."waarde_5_element_id" 
 AND t_vpb_aangifte_bewering_5.waarde_regelnummer = t_vpb_aangifte_bewering_1.waarde_regelnummer) 
