DROP TABLE DG_I_P_40ANA_INZ.p_inz_erf_uitgenodigd;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_erf_uitgenodigd,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   finr_relatie INTEGER,
   datum_d DATE FORMAT 'yyyy-mm-dd',
   fase VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
   proces VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
   reden_annuleren VARCHAR(256) CHARACTER SET UNICODE NOT CASESPECIFIC,
   dagtekening_d DATE FORMAT 'yyyy-mm-dd',
   type_relatie VARCHAR(130) CHARACTER SET UNICODE NOT CASESPECIFIC,
   ingang_d DATE FORMAT 'yyyy-mm-dd',
   naam VARCHAR(1200) CHARACTER SET UNICODE NOT CASESPECIFIC,
   geboortedatum_d DATE FORMAT 'yyyy-mm-dd',
   leeftijd SMALLINT,
   volgorde INTEGER,
   parent INTEGER,
   niveau SMALLINT,
   laatste_stand_ind BYTEINT,
   status_einde BYTEINT,
   vip_ind BYTEINT,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC COMPRESS '2022.14')
PRIMARY INDEX (finr); 
