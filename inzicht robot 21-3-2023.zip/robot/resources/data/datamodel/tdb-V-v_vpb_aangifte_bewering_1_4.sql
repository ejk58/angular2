REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_1_4 AS 
SELECT v_vpb_aangifte_bewering_1_3."finr", v_vpb_aangifte_bewering_1_3."rsin_aangegevene",
 v_vpb_aangifte_bewering_1_3."rsin_aangever", v_vpb_aangifte_bewering_1_3."aangifte_volgnummer",
 v_vpb_aangifte_bewering_1_3."tijdvak_begin_d", v_vpb_aangifte_bewering_1_3."tijdvak_eind_d",
 row_number() over (partition by v_vpb_aangifte_bewering_1_3."finr",
 v_vpb_aangifte_bewering_1_3."rsin_aangegevene" 
ORDER BY v_vpb_aangifte_bewering_1_3."tijdvak_begin_d" desc, v_vpb_aangifte_bewering_1_3."tijdvak_eind_d" desc) AS "volgorde" 
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_1_3" AS v_vpb_aangifte_bewering_1_3 
