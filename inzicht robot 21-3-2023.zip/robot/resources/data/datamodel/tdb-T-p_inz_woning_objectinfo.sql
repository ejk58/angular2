DROP TABLE DG_I_P_40ANA_INZ.p_inz_woning_objectinfo;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_woning_objectinfo,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   belastingjaar SMALLINT,
   woz_objectnr DECIMAL(12,0),
   woz_objectnr_display DECIMAL(12,0),
   objectnr VARCHAR(25) CHARACTER SET UNICODE CASESPECIFIC,
   bron VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   koopdatum DATE FORMAT 'YY/MM/DD',
   verkoopdatum DATE FORMAT 'YY/MM/DD',
   ingangs_d DATE FORMAT 'YY/MM/DD',
   woz_waarde_abs_eur DECIMAL(14,0),
   woz_waarde_woz_eur DECIMAL(14,0),
   hypotheek_d DATE FORMAT 'YY/MM/DD',
   gebruik VARCHAR(300) CHARACTER SET UNICODE CASESPECIFIC,
   cultuurcode_bb VARCHAR(1000) CHARACTER SET UNICODE CASESPECIFIC,
   woningscode SMALLINT,
   eigendom INTEGER,
   aantal_pers INTEGER,
   object_beschr VARCHAR(500) CHARACTER SET UNICODE CASESPECIFIC,
   details_ind SMALLINT,
   ingeschr_persoon VARCHAR(1000) CHARACTER SET UNICODE CASESPECIFIC,
   match SMALLINT,
   wonend_op_adres SMALLINT,
   adres VARCHAR(500) CHARACTER SET UNICODE CASESPECIFIC,
   ingeschr_persoonbevatvip_ind BYTEINT COMPRESS (0,1),
   adreskey INTEGER,
   releasenr VARCHAR(7) CHARACTER SET UNICODE CASESPECIFIC COMPRESS '2020.05',
   created_dt TIMESTAMP(0))
PRIMARY INDEX (finr,belastingjaar,woningscode)
INDEX (finr,belastingjaar,woz_objectnr,woningscode)
INDEX (finr,belastingjaar,woz_objectnr)
INDEX (belastingjaar,woz_objectnr); 
