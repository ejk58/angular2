DROP TABLE DG_I_P_40ANA_INZ.p_inz_finr_relaties_historie;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_finr_relaties_historie,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   id_relatie VARCHAR(32) CHARACTER SET UNICODE NOT CASESPECIFIC,
   id_relatie_type VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC COMPRESS ('finr','TIN','onbekend'),
   relatiesoort INTEGER COMPRESS 997,
   relatiesoort_bes VARCHAR(60) CHARACTER SET UNICODE CASESPECIFIC COMPRESS ('Zelfde adres','Ouder van','Kind van'),
   ingang_d DATE FORMAT 'YY/MM/DD',
   verval_d DATE FORMAT 'YY/MM/DD',
   naam_relatie VARCHAR(512) CHARACTER SET UNICODE CASESPECIFIC,
   leeftijd_relatie INTEGER,
   geboorte_oprichting_d_relatie DATE FORMAT 'YY/MM/DD',
   overlijden_opheffing_d_relatie DATE FORMAT 'YY/MM/DD' COMPRESS,
   zelfde_adres_ind VARCHAR(3) CHARACTER SET UNICODE CASESPECIFIC COMPRESS 'Ja',
   zelfde_entiteit_ind VARCHAR(3) CHARACTER SET UNICODE CASESPECIFIC COMPRESS ('Nee','Ja'),
   bron_kvk_ind BYTEINT,
   ubo_ind BYTEINT,
   aandeel_omvang VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC COMPRESS,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC COMPRESS '&releas')
PRIMARY INDEX (finr); 
