CREATE JOIN INDEX DG_I_P_40ANA_INZ.ji_schenk_zaak_schenker,FALLBACK,CHECKSUM = DEFAULT, MAP = TD_MAP1 AS 
SELECT DG_I_P_40ANA_INZ.t_schenk_zaak.ROWID,DG_I_P_40ANA_INZ.t_schenk_zaak.schenker_finr 
 FROM DG_I_P_40ANA_INZ.t_schenk_zaak 
WHERE NOT (DG_I_P_40ANA_INZ.t_schenk_zaak.schenker_finr IS NULL)
PRIMARY INDEX (schenker_finr); 
