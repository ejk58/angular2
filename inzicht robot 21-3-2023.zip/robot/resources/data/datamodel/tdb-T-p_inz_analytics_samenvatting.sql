DROP TABLE DG_I_P_40ANA_INZ.p_inz_analytics_samenvatting;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_analytics_samenvatting,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   week INTEGER,
   dag INTEGER,
   maand INTEGER,
   jaar INTEGER,
   klantbeeld VARCHAR(50) CHARACTER SET UNICODE CASESPECIFIC,
   omgeving VARCHAR(15) CHARACTER SET UNICODE CASESPECIFIC,
   aantal_gebruikers INTEGER NOT NULL,
   aantal_sessies INTEGER,
   aantal_finr INTEGER,
   aantal_pagina INTEGER,
   aantal_nieuwe_gebruikers INTEGER,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(7) CHARACTER SET UNICODE CASESPECIFIC COMPRESS '2020.05')
PRIMARY INDEX (klantbeeld)
INDEX (maand,jaar,klantbeeld)
INDEX (maand,jaar); 
