REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_1_1 AS 
SELECT t_vpb_aangifte_pers_relatie.rsin_aangever AS "finr", t_vpb_aangifte_pers_relatie.rsin_aangegevene,
 t_vpb_aangifte_pers_relatie.rsin_aangever, t_vpb_aangifte_pers_relatie.aangifte_volgnummer,
 t_vpb_aangifte.tijdvak_begin_d, t_vpb_aangifte.tijdvak_eind_d 
FROM DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_PERS_RELATIE AS t_vpb_aangifte_pers_relatie inner JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE AS t_vpb_aangifte 
 on (t_vpb_aangifte.rsin_aangever = t_vpb_aangifte_pers_relatie.rsin_aangever 
 AND t_vpb_aangifte.volgnummer = t_vpb_aangifte_pers_relatie.aangifte_volgnummer) 
WHERE 1 = 1 
qualify row_number() over (partition by t_vpb_aangifte_pers_relatie.rsin_aangever,
 t_vpb_aangifte_pers_relatie.rsin_aangegevene, t_vpb_aangifte.tijdvak_begin_d,
 t_vpb_aangifte.tijdvak_eind_d 
ORDER BY t_vpb_aangifte_pers_relatie.aangifte_volgnummer desc) = 1 
