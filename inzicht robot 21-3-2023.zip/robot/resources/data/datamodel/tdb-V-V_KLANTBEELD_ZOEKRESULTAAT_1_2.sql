REPLACE VIEW DG_I_P_40ANA_INZ.v_klantbeeld_zoekresultaat_1_2 AS
   SELECT
     t_persoon.finr AS "zoeksleutel",
     cast('finr' AS varchar(32)) AS "zoeksleuteltype",
     t_persoon.finr AS "subject_title",
     cast('BSN/RSIN' AS varchar(32)) AS "label",
     cast('#01689B' AS varchar(7)) AS "background_color",
     t_persoon.naam AS "name",
     t_persoon.finr,
     cast(null AS varchar(15)) AS "woz_objectnr",
     cast('vastgoed-persoon' AS varchar(20)) AS "initpageid"
   FROM
     DG_I_P_40ANA_INZ.T_PERSOON AS t_persoon
   WHERE
     t_persoon.segment NOT IN ('GO'); 
