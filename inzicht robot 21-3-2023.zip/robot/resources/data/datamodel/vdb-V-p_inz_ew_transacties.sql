/****************************************************
Copy Object Script for VIEW: p_inz_ew_transacties
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_ew_transacties AS
SELECT * FROM DG_I_P_40ANA_INZ.p_inz_ew_transacties; 
