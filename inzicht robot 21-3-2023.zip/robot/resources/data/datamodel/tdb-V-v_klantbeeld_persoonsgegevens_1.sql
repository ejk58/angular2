REPLACE VIEW DG_I_P_40ANA_INZ.v_klantbeeld_persoonsgegevens_1 AS
SELECT
     CAST(p_inz_finrs.finr AS VARCHAR(11)) AS "finr",
     max(CAST(p_inz_finrs.naam_uitgeschreven AS VARCHAR(1200))) AS "naam_uitgeschreven",
     max(p_inz_finrs.np_ind) AS "np_ind",
     max(p_inz_finrs.geboortedatum_d) AS "geboorte_d",
     max(p_inz_finrs.overlijdensdatum_d) AS "overlijdensdatum_d",
     max(p_inz_finrs.burgerlijke_staat) AS "burgerlijke_staat",
     max(p_inz_finrs.oprichtingsdatum_d) AS "oprichting_d",
     max(p_inz_finrs.opheffingsdatum_d) AS "opheffing_d",
     max(p_inz_finrs.faillissement_start_d) AS "faillissement_start_d",
     max(p_inz_finrs.faillissement_eind_d) AS "faillissement_eind_d",
     max(CASE WHEN p_inz_adressen.adressoort = 1 THEN  
         CAST(p_inz_adressen.adres ||'<br>' ||'sinds ' || CAST(p_inz_adressen.ingang_d AS DATE FORMAT 'DD-MM-YYYY') AS VARCHAR(150)) 
         ELSE null END) AS "adres_volgens_gemeente",
     max(CASE WHEN p_inz_adressen.adressoort = 2 THEN  
         CAST(p_inz_adressen.adres ||'<br>' ||'sinds ' || CAST(p_inz_adressen.ingang_d AS DATE FORMAT 'DD-MM-YYYY') AS VARCHAR(150)) 
         ELSE null END) AS "vestigingsadres"
   FROM
     DG_I_P_40ANA_INZ.P_INZ_FINRS AS p_inz_finrs left JOIN 
     DG_I_P_40ANA_INZ.P_INZ_ADRESSEN AS p_inz_adressen
      on
      (
        p_inz_finrs.finr = p_inz_adressen.finr
        AND p_inz_adressen.verval_d IS NULL 
        AND p_inz_adressen.adressoort IN (1,2)
     )
   group by
     p_inz_finrs.finr; 
