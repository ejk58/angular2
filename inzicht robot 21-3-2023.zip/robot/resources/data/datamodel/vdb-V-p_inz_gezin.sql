/****************************************************
Copy Object Script for VIEW: p_inz_gezin
****************************************************/
 CREATE VIEW DG_I_P_50PRO_INZ.p_inz_gezin AS LOCKING ROW FOR ACCESS (SELECT * FROM DG_I_P_40ANA_INZ.p_inz_gezin); 
