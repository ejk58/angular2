REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_aangifte_bewering_1_9 AS 
SELECT distinct v_vpb_aangifte_bewering_1_5."finr", v_vpb_aangifte_bewering_1_5."rsin_aangegevene",
 t_vpb_structuur_element.structuur_id, t_vpb_structuur_element.onderdeel_id,
 t_vpb_structuur_element.rubriek_id, t_vpb_structuur_element.id AS "element_id",
 t_vpb_structuur_element.id, t_vpb_structuur_element.rubriek_id AS "parent_id",
 2 AS "niveau", 1000 * t_vpb_structuur_element.rubriek_id + 10 * t_vpb_structuur_element.verticale_positie + t_vpb_structuur_element.horizontale_positie AS "volgorde",
 coalesce(t_persoon.is_afgeschermd_ind,0) AS "is_afgeschermd_ind",
 t_vpb_structuur_element.is_multi_regel_ind AS "bevat_hyperlinks_ind",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_structuur_element.verticale_naam || coalesce(' - ' || t_vpb_structuur_element.horizontale_naam,
 '') 
 ELSE t_vpb_structuur_element.verticale_naam 
END AS "naam", 
CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_1.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_1.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_1", v_vpb_aangifte_bewering_1_5."rsin_aangever_1",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_1", v_vpb_aangifte_bewering_1_5."tijdvak_1",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_2.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_2.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_2", v_vpb_aangifte_bewering_1_5."rsin_aangever_2",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_2", v_vpb_aangifte_bewering_1_5."tijdvak_2",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_3.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_3.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_3", v_vpb_aangifte_bewering_1_5."rsin_aangever_3",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_3", v_vpb_aangifte_bewering_1_5."tijdvak_3",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_4.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_4.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_4", v_vpb_aangifte_bewering_1_5."rsin_aangever_4",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_4", v_vpb_aangifte_bewering_1_5."tijdvak_4",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_5.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_5.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_5", v_vpb_aangifte_bewering_1_5."rsin_aangever_5",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_5", v_vpb_aangifte_bewering_1_5."tijdvak_5",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_6.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_6.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_6", v_vpb_aangifte_bewering_1_5."rsin_aangever_6",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_6", v_vpb_aangifte_bewering_1_5."tijdvak_6",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_7.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_7.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_7", v_vpb_aangifte_bewering_1_5."rsin_aangever_7",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_7", v_vpb_aangifte_bewering_1_5."tijdvak_7",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_8.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_8.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_8", v_vpb_aangifte_bewering_1_5."rsin_aangever_8",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_8", v_vpb_aangifte_bewering_1_5."tijdvak_8",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_9.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_9.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_9", v_vpb_aangifte_bewering_1_5."rsin_aangever_9",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_9", v_vpb_aangifte_bewering_1_5."tijdvak_9",
 CASE 
 WHEN t_vpb_structuur_element.is_multi_regel_ind = 0 THEN t_vpb_aangifte_bewering_10.waarde 
 ELSE 
CASE 
 WHEN t_vpb_aangifte_bewering_10.rsin_aangegevene is not null THEN '...' 
END 
END AS "waarde_10", v_vpb_aangifte_bewering_1_5."rsin_aangever_10",
 v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_10", v_vpb_aangifte_bewering_1_5."tijdvak_10",
     COALESCE(t_vpb_aangifte_bewering_1.waarde_type,t_vpb_aangifte_bewering_2.waarde_type,t_vpb_aangifte_bewering_3.waarde_type 
    ,t_vpb_aangifte_bewering_4.waarde_type,t_vpb_aangifte_bewering_5.waarde_type,t_vpb_aangifte_bewering_6.waarde_type 
    ,t_vpb_aangifte_bewering_7.waarde_type,t_vpb_aangifte_bewering_8.waarde_type,t_vpb_aangifte_bewering_9.waarde_type 
    ,t_vpb_aangifte_bewering_10.waarde_type) AS "waarde_type"
FROM DG_I_P_40ANA_INZ."v_vpb_aangifte_bewering_1_5" AS v_vpb_aangifte_bewering_1_5 inner JOIN DG_I_P_40ANA_INZ.T_VPB_STRUCTUUR_ELEMENT AS t_vpb_structuur_element 
 on (t_vpb_structuur_element.volgorde_in_elementenset = 1) left JOIN "DG_I_P_40ANA_INZ ".T_PERSOON AS t_persoon 
 on (t_persoon.finr = v_vpb_aangifte_bewering_1_5."rsin_aangegevene") left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_1 
 on (t_vpb_aangifte_bewering_1.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_1.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_1" 
 AND t_vpb_aangifte_bewering_1.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_1" 
 AND t_vpb_aangifte_bewering_1.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_1.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_2 
 on (t_vpb_aangifte_bewering_2.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_2.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_2" 
 AND t_vpb_aangifte_bewering_2.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_2" 
 AND t_vpb_aangifte_bewering_2.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_2.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_3 
 on (t_vpb_aangifte_bewering_3.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_3.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_3" 
 AND t_vpb_aangifte_bewering_3.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_3" 
 AND t_vpb_aangifte_bewering_3.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_3.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_4 
 on (t_vpb_aangifte_bewering_4.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_4.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_4" 
 AND t_vpb_aangifte_bewering_4.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_4" 
 AND t_vpb_aangifte_bewering_4.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_4.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_5 
 on (t_vpb_aangifte_bewering_5.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_5.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_5" 
 AND t_vpb_aangifte_bewering_5.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_5" 
 AND t_vpb_aangifte_bewering_5.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_5.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_6 
 on (t_vpb_aangifte_bewering_6.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_6.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_6" 
 AND t_vpb_aangifte_bewering_6.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_6" 
 AND t_vpb_aangifte_bewering_6.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_6.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_7 
 on (t_vpb_aangifte_bewering_7.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_7.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_7" 
 AND t_vpb_aangifte_bewering_7.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_7" 
 AND t_vpb_aangifte_bewering_7.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_7.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_8 
 on (t_vpb_aangifte_bewering_8.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_8.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_8" 
 AND t_vpb_aangifte_bewering_8.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_8" 
 AND t_vpb_aangifte_bewering_8.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_8.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_9 
 on (t_vpb_aangifte_bewering_9.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_9.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_9" 
 AND t_vpb_aangifte_bewering_9.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_9" 
 AND t_vpb_aangifte_bewering_9.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_9.waarde_regelnummer = 1) left JOIN DG_I_P_40ANA_INZ.T_VPB_AANGIFTE_BEWERING AS t_vpb_aangifte_bewering_10 
 on (t_vpb_aangifte_bewering_10.rsin_aangegevene = v_vpb_aangifte_bewering_1_5."rsin_aangegevene" 
 AND t_vpb_aangifte_bewering_10.rsin_aangever = v_vpb_aangifte_bewering_1_5."rsin_aangever_10" 
 AND t_vpb_aangifte_bewering_10.aangifte_volgnummer = v_vpb_aangifte_bewering_1_5."aangifte_volgnummer_10" 
 AND t_vpb_aangifte_bewering_10.element_id = t_vpb_structuur_element.id 
 AND t_vpb_aangifte_bewering_10.waarde_regelnummer = 1) 
