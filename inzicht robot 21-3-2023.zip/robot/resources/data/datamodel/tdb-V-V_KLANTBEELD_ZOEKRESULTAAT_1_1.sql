REPLACE VIEW DG_I_P_40ANA_INZ.v_klantbeeld_zoekresultaat_1_1 AS
   SELECT
     t_woz_object.woz_objectnr AS "zoeksleutel",
     'wozobjectnr' AS "zoeksleuteltype",
     t_woz_object.woz_objectnr AS "subject_title",
     'WOZ-objectnr' AS "label",
     '#A90061' AS "background_color",
     t_woz_object.aanduiding AS "name",
     cast(null AS varchar(11)) AS "finr",
     t_woz_object.woz_objectnr,
     cast('vastgoed-wozdetails' AS varchar(20)) AS "initpageid"
   FROM
     DG_I_P_40ANA_INZ.T_WOZ_OBJECT AS t_woz_object; 
