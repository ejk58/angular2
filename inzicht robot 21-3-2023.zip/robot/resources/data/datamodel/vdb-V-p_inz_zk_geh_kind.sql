/****************************************************
Copy Object Script for VIEW: p_inz_zk_geh_kind
****************************************************/
CREATE VIEW DG_I_P_50PRO_INZ.p_inz_zk_geh_kind AS LOCKING ROW FOR ACCESS SELECT * FROM DG_I_P_40ANA_INZ.p_inz_zk_geh_kind 
