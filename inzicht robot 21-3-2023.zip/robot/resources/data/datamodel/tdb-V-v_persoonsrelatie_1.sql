REPLACE VIEW DG_I_P_40ANA_INZ.v_persoonsrelatie_1 AS 
SELECT v_persoonsrelatie_1_1."finr", v_persoonsrelatie_1_1."finr_woonadres_regel_1",
 v_persoonsrelatie_1_1."finr_woonadres_regel_2", v_persoonsrelatie_1_1."finr_woonadres_regel_3",
 substr(cast(xmlagg(', ' || v_persoonsrelatie_1_1."finr_bron_relsrt_beschrijving") AS varchar(512)),
 2) AS "finr_bron_relsrt_beschrijving", v_persoonsrelatie_1_1."bron_bsn",
 v_persoonsrelatie_1_1."bron_naam", v_persoonsrelatie_1_1."bron_icoontype",
 v_persoonsrelatie_1_1."bron_leeftijd", v_persoonsrelatie_1_1."bron_is_overleden_ind",
 v_persoonsrelatie_1_1."bron_is_afgeschermd_ind", v_persoonsrelatie_1_1."bron_woont_op_zelfde_adres_ind",
 max(v_persoonsrelatie_1_1."bron_is_mogelijke_erfgenaam_ind") AS "bron_is_mogelijke_erfgenaam_ind",
 max(v_persoonsrelatie_1_1."bron_heeft_erfenis_verworpen_ind") AS "bron_heeft_erfenis_verworpen_ind",
 v_persoonsrelatie_1_1."bron_doel_relsrt_id", v_persoonsrelatie_1_1."doel_bsn" 
FROM DG_I_P_40ANA_INZ."v_persoonsrelatie_1_1" AS v_persoonsrelatie_1_1 
group by v_persoonsrelatie_1_1."finr", v_persoonsrelatie_1_1."finr_woonadres_regel_1",
 v_persoonsrelatie_1_1."finr_woonadres_regel_2", v_persoonsrelatie_1_1."finr_woonadres_regel_3",
 v_persoonsrelatie_1_1."bron_bsn", v_persoonsrelatie_1_1."bron_naam",
 v_persoonsrelatie_1_1."bron_icoontype", v_persoonsrelatie_1_1."bron_leeftijd",
 v_persoonsrelatie_1_1."bron_is_overleden_ind", v_persoonsrelatie_1_1."bron_is_afgeschermd_ind",
 v_persoonsrelatie_1_1."bron_woont_op_zelfde_adres_ind", v_persoonsrelatie_1_1."bron_doel_relsrt_id",
 v_persoonsrelatie_1_1."doel_bsn" 
