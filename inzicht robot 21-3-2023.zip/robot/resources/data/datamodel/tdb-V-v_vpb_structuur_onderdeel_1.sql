REPLACE VIEW DG_I_P_40ANA_INZ.v_vpb_structuur_onderdeel_1 AS 
SELECT t_vpb_structuur_onderdeel.id, 
    t_vpb_structuur_onderdeel.structuur_id,
 t_vpb_structuur_onderdeel.naam,
    t_vpb_structuur_onderdeel.default_ind 
FROM DG_I_P_40ANA_INZ.T_VPB_STRUCTUUR_ONDERDEEL AS t_vpb_structuur_onderdeel 
