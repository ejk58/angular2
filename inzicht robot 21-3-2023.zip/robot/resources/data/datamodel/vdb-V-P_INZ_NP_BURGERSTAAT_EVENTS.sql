/****************************************************
Copy Object Script for VIEW: P_INZ_NP_BURGERSTAAT_EVENTS
****************************************************/
REPLACE VIEW DG_I_P_50PRO_INZ.P_INZ_NP_BURGERSTAAT_EVENTS AS SELECT * FROM DG_I_P_40ANA_INZ.p_inz_np_burgerstaat_events; 
