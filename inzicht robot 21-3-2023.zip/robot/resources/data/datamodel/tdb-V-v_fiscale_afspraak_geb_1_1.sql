REPLACE VIEW DG_I_P_40ANA_INZ.v_fiscale_afspraak_geb_1_1 AS
  SELECT t_fiscale_afspraak.fiscale_afspraak_id,
    t_fiscale_afspraak.finr,
    t_fiscale_afspraak.vermoedelijke_schenking_d,
    t_fiscale_afspraak.dagtekening_d AS "gebeurtenis_d",
    CAST('UDA' AS VARCHAR(50)) AS "gebeurtenis_type",
    CAST(NULL AS DATE) AS "besluit_ontvangst_d",
    t_fiscale_afspraak.gewenste_reactie_d AS "verval_d",
    'Reden muteren: ' || t_fiscale_afspraak.reden_muteren AS "details"
    FROM DG_I_P_40ANA_INZ.T_FISCALE_AFSPRAAK AS t_fiscale_afspraak 
