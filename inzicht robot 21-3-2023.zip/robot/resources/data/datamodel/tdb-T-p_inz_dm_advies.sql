DROP TABLE DG_I_P_40ANA_INZ.p_inz_dm_advies;

CREATE MULTISET TABLE DG_I_P_40ANA_INZ.p_inz_dm_advies,FALLBACK,
   NO BEFORE JOURNAL,
   NO AFTER JOURNAL,
   CHECKSUM = DEFAULT,
   DEFAULT MERGEBLOCKRATIO,
   MAP = TD_MAP1
   (
   finr INTEGER,
   burgerlijke_staat VARCHAR(300) CHARACTER SET UNICODE CASESPECIFIC,
   advies_beslagvrije_voet_eur INTEGER,
   inkomen_eur INTEGER,
   correctie_inkomen_partner_eur INTEGER,
   correctie_zorgkosten_eur INTEGER,
   correctie_woonlasten_eur INTEGER,
   correctie_kindgebondenbudget_eur INTEGER,
   correctie_vt_eur INTEGER,
   beslagvrije_voet_eur INTEGER,
   inkomen_partner_eur INTEGER,
   vt_actief_eur INTEGER,
   vt_partner_actief_eur INTEGER,
   vermenigvuldigingsfactor DECIMAL(3,1),
   btc_eur INTEGER,
   type_schuld VARCHAR(30) CHARACTER SET UNICODE CASESPECIFIC,
   advies_tekst VARCHAR(192) CHARACTER SET UNICODE CASESPECIFIC,
   categorie_bvv VARCHAR(200) CHARACTER SET UNICODE CASESPECIFIC,
   created_dt TIMESTAMP(0),
   releasenr VARCHAR(10) CHARACTER SET UNICODE CASESPECIFIC,
   beslagvrij_bedrag VARCHAR(200) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX (finr); 
