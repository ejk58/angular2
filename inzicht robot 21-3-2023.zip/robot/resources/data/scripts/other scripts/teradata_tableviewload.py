
import sys
import jaydebeapi

from teradata_private_module import get_username, get_password
from datetime import datetime
from os import listdir
from os.path import join
from time import sleep


JDBCDRIVERNAME = "com.teradata.jdbc.TeraDriver"
JDBCDRIVERJAR = ["C:\\ws\\apps\\Liquibase\\lib\\terajdbc4.jar", "C:\\ws\\apps\\Liquibase\\lib\\tdgssconfig.jar"]
#DATABASEURL = "jdbc:teradata://rtdaoudll01.data.rsi.bdp.belastingdienst.nl"
#DATABASEURL = "jdbc:teradata://rtdatudll01.data.rsi.bdp.belastingdienst.nl"
DATABASEURL = "jdbc:teradata://tdunity-acc.data.bdp.belastingdienst.nl"
SCRIPTDIRECTORY = "C:/ws/projects/teradata/scripts/"
SCHEMAS = ["DG_I_P_40ANA_INZ", "DG_I_P_50PRO_INZ"]
SKIPEXISTINGOBJECTS = False


def showfatalerror(errorcode, errormessage, traceback):
    print("\n" + errormessage)
    sys.exit(errorcode)


def getendindexofobjectname(line, startindex):
    endindex = len(line)
    candidateindex = line.find(" ", startindex + 1)
    endindex = candidateindex if candidateindex > startindex and candidateindex < endindex else endindex
    candidateindex = line.find(",", startindex + 1)
    endindex = candidateindex if candidateindex > startindex and candidateindex < endindex else endindex
    candidateindex = line.find(";", startindex + 1)
    endindex = candidateindex if candidateindex > startindex and candidateindex < endindex else endindex
    candidateindex = line.find("(", startindex + 1)
    endindex = candidateindex if candidateindex > startindex and candidateindex < endindex else endindex
    candidateindex = line.find(")", startindex + 1)
    endindex = candidateindex if candidateindex > startindex and candidateindex < endindex else endindex
    return endindex


def getobjectname(line, startindex):
    baseline = line[startindex:].replace("\n", " ").replace("\"", "").replace(". ", ".").replace(" .", ".")
    endindex = getendindexofobjectname(baseline, 0)
    return baseline[0:endindex].strip()


def connecttoteradata():
    try:
        connection = jaydebeapi.connect(JDBCDRIVERNAME, DATABASEURL, [get_username(DATABASEURL), get_password(DATABASEURL)], JDBCDRIVERJAR)
    except:
        type, value, traceback = sys.exc_info()
        showfatalerror(10, "Could not connect to database: " + str(type) + " " + str(value), traceback)

    return connection


def executequery(connection, query):
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        result = cursor.fetchall()
    finally:
        cursor.close()

    return result


def executescript(connection, script):
    pass
    try:
        cursor = connection.cursor()
        cursor.execute(script)
    finally:
        cursor.close()


def disconnect(connection):
    connection.close()


print("Connecting to Teradata database...")
connection = connecttoteradata()

print("Reading join index scripts...")
joinindexscriptfiles = [ file for file in listdir(SCRIPTDIRECTORY) if file.startswith("joinindex-") and file.endswith(".sql") ]

joinindexmap = {}
for joinindexscriptfile in joinindexscriptfiles:
    tablename = ""
    script = ""

    print("Reading join index script file " + joinindexscriptfile + "...")
    with open(join(SCRIPTDIRECTORY, joinindexscriptfile), "r", encoding = "utf-8") as inputfile:
        scriptlines = inputfile.readlines()
        for scriptline in scriptlines:
            upperscriptline = scriptline.upper()
            if 'FROM ' in upperscriptline:
                startindex = upperscriptline.index('FROM ') + 5
                tablename = getobjectname(scriptline, startindex)
            script = script + scriptline

    if len(tablename) > 0:
        if tablename not in joinindexmap:
            joinindexmap[tablename] = []
        joinindexmap[tablename].append(script)


print("Reading tables from Teradata databases " + " + ".join(SCHEMAS) + "..." )
query = "SELECT databasename || '.' || tablename FROM DBC.tablesV WHERE tablekind = 'T' AND databasename IN ('" + "', '".join(SCHEMAS) + "')"
tableresults = executequery(connection, query)
objects = []
for tableresult in tableresults:
    tableresultname = str(tableresult)[2:-3]
    objects.append(tableresultname.upper())

print("Reading table scripts...")
tablescriptfiles = [ file for file in listdir(SCRIPTDIRECTORY) if file.startswith("table-") and file.endswith(".sql") ]

for tablescriptfile in tablescriptfiles:
    tablename = ""
    script = ""

    print("Reading table script file " + tablescriptfile + "...")
    with open(join(SCRIPTDIRECTORY, tablescriptfile), "r", encoding = "utf-8") as inputfile:
        scriptlines = inputfile.readlines()
        for scriptline in scriptlines:
            upperscriptline = scriptline.upper()
            if 'CREATE ' in upperscriptline and 'TABLE ' in upperscriptline:
                startindex = upperscriptline.index('TABLE ') + 6
                tablename = getobjectname(scriptline, startindex)
            script = script + scriptline

    if len(tablename) > 0:
        objectexists = tablename.upper() in objects
        if objectexists and not SKIPEXISTINGOBJECTS:
            print("Dropping existing table " + tablename + "...")
            tablenameparts = tablename.split(".")
            query = "SELECT DISTINCT databasename || '.' || indexname FROM dbc.indicesV WHERE indextype = 'J' AND databasename = '" + tablenameparts[0] + "' AND tablename = '" + tablenameparts[1] + "'"
            joinindexresults = executequery(connection, query)
            for joinindex in joinindexresults:
                query = "DROP JOIN INDEX " + str(joinindex)[2:-3]
                print(query)
                executescript(connection, query)

            query = "DROP TABLE " + tablename
            executescript(connection, query)

        if objectexists and SKIPEXISTINGOBJECTS:
            print("Skipping table script for table " + tablename + "...")
        else:
            print("Executing table script for table " + tablename + "...")
            executescript(connection, script)
            objects.append(tablename.upper())
            
            if tablename in joinindexmap:
                print("Executing join index scripts for table " + tablename + "...")
                for joinindexscript in joinindexmap[tablename]:
                    executescript(connection, joinindexscript)


print("Reading views from Teradata databases " + " + ".join(SCHEMAS) + "..." )
query = "SELECT databasename || '.' || tablename FROM DBC.tablesV WHERE tablekind = 'V' AND databasename IN ('" + "', '".join(SCHEMAS) + "')"
viewresults = executequery(connection, query)
for viewresult in viewresults:
    viewresultname = str(viewresult)[2:-3]
    objects.append(viewresultname.upper())

print("Reading view scripts...")
viewscriptfiles = [ file for file in listdir(SCRIPTDIRECTORY) if file.startswith("view-") and file.endswith(".sql") ]

viewexecutionqueue = []
for viewscriptfile in viewscriptfiles:
    viewname = ""
    referencedobjectnames = []
    script = ""
    print("Reading view script file" + viewscriptfile + "...")
    with open(join(SCRIPTDIRECTORY, viewscriptfile), "r", encoding = "utf-8") as inputfile:
        scriptlines = inputfile.readlines()
        for scriptline in scriptlines:
            uppescriptline = scriptline.upper()
            if ('CREATE ' in uppescriptline or 'REPLACE ' in uppescriptline) and 'VIEW ' in uppescriptline:
                startindex = uppescriptline.index('VIEW ') + 5
                viewname = getobjectname(scriptline, startindex)

            for schema in SCHEMAS:
                if schema in scriptline:
                    startindex = scriptline.index(schema)
                    referencedobjectnames.append(getobjectname(scriptline, startindex))
                
            script = script + scriptline

    viewexecutionqueue.append({
        'viewname': viewname,
        'script': script,
        'referencedobjectnames': [ referencedobjectname.upper() for referencedobjectname in referencedobjectnames if referencedobjectname != viewname ]
    })

changes = True
while changes and len(viewexecutionqueue) > 0:
    changes = False
    viewskippedqueue = []

    for view in viewexecutionqueue:
        viewname = view['viewname']
        objectexists = viewname.upper() in objects
        
        if not objectexists or not SKIPEXISTINGOBJECTS:
            viewexecutable = True
            for referencedobjectname in view['referencedobjectnames']:
                viewexecutable = viewexecutable and referencedobjectname in objects

            if viewexecutable:
                if objectexists and not SKIPEXISTINGOBJECTS:
                    query = "DROP VIEW " + viewname
                    executescript(connection, query)

                print("Executing view script for view " + viewname + "...")
                executescript(connection, view['script'])
                objects.append(viewname.upper())
                changes = True
            else:
                viewskippedqueue.append(view)
        else:
            print("Skipping view script for view " + viewname + "...")

    viewexecutionqueue = viewskippedqueue

print("Reporting skipped views...")
for view in viewexecutionqueue:
    missingobjects = [ referencedobjectname for referencedobjectname in view['referencedobjectnames'] if referencedobjectname not in objects ]
    print(" - " + view['viewname'] + " misses objects " + ", ".join(missingobjects))

print("Disconnecting from Teradata database...")
disconnect(connection)
print("Done")
