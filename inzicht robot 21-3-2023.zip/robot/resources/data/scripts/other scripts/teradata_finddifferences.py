
import sys
import jaydebeapi

from teradata_private_module import get_username, get_password
from datetime import datetime
from os import listdir
from os.path import join
from time import sleep


JDBCDRIVERNAME = "com.teradata.jdbc.TeraDriver"
JDBCDRIVERJAR = ["C:\\ws\\apps\\Liquibase\\lib\\terajdbc4.jar", "C:\\ws\\apps\\Liquibase\\lib\\tdgssconfig.jar"]
DATABASEONTURL = "jdbc:teradata://rtdaoudll01.data.rsi.bdp.belastingdienst.nl"
DATABASEACCURL = "jdbc:teradata://tdunity-acc.data.bdp.belastingdienst.nl"
SCHEMAS = ["DG_I_P_40ANA_INZ", "DG_I_P_50PRO_INZ"]
CONFIGOBJECTSFILE = "C:/ws/projects/teradata/views.txt"
SKIPEXISTINGOBJECTS = False




def connecttoteradata(databaseurl):
    try:
        connection = jaydebeapi.connect(JDBCDRIVERNAME, databaseurl, [get_username(databaseurl), get_password(databaseurl)], JDBCDRIVERJAR)
    except:
        type, value, traceback = sys.exc_info()
        showfatalerror(10, "Could not connect to database: " + str(type) + " " + str(value), traceback)

    return connection


def executequery(connection, query):
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        result = cursor.fetchall()
#    except:
#        type, value, traceback = sys.exc_info()
#        print("")
#        showfatalerror(11, "Could not complete query: " + str(type) + " " + str(value), traceback)
    finally:
        cursor.close()

    return result


def disconnect(connection):
    connection.close()


def retrieveteradataobjects(url, environment):
    objects = []

    print("Connecting to Teradata " + environment + " database...")
    connection = connecttoteradata(url)

    print("Reading Teradata " + environment + " database objects...")
    query = "SELECT CASE WHEN tablekind = 'T' THEN 'table ' ELSE 'view ' END || databasename || '.' || tablename FROM DBC.tablesV WHERE databasename IN ('" + "', '".join(SCHEMAS) + "') AND tablekind IN ('T', 'V')ORDER BY databasename, tablename"
    tables = executequery(connection, query)
    for table in tables:
        tablename = str(table)[2:-3]
        tablekey = tablename.lower()
        objects.append(tablekey)

    print("Disconnecting from Teradata " + environment + " database...")
    disconnect(connection)

    return objects


def main():
    ont_objects = retrieveteradataobjects(DATABASEONTURL, "Ont")
    acc_objects = retrieveteradataobjects(DATABASEACCURL, "Acc")

    print("Comparing database objects...")
    for acc_object in acc_objects:
        if acc_object not in ont_objects:
            print("- acc only " + acc_object)
    
    for ont_object in ont_objects:
        if ont_object not in acc_objects:
            print("- ont only " + ont_object)
    
    print("Done")


main()

