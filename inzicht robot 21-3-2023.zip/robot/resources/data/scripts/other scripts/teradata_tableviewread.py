
import sys
import jaydebeapi

from teradata_private_module import get_username, get_password
from os import makedirs
from os.path import exists


JDBCDRIVERNAME = "com.teradata.jdbc.TeraDriver"
JDBCDRIVERJAR = ["C:\\ws\\apps\\Liquibase\\lib\\terajdbc4.jar", "C:\\ws\\apps\\Liquibase\\lib\\tdgssconfig.jar"]
DATABASEURL = "jdbc:teradata://rtdaoudll01.data.rsi.bdp.belastingdienst.nl"
#DATABASEURL = "jdbc:teradata://o802vtdavapp.ont.belastingdienst.nl"
SCRIPTDIRECTORY = "C:/ws/projects/teradata/scripts - source/"
SCHEMAS = ["DG_I_P_40ANA_INZ", "DG_I_P_50PRO_INZ"]
#SCHEMAS = ["IVAI_DEV_TABLE", "IVAI_DEV_VIEW"]


def showfatalerror(errorcode, errormessage, traceback):
    print("\n" + errormessage)
    sys.exit(errorcode)


def connecttoteradata():
    try:
        connection = jaydebeapi.connect(JDBCDRIVERNAME, DATABASEURL, [get_username(DATABASEURL), get_password(DATABASEURL)], JDBCDRIVERJAR)
    except:
        type, value, traceback = sys.exc_info()
        showfatalerror(10, "Could not connect to database: " + str(type) + " " + str(value), traceback)

    return connection


def executequery(connection, query):
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        result = cursor.fetchall()
    except:
        type, value, traceback = sys.exc_info()
        print("")
        showfatalerror(11, "Could not complete query: " + str(type) + " " + str(value), traceback)
    finally:
        cursor.close()

    return result


def disconnect(connection):
    connection.close()


print("Creating scripts directory...")
makedirs(SCRIPTDIRECTORY, exist_ok = True)

print("Connecting to Teradata database...")
connection = connecttoteradata()

print("Reading database tables...")
query = "SELECT databasename || '.' || tablename FROM DBC.tablesV WHERE tablekind = 'T' AND databasename IN ('" + "', '".join(SCHEMAS) + "')"
tables = executequery(connection, query)

for table in tables:
    tablename = str(table)[2:-3]
    print("Writing script for table " + tablename + "...")
    query = "SHOW TABLE " + tablename
    tablescript = executequery(connection, query)
    basename = str(table)[2:-3]
    filename = SCRIPTDIRECTORY + "table-" + basename.replace(".", "-").lower() + ".sql"
    with open(filename, "w", encoding = "utf-8") as outputfile:
        script = str(tablescript)[3:-4]
        scriptlines = script.replace('\\n', '\n').replace('\\r', '\n').split('\n')
        for scriptline in scriptlines:
            scriptline = scriptline.replace("\\t", " ")
            scriptline = scriptline.replace("\\'", "'")
            outputfile.write(scriptline + "\n")

    tablenameparts = tablename.split(".")
    query = "SELECT DISTINCT databasename || '.' || indexname FROM dbc.indicesV WHERE indextype = 'J' AND databasename = '" + tablenameparts[0] + "' AND tablename = '" + tablenameparts[1] + "'"
    joinindexes = executequery(connection, query)
    
    for joinindex in joinindexes:
        joinindexname = str(joinindex)[2:-3]
        print("Writing script for join index " + joinindexname + "...")
        query = "SHOW JOIN INDEX " + joinindexname
        joinindexscript = executequery(connection, query)
        basename = str(joinindex)[2:-3]
        filename = SCRIPTDIRECTORY + "joinindex-" + basename.replace(".", "-").lower() + ".sql"
        with open(filename, "w", encoding = "utf-8") as outputfile:
            script = str(joinindexscript)[3:-4]
            scriptlines = script.replace('\\n', '\n').replace('\\r', '\n').split('\n')
            for scriptline in scriptlines:
                scriptline = scriptline.replace("\\t", " ")
                scriptline = scriptline.replace("\\'", "'")
                outputfile.write(scriptline + "\n")


print("Reading database views...")
query = "SELECT databasename || '.' || tablename FROM DBC.tablesV WHERE tablekind = 'V' AND databasename IN ('" + "', '".join(SCHEMAS) + "')"
views = executequery(connection, query)

for view in views:
    viewname = str(view)[2:-3]
    print("Writing script for view " + viewname + "...")
    query = "SHOW VIEW " + viewname
    viewscript = executequery(connection, query)
    basename = str(view)[2:-3]
    filename = SCRIPTDIRECTORY + "view-" + basename.replace(".", "-").lower() + ".sql"
    with open(filename, "w", encoding = "utf-8") as outputfile:
        script = str(viewscript)[3:-4]
        scriptlines = script.replace('\\n', '\n').replace('\\r', '\n').split('\n')
        for scriptline in scriptlines:
            scriptline = scriptline.replace("\\t", " ")
            scriptline = scriptline.replace("\\'", "'")
            outputfile.write(scriptline + "\n")

print("Disconnecting from Teradata database...")
disconnect(connection)
print("Done")
