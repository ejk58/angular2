import os
import time

import jaydebeapi
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait


def setup_db2_connection(db2_connect_string, db2_login):
    conn = jaydebeapi.connect("com.ibm.db2.jcc.DB2Driver", db2_connect_string, db2_login,
                              os.path.dirname(os.path.abspath(__file__)) + "/db2/db2jcc4.jar")
    return conn


def get_conf_domain_attributes_from_db2(db2_connect_string, db2_login, db2_schema, domain):
    conn = setup_db2_connection(db2_connect_string, db2_login)
    curs = conn.cursor()
    curs.execute(
        f"SELECT attribute.KEY,attribute.VALUE FROM {db2_schema}.CONF_DOMAIN_ATTRIBUTE AS attribute LEFT JOIN {db2_schema}.CONF_DOMAIN AS domain ON attribute.DOMAIN_ID = domain.ID WHERE domain.KEY = '{domain}' ORDER BY attribute.ID")
    rows = curs.fetchall()
    curs.close()
    conn.close()
    return rows


def get_all_conf_domain_attributes(db2_connect_string, db2_login, db2_schema, domain):
    conn = setup_db2_connection(db2_connect_string, db2_login)
    curs = conn.cursor()
    curs.execute(
        f"SELECT attribute.KEY,attribute.VALUE FROM {db2_schema}.CONF_DOMAIN_ATTRIBUTE AS attribute LEFT JOIN {db2_schema}.CONF_DOMAIN AS domain ON attribute.DOMAIN_ID = domain.ID WHERE domain.KEY = '{domain}'")
    rows = curs.fetchall()
    curs.close()
    conn.close()
    return len(rows) - 1  # Minus 1 because there is a "subject" config domain attribute that we don't test.


def check_conf_domain_attribute_on_page(base_url, browser):
    browser.get(base_url)
    try:
        try:
            browser.find_element(By.XPATH,
                                 "//*/div[text()=' Je probeert gegevens op te halen waartoe je geen rechten hebt (401). ']")
        except NoSuchElementException:
            pass
        try:
            browser.find_element(By.CSS_SELECTOR, ".bd-anim-spin.loading")
        except NoSuchElementException:
            pass
        browser.get(base_url)
    except NoSuchElementException:
        pass

    WebDriverWait(browser, 10).until(EC.invisibility_of_element_located((By.CSS_SELECTOR, ".bd-anim-spin.loading")),
                                     "Widgets loading more than 10 seconds.")
    WebDriverWait(browser, 10).until(EC.invisibility_of_element_located((By.CSS_SELECTOR, ".fa-spin.loading")),
                                     "Widgets loading more than 10 seconds.")
    time.sleep(1)
    element = browser.find_elements(By.CSS_SELECTOR, '.widget-error div.notification.notification-error')
    return len(element)


def check_conf_domain_attribute(conf_attr_from_db, browser, environment, domain, path_keys, conf_attr_key):
    keys_from_db = [c[0] for c in conf_attr_from_db]

    if conf_attr_key not in keys_from_db:
        NoSuchElementException

    for c in conf_attr_from_db:
        if c[0] == conf_attr_key:
            conf_attr_value = c[1]
            break

    if len(conf_attr_from_db) != 0:
        found_errors = check_conf_domain_attribute_on_page(
            f"https://inzicht.{environment}.belastingdienst.nl/inzicht/#/main/(left:{domain}/{conf_attr_value};{path_keys})", browser)
    else:
        found_errors = -1
    return found_errors


def login_to_inzicht(login_url, app_user, app_password):
    options = Options()
    options.add_argument("--headless")
    browser = webdriver.Chrome(chrome_options=options)

    try:
        browser.get(login_url)
        element = browser.find_element(By.ID, "usernameInput")
        element.send_keys(app_user)
        element = browser.find_element(By.ID, "passwordInput")
        element.send_keys(app_password)
        element.send_keys(Keys.RETURN)
        WebDriverWait(browser, 10).until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".leftArea")),
                                         "Couldn't log in for more than 10 seconds.")
    except NoSuchElementException:
        pass

    return browser


def logout_from_inzicht(browser):
    browser.close()