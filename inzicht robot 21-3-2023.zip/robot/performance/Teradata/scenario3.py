query1 = "EXECUTE DG_I_O_40ANA_INZ.STRESSTEST_BASISGEGEVENS_WIDGET(<finr>);"
query2 = "EXECUTE DG_I_O_40ANA_INZ.STRESSTEST_FISCALE_ACTIVITEITEN_OB_WIDGET(<finr>);"
query3 = "EXECUTE DG_I_O_40ANA_INZ.STRESSTEST_ECONOMISCHE_ACTIVITEITEN_WIDGET(<finr>);"
query4 = "EXECUTE DG_I_O_40ANA_INZ.STRESSTEST_FISCALE_ACTIVITEITEN_LH_WIDGET(<finr>);"
query5 = "EXECUTE DG_I_O_40ANA_INZ.STRESSTEST_COMPETENTIE_WIDGET(<finr>);"
query6 = "EXECUTE DG_I_O_40ANA_INZ.STRESSTEST_TOEZENDGEGEVENS_WIDGET(<finr>);"
query7 = "EXECUTE DG_I_O_40ANA_INZ.STRESSTEST_MEER_CONTACTGEGEVENS_WIDGET(<finr>);"

a_file = open("finrs.txt", "r")
list_of_lists = [(line.strip()).split() for line in a_file]
a_file.close()

with open("scenario3.csv", "a") as myfile:
    for i in list_of_lists:
        query10 = query1.replace("<finr>", i[0])
        query20 = query2.replace("<finr>", i[0])
        query30 = query3.replace("<finr>", i[0])
        query40 = query4.replace("<finr>", i[0])
        query50 = query5.replace("<finr>", i[0])
        query60 = query6.replace("<finr>", i[0])
        query70 = query7.replace("<finr>", i[0])
        myfile.write(str(i[0]) + "|" + query10 + "|" + query20 + "|" + query30 + "|" + query40 + "|" + query50 + "|" + query60 + "|" + query70 + "\n")