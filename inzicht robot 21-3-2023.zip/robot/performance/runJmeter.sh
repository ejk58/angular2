echo -e "\e[33m################################################################"
echo -e "             Starting Inzicht performance test on PROD             "
echo -e "################################################################\e[0m"
echo -e ""
echo -e "\e[93m----------------------------------------------------------------"
echo -e "Running with 150 users"
echo -e "----------------------------------------------------------------\e[0m"
/opt/jmeter5/bin/jmeter -n -Jusername=bihas07 -Jpassword= -Jenvironment=. -JtaxYear=2015 -Jusers=150 -Jloops=5 -JnwBsnCsv=bsn2014.csv -JdiBsnCsv=bsnMKB.csv -JinvBsnCsv=bsnMKB.csv -t Inzicht.jmx -l results1.jtl -e -o ./dashboard1

mv -f results*.jtl ./dashboard1
mv -f jmeter.log ./dashboard1


echo -e ""
echo -e "\e[93m----------------------------------------------------------------"
echo -e "Running with 300 users"
echo -e "----------------------------------------------------------------\e[0m"
/opt/jmeter5/bin/jmeter -n -Jusername=bihas07 -Jpassword= -Jenvironment=. -JtaxYear=2015 -Jusers=250 -Jloops=5 -JnwBsnCsv=bsn2014.csv -JdiBsnCsv=bsnMKB.csv -JinvBsnCsv=bsnMKB.csv -t Inzicht.jmx -l results2.jtl -e -o ./dashboard2

mv -f results*.jtl ./dashboard2
mv -f jmeter.log ./dashboard2


echo -e ""
echo -e "\e[93m----------------------------------------------------------------"
echo -e "Running with 500 users"
echo -e "----------------------------------------------------------------\e[0m"
/opt/jmeter5/bin/jmeter -n -Jusername=bihas07 -Jpassword= -Jenvironment=. -JtaxYear=2015 -Jusers=500 -Jloops=5 -JnwBsnCsv=bsn2014.csv -JdiBsnCsv=bsnMKB.csv -JinvBsnCsv=bsnMKB.csv -t Inzicht.jmx -l results3.jtl -e -o ./dashboard3

mv -f results*.jtl ./dashboard3
mv -f jmeter.log ./dashboard3


echo -e ""
echo -e "\e[33m################################################################"
echo -e "            Inzicht performance test ended on PROD              "
echo -e "################################################################\e[0m"
