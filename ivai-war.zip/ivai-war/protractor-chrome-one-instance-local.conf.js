/**
 * Configuration to run protractor on 1 browser instance on local selenium grid (to start Chrome locally).
 *
 * Two configuration settings have been changed compared to protractor.conf.js:
 * - multiCapabilities (no 'shardTestFiles' and no 'maxInstances');
 * - seleniumAddress ('seleniumAddress' is empty).
 *
 * Reminder: run the pree2e script from package.json first!
 */
protractor = require('./protractor.conf.js');
var config = protractor.config;

// Capabilities for the webdriver instance
config.multiCapabilities = [
    {
        'browserName': 'chrome',
        'chromeOptions': {
            // Disable warnings and disable infobars when starting chrome
            'args': ['--disable-gpu --disable-infobars --disable-extensions --start-maximized --window-size=1366, 768'],
            // Allow to disable browser extentions that can interrupt tests
            useAutomationExtension: false
        }
    }
];

// Run tests on Selenium server, needed for run on Jenkins
config.seleniumAddress = '';

exports.config = config;
