/**
 * Configuration to run protractor on 1 browser instance.
 *
 * One configuration setting has been changed compared to protractor.conf.js:
 * - multiCapabilities (no 'shardTestFiles' and no 'maxInstances');
 */
protractor = require('./protractor.conf.js');
var config = protractor.config;

// Capabilities for the webdriver instance
config.multiCapabilities = [
    {
        'browserName': 'chrome',
        'chromeOptions': {
            // Disable warnings and disable infobars when starting chrome
            'args': ['--disable-gpu --disable-infobars --disable-extensions --start-maximized --window-size=1366, 768'],
            // Allow to disable browser extentions that can interrupt tests
            useAutomationExtension: false
        }
    }
];

exports.config = config;
