const {SpecReporter} = require('jasmine-spec-reporter');
var HtmlReporter2 = require('protractor-beautiful-reporter');

var fs = require('fs');

function rmDir(dirPath) {
    try {
        var files = fs.readdirSync(dirPath);
    }
    catch (e) {
        return;
    }
    if (files.length > 0)
        for (var i = 0; i < files.length; i++) {
            var filePath = dirPath + '/' + files[i];
            if (fs.statSync(filePath).isFile())
                fs.unlinkSync(filePath);
            else
                rmDir(filePath);
        }
    fs.rmdirSync(dirPath);
};

exports.config = {
    getPageTimeout: 120000,

    specs: [
        './src/test/e2e/**/*.e2e-spec.ts'
    ],

    localSeleniumStandaloneOpts: {
        // The port to start the Selenium Server on, or null if the server should
        // find its own unused port.
        // host: 'localhost',
        // port: 4444,
        jvmArgs: [
            '-Dwebdriver.chrome.driver=./node_modules/webdriver-manager/selenium/chromedriver_2.35.exe'
        ]
    },

    SELENIUM_PROMISE_MANAGER: false,

    // Capabilities for the webdriver instance.
    multiCapabilities: [
        {
            'browserName': 'chrome',
            'chromeOptions': {
                // Disable warnings and disable infobars when starting chrome
                'args': ['--disable-gpu --disable-infobars --disable-extensions --start-maximized --window-size=1366, 768'],
                // Allow to disable browser extentions that can interrupt tests
                useAutomationExtension: false
            },
            // // Allow different spec-files to run in parallel.
            // shardTestFiles: true,
            // // Maximum number of browser instances that can run in parallel
            // maxInstances: 15
        }
    ],
    baseUrl: 'https://inzicht.str11.ont.belastingdienst.nl/inzicht/#/login',
    //baseUrl: 'http://PVPCOBB245.ont.belastingdienst.nl:9080/inzicht/#/login',
    // Run tests on Selenium server, needed for run on Jenkins
    seleniumAddress: 'http://iva-selgrid.belastingdienst.nl:4444/wd/hub',

    useAllAngular2AppRoots: true,

    framework: 'jasmine',
    jasmineNodeOpts: {
        showColors: true,
        defaultTimeoutInterval: 120000,
        print: function () {
        }
    },

    /**
     * A callback function called once configs are read but before any
     * environment setup. This will only run once, and before onPrepare.
     * */
    beforeLaunch: function () {
        rmDir('./src/test/e2e/reports/e2e-tests');
        rmDir('./src/test/e2e/reports/.tmp');
    },

    /**
     * A callback function called once protractor is ready and available, and
     * before the specs are executed. If multiple capabilities are being run,
     * this will run once per capability.
     */
    onPrepare: function () {
        require('ts-node').register({
            project: './src/test/e2e/tsconfig.e2e.json'
        });

        jasmine.getEnv().addReporter(new SpecReporter({
            spec: {displayStacktrace: true}
        }));

        jasmine.getEnv().addReporter((new HtmlReporter2({
            baseDirectory: './src/test/e2e/reports/e2e-tests/',
            docTitle: 'Inzicht V2 E2E test report'
        }).getJasmine2Reporter()));

        //image-comparison config
        const protractorImageComparison = require('protractor-image-comparison');
        browser.protractorImageComparison = new protractorImageComparison({
            baselineFolder: './src/test/e2e/baseline/',
            screenshotPath: './src/test/e2e/reports/.tmp/',
            autoSaveBaseline: true,
            ignoreTransparentPixel: true,
            disableCSSAnimation: true
        });

    },

    /**
     * A callback function called once tests are finished. onComplete can
     * optionally return a promise, which Protractor will wait for before
     * shutting down webdriver.
     */
    onComplete: function () {
        browser.driver.close();
        browser.driver.quit();
    },
}
