package nl.belastingdienst.iva.inzicht.jira.domain;

import java.util.Map;

public class JiraErrorResponse {
	
	private String[] errorMessages;
	private Map<String, String> errors;
	
	public JiraErrorResponse() {}

	public String[] getErrorMessages() {
		return errorMessages;
	}

	public void setErrorMessages(String[] errorMessages) {
		this.errorMessages = errorMessages;
	}

	public Map<String, String> getErrors() {
		return errors;
	}

	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}
	
	
	
}
