package nl.belastingdienst.iva.inzicht.domain.query;

public class QueryResultColumn {

    private String columnName;
    private String columnAlias;
    private boolean maskable;
    private int hashCode;

    public QueryResultColumn(String columnName, String columnAlias, boolean maskable) {
        this.columnName = columnName;
        this.columnAlias = columnAlias;
        this.maskable = maskable;
        this.hashCode = calculateHashCode();
    }

    public String getColumnName() {
        return this.columnName;
    }
    
    public String getColumnAlias() {
        return this.columnAlias;
    }
    
    public boolean isMaskable() {
        return this.maskable;
    }
    
    public boolean hasColumnAlias() {
        return (this.columnAlias != null);
    }
    
    public String getName() {
        return this.columnAlias == null ? this.columnName : this.columnAlias;
    }

    @Override
    public int hashCode() {
        return this.hashCode;
    }
    
    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        } 
        
        if (object == null || (getClass() != object.getClass()) || (this.hashCode != object.hashCode())) {
            return false;
        }
        
        QueryResultColumn otherQueryTemplateColumn = (QueryResultColumn) object;
        
        return compareValues(this.columnName, otherQueryTemplateColumn.columnName) 
                && compareValues(this.columnAlias, otherQueryTemplateColumn.columnAlias)
                && (maskable == otherQueryTemplateColumn.maskable);
    }
    
    private boolean compareValues(String value, String otherValue) {
        return (value == null ? otherValue == null : value.equals(otherValue));
    }
    
    private int calculateHashCode() {
        final int prime = 31;
        int result = 1;
        
        result = prime * result + ((columnName == null) ? 0 : columnName.hashCode());
        result = prime * result + ((columnAlias == null) ? 0 : columnAlias.hashCode());
        result = prime * result + (maskable ? 1231 : 1237);

        return result;
    }
}
