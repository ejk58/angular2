package nl.belastingdienst.iva.inzicht.database.notification;

import java.util.List;

import javax.persistence.CacheRetrieveMode;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

public class NotificationDao {

  @PersistenceContext(unitName = "ivai-pu-inzicht")
  private EntityManager entityManager;

  public List<Notification> getNotificationMessages(String domainKey, String pageKey) {
    TypedQuery<Notification> query = entityManager.createNamedQuery(Notification.QUERY_GETNOTIFICATION, Notification.class);
    query.setParameter("domain", domainKey);
    query.setParameter("page", pageKey);
    query.setHint("javax.persistence.cache.retrieveMode", CacheRetrieveMode.BYPASS);

    return query.getResultList();
  }
}
