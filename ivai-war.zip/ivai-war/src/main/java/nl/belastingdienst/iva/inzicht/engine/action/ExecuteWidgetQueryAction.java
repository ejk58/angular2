package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public class ExecuteWidgetQueryAction implements Action {

	public static final String NAME = "ExecuteWidgetQuery";
	
	@Override
	public Flow execute(EngineRestCallContext restCallContext) {
		DataProvider dataProvider = restCallContext.getDataProvider();
        Widget widget = restCallContext.findWidget();
        Query query = widget.getQuery();
        DataMap[] result = (query == null) ? DomainUtils.emptyDataMapArray() : dataProvider.retrieveDataAsMultiMap(query, restCallContext);
        restCallContext.setResult(result);
        return Flow.CONTINUE;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + RulesEngineKey.PARAMETEREND;
	}
}
