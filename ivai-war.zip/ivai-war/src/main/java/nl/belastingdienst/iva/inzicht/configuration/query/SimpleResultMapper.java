package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.List;

import nl.belastingdienst.iva.inzicht.database.configuration.query.ResultMapper;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class SimpleResultMapper implements ResultMapper {

    private List<ColumnMapper> columnMappers;
	
	public SimpleResultMapper(List<ColumnMapper> columnMappers) {
		this.columnMappers = columnMappers;
	}
	
	@Override
	public DataMap[] map(DataMap[] sourceData) {
		DataMap[] destinationData = new DataHashMap[sourceData.length];
		
		for (int index = 0; index < sourceData.length; index++) {
			destinationData[index] = mapRow(sourceData[index]);
		}
		
		return destinationData;
	}
	
	public DataMap mapRow(DataMap sourceDataMap) {
		DataMap destinationDataMap = new DataHashMap();

        for (ColumnMapper columnMapper : this.columnMappers) {
        	destinationDataMap.put(columnMapper.getKey(), columnMapper.getValue(sourceDataMap));
        }
        
		return destinationDataMap;
	}
}
