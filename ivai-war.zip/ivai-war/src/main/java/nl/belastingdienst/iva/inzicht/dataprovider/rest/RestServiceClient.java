package nl.belastingdienst.iva.inzicht.dataprovider.rest;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.servlet.http.Cookie;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.NewCookie;

import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientWebException;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.CredentialsType;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProviderClient;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.JsonDataMapParser;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.User;

@Typed(RestServiceClient.class)
public class RestServiceClient implements DataProviderClient {

	@Inject
	private RestQueryFactory restQueryFactory;
	
    @Inject
    private JsonDataMapParser jsonDataMapParser;
	
    @Override
    public DataMap[] retrieveDataAsMultiMap(QueryInterface query, RestCallContext restCallContext) {
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();        
        RestQuery restQuery = this.restQueryFactory.getRestQuery(query, queryValues);
        String response = callRestService(restQuery, restCallContext);
        return processResponse(restQuery, response);
    }

    public DataMap[] retrieveDataAsMultiMap(Datasource datasource, QueryInterface query, RestCallContext restCallContext) {
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();        
        RestQuery restQuery = this.restQueryFactory.getRestQuery(datasource, query, queryValues);
        String response = callRestService(restQuery, restCallContext);
        return processResponse(restQuery, response);
    }

    private String callRestService(RestQuery restQuery, RestCallContext restCallContext) {
        String requestUrl = restQuery.getRequestUrl();
        Datasource datasource = restQuery.getDatasource();
        Resource resource = createResourceForDatasource(datasource, requestUrl, restCallContext);
        boolean trustAllCertificates = (datasource.getNumber(DatasourceKey.TRUSTALLCERTIFICATES) == 1);
        String result = null;

        try {
            trustAllCertificates(trustAllCertificates);
            result = resource.get(String.class);
        } catch (ClientWebException exception) {
            String message = "Failed to retrieve data from the rest-service with ClientWebException (status code = " + exception.getResponse().getStatusCode() +
                    ", error = '" + exception.getResponse().getEntity(String.class) + "'" + ")";
            throw new BadGatewayException(message, exception);
        } catch (Exception exception) {
            String message = "Failed to retrieve data from the rest-service with exception " + ExceptionUtils.getExceptionsForMessage(exception) +
                    " (request-url = '" + requestUrl + "')";
            throw new InternalServerErrorException(message, exception);
        }

        return result;
    }

    private Resource createResourceForDatasource(Datasource datasource, String requestUrl, RestCallContext restCallContext) {
        CredentialsType credentialsType = CredentialsType.findCredentialsType(datasource.getValue(DatasourceKey.CREDENTIALSTYPE));
        RestClient client = createRestClientForDatasource(datasource);
        String wsaAddress = datasource.getValue(DatasourceKey.WSAADDRESSHEADER);
        
        Resource resource = client.resource(requestUrl);
        resource.accept(MediaType.APPLICATION_JSON);
        resource.contentType(MediaType.APPLICATION_JSON);
        
        if (credentialsType != null) {
        	String cookieName = null;
            String credentialsValue;

            if (credentialsType == CredentialsType.LTPATOKEN || credentialsType == CredentialsType.LTPA2TOKEN) {
                User user = restCallContext.getUser();
                cookieName = credentialsType.getCookieName();
                credentialsValue = user.getLtpaToken();
            } else if (credentialsType == CredentialsType.SSOCOOKIE) {
                User user = restCallContext.getUser();
                Cookie ssoCookie = user.getSsoCookie();
                cookieName = ssoCookie.getName();
                credentialsValue = ssoCookie.getValue();
            } else {
                credentialsValue = datasource.getValue(DatasourceKey.CREDENTIALSVALUE);
            }
            
            if (credentialsType.isHttpHeader()) {
                resource.header(credentialsType.getHttpHeader(), credentialsValue);
            } else if (credentialsType.isCookieName()) {
                resource.cookie(new NewCookie(cookieName, credentialsValue));
            }
        }
        
        if (wsaAddress != null) {
            resource.header("X_WSA_ADDRESS_X", wsaAddress);
        }

        return resource;
    }
    
    private RestClient createRestClientForDatasource(Datasource datasource) {
        int connectTimeout = datasource.getNumber(DatasourceKey.CONNECTTIMEOUT);
        int readTimeout = datasource.getNumber(DatasourceKey.READTIMEOUT);
        boolean trustAllCertificates = (datasource.getNumber(DatasourceKey.TRUSTALLCERTIFICATES) == 1);

        ClientConfig clientConfig = new ClientConfig();
        clientConfig.connectTimeout(connectTimeout);
        clientConfig.readTimeout(readTimeout);
        clientConfig.setBypassHostnameVerification(trustAllCertificates);

        return new RestClient(clientConfig);
    }
    
    private void trustAllCertificates(boolean trustAllCertificates) {
        if (trustAllCertificates) {
            try {
                TrustManager[] trustManager = new TrustManager[]{new AllCertificatesTrustManager()};
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, trustManager, new java.security.SecureRandom());
                HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
                // TODO: niet statisch de trust zetten, maar per Datasource
            } catch (NoSuchAlgorithmException | KeyManagementException exception) {
                throw new InternalServerErrorException(exception.getMessage(), exception);
            }
        }
    }

    private DataMap[] processResponse(RestQuery restQuery, String response) {
    	String basePath = restQuery.getBasePath();
    	return this.jsonDataMapParser.parseJsonResult("rest-service", basePath, response);
    }
}
