package nl.belastingdienst.iva.inzicht.dataprovider.rest;

import javax.net.ssl.X509TrustManager;

public class AllCertificatesTrustManager implements X509TrustManager {
    
    @Override
    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
        return null;
    }
    
    @Override
    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
        // Do nothing, trust all
    }
    
    @Override
    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
        // Do nothing, trust all
    }
}
