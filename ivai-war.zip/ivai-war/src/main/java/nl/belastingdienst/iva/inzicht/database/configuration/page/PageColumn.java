package nl.belastingdienst.iva.inzicht.database.configuration.page;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;

@Entity
@Table(name = "CONF_PAGE_COLUMN")
public class PageColumn {

    @Id
    private Integer id;

    private Integer index;

    private boolean filterValue;

    private boolean filterLabel;

    @OneToOne
    @JoinColumn(name = "QUERY_COLUMN_ID")
    private QueryColumn queryColumn;

    @JsonIgnore
    public Integer getId() {
        return id;
    }

    @JsonIgnore
    public Integer getIndex() {
        return index;
    }

    public String getDestinationKey() {
        return this.queryColumn.getDestinationKey();
    }

    @JsonIgnore
    public boolean isMaskable() {
        return this.queryColumn.isMaskable();
    }

    @JsonIgnore
    public boolean isFilterValue() {
        return this.filterValue;
    }

    public boolean isFilterLabel() {
        return this.filterLabel;
    }
}
