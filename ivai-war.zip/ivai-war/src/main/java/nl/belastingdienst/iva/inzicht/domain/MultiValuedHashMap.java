package nl.belastingdienst.iva.inzicht.domain;

import javax.ws.rs.core.MultivaluedMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MultiValuedHashMap<K, V> extends HashMap<K, List<V>> implements MultivaluedMap<K, V> {

    private static final long serialVersionUID = 1L;

    public MultiValuedHashMap(MultivaluedMap<K, V> multiValuedMap) {
    	super(multiValuedMap);
    }
    
    public MultiValuedHashMap() {
    	super();
    }
    
    @Override
    public void add(K key, V value) {
        List<V> values = get(key);

        if (values == null) {
            values = new ArrayList<>();
        }
        values.add(value);
        put(key, values);
    }

    @Override
    public V getFirst(K key) {
        return (get(key) == null) ? null : get(key).get(0);
    }

    @Override
    public void putSingle(K key, V value) {
        List<V> values = new ArrayList<>();
        values.add(value);
        put(key, values);
    }
}
