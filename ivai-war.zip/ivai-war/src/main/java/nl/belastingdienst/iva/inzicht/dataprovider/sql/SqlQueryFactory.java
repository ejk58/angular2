package nl.belastingdienst.iva.inzicht.dataprovider.sql;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryFilter;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractQueryFactory;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;

public class SqlQueryFactory extends AbstractQueryFactory {
    
    public SqlQueryFactory() {
        registerParameterBuilder(QueryParameterType.STRING, new SqlStringQueryParameterBuilder());
        registerParameterBuilder(QueryParameterType.LISTOFSTRINGS, new SqlStringQueryParameterBuilder());
    }

    public SqlQuery getSqlQuery(Datasource datasource, QueryInterface query, MultivaluedMap<String, String> queryValues, Map<String, String> configurationValues) {
        String viewName = query.getViewName();
        List<QueryResultColumn> columns = mapColumns(query.getQueryColumns());
        
        String queryTemplate = query.getQueryTemplate();
        queryTemplate = addResultColumns(queryTemplate, columns);
        queryTemplate = addFilter(queryTemplate, query, queryValues);
        queryTemplate = addViewName(queryTemplate, viewName);
        queryTemplate = replaceParameters(queryTemplate, queryValues, configurationValues);

        return new SqlQuery(datasource, viewName, queryTemplate, columns);
    }
    
    public SqlQuery getSqlQuery(Datasource datasource, QueryInterface query, MultivaluedMap<String, String> queryValues) {
        return getSqlQuery(datasource, query, queryValues, Collections.<String, String>emptyMap());
    }
    
    public SqlQuery getSqlQuery(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Datasource datasource = query.getDatasource();
        return getSqlQuery(datasource, query, queryValues, Collections.<String, String>emptyMap());
    }
    
    public SqlQuery getSqlQuery(Datasource datasource, String viewName, String baseTemplate, MultivaluedMap<String, String> queryValues) {
        List<QueryResultColumn> columns = Collections.<QueryResultColumn>emptyList();
        
        String queryTemplate = baseTemplate;
        queryTemplate = addViewName(queryTemplate, viewName);
        queryTemplate = replaceParameters(queryTemplate, queryValues);
        
        return new SqlQuery(datasource, viewName, queryTemplate, columns);
    }
    
    private String addFilter(String queryTemplate, QueryInterface query, MultivaluedMap<String, String> queryValues) {
        return QueryUtils.addFilter(queryTemplate, buildFilters(query, queryValues));
    }
    
    private String addResultColumns(String queryTemplate, List<QueryResultColumn> columns) {
        return QueryUtils.addResultColumns(queryTemplate, buildResultColumns(columns));
    }

    private String addViewName(String queryTemplate, String viewName) {
        return QueryUtils.addViewName(queryTemplate, viewName);
    }
    
    private String buildFilters(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        List<QueryFilter> queryFilters = query.getQueryFilters();
        StringBuilder filter = new StringBuilder();

        for (QueryFilter queryFilter : queryFilters) {
            List<String> parameterList = queryFilter.getParameterList();
            boolean parameterAvailable = true;

            for (String parameter : parameterList) {
                parameterAvailable = parameterAvailable && queryValues.containsKey(parameter);
            }

            if (parameterAvailable) {
                filter.append(" ");
                filter.append(queryFilter.getFilterTemplate());
            } else if (queryFilter.hasNoFilterTemplate()) {
                filter.append(" ");
                filter.append(queryFilter.getNoFilterTemplate());
            }
        }

        return filter.toString();
    }
    
    private String buildResultColumns(List<QueryResultColumn> columnList) {
        StringBuilder resultColumns = new StringBuilder();

        if (columnList != null) {
            for (QueryResultColumn column : columnList) {
                if (resultColumns.length() > 0) {
                    resultColumns.append(", ");
                }

                resultColumns.append(column.getColumnName());
                resultColumns.append(" AS ");
                resultColumns.append(column.getName());
            }
        }

        return resultColumns.toString();
    }
}
