package nl.belastingdienst.iva.inzicht.jira.domain;

public class FixVersion {
	
	private String id;

	public FixVersion(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}
