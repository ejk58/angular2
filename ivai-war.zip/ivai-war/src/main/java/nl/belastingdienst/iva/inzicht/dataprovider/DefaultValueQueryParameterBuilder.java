package nl.belastingdienst.iva.inzicht.dataprovider;

import java.util.function.Function;

public class DefaultValueQueryParameterBuilder implements Function<String, String> {

    private String prefix;
    private String postfix;
    
    public DefaultValueQueryParameterBuilder(String prefix, String postfix) {
        this.prefix = prefix;
        this.postfix = postfix;
    }
    
    public DefaultValueQueryParameterBuilder() {
        this("", "");
    }
    
    @Override
    public String apply(String value) {
        return (value == null) ? null : this.prefix + value + this.postfix;
    }
}
