package nl.belastingdienst.iva.inzicht.service.subject;

import java.util.List;
import java.util.Map;

import javax.enterprise.inject.Typed;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainPathKey;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@Typed(SubjectMapper.class)
public class SubjectMapper {
    
    private static final String MODEL = "model";
    private static final String PRESENTATION = "presentation";

    private static final String TITLE = "title";
    private static final String NAME = "name";
    private static final String REMARK = "remark";
    private static final String LABEL = "label";
    private static final String BACKGROUNDCOLOR = "backgroundColor";
    private static final String COLOR = "color";
    
	public SubjectResponse[] map(Domain view, DataMap[] data) {
		SubjectResponse[] subjectResponse = new SubjectResponse[data.length];

		for (int index = 0; index < data.length; index++) {
			subjectResponse[index] = mapSubject(view, data[index]);
		}

		return subjectResponse;
	}

	public SubjectResponse mapSubject(Domain view, DataMap dataRow) {
		SubjectResponse subject = new SubjectResponse();

		subject.setModel(mapModel(view, dataRow.get(MODEL)));
		subject.setPresentation(mapPresentation(dataRow.get(PRESENTATION)));

		return subject;
	}

	private DataMap mapModel(Domain view, Object dataObject) {
        DataMap subjectModel = new DataHashMap();
	    
   	    if (dataObject instanceof Map) {
            List<DomainPathKey> pathKeys = view.getPathKeys();
   	        Map<?, ?> dataRow = (Map<?, ?>) dataObject;
    
    		pathKeys.stream()
    				.filter(pathKey -> pathKey.getMandatory())
    				.map(pathKey -> pathKey.getName())
    				.forEach(pathKeyName -> subjectModel.put(pathKeyName, dataRow.get(pathKeyName)));
        }

		return subjectModel;
	}

	private DataMap mapPresentation(Object dataObject) {
		DataMap subjectPresentation = new DataHashMap();

		if (dataObject instanceof Map) {
		    Map<?, ?> dataRow = (Map<?, ?>) dataObject;
		    
    		subjectPresentation.put(ResponseKey.TITLE, dataRow.get(TITLE));
    		subjectPresentation.put(ResponseKey.NAME, dataRow.get(NAME));
    		subjectPresentation.put(ResponseKey.REMARK, dataRow.get(REMARK));
    		subjectPresentation.put(ResponseKey.LABEL, mapLabel(dataRow));
		}

		return subjectPresentation;
	}

	private DataMap mapLabel(Map<?, ?> dataRow) {
		DataMap subjectLabel = new DataHashMap();

		subjectLabel.put(ResponseKey.TEXT, dataRow.get(LABEL));
        subjectLabel.put(ResponseKey.BACKGROUNDCOLOR, dataRow.containsKey(BACKGROUNDCOLOR) ? dataRow.get(BACKGROUNDCOLOR) : "#800000");
        subjectLabel.put(ResponseKey.COLOR, dataRow.containsKey(COLOR) ? dataRow.get(COLOR) : "#FFFFFF");

		return subjectLabel;
	}
}
