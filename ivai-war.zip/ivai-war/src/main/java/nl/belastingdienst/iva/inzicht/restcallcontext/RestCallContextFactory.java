package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotFoundException;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.User;

public class RestCallContextFactory {

    public RestCallContext getRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration, User user) {
    	long beginTime = System.currentTimeMillis();
        return user == null ? 
        		buildUnauthenticatedRestCallContext(serviceType, queryValues, configuration, beginTime) :
        		buildDefaultRestCallContext(serviceType, queryValues, configuration, user, beginTime);
    }

    public RestCallContext getRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration) {
    	long beginTime = System.currentTimeMillis();
        return buildUnauthenticatedRestCallContext(serviceType, queryValues, configuration, beginTime);
    }

    public RestCallContext getRestCallContext(RestCallContext restCallContext, MultivaluedMap<String, String> queryValues) {
        long beginTime = restCallContext.getBeginTime();
        RestServiceType serviceType = restCallContext.getServiceType();
        Configuration configuration = restCallContext.getConfiguration();
        User user = restCallContext.getUser();
        return buildDefaultRestCallContext(serviceType, queryValues, configuration, user, beginTime);
    }
    
    public RestCallContext getRestCallContext(RestCallContext restCallContext) {
        long beginTime = restCallContext.getBeginTime();
        RestServiceType serviceType = restCallContext.getServiceType();
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        Configuration configuration = restCallContext.getConfiguration();
        User user = restCallContext.getUser();
        List<DomainRole> authorizedRoles = restCallContext.getAuthorizedRoles();
        return buildEngineRestCallContext(serviceType, queryValues, configuration, user, authorizedRoles, beginTime);
    }
    
    private RestCallContext buildDefaultRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, 
    		Configuration configuration, User user, long beginTime) {
        List<DomainRole> authorizedRoles = determineAuthorizedRoles(queryValues, configuration);
        return new DefaultRestCallContext(serviceType, queryValues, configuration, user, authorizedRoles, beginTime);
    }

    private RestCallContext buildEngineRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, 
    		Configuration configuration, User user, List<DomainRole> authorizedRoles, long beginTime) {
        return new EngineRestCallContext(serviceType, queryValues, configuration, user, authorizedRoles, beginTime);
    }

    private RestCallContext buildUnauthenticatedRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, 
    		Configuration configuration, long beginTime) {
        return new UnauthenticatedRestCallContext(serviceType, queryValues, configuration, beginTime);
    }

    private List<DomainRole> determineAuthorizedRoles(MultivaluedMap<String, String> queryValues, Configuration configuration) {
        Set<Domain> relatedViews = determineLinkedViews(queryValues, configuration);
        Set<DomainRole> roles = new HashSet<>();
        
        for (Domain relatedView : relatedViews) {
            roles.addAll(relatedView.getRoles());
        }

        return new ArrayList<>(roles);
    }

    private Set<Domain> determineLinkedViews(MultivaluedMap<String, String> queryValues, Configuration configuration) {
        Set<Domain> linkedViews = null;

        if (queryValues.containsKey(QueryValueKey.DOMAINKEY)) {
        	linkedViews = merge(linkedViews, findDomain(queryValues.getFirst(QueryValueKey.DOMAINKEY), configuration));
        }
        
        if (queryValues.containsKey(QueryValueKey.VIEWKEY)) {
        	linkedViews = merge(linkedViews, findDomain(queryValues.getFirst(QueryValueKey.VIEWKEY), configuration));
        }
        
        if (queryValues.containsKey(QueryValueKey.PAGEKEY)) {
        	linkedViews = merge(linkedViews, findLinkedDomainsForPage(queryValues.getFirst(QueryValueKey.PAGEKEY), configuration));
        }
        
        if (queryValues.containsKey(QueryValueKey.TABKEY)) {
        	linkedViews = merge(linkedViews, findLinkedDomainsForPage(queryValues.getFirst(QueryValueKey.TABKEY), configuration));
        }
        
        if (queryValues.containsKey(QueryValueKey.WIDGETKEY)) {
        	linkedViews = merge(linkedViews, findLinkedDomainsForWidget(queryValues.getFirst(QueryValueKey.WIDGETKEY), configuration));
        }
        
        return linkedViews == null ? Collections.<Domain>emptySet() : linkedViews;
    }

    private Set<Domain> merge(Set<Domain> viewSet, Set<Domain> newViewSet) {
    	if (viewSet == null) {
    		viewSet = newViewSet; 
    	} else {
    		viewSet.retainAll(newViewSet);
    	}
    	
    	return viewSet;
    }
    
    private Set<Domain> findDomain(String domainKey, Configuration configuration) {
        Domain view = checkUnfoundItem("domain", domainKey, configuration.findDomain(domainKey));
        Set<Domain> viewSet = new HashSet<>();
        viewSet.add(view);
        return viewSet;
    }
    
    private Set<Domain> findLinkedDomainsForPage(String pageKey, Configuration configuration) {
        Page tab = checkUnfoundItem("page", pageKey, configuration.findPage(pageKey));
        return new HashSet<>(tab.getLinkedDomains());
    }

    private Set<Domain> findLinkedDomainsForWidget(String widgetKey, Configuration configuration) {
        Widget widget = checkUnfoundItem("widget", widgetKey, configuration.findWidget(widgetKey));
        return new HashSet<>(widget.getLinkedDomains());
    }

    private <T> T checkUnfoundItem(String item, String key, T value) {
        if (value == null) {
            throw (key == null || DomainUtils.isUndefined(key)) ? 
            	    new BadRequestException("The " + item + " " + key + " is not defined.") :
            	    new NotFoundException("The " + item + " " + key + " is not found.");
        }
        
        return value;
    }
}
