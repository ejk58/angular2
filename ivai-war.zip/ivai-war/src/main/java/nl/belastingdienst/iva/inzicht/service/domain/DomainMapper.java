package nl.belastingdienst.iva.inzicht.service.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.enterprise.inject.Typed;

import nl.belastingdienst.iva.inzicht.configuration.domain.DomainComparator;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainMenuGroup;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageDomain;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@Typed(DomainMapper.class)
public class DomainMapper {

    private DomainComparator domainComparator = new DomainComparator();
    
    public DataMap map(Set<Domain> domainSet) {
        List<Domain> domainList = new ArrayList<>(domainSet);
        DataMap domainResponse = new DataHashMap();
        List<DataMap> domains = new ArrayList<>();

        Collections.sort(domainList, this.domainComparator);
        for (Domain domain : domainList) {
            if (!domain.getPageDomains().isEmpty()) {
                PageDomain pageDomain = domain.getPageDomains().get(0);
                Page page = pageDomain.getPage();
                DataMap domainDataMap = new DataHashMap();
                
                domainDataMap.put(ResponseKey.DOMAINID, domain.getKey());
                domainDataMap.put(ResponseKey.NAME, domain.getName());
                domainDataMap.put(ResponseKey.ICONNAME, domain.getIconName());
                domainDataMap.put(ResponseKey.PATHKEYS, domain.getPathKeys());
                domainDataMap.put(ResponseKey.SUBJECTTYPES, domain.getSubjectTypes());
                domainDataMap.put(ResponseKey.INITIALPAGE, page.getKey());
                domainDataMap.put(ResponseKey.INDEX, domain.getIndex());
                
                domains.add(domainDataMap);
            }
        }
        
        domainResponse.put(ResponseKey.VIEWS, domains);
        
        return domainResponse;
    }
    
    public DataMap map(Domain domain, List<String> importantPages) {
        DataMap domainResponse = new DataHashMap();

        domainResponse.put(ResponseKey.DOMAINS, mapDomains(domain, importantPages));
        domainResponse.put(ResponseKey.ATTRIBUTES, mapAttributes(domain));
        
        return domainResponse;
    }
    
    public DataMap map(Domain domain) {
        return map(domain, Collections.<String>emptyList());
    }
    
    private DataMap[] mapDomains(Domain domain, List<String> importantPages) {
        SortedSet<Integer> menuGroupIndexSet = getMenuGroupIndexSet(domain);
        List<DataMap> domains = new ArrayList<>();

        for (int menuGroupIndex : menuGroupIndexSet) {
            DataMap menuGroup = new DataHashMap();
            DomainMenuGroup viewMenuGroup = getMenuGroupByIndex(domain, menuGroupIndex);
            
            menuGroup.put(ResponseKey.TITLE, viewMenuGroup == null ? null : viewMenuGroup.getTitle());
            menuGroup.put(ResponseKey.ICONNAME, viewMenuGroup == null ? null : viewMenuGroup.getIconName());
            menuGroup.put(ResponseKey.OPTIONS, mapMenuItems(domain, importantPages, menuGroupIndex));

            domains.add(menuGroup);
        }
        
        return DomainUtils.inArray(domains);
    }
    
    private DataMap mapAttributes(Domain domain) {
        Map<String, String> domainAttributes = domain.getAttributes();
        DataMap attributes = new DataHashMap();
        
        attributes.putAll(domainAttributes);
        
        return attributes;
    }
    
    private DataMap[] mapMenuItems(Domain domain, List<String> importantPages, int index) {
        List<PageDomain> pageDomains = domain.getPageDomains();
        List<DataMap> menuItems = new ArrayList<>();
        
        for (PageDomain pageDomain : pageDomains) {
            if (pageDomain.getGroupIndex() != null && pageDomain.getGroupIndex() == index) {
                Page tab = pageDomain.getPage();
                String tabTitle = tab.getTitle();
                DataMap menuItem = new DataHashMap();
                
                menuItem.put(ResponseKey.KEY, tab.getKey());
                menuItem.put(ResponseKey.LABEL, tabTitle);
                menuItem.put(ResponseKey.MACHINENAME, tab.getKey());
                menuItem.put(ResponseKey.IMPORTANT, importantPages.contains(tabTitle.toLowerCase()));
                menuItem.put(ResponseKey.INDEX, pageDomain.getMemberIndex());
                
                menuItems.add(menuItem);
            }
        }

        return DomainUtils.inArray(menuItems);
    }
    
    private SortedSet<Integer> getMenuGroupIndexSet(Domain domain) {
        SortedSet<Integer> menuGroupIndexSet = new TreeSet<>();
        
        List<PageDomain> pageDomains = domain.getPageDomains();
        for (PageDomain pageDomain : pageDomains) {
            if (pageDomain.getGroupIndex() != null) {
                menuGroupIndexSet.add(pageDomain.getGroupIndex());
            }
        }
        
        return menuGroupIndexSet;
    }
    
    private DomainMenuGroup getMenuGroupByIndex(Domain view, int index) {
        List<DomainMenuGroup> viewMenuGroups = view.getMenuGroups();
        
        for (DomainMenuGroup viewMenuGroup : viewMenuGroups) {
            if (viewMenuGroup.getIndex() == index) {
                return viewMenuGroup;
            }
        }
        
        return null;
    }
}
