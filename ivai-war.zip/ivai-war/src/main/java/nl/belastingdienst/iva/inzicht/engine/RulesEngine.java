package nl.belastingdienst.iva.inzicht.engine;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.engine.action.ActionFactory;
import nl.belastingdienst.iva.inzicht.engine.condition.ConditionFactory;
import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContextFactory;

@Singleton
@Startup
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class RulesEngine {

    @Inject
    private DataProvider dataProvider;

    @Inject
	private RestCallContextFactory restCallContextFactory;
    
    @Inject
    private ConditionFactory conditionFactory;
    
    @Inject
    private ActionFactory actionFactory;
    
	public DataMap[] run(RuleInterface rule, RestCallContext restCallContext, DataMap[] result) {
		EngineRestCallContext engineRestCallContext = getEngineRestCallContext(restCallContext, result);
		rule.apply(engineRestCallContext);
		return engineRestCallContext.getResult();
	}
	
	public DataMap[] run(RuleInterface rule, RestCallContext restCallContext) {
		return run(rule, restCallContext, DomainUtils.emptyDataMapArray());
	}
	
	public ConditionFactory getConditionFactory() {
		return this.conditionFactory;
	}
	
	public ActionFactory getActionFactory() {
		return this.actionFactory;
	}
	
    public DataMap getStatus() {
        return DomainUtils.emptyDataMap();
    }
    
    private EngineRestCallContext getEngineRestCallContext(RestCallContext restCallContext, DataMap[] result) {
    	EngineRestCallContext engineRestCallContext = (EngineRestCallContext) this.restCallContextFactory.getRestCallContext(restCallContext);
    	engineRestCallContext.setResult(result);
    	engineRestCallContext.setDataProvider(this.dataProvider);
    	return engineRestCallContext;
    }
}
