package nl.belastingdienst.iva.inzicht.domain;

public enum MessageType {

    ERROR("Error"),
    WARNING("Warning"),
    MESSAGE("Message"),
    PERFORMANCE("Performance");

    private String label;
    
    private MessageType(String name) {
        this.label = "type = " + name;
    }
    
    public String getLabel() {
        return this.label;
    }
}
