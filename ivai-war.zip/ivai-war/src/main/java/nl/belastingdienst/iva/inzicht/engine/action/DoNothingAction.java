package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public class DoNothingAction implements Action {

	public static final String NAME = "DoNothing";
	
	@Override
	public Flow execute(EngineRestCallContext restCallContext) {
		return Flow.CONTINUE;
	}

	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + RulesEngineKey.PARAMETEREND;
	}
}
