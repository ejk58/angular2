package nl.belastingdienst.iva.inzicht.configuration.datasource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.login.LoginException;

import org.apache.log4j.Logger;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;

public class DatasourceParser {
    
    private static final Logger logger = Logger.getLogger(DatasourceParser.class);

    public Map<String, Datasource> parse(List<Datasource> datasourceList) {
    	Map<String, Datasource> datasourceMap = new HashMap<>();
    	
    	for (Datasource datasource : datasourceList) {
    		parseDatasource(datasource.getKey(), datasource);
            datasourceMap.put(datasource.getKey(), datasource);
    	}
    	
    	return datasourceMap;
    }

    private void parseDatasource(String key, Datasource datasource) {
    	try {
    		datasource.buildParameterMap();
        } catch (LoginException | IllegalStateException exception) {
            logger.error(MessageUtils.createMessage(MessageType.ERROR, "Failed to extract the credentials for datasource " + key + 
                    " with the exception " + exception.getClass().getSimpleName() + ": " + exception.getMessage()));
        }
    }
}
