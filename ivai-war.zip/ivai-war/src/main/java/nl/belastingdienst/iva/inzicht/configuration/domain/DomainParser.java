package nl.belastingdienst.iva.inzicht.configuration.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageDomain;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class DomainParser {

    private Map<String, Domain> domainMap;
    private Map<DomainRole, List<Domain>> domainsPerRoleMap;
    
    public DomainParser(List<Domain> domainList) {
        List<Domain> domains = enhanceDomains(domainList);
        
        createDomainMap(domains);
        createDomainssPerRole(domains);
        linkDomains(domains);
    }
    
    public Map<String, Domain> getDomainMap() {
    	return this.domainMap;
    }

    public Map<DomainRole, List<Domain>> getDomainsPerRole() {
    	return this.domainsPerRoleMap;
    }
    
    public List<String> getDomainKeyList() {
    	return new ArrayList<>(this.domainMap.keySet());
    }
    
    private void createDomainMap(List<Domain> domainList) {
        this.domainMap = new LinkedHashMap<>();
        
        for (Domain domain : domainList) {
            String domainKey = domain.getKey().toLowerCase();
            this.domainMap.put(domainKey, domain);
        }
    }
    
    private void createDomainssPerRole(List<Domain> domainList) {
        this.domainsPerRoleMap = new HashMap<>();
        
        for (Domain domain : domainList) {
            List<DomainRole> roles = domain.getRoles();
            
            for (DomainRole role : roles) {
                if (!this.domainsPerRoleMap.containsKey(role)) {
                    this.domainsPerRoleMap.put(role, new ArrayList<Domain>());
                }
                
                this.domainsPerRoleMap.get(role).add(domain);
            }
        }
    }
    
    private List<Domain> enhanceDomains(List<Domain> domains) {
        
        for (Domain domain : domains) {
            DataMap domainDataMap = convertToDataMap(domain);
            domain.setDomainMap(domainDataMap);
        }
        
        return domains;
    }    
    
    private List<Domain> linkDomains(List<Domain> domains) {
        for (Domain domain : domains) {
        	domain.linkDomain();
        }
        
        return domains;
    }
    
    private DataMap convertToDataMap(Domain domain) {
        List<PageDomain> pageDomainList = domain.getPageDomains();
        DataMap domainDataMap = new DataHashMap();

        domainDataMap.put("viewId", domain.getKey());
        domainDataMap.put("name", domain.getName());
        
        if (!pageDomainList.isEmpty()) {
        	PageDomain pageDomain = pageDomainList.get(0);
            Page tab = pageDomain.getPage();
            domainDataMap.put("initTab", tab.getKey());
        }
        
        domainDataMap.put("pathKeys", domain.getPathKeys());
        domainDataMap.put("index", domain.getIndex());
        
        return domainDataMap;
    }
}
