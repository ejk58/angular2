package nl.belastingdienst.iva.inzicht.service.subject;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.ForbiddenException;
import nl.belastingdienst.iva.inzicht.domain.exception.GatewayTimeoutException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotAuthorizedException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotFoundException;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.service.audit.AuditTrailService;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/subject")
@RolesAllowed({ RoleUtils.INZICHT_USER_ROLE })
public class SubjectService extends AbstractRestService {

    @Inject
    private AuditTrailService auditTrailService;

    @Inject
    private DataProvider dataprovider;
    
    @Inject
    private SubjectMapper subjectMapper;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getSubject(@Context UriInfo uriInfo) {
    	MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.SUBJECTSERVICE, queryValues);
        
        try {
            logSubjectSearch(restCallContext);
            checkRequiredRoles(restCallContext);
            checkRequiredPermission(restCallContext);
            
            Domain view = restCallContext.findView();
            boolean vipUser = RoleUtils.isVipUser(restCallContext);
            Query query = vipUser ? view.getSearchVipQuery() : view.getSearchNoVipQuery();
            DataMap[] response = this.dataprovider.retrieveDataAsMultiMap(query, restCallContext);
            Status status = determineStatus(restCallContext, response, vipUser);
            
            return buildResponse(status, this.subjectMapper.map(view, response), restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }

    private void logSubjectSearch(RestCallContext restCallContext) {
        this.auditTrailService.logSubjectSearch(restCallContext);
    }

    private Status determineStatus(RestCallContext restCallContext, DataMap[] dataMap, boolean vipUser) {
        Status status;
        
        if (dataMap.length > 0 || !restCallContext.hasDomainPathKeys()) {
            status = Status.OK;
        } else {
            status = Status.NOT_FOUND;
        }
        
        return status;
    }

    @Override
    protected boolean isExceptionForWarningMessage(Throwable exception) {
        return (exception instanceof BadRequestException) || (exception instanceof NotAuthorizedException) || 
                (exception instanceof NotFoundException) || (exception instanceof GatewayTimeoutException);
    }

    @Override
    protected boolean isExceptionForErrorMessage(Throwable exception) {
        return (exception instanceof ForbiddenException) || 
                (exception instanceof InternalServerErrorException) || (exception instanceof BadGatewayException);
    }
}
