package nl.belastingdienst.iva.inzicht.jira.domain;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class JiraIssueFields {
	
	private Project project;
	private String summary;
	private IssueType issuetype;
	private String description;
	private FixVersion[] fixVersions;
	private String[] labels;
	
	private String epicLink;
	
	public JiraIssueFields(Project project, String summary, IssueType issuetype, String description, FixVersion[] fixVersions, String[] labels) {
		this.project = project;
		this.summary = summary;
		this.issuetype = issuetype;
		this.description = description;
		this.fixVersions = fixVersions;
		this.labels = labels;
	}

	public Project getProject() {
		return project;
	}

	public String getSummary() {
		return summary;
	}

	public IssueType getIssuetype() {
		return issuetype;
	}

	public String getDescription() {
		return description;
	}

	public FixVersion[] getFixVersions() {
		return fixVersions;
	}
	
	public String[] getLabels() {
		return labels;
	}
	
	@JsonProperty("customfield_10001")
	public String getEpicLink() {
		return epicLink;
	}
	public void setEpicLink(String epicLink) {
		this.epicLink = epicLink;
	}

}
