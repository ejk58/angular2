package nl.belastingdienst.iva.inzicht.service.event;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import nl.belastingdienst.iva.inzicht.database.event.Event;
import nl.belastingdienst.iva.inzicht.database.event.EventDao;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/event")
@RolesAllowed({ RoleUtils.INZICHT_USER_ROLE })
public class EventService extends AbstractRestService {

    @Inject
	private EventDao eventDao;

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response saveEvent(Event event) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>();
        queryValues.add(QueryValueKey.EVENT, event == null ? "null" : event.toString());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.EVENTSAVESERVICE, queryValues);

        try {
    		this.eventDao.saveEvent(event);
            return buildResponse(restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
	}
}
