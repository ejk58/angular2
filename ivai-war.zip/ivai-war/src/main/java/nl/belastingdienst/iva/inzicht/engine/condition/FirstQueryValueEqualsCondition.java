package nl.belastingdienst.iva.inzicht.engine.condition;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public class FirstQueryValueEqualsCondition implements Condition {

	public static final String NAME = "FirstQueryValueEquals";
	
	private String queryValueKey;
	private String value;
	
	public FirstQueryValueEqualsCondition(String queryValueKey, String value) {
		this.queryValueKey = queryValueKey;
		this.value = value;
	}
	
	@Override
	public boolean test(EngineRestCallContext restCallContext) {
		MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
		return this.value.equals(queryValues.getFirst(this.queryValueKey));
	}

	@Override
	public String getCondition() {
		return NAME + RulesEngineKey.PARAMETERSTART + this.queryValueKey + RulesEngineKey.PARAMETERSEPARATOR + this.value + RulesEngineKey.PARAMETEREND;
	}
}
