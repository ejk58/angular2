package nl.belastingdienst.iva.inzicht.jira.domain;

public class JiraIssue {
	
	private JiraIssueFields fields;

	public JiraIssue(JiraIssueFields fields) {
		this.fields = fields;
	}

	public JiraIssueFields getFields() {
		return fields;
	}
	
}
