package nl.belastingdienst.iva.inzicht.engine;

import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public interface RuleInterface {

	Flow apply(EngineRestCallContext restCallContext);
	String getRule();
}
