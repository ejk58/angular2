package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.Map;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class TranslateColumnMapper implements ColumnMapper {

	private ColumnMapper innerColumnMapper;
	private String destinationKey;
	private Map<String, String> translationMap;
	
	public TranslateColumnMapper(ColumnMapper innerColumnMapper, String destinationKey, Map<String, String> translationMap) {
		this.innerColumnMapper = innerColumnMapper;
		this.destinationKey = destinationKey;
		this.translationMap = translationMap;
	}
	
	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public Object getValue(DataMap sourceDataMap) {
		Object sourceData = this.innerColumnMapper.getValue(sourceDataMap);

		return this.translationMap.containsKey(sourceData) ? this.translationMap.get(sourceData) : sourceData; 
	}
}
