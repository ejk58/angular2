package nl.belastingdienst.iva.inzicht.configuration.widget;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageAttribute;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageWidget;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.WidgetAttribute;

public class WidgetParser {

    private List<Widget> widgetList;
    private Map<String, Widget> widgetMap;

    public WidgetParser(List<Page> pageList, List<Widget> exportWidgetList) {
        buildWidgetListAndMap(pageList, exportWidgetList);
    }

    public Map<String, Widget> getWidgetMap() {
        return this.widgetMap;
    }

    private void buildWidgetListAndMap(List<Page> pageList, List<Widget> exportWidgetList) {
        this.widgetList = new ArrayList<>();
        this.widgetMap = new HashMap<>();

        for (Page page : pageList) {
            for (PageWidget pageWidget : page.getPageWidgets()) {
                buildWidgetListAndMap(pageWidget.getWidget());
            }
        }
        
        for (Widget widget : exportWidgetList) {
            buildWidgetListAndMap(widget);
        }
        
        for (Widget widget : this.widgetList) {
            linkWidgetFromWidgetAttributeToDomains(widget);
        }
        
        for (Page page : pageList) {
            linkWidgetFromPageAttributeToDomains(page);
        }
    }
    
    private void buildWidgetListAndMap(Widget widget) {
        if (!this.widgetMap.containsKey(widget.getName())) {
            this.widgetList.add(widget);
            this.widgetMap.put(widget.getName(), widget);
            
            for (Widget innerWidget : widget.getWidgetList()) {
                buildWidgetListAndMap(innerWidget);
            }
        }
    }
    
    private void linkWidgetFromWidgetAttributeToDomains(Widget widget) {
        for (WidgetAttribute widgetAttribute : widget.getAttributeList()) {
            String attributeKey = widgetAttribute.getKey();
            
            if (attributeKey.endsWith("Widget")) {
                String widgetName = widgetAttribute.getValue();
                Widget innerWidget = this.widgetMap.get(widgetName);
                
                if (innerWidget != null) {
                    List<Domain> linkedDomains = widget.getLinkedDomains();
                    linkedDomains.forEach(innerWidget::linkDomain);
                }
            }
        }
    }
    
    private void linkWidgetFromPageAttributeToDomains(Page page) {
        for (PageAttribute pageAttribute : page.getAttributeList()) {
            String attributeKey = pageAttribute.getKey();
            
            if (attributeKey.endsWith("Widget")) {
                String widgetName = pageAttribute.getValue();
                Widget innerWidget = this.widgetMap.get(widgetName);
                
                if (innerWidget != null) {
                    List<Domain> linkedDomains = page.getLinkedDomains();
                    linkedDomains.forEach(innerWidget::linkDomain);
                }
            }
        }
    }
}
