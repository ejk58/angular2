package nl.belastingdienst.iva.inzicht.database.configuration.widget;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageWidget;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.database.configuration.rule.RuleGroup;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.query.QueryType;

@Entity
@Table(name = "CONF_WIDGET")
@NamedQuery(name = Widget.QUERY_GETWIDGETS, query = "SELECT w FROM Widget w " + 
        "LEFT JOIN FETCH w.attributeList " + 
        "LEFT JOIN FETCH w.columnList " + 
        "LEFT JOIN FETCH w.helpList " + 
        "ORDER BY w.name")
public class Widget {
    
    public static final String QUERY_GETWIDGETS = "Widget.getWidgets";

    @Id
    private Integer id;
    private Integer index;
    private String name;
    private String type;
    private String title;
    private String description;
    private String descriptionMore;
    private boolean refreshInfo;
    private boolean visible;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "QUERY_ID")
    private Query query;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RULE_GROUP_ID")
    private RuleGroup ruleGroup;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "rowIndex, columnIndex")
    private List<PageWidget> pageWidgets = new ArrayList<>();

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "key")
    private List<WidgetAttribute> attributeList;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "index")
    private List<WidgetColumn> columnList;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "CONTAINER_WIDGET_ID")
    @OrderBy(value = "index")
    private List<Widget> widgetList;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "WIDGET_ID")
    @OrderBy(value = "index")
    private List<WidgetHelp> helpList;

    @Transient
    private DataMap[] refreshInfoMap;
    
    @Transient
    private List<Domain> linkedDomains;
    
    public Integer getId() {
        return this.id;
    }

    public Integer getIndex() {
        return this.index;
    }

    public String getName() {
        return this.name;
    }

    public String getType() {
        return this.type;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public String getDescriptionMore() {
        return this.descriptionMore;
    }

    public Query getQuery() {
        return this.query;
    }
    
    public RuleGroup getRuleGroup() {
		return this.ruleGroup;
	}

	public boolean isRefreshInfo() {
        return this.refreshInfo && 
        		(this.query != null && query.getType() == QueryType.TERADATA && this.query.getViewName() != null);
    }

    public boolean isVisible() {
        return this.visible;
    }

    public List<WidgetAttribute> getAttributeList() {
        return attributeList;
    }

    public List<WidgetColumn> getColumnList() {
        return columnList;
    }

    public List<Widget> getWidgetList() {
        return widgetList;
    }

    public List<WidgetHelp> getHelpList() {
        return helpList;
    }

    public DataMap[] getRefreshInfoMap() {
    	return this.refreshInfoMap;
    }
    
    public List<Domain> getLinkedDomains() {
        return (this.linkedDomains == null ? Collections.<Domain>emptyList() : Collections.unmodifiableList(this.linkedDomains));
    }

    public void setRefreshInfoMap(DataMap[] refreshInfoMap) {
    	this.refreshInfoMap = refreshInfoMap;
    }
    
    public void linkDomain(Domain domain) {
    	
    	if (this.linkedDomains == null) {
    		this.linkedDomains = new ArrayList<>();
    	}
    	
    	if (!this.linkedDomains.contains(domain)) {
    		this.linkedDomains.add(domain);
    	}
    	
        for (Widget innerWidget : this.widgetList) {
        	innerWidget.linkDomain(domain);
        }
    }

    public String toString(String prefix) {
    	StringBuilder widgetBuilder = new StringBuilder();
    
    	widgetBuilder.append(prefix);
    	widgetBuilder.append("widget = ");
    	widgetBuilder.append(this.name);
    	widgetBuilder.append(" (title = ");
    	widgetBuilder.append(this.title);
    	widgetBuilder.append(", type = ");
    	widgetBuilder.append(this.type);
    	widgetBuilder.append(", query = ");
    	widgetBuilder.append(this.query == null ? "<none>" : this.query.getKey());
    	widgetBuilder.append(")\n");
    	
    	for (Widget widget : this.widgetList) {
    		widgetBuilder.append(widget.toString("    " + prefix));
    	}
    	
    	return widgetBuilder.toString();
    }
}
