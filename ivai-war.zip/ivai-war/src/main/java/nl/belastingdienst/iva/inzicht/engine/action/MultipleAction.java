package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.List;
import java.util.stream.Collectors;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public class MultipleAction implements Action {

	private List<? extends Action> actions;

	public MultipleAction(List<? extends Action> actions) {
		this.actions = actions;
	}
	
	@Override
	public Flow execute(EngineRestCallContext restCallContext) {
		Flow flow = Flow.CONTINUE;
		
		for (Action action : this.actions) {
			Flow actionFlow = action.execute(restCallContext);
			flow = Flow.getNextFlow(flow, actionFlow);
		}
		
		return flow;
	}

	@Override
	public String getAction() {
		return this.actions.stream().map(Action::getAction).collect(Collectors.joining(" " + RulesEngineKey.ACTIONOPERATOR + " "));
	}
}
