package nl.belastingdienst.iva.inzicht.configuration.query;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class HashColumnMapper implements ColumnMapper {

	private static final String HASHALGORITHM = "MD5";
	
	private ColumnMapper innerColumnMapper;
	private String destinationKey;
	
	public HashColumnMapper(ColumnMapper innerColumnMapper, String destinationKey) {
		this.innerColumnMapper = innerColumnMapper;
		this.destinationKey = destinationKey;
	}
	
	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public Object getValue(DataMap sourceDataMap) {
		Object sourceData = this.innerColumnMapper.getValue(sourceDataMap);
		return createHash(sourceData); 
	}
	
	private String createHash(Object sourceData) {
		if (sourceData != null) {
			try {
				MessageDigest messageDigest = MessageDigest.getInstance(HASHALGORITHM);
		        messageDigest.update(sourceData.toString().getBytes());
		        byte[] bytes = messageDigest.digest();
		        
		        StringBuilder hashBuilder = new StringBuilder();
		        for (int index = 0; index < bytes.length ;index++) {
		        	hashBuilder.append(Integer.toString((bytes[index] & 0xff) + 0x100, 16).substring(1));
		        }
		        return hashBuilder.toString();
			} catch (NoSuchAlgorithmException exception) {
				throw new IllegalStateException("The hashing algorithm " + HASHALGORITHM + " does not exist.", exception);
			}
		}

		return null;
	}
}
