package nl.belastingdienst.iva.inzicht.database.feedback;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class FeedbackDao {

    @PersistenceContext(unitName = "ivai-pu-inzicht")
    private EntityManager entityManager;

    public void saveFeedback(Feedback feedback) {
        this.entityManager.persist(feedback);
    }
}
