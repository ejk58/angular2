package nl.belastingdienst.iva.inzicht.service.page;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;

public class PageItem implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "widget")
    private String widgetId;

    @XmlElement(name = "title")
    private String widgetTitle;
    
    @XmlElement(name = "type")
    private String widgetType;

    @XmlElement(name = "gridColumns")
    private int gridColumns;

    public PageItem(Widget widget, int gridColumns) {
        this.widgetId = widget.getName();
        this.widgetTitle = widget.getTitle();
        this.widgetType = widget.getType();
        this.gridColumns = gridColumns;
    }

    public String getWidget() {
        return widgetId;
    }

    public String getTitle() {
        return widgetTitle;
    }
    
    public String getType() {
    	return widgetType;
    }

    public int getGridColumns() {
        return gridColumns;
    }
}
