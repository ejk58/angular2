package nl.belastingdienst.iva.inzicht.database.configuration.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CONF_DOMAIN_SUBJECTTYPE")
public class DomainSubjectType {

    @Id
    private int id;
    private String name;
    private String type;

    public DomainSubjectType() {
        super();
    }
    
    public DomainSubjectType(String name, String type) {
        this.name = name;
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }
}
