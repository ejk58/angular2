package nl.belastingdienst.iva.inzicht.database.configuration.query;

import nl.belastingdienst.iva.inzicht.domain.DataMap;

@FunctionalInterface
public interface ResultMapper {
	
	DataMap[] map(DataMap[] sourceData);
}
