package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.User;

public interface RestCallContext {

	RestServiceType getServiceType();
	String getServiceName();
	MultivaluedMap<String, String> getQueryValues();
	Configuration getConfiguration();
	User getUser();
	
	List<DomainRole> getAuthorizedRoles();
    String getUserName();

    long getBeginTime();
    long getElapsedTime();
    
    String getFirstQueryValue(String key);

    String getViewKey();
    String getTabKey();
    String getWidgetKey();
    String getSubjectNr();
    String getEntityNr();
    
    boolean hasDomainPathKeys();
    boolean hasMandatoryPathKeys();

    Domain findView();
    Page findTab();
    Widget findWidget();
}
