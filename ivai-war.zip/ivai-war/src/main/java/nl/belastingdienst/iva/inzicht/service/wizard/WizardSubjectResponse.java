package nl.belastingdienst.iva.inzicht.service.wizard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class WizardSubjectResponse {

    @XmlElement(name = ResponseKey.SUBJECTNR)
    private String subjectNr;

    @XmlElement(name = ResponseKey.NAME)
    private String name;

    @XmlElement(name = ResponseKey.VIEWS)
    private List<DataMap> views;

    @XmlElement(name = ResponseKey.TAXYEARS)
    private List<String> taxYears;

    @XmlElement(name = ResponseKey.RELATIONTYPE)
    private String relationType;

    @XmlElement(name = ResponseKey.MAIN)
    private boolean main;

    @XmlElement(name = ResponseKey.VIP)
    private boolean vip;

    @XmlElement(name = ResponseKey.IMPORTANTDOMAINS)
    private String importantDomains;

    @XmlElement(name = ResponseKey.UWBCODES)
    private String uwbCodes;

    public String getSubjectNr() {
        return subjectNr;
    }

    public void setSubjectNr(String subjectNr) {
        this.subjectNr = subjectNr;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getTaxYears() {
        return Collections.unmodifiableList(this.taxYears);
    }

    public void addTaxYear(String taxYear) {
        if (this.taxYears == null) {
            this.taxYears = new ArrayList<>();
        }
        
        this.taxYears.add(taxYear);
    }

    public void setTaxYears(List<String> taxYears) {
        this.taxYears = taxYears;
    }

    public List<DataMap> getViews() {
        return (this.views == null) ? Collections.<DataMap>emptyList() : Collections.unmodifiableList(this.views);
    }

    public void addView(DataMap view) {
        if (this.views == null) {
            this.views = new ArrayList<>();
        }
        
        this.views.add(view);
    }

    public void setViews(List<DataMap> views) {
        this.views = views;
    }
    
    public void clearViews() {
        this.views = null; 
    }

    public String getRelationType() {
        return relationType;
    }

    public void setRelationType(String relationType) {
        this.relationType = relationType;
    }

    public boolean isMain() {
        return main;
    }

    public void setMain(boolean main) {
        this.main = main;
    }

    public boolean isVip() {
        return vip;
    }

    public void setVip(boolean vip) {
        this.vip = vip;
    }

    public String getImportantDomains() {
        return importantDomains;
    }

    public void setImportantDomains(String importantDomains) {
        this.importantDomains = importantDomains;
    }

    public String getUwbCodes() {
        return uwbCodes;
    }

    public void setUwbCodes(String uwbCodes) {
        this.uwbCodes = uwbCodes;
    }
}
