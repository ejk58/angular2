package nl.belastingdienst.iva.inzicht.dataprovider.teradata;

import java.net.SocketTimeoutException;
import java.util.Map;

import javax.enterprise.inject.Typed;
import javax.inject.Inject;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.log4j.Logger;
import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientRuntimeException;
import org.apache.wink.client.ClientWebException;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.codehaus.jackson.JsonNode;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.configuration.ConfigurationFactory;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProviderClient;
import nl.belastingdienst.iva.inzicht.dataprovider.sql.SqlQuery;
import nl.belastingdienst.iva.inzicht.dataprovider.sql.SqlQueryFactory;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.JsonDataMapParser;
import nl.belastingdienst.iva.inzicht.domain.MessageType;
import nl.belastingdienst.iva.inzicht.domain.MessageUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.BadGatewayException;
import nl.belastingdienst.iva.inzicht.domain.exception.ExceptionUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.GatewayTimeoutException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@Typed(TeradataClient.class)
public class TeradataClient implements DataProviderClient {

	private static final String DATASOURCENAME = "Teradata";
	private static final String DATAPATH = "results/[0]/data";
	private static final String QUERYPREFIX = "{\"rowLimit\": \"0\", \"query\": \"";
	private static final String QUERYPOSTFIX = "\"}";
    
    private static final Logger logger = Logger.getLogger(TeradataClient.class);

    @Inject
    private SqlQueryFactory sqlQueryFactory;
    
    @Inject
    private JsonDataMapParser jsonDataMapParser;
    
    @Inject
    private ConfigurationFactory configurationFactory;

    @Override
    public DataMap[] retrieveDataAsMultiMap(QueryInterface query, RestCallContext restCallContext) {
        Configuration configuration = restCallContext.getConfiguration();
        MultivaluedMap<String, String> queryValues = restCallContext.getQueryValues();
        return retrieveDataAsMultiMap(configuration, query, queryValues);
    }

    public DataMap[] retrieveDataAsMultiMap(Configuration configuration, QueryInterface query, MultivaluedMap<String, String> queryValues) {
        SqlQuery sqlQuery = prepareQuery(configuration, query, queryValues);
        String resultSet = postQuery(sqlQuery);
        return processResultSet(resultSet);
    }

    public JsonNode retrieveData(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Configuration configuration = this.configurationFactory.getConfiguration();
        SqlQuery sqlQuery = prepareQuery(configuration, query, queryValues);
        String resultSet = postQuery(sqlQuery);
        return extractResultSet(resultSet);
    }

    private SqlQuery prepareQuery(Configuration configuration, QueryInterface query, MultivaluedMap<String, String> queryValues) {
        Datasource datasource = query.hasDatasource() ? query.getDatasource() : configuration.getTeradataDatasource(); 
        Map<String, String> configurationValues = this.sqlQueryFactory.buildConfigurationValues(datasource, configuration);
        return this.sqlQueryFactory.getSqlQuery(datasource, query, queryValues, configurationValues);
    }

    private String postQuery(SqlQuery sqlQuery) {
        String query = QUERYPREFIX + sqlQuery.getQuery() + QUERYPOSTFIX;
        Resource resource = getResource(sqlQuery.getDatasource());
        return callResource(resource, sqlQuery, query, true);
    }
    
    private DataMap[] processResultSet(String response) {
    	return this.jsonDataMapParser.parseJsonResult(DATASOURCENAME, DATAPATH, response);
    }

    private JsonNode extractResultSet(String response) {
    	return this.jsonDataMapParser.extractJsonResult(DATASOURCENAME, DATAPATH, response);
    }

    private Resource getResource(Datasource datasource) {
        ClientConfig clientConfig = new ClientConfig();
        clientConfig.connectTimeout(datasource.getNumber(DatasourceKey.CONNECTTIMEOUT));
        clientConfig.readTimeout(datasource.getNumber(DatasourceKey.READTIMEOUT));

        RestClient client = new RestClient(clientConfig);

        Resource resource = client.resource(datasource.getValue(DatasourceKey.RESTURL));
        resource.accept("application/vnd.com.teradata.rest-v1.0+json");
        resource.contentType(MediaType.APPLICATION_JSON);
        resource.header(HttpHeaders.AUTHORIZATION, datasource.getValue(DatasourceKey.CREDENTIALSVALUE));

        return resource;
    }

    private String callResource(Resource resource, SqlQuery sqlQuery, String query, boolean retryOnTimeout) {
        Datasource datasource = sqlQuery.getDatasource();
        long slowExecutionThreshold = datasource.getNumber(DatasourceKey.SLOWEXECUTIONTIME);
        String result = null;

        try {
            long before = System.currentTimeMillis();
            result = resource.post(String.class, query);
            long after = System.currentTimeMillis();
            long duration = after - before;

            if (duration > slowExecutionThreshold) {
                logger.warn(MessageUtils.createMessage(MessageType.WARNING, "Slow query (" + duration + "ms) on Teradata (query = '" + query + "')"));
            }
        } catch (ClientWebException exception) {
            String message = "Failed to run a query on Teradata with ClientWebException (" + getInformationFromClientWebException(exception) + ")";
            throw new BadGatewayException(message, exception);
        } catch (ClientRuntimeException exception) {
            if (retryOnTimeout && findSocketTimeoutInException(exception)) {
                logger.warn(MessageUtils.createMessage(MessageType.WARNING, "Retry for query on Teradata after time-out exception " + 
                        ExceptionUtils.getExceptionsForMessage(exception) + " (query = '" + query + "')"));
                result = callResource(resource, sqlQuery, query, false);
            } else if (findSocketTimeoutInException(exception)) {
                String message = "Failed to run a query on Teradata with time-out exception " + 
                        ExceptionUtils.getExceptionsForMessage(exception) + " (query = '" + query + "')";
                throw new GatewayTimeoutException(message, exception);
            } else {
                String message = "Failed to run a query on Teradata with exception " + 
                        ExceptionUtils.getExceptionsForMessage(exception) + " (query = '" + query + "')";
                throw new BadGatewayException(message, exception);
            }
        } catch (Exception exception) {
            String message = "Failed to run a query on Teradata with exception " + 
                    ExceptionUtils.getExceptionsForMessage(exception) + " (query = '" + query + "')";
            throw new InternalServerErrorException(message, exception);
        }

        return result;
    }

    private boolean findSocketTimeoutInException(Exception exception) {
        Throwable cause = exception;

        while (cause != null) {
            if (cause instanceof SocketTimeoutException) {
                return true;
            }
            cause = cause.getCause();
        }

        return false;
    }

    private String getInformationFromClientWebException(ClientWebException clientWebException) {
        String message = clientWebException.getResponse().getMessage();
        
        try {
            String error = clientWebException.getResponse().getEntity(String.class);
            JsonNode root = this.jsonDataMapParser.extractJsonResult(DATASOURCENAME + " (error)", null, error);
            message = root.path("message") == null ? null : root.path("message").toString();
        } catch (Exception exception) {
            logger.error("Parsing the Teradata response for the error handling throws an exception " + 
                    ExceptionUtils.getExceptionsForMessage(exception), exception);
        }
        
        return "entity = '" + clientWebException.getRequest().getEntity().toString() + 
                "', status code = " + clientWebException.getResponse().getStatusCode() +
                ", message = '" + message + "'";
    }
}
