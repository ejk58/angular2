package nl.belastingdienst.iva.inzicht.domain.rule;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RuleUtils {

    private RuleUtils() {
        throw new UnsupportedOperationException();
    }

	public static boolean findAtIndex(String description, String key, int index) {
		return description.regionMatches(index, key, 0, key.length());
	}
	
	public static boolean findGroupStartAtIndex(String description, List<GroupCharacter> groupCharacters, int index) {
		return getGroupCharacterAtIndex(description, groupCharacters, index) != null;
	}
	
	public static int getEndOfGroupIndex(String description, List<GroupCharacter> groupCharacters, int startIndex) {
		List<String> closingCharacterList = new ArrayList<>();
		
		for (int index = startIndex; index < description.length(); index++) {
			GroupCharacter groupCharacter = getGroupCharacterAtIndex(description, groupCharacters, index);
			if (groupCharacter != null) {
				closingCharacterList.add(groupCharacter.getEndCharacter());
			} 
			
			int lastClosingCharacterIndex = closingCharacterList.size() - 1;
			if (lastClosingCharacterIndex >= 0 && findAtIndex(description, closingCharacterList.get(lastClosingCharacterIndex), index)) {
				closingCharacterList.remove(lastClosingCharacterIndex);
			}
			
			if (closingCharacterList.isEmpty()) {
				return index == startIndex ? index : index + 1;
			}
		}

		throw new IllegalArgumentException("The group characters in the rule '" + description + 
				"' appear to be unbalanced when processing the rule starting from index " + startIndex + " (missing: '" + 
				closingCharacterList.stream().collect(Collectors.joining(", ")) + "').");
	}	
	
	private static GroupCharacter getGroupCharacterAtIndex(String description, List<GroupCharacter> groupCharacters, int index) {
		for (GroupCharacter groupCharacter : groupCharacters) {
			if (findAtIndex(description, groupCharacter.getStartCharacter(), index)) {
				return groupCharacter;
			}
		}
		
		return null;
	}
}
