package nl.belastingdienst.iva.inzicht.service.page;

import java.util.Collections;
import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/page")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class PageService extends AbstractRestService {

    @Inject
    private PageMapper pageMapper;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{viewKey}")
    public Response getAllPages(@PathParam("viewKey") String viewKey, @Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        queryValues.add(QueryValueKey.VIEWKEY, viewKey);
        
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.PAGESERVICE, queryValues);
        
        try {
            validateSubjectKey(restCallContext);
            checkRequiredRoles(restCallContext);

            Domain view = restCallContext.findView();
            List<Page> tabs = restCallContext.getConfiguration().findPagesByDomain(viewKey);
            
            if (tabs == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            
            List<String> importantDomains = Collections.<String>emptyList();
            DataMap pageResponse = this.pageMapper.map(view, tabs, importantDomains);
            return buildResponse(pageResponse, restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
}
