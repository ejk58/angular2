package nl.belastingdienst.iva.inzicht.service.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import nl.belastingdienst.iva.inzicht.user.RoleUtils;

public class SSOServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final Logger logger = Logger.getLogger(SSOServlet.class);

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        StringBuilder jsonReturn = new StringBuilder();

        jsonReturn.append("{\"role\":[");
        if (request.isUserInRole(RoleUtils.INZICHT_USER_ROLE)) {
            jsonReturn.append("\"");
            jsonReturn.append(RoleUtils.INZICHT_USER_ROLE);
            jsonReturn.append("\"");
        }
        jsonReturn.append("]");

        if (request.getUserPrincipal() != null) {
            jsonReturn.append(",\"username\":\"");
            jsonReturn.append(request.getUserPrincipal().getName());
            jsonReturn.append("\"");
        }

        jsonReturn.append("}");

        try {
            PrintWriter writer = response.getWriter();
            writer.write(jsonReturn.toString());
        } catch (IOException e) {
            logger.error("Error occured while getting writer to the response", e);
        }
    }
}
