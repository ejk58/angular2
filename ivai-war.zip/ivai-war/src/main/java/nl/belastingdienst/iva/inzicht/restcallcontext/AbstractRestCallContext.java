package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainPathKey;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.NotFoundException;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;

public abstract class AbstractRestCallContext implements RestCallContext{

	private RestServiceType serviceType;
    private MultivaluedMap<String, String> queryValues;
    private Configuration configuration;
    
    private long beginTime;

    public AbstractRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration, long beginTime) {
        this.serviceType = serviceType;
        this.queryValues = queryValues;
        this.configuration = configuration;
        this.beginTime = beginTime;

        this.queryValues.remove(QueryValueKey.USERNAME);
        this.queryValues.remove(QueryValueKey.NOCACHE);
    }

    @Override
    public RestServiceType getServiceType() {
        return this.serviceType;
    }

    @Override
    public String getServiceName() {
        return this.serviceType.getName();
    }

    @Override
    public MultivaluedMap<String, String> getQueryValues() {
        return this.queryValues;
    }
    
    @Override
    public Configuration getConfiguration() {
        return this.configuration;
    }
    
    @Override
    public String getViewKey() {
        return DomainUtils.getFirst(this.queryValues, QueryValueKey.DOMAINKEY, QueryValueKey.VIEWKEY);
    }

    @Override
    public String getTabKey() {
        return DomainUtils.getFirst(this.queryValues, QueryValueKey.PAGEKEY, QueryValueKey.TABKEY);
    }
    
    @Override
    public String getWidgetKey() {
        return this.queryValues.getFirst(QueryValueKey.WIDGETKEY);
    }

    @Override
    public String getSubjectNr() {
        return this.queryValues.getFirst(QueryValueKey.SUBJECTNR);
    }
    
    @Override
    public String getEntityNr() {
        return this.queryValues.getFirst(QueryValueKey.ENTITYNR);
    }
    
    @Override
    public String getUserName() {
    	return this.queryValues.getFirst(QueryValueKey.USERNAME);
    }
    
    @Override
    public long getBeginTime() {
        return this.beginTime;
    }
    
    @Override
    public long getElapsedTime() {
        return System.currentTimeMillis() - this.beginTime;
    }
    
    @Override
    public String getFirstQueryValue(String key) {
        return this.queryValues.getFirst(key);
    }
    
    @Override
    public boolean hasDomainPathKeys() {
        Set<String> keys = this.queryValues.keySet();

        for (String key : keys) {
            if (!QueryValueKey.SYSTEMKEYS.contains(key)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean hasMandatoryPathKeys() {
        String viewKey = getViewKey();
        Domain view = this.configuration.findDomain(viewKey);
        return view != null && checkMandatoryPathKeys(view); 
    }

    @Override
    public Domain findView() {
        String viewKey = getViewKey();
        Domain view = this.configuration.findDomain(viewKey);
        return checkUnfoundItem("view", viewKey, view);
    }
    
    @Override
    public Page findTab() {
        String tabKey = getTabKey();
        Page tab = this.configuration.findPage(tabKey);
        return checkUnfoundItem("tab", tabKey, tab);
    }

    @Override
    public Widget findWidget() {
        String widgetKey = getWidgetKey();
        Widget widget = this.configuration.findWidget(widgetKey);
        return checkUnfoundItem("widget", widgetKey, widget);
    }

    private boolean checkMandatoryPathKeys(Domain view) {
        List<DomainPathKey> pathKeys = view.getPathKeys();
        for (DomainPathKey pathKey : pathKeys) {
            if (pathKey.getMandatory() && !this.queryValues.containsKey(pathKey.getName())) {
                return false;
            }
        }
        
        return true;
    }
    
    private <T> T checkUnfoundItem(String item, String key, T definition) {
        if (definition == null) {
            throw (key == null || DomainUtils.isUndefined(key)) ?
                new BadRequestException("The " + item + " " + key + " is not defined.") :
                new NotFoundException("The " + item + " " + key + " is not found.");
        }
        
        return definition;
    }
    
    @Override
    public String toString() {
        StringBuilder queryValuesBuilder = new StringBuilder();
        
        for (Entry<String, List<String>> queryValue : this.queryValues.entrySet()) {
            if (queryValuesBuilder.length() > 0) {
                queryValuesBuilder.append(", ");
            }
            
            queryValuesBuilder.append(queryValue.getKey());
            queryValuesBuilder.append("=");
            queryValuesBuilder.append(convertQueryValueListToString(queryValue.getValue()));
        }
        
        return queryValuesBuilder.toString();
    }
    
    protected void setUserName(String userName) {
    	this.queryValues.putSingle(QueryValueKey.USERNAME, userName);
    }

    private String convertQueryValueListToString(List<String> queryValueList) {
        StringBuilder queryValuesBuilder = new StringBuilder();
        
        if (queryValueList != null) {
            queryValuesBuilder.append("[");
            for (int index = 0; index < queryValueList.size(); index++) {
                String value = queryValueList.get(index);
                
                if (index > 0) {
                    queryValuesBuilder.append(", ");
                }
                
                if (value != null) {
                    queryValuesBuilder.append("'");
                    queryValuesBuilder.append(value);
                    queryValuesBuilder.append("'");
                } else {
                    queryValuesBuilder.append("null");
                }
            }
            queryValuesBuilder.append("]");
        } else {
            queryValuesBuilder.append("null");
        }
        
        return queryValuesBuilder.toString();
    }
}
