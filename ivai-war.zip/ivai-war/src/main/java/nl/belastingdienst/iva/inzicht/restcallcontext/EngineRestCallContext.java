package nl.belastingdienst.iva.inzicht.restcallcontext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.domain.DomainRole;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.User;

public class EngineRestCallContext extends DefaultRestCallContext {

    private DataProvider dataProvider;
	private List<DataMap> result;
	
    public EngineRestCallContext(RestServiceType serviceType, MultivaluedMap<String, String> queryValues, Configuration configuration, User user, 
            List<DomainRole> authorizedRoles, long beginTime) {
    	super(serviceType, queryValues, configuration, user, authorizedRoles, beginTime);

        this.result = new ArrayList<>();
    }

    public DataProvider getDataProvider() {
		return this.dataProvider;
	}

	public void setDataProvider(DataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}

	public DataMap[] getResult() {
		return DomainUtils.inArray(this.result);
	}

	public void setResult(DataMap[] result) {
        this.result = new ArrayList<>();
    	this.result.addAll(Arrays.asList(result));
    }
	
	public void setResult(List<DataMap> result) {
        this.result = new ArrayList<>();
    	this.result.addAll(result);
    }
	
	public void addRowsToResult(DataMap[] resultRows) {
		for (DataMap resultRow : resultRows) {
			this.result.add(resultRow);
		}
	}
}
