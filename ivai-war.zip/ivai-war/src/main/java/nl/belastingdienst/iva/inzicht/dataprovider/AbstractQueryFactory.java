package nl.belastingdienst.iva.inzicht.dataprovider;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryColumn;
import nl.belastingdienst.iva.inzicht.domain.exception.BadRequestException;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.query.QueryParameterType;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;

public class AbstractQueryFactory {

    private Map<QueryParameterType, Function<String, String>> parameterBuilderMap;
    
    public AbstractQueryFactory() {
        this.parameterBuilderMap = makeDefaultParameterBuilderMap();
    }
    
    public void registerParameterBuilder(QueryParameterType type, Function<String, String> parameterBuilder) {
        this.parameterBuilderMap.put(type, parameterBuilder);
    }

    public List<QueryResultColumn> mapColumns(List<QueryColumn> queryColumns) {
        List<QueryResultColumn> columnList = new ArrayList<>();

        for (QueryColumn queryColumn : queryColumns) {
            if (queryColumn.isComposite()) {
                columnList.addAll(mapColumns(queryColumn.getColumns()));
            } else if (!queryColumn.isValue()) {
                columnList.add(new QueryResultColumn(queryColumn.getName(), queryColumn.getAlias(), queryColumn.isMaskable()));
            }
        }
        
        return columnList;
    }
    
    public String replaceParameters(String queryTemplate, MultivaluedMap<String, String> queryParameters, Map<String, String> configurationParameters) {
        String query = queryTemplate;
        Matcher matcher = QueryUtils.PATTERN_ANYPARAMETER.matcher(query);

        while (matcher.find()) {
            String parameter = matcher.group();
            String value = prepareParameters(queryTemplate, parameter, queryParameters, configurationParameters);
            query = matcher.replaceFirst(value);
            matcher = QueryUtils.PATTERN_ANYPARAMETER.matcher(query);
        }

        return query;
    }

    public String replaceParameters(String queryTemplate, MultivaluedMap<String, String> queryParameters) {
        return replaceParameters(queryTemplate, queryParameters, Collections.<String, String>emptyMap());
    }
    
    public Map<String, String> buildConfigurationValues(Datasource datasource, Configuration configuration) {
        Map<String, String> datasourceMap = datasource == null ? Collections.<String, String>emptyMap() : datasource.getParameterMap();
        Map<String, Object> configurationMap = configuration == null ? Collections.<String, Object>emptyMap() : configuration.getKeyValueMap();
        
        return Stream.of(configurationMap, datasourceMap)
                .flatMap(map -> map.entrySet().stream())
                .filter(entry -> entry.getValue() != null)
                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue().toString()));
    }

    private String prepareParameters(String inputQueryTemplate, String parameter, 
            MultivaluedMap<String, String> queryParameters, Map<String, String> configurationParameters) {

        String parameterName = QueryUtils.extractParameterName(parameter);
        QueryParameterType parameterType = QueryUtils.extractParameterType(parameter);
        String parameters;

        if (parameterType == null) {
            throw new InternalServerErrorException("The parameter " + parameter + " is missing a known type in query " + inputQueryTemplate);
        } else if (parameterType.isConfigurationValue()) {
            parameters = prepareConfigurationValue(inputQueryTemplate, parameterName, parameterType, configurationParameters);
        } else if (parameterType.isSingleValue()) {
            parameters = prepareSingleValue(inputQueryTemplate, parameterName, parameterType, queryParameters);
        } else {
            parameters = prepareMultipleValues(inputQueryTemplate, parameterName, parameterType, queryParameters);
        }

        return parameters;
    }

    private String prepareConfigurationValue(String queryTemplate, String name, QueryParameterType type, Map<String, String> configurationParameters) {
        String value = configurationParameters.get(name);

        if (value == null) {
            String message = "The configuration value " + name + " (" + type + ") does not exist for query " + queryTemplate;
            throw new InternalServerErrorException(message);
        }

        return value;
    }

    private String prepareSingleValue(String queryTemplate, String name, QueryParameterType type, MultivaluedMap<String, String> queryParameters) {
        String value = queryParameters.getFirst(name);

        if (!type.validate(value)) {
            String message = "The query parameter " + name + " (" + type + ") is invalid with value '" + value + "' for query " + queryTemplate;
            throw new BadRequestException(message);
        }

        Function<String, String> parameterBuilder = this.parameterBuilderMap.get(type);
        return parameterBuilder.apply(value);
    }

    private String prepareMultipleValues(String queryTemplate, String name, QueryParameterType type, MultivaluedMap<String, String> queryParameters) {
        List<String> values = queryParameters.get(name);

        if (!type.validateAll(values)) {
            String message = "The query parameter " + name + " (" + type + ") is invalid with values '"
                    + (values == null ? null : String.join(", ", values)) + "' for query " + queryTemplate;
            throw new BadRequestException(message);
        }

        Function<String, String> parameterBuilder = this.parameterBuilderMap.get(type);
        return values.stream().map(parameterBuilder).collect(Collectors.joining(", "));
    }

    private Map<QueryParameterType, Function<String, String>> makeDefaultParameterBuilderMap() {
        Map<QueryParameterType, Function<String, String>> resultMap = new EnumMap<>(QueryParameterType.class);

        for (QueryParameterType type : QueryParameterType.values()) {
            Function<String, String> parameterBuilder;

            if (type == QueryParameterType.STRING || type == QueryParameterType.DATE || type == QueryParameterType.LISTOFSTRINGS) {
                parameterBuilder = new DefaultValueQueryParameterBuilder("'", "'");
            } else if (type == QueryParameterType.FILTER) {
                parameterBuilder = new DefaultValueQueryParameterBuilder(" ", "");
            } else {
                parameterBuilder = new DefaultValueQueryParameterBuilder();
            }
            
            resultMap.put(type, parameterBuilder);
        }
        
        return resultMap;
    }
}
