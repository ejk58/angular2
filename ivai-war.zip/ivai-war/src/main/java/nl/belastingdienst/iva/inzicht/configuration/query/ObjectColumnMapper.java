package nl.belastingdienst.iva.inzicht.configuration.query;

import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;

public class ObjectColumnMapper implements ColumnMapper {

    private List<ColumnMapper> partialColumnMappers;
    private String destinationKey;
	
	public ObjectColumnMapper(List<ColumnMapper> partialColumnMappers, String destinationKey) {
		this.partialColumnMappers = partialColumnMappers;
		this.destinationKey = destinationKey;
	}

	@Override
	public String getKey() {
		return this.destinationKey;
	}

	@Override
	public DataMap getValue(DataMap sourceDataMap) {
        DataMap destinationDataMap = new DataHashMap();
        
        for (ColumnMapper columnMapper : this.partialColumnMappers) {
        	destinationDataMap.put(columnMapper.getKey(), columnMapper.getValue(sourceDataMap));
        }
        
		return destinationDataMap;
	}
}
