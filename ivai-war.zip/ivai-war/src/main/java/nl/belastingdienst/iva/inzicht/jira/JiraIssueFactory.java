package nl.belastingdienst.iva.inzicht.jira;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.attribute.AttributeGroup;
import nl.belastingdienst.iva.inzicht.database.feedback.Feedback;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.jira.domain.FixVersion;
import nl.belastingdienst.iva.inzicht.jira.domain.IssueType;
import nl.belastingdienst.iva.inzicht.jira.domain.JiraIssue;
import nl.belastingdienst.iva.inzicht.jira.domain.JiraIssueFields;
import nl.belastingdienst.iva.inzicht.jira.domain.Project;

public class JiraIssueFactory {
	
	private static final String BOLD_KEY_NORMAL_VALUE_FORMAT = "*%s*: %s%n";
	
	public JiraIssue createIssue(Feedback feedback, Configuration configuration) {
		Project project = new Project(configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKPROJECT));
		IssueType issueType = IssueType.STORY;
		String summary = feedback.getSummary();
		String description = makeDescription(feedback);
		FixVersion[] fixVersions = deduceFixVersions(configuration, feedback.getTopic());
		String[] labels = {configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKENVIRONMENT)};
		
		JiraIssueFields fields = new JiraIssueFields(project, summary, issueType, description, fixVersions, labels);
		
		if (issueType.isEpicLinkSupported()) {
			AttributeGroup jiraFeedbackEpicLinksGroup = configuration.getAttributeGroup(ConfigurationKey.JIRAFEEDBACKEPICLINKSGROUP);
			String epicLink = jiraFeedbackEpicLinksGroup.getAttributeMap().get(feedback.getDomain());
			fields.setEpicLink(epicLink);
		}
		
		return new JiraIssue(fields);
	}
	
	private FixVersion[] deduceFixVersions(Configuration configuration, String topic) {
		AttributeGroup fixVersionAttributeGroup = configuration.getAttributeGroup(ConfigurationKey.JIRAFEEDBACKTOPICFIXVERSIONSGROUP);
		String fixVersionIdForTopic = fixVersionAttributeGroup.getAttributeMap().get(topic);
		if (fixVersionIdForTopic != null) {
			FixVersion fixVersion = new FixVersion(fixVersionIdForTopic);
			return new FixVersion[] {fixVersion};
		}
		return new FixVersion[] {};
	}

	private String makeDescription(Feedback feedback) {
		StringBuilder description = new StringBuilder();
		
		if (feedback.getScope() != null) {
			description.append(String.format(BOLD_KEY_NORMAL_VALUE_FORMAT, "Scope", feedback.getScope()));
		}
		
		if (feedback.getTopic() != null) {
			description.append(String.format(BOLD_KEY_NORMAL_VALUE_FORMAT, "Topic", feedback.getTopic()));
		}
		
		if (feedback.getRemark() != null) {
			if (description.length() > 0) {
				description.append(String.format("%n"));
			}
			description.append(String.format("%s%n%n", feedback.getRemark()));
		}
		
		if (feedback.getWidget() != null) {
			description.append(String.format(BOLD_KEY_NORMAL_VALUE_FORMAT, "Widget", feedback.getWidget()));
		}
		
		description.append(String.format(BOLD_KEY_NORMAL_VALUE_FORMAT, "Url", feedback.getUrl()));
		description.append(String.format(BOLD_KEY_NORMAL_VALUE_FORMAT, "Verstuurd door", feedback.getUsername()));
		
		return description.toString();
	}

}
