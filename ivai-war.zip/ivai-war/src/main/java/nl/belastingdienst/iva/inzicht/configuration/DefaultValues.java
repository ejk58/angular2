package nl.belastingdienst.iva.inzicht.configuration;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;

public class DefaultValues {

    public static final Map<String, String> VALUES;

    private static final String[][] DEFAULTVALUES = {
            {ConfigurationKey.CONFIGURATIONSTATUS, "ERROR"},
            {ConfigurationKey.JIRAISSUECREATIONFROMFEEDBACKENABLED, "false"},
            {ConfigurationKey.MIHSUBJECTVIPRESTQUERY, "/mihproxy/v1/authorizedForBsn/{subjectNr:subjectnumber}"},
            {ConfigurationKey.MIHENTITYVIPRESTQUERY, "/mihproxy/v1/authorizedForEntity/{entityNr:number}"},
            {ConfigurationKey.TERADATAVIPSQLQUERY, "SELECT IS_VIP as vip FROM {teradataSchema:config}.{viewName} WHERE finr = {subjectNr:subjectnumber}"},
            {ConfigurationKey.TERADATAVIPVIEWNAME, "INZICHT_FINRS"},
            {ConfigurationKey.PERMISSIONCACHEACCESSIBLE, "false"},
            {ConfigurationKey.ACCESSPERMISSIONPROVIDER, "Teradata"},
            {ConfigurationKey.RESULTPERMISSIONPROVIDER, "Teradata"},
            {ConfigurationKey.PERMISSIONCACHEEXPIRATIONAGE, "3600000"}
            };

    static {
        Map<String, String> values = new HashMap<>();
        
        for (String[] defaultValue : DEFAULTVALUES) {
            values.put(defaultValue[0], defaultValue[1]);
        }
        
        VALUES = Collections.unmodifiableMap(values);
    }
    
    private DefaultValues() {
        throw new UnsupportedOperationException();
    }
}
