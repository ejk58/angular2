package nl.belastingdienst.iva.inzicht.engine.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public class ReverseResultAction implements Action {

	public static final String NAME = "ReverseResult";

	@Override
	public Flow execute(EngineRestCallContext restCallContext) {
		List<DataMap> result = new ArrayList<>();
		result.addAll(Arrays.asList(restCallContext.getResult()));
		Collections.reverse(result);
		restCallContext.setResult(DomainUtils.inArray(result));
		
		return Flow.CONTINUE;
	}
	
	@Override
	public String getAction() {
		return NAME + RulesEngineKey.PARAMETERSTART + RulesEngineKey.PARAMETEREND;
	}
}
