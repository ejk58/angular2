package nl.belastingdienst.iva.inzicht.service.wizard;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.database.configuration.domain.Domain;
import nl.belastingdienst.iva.inzicht.database.configuration.query.Query;
import nl.belastingdienst.iva.inzicht.dataprovider.DataProvider;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.MultiValuedHashMap;
import nl.belastingdienst.iva.inzicht.domain.key.QueryValueKey;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.domain.vip.VipUtils;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/wizard")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class WizardService extends AbstractRestService {

    private static final Integer MAIN_FLAG = 1;

    @Inject
    private DataProvider dataprovider;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getWizardSubjects(@Context UriInfo uriInfo) {
    	MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.WIZARDSERVICE, queryValues);
        return retrieveWizardResponse(restCallContext);
    }

    @Deprecated
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{viewKey}")
    public Response getWizardSubjects(@PathParam("viewKey") String viewKey, @Context UriInfo uriInfo) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>(uriInfo.getQueryParameters());
        queryValues.add(QueryValueKey.VIEWKEY, viewKey);
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.WIZARDSERVICE, queryValues);
        
        return retrieveWizardResponse(restCallContext);
    }
    
    @Deprecated
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{viewKey}/{subjectNumber}")
    public Response getWizardSubjects(@PathParam("viewKey") String viewKey, @PathParam("subjectNumber") String subjectNr) {
        MultivaluedMap<String, String> queryValues = new MultiValuedHashMap<>();
        queryValues.add(QueryValueKey.VIEWKEY, viewKey);
        queryValues.add(QueryValueKey.SUBJECTNR, subjectNr);
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.WIZARDSERVICE, queryValues);
        
        return retrieveWizardResponse(restCallContext);
    }

    private Response retrieveWizardResponse(RestCallContext restCallContext) {
        try {
            checkRequiredRoles(restCallContext);
            Domain view = restCallContext.findView();
            DataMap wizardResponse = new DataHashMap();
            
            wizardResponse.put(ResponseKey.OPTIONS, retrieveWizardOptions());
            wizardResponse.put(ResponseKey.DATA, retrieveWizardSubjects(view, restCallContext));

            return buildResponse(wizardResponse, restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
    
    private DataMap retrieveWizardOptions() {
        return DomainUtils.emptyDataMap();
    }
    
    private List<WizardSubjectResponse> retrieveWizardSubjects(Domain view, RestCallContext restCallContext) {
        boolean vip = RoleUtils.isVipUser(restCallContext);
        Query query = vip ? view.getWizardVipQuery() : view.getWizardNoVipQuery();
        DataMap[] dataMap = this.dataprovider.retrieveDataAsMultiMap(query, restCallContext);
        Map<String, WizardSubjectResponse> subjectResponsesMap = new LinkedHashMap<>();
        
        for (DataMap subjectDataMap : dataMap) {
            String subjectNrKey = subjectDataMap.getAsString("SUBJECTNR");
            if (!subjectResponsesMap.containsKey(subjectNrKey)) {
                WizardSubjectResponse subjectResponse = new WizardSubjectResponse();
                subjectResponse.setSubjectNr(subjectNrKey);
                subjectResponse.setName(subjectDataMap.getAsString("NAME"));
                subjectResponse.setMain(MAIN_FLAG.equals(subjectDataMap.get("IS_MAIN")));
                subjectResponse.setVip(VipUtils.detectVipMaskRow(subjectDataMap));
                subjectResponse.setRelationType(subjectDataMap.getAsString("RELATIONTYPE"));
                subjectResponse.setImportantDomains(subjectDataMap.getAsString("importantDomains"));
                subjectResponse.setUwbCodes(subjectDataMap.getAsString("uwbCodes"));
                subjectResponsesMap.put(subjectNrKey, subjectResponse);
            }

            String taxYear = subjectDataMap.getAsString("TAXYEAR");
            if (taxYear != null) {
                WizardSubjectResponse subjectResponse = subjectResponsesMap.get(subjectNrKey);
                subjectResponse.addTaxYear(taxYear);
            }
        }

        return new ArrayList<>(subjectResponsesMap.values());
    }
}
