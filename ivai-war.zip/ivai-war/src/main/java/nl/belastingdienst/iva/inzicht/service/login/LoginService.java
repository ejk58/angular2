package nl.belastingdienst.iva.inzicht.service.login;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Path("/security")
public class LoginService {

    @Context
    private HttpServletRequest httpServletRequest;

    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(LoginRequest loginRequest) {
        try {
            if (httpServletRequest.getUserPrincipal() != null) {
                httpServletRequest.logout();
            }
            httpServletRequest.login(loginRequest.getUsername(), loginRequest.getPassword());
        } catch (Exception exception) {
            return Response.status(Response.Status.FORBIDDEN).build();
        }
        
        if (!this.httpServletRequest.isUserInRole(RoleUtils.INZICHT_USER_ROLE)) {
            return Response.status(Response.Status.FORBIDDEN).build();
        }
        
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setUsername(loginRequest.getUsername());
        loginResponse.addRole(RoleUtils.INZICHT_USER_ROLE);

        return Response.ok(loginResponse).build();
    }

    @POST
    @Path("/logout")
    @Produces({MediaType.TEXT_PLAIN})
    public Response logout() throws ServletException {
        httpServletRequest.logout();
        return Response.ok("U bent uitgelogd").build();
    }
}
