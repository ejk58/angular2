package nl.belastingdienst.iva.inzicht.engine.condition;

import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public interface Condition {

	boolean test(EngineRestCallContext restCallContext);
	String getCondition();
}
