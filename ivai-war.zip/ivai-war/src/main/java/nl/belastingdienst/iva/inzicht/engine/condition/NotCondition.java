package nl.belastingdienst.iva.inzicht.engine.condition;

import nl.belastingdienst.iva.inzicht.domain.key.RulesEngineKey;
import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public class NotCondition implements Condition {

	private Condition condition;

	public NotCondition(Condition condition) {
		this.condition = condition;
	}
	
	@Override
	public boolean test(EngineRestCallContext restCallContext) {
		return !this.condition.test(restCallContext);
	}
	
	@Override
	public String getCondition() {
		return RulesEngineKey.NOTCONDITIONOPERATOR + this.condition.getCondition();
	}
}
