package nl.belastingdienst.iva.inzicht.dataprovider;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import nl.belastingdienst.iva.inzicht.database.configuration.query.ResultMapper;
import nl.belastingdienst.iva.inzicht.dataprovider.db2.Db2Client;
import nl.belastingdienst.iva.inzicht.dataprovider.internal.InternalClient;
import nl.belastingdienst.iva.inzicht.dataprovider.rest.RestServiceClient;
import nl.belastingdienst.iva.inzicht.dataprovider.teradata.TeradataClient;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.DomainUtils;
import nl.belastingdienst.iva.inzicht.domain.exception.NotAuthorizedException;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryType;
import nl.belastingdienst.iva.inzicht.domain.vip.Permission;
import nl.belastingdienst.iva.inzicht.domain.vip.VipUtils;
import nl.belastingdienst.iva.inzicht.permission.PermissionFactory;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

public class DataProvider {

    @Inject
    private InternalClient internalClient;

    @Inject
    private TeradataClient teradataClient;

    @Inject
    private Db2Client db2Client;

    @Inject
    private RestServiceClient restServiceClient;
    
    @Inject
    private PermissionFactory permissionFactory;
    
    private Map<QueryType, DataProviderClient> clientMap;
    
    @PostConstruct
    private void initializeClientMap() {
        this.clientMap = new EnumMap<>(QueryType.class);

        this.clientMap.put(QueryType.INTERNAL, this.internalClient);
        this.clientMap.put(QueryType.TERADATA, this.teradataClient);
        this.clientMap.put(QueryType.DB2, this.db2Client);
        this.clientMap.put(QueryType.REST, this.restServiceClient);
    }

    public DataMap[] retrieveDataAsMultiMap(QueryInterface query, RestCallContext restCallContext) {
        DataMap[] result = DomainUtils.emptyDataMapArray();
        
        if (query != null) {
            checkRequiredRoles(query, restCallContext);
            checkRequiredPermission(query, restCallContext);
        	
            DataProviderClient client = this.clientMap.get(query.getType());
            ResultMapper resultMapper = query.getResultMapper();
            
            result = client.retrieveDataAsMultiMap(query, restCallContext);
            result = resultMapper.map(result);
            result = processVipInformation(query, result, restCallContext);
        }

        return result;
    }

    private void checkRequiredRoles(QueryInterface query, RestCallContext restCallContext) {
        if (!RoleUtils.isAuthorizedUser(restCallContext)) {
            throw new NotAuthorizedException("The user lacks a role (" + restCallContext.getAuthorizedRoles() + 
                    ") for a view that is linked to the query " + query.getKey());
        }
    }

    private void checkRequiredPermission(QueryInterface query, RestCallContext restCallContext) {
        if (!this.permissionFactory.getAccess(restCallContext)) {
            throw new NotAuthorizedException("The user has no permission to access the data with the query " + query.getKey());
        }
    }

    private DataMap[] processVipInformation(QueryInterface query, DataMap[] data, RestCallContext restCallContext) {
        DataMap[] result = data;
        
        if (query.getVipFilterColumnKey() != null) {
            result = filterVipInformation(query, result, restCallContext);
        }
        
        if (query.getVipMaskColumnKey() != null) {
            result = maskVipInformation(query, result, restCallContext);
        } else if (!query.getMaskableColumnKeys().isEmpty()) {
            result = maskVipInformationFromData(query, result, restCallContext);
        } 
        
        if (query.getVipTagColumnKey() != null) {
            result = tagVipInformation(query, data, restCallContext);
        }
        
        return result;
    }
    
    private DataMap[] filterVipInformation(QueryInterface query, DataMap[] data, RestCallContext restCallContext) {
        String vipFilterColumnKey = query.getVipFilterColumnKey();
        List<DataMap> result = new ArrayList<>();
        
        for (DataMap dataMap : data) {
            String subjectNr = dataMap.getAsString(vipFilterColumnKey);
            boolean access = this.permissionFactory.getAccess(restCallContext, subjectNr);
            if (access) {
                result.add(dataMap);
            }
        }
        
        return DomainUtils.inArray(result);
    }
    
    private DataMap[] maskVipInformation(QueryInterface query, DataMap[] data, RestCallContext restCallContext) {
        String vipMaskColumnKey = query.getVipMaskColumnKey();
        List<String> maskableColumnKeys = query.getMaskableColumnKeys();
        List<DataMap> result = new ArrayList<>();
        
        for (DataMap dataMap : data) {
            String subjectNr = dataMap.getAsString(vipMaskColumnKey);
            boolean access = this.permissionFactory.getAccess(restCallContext, subjectNr);
            if (!access) {
                for (String columnKey : maskableColumnKeys) {
                    dataMap.put(columnKey, VipUtils.VIP_MASK);
                }
            }
            result.add(dataMap);
        }
        
        return DomainUtils.inArray(result);
    }
    
    private DataMap[] tagVipInformation(QueryInterface query, DataMap[] data, RestCallContext restCallContext) {
        String vipTagColumnKey = query.getVipTagColumnKey();
        List<DataMap> result = new ArrayList<>();
        
        for (DataMap dataMap : data) {
            String subjectNr = dataMap.getAsString(vipTagColumnKey);
            Permission permission = this.permissionFactory.getPermission(restCallContext, subjectNr);
            dataMap.put(vipTagColumnKey, permission);

            result.add(dataMap);
        }
        
        return DomainUtils.inArray(result);
    }
    
    private DataMap[] maskVipInformationFromData(QueryInterface query, DataMap[] data, RestCallContext restCallContext) {
        boolean vipUser = RoleUtils.isVipUser(restCallContext);
        DataMap[] result = data;

        if (!vipUser) {
            List<String> columnKeys = query.getMaskableColumnKeys();
            
            for (DataMap dataMap : result) {
                if (VipUtils.detectVipMaskRow(dataMap)) {
                    for (String columnKey : columnKeys) {
                        dataMap.put(columnKey, VipUtils.VIP_MASK);
                    }
                }
            }
        }
    	
        return result;
    }
}
