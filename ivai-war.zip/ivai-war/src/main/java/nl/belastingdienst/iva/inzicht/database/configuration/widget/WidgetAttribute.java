package nl.belastingdienst.iva.inzicht.database.configuration.widget;

import org.codehaus.jackson.annotate.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "CONF_WIDGET_ATTRIBUTE")
public class WidgetAttribute {

    @Id
    private int id;

    private String key;
    private String value;

    @JsonIgnore
    public int getId() {
        return id;
    }

    public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}
}
