package nl.belastingdienst.iva.inzicht.jira;

import javax.ws.rs.core.Response.StatusType;

public class JiraException extends Exception {

	private static final long serialVersionUID = 1L;

	public JiraException(String message, StatusType statusType) {
		super("Error " + statusType.toString() + ": " + message);
	}

}
