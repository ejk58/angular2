package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.ws.rs.core.HttpHeaders;

import com.ibm.websphere.security.NotImplementedException;
import com.ibm.wsspi.security.auth.callback.Constants;
import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandlerFactory;

public enum CredentialsType {

    LOGINPASSWORD("LOGINPASSWORD", HttpHeaders.AUTHORIZATION, null) {
        @Override
        public String getCredentialsAsString(String credentialsAlias) throws LoginException {
            PasswordCredential passwordCredential = getCredentials(credentialsAlias);
            return passwordCredential.getUserName() + ":" + new String(passwordCredential.getPassword());
        }
    },
    APIKEY("APIKEY", "x-api-key", null) {
        @Override
        public String getCredentialsAsString(String credentialsAlias) throws LoginException {
            PasswordCredential passwordCredential = getCredentials(credentialsAlias);
            return new String(passwordCredential.getPassword());
        }
    },
    URLPARAMETER("URLPARAMETER", null, null) {
        @Override
        public String getCredentialsAsString(String credentialsAlias) throws LoginException {
            PasswordCredential passwordCredential = getCredentials(credentialsAlias);
            return new String(passwordCredential.getPassword());
        }
    },
    LTPATOKEN("LTPATOKEN", null, "LtpaToken") {
        @Override
        public String getCredentialsAsString(String credentialsAlias) {
            return null;
        }
    },
    LTPA2TOKEN("LTPA2TOKEN", null, "LtpaToken2") {
        @Override
        public String getCredentialsAsString(String credentialsAlias) {
            return null;
        }
    },
    SSOCOOKIE("SSOCOOKIE", null, null) {
        @Override
        public String getCredentialsAsString(String credentialsAlias) {
            return null;
        }
    };
    
    private String name;
    private String httpHeader;
    private String cookieName;
    
    private CredentialsType(String name, String httpHeader, String cookieName) {
        this.name = name;
        this.httpHeader = httpHeader;
        this.cookieName = cookieName;
    }

    public PasswordCredential getCredentials(String credentialsAlias) throws LoginException {
        Map<String, String> map = new HashMap<>();
        map.put(Constants.MAPPING_ALIAS, credentialsAlias);
        
        CallbackHandler callbackHandler = getCallbackHandler(map);
        LoginContext loginContext = new LoginContext("DefaultPrincipalMapping", callbackHandler);
        loginContext.login();
        Subject subject = loginContext.getSubject();
        Set<?> credentials = subject.getPrivateCredentials();
        PasswordCredential passwordCredential = (PasswordCredential) credentials.iterator().next();
        return passwordCredential;
    }
    
    public String getHttpHeader() {
        return this.httpHeader;
    }
    
    public String getCookieName() {
        return this.cookieName;
    }
    
    public abstract String getCredentialsAsString(String credentialsAlias) throws LoginException;
    
    public boolean isHttpHeader() {
        return this.httpHeader != null;
    }
    
    public boolean isCookieName() {
        return this.cookieName != null;
    }
    
    private CallbackHandler getCallbackHandler(Map<String, String> map) {
        try {
            return WSMappingCallbackHandlerFactory.getInstance().getCallbackHandler(map, null);
        } catch (NotImplementedException exception) {
            throw new IllegalStateException(exception); 
        }
    }
    
    public static CredentialsType findCredentialsType(String credentialsTypeName) {
        for (CredentialsType credentialsType : values()) {
            if (credentialsType.name.equals(credentialsTypeName)) {
                return credentialsType;
            }
        }
        
        return null;
    }
    
    public static CredentialsType getCredentialsType(String credentialsTypeName, String datasourceName) {
    	CredentialsType credentialsType = findCredentialsType(credentialsTypeName);

    	if (credentialsType == null) {
    		throw new IllegalStateException("The credentials type '" + credentialsTypeName + "' for datasource '" + datasourceName + "' is not supported.");
    	}
    	
    	return credentialsType;
    }
}
