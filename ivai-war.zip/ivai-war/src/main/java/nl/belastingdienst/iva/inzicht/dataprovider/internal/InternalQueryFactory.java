package nl.belastingdienst.iva.inzicht.dataprovider.internal;

import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.core.MultivaluedMap;

import nl.belastingdienst.iva.inzicht.database.configuration.query.QueryFilter;
import nl.belastingdienst.iva.inzicht.dataprovider.AbstractQueryFactory;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.domain.query.QueryUtils;

public class InternalQueryFactory extends AbstractQueryFactory {
 
    public String getInternalQuery(QueryInterface query, MultivaluedMap<String, String> queryValues) {
        String internalQuery = query.getQueryTemplate();
        internalQuery = addResultColumns(internalQuery, query);
        internalQuery = addFilters(internalQuery, query, queryValues);
        return replaceParameters(internalQuery, queryValues); 
    }
    
    private String addResultColumns(String internalQuery, QueryInterface query) {
        List<QueryResultColumn> resultColumns = mapColumns(query.getQueryColumns());
        String columns = resultColumns.stream().map(resultColumn -> resultColumn.getName()).collect(Collectors.joining(" "));
        return QueryUtils.addResultColumns(internalQuery, columns);
    }
    
    private String addFilters(String internalQuery, QueryInterface query, MultivaluedMap<String, String> queryValues) {
        List<QueryFilter> queryFilters = query.getQueryFilters();
        StringBuilder filter = new StringBuilder();

        for (QueryFilter queryFilter : queryFilters) {
            List<String> parameterList = queryFilter.getParameterList();
            boolean parameterAvailable = true;

            for (String parameter : parameterList) {
                parameterAvailable = parameterAvailable && queryValues.containsKey(parameter);
            }

            if (parameterAvailable) {
                filter.append(" ");
                filter.append(queryFilter.getFilterTemplate());
            } else if (queryFilter.hasNoFilterTemplate()) {
                filter.append(" ");
                filter.append(queryFilter.getNoFilterTemplate());
            }
        }
        
        return QueryUtils.addFilter(internalQuery, filter.toString());
    }
}
