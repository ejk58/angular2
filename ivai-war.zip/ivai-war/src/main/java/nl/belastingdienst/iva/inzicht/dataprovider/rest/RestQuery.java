package nl.belastingdienst.iva.inzicht.dataprovider.rest;

import java.util.List;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.domain.query.QueryResultColumn;

public class RestQuery {

    private Datasource datasource;
    private String requestUrl;
    private String basePath; 
    private List<QueryResultColumn> columns;

    public RestQuery(Datasource datasource, String requestUrl, String basePath, List<QueryResultColumn> columns) {
        this.datasource = datasource;
        this.requestUrl = requestUrl;
        this.basePath = basePath;
        this.columns = columns;
    }
    
    public Datasource getDatasource() {
        return this.datasource;
    }

    public String getRequestUrl() {
        return this.requestUrl;
    }
    
    public String getBasePath() {
        return this.basePath;
    }

    public List<QueryResultColumn> getColumns() {
        return this.columns;
    }
}
