package nl.belastingdienst.iva.inzicht.configuration.page;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageDomain;

public class PageParser {

    private List<Page> pageList;

    public PageParser(List<Page> pageList) {
        this.pageList = pageList;
    }

    public Map<String, Page> getPageMap() {
        Map<String, Page> pageMap = new ConcurrentHashMap<>();
        
        for (Page page : this.pageList) {
            String pageKey = page.getKey().toLowerCase();
            pageMap.put(pageKey, page);
        }
        
        return pageMap;
    }

    public Map<String, List<Page>> getPageByDomainMap() {
        Map<String, List<Page>> pageMap = new ConcurrentHashMap<>();
        
        for (Page page : this.pageList) {
            for (PageDomain pageDomain : page.getPageDomains()) {
                String key = pageDomain.getDomain().getKey().toLowerCase();
                List<Page> values = !pageMap.containsKey(key) ? new ArrayList<>() : pageMap.get(key);
                values.add(page);
                pageMap.put(key, values);
            }
        }
        
        return pageMap;
    }
}
