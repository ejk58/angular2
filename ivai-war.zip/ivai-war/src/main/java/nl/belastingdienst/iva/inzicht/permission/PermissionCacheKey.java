package nl.belastingdienst.iva.inzicht.permission;

public class PermissionCacheKey {

    private String permissionProvider;
    private String userName;
    private String key;
    private String value;
    
    private long moment;
    private int hashCode;

    public PermissionCacheKey(String permissionProvider, String userName, String key, String value) {
        if (permissionProvider == null || userName == null || key == null || value == null) {
            throw new NullPointerException("Permission-provider, username and subject-key/number are mandatory, " + 
            		"these values cannot be null in the permission cache.");
        }

        this.moment = System.currentTimeMillis();
        this.hashCode = calculateHashCode(permissionProvider, userName, key, value);
        
        this.permissionProvider = permissionProvider;
        this.userName = userName;
        this.key = key;
        this.value = value;
    }
    
    public long getMoment() {
        return this.moment;
    }
    
    public String getKey() {
		return this.key;
	}

	public String getValue() {
		return this.value;
	}

	@Override
    public int hashCode() {
        return this.hashCode;
    }
    
    @Override
    public boolean equals(Object otherObject) {
        if (this == otherObject) {
            return true;
        }
        
        if ((otherObject == null) || (this.getClass() != otherObject.getClass())) {
            return false;
        }
        
        return equals((PermissionCacheKey) otherObject);
    }
    
    public boolean equals(PermissionCacheKey otherPermissionCacheKey) {
        return this.permissionProvider.equals(otherPermissionCacheKey.permissionProvider) && 
                this.userName.equals(otherPermissionCacheKey.userName) && 
                this.key.equals(otherPermissionCacheKey.key) && 
                this.value.equals(otherPermissionCacheKey.value);
    }
    
    private int calculateHashCode(String permissionProvider, String userName, String key, String value) {
        final int prime = 31;
        int result = 1;
        result = prime * result + permissionProvider.hashCode();
        result = prime * result + userName.hashCode();
        result = prime * result + key.hashCode();
        result = prime * result + value.hashCode();
        return result;
    }
}
