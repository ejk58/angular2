package nl.belastingdienst.iva.inzicht.service.feedback;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import nl.belastingdienst.iva.inzicht.configuration.Configuration;
import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.database.configuration.page.Page;
import nl.belastingdienst.iva.inzicht.database.configuration.page.PageWidget;
import nl.belastingdienst.iva.inzicht.database.configuration.widget.Widget;
import nl.belastingdienst.iva.inzicht.database.feedback.Feedback;
import nl.belastingdienst.iva.inzicht.database.feedback.FeedbackDao;
import nl.belastingdienst.iva.inzicht.domain.DataHashMap;
import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.key.ConfigurationKey;
import nl.belastingdienst.iva.inzicht.domain.key.ResponseKey;
import nl.belastingdienst.iva.inzicht.jira.JiraException;
import nl.belastingdienst.iva.inzicht.jira.JiraIssueFactory;
import nl.belastingdienst.iva.inzicht.jira.JiraRestClient;
import nl.belastingdienst.iva.inzicht.jira.domain.JiraIssue;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;
import nl.belastingdienst.iva.inzicht.service.AbstractRestService;
import nl.belastingdienst.iva.inzicht.service.RestServiceType;
import nl.belastingdienst.iva.inzicht.user.RoleUtils;

@Stateless
@Path("/feedback")
@RolesAllowed({RoleUtils.INZICHT_USER_ROLE})
public class FeedbackService extends AbstractRestService {

    @Inject
    private FeedbackDao feedbackDao;
    
    @Inject
    private JiraIssueFactory jiraIssueFactory;
    
    @Inject
    private JiraRestClient jiraRestClient;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    public Response saveFeedback(Feedback feedback) {
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.FEEDBACKSAVESERVICE);
        Configuration configuration = restCallContext.getConfiguration();
        String userName = restCallContext.getUserName();
        
        feedback.setUsername(userName);
        feedback.setCreated(new Date());
        
        String environment = configuration.getValueAsString(ConfigurationKey.JIRAFEEDBACKENVIRONMENT);
        feedback.setSummary(environment + ": Te beoordelen");
        
        if (Boolean.TRUE.equals(configuration.getValueAsBoolean(ConfigurationKey.JIRAISSUECREATIONFROMFEEDBACKENABLED))) {
	        try {
	        	createJiraIssue(feedback, configuration);
	        } catch (Exception exception) {
	        	logException(restCallContext, exception, "A problem occurred while making a Jira issue");
	        }
        }
        
        try {
        	this.feedbackDao.saveFeedback(feedback);
        	return buildResponse(restCallContext);
        } catch (Exception exception) {
        	return handleException(exception, restCallContext);
        }
    }
    
    @GET
    @Path("/widgets")
    @Produces({MediaType.APPLICATION_JSON})
    public Response getWidgetNames(@Context UriInfo uriInfo) {
        RestCallContext restCallContext = buildRestCallContext(RestServiceType.FEEDBACKLOADSERVICE, uriInfo.getQueryParameters());

        try {
            Page tab = restCallContext.findTab();
            DataMap response = new DataHashMap();
            response.put(ResponseKey.WIDGETS, getWidgetNames(tab));
            return buildResponse(response, restCallContext);
        } catch (Exception exception) {
            return handleException(exception, restCallContext);
        }
    }
    
    private void createJiraIssue(Feedback feedback, Configuration configuration) throws IOException, JiraException {
		JiraIssue issue = jiraIssueFactory.createIssue(feedback, configuration);		
		Datasource jiraFeedbackDatasource = configuration.getJiraFeedbackDatasource();
		jiraRestClient.submit(jiraFeedbackDatasource, issue);
	}

    private List<String> getWidgetNames(Page tab) {
    	List<String> widgetNames = new ArrayList<>();
    	
    	for (PageWidget tabWidget : tab.getPageWidgets()) {
    		Widget widget = tabWidget.getWidget();
    		if (!widget.getType().endsWith("Filter")) {
    			widgetNames.add(widget.getTitle() != null ? widget.getTitle() : widget.getName());
    		} else {
        		widgetNames.addAll(getInnerWidgetNames(widget));
    		}
    	}
    	
		return widgetNames;
	}
    
    private List<String> getInnerWidgetNames(Widget widget) {
    	List<String> widgetNames = new ArrayList<>();

    	for (Widget innerWidget : widget.getWidgetList()) {
    		if (!innerWidget.getType().endsWith("Filter")) {
    			widgetNames.add(innerWidget.getTitle() != null ? innerWidget.getTitle() : innerWidget.getName());
    		} else {
        		widgetNames.addAll(getInnerWidgetNames(innerWidget));
    		}
    	}
    	
    	return widgetNames;
    }
}
