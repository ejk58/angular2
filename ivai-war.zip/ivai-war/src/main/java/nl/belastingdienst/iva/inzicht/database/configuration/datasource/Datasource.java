package nl.belastingdienst.iva.inzicht.database.configuration.datasource;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.security.auth.login.LoginException;

import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;

@Entity
@Table(name = "CONF_DATASOURCE")
@NamedQuery(name = Datasource.QUERY_GETDATASOURCES, query = "SELECT d FROM Datasource d ORDER BY d.key")
public class Datasource {

    public static final String QUERY_GETDATASOURCES = "Datasource.getDatasources"; 
    
    private static final String FALSE = "0";

    @Id
    private Integer id;
    private String key;
    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "DATASOURCE_ID")
    private List<DatasourceParam> parameterList;

    @Transient
    private Map<String, String> parameterMap;
    
    public Integer getId() {
        return this.id;
    }
    
    public String getKey() {
        return this.key;
    }
    
    public List<DatasourceParam> getParameterList() {
        return Collections.unmodifiableList(this.parameterList);
    }
    
    public Map<String, String> getParameterMap() {
        return (this.parameterMap == null) ? Collections.<String, String>emptyMap() : Collections.unmodifiableMap(this.parameterMap);
    }
    
    public boolean hasParameterMap() {
        return (this.parameterMap != null) && (this.parameterMap.size() > 0);
    }
    
    public String getValue(String key) {
        return this.parameterMap.get(key);
    }

    public Integer getNumber(String key) {
        String value = this.parameterMap.get(key);
        return (value == null) ? null : Integer.parseInt(value);
    }
    
    public boolean getBoolean(String key) {
        String value = this.parameterMap.get(key);
        return (value != null && value.length() > 0 && !FALSE.equals(value));
    }
    
    @Override
    public int hashCode() {
        return this.key.hashCode();
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        
        Datasource otherDatasource = (Datasource) object;
        return this.key.equals(otherDatasource.key);
    }

    public void buildParameterMap() throws LoginException {
    	if (this.parameterMap == null) {
    		try {
    			createParameterMap();
    			enhanceParameterMap();
    		} finally {
    			lockParameterMap();
    		}
    	}
    }
    
    private void createParameterMap() {
        this.parameterMap = new HashMap<>();
        
        for (DatasourceParam parameter : this.parameterList) {
        	this.parameterMap.put(parameter.getKey(), parameter.getValue());
        }
    }
    
    private void enhanceParameterMap() throws LoginException {
        if (this.parameterMap.containsKey(DatasourceKey.CREDENTIALSTYPE) && this.parameterMap.containsKey(DatasourceKey.CREDENTIALSMAPPING)) {
            CredentialsType credentialsType = CredentialsType.getCredentialsType(this.parameterMap.get(DatasourceKey.CREDENTIALSTYPE), this.key);
            CredentialsEncoding credentialsEncoding = CredentialsEncoding.getCredentialsEncoding(this.parameterMap.get(DatasourceKey.CREDENTIALSENCODING), this.key);
            String parameterValue = this.parameterMap.get(DatasourceKey.CREDENTIALSMAPPING);
            String credentialsValue = credentialsEncoding.encodeCredentials(credentialsType.getCredentialsAsString(parameterValue));
            this.parameterMap.put(DatasourceKey.CREDENTIALSVALUE, credentialsValue);
        }
    }
    
    private void lockParameterMap() {
    	this.parameterMap = Collections.unmodifiableMap(this.parameterMap);
    }
}
