package nl.belastingdienst.iva.inzicht.engine.action;

import nl.belastingdienst.iva.inzicht.engine.Flow;
import nl.belastingdienst.iva.inzicht.restcallcontext.EngineRestCallContext;

public interface Action {

	Flow execute(EngineRestCallContext restCallContext);
	String getAction();
}
