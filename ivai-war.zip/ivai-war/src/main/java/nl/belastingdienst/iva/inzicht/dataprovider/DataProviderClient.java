package nl.belastingdienst.iva.inzicht.dataprovider;

import nl.belastingdienst.iva.inzicht.domain.DataMap;
import nl.belastingdienst.iva.inzicht.domain.query.QueryInterface;
import nl.belastingdienst.iva.inzicht.restcallcontext.RestCallContext;

@FunctionalInterface
public interface DataProviderClient {

    DataMap[] retrieveDataAsMultiMap(QueryInterface query, RestCallContext restCallContext);
}
