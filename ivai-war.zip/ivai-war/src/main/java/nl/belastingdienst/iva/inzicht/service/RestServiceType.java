package nl.belastingdienst.iva.inzicht.service;

public enum RestServiceType {
	PAGESERVICE("PageService/getAllPages"),
	RELATIONSERVICE("RelationService/getRelations"),
	SUBJECTSERVICE("SubjectService/getSubject"),
	VIEWSERVICE("ViewService/getViews"),
	WIDGETSERVICE("WidgetService/getWidget"),
	
	EVENTSAVESERVICE("EventService/saveEvent"),
	FEEDBACKLOADSERVICE("FeedbackService/getWidgets"),
	FEEDBACKSAVESERVICE("FeedbackService/saveFeedback"),
	NOTIFICATIONSERVICE("NotificationService/getNotifications"),
	
	ALIVESERVICE("SystemService/isAlive"),
	SYSTEMSERVICE("SystemService/getStatus"),
	WIZARDSERVICE("WizardService/getSubjects");
	
	private String name;
	
	private RestServiceType(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
