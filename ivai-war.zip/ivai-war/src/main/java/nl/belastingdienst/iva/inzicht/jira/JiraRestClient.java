package nl.belastingdienst.iva.inzicht.jira;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.stream.Collectors;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status.Family;
import javax.ws.rs.core.Response.StatusType;

import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientResponse;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.codehaus.jackson.map.ObjectMapper;

import nl.belastingdienst.iva.inzicht.database.configuration.datasource.Datasource;
import nl.belastingdienst.iva.inzicht.dataprovider.rest.AllCertificatesTrustManager;
import nl.belastingdienst.iva.inzicht.domain.exception.InternalServerErrorException;
import nl.belastingdienst.iva.inzicht.domain.key.DatasourceKey;
import nl.belastingdienst.iva.inzicht.jira.domain.JiraErrorResponse;
import nl.belastingdienst.iva.inzicht.jira.domain.JiraIssue;

public class JiraRestClient {
	
	private ObjectMapper objectMapper;
	
	public JiraRestClient() {
		this.objectMapper = new ObjectMapper();
	}

	public void submit(Datasource jiraFeedbackDatasource, JiraIssue issue) throws IOException, JiraException {
		String json = objectMapper.writeValueAsString(issue);
		
		RestClient restClient = createRestClientForDatasource(jiraFeedbackDatasource);
		String restUrl = jiraFeedbackDatasource.getValue(DatasourceKey.RESTURL);
		String fullIssueUrl = restUrl + "/api/2/issue";
		
		Resource resource = restClient.resource(fullIssueUrl);
        resource.contentType(MediaType.APPLICATION_JSON);
        resource.header(HttpHeaders.AUTHORIZATION, jiraFeedbackDatasource.getValue(DatasourceKey.CREDENTIALSVALUE));
		
		ClientResponse response = resource.post(json);
		StatusType statusType = response.getStatusType();
		if (statusType.getStatusCode() == 401) {
			throw new JiraException("Unauthorized for the Jira environment or given project", statusType);
		} else if (statusType.getFamily() == Family.CLIENT_ERROR || statusType.getFamily() == Family.SERVER_ERROR) {
			JiraErrorResponse jiraErrorResponse = response.getEntity(JiraErrorResponse.class);
			
			String errors = jiraErrorResponse.getErrors().entrySet().stream()
					.map(entry -> "(" + entry.getKey() + ": " + entry.getValue() + ")")
					.collect(Collectors.joining(", "));
			String errorMessage = "Errors encountered while submitting Jira issue: " + errors;
			throw new JiraException(errorMessage, statusType);
		}
	}
	
	// TODO: this is a copy of RestServiceClient's createRestClientForDatasource method
	private RestClient createRestClientForDatasource(Datasource datasource) {
        int connectTimeout = datasource.getNumber(DatasourceKey.CONNECTTIMEOUT);
        int readTimeout = datasource.getNumber(DatasourceKey.READTIMEOUT);
        boolean trustAllCertificates = (datasource.getNumber(DatasourceKey.TRUSTALLCERTIFICATES) == 1);

        ClientConfig clientConfig = new ClientConfig();
        clientConfig.connectTimeout(connectTimeout);
        clientConfig.readTimeout(readTimeout);
    	trustAllCertificates(trustAllCertificates);

        return new RestClient(clientConfig);
    }
	
	// TODO: this is a copy of RestServiceClient's trustAllCertificates method
	private void trustAllCertificates(boolean trustAllCertificates) {
        if (trustAllCertificates) {
            try {
                TrustManager[] trustManager = new TrustManager[]{new AllCertificatesTrustManager()};
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, trustManager, new java.security.SecureRandom());
                HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            } catch (NoSuchAlgorithmException | KeyManagementException exception) {
                throw new InternalServerErrorException(exception.getMessage(), exception);
            }
        }
    }
	
}
