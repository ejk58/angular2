import {AfterViewInit, Component, ElementRef, Input, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Store} from '@ngrx/store';
import {fromEvent} from 'rxjs';
import {Column} from '../../classes/column';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {SplitViewState} from '../../services/split-view-state.service';
import {TrackingService} from '../../services/tracking.service';
import * as fromSelectors from '../../store/selectors';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  providers: [Unsubscriber]
})
export class ListComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild('listsection') private readonly listSection: ElementRef;

  @Input() side: string;
  @Input() widgetId: string;
  @Input() widget: any;

  public static readonly horizontalLayoutWidthThreshold: number = 500;

  public labelKey: string;
  public valueKey: string;
  public activeSides: any;
  public params: any;
  public isBulletList: boolean = false;
  public list: {}[];
  public detailsPage: string;
  public detailsPageNavigationLabel: string;

  public listValuesHorizontally: boolean;
  public isWide: boolean;

  constructor(private readonly util: PageNavigationUtilService,
              private readonly trackingService: TrackingService,
              private readonly store: Store<any>,
              private readonly splitViewState: SplitViewState,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit(): void {
    this.store.select(fromSelectors.getRouterSides)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(routerSides => {
        this.activeSides = routerSides;
        this.params = this.activeSides[this.side];
      });

    if (this.widget.type === 'List') {
      this.addListData();
      if (this.listValuesHorizontally) {
        this.initHorizontalLayoutResizeListener();
      }
    } else if (this.widget.type === 'CrossList') {
      this.addCrossListData();
    } else if (this.widget.type === 'BulletList') {
      this.isBulletList = true;
      this.addBulletListData();
    }

    this.initializeDetailsPageButton();
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.checkIsWide();
    });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  private initHorizontalLayoutResizeListener(): void {
    fromEvent(window, 'resize')
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(this.checkIsWide.bind(this));

    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(sizes => {
        if (sizes != null && this.listSection != null) {
          this.checkIsWide();
        }
      });
  }

  private checkIsWide(): void {
    this.isWide = this.listSection && this.listSection.nativeElement.offsetWidth >= ListComponent.horizontalLayoutWidthThreshold;
  }

  private addListData(): void {
    this.list = [];
    if (this.widget.data[0]) {
      for (const key in this.widget.options.columns) {
        if (Column.isVisible(this.widget.options.columns[key].behaviour)) {
          if (this.widget.options.columns[key].columnType === 'JSON') {
            this.list = this.list.concat(this.addJsonObjectToList(this.widget.data[0][key]));
          } else {
            const label = this.widget.options.columns[key].label;
            const column = this.widget.options.columns[key];
            const row = this.widget.data[0];
            row['alignment'] = 'left';

            this.list.push({'label': label, 'column': column, 'row': row});
          }
        }
      }
    }

    this.listValuesHorizontally = this.widget.options.listValuesHorizontally === 'true';
  }

  private addCrossListData(): void {
    this.list = [];
    if (this.widget.data[0]) {
      const visibleKeys = Object.keys(this.widget.data[0]).filter(key => {
        return this.widget.options.columns[key] && Column.isVisible(this.widget.options.columns[key].behaviour);
      });
      this.labelKey = visibleKeys.length <= 1 ? null : visibleKeys[0];
      this.valueKey = visibleKeys.length <= 1 ? visibleKeys[0] : visibleKeys[1];

      for (let index = 0; index < this.widget.data.length; index++) {
        if (Column.isVisible(this.widget.options.columns[this.valueKey].behaviour)) {
          if (this.widget.options.columns[this.valueKey].columnType === 'JSON') {
            this.list = this.list.concat(this.addJsonObjectToList(this.widget.data[index]));
          } else {
            const label = this.labelKey == null ? null : this.widget.data[index][this.labelKey];
            const columnLabel = this.widget.options.columns[this.labelKey];
            const column = this.widget.options.columns[this.valueKey];
            const row = this.widget.data[index];
            row['alignment'] = 'left';
            this.list.push({'label': label, 'columnLabel': columnLabel, 'column': column, 'row': row});
          }
        }
      }
    }
  }

  private addBulletListData(): void {
    this.list = [];
    if (this.widget.data[0]) {
      const visibleKeys = Object.keys(this.widget.data[0]).filter(key => {
        return this.widget.options.columns[key] && Column.isVisible(this.widget.options.columns[key].behaviour);
      });
      this.labelKey = visibleKeys.length <= 1 ? null : visibleKeys[0];
      this.valueKey = visibleKeys.length <= 1 ? visibleKeys[0] : visibleKeys[1];

      for (let index = 0; index < this.widget.data.length; index++) {
        const label = '___';
        const column = this.widget.options.columns[this.valueKey];
        const row = this.widget.data[index];
        row['alignment'] = 'left';

        this.list.push({'label': label, 'column': column, 'row': row});
      }
    }
  }

  private addJsonObjectToList(jsonObject: any): {'label': any, 'column': any, 'row': any}[] {
    return Object.keys(jsonObject).map((key) => {
      const column = {'columnName': key, 'columnType': 'STRING', 'label': key, 'behaviour': 'visible'};
      return {'label': key, 'column': column, 'row': {[key]: jsonObject[key], 'alignment': 'left'}};
    });
  }

  private initializeDetailsPageButton(): void {
    this.detailsPage = this.widget.options.detailsPage;
    this.detailsPageNavigationLabel = this.widget.options.detailsPageNavigationLabel ? this.widget.options.detailsPageNavigationLabel : 'Details';
  }

  public hasDetailsPageButton(): boolean {
    return this.detailsPage != null;
  }

  onGlobalDetails() {
    this.trackingService.trackEvent('klik',
      'Klik doorsturen:' + this.side + '/tab van:' + this.params.domain +
      '/widget van:' + this.widgetId + '/tab naar:' + this.detailsPage,
      null, null);
    this.util.updateBreadcrumb(this.side, this.widgetId, this.params.klantbeeld, this.params.domain, this.detailsPage, null);
    this.util.navigateToPage(this.side, this.detailsPage, null, null);
  }

  public hasValue(item: any): boolean {
    if (item.row[item.column.columnName] && item.column.columnType === 'FOOTNOTEDSTRING') {
      return item.row[item.column.columnName]['value'] != undefined;
    } else {
      return item.row[item.column.columnName] != undefined;
    }
  }
}
