import { Selection } from 'd3-ng2-service';
import { Node } from './node';

export class Link {

  public startNode: Node;
  public endNode: Node;
  public id: string;
  public classes: string[];

  constructor(startNode: Node, endNode: Node) {
    this.startNode = startNode;
    this.endNode = endNode;
    this.id = 'id-' + startNode.subjectNr + '-' + endNode.subjectNr;
    this.classes = ['link', 'id-' + startNode.subjectNr + '-link', 'id-' + endNode.subjectNr + '-link'];

    if ((this.startNode.isSubject && this.endNode.isFiscalPartner) || (this.startNode.isFiscalPartner && this.endNode.isSubject)) {
      this.classes.push('fiscal-link');
    }
  }

  public draw(graph: Selection<any, any, any, any>): void {
    graph.append('line')
      .attr('x1', this.startNode.x)
      .attr('y1', this.startNode.y)
      .attr('x2', this.endNode.x)
      .attr('y2', this.endNode.y)
      .attr('id', this.id)
      .attr('class', this.classes.join(' '));
  }
}
