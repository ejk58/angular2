import { Selection } from 'd3-ng2-service';

export class Node {

  public static readonly subjectType: string = 'BELASTINGPLICHTIGE';
  public static readonly parentType: string = 'OUDER VAN';
  public static readonly motherType: string = 'MOEDER VAN';
  public static readonly fatherType: string = 'VADER VAN';
  public static readonly childType: string = 'KIND VAN';
  public static readonly marriedPartnerType: string = 'GEHUWD';
  public static readonly marriedWithPartnerType: string = 'GEHUWD MET';
  public static readonly livingPartnerType: string = 'WOONT SAMEN MET';
  public static readonly exPartnerType: string = 'EX-PARTNER';
  public static readonly shareholderType: string = 'AANDEELHOUDER VAN';
  public static readonly managerType: string = 'BESTUURDER VAN';
  public static readonly manyPeopleType: string = '>20 PERSONEN OP ADRES';

  public static readonly personLineHeight: number = 12;
  public static readonly adultNodeRadius: number = 25;
  public static readonly childNodeRadius: number = 20;
  public static readonly manyPeopleNodeRadius: number = 30;
  public static readonly auraRadius: number = Node.adultNodeRadius + Node.personLineHeight * 3;

  private static readonly adultPersonScale: number = 0.40;
  private static readonly childPersonScale: number = 0.30;
  private static readonly manyPeoplePersonScale: number = 0.90;
  private static readonly companyScale: number = 2.00;

  // tslint:disable-next-line:max-line-length
  private static readonly personPath = 'M26.49,115.16H22.84A8,8,0,0,1,15,107.59L12,72.86C4.87,63.55,3.49,48.29,3.44,47.63' +
    'A14.81,14.81,0,0,1,7.11,36.45a13.6,13.6,0,0,1,10.26-4.2H32a13.64,13.64,0,0,1,10.3,4.18,14.63,14.63,0,0,1,3.64,11.18c-.06.67-1.43,15.94-8.58,25.25l-2.94,34.76' +
    'A8,8,0,0,1,26.49,115.16ZM24.66,28.77c-6.41,0-12-6.22-12-13.31a12.19,12.19,0,0,1,12-12.31,12.19,12.19,0,0,1,12,12.31C36.7,22.56,31.08,28.77,24.66,28.77Z';
  private static readonly manyPeoplePath = 'M35.23,17.33l-.27.25a5.61,5.61,0,0,0,.54.59,8,8,0,0,1,3.13,1.32h.05a5.37,5.37,0,0,0,5-5.48,5.05,5.05,0,0,0-5-5.07,5.13,5.13,0,0,0-1.62.29,7,7,0,0,1,.45,2.52' +
    'A7.91,7.91,0,0,1,35.23,17.33Z' +
    'M46,22.64a5.73,5.73,0,0,0-4.3-1.72H40.16a8.23,8.23,0,0,1,1.72,5.87c-.07.78-.78,7.58-4.06,12.12L36.47,54.55s0,.08,0,.12a3.34,3.34,0,0,0,1.47.38h1.52a3.32,3.32,0,0,0,3.31-3.1' +
    'L44,37.64c3-3.83,3.55-10.12,3.58-10.39A6,6,0,0,0,46,22.64Z' +
    'M25.9,18.16H18.27a7.14,7.14,0,0,0-5.35,2.16A7.56,7.56,0,0,0,11,26.07c0,.34.75,8.19,4.46,13L17,56.92a4.15,4.15,0,0,0,4.09,3.9H23a4.15,4.15,0,0,0,4.14-3.88' +
    'L28.7,39.05c3.73-4.79,4.44-12.65,4.47-13a7.46,7.46,0,0,0-1.9-5.75A7.16,7.16,0,0,0,25.9,18.16Zm-3.83-1.79c3.35,0,6.28-3.2,6.26-6.85a6.26,6.26,0,1,0-12.52,0' +
    'C15.82,13.16,18.73,16.36,22.08,16.36Z' +
    'M27.34,15.58a8.36,8.36,0,0,1-.74.65,6.14,6.14,0,0,0,.51.46,8.74,8.74,0,0,1,3.54,1.21A6.08,6.08,0,0,0,36,11.76a5.68,5.68,0,0,0-5.63-5.7,5.8,5.8,0,0,0-1.26.16,7.58,7.58,0,0,1,.72,3.28' +
    'A8.62,8.62,0,0,1,27.34,15.58Z' +
    'M38.66,21.47a6.45,6.45,0,0,0-4.83-1.94H32.6a9,9,0,0,1,2.08,6.66c-.08.86-.86,8.41-4.51,13.42L28.67,57a5.54,5.54,0,0,1-.1.73,3.77,3.77,0,0,0,1,.16h1.71' +
    'A3.73,3.73,0,0,0,35,54.44l1.38-16.1c3.36-4.31,4-11.38,4-11.69A6.72,6.72,0,0,0,38.66,21.47Z';
   private static readonly companyPath = 'M12 7V3H2v18h20V7H12zM6,19H4v-2h2v2zm0-4H4v-2h2v2zm0-4H4V9h2v2zm0-4H4V5h2v2zm4,12H8v-2h2v2zm0-4H8v-2h2v2zm0-4' +
    'H8V9h2v2zm0-4H8V5h2v2zm10,12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8v10zm-2-8h-2v2h2v-2zm0,4h-2v2h2v-2z';

  private static readonly nameUnknown = 'onbekend';
  private static readonly dataIndex = 'data-index';
  private static readonly textAnchor = 'text-anchor';
  private static readonly personHighlight = 'person-highlight';

  public isMasked: boolean;
  public isNaturalPerson: boolean;
  public isSubject: boolean;
  public isFiscalPartner: boolean;
  public isMarriedPartner: boolean;
  public isLivingPartner: boolean;
  public isPartnersChild: boolean;
  public isNormalPerson: boolean;
  public isParent: boolean;
  public isChild: boolean;
  public isCompany: boolean;
  public isYoungPerson: boolean;
  public isExPartner: boolean;
  public isManyPeople: boolean;
  public isRelated: boolean;
  public isSameAddress: boolean;

  public subjectNr: string;
  public types: string[];
  public name: string;
  public age: string;
  public label: string;

  public index: number;
  public rank: number;
  public data: any;
  public id: string;
  public classes: string[];
  public x: number;
  public y: number;
  public radius: number;

  constructor(row: any, index: number) {
    const mainType = row['relatiesoort_bes'];

    this.subjectNr = (row['finr_relatie'] === null ? Node.nameUnknown : row['finr_relatie']);
    this.name = (row['naam_relatie'] ? row['naam_relatie'] : '');
    this.types = [mainType];

    this.isMasked = (this.name === '######');
    this.isSubject = (mainType === Node.subjectType);
    this.isNaturalPerson = (row['is_np'] === 1);
    this.isNormalPerson = (!this.isMasked && mainType !== Node.shareholderType &&
        mainType !== Node.managerType && mainType !== Node.manyPeopleType);
    this.isChild = (mainType === Node.parentType || mainType === Node.motherType || mainType === Node.fatherType);
    this.isParent = (mainType === Node.childType);
    this.isCompany = (mainType === Node.shareholderType || mainType === Node.managerType);
    this.isYoungPerson = (this.isNormalPerson && row['leeftijd_relatie'] != null && row['leeftijd_relatie'] < 18);
    this.isMarriedPartner = (mainType === Node.marriedPartnerType || mainType === Node.marriedWithPartnerType);
    this.isLivingPartner = (mainType === Node.livingPartnerType);
    this.isExPartner = (mainType === Node.exPartnerType);
    this.isFiscalPartner = (row['finr_relatie'] != null && row['finr_relatie'] === row['finr_fiscale_partner']);
    this.isPartnersChild = (row['kind_van_fisc_partner'] === 1);
    this.isManyPeople = (mainType === Node.manyPeopleType);
    this.isSameAddress = (row['zelfde_adres_bes'] === 'Zelfde adres');
    this.isRelated = (this.isFiscalPartner || this.isMarriedPartner || this.isLivingPartner ||
        this.isParent || this.isChild || this.isCompany);

    this.age = (this.isMasked ? null : row['leeftijd_relatie']);
    this.label = (this.isMasked ? 'VIP' : this.age);

    this.index = index;
    this.data = row;
    this.id = 'id-' + this.subjectNr;
    this.classes = ['node', 'group'];

    if (this.isSubject) {
      this.classes.push('belastingplichtige');
    } else {
      this.classes.push('url-item');

      if (this.isFiscalPartner) {
        this.classes.push('fiscaal-partner');
      }

      if (mainType === Node.shareholderType) {
        this.classes.push('aandeelhouder-van');
      } else if (mainType === Node.managerType) {
        this.classes.push('bestuurder-van');
      } else if (mainType === Node.manyPeopleType) {
        this.classes.push('meer-dan-20-personen-op-adres');
      } else if (mainType === Node.parentType || this.isPartnersChild) {
        this.classes.push('ouder-van');
      } else if (mainType === Node.motherType) {
        this.classes.push('moeder-van');
      } else if (mainType === Node.fatherType) {
        this.classes.push('vader-van');
      } else if (mainType === Node.childType) {
        this.classes.push('kind-van');
      } else if (this.isMarriedPartner) {
        this.classes.push('married-partner');
      } else if (this.isLivingPartner) {
        this.classes.push('living-partner');
      } else if (this.isExPartner) {
        this.classes.push('ex-partner');
      } else if (!this.isFiscalPartner) {
        this.classes.push('onbekende-relatie');
      }
    }

    if (this.isYoungPerson) {
      this.classes.push('leeftijd-kind');
    }

    this.x = 0;
    this.y = 0;
    this.radius = Node.adultNodeRadius;
    if (this.isYoungPerson) {
      this.radius = Node.childNodeRadius;
    } else if (this.isManyPeople) {
      this.radius = Node.manyPeopleNodeRadius;
    }

    this.determineRank();
  }

  public isSameSubject(row: any): boolean {
    return this.subjectNr === row['finr_relatie'];
  }

  public merge(row: any): void {
    const additionalName = (row['naam_relatie'] ? row['naam_relatie'] : '');
    const additionalType = row['relatiesoort_bes'];

    this.name = this.name === additionalName ? this.name : this.name + ' / ' + additionalName;
    this.types.push(additionalType);

    if (additionalType === Node.shareholderType) {
      this.classes.push('aandeelhouder-van');
    } else if (additionalType === Node.managerType) {
      this.classes.push('bestuurder-van');
    } else if (additionalType === Node.manyPeopleType) {
      this.classes.push('meer-dan-20-personen-op-adres');
    } else if (additionalType === Node.parentType) {
      this.classes.push('ouder-van');
    } else if (additionalType === Node.motherType) {
      this.classes.push('moeder-van');
    } else if (additionalType === Node.fatherType) {
      this.classes.push('vader-van');
    } else if (additionalType === Node.childType) {
      this.classes.push('kind-van');
    } else if (additionalType === Node.marriedPartnerType || additionalType === Node.marriedWithPartnerType) {
      this.classes.push('married-partner');
    } else if (additionalType === Node.livingPartnerType) {
      this.classes.push('living-partner');
    } else if (additionalType === Node.exPartnerType) {
      this.classes.push('ex-partner');
    }

    this.determineRank();
  }

  public getName(): string {
    return (this.name == null || this.name.length <= 18) ? this.name : this.name.substring(0, 18) + '...';
  }

  public getDescription(): string {
    let description = '';

    this.types.forEach((type: string) => {
      if (description.length === 0) {
        description = type[0].toUpperCase() + type.slice(1).toLowerCase();
      } else {
        description = description + ' / ' + type.toLowerCase();
      }
    });

    return description;
  }

  public getRelations(): string[] {
    return this.types.map((type: string): string => {
      return (type == null || type.length < 1 ? type : (type[0].toUpperCase() + type.slice(1).toLowerCase()));
    });
  }

  public draw(graph: Selection<any, any, any, any>): void {
    this.drawIcon(graph);
    this.drawTextBox(graph);
  }

  public drawIcon(graph: Selection<any, any, any, any>): void {
    let element = null;

    const nodeGroup = graph.append('g')
      .attr('id', 'RelationNode' + this.subjectNr)
      .attr('class', this.classes.join(' '));

    if (!this.isNaturalPerson && !this.isManyPeople) {
      element = nodeGroup.append('rect')
        .attr('class', 'background-icon')
        .attr('x', this.x - this.radius)
        .attr('y', this.y - this.radius)
        .attr('width', this.radius * 2)
        .attr('height', this.radius * 2)
        .attr('rx', 5)
        .attr('ry', 5)
        .attr(Node.dataIndex, this.index);
    } else {
      element = nodeGroup.append('circle')
        .attr('class', 'background-icon')
        .attr('cx', this.x)
        .attr('cy', this.y)
        .attr('r', this.radius)
        .attr(Node.dataIndex, this.index);
    }

    if (this.name != null) {
      nodeGroup.append('title').text(this.name);
    }

    this.addMouseEventToNode(graph, element);

    if (!this.isNaturalPerson && !this.isManyPeople) {
      nodeGroup.append('path')
        .attr('d', Node.companyPath)
        .attr('class', 'company-icon no-pointer-events')
        .attr('transform', 'translate(' + (this.x - 24) + ', ' + (this.y - 24) + ') ' +
          'scale(' + Node.companyScale + ')');
    } else if (this.isManyPeople) {
      nodeGroup.append('path')
        .attr('d', Node.manyPeoplePath)
        .attr('class', 'person-icon no-pointer-events')
        .attr('transform', 'translate(' + (this.x - 24) + ', ' + (this.y - 28) + ') ' +
          'scale(' + Node.manyPeoplePersonScale + ')');
    } else {
      nodeGroup.append('path')
        .attr('d', Node.personPath)
        .attr('class', 'person-icon no-pointer-events')
        .attr('transform', (!this.isMasked && this.isYoungPerson) ?
          'translate(' + (this.x - 7) + ', ' + (this.y - 17) + ') scale(' + Node.childPersonScale + ')' :
          'translate(' + (this.x - 10) + ', ' + (this.y - 23) + ') scale(' + Node.adultPersonScale + ')');

      nodeGroup.append('text')
        .attr('class', 'person-label no-pointer-events')
        .attr('x', this.x)
        .attr('y', this.y + 2)
        .attr('font-size', 14)
        .attr(Node.textAnchor, 'middle')
        .text(this.label);
    }
  }

  public drawTextBox(graph: Selection<any, any, any, any>): void {
    if (this.isCompany) {
      const relations = this.getRelations();
      let relationTextGroup = graph.append('g');

      relationTextGroup = relationTextGroup.append('text')
        .attr('class', 'person-information no-pointer-events')
        .attr(Node.dataIndex, this.index)
        .attr('x', this.x)
        .attr('y', this.y - this.radius - Node.personLineHeight * relations.length - 4);

      relations.forEach((relation: string): void => {
        relationTextGroup.append('svg:tspan')
          .attr('class', 'person-company no-pointer-events')
          .attr('x', this.x)
          .attr('dy', Node.personLineHeight)
          .attr(Node.textAnchor, 'middle')
          .text(relation);
      });
    }

    let textGroup = graph.append('g');

    textGroup = textGroup.append('text')
      .attr('class', 'person-information no-pointer-events')
      .attr(Node.dataIndex, this.index)
      .attr('x', this.x)
      .attr('y', this.y + this.radius);

    textGroup.append('svg:tspan')
      .attr('class', 'person-name no-pointer-events')
      .attr('x', this.x)
      .attr('dy', Node.personLineHeight)
      .attr(Node.textAnchor, 'middle')
      .text(this.getName());

    textGroup.append('svg:tspan')
      .attr('class', 'no-pointer-events')
      .attr('x', this.x)
      .attr('dy', Node.personLineHeight)
      .attr(Node.textAnchor, 'middle')
      .text(this.subjectNr);
  }

  private addMouseEventToNode(graph: Selection<any, any, any, any>, element): void {
    element.on('mouseover', () => {
      graph.select('#' + this.id + '-hoverbox').classed(Node.personHighlight, true);
      graph.select('#' + this.id + '-text').classed(Node.personHighlight, true);
      graph.selectAll('.' + this.id + '-link').classed('link-highlight', true);
    });

    element.on('mouseout', () => {
      graph.select('#' + this.id + '-hoverbox').classed(Node.personHighlight, false);
      graph.select('#' + this.id + '-text').classed(Node.personHighlight, false);
      graph.selectAll('.' + this.id + '-link').classed('link-highlight', false);
    });

    if (!this.isMasked && !this.isSubject && !this.isManyPeople) {
      element.on('click', () => {
        // widget.analyticsService.trackEvent('Select relation in social graph', node.subjectNr, null);
        // window.open(this.urlService.getModifiedUrl({ 'subjectNr': node.subjectNr }), '_blank');
      });
    }
  }

  private determineRank(): void {
    if (this.isSubject) {
      this.rank = 0;
    } else if (this.isFiscalPartner) {
      this.rank = 1;
    } else if (this.isMarriedPartner) {
      this.rank = 2;
    } else if (this.isLivingPartner) {
      this.rank = 3;
    } else if (this.isChild && this.isPartnersChild) {
      this.rank = 4;
    } else if (this.isChild) {
      this.rank = 5;
    } else if (this.isPartnersChild) {
      this.rank = 6;
    } else if (this.isParent) {
      this.rank = 7;
    } else if (this.isCompany) {
      this.rank = 8;
    } else if (this.isExPartner) {
      this.rank = 9;
    } else {
      this.rank = 10;
    }
  }
}
