import { Component } from '@angular/core';

@Component({
    selector: 'i-invisible',
    templateUrl: './invisible.component.html'
})
export class InvisibleComponent {

}
