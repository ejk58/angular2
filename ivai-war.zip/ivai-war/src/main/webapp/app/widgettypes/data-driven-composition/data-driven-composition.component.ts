import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'i-data-composition',
  templateUrl: './data-driven-composition.component.html',
  styleUrls: ['./data-driven-composition.component.scss']
})
export class DataDrivenCompositionComponent implements OnInit {
  @Input() side: string;
  @Input() widgetId: string;
  @Input() widget: any;
  @Input() filter: any;
  @Output() hasData: EventEmitter<any> = new EventEmitter<any>();

  public widgets: any[];
  public hideInnerTitleAndDescription: boolean = true;

  private emptyWidgets: string[];

  ngOnInit() {
    this.emptyWidgets = [];
    this.widgets = this.widget.data;

    this.hideInnerTitleAndDescription = !this.widget.options.hideTitle;

    if (!this.widget.data || this.widget.data.length === 0) {
      this.hasData.emit({id: this.widgetId, hasData: false});
    }
  }

  changeDataStatus(e) {
    if (!e.hasData) {
      this.emptyWidgets.push(e.id);
      if (this.emptyWidgets.length === this.widgets.length) {
        this.hasData.emit({id: this.widgetId, hasData: false});
      }
    }
  }
}
