import {LegendItem} from './legend-item';

export class LegendGroup {
  public group: string;
  public items: LegendItem[] = [];

  constructor(group: string, items?: LegendItem[]) {
    this.group = group;
    this.items = items;
  }
}
