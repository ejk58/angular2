export class LegendItem {
  public row: any;
  public column: any;
  public active: boolean = true;

  constructor(row: any, column: any) {
    this.row = row;
    this.column = column;
  }
}
