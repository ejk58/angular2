import { Component, Input, OnInit, AfterViewInit, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { D3Service, D3, Selection } from 'd3-ng2-service';

@Component({
  selector: 'i-compliance-graph',
  templateUrl: './compliance-graph.component.html',
  styleUrls: ['./compliance-graph.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class ComplianceGraphComponent implements OnInit, AfterViewInit {

  @Input() widgetId: string;
  @Input() side: string;
  @Input() widget: any;

  @ViewChild('complianceGraphCanvas') canvasElementRef: ElementRef;

  public size: {width: number; height: number};
  public subjectIsPerson: boolean;

  private readonly d3: D3;
  private canvas: Selection<any, any, any, any>;
  private graph: Selection<any, any, any, any>;

  private readonly width: number = 0;
  private readonly height: number = 0;

  constructor(private readonly d3Service: D3Service) {
    this.d3 = d3Service.getD3();
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    if (this.widget.data.length > 0) {
      this.drawBasicCanvas();
    }
  }

  private drawBasicCanvas(): void {
    this.canvas = this.d3.select(this.canvasElementRef.nativeElement)
      .append('svg')
      .attr('preserveAspectRatio', 'xMinYMin meet')
      .attr('viewBox', '0 0 ' + this.width + ' ' + this.height)
      .classed('compliance-graph-svg', true);

    this.graph = this.canvas
      .append('g');
  }
}
