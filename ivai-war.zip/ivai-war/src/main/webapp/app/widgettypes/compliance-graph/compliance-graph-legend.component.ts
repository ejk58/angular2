import { Component, Input, ViewEncapsulation } from '@angular/core';
import { TrackingService } from '../../services/tracking.service';

@Component({
  selector: 'i-compliance-graph-legend',
  templateUrl: './compliance-graph-legend.component.html',
  styleUrls: ['./compliance-graph-legend.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ComplianceGraphLegendComponent {

  @Input() widgetId: string;
  @Input() side: string;

  public visible: boolean;

  constructor(private readonly trackingService: TrackingService) {
    this.visible = false;
  }

  public getButtonArrow() {
    return this.visible ? 'fa fa-fw bd_keyboard_arrow_up' : 'fa fa-fw bd_keyboard_arrow_down';
  }

  public toggleLegend(event: any) {
    this.visible = !this.visible;

    if (this.visible) {
      this.trackingService.trackEvent('klik',
        'Klik legenda open:' + this.side + '/widget:' + this.widgetId,
        null, null);
    }
  }
}
