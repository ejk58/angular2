import {Component, Input, ViewEncapsulation, OnInit} from '@angular/core';
import {Store} from '@ngrx/store';

import * as fromSelectors from '../../store/selectors';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {SplitViewState} from '../../services/split-view-state.service';
import {TrackingService} from '../../services/tracking.service';
import {Subject} from '../../classes/subject';
import {SplitWidth} from '../../classes/split-width';

@Component({
  selector: 'i-relation-graph-legend',
  templateUrl: './relation-graph-legend.component.html',
  styleUrls: ['./relation-graph-legend.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class RelationGraphLegendComponent implements OnInit {

  private static readonly SidePanelWidth: number = 250;

  @Input() widgetId: string;
  @Input() side: string;
  @Input() subjectIsPerson: boolean;
  @Input() entity: {entityNr: number; entityName: string, page: string};
  @Input() address: {address: string, city: string};

  public subject: Subject;
  public splitWidth: SplitWidth = SplitWidth.default;
  public breakpointWidth: number;
  public visible: boolean;
  public sidePanelVisible: boolean = true;
  public addressAvailable: boolean;
  public entityAvailable: boolean;
  public entityLinkAvailable: boolean;

  constructor(private readonly store: Store<any>,
              private readonly pageNavigationUtilService: PageNavigationUtilService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService) {

    this.visible = false;
  }

  ngOnInit(): void {
    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedSubject');

    this.store.select(fromSelectors[indicatedSelectedSubjectSelector]).subscribe(activeSubject => {
      this.subject = activeSubject;
    });

    this.splitViewState.listenSizes().subscribe(splitWidth => this.splitWidth = splitWidth != null ? splitWidth : SplitWidth.default);

    this.breakpointWidth = this.splitViewState.breakpointResponsive + RelationGraphLegendComponent.SidePanelWidth;
    this.addressAvailable = this.address != null && (this.address.address != null || this.address.city != null);
    this.entityAvailable = this.entity != null && (this.entity.entityName != null || this.entity.entityNr != null);
    this.entityLinkAvailable = this.entity != null && this.entity.page != null && this.entity.entityNr != null;
  }

  public getButtonArrow(): string {
    return this.visible ? 'fa fa-fw bd_keyboard_arrow_up' : 'fa fa-fw bd_keyboard_arrow_down';
  }

  public toggleLegend(event: any): void {
    this.visible = !this.visible;

    if (this.visible) {
      this.trackingService.trackEvent('klik',
        'Klik legenda open:' + this.side + '/widget:' + this.widgetId,
        null, null);
    }
  }

  public toggleSidePanel(): void {
    this.sidePanelVisible = !this.sidePanelVisible;
  }

  public clickEntityLink(): void {
    if (this.entityLinkAvailable) {
      const model = {entityNr: this.entity.entityNr};
      this.pageNavigationUtilService.navigate(this.side, 'right', this.entity.page, model, null);
    }
  }
}
