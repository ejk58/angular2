export enum NodeBehaviour {
  node = 1,
  group = 2
}
