export enum LinkDirection {
  sameTarget = 0,
  levelDown = 1,
  levelUp = 2,
  sameLevel = 3
}
