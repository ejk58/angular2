import { Node } from './node';

export interface GraphBuilder {
  build(nodes: Node[]): Node[][];
}
