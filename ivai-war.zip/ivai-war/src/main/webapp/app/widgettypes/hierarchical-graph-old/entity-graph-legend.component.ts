import { Component, Input, Output, OnInit, ViewEncapsulation, EventEmitter } from '@angular/core';

import { D3Service, D3 } from 'd3-ng2-service';

import { SplitWidth } from '../../classes/split-width';
import { Node } from './node';
import { TrackingService } from '../../services/tracking.service';
import { SplitViewState } from '../../services/split-view-state.service';

@Component({
  selector: 'i-entity-graph-legend',
  templateUrl: './entity-graph-legend.component.html',
  styleUrls: ['./entity-graph-legend.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class EntityGraphLegendComponent implements OnInit {

  private static readonly SidePanelWidth: number = 500;

  @Input() widgetId: string;
  @Input() side: string;
  @Input() subject: Node;

  @Output() filterChange = new EventEmitter<any>();

  public aandeelhouder: boolean = true;
  public aandeelhouderPercentage: boolean = true;
  public bestuurder: boolean = false;
  public relatie2deGraad: boolean = false;
  public visible: boolean;
  public sidePanelVisible: boolean = true;
  public splitWidth: SplitWidth = SplitWidth.default;
  public breakpointWidth: number;

  private readonly d3: D3;

  constructor(private readonly d3Service: D3Service,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService) {
    this.d3 = d3Service.getD3();
  }

  ngOnInit() {
    this.splitViewState.listenSizes().subscribe(splitWidth => {
      this.splitWidth = splitWidth != null ? splitWidth : SplitWidth.default;
    });

    this.breakpointWidth = this.splitViewState.breakpointResponsive + EntityGraphLegendComponent.SidePanelWidth;
  }

  public getButtonArrow(): string {
    return this.visible ? 'fa fa-fw bd_keyboard_arrow_up' : 'fa fa-fw bd_keyboard_arrow_down';
  }

  public getSubjectName(): string {
    return this.subject ? this.subject.name : '';
  }

  public getSubjectIcon(): string {
    return this.subject ? this.subject.getIcon() : Node.iconUnknown;
  }

  public toggleLegend(event: any): void {
    this.visible = !this.visible;

    if (this.visible) {
      this.trackingService.trackEvent('klik',
        'Klik legenda open:' + this.side + '/widget:' + this.widgetId,
        null, null);
    }
  }

  public toggleSidePanel(): void {
    this.sidePanelVisible = !this.sidePanelVisible;
  }

  public toggleFilter(name: string): void {
    this[name] = !this[name];

    this.filterChange.emit({
      'shareholderPercentage': this.aandeelhouderPercentage,
      'shareholderLink': this.aandeelhouder,
      'managerLink': this.bestuurder,
      'familyLink': this.relatie2deGraad
    });
  }
}
