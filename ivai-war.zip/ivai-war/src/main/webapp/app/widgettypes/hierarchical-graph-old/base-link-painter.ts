import { Selection } from 'd3-ng2-service';
import { LinkType } from './link-type';
import { LinkDirection } from './link-direction';
import { Link } from './link';
import { LinkPainter } from './link-painter';
import { NodePainter } from './node-painter';
import { BaseNodePainter } from './base-node-painter';

export class BaseLinkPainter implements LinkPainter {

  public static readonly linkHeight = 80;
  public static readonly linkRadius: number = 40;
  public static readonly linkCrossingRadius: number = 25;
  public static readonly percentageRadius: number = 10;
  public static readonly percentageDefaultDelta: number = 0.50;
  public static readonly percentageMinDelta: number = 0.15;
  public static readonly percentageMaxDelta: number = 0.85;

  constructor(private readonly loopLinkShift: number,
              private readonly nodePainter: NodePainter) {

    this.loopLinkShift = loopLinkShift;
  }

  public getXStartCoordinate(link: Link): number {
    return this.nodePainter.getXCoordinate(link.node) + (link.isLoop ? this.loopLinkShift : 0);
  }

  public getYStartCoordinate(link: Link): number {
    return this.nodePainter.getYCoordinate(link.node);
  }

  public getXEndCoordinate(link: Link): number {
    return this.nodePainter.getXCoordinate(link.otherNode) + (link.isLoop ? this.loopLinkShift : 0);
  }

  public getYEndCoordinate(link: Link): number {
    return this.nodePainter.getYCoordinate(link.otherNode);
  }

  public drawLink(graph: Selection<any, any, any, any>, link: Link): void {
    if (link.visible) {
      const linkGroup = this.createLinkGroup(graph, link);
      this.drawLine(linkGroup, link);
    }
  }

  public drawPercentage(graph: Selection<any, any, any, any>, link: Link): void {
    if (link.visible && (link.hasType(LinkType.Aandeelhouder) || link.hasType(LinkType.HeeftAandeelhouder))) {
      const linkGroup = this.createLinkGroup(graph, link);
      this.drawPercentageCircle(linkGroup, link);
    }
  }

  private createLinkGroup(graph: Selection<any, any, any, any>, link: Link): Selection<any, any, any, any> {
    return graph.append('g')
      .attr('class', link.classes.join(' '));
  }

  private drawLine(linkGroup: Selection<any, any, any, any>, link: Link): void {
    const x1 = this.getXStartCoordinate(link);
    const y1 = this.getYStartCoordinate(link);
    const x2 = this.getXEndCoordinate(link);
    const y2 = this.getYEndCoordinate(link);

    link.types.forEach((type) => {
      if (link.direction !== LinkDirection.sameLevel) {
        linkGroup.append('line')
          .attr('x1', x1)
          .attr('y1', y1 + BaseNodePainter.nodeHeight)
          .attr('x2', x2)
          .attr('y2', y2)
          .attr('class', 'link-line link-relationtype-' + type);
      }

      if (link.direction === LinkDirection.sameLevel && (type === LinkType.FiscaalPartner || type === LinkType.VoorlopigFiscaalPartner)) {
        linkGroup.append('line')
          .attr('x1', x1)
          .attr('y1', y1 + BaseNodePainter.imageTopMargin + BaseNodePainter.imageRadius)
          .attr('x2', x2)
          .attr('y2', y2 + BaseNodePainter.imageTopMargin + BaseNodePainter.imageRadius)
          .attr('class', 'link-line link-fiscal-partner link-relationtype-' + type);
      }

      if (link.direction === LinkDirection.sameLevel && type !== LinkType.FiscaalPartner && type !== LinkType.VoorlopigFiscaalPartner) {
        const indexDelta = Math.abs(link.otherNode.index - link.node.index);
        linkGroup.append('path')
          .attr('d', 'M' + x1 + ' ' + (y1 + BaseNodePainter.nodeHeight) +
            'Q' + ((x1 + x2) / 2) + ' ' + (y2 + BaseLinkPainter.linkRadius * 4 + indexDelta * 10) +
            ' ' + x2 + ' ' + (y2 + BaseNodePainter.nodeHeight))
          .attr('class', 'link-line link-relationtype-' + type);
      }
    });
  }

  private drawPercentageCircle(linkGroup: Selection<any, any, any, any>, link: Link): void {
    if (link.hasType(LinkType.Aandeelhouder) || link.hasType(LinkType.HeeftAandeelhouder)) {
      const delta = this.calculatePercentageDelta(link);
      const x = this.calculateDeltaX(link, delta);
      const y = this.calculateDeltaY(link, delta);

      const percentageGroup = linkGroup
        .append('g')
        .attr('class', 'link-percentage percentage');
      percentageGroup.append('circle')
        .attr('r', BaseLinkPainter.percentageRadius)
        .attr('cx', x)
        .attr('cy', y)
        .attr('class', 'percentage-circle');
      percentageGroup.append('text')
        .attr('x', x)
        .attr('y', y + 3)
        .attr('text-anchor', 'middle')
        .attr('class', 'percentage-text')
        .attr('fill', '#b4b4b4')
        .text(link.percentage ? link.percentage : 'NB');
    }
  }

  private calculatePercentageDelta(link: Link): number {
    const x1 = this.getXStartCoordinate(link);
    const y1 = this.getYStartCoordinate(link);
    const x2 = this.getXEndCoordinate(link);
    const y2 = this.getYEndCoordinate(link);
    let delta = BaseLinkPainter.percentageDefaultDelta;

    if (this.detectCrossingLinks(link, delta)) {
      const linkLength = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - (y1 + BaseNodePainter.nodeHeight), 2));
      const deltaStep =  BaseLinkPainter.percentageRadius / linkLength;

      delta = BaseLinkPainter.percentageMinDelta;
      while (delta < BaseLinkPainter.percentageMaxDelta && this.detectCrossingLinks(link, delta)) {
        delta = Math.max(delta + deltaStep, BaseLinkPainter.percentageMaxDelta);
      }
    }

    return delta;
  }

  private detectCrossingLinks(link: Link, delta: number): boolean {
    const x = this.calculateDeltaX(link, delta);
    const y = this.calculateDeltaY(link, delta);

    for (let index = 0; index < link.possibleCrossingLinks.length; index++) {
      const crossingLink = link.possibleCrossingLinks[index];
      const crossingLinkStartpointY = this.getYStartCoordinate(crossingLink) + BaseNodePainter.nodeHeight;
      const crossingDelta = (y - crossingLinkStartpointY) / (this.getYEndCoordinate(crossingLink) - crossingLinkStartpointY);
      const crossingLinkX = this.calculateDeltaX(crossingLink, crossingDelta);

      if (Math.abs(x - crossingLinkX) < BaseLinkPainter.linkCrossingRadius) {
        return true;
      }
    }

    return false;
  }

  private calculateDeltaX(link: Link, delta: number) {
    const x1 = this.getXStartCoordinate(link);
    const x2 = this.getXEndCoordinate(link);

    return x1 + Math.round((x2 - x1) * delta);
  }

  private calculateDeltaY(link: Link, delta: number) {
    const y1 = this.getYStartCoordinate(link);
    const y2 = this.getYEndCoordinate(link);

    return y1 + BaseNodePainter.nodeHeight + Math.round((y2 - (y1 + BaseNodePainter.nodeHeight)) * delta);
  }
}
