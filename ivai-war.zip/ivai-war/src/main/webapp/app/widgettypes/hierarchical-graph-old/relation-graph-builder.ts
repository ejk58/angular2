import { GraphBuilder } from './graph-builder';
import { BaseGraphBuilder } from './base-graph-builder';
import { Node } from './node';

export class RelationGraphBuilder extends BaseGraphBuilder implements GraphBuilder {

  private static readonly optimizationThreshold = 500;

  private static readonly longHorizontalDistanceScoreModifier: number = 1000;
  private static readonly longVerticalDistanceScoreModifier: number = 1;
  private static readonly crossedLinksScoreWeight: number = 25;
  private static readonly crossedNodesScoreWeight: number = 200;

  public build(nodes: Node[]): Node[][] {
    let grid: Node[][];

    if (nodes && nodes.length > 0) {
      nodes = this.prepareNodesForGrid(nodes);
      grid = this.buildGrid(nodes);
      grid = this.improveGrid(grid, nodes);
    }

    return grid;
  }

  protected buildGrid(nodeList: Node[]): Node[][] {
    let grid: Node[][] = this.buildEmptyGrid(nodeList);

    grid = this.fillGridWithDividerSpaces(grid);
    grid = this.fillGridWithRelationNodes(grid, nodeList);
    grid = this.fillGridWithSpaces(grid, 3);
    grid = this.linkNodesToGrid(grid);

    return grid;
  }

  private improveGrid(grid: Node[][], nodes: Node[]): Node[][] {
    let newPenalty = this.calculatePenalty(grid, nodes);
    let penalty = newPenalty + 1;
    let count = 0;

    if (nodes.length <= RelationGraphBuilder.optimizationThreshold) {
      while (count < 20 && newPenalty < penalty) {
        penalty = newPenalty;
        newPenalty = this.rearrangeNodesInGrid(grid, nodes);
        count++;
      }
    }

    grid = this.trimEmptyColumnsFromGrid(grid);
    grid = this.linkNodesToGrid(grid);

    return grid;
  }

  private fillGridWithDividerSpaces(grid: Node[][]): Node[][] {
    grid.forEach(gridRow => gridRow.push(null));

    return grid;
  }

  private fillGridWithRelationNodes(grid: Node[][], nodeList: Node[]): Node[][] {
    nodeList.forEach(node => {
      if (node.isPerson()) {
        grid[node.level].unshift(node);
      } else {
        grid[node.level].push(node);
      }
    });

    return grid;
  }

  private rearrangeNodesInGrid(grid: Node[][], nodeList: Node[]): number {
    let level, index, subIndex;
    let newPenalty;
    const maxLevel = grid.length;
    const maxRowSize = grid[0].length;
    let penalty = this.calculatePenalty(grid, nodeList);

    for (level = 0; level < maxLevel; level++) {
      const personDivider = this.findDivider(grid[level], true);
      for (index = 0; index < personDivider; index++) {
        for (subIndex = 0; subIndex < personDivider; subIndex++) {
          if (subIndex !== index) {
            this.shiftNodesInGrid(grid, level, index, subIndex);
            newPenalty = this.calculatePenalty(grid, nodeList);

            if (newPenalty <= penalty) {
              penalty = newPenalty;
            } else {
              this.shiftNodesInGrid(grid, level, subIndex, index);
            }
          }
        }
      }

      const businessDivider = this.findDivider(grid[level], false);
      for (index = businessDivider; index < maxRowSize; index++) {
        for (subIndex = businessDivider; subIndex < maxRowSize; subIndex++) {
          if (subIndex !== index) {
            this.shiftNodesInGrid(grid, level, index, subIndex);
            newPenalty = this.calculatePenalty(grid, nodeList);

            if (newPenalty <= penalty) {
              penalty = newPenalty;
            } else {
              this.shiftNodesInGrid(grid, level, subIndex, index);
            }
          }
        }
      }
    }

    return penalty;
  }

  private calculatePenalty(grid: Node[][], nodes: Node[]): number {
    let penalty = 0;

    for (let index = 0; index < nodes.length; index++) {
      const node = nodes[index];
      for (let childIndex = 0; childIndex < node.childLinks.length; childIndex++) {
        const relation = node.childLinks[childIndex];
        penalty = penalty +
          this.calculateLinkDistancePenalty(relation, RelationGraphBuilder.longVerticalDistanceScoreModifier) +
          this.calculateCrossedLinksPenalty(relation, RelationGraphBuilder.crossedLinksScoreWeight) +
          this.calculateLongVerticalLinksPenalty(relation, grid, RelationGraphBuilder.crossedNodesScoreWeight);
      }

      for (let siblingIndex = 0; siblingIndex < node.sameLevelLinks.length; siblingIndex++) {
        const relation = node.sameLevelLinks[siblingIndex];
        penalty = penalty +
          this.calculateLinkDistancePenalty(relation, RelationGraphBuilder.longHorizontalDistanceScoreModifier);
      }
    }

    return penalty;
  }

  private findDivider(gridRow: Node[], personSide: boolean): number {
    let lastPersonIndex = -1;

    for (let index = 0; index < gridRow.length; index++) {
      const node = gridRow[index];

      if (node != null) {
        if (node.isPerson()) {
          lastPersonIndex = index;
        } else {
          return personSide ? index - 1 : (lastPersonIndex + 2);
        }
      }
    }

    return personSide ? gridRow.length : (lastPersonIndex + 2);
  }
}
