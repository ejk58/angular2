import {Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation} from '@angular/core';
import {Group} from './group';

type Item = {
  label: string,
  value: string
};

type SelectList = {
  groupType: number,
  selectedItems: string[],
  defaultLabel?: string,
  disabled?: boolean,
  items?: Item[]
};

@Component({
  selector: 'i-entity-graph-filter',
  templateUrl: './entity-graph-filter.component.html',
  styleUrls: ['./entity-graph-filter.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EntityGraphFilterComponent implements OnInit {
  @Input() groups: Group[];
  @Input() maxNumberOfSelections: number;
  @Output() selectionChange = new EventEmitter<SelectList>();

  public selectLists: SelectList[] = [];
  public currentSelectedGroup: number;

  ngOnInit() {
    this.groups.forEach((group) => {
      let isDisabled: boolean = false;
      if (!this.isEntity(group.type) && (!group.nodes || group.nodes.length < 1)) {
        isDisabled = true;
      }
      const items: Item[] = [];
      const selectedItems: string[] = [];
      group.nodes.forEach((node) => {
        const item: Item = {label: node.name, value: node.id};
        items.push(item);
        if (group.nodes.length <= this.maxNumberOfSelections) {
          selectedItems.push(item.value);
        }
      });

      this.selectLists.push({
        groupType: group.type,
        defaultLabel: group.name,
        disabled: isDisabled,
        items: items,
        selectedItems: selectedItems
      });
    });
  }

  public emitSelectedValues(selectList: SelectList): void {
    if (!selectList.disabled) {
      this.currentSelectedGroup = selectList.groupType;
      this.selectionChange.emit({
        groupType: selectList.groupType,
        selectedItems: selectList.selectedItems
      });
    }
  }

  // group.type === null or 0 means 'Entiteit'
  public isEntity(groupType: number): boolean {
    return groupType === null || groupType === 0;
  }
}


