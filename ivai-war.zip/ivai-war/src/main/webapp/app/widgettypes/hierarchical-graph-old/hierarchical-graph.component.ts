import { Component, Input, OnInit, AfterViewInit, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { D3Service, D3, Selection } from 'd3-ng2-service';
import { Store } from '@ngrx/store';
import * as fromSelectors from '../../store/selectors';
import { PageNavigationUtilService } from '../../commons/page-navigation-util.service';
import { SvgIconProvider } from '../../commons/svg-icon-provider';

import { Group } from './group';
import { Node } from './node';
import { LinkType } from './link-type';
import { Link } from './link';
import { GraphBuilder } from './graph-builder';
import { EntityGraphBuilder } from './entity-graph-builder';
import { RelationGraphBuilder } from './relation-graph-builder';
import { NodePainter } from './node-painter';
import { BaseNodePainter } from './base-node-painter';
import { LinkPainter } from './link-painter';
import { BaseLinkPainter } from './base-link-painter';
import { BoxPainter } from './box-painter';
import { BaseBoxPainter } from './base-box-painter';
import {NodeType} from './node-type';

@Component({
  selector: 'i-hierarchical-graph',
  templateUrl: './hierarchical-graph.component.html',
  styleUrls: ['./hierarchical-graph.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class HierarchicalGraphComponent implements OnInit, AfterViewInit {

  private static readonly entityGraphType = 'entity';
  private static readonly relationGraphType = 'relation';

  private static readonly defaultMaxAllowedRows: number = 500;
  private static readonly aspectRatio: number = 0.5;

  private static readonly graphMinimumWidth = BaseBoxPainter.boxSpace * 2;
  private static readonly graphTopMargin = 100;
  private static readonly graphBottomMargin = 100;
  private static readonly graphLeftMargin = 50;
  private static readonly graphRightMargin = 50;
  private static readonly graphHorizontalGap = BaseNodePainter.nodeWidth;
  private static readonly graphVerticalGap = BaseNodePainter.nodeHeight + BaseLinkPainter.linkHeight;
  private static readonly graphFiscalPartnerShift = Math.floor(BaseNodePainter.nodeWidth / 4);
  private static readonly graphLoopLinkShift = 4;

  private static readonly linkRelationType = '.link-relationtype-';
  private static readonly groupFilter = 'group-filter';

  @Input() widgetId: string;
  @Input() side: string;
  @Input() widget: any;

  @ViewChild('hierarchicalGraphCanvas') canvasElementRef: ElementRef;

  public zoomCanvas: Selection<any, any, any, any>;
  public zoomElement: Selection<any, any, any, any>;
  public size: {width: number; height: number};
  public subject: Node = null;
  public home: {x: number, y: number};
  public maxAllowedRows: number = HierarchicalGraphComponent.defaultMaxAllowedRows;
  public hasTooManyRows: boolean = false;
  public hasLoops: boolean = false;
  public hasUnconnectedNodes: boolean = false;
  public graphType: string;
  public entity: {entityNr: string; entityName: string, page: string};
  public address: {address: string, city: string};

  private readonly d3: D3;
  private canvas: Selection<any, any, any, any>;
  private graph: Selection<any, any, any, any>;

  private graphBuilder: GraphBuilder;
  private nodePainter: NodePainter;
  private linkPainter: LinkPainter;
  private boxPainter: BoxPainter;

  private nodes: Node[];
  private gridNodes: Node[];
  private links: Link[];
  private groups: Group[];
  private grid: Node[][];

  private maxLevel: number;
  private maxRowSize: number;
  private width: number;
  private height: number;
  private leftMargin: number;
  private profilePage: string;
  private relationPage: string;
  private entityPage: string;

  constructor(private readonly d3Service: D3Service,
      private readonly store: Store<any>,
      private readonly pageNavigationUtilService: PageNavigationUtilService,
      private readonly svgIconProvider: SvgIconProvider) {

    this.d3 = d3Service.getD3();
  }

  ngOnInit() {
    this.store.select(fromSelectors.getSystemHierarchicalGraphMaxRows).subscribe(configurationData => {
      this.maxAllowedRows = configurationData;
    });

    this.initializeVariables();

    if (this.widget.data.length > 0 && !this.hasTooManyRows) {
      this.prepareNodeStructure();
      this.buildGrid();
    }
  }

  ngAfterViewInit() {
    if (this.widget.data.length > 0 && !this.hasTooManyRows) {
      this.drawGraph();
    }
  }

  public changeLinkVisiblity(graphFilter: any): void {
    const elementStyleList = [
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.FiscaalPartner, key: 'opacity', value: graphFilter.familyLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.VoorlopigFiscaalPartner, key: 'opacity', value: graphFilter.familyLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Ouder, key: 'opacity', value: graphFilter.familyLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Kind, key: 'opacity', value: graphFilter.familyLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.BroerOfZus, key: 'opacity', value: graphFilter.familyLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Bestuurder, key: 'opacity', value: graphFilter.managerLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.FirmantDeelnemer, key: 'opacity', value: graphFilter.shareholderLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Aandeelhouder, key: 'opacity', value: graphFilter.shareholderLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.ObFiscaleEenheid, key: 'opacity', value: graphFilter.shareholderLink ? '1' : '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.VpbFiscaleEenheid, key: 'opacity', value: graphFilter.shareholderLink ? '1' : '0'},
      {selector: '.link-percentage', key: 'opacity', value: graphFilter.shareholderPercentage ? '1' : '0'}];
    this.changeStyles(elementStyleList);
  }

  public changeFilterSelection(selectionFilter: any): void {
    const groupType = selectionFilter.groupType;
    const nodeIds = selectionFilter.selectedItems;

    this.removeAllFilterClasses();
    if (nodeIds != null && nodeIds.length > 0) {
      this.setNewFilterClasses(nodeIds.map((nodeId: string): string => '.group-' + groupType + '-' + nodeId));
    }
  }

  private initializeVariables(): void {
    if (this.widget.options.graphType === 'relation') {
      this.graphType = HierarchicalGraphComponent.relationGraphType;
      this.graphBuilder = new RelationGraphBuilder();
    } else {
      this.graphType = HierarchicalGraphComponent.entityGraphType;
      this.graphBuilder = new EntityGraphBuilder();
    }

    this.hasTooManyRows = (this.widget.data.length > this.maxAllowedRows);
    this.maxLevel = 0;
    this.maxRowSize = 1;

    this.nodes = [];
    this.gridNodes = [];
    this.links = [];
    this.groups = [];
    this.grid = [];

    this.profilePage = this.widget.options.profilePage;
    this.relationPage = this.widget.options.relationPage;
    this.entityPage = this.widget.options.entityPage;
  }

  private prepareNodeStructure(): void {
    this.buildGroups();
    this.buildPresentNodes();
    this.buildUnknownNodes();
    this.buildLinks();

    this.joinLinksToNodes();
    this.joinNodesInGroups();
    this.joinGridNodesAndLinksToGroups();
    this.filterGridNodes();
    this.solveLoops();

    this.findSubject();
  }

  private buildGroups(): void {
    if (this.graphType === HierarchicalGraphComponent.entityGraphType) {
      this.groups.push(new Group(null, 'Entiteit'));
      this.groups.push(new Group(LinkType.ObFiscaleEenheid, 'Fiscale eenheden OB'));
      this.groups.push(new Group(LinkType.VpbFiscaleEenheid, 'Fiscale eenheden VPB'));
    }
  }

  private buildPresentNodes(): void {
    this.widget.data
      .filter(row => row['relatiesoort'] === LinkType.Zelf)
      .forEach(row => this.nodes.push(new Node(row)));
  }

  private buildUnknownNodes(): void {
    this.widget.data
      .filter(row => row['relatiesoort'] !== LinkType.Zelf)
      .map(row => [row['finr'], row['finr_relatie']])
      .reduce((subjectNrs, subjectNr) => subjectNrs.concat(subjectNr), [])
      .filter((subjectNr, index, array) => index === array.indexOf(subjectNr))
      .filter(subjectNr => this.findNode(subjectNr) == null)
      .forEach(subjectNr => this.nodes.push(new Node({finr: subjectNr})));
  }

  private buildLinks(): void {
    this.widget.data
      .filter(row => row['relatiesoort'] !== LinkType.Zelf && row['finr'] !== row['finr_relatie'])
      .forEach(row => this.buildOrMergeLink(row));
  }

  private joinLinksToNodes(): void {
    this.links.forEach(link => {
      link.node.addLink(link);
      link.otherNode.addLink(link);
    });
  }

  private joinNodesInGroups(): void {
    this.nodes
      .forEach(node => this.groups
        .filter(group => group.type != null && node.hasGroupType(group.type))
        .forEach(group => group.nodes.push(node)));
  }

  private filterGridNodes(): void {
    const connectedNodes = this.nodes.filter(node => node.isConnected() || node.isSubject);
    this.hasUnconnectedNodes = this.nodes.length > connectedNodes.length;
    this.gridNodes = connectedNodes.filter(node => node.visible);
  }

  private joinGridNodesAndLinksToGroups(): void {
    this.groups
      .filter(group => group.type != null)
      .forEach(group => group.nodes
        .forEach(node => this.joinGridNodesAndLinksToGroup(node, group)));
  }

  private joinGridNodesAndLinksToGroup(node: Node, group: Group): void {
    const groupClass = 'group-' + group.type + '-' + node.id;
    const groupNodes = node.childLinks.map(link => link.otherNode);

    node.addClass(groupClass);
    node.addClass('group-main-' + group.type + '-' + node.id);

    node.childLinks
      .filter(link => link.hasType(group.type))
      .forEach(link => {
        link.otherNode.addClass(groupClass);

        if (!node.hasGroupBehaviour()) {
          link.addClass(groupClass);

          link.otherNode.childLinks
            .filter(link => groupNodes.some(groupNode => groupNode === link.otherNode))
            .forEach(link => link.addClass(groupClass));
        }
      });
  }

  public solveLoops(): void {
    this.gridNodes.forEach(node =>  this.solveLoopsForNode(node));
  }

  private findSubject(): void {
    this.nodes
      .filter(node => node.isSubject)
      .forEach(node => this.subject = node);

    if (this.subject != null) {
      const subjectRow = this.subject.data;
      this.entity = {entityNr: subjectRow['entiteitnr'], entityName: subjectRow['entiteitnaam'], page: this.entityPage};
      this.address = {address: subjectRow['straat'], city: subjectRow['postcode_plaats']};
    }
  }

  private buildOrMergeLink(row: any): void {
    const node = this.findNode(row['finr']);
    const otherNode = this.findNode(row['finr_relatie']);
    const type = row['relatiesoort'];
    let link = this.findLink(type, node, otherNode);

    if (link == null) {
      link = new Link(this.findNode(row['finr']), this.findNode(row['finr_relatie']), row);
      this.links.push(link);
    } else {
      link.addLink(row);
    }
  }

  private findNode(subjectNr: string): Node {
    for (let index = 0; index < this.nodes.length; index++) {
      if (this.nodes[index].subjectNr === subjectNr) {
        return this.nodes[index];
      }
    }

    return null;
  }

  private findLink(type: number, node: Node, parentNode: Node): Link {
    for (let index = 0; index < this.links.length; index++) {
      if (this.links[index].hasMatchingDirectionAndNodes(type, node, parentNode)) {
        return this.links[index];
      }
    }

    return null;
  }

  public solveLoopsForNode(node: Node): void {
    let loop = this.findLoop([node]);
    while (loop != null) {
      this.hasLoops = true;
      this.removeLoop(loop);
      loop = this.findLoop([node]);
    }
  }

  private findLoop(path: Node[]): Node[] {
    const tailNode = path[path.length - 1];
    const tailLinks = tailNode.childLinks; // .concat(tailNode.sameLevelLinks);

    let loopPath = null;

    let index = 0;
    while (index < tailLinks.length && loopPath == null) {
      const nextNode = tailLinks[index].getOtherNode(tailNode);
      const nextPath = path.concat([nextNode]);
      if (path.some(node => node === nextNode)) {
        loopPath = nextPath.slice(path.indexOf(nextNode));
      }
      index++;
    }

    if (loopPath == null) {
      index = 0;
      while (index < tailLinks.length && loopPath == null) {
        const nextNode = tailLinks[index].getOtherNode(tailNode);
        const nextPath = path.concat([nextNode]);
        loopPath = this.findLoop(nextPath);
        index++;
      }
    }

    return loopPath;
  }

  private removeLoop(loopPath: Node[]): void {
    const loopPathLinks = this.getPathLinks(loopPath);
    const weakestLink = this.findWeakestLink(loopPathLinks);
    weakestLink.setLoop();
  }

  private getPathLinks(path: Node[]): Link[] {
    return path
      .map((node, index, nodes) => node.childLinks // .concat(node.sameLevelLinks)
          .filter(link => index < (nodes.length - 1) && link.hasMatchingNodes(node, nodes[index + 1])))
      .map(links => links.length > 0 ? links[0] : null)
      .filter(link => link != null);
  }

  private findWeakestLink(links: Link[]): Link {
    return links
        .reduce((weakestLink, link) => link.weight < weakestLink.weight ? link : weakestLink, links[0]);
  }

  private buildGrid(): void {
    this.buildGridFromNodes();
    this.updateGridVariables();
    this.findAdjacentFiscalPartners();
  }

  private buildGridFromNodes(): void {
    this.grid = this.graphBuilder.build(this.gridNodes);
  }

  private updateGridVariables(): void {
    this.maxLevel = this.grid.length;
    this.maxRowSize = this.grid[0].length;
  }

  private findAdjacentFiscalPartners() {
    for (let level = 0; level < this.maxLevel; level++) {
      for (let index = 0; index < (this.maxRowSize - 1); index++) {
        const node = this.grid[level][index];
        const nextNode = this.grid[level][index + 1];

        if (node != null && nextNode != null && node.isFiscalPartnerWith(nextNode)) {
          node.fiscalPartnerIndexDelta = 1;
          nextNode.fiscalPartnerIndexDelta = -1;
        }
      }
    }
  }

  private drawGraph(): void {
    this.drawBasicSvg();

    this.createNodePainter();
    this.createLinkPainter();
    this.createBoxPainter();

    this.drawLinks();
    this.drawPercentages();
    this.drawNodes();
    this.drawBoxes();

    this.initializeStyles();
    this.enableZoomAndPan();
  }

  private drawBasicSvg(): void {
    const minimumWidth = (this.maxRowSize - 1) * HierarchicalGraphComponent.graphHorizontalGap + BaseNodePainter.nodeWidth +
        HierarchicalGraphComponent.graphLeftMargin +
        HierarchicalGraphComponent.graphRightMargin;
    const minimumHeight = (this.maxLevel - 1) * HierarchicalGraphComponent.graphVerticalGap + BaseNodePainter.nodeHeight +
        HierarchicalGraphComponent.graphTopMargin +
        HierarchicalGraphComponent.graphBottomMargin;

    this.width = Math.max(minimumWidth, Math.floor(minimumHeight / HierarchicalGraphComponent.aspectRatio), HierarchicalGraphComponent.graphMinimumWidth);
    this.height = Math.max(minimumHeight, Math.floor(minimumWidth * HierarchicalGraphComponent.aspectRatio));
    this.leftMargin = (this.width > minimumWidth) ?
      (HierarchicalGraphComponent.graphLeftMargin + Math.floor((this.width - minimumWidth) / 2)) : HierarchicalGraphComponent.graphLeftMargin;

    this.canvas = this.d3.select(this.canvasElementRef.nativeElement)
      .append('svg')
      .attr('preserveAspectRatio', 'xMinYMin meet')
      .attr('viewBox', '0 0 ' + this.width + ' ' + this.height)
      .classed('hierarchical-svg ' + this.graphType, true);

    this.graph = this.canvas
      .append('g');
  }

  private createNodePainter(): void {
    this.nodePainter = new BaseNodePainter(HierarchicalGraphComponent.graphHorizontalGap, HierarchicalGraphComponent.graphVerticalGap,
        this.leftMargin, HierarchicalGraphComponent.graphTopMargin, HierarchicalGraphComponent.graphFiscalPartnerShift);
  }

  private createLinkPainter(): void {
    this.linkPainter = new BaseLinkPainter(HierarchicalGraphComponent.graphLoopLinkShift, this.nodePainter);
  }

  private createBoxPainter(): void {
    this.boxPainter = new BaseBoxPainter(this.side, this.width, HierarchicalGraphComponent.graphVerticalGap,
        this.profilePage, this.relationPage, this.nodePainter, this.pageNavigationUtilService, this.svgIconProvider);
  }

  private drawLinks(): void {
    this.links.forEach(link => this.linkPainter.drawLink(this.graph, link));
  }

  private drawPercentages(): void {
    this.links.forEach(link => this.linkPainter.drawPercentage(this.graph, link));
  }

  private drawNodes(): void {
    this.gridNodes.forEach(node => this.nodePainter.drawNode(this.graph, node));
  }

  private drawBoxes(): void {
    this.gridNodes
      .filter(node => node.type !== NodeType.MeerDan20PersonenOpAdres)
      .forEach(node => this.boxPainter.drawBox(this.graph, node, ''));

    this.groups.forEach(group => group.nodes
      .filter(node => !node.visible)
      .forEach(node => this.boxPainter.drawBox(this.graph, node, ' group-' + group.type + '-' + node.id)));
  }

  private initializeStyles(): void {
    const relationGraphSpecificVisibility = this.graphType === HierarchicalGraphComponent.relationGraphType ? '1' : '0';

    const styleList = [
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.FiscaalPartner, key: 'opacity', value: relationGraphSpecificVisibility},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.VoorlopigFiscaalPartner, key: 'opacity', value: relationGraphSpecificVisibility},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Kind, key: 'opacity', value: relationGraphSpecificVisibility},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Ouder, key: 'opacity', value: relationGraphSpecificVisibility},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Gehuwd, key: 'opacity', value: '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.GehuwdMet, key: 'opacity', value: '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Samenwonend, key: 'opacity', value: '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.SamenwonendMet, key: 'opacity', value: '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.ExPartnerGehuwd, key: 'opacity', value: '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.ExPartnerSamenwonend, key: 'opacity', value: '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.BroerOfZus, key: 'opacity', value: '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.ZelfdeAdres, key: 'opacity', value: '0'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.MeerRelaties, key: 'opacity', value: '1'},

      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Bestuurder, key: 'opacity', value: relationGraphSpecificVisibility},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.FirmantDeelnemer, key: 'opacity', value: '1'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.Aandeelhouder, key: 'opacity', value: '1'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.ObFiscaleEenheid, key: 'opacity', value: '1'},
      {selector: HierarchicalGraphComponent.linkRelationType + LinkType.VpbFiscaleEenheid, key: 'opacity', value: '1'}];
    this.changeStyles(styleList);
  }

  private enableZoomAndPan(): void {
    setTimeout(() => {
      this.zoomCanvas = this.canvas;
      this.zoomElement = this.graph;
      this.size = {width: this.width, height: this.height};
      this.home = this.subject == null ? null : {'x': this.nodePainter.getXCoordinate(this.subject), 'y': this.nodePainter.getYCoordinate(this.subject) };
    });
  }

  private removeAllFilterClasses(): void {
    const elementClassList = [];

    elementClassList.push({selector: '.group-filter' , name: HierarchicalGraphComponent.groupFilter, present: false});
    for (let index = 0; index < 4; index++) {
      const groupClassName = this.createFilterGroupClassName(index);
      elementClassList.push({selector: '.' + groupClassName, name: groupClassName, present: false});
    }

    this.setClasses(elementClassList);
  }

  private setNewFilterClasses(groupIds: string[]): void {
    const elementClassList = [];

    elementClassList.push({selector: '.node', name: HierarchicalGraphComponent.groupFilter, present: true});
    elementClassList.push({selector: '.link', name: HierarchicalGraphComponent.groupFilter, present: true});

    groupIds.forEach((groupId, index) => {
      const groupClassName = this.createFilterGroupClassName(index);
      elementClassList.push({selector: groupId + '.box', name: HierarchicalGraphComponent.groupFilter, present: true});
      elementClassList.push({selector: groupId, name: groupClassName, present: true});
    });

    this.setClasses(elementClassList);
  }

  private createFilterGroupClassName(index: number): string {
    return (!isNaN(index) && index >= 0) ? ('group-nr' + (index % 4 + 1)) : '';
  }

  private changeStyles(elementStyleList: {selector: string, key: string, value: string}[]): void {
    elementStyleList.forEach(elementStyle => {
      this.d3.select(this.canvasElementRef.nativeElement).selectAll(elementStyle.selector).style(elementStyle.key, elementStyle.value);
    });
  }

  private setClasses(elementClassList: {selector: string, name: string, present: boolean}[]): void {
    elementClassList.forEach(elementClass => {
      this.d3.select(this.canvasElementRef.nativeElement).selectAll(elementClass.selector).classed(elementClass.name, elementClass.present);
    });
  }
}
