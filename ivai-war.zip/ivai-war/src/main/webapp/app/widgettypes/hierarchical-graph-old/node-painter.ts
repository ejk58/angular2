import { Selection } from 'd3-ng2-service';
import { Node } from './node';

export interface NodePainter {
  getXCoordinate(node: Node): number;
  getYCoordinate(node: Node): number;

  drawNode(graph: Selection<any, any, any, any>, node: Node): void;
  addMouseEvents(graph: Selection<any, any, any, any>, nodeGroup: Selection<any, any, any, any>, node: Node): void;
}
