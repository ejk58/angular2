import { GraphBuilder } from './graph-builder';
import { Node } from './node';
import { Link } from './link';

export class BaseGraphBuilder implements GraphBuilder {

  public build(nodes: Node[]): Node[][] {
    let grid: Node[][];

    if (nodes && nodes.length > 0) {
      nodes = this.prepareNodesForGrid(nodes);
      grid = this.buildGrid(nodes);
      grid = this.cleanGrid(grid);
    }

    return grid;
  }

  protected prepareNodesForGrid(nodes: Node[]): Node[] {
    nodes = this.setLevelsForNodes(nodes);
    nodes = this.adjustLevelsForHorizontalRelations(nodes);
    nodes = this.adjustLevelsForNonPersonNodes(nodes);
    nodes = this.determinePossibleCrossingLinks(nodes);

    return nodes;
  }

  protected buildGrid(nodeList: Node[]): Node[][] {
    let grid: Node[][] = this.buildEmptyGrid(nodeList);

    grid = this.fillGridWithNodes(grid, nodeList);
    grid = this.fillGridWithSpaces(grid, 2);
    grid = this.linkNodesToGrid(grid);

    return grid;
  }

  protected cleanGrid(grid: Node[][]): Node[][] {
    grid = this.trimEmptyColumnsFromGrid(grid);
    grid = this.linkNodesToGrid(grid);

    return grid;
  }

  protected setLevelsForNodes(nodes: Node[]): Node[] {
    nodes
      .filter(node => node.level == null)
      .forEach(node => this.determineLevelFromParentNodes(node));

    return nodes;
  }

  protected adjustLevelsForHorizontalRelations(nodes: Node[]): Node[] {
    nodes.forEach((node: Node): void => {
      const level = node.sameLevelLinks
        .map(sameLevelLink => (sameLevelLink.otherNode === node ? sameLevelLink.node : sameLevelLink.otherNode))
        .reduce((level, sameLinkNode) => Math.max(sameLinkNode.level, node.level), node.level);

      if (level > node.level) {
        node.level = level;
        node.childLinks.forEach(childLink => this.determineLevelForChildNodes(childLink.otherNode, level + 1));
      }
    });

    return nodes;
  }

  protected adjustLevelsForNonPersonNodes(nodes: Node[]): Node[] {
    nodes
      .filter(node => !node.isPerson())
      .forEach(node => this.determineLevelFromChildNodes(node));

    return nodes;
  }

  protected determineLevelForChildNodes(node: Node, level: number): void {
    node.level = Math.max(node.level, level);
    node.childLinks.forEach(childLink => this.determineLevelForChildNodes(childLink.otherNode, level + 1));
  }

  protected determineLevelFromParentNodes(node: Node): number {
    if (node.level == null) {
      node.level = node.parentLinks
        .reduce((level, parentLink) => Math.max(level, this.determineLevelFromParentNodes(parentLink.node) + 1), 0);
    }

    return node.level;
  }

  protected determineLevelFromChildNodes(node: Node): number {
    node.level = node.childLinks
      .reduce((level, childLink) => Math.min(level, this.determineLevelFromChildNodes(childLink.otherNode) - 1), node.level);

    return node.level;
  }

  protected buildEmptyGrid(nodes: Node[]): Node[][] {
    const grid: Node[][] = [];
    const maxLevel = this.findMaximumLevelInNodes(nodes);

    for (let level = 0; level < maxLevel; level++) {
      grid.push([]);
    }

    return grid;
  }

  protected linkNodesToGrid(grid: Node[][]): Node[][] {
    grid.forEach((gridRow, level) => {
      for (let index = 0; index < gridRow.length; index++) {
        if (grid[level][index] != null) {
          grid[level][index].index = index;
        }
      }
    });

    return grid;
  }

  protected fillGridWithNodes(grid: Node[][], nodes: Node[]): Node[][] {
    nodes.forEach(node => grid[node.level].push(node));

    return grid;
  }

  protected fillGridWithSpaces(grid: Node[][], extraRowSize: number): Node[][] {
    const maxRowSize = this.findMaximumRowSizeInGrid(grid) + extraRowSize;

    grid.forEach((gridRow, level) => {
      while (grid[level].length < maxRowSize) {
        if ((maxRowSize - grid[level].length) % 2 === 0) {
          grid[level].splice(0, 0, null);
        } else {
          grid[level].splice(grid[level].length, 0, null);
        }
      }
    });

    return grid;
  }

  protected trimEmptyColumnsFromGrid(grid: Node[][]): Node[][] {
    const firstColumnEmpty = this.findEmptyColumn(grid, 0);
    if (firstColumnEmpty) {
      grid.forEach(gridRow => gridRow.shift());
    }

    const lastColumnEmpty = this.findEmptyColumn(grid, grid[0].length - 1);
    if (lastColumnEmpty) {
      grid.forEach(gridRow => gridRow.pop());
    }

    return (firstColumnEmpty || lastColumnEmpty) ? this.trimEmptyColumnsFromGrid(grid) : grid;
  }

  protected determinePossibleCrossingLinks(nodes: Node[]): Node[] {
    nodes.forEach(node => {
      node.childLinks
        .filter(link => link.weight > 0)
        .forEach(link => this.determinePossibleCrossingLinksForLink(nodes, link));
    });

    return nodes;
  }

  protected determinePossibleCrossingLinksForLink(nodes: Node[], link: Link): void {
    const parentNode = link.node;
    const node = link.otherNode;

    nodes
      .filter(crossingNode => crossingNode !== parentNode && crossingNode.level < node.level)
      .map(crossingNode => crossingNode.childLinks)
      .forEach(links => links
          .filter(crossingLink => crossingLink.visible && crossingLink.weight > 0 && crossingLink.otherNode !== node && crossingLink.otherNode.level > parentNode.level)
          .forEach(crossingLink => link.possibleCrossingLinks.push(crossingLink)));
  }

  protected calculateLinkDistancePenalty(link: Link, weight: number): number {
    const parentNode = link.node;
    const node = link.otherNode;
    return Math.abs(node.index - parentNode.index) * link.weight * weight;
  }

  protected calculateCrossedLinksPenalty(link: Link, weight: number): number {
    const node = link.node;
    const relatedNode = link.otherNode;
    let crossedLinksCount = 0;

    for (let index = 0; index < link.possibleCrossingLinks.length; index++) {
      const parentNode = link.possibleCrossingLinks[index].node;
      const childNode = link.possibleCrossingLinks[index].otherNode;

      if ((parentNode.index < node.index) && (childNode.index > relatedNode.index)) {
        crossedLinksCount++;
      } else if ((parentNode.index > node.index) && (childNode.index < relatedNode.index)) {
        crossedLinksCount++;
      }
    }

    return crossedLinksCount * weight;
  }

  protected calculateLongVerticalLinksPenalty(link: Link, grid: Node[][], weight: number): number {
    const node = link.node;
    const relatedNode = link.otherNode;
    let crossedNodesCount = 0;

    for (let level = node.level + 1; level < relatedNode.level; level++) {
      const lineIndex = node.index + (relatedNode.index - node.index) * (level - node.level) / (relatedNode.level - node.level);
      const index = Math.round(lineIndex);

      if ((Math.abs(lineIndex - index) < 0.4) && (grid[level][index] !== null)) {
        crossedNodesCount++;
      }
    }

    return crossedNodesCount * weight;
  }

  protected findMaximumLevelInNodes(nodes: Node[]): number {
    return nodes.reduce((maxLevel: number, node: Node): number => Math.max(maxLevel, node.level + 1), 0);
  }

  protected findMaximumRowSizeInGrid(grid: Node[][]): number {
    return grid
      .map(gridRow => gridRow.length)
      .reduce((maxSize, rowSize) => Math.max(maxSize, rowSize), 0);
  }

  protected findEmptyColumn(grid: Node[][], index: number): boolean {
    return grid.reduce((isEmptyColumn, gridRow) => isEmptyColumn && gridRow[index] == null, true);
  }

  protected swapNodesInGrid(grid: Node[][], level: number, index: number, otherIndex: number): void {
    const node = grid[level][index];
    const otherNode = grid[level][otherIndex];

    grid[level][index] = otherNode;
    grid[level][otherIndex] = node;

    if (node !== null) {
      node.index = otherIndex;
    }

    if (otherNode !== null) {
      otherNode.index = index;
    }
  }

  protected shiftNodesInGrid(grid: Node[][], level: number, startIndex: number, endIndex: number): void {
    const direction = (startIndex < endIndex ? 1 : -1);
    const node = grid[level][startIndex];
    let index = startIndex;

    while (index !== endIndex) {
      const otherNode = grid[level][index + direction];
      grid[level][index] = otherNode;

      if (otherNode !== null) {
        otherNode.index = index;
      }

      index = index + direction;
    }

    grid[level][endIndex] = node;

    if (node !== null) {
      node.index = endIndex;
    }
  }
}
