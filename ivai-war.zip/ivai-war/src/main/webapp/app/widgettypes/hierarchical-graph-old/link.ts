import { LinkType } from './link-type';
import { LinkDirection } from './link-direction';
import { Node } from './node';

export class Link {

  private static readonly linkMap: Map<number, {direction: number, weight: number, visible: boolean}> = new Map([
    [LinkType.Zelf, {'direction': LinkDirection.sameTarget, 'weight': 0, 'visible': true}],
    [LinkType.FiscaalPartner, {'direction': LinkDirection.sameLevel, 'weight': 20, 'visible': true}],
    [LinkType.VoorlopigFiscaalPartner, {'direction': LinkDirection.sameLevel, 'weight': 20, 'visible': true}],
    [LinkType.Kind, {'direction': LinkDirection.levelUp, 'weight': 2, 'visible': true}],
    [LinkType.Ouder, {'direction': LinkDirection.levelDown, 'weight': 2, 'visible': true}],
    [LinkType.Gehuwd, {'direction': LinkDirection.sameLevel, 'weight': 1, 'visible': true}],
    [LinkType.GehuwdMet, {'direction': LinkDirection.sameLevel, 'weight': 1, 'visible': true}],
    [LinkType.Samenwonend, {'direction': LinkDirection.sameLevel, 'weight': 1, 'visible': true}],
    [LinkType.SamenwonendMet, {'direction': LinkDirection.sameLevel, 'weight': 1, 'visible': true}],
    [LinkType.ExPartnerGehuwd, {'direction': LinkDirection.sameLevel, 'weight': 0, 'visible': true}],
    [LinkType.ExPartnerSamenwonend, {'direction': LinkDirection.sameLevel, 'weight': 0, 'visible': true}],
    [LinkType.BroerOfZus, {'direction': LinkDirection.sameLevel, 'weight': 1, 'visible': true}],
    [LinkType.FirmantDeelnemer, {'direction': LinkDirection.levelDown, 'weight': 2, 'visible': true}],
    [LinkType.HeeftFirmantDeelnemer, {'direction': LinkDirection.levelUp, 'weight': 2, 'visible': true}],
    [LinkType.Bestuurder, {'direction': LinkDirection.levelDown, 'weight': 2, 'visible': true}],
    [LinkType.HeeftBestuurder, {'direction': LinkDirection.levelUp, 'weight': 2, 'visible': true}],
    [LinkType.Aandeelhouder, {'direction': LinkDirection.levelDown, 'weight': 2, 'visible': true}],
    [LinkType.HeeftAandeelhouder, {'direction': LinkDirection.levelUp, 'weight': 2, 'visible': true}],
    [LinkType.ObFiscaleEenheid, {'direction': LinkDirection.levelDown, 'weight': 1, 'visible': false}],
    [LinkType.OnderObFiscaleEenheid, {'direction': LinkDirection.levelUp, 'weight': 1, 'visible': false}],
    [LinkType.VpbFiscaleEenheid, {'direction': LinkDirection.levelDown, 'weight': 1, 'visible': false}],
    [LinkType.OnderVpbFiscaleEenheid, {'direction': LinkDirection.levelUp, 'weight': 1, 'visible': false}],
    [LinkType.ZelfdeAdres, {'direction': LinkDirection.sameLevel, 'weight': 0, 'visible': false}],
    [LinkType.HeeftMeerRelaties, {'direction': LinkDirection.levelUp, 'weight': 3, 'visible': true}],
    [LinkType.MeerRelaties, {'direction': LinkDirection.levelDown, 'weight': 3, 'visible': true}],
    [LinkType.OnbekendeRelatie, {'direction': LinkDirection.levelDown, 'weight': 0, 'visible': true}]
  ]);

  public isLoop: boolean;

  public node: Node;
  public otherNode: Node;
  public types: number[];
  public percentage: number;
  public visible: boolean;

  public possibleCrossingLinks: Link[];
  public direction: number;
  public weight: number;
  public classes: string[];

  constructor(node: Node, otherNode: Node, row: any) {
    const type = Link.linkMap.has(row['relatiesoort']) ? row['relatiesoort'] : LinkType.OnbekendeRelatie;
    const percentage = row['perc_betrokkenheid'];
    const direction = Link.linkMap.get(type).direction;
    const weight = Link.linkMap.get(type).weight;

    this.isLoop = false;

    if (direction !== LinkDirection.levelUp) {
      this.node = node;
      this.otherNode = otherNode;
      this.direction = direction;
    } else {
      this.node = otherNode;
      this.otherNode = node;
      this.direction = LinkDirection.levelDown;
    }

    this.types = [type];
    this.percentage = percentage;
    this.visible = Link.linkMap.has(type) && Link.linkMap.get(type).visible && node.visible && otherNode.visible;

    this.possibleCrossingLinks = [];
    this.weight = isNaN(weight) ? 0 : weight;
    this.classes = ['link', 'link-id-' + node.subjectNr, 'link-id-' + otherNode.subjectNr];
  }

  public hasType(type: number): boolean {
    return this.types.some(linkType => linkType === type);
  }

  public hasMatchingDirectionAndNodes(type: number, node: Node, otherNode: Node): boolean {
    const direction = Link.linkMap.has(type) ? Link.linkMap.get(type).direction : LinkDirection.levelDown;
    let matching = false;

    if (direction === LinkDirection.levelDown) {
      matching = (this.node === node && this.otherNode === otherNode);
    } else if (direction === LinkDirection.levelUp) {
      matching = (this.otherNode === node && this.node === otherNode);
    } else if (direction === LinkDirection.sameLevel) {
      matching = (this.otherNode === otherNode && this.node === node) || (this.otherNode === node && this.node === otherNode);
    }

    return matching;
  }

  public hasMatchingNodes(node: Node, otherNode: Node): boolean {
    return (this.otherNode === otherNode && this.node === node) || (this.otherNode === node && this.node === otherNode);
  }

  public isFiscalPartnerLink(): boolean {
    return this.hasType(LinkType.FiscaalPartner) || this.hasType(LinkType.VoorlopigFiscaalPartner);
  }

  public getDirection(): number {
    return this.direction;
  }

  public getOtherNode(node: Node): Node {
    return this.node === node ? this.otherNode : this.node;
  }

  public setLoop(): void {
    if (!this.isLoop) {
      this.isLoop = true;
      this.classes.push('link-loop');
    }

    this.node.hideLoopLink(this);
    this.otherNode.hideLoopLink(this);
  }

  public addPossibleCrossingLink(link: Link): void {
    this.possibleCrossingLinks.push(link);
  }

  public addLink(row: any): void {
    const type = row['relatiesoort'];
    const percentage = row['perc_betrokkenheid'];
    const weight = Link.linkMap.has(type) ? Link.linkMap.get(type).weight : 0;
    const visible = Link.linkMap.has(type) && Link.linkMap.get(type).visible;

    this.types.push(type);
    this.percentage = (this.percentage == null) ? percentage : this.percentage;
    this.weight = this.weight + (isNaN(weight) ? 0 : weight);
    this.visible = this.visible || visible;
  }

  public addClass(newClass: string): void {
    this.classes.push(newClass);
  }
}
