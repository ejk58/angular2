import { Selection } from 'd3-ng2-service';
import { Node } from './node';

export interface BoxPainter {
  getXCoordinate(node: Node): number;
  getYCoordinate(node: Node): number;

  drawBox(graph: Selection<any, any, any, any>, node: Node, boxClass: string): void;
}
