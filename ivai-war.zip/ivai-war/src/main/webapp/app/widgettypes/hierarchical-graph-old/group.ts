import { Node } from './node';

export class Group {

  public type: number;
  public name: string;
  public isEnabled: boolean;
  public nodes: Node[];

  constructor(type: number, name: string) {
    this.type = type;
    this.name = name;
    this.nodes = [];
  }

  public addNode(node: Node): void {
    this.nodes.push(node);
  }
}
