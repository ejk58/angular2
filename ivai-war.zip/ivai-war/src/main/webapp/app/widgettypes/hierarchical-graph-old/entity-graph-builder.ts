import { GraphBuilder } from './graph-builder';
import { BaseGraphBuilder } from './base-graph-builder';
import { Node } from './node';

export class EntityGraphBuilder extends BaseGraphBuilder implements GraphBuilder {

  private static readonly optimizationThreshold = 500;

  private static readonly longHorizontalDistanceScoreModifier = 1;
  private static readonly longVerticalDistanceScoreModifier: number = 1;
  private static readonly crossedLinesScoreWeight: number = 25;
  private static readonly crossedNodesScoreWeight: number = 200;

  public build(nodes: Node[]): Node[][] {
    let grid: Node[][];

    if (nodes && nodes.length > 0) {
      nodes = this.prepareNodesForGrid(nodes);
      grid = this.buildGrid(nodes);
      grid = this.improveGrid(grid, nodes);
      grid = this.cleanGrid(grid);
    }

    return grid;
  }

  private improveGrid(grid: Node[][], nodes: Node[]): Node[][] {
    let newPenalty = this.calculatePenalty(grid, nodes);
    let score = newPenalty + 1;
    let count = 0;

    if (nodes.length <= EntityGraphBuilder.optimizationThreshold) {
      while (count < 20 && newPenalty < score) {
        score = newPenalty;
        newPenalty = this.rearrangeNodesInGrid(grid, nodes);
        count++;
      }
    }

    return grid;
  }

  private rearrangeNodesInGrid(grid: Node[][], nodes: Node[]): number {
    let level, index, subIndex;
    let newPenalty;
    const maxLevel = grid.length;
    const maxRowSize = grid[0].length;
    let penalty = this.calculatePenalty(grid, nodes);

    for (level = 0; level < maxLevel; level++) {
      for (index = 0; index < (maxRowSize - 1); index++) {
        for (subIndex = index + 1; subIndex < maxRowSize; subIndex++) {
          if ((subIndex - index) > 1) {
            this.shiftNodesInGrid(grid, level, index, subIndex);
            newPenalty = this.calculatePenalty(grid, nodes);

            if (newPenalty <= penalty) {
              penalty = newPenalty;
            } else {
              this.shiftNodesInGrid(grid, level, subIndex, index);
            }
          }
        }
      }
    }

    for (level = 0; level < maxLevel; level++) {
      for (index = 0; index < (maxRowSize - 1); index++) {
        for (subIndex = index + 1; subIndex < maxRowSize; subIndex++) {
          if (grid[level][index] !== null || grid[level][subIndex] !== null) {
            this.swapNodesInGrid(grid, level, index, subIndex);
            newPenalty = this.calculatePenalty(grid, nodes);

            if (newPenalty <= penalty) {
              penalty = newPenalty;
            } else {
              this.swapNodesInGrid(grid, level, index, subIndex);
            }
          }
        }
      }
    }

    for (level = 1; level < maxLevel; level++) {
      for (index = 0; index < (maxRowSize - 1); index++) {
        if (grid[level][index] !== null && grid[level][index].parentLinks.length === 1) {
          const parentLevel = grid[level][index].parentLinks[0].node.level;
          for (subIndex = 0; subIndex < maxRowSize; subIndex++) {
            if (index !== subIndex && grid[level][index] !== null) {
              this.swapNodesInGrid(grid, level, index, subIndex);
              this.swapNodesInGrid(grid, parentLevel, index, subIndex);
              newPenalty = this.calculatePenalty(grid, nodes);

              if (newPenalty < penalty) {
                penalty = newPenalty;
              } else {
                this.swapNodesInGrid(grid, level, index, subIndex);
                this.swapNodesInGrid(grid, parentLevel, index, subIndex);
              }
            }
          }
        }
      }
    }

    return penalty;
  }

  private calculatePenalty(grid: Node[][], nodes: Node[]): number {
    let penalty = 0;

    for (let index = 0; index < nodes.length; index++) {
      const node = nodes[index];
      for (let childIndex = 0; childIndex < node.childLinks.length; childIndex++) {
        const relation = node.childLinks[childIndex];
        penalty = penalty +
          this.calculateLinkDistancePenalty(relation, EntityGraphBuilder.longVerticalDistanceScoreModifier) +
          this.calculateCrossedLinksPenalty(relation, EntityGraphBuilder.crossedLinesScoreWeight) +
          this.calculateLongVerticalLinksPenalty(relation, grid, EntityGraphBuilder.crossedNodesScoreWeight);
      }

      for (let siblingIndex = 0; siblingIndex < node.sameLevelLinks.length; siblingIndex++) {
        const relation = node.sameLevelLinks[siblingIndex];
        penalty = penalty +
          this.calculateLinkDistancePenalty(relation, EntityGraphBuilder.longHorizontalDistanceScoreModifier);
      }

    }

    return penalty;
  }
}
