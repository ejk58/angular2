import { NodeType } from './node-type';
import { NodeBehaviour } from './node-behaviour';
import { LinkType } from './link-type';
import { LinkDirection } from './link-direction';
import { Link } from './link';

export class Node {

  public static readonly nameUnknown: string = 'onbekend';
  public static readonly iconUnknown: string = 'bd_warning';

  private static readonly nodeMap: Map<number, {icon: string, behaviour: number}> = new Map([
    [NodeType.Persoon, {'icon': 'bd_np_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.PersoonMetRelatiesBuitenEntiteit, {'icon': 'bd_np-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.PersoonMetRelatiesBinnenEntiteit, {'icon': 'bd_np-in_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.PersoonMetRelatiesBinnenEnBuitenEntiteit, {'icon': 'bd_np-in-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.Eenmanszaak, {'icon': 'bd_ez_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.EenmanszaakMetRelatiesBuitenEntiteit, {'icon': 'bd_ez-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.EenmanszaakMetRelatiesBinnenEntiteit, {'icon': 'bd_ez-in_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.EenmanszaakMetRelatiesBinnenEnBuitenEntiteit, {'icon': 'bd_ez-in-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.BvOfNv, {'icon': 'bd_bv_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.BvOfNvMetRelatiesBuitenEntiteit, {'icon': 'bd_bv-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.Stichting, {'icon': 'bd_vg_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.StichtingMetRelatiesBuitenEntiteit, {'icon': 'bd_vg-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.Vof, {'icon': 'bd_vof_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.VofMetRelatiesBuitenEntiteit, {'icon': 'bd_vof-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.BuitenlandseRechtsvorm, {'icon': 'bd_bl_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.BuitenlandseRechtsvormMetRelatiesBuitenEntiteit, {'icon': 'bd_bl-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.OverigeRechtsvorm, {'icon': 'bd_on_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.OverigeRechtsvormMetRelatiesBuitenEntiteit, {'icon': 'bd_on-out_diap', 'behaviour': NodeBehaviour.node}],
    [NodeType.ObFiscaleEenheid, {'icon': 'bd_on_diap', 'behaviour': NodeBehaviour.group}],
    [NodeType.ObFiscaleEenheidMetRelatiesBuitenEntiteit, {'icon': 'bd_on-out_diap', 'behaviour': NodeBehaviour.group}],
    [NodeType.MeerDan20PersonenOpAdres, {'icon': 'bd_np-20-plus', 'behaviour': NodeBehaviour.node}]
  ]);

  public isSubject: boolean;
  public isGehuwdPartner: boolean;
  public isSamenwonendPartner: boolean;
  public isExPartner: boolean;
  public isZelfdeAdres: boolean;
  public isZelfdeEntiteit: boolean;

  public subjectNr: string;
  public type: number;
  public behaviour: number;
  public groupTypes: number[];
  public name: string;
  public age: number;
  public relation: string;
  public description: string;
  public visible: boolean;

  public data: any;
  public model: Object;
  public level: number;
  public index: number;
  public fiscalPartnerIndexDelta: number;
  public parentLinks: Link[];
  public childLinks: Link[];
  public sameLevelLinks: Link[];
  public loopLinks: Link[];
  public id: string;
  public classes: string[];

  constructor(row: any) {
    this.isSubject = false;
    this.isGehuwdPartner = false;
    this.isSamenwonendPartner = false;
    this.isExPartner = false;
    this.isZelfdeEntiteit = row['is_zelfde_entiteit'] != null ? row['is_zelfde_entiteit'] : false;
    this.isZelfdeAdres = row['is_zelfde_adres'] != null ? row['is_zelfde_adres'] : false;

    this.subjectNr = row['finr'];
    this.type = row['soort'] != null ? row['soort'] : null;
    this.behaviour = Node.nodeMap.has(this.type) ? Node.nodeMap.get(this.type).behaviour : NodeBehaviour.node;
    this.name = row['naam'];
    this.age = row['leeftijd'];
    this.groupTypes = [];
    this.relation = row['relatiebeschrijving'];
    this.description = row['omschrijving'];
    this.visible = this.behaviour !== NodeBehaviour.group;

    this.data = row;
    this.model = row['model'];
    this.level = null;
    this.index = null;
    this.fiscalPartnerIndexDelta = 0;
    this.parentLinks = [];
    this.childLinks = [];
    this.sameLevelLinks = [];
    this.loopLinks = [];
    this.id = 'id-' + row['finr'];
    this.classes = ['node', 'node-id-' + row['finr']];

    if (row['is_subject'] === 1) {
      this.relation = this.relation ? this.relation : 'Belastingplichtige';
      this.isSubject = true;
      this.classes = this.classes.filter((item: string): boolean =>
        item !== 'node-gehuwd-partner' && item !== 'node-samenwonend-partner' && item !== 'node-ex-partner'
      );
      this.classes.push('node-subject');
    }

    if (row['is_fe_ob'] === 1) {
      this.groupTypes.push(LinkType.ObFiscaleEenheid);
    }

    if (row['is_fe_vpb'] === 1) {
      this.groupTypes.push(LinkType.VpbFiscaleEenheid);
    }
  }

  public isOfBaseType(baseType: number): boolean {
    return this.type === baseType ||
        this.type === (baseType + 1) ||
        this.type === (baseType + 10) ||
        this.type === (baseType + 11);
  }

  public isPerson(): boolean {
    return this.isOfBaseType(NodeType.Persoon) || this.type === NodeType.MeerDan20PersonenOpAdres;
  }

  public isGroupNode(): boolean {
    return this.groupTypes.length > 0;
  }

  public isConnected(): boolean {
    return this.parentLinks.length > 0 || this.childLinks.length > 0 || this.sameLevelLinks.length > 0;
  }

  public isFiscalPartnerWith(node: Node): boolean {
    return this.sameLevelLinks.some(link => link.isFiscalPartnerLink() && link.hasMatchingNodes(this, node));
  }

  public hasGroupType(type: number): boolean {
    return this.groupTypes.some(groupType => groupType === type);
  }

  public hasGroupBehaviour(): boolean {
    return this.behaviour === NodeBehaviour.group;
  }

  public getName(): string {
    return this.name != null ? this.name : Node.nameUnknown;
  }

  public getIcon(): string {
    return Node.nodeMap.has(this.type) ? Node.nodeMap.get(this.type).icon : Node.iconUnknown;
  }

  public getModel(): Object {
    return this.model != null ? this.model : {subjectNr: this.subjectNr};
  }

  public addLink(link: Link): void {
    const direction = link.getDirection();
    const otherNode = link.getOtherNode(this);

    if (direction === LinkDirection.sameLevel) {
      this.sameLevelLinks.push(link);
    } else if (link.node === this) {
      this.childLinks.push(link);
    } else if (link.otherNode === this) {
      this.parentLinks.push(link);
    }

    if (otherNode != null && otherNode.isSubject) {
      if (link.hasType(LinkType.Gehuwd) || link.hasType(LinkType.GehuwdMet)) {
        this.isGehuwdPartner = true;
        this.classes.push('node-gehuwd-partner');
      }

      if (link.hasType(LinkType.Samenwonend) || link.hasType(LinkType.SamenwonendMet)) {
        this.isSamenwonendPartner = true;
        this.classes.push('node-samenwonend-partner');
      }

      if (link.hasType(LinkType.ExPartnerGehuwd) || link.hasType(LinkType.ExPartnerSamenwonend)) {
        this.isExPartner = true;
        this.classes.push('node-ex-partner');
      }
    }
  }

  public addClass(newClass: string): void {
    this.classes.push(newClass);
  }

  public hideLoopLink(loopLink: Link): void {
    this.parentLinks = this.parentLinks.filter(link => link !== loopLink);
    this.childLinks = this.childLinks.filter(link => link !== loopLink);
    this.sameLevelLinks = this.sameLevelLinks.filter(link => link !== loopLink);
    this.loopLinks.push(loopLink);
  }
}
