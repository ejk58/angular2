import { Selection } from 'd3-ng2-service';
import { Link } from './link';

export interface LinkPainter {
  getXStartCoordinate(link: Link): number;
  getYStartCoordinate(link: Link): number;
  getXEndCoordinate(link: Link): number;
  getYEndCoordinate(link: Link): number;

  drawLink(graph: Selection<any, any, any, any>, link: Link): void;
  drawPercentage(graph: Selection<any, any, any, any>, link: Link): void;
}
