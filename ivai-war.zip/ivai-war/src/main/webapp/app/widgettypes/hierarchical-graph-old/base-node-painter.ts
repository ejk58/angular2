import { Selection } from 'd3-ng2-service';
import { NodePainter } from './node-painter';
import { NodeType } from './node-type';
import { Node } from './node';

export class BaseNodePainter implements NodePainter {

  public static readonly imageAreaHeight = 66;
  public static readonly imageSize = 36;
  public static readonly imageRadius = Math.floor(BaseNodePainter.imageSize / 2);
  public static readonly imageTopMargin = 20;
  public static readonly imageAuraHeight = 56;
  public static readonly imageAuraTopMargin = 10;
  public static readonly imageAuraRadius = Math.floor(BaseNodePainter.imageAuraHeight / 2);
  public static readonly labelAreaHeight = 40;
  public static readonly labelTopMargin = BaseNodePainter.imageAreaHeight + 4;
  public static readonly labelWidth = 200;
  public static readonly labelHeight = 16;
  public static readonly nodeWidth = BaseNodePainter.labelWidth;
  public static readonly nodeHeight = BaseNodePainter.imageAreaHeight + BaseNodePainter.labelAreaHeight;
  public static readonly nodeRadius = Math.floor(BaseNodePainter.nodeWidth / 3);
  public static readonly nodeRelationOut = 'node-relation-out';
  public static readonly textAnchor = 'text-anchor';

  constructor(private readonly horizontalGap: number,
              private readonly verticalGap: number,
              private readonly leftMargin: number,
              private readonly topMargin: number,
              private readonly fiscalPartnerShift: number) {
    this.horizontalGap = horizontalGap;
    this.verticalGap = verticalGap;
    this.leftMargin = leftMargin;
    this.topMargin = topMargin;
    this.fiscalPartnerShift = fiscalPartnerShift;
  }

  public getXCoordinate(node: Node): number {
    let x = isNaN(node.index) ? 0 : (this.horizontalGap * node.index + Math.floor(BaseNodePainter.nodeWidth / 2) + this.leftMargin);

    if (node.fiscalPartnerIndexDelta === -1) {
      x = x - this.fiscalPartnerShift;
    } else if (node.fiscalPartnerIndexDelta === 1) {
      x = x + this.fiscalPartnerShift;
    }

    return x;
  }

  public getYCoordinate(node: Node): number {
    return isNaN(node.level) ? 0 : (node.level * this.verticalGap + this.topMargin);
  }

  public drawNode(graph: Selection<any, any, any, any>, node: Node): void {
    if (node.visible) {
      const nodeGroup = this.createNodeGroup(graph, node);
      this.drawAura(nodeGroup, node);
      this.drawImage(nodeGroup, node);
      this.drawAge(nodeGroup, node);
      this.drawLabel(nodeGroup, node);
      this.drawMouseArea(nodeGroup, node);
      this.addMouseEvents(graph, nodeGroup, node);
    }
  }

  public addMouseEvents(graph: Selection<any, any, any, any>, nodeGroup: Selection<any, any, any, any>, node: Node): void {
    nodeGroup.on('mouseover', () => {
      graph.selectAll('.node-' + node.id).classed('node-highlight', true);
      graph.selectAll('.link-' + node.id).classed('link-highlight', true);
      graph.selectAll('.box-' + node.id).classed('box-highlight', true);
    });

    nodeGroup.on('mouseout', () => {
      graph.selectAll('.node-' + node.id).classed('node-highlight', false);
      graph.selectAll('.link-' + node.id).classed('link-highlight', false);
      graph.selectAll('.box-' + node.id).classed('box-highlight', false);
    });
  }

  private createNodeGroup(graph: Selection<any, any, any, any>, node: Node): Selection<any, any, any, any> {
    return graph.append('g')
      .attr('class', node.classes.join(' '));
  }

  private drawAura(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node);

    if (node.isZelfdeEntiteit) {
      nodeGroup.append('circle')
        .attr('r', BaseNodePainter.imageAuraRadius)
        .attr('cx', x)
        .attr('cy', y + BaseNodePainter.imageAuraTopMargin + BaseNodePainter.imageAuraRadius)
        .attr('class', 'node-same-entity-icon');
    }

    if (node.isZelfdeAdres) {
      nodeGroup.append('path')
        .attr('d', 'M' + x + ',' + (y + BaseNodePainter.imageTopMargin - 3) +
          ' l-3,-5' +
          ' a4,5,0,1,1,6,0' +
          ' Z')
        .attr('class', 'node-same-address-icon');
      nodeGroup.append('circle')
        .attr('r', 2)
        .attr('cx', x)
        .attr('cy', y + BaseNodePainter.imageTopMargin - 12)
        .attr('class', 'node-same-address-circle-icon');
    }
  }

  private drawImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    if (node.type === NodeType.MeerDan20PersonenOpAdres) {
      this.drawMeerDan20PersonenOpZelfdeAdresImage(nodeGroup, node);
    } else if (node.isOfBaseType(NodeType.Persoon)) {
      this.drawPersoonImage(nodeGroup, node);
    } else if (node.isOfBaseType(NodeType.Eenmanszaak)) {
      this.drawEenmanszaakImage(nodeGroup, node);
    } else if (node.isOfBaseType(NodeType.BvOfNv)) {
      this.drawBvOfNvImage(nodeGroup, node);
    } else if (node.isOfBaseType(NodeType.Stichting)) {
      this.drawStichtingImage(nodeGroup, node);
    } else if (node.isOfBaseType(NodeType.Vof)) {
      this.drawVofImage(nodeGroup, node);
    } else if (node.isOfBaseType(NodeType.BuitenlandseRechtsvorm)) {
      this.drawBuitenlandseRechtsvormImage(nodeGroup, node);
    } else if (node.isOfBaseType(NodeType.OverigeRechtsvorm)) {
      this.drawOverigeRechtsvormImage(nodeGroup, node);
    } else if (node.isOfBaseType(NodeType.VasteInrichting)) {
      this.drawVasteInrichtingImage(nodeGroup, node);
    } else {
      this.drawOnbekendeRechtsvormImage(nodeGroup, node);
    }
  }

  private drawPersoonImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    if (node.type === NodeType.PersoonMetRelatiesBuitenEntiteit || node.type === NodeType.PersoonMetRelatiesBinnenEnBuitenEntiteit) {
      nodeGroup.append('path')
        .attr('d', 'M' + (x - BaseNodePainter.imageRadius - 3) + ',' + (y + BaseNodePainter.imageRadius + 1) +
          ' a' + (BaseNodePainter.imageRadius - 1) + ',' + (BaseNodePainter.imageRadius - 1) + ',0,0,1,' +
          (BaseNodePainter.imageRadius + 3) + ',-' + (BaseNodePainter.imageRadius + 3))
        .attr('class', BaseNodePainter.nodeRelationOut);
    }

    nodeGroup.append('circle')
      .attr('r', BaseNodePainter.imageRadius)
      .attr('cx', x)
      .attr('cy', y + BaseNodePainter.imageRadius)
      .attr('class', 'node-icon');

    if (node.type === NodeType.PersoonMetRelatiesBinnenEntiteit || node.type === NodeType.PersoonMetRelatiesBinnenEnBuitenEntiteit) {
      nodeGroup.append('circle')
        .attr('r', BaseNodePainter.imageRadius - 7)
        .attr('cx', x)
        .attr('cy', y + BaseNodePainter.imageRadius)
        .attr('class', 'node-relation-in');
    }
  }

  private drawEenmanszaakImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    if (node.type === NodeType.EenmanszaakMetRelatiesBuitenEntiteit || node.type === NodeType.EenmanszaakMetRelatiesBinnenEnBuitenEntiteit) {
      nodeGroup.append('path')
        .attr('d', 'M' + (x - BaseNodePainter.imageRadius - 3) + ',' + (y + BaseNodePainter.imageRadius + 1) +
          ' a' + (BaseNodePainter.imageRadius - 1) + ',' + (BaseNodePainter.imageRadius - 1) + ',0,0,1,' + (BaseNodePainter.imageRadius + 3) +
          ',-' + (BaseNodePainter.imageRadius + 3))
        .attr('class', BaseNodePainter.nodeRelationOut);
    }

    nodeGroup.append('path')
      .attr('d', 'M' + (x - BaseNodePainter.imageRadius) + ',' + (y + BaseNodePainter.imageSize) +
        ' v' + -BaseNodePainter.imageRadius +
        ' a' + BaseNodePainter.imageRadius + ',' + BaseNodePainter.imageRadius + ',0,0,1,' + (BaseNodePainter.imageRadius * 2) + ',0' +
        ' v' + BaseNodePainter.imageRadius +
        ' h' + (-BaseNodePainter.imageSize) +
        ' Z')
      .attr('class', 'node-icon');

    if (node.type === NodeType.EenmanszaakMetRelatiesBinnenEntiteit || node.type === NodeType.EenmanszaakMetRelatiesBinnenEnBuitenEntiteit) {
      nodeGroup.append('circle')
        .attr('r', BaseNodePainter.imageRadius - 7)
        .attr('cx', x)
        .attr('cy', y + BaseNodePainter.imageRadius)
        .attr('class', 'node-relation-in');
    }
  }

  private drawBvOfNvImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    if (node.type === NodeType.BvOfNvMetRelatiesBuitenEntiteit) {
      nodeGroup.append('path')
        .attr('d', 'M' + (x - BaseNodePainter.imageRadius - 4) + ',' + (y - 4) +
          ' h' + (BaseNodePainter.imageSize) +
          ' h' + (-BaseNodePainter.imageSize) +
          ' v' + (BaseNodePainter.imageSize))
        .attr('class', BaseNodePainter.nodeRelationOut);
    }

    nodeGroup.append('rect')
      .attr('height', BaseNodePainter.imageSize)
      .attr('width', BaseNodePainter.imageSize)
      .attr('x', x - BaseNodePainter.imageRadius)
      .attr('y', y)
      .attr('class', 'node-icon');
  }

  private drawStichtingImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    if (node.type === NodeType.StichtingMetRelatiesBuitenEntiteit) {
      nodeGroup.append('path')
        .attr('d', 'M' + (x - 4) + ',' + (y - 1) +
          ' l' + -BaseNodePainter.imageRadius  + ',' + (BaseNodePainter.imageSize))
        .attr('class', BaseNodePainter.nodeRelationOut);
    }

    nodeGroup.append('path')
      .attr('d', 'M' + x + ',' + y +
        ' l' + BaseNodePainter.imageRadius  + ',' + BaseNodePainter.imageSize +
        ' h' + (-BaseNodePainter.imageSize) +
        ' Z')
      .attr('class', 'node-icon');
  }

  private drawVofImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    if (node.type === NodeType.VofMetRelatiesBuitenEntiteit) {
      nodeGroup.append('path')
        .attr('d', 'M' + (x - 4) + ',' + (y - 1) +
          ' l' + -BaseNodePainter.imageRadius + ',' + (BaseNodePainter.imageRadius * 0.8) +
          ' l' + (BaseNodePainter.imageRadius * 0.4) + ',' + (BaseNodePainter.imageRadius * 1.2))
        .attr('class', BaseNodePainter.nodeRelationOut);
    }

    nodeGroup.append('path')
      .attr('d', 'M' + x + ',' + y +
        ' l' + BaseNodePainter.imageRadius + ',' + (BaseNodePainter.imageRadius * 0.8) +
        ' l' + (-BaseNodePainter.imageRadius * 0.4) + ',' + (BaseNodePainter.imageRadius * 1.2) +
        ' h' + (-BaseNodePainter.imageRadius * 1.2) +
        ' l' + (-BaseNodePainter.imageRadius * 0.4) + ',' + (-BaseNodePainter.imageRadius * 1.2) +
        ' Z')
      .attr('class', 'node-icon');
  }

  private drawBuitenlandseRechtsvormImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    if (node.type === NodeType.BuitenlandseRechtsvormMetRelatiesBuitenEntiteit) {
      nodeGroup.append('path')
        .attr('d', 'M' + (x - BaseNodePainter.imageRadius - 4) + ',' + (y - 4) +
          ' h' + (BaseNodePainter.imageSize) +
          ' h' + (-BaseNodePainter.imageSize) +
          ' v' + (BaseNodePainter.imageSize))
        .attr('class', BaseNodePainter.nodeRelationOut);
    }

    nodeGroup.append('path')
      .attr('d', 'M' + (x - BaseNodePainter.imageRadius) + ',' + y +
        ' h' + BaseNodePainter.imageRadius +
        ' v' + (BaseNodePainter.imageSize) +
        ' v' + (-BaseNodePainter.imageSize) +
        ' h' + (BaseNodePainter.imageRadius) +
        ' v' + (BaseNodePainter.imageSize) +
        ' h' + (-BaseNodePainter.imageSize) +
        ' Z')
      .attr('class', 'node-icon');
  }

  private drawOverigeRechtsvormImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    if (node.type === NodeType.OverigeRechtsvormMetRelatiesBuitenEntiteit) {
      nodeGroup.append('path')
        .attr('d', 'M' + (x - BaseNodePainter.imageRadius - 4) + ',' + (y - 4) +
          ' h' + (BaseNodePainter.imageSize) +
          ' h' + (-BaseNodePainter.imageSize) +
          ' v' + (BaseNodePainter.imageSize))
        .attr('class', BaseNodePainter.nodeRelationOut);
    }

    nodeGroup.append('rect')
      .attr('height', BaseNodePainter.imageSize)
      .attr('width', BaseNodePainter.imageSize)
      .attr('x', x - BaseNodePainter.imageRadius)
      .attr('y', y)
      .attr('class', 'node-icon node-dashed-icon');
  }

  private drawVasteInrichtingImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    if (node.type === NodeType.VasteInrichtingMetRelatiesBuitenEntiteit) {
      nodeGroup.append('path')
        .attr('d', 'M' + (x + 3) + ',' + (y - 4) +
          ' h' + (BaseNodePainter.imageSize - 6) +
          ' h' + (-BaseNodePainter.imageSize + 6) +
          ' l' + '-6,' + (BaseNodePainter.imageSize))
        .attr('class', BaseNodePainter.nodeRelationOut);
    }

    nodeGroup.append('path')
      .attr('d', 'M' + (x + 6) + ',' + y +
        ' h' + (BaseNodePainter.imageSize - 6) +
        ' l' + '-6,' + (BaseNodePainter.imageSize) +
        ' h' + (-BaseNodePainter.imageSize + 6) +
        ' Z')
      .attr('class', 'node-icon');
  }

  private drawMeerDan20PersonenOpZelfdeAdresImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    nodeGroup.append('path')
      .attr('d', 'M' + (x + BaseNodePainter.imageRadius + 10) + ',' + (y + BaseNodePainter.imageRadius - 14) +
        ' a' + Math.floor(BaseNodePainter.imageRadius / 4) + ',' + Math.floor(BaseNodePainter.imageRadius / 4) + ',0,0,0,-' +
        (BaseNodePainter.imageRadius - 4) + ',-' + (BaseNodePainter.imageRadius - 4))
      .attr('class', 'node-icon');
    nodeGroup.append('path')
      .attr('d', 'M' + (x + BaseNodePainter.imageRadius + 3) + ',' + (y + BaseNodePainter.imageRadius - 1) +
        ' a' + Math.floor(BaseNodePainter.imageRadius / 2) + ',' + Math.floor(BaseNodePainter.imageRadius / 2) + ',0,0,0,-' +
        (BaseNodePainter.imageRadius + 2) + ',-' + (BaseNodePainter.imageRadius + 2))
      .attr('class', 'node-icon');
    nodeGroup.append('circle')
      .attr('r', BaseNodePainter.imageRadius)
      .attr('cx', x)
      .attr('cy', y + BaseNodePainter.imageRadius)
      .attr('class', 'node-icon');
  }

  private drawOnbekendeRechtsvormImage(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin;

    nodeGroup.append('path')
      .attr('d', 'M' + (x - BaseNodePainter.imageRadius) + ',' + y +
        ' h' + (BaseNodePainter.imageSize) +
        ' l' + (-BaseNodePainter.imageRadius) + ',' + (BaseNodePainter.imageSize) +
        ' Z')
      .attr('class', 'node-icon');
  }

  private drawAge(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    if (node.age != null) {
      const x = this.getXCoordinate(node);
      const y = this.getYCoordinate(node) + BaseNodePainter.imageTopMargin + BaseNodePainter.imageRadius + 5;

      nodeGroup.append('text')
        .attr('x', x)
        .attr('y', y)
        .attr(BaseNodePainter.textAnchor, 'middle')
        .attr('class', 'node-age-label')
        .attr('fill', '#535353')
        .text(node.age);
    }
  }

  private drawLabel(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const name = node.getName();
    const shortName = (name == null || name.length <= 18) ? name : name.substr(0, 16) + '...';
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + BaseNodePainter.labelTopMargin;

    nodeGroup.append('text')
      .attr('x', x)
      .attr('y', y + Math.floor(BaseNodePainter.labelHeight * 0.5))
      .attr(BaseNodePainter.textAnchor, 'middle')
      .attr('class', 'node-name node-' + node.id + '-name')
      .attr('fill', '#535353')
      .text(shortName);

    if (node.type !== NodeType.MeerDan20PersonenOpAdres) {
      nodeGroup.append('text')
        .attr('x', x)
        .attr('y', y + Math.floor(BaseNodePainter.labelHeight * 1.5))
        .attr(BaseNodePainter.textAnchor, 'middle')
        .attr('class', 'node-number node-' + node.id + '-number')
        .attr('fill', '#535353')
        .text(node.subjectNr);
    }
  }

  private drawMouseArea(nodeGroup: Selection<any, any, any, any>, node: Node): void {
    const x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node) + Math.floor(BaseNodePainter.nodeHeight / 2);

    nodeGroup.append('circle')
      .attr('cx', x)
      .attr('cy', y)
      .attr('r', BaseNodePainter.nodeRadius)
      .attr('class', 'node-aura')
      .style('fill-opacity', '0.0');
  }
}
