import {Selection} from 'd3-ng2-service';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {SvgIconProvider} from '../../commons/svg-icon-provider';
import {Node} from './node';
import {BoxPainter} from './box-painter';
import {NodePainter} from './node-painter';
import {BaseNodePainter} from './base-node-painter';

export class BaseBoxPainter implements BoxPainter {

  public static readonly boxLabelHeight = 14;
  public static readonly boxLeftPadding = 15;
  public static readonly boxRightPadding = 20;
  public static readonly boxTopPadding = 15;
  public static readonly boxBottomPadding = 18;
  public static readonly boxLabelWidth = 200;
  public static readonly boxIconWidth = 40;
  public static readonly boxArrowWidth = 5;
  public static readonly boxArrowDistance = 5;
  public static readonly boxButtonWidth = 30;
  public static readonly boxButtonHeight = 30;
  public static readonly boxInitialWidth = BaseBoxPainter.boxLabelWidth + BaseBoxPainter.boxIconWidth * 2 + BaseBoxPainter.boxLeftPadding + BaseBoxPainter.boxRightPadding;
  public static readonly boxSpace = BaseBoxPainter.boxInitialWidth + BaseBoxPainter.boxArrowWidth + BaseBoxPainter.boxArrowDistance + BaseNodePainter.imageRadius;
  public static readonly boxBackground = 'box-background';
  public static readonly textAnchor = 'text-anchor';
  public static readonly boxButton = 'box-button';

  private readonly side: string;
  private readonly width: number;
  private readonly verticalGap: number;
  private readonly profilePage: string;
  private readonly relationPage: string;

  constructor(side: string, width: number, verticalGap: number, profilePage: string, relationPage: string,
      private readonly nodePainter: NodePainter,
      private readonly pageNavigationUtilService: PageNavigationUtilService,
      private readonly svgIconProvider: SvgIconProvider) {

    this.side = side;
    this.width = width;
    this.verticalGap = verticalGap;

    this.profilePage = profilePage;
    this.relationPage = relationPage;
  }

  public getNodeXCoordinate(node: Node): number {
    let x = 0;

    if (node.visible) {
      x = this.nodePainter.getXCoordinate(node);
    } else if (node.childLinks.length > 0) {
      const firstChildNode = node.childLinks[0].otherNode;
      x = this.nodePainter.getXCoordinate(firstChildNode);
    }

    return x;
  }

  public getXCoordinate(node: Node): number {
    let x = 0;

    if (node.visible) {
      x = this.nodePainter.getXCoordinate(node) + BaseNodePainter.imageRadius + BaseBoxPainter.boxArrowDistance + BaseBoxPainter.boxArrowWidth;
    } else if (node.childLinks.length > 0) {
      const firstChildNode = node.childLinks[0].otherNode;
      x = this.nodePainter.getXCoordinate(firstChildNode) + BaseNodePainter.imageRadius + BaseBoxPainter.boxArrowDistance + BaseBoxPainter.boxArrowWidth;
    }

    return x;
  }

  public getYCoordinate(node: Node): number {
    const boxHeight = this.getBoxHeight(node);
    let y = 0;

    if (node.visible) {
      y = this.nodePainter.getYCoordinate(node) + BaseNodePainter.imageRadius + BaseNodePainter.imageTopMargin - Math.floor(boxHeight / 2);
    } else if (node.childLinks.length > 0) {
      const verticalDelta = Math.floor(this.verticalGap / 2) + BaseNodePainter.nodeRadius - boxHeight + 10;
      const firstChildNode = node.childLinks[0].otherNode;
      y = this.nodePainter.getYCoordinate(firstChildNode) + BaseNodePainter.imageRadius + BaseNodePainter.imageTopMargin - Math.floor(boxHeight / 2) + verticalDelta;
    }

    return y;
  }

  public getBoxHeight(node: Node): number {
    const relationDelta = (node.relation == null) ? 0 : 1;
    const descriptionDelta = (node.description == null) ? 0 : 1;
    return BaseBoxPainter.boxTopPadding + BaseBoxPainter.boxBottomPadding + BaseBoxPainter.boxLabelHeight * (2 + relationDelta + descriptionDelta);
  }

  public drawBox(graph: Selection<any, any, any, any>, node: Node, boxClass: string): void {
    const boxGroup = this.createBoxGroup(graph, node, boxClass);
    this.drawNodeBox(graph, boxGroup, node);
  }

  private createBoxGroup(graph: Selection<any, any, any, any>, node: Node, boxClass: string): Selection<any, any, any, any> {
    return graph.append('g')
      .attr('class', 'box box-' + node.id + boxClass);
  }

  private drawNodeBox(graph: Selection<any, any, any, any>, boxGroup: Selection<any, any, any, any>, node: Node): void {
    const relationDelta = (node.relation == null) ? 0 : 1;
    const descriptionDelta = (node.description == null) ? 0 : 1;
    const boxHeight = BaseBoxPainter.boxTopPadding + BaseBoxPainter.boxBottomPadding + BaseBoxPainter.boxLabelHeight * (2 + relationDelta + descriptionDelta);

    let x = this.getXCoordinate(node);
    const y = this.getYCoordinate(node);
    const nodeX = this.getNodeXCoordinate(node);

    const boxElement = boxGroup.append('rect')
      .attr('x', x)
      .attr('y', y)
      .attr('width', BaseBoxPainter.boxInitialWidth)
      .attr('height', boxHeight)
      .attr('rx', 2)
      .attr('ry', 2)
      .attr('class', BaseBoxPainter.boxBackground);

    const relationElement = boxGroup.append('text')
      .attr('x', x + BaseBoxPainter.boxLeftPadding)
      .attr('y', y + BaseBoxPainter.boxTopPadding + BaseBoxPainter.boxLabelHeight * relationDelta)
      .attr(BaseBoxPainter.textAnchor, 'start')
      .attr('class', 'box-label box-relation')
      .text(node.relation);
    const relationBox = (relationElement.node() as SVGGraphicsElement).getBBox();

    const nameElement = boxGroup.append('text')
      .attr('x', x + BaseBoxPainter.boxLeftPadding)
      .attr('y', y + BaseBoxPainter.boxTopPadding + BaseBoxPainter.boxLabelHeight * (1 + relationDelta))
      .attr(BaseBoxPainter.textAnchor, 'start')
      .attr('class', 'box-label box-name')
      .text(node.name);
    const nameBox = (nameElement.node() as SVGGraphicsElement).getBBox();

    const numberElement = boxGroup.append('text')
      .attr('x', x + BaseBoxPainter.boxLeftPadding)
      .attr('y', y  + BaseBoxPainter.boxTopPadding + BaseBoxPainter.boxLabelHeight * (2 + relationDelta))
      .attr(BaseBoxPainter.textAnchor, 'start')
      .attr('class', 'box-label box-number')
      .text(node.subjectNr);
    const numberBox = (numberElement.node() as SVGGraphicsElement).getBBox();

    const descriptionElement = boxGroup.append('text')
      .attr('x', x + BaseBoxPainter.boxLeftPadding)
      .attr('y', y + BaseBoxPainter.boxTopPadding + BaseBoxPainter.boxLabelHeight * (3 + relationDelta))
      .attr(BaseBoxPainter.textAnchor, 'start')
      .attr('class', 'box-label box-description')
      .text(node.description);
    const descriptionBox = (descriptionElement.node() as SVGGraphicsElement).getBBox();

    const boxWidth = Math.max (relationBox.width, nameBox.width, numberBox == null ? 0 : numberBox.width, descriptionBox.width) +
        BaseBoxPainter.boxIconWidth * 2 + BaseBoxPainter.boxLeftPadding + BaseBoxPainter.boxRightPadding;

    if (node.visible) {
      if ((this.width - x) < boxWidth) {
        x = nodeX - BaseNodePainter.imageRadius - BaseBoxPainter.boxArrowDistance - BaseBoxPainter.boxArrowWidth - boxWidth;

        if (x >= 0) {
          boxGroup
            .append('path')
            .attr('d', 'M' + (x + boxWidth + BaseBoxPainter.boxArrowWidth) + ',' + (y + Math.floor(boxHeight / 2)) + 'l-9,-9v18z')
            .attr('class', BaseBoxPainter.boxBackground);
        } else {
          x = 0;
        }
      } else {
        boxGroup
          .append('path')
          .attr('d', 'M' + (x - BaseBoxPainter.boxArrowWidth) + ',' + (y + Math.floor(boxHeight / 2)) + 'l9,-9v18z')
          .attr('class', BaseBoxPainter.boxBackground);
      }
    } else {
      x = Math.max(0, nodeX - Math.floor(boxWidth / 2));
    }

    boxElement.attr('x', x).attr('width', boxWidth);
    relationElement.attr('x', x + BaseBoxPainter.boxLeftPadding);
    nameElement.attr('x', x + BaseBoxPainter.boxLeftPadding);
    numberElement.attr('x', x + BaseBoxPainter.boxLeftPadding);
    descriptionElement.attr('x', x + BaseBoxPainter.boxLeftPadding);

    const buttonY = y + Math.floor((boxHeight - BaseBoxPainter.boxButtonHeight) / 2);

    if (this.profilePage != null) {
      const profileButtonX = x + boxWidth - (BaseBoxPainter.boxButtonWidth + 10) * (this.relationPage != null ? 2 : 1);
      const profileButtonY = buttonY;
      const profileButtonSize = BaseBoxPainter.boxButtonWidth - 12;

      if (node.isPerson()) {
        this.svgIconProvider.drawPersonIcon(boxGroup, profileButtonX + 2, profileButtonY + 4, profileButtonSize, BaseBoxPainter.boxButton);
      } else {
        this.svgIconProvider.drawBusinessIcon(boxGroup, profileButtonX, profileButtonY + 4, profileButtonSize, BaseBoxPainter.boxButton);
      }

      const profileButtonBox = boxGroup.append('rect')
        .attr('x', profileButtonX)
        .attr('y', profileButtonY)
        .attr('width', BaseBoxPainter.boxButtonWidth)
        .attr('height', BaseBoxPainter.boxButtonHeight)
        .attr('class',  'box-' + node.id + '-button-profile box-button-aura');

      profileButtonBox.on('click', () => {
        this.openProfileInRightSide(node);
      });
    }

    if (this.relationPage != null) {
      const relationsButtonX = x + boxWidth - BaseBoxPainter.boxButtonWidth - 10;
      const relationsButtonY = buttonY;
      const relationsButtonSize = BaseBoxPainter.boxButtonWidth - 12;

      this.svgIconProvider.drawRelationsIcon(boxGroup, relationsButtonX + 6, relationsButtonY + 4, relationsButtonSize, BaseBoxPainter.boxButton);

      const relationButtonBox = boxGroup.append('rect')
        .attr('x', relationsButtonX)
        .attr('y', relationsButtonY)
        .attr('width', BaseBoxPainter.boxButtonWidth)
        .attr('height', BaseBoxPainter.boxButtonHeight)
        .attr('class', 'box-' + node.id + '-button-relation box-button-aura');

      relationButtonBox.on('click', () => {
        this.openRelationsInRightSide(node);
      });
    }

    if (this.profilePage != null && this.relationPage != null) {
      boxGroup.append('line')
        .attr('x1', x + boxWidth - BaseBoxPainter.boxButtonWidth - 17)
        .attr('y1', buttonY)
        .attr('x2', x + boxWidth - BaseBoxPainter.boxButtonWidth - 17)
        .attr('y2', buttonY + BaseBoxPainter.boxButtonHeight)
        .attr('class', 'box-button-separator');
    }

    this.nodePainter.addMouseEvents(graph, boxGroup, node);
  }

  public openProfileInRightSide(node: Node): void {
    if (this.profilePage != null) {
      this.pageNavigationUtilService.navigate(this.side, 'right', this.profilePage, node.getModel(), null);
    }
  }

  public openRelationsInRightSide(node: Node): void {
    if (this.relationPage != null) {
      this.pageNavigationUtilService.navigate(this.side, 'right', this.relationPage, node.getModel(), null);
    }
  }
}
