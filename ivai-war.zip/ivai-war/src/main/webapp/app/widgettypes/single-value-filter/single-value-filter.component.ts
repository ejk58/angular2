import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import * as fromSelectors from '../../store/selectors';
import {Store} from '@ngrx/store';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {ActivatedRoute} from '@angular/router';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-single-value-filter',
  templateUrl: './single-value-filter.component.html',
  styleUrls: ['./single-value-filter.component.scss'],
  providers: [Unsubscriber]
})
export class SingleValueFilterComponent implements OnInit, OnDestroy {
  @Input() side: string;
  @Input() widgetId: string;
  @Input() widget: any;
  @Input() filter: any;
  public selectedContent: string;
  public localFilter: any;
  public tabId: number;
  public widgetName: string;

  constructor(private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly route: ActivatedRoute,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) {}

  ngOnInit() {
    this.route.params
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(params => {
        if (params.tabId) {
          this.tabId = params.tabId;
        }
        if (params.containerId) {
          this.widgetName = params.containerId;
        }
      });

    if (this.widget.data.length > 0) {
      const activeFilterOnInit: any = this.widget.data.find(widgetData => widgetData.Filter.tabActiveOnInit === 1);
      let activeTab: any = activeFilterOnInit ? activeFilterOnInit.Filter.value : this.widget.data[0].Filter.value;
      const localWidgetName = this.widgetName;
      const widgetInFilter: boolean = this.widget.options.widgets.some(widget => localWidgetName === widget.name);
      if (widgetInFilter && this.tabId && this.widget.data[this.tabId]) {
        activeTab = this.widget.data[this.tabId].Filter.value; // When returning from detail page
      }
      this.displaySelectedContent(activeTab);
    }
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  displaySelectedContent(content: string) {
    this.localFilter = this.getFilter(content);
    this.selectedContent = content;
  }

  getFilter(value: any) {
    let filter = this.filter || {};
    const selectedDataSet: any = this.widget.data.find(dataSet => dataSet.Filter.value === value);
    if (selectedDataSet) {
      filter[selectedDataSet.Filter.key] = selectedDataSet.Filter.value;
    }
    this.filter = filter;
    return this.filter;
  }
}
