import {Component, OnInit} from '@angular/core';
import {TableComponent} from '../table/table.component';
import {Column} from '../../classes/column';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-collapsible-table',
  templateUrl: './collapsible-table.component.html',
  styleUrls: ['./collapsible-table.component.scss'],
  providers: [Unsubscriber]
})
export class CollapsibleTableComponent extends TableComponent implements OnInit {

  public collapsedIds: number[] = [];
  public firstColName: string;
  public maxLevel: number;
  public allRowsAreCollapsed: boolean;

  ngOnInit() {
    super.ngOnInit();
    this.firstColName = this.getFirstColName();
    this.setParentIndicatorAndAddChildren();
    this.maxLevel = this.getMaxLevel();
    this.collapseAllWithoutEvent();

    // insert the collapse header at the start
    if (this.haveGroupAttributes) {
      this.columnGroups.unshift({
        columnType: null,
        label: null,
        span: 1,
        sticky: Object.keys(this.columns).some(c => this.columns[c].sticky)
      });
    }
  }

  public rowClick(row): void {
    const parentId = row[this.findKey('identifier', row)];
    const index = this.collapsedIds.indexOf(parentId);
    if (index < 0) {
      this.collapsedIds.push(parentId);
      this.trackingService.trackEvent('klik',
        'Klik inklappen:' + this.side + '/widget:' + this.widgetId + '/soort:Regel', null, null);
      this.collapseAllLevels(row['CHILDREN']);
    } else {
      this.collapsedIds.splice(index, 1);
      this.openOneChildLevel(parentId);
    }
  }

  public isFirstcol(key): boolean {
    return key === this.firstColName;
  }

  public getClasses(options: string[], row: any, columnName: string): string {
    const classes: string[] = [];

    for (let i = 0; i < options.length; i++) {
      const option = options[i];
      if (option === 'tablerow-level') {
        classes.push('tablerow-level-' + this.getLevel(row));
      } else if (option === 'tablecol-level' && this.getLevel(row) > 0) {
        classes.push('tablecol-level-' + this.getLevel(row));
      } else if (option === 'firstcol' && this.isFirstcol(columnName)) {
        classes.push(option);
      } else if (option === 'isparent' && this.hasChildren(row)) {
        classes.push(option);
      } else if (option === 'collapsed') {
        if (this.isCollapsed(row)) {
          classes.push(option);
        } else {
          classes.push('not-collapsed');
        }
      } else if (option === 'expanded-row' && !this.isCollapsed(row) && this.hasChildren(row)) {
        classes.push(option);
      } else if (option === 'visible-row') {
        if (this.isVisible(row)) {
          classes.push(option);
        } else {
          classes.push('invisible-row');
        }
      }
    }
    // add styling from backend
    classes.push('bdTableRow-' + row.opmaak);

    return classes.join(' ');
  }

  public expandAll(): void {
    this.trackingService.trackEvent('klik',
      'Klik uitklappen:' + this.side + '/widget:' + this.widgetId + '/soort:Alles', null, null);
    this.collapsedIds = [];
    this.allRowsAreCollapsed = false;
  }

  public collapseAll(): void {
    this.trackingService.trackEvent('klik',
      'Klik inklappen:' + this.side + '/widget:' + this.widgetId + '/soort:Alles', null, null);
    this.collapseAllWithoutEvent();
  }

  private collapseAllLevels(children): void {
    if (children.length < 1) {
      return;
    }
    for (let index = 0; index < children.length; index++) {
      const id = children[index][this.findKey('identifier', children[index])];
      if (this.collapsedIds.indexOf(id) < 0) {
        this.collapsedIds.push(id);
      }
      this.collapseAllLevels(children[index]['CHILDREN']);
    }
  }

  private getFirstColName(): string {
    const firstColumnName = Object.keys(this.columns).find(columnName => Column.isVisible(this.columns[columnName].behaviour));
    return firstColumnName ? firstColumnName : null;
  }

  private setParentIndicatorAndAddChildren(): void {
    for (let rowIndex = 0; rowIndex < this.data.length; rowIndex++) {
      const row = this.data[rowIndex];
      const parentId = row[this.findKey('identifier', row)];

      row['CHILDREN'] = [];
      for (let index = rowIndex + 1; index < this.data.length; index++) {
        if (this.data[index][this.findKey('parent', this.data[index])] === parentId) {
          row['CHILDREN'].push(this.data[index]);
          row['ISPARENT'] = true;
        }
      }
    }
  }

  private getMaxLevel(): number {
    let max = 1;
    for (let index = 0; index < this.data.length; index++) {
      if (this.data[index][this.findKey('niveau', this.data[index])] > max) {
        max = this.data[index][this.findKey('niveau', this.data[index])];
      }
    }
    return max;
  }

  private isVisible(row): boolean {
    const parentId = row[this.findKey('parent', row)];
    return (parentId == null || this.collapsedIds.indexOf(parentId) < 0);
  }

  private isCollapsed(row): boolean {
    if (this.hasChildren(row)) {
      const index = this.collapsedIds.indexOf(row[this.findKey('identifier', row)]);
      return (index > -1);
    }
    return false;
  }

  private openOneChildLevel(parentId): void {
    this.trackingService.trackEvent('klik',
      'Klik uitklappen:' + this.side + '/widget:' + this.widgetId + '/soort:Regel', null, null);
    if (this.collapsedIds.indexOf(parentId) > -1) {
      this.collapsedIds.splice(this.collapsedIds.indexOf(parentId), 1);
    }
  }

  private hasChildren(row): boolean {
    return (row['ISPARENT']);
  }

  private getLevel(row): number {
    return row[this.findKey('niveau', row)];
  }

  private getIdentifier(row): number {
    return row[this.findKey('identifier', row)];
  }

  private collapseAllWithoutEvent(): void {
    for (let index = 0; index < this.data.length; index++) {
      const row = this.data[index];
      const parentId = row[this.findKey('parent', row)];
      const id = row[this.findKey('identifier', row)];
      if (parentId == null) {
        this.collapsedIds.push(id);
        this.collapseAllLevels(row['CHILDREN']);
      }
    }
    this.allRowsAreCollapsed = true;
  }

  private findKey(find, obj) {
    if (obj.constructor === Object) {
      obj = Object.keys(obj);
    }
    for (let i = 0; i < obj.length; i++) {
      if (find.toLowerCase() === obj[i].toLowerCase()) {
        return obj[i];
      }
    }
    return false;
  }

}
