import {Component, OnInit} from '@angular/core';
import {CollapsibleTableComponent} from '../collapsible-table/collapsible-table.component';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-flexible-collapsible-table',
  templateUrl: '../collapsible-table/collapsible-table.component.html',
  styleUrls: ['../collapsible-table/collapsible-table.component.scss'],
  providers: [Unsubscriber]
})
export class FlexibleCollapsibleTableComponent extends CollapsibleTableComponent implements OnInit {

  ngOnInit() {

    if (this.widget.data.length > 0) {
      const groupConfig = this.widget.data.shift(); // First data-row contains column-groups
      const labelConfig = this.widget.data.shift(); // Second data-row contains column-labels
      this.setGroupForColumns(groupConfig);
      this.setLabelForColumns(labelConfig);
    }

    super.ngOnInit();

  }

  private setGroupForColumns(groupConfig) {
    const groupKeys = Object.keys(groupConfig);
    groupKeys.forEach(key => {
      if (this.widget.options.columns[key]) {
        const columnType: string = this.widget.options.columns[key].columnType;
        const columnName: string = this.widget.options.columns[key].columnName;
        const value: number | string | Date = this.getColumnValue(groupConfig, columnType, columnName);
        if (value != null) {
          this.widget.options.columns[key].group = value;
        }
      }
    });
  }

  private setLabelForColumns(labelConfig) {
    const labelKeys = Object.keys(labelConfig);
    labelKeys.forEach(key => {
      if (this.widget.options.columns[key]) {
        const columnType: string = this.widget.options.columns[key].columnType;
        const columnName: string = this.widget.options.columns[key].columnName;
        const value: number | string | Date = this.getColumnValue(labelConfig, columnType, columnName);
        if (value != null) {
          this.widget.options.columns[key].label = value;
        } else {
          this.widget.options.columns[key].behaviour = 'invisible';
        }
      }
    });
  }
}
