import {Node} from '../../../classes/nodes/node';

import {Grid} from '../model/grid';
import {GridLayoutManager} from './grid-layout-manager';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';

export class GroupGridLayoutManager implements GridLayoutManager {

  protected readonly horizontalGap;
  protected readonly verticalGap;

  constructor(protected readonly nodeRadius: number,
      protected readonly horizontalStep: number,
      protected readonly verticalStep: number,
      protected readonly maxLevel: number,
      protected readonly maxRowSize: number) {

    this.horizontalGap = this.horizontalStep - (this.nodeRadius * 2);
    this.verticalGap = this.verticalStep - (this.nodeRadius * 2);
  }

  public build(nodes: Node<NodeHierarchicalModel, any>[]): Grid {
    let grid: Node<NodeHierarchicalModel, any>[][] = [];

    if (nodes && nodes.length > 0) {
      this.prepareNodesForGrid(nodes);
      this.buildGrid(nodes, grid);
      this.improveGrid(nodes, grid);
      this.calculateNodesInGrid(nodes);
    }

    return this.buildResponse(grid);
  }

  protected prepareNodesForGrid(nodes: Node<NodeHierarchicalModel, any>[]): void {
    nodes
      .filter(node => node.model.groupLinks.length > 0)
      .forEach(node => {
        const groupNode = (node === node.model.groupLinks[0].source) ? node.model.groupLinks[0].target : node.model.groupLinks[0].source;
        node.model.level = isNaN(groupNode.model.level) ? 0 : groupNode.model.level;
        node.model.index = isNaN(groupNode.model.index) ? 0 : groupNode.model.index;
      });
  }

  protected buildGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    this.buildEmptyGrid(nodes, grid);
    this.fillGridWithNodes(nodes, grid);
  }

  protected improveGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    for (let index = 0; index < 10; index++) {
      this.moveNodesInGrid(nodes, grid);
    }
  }

  protected calculateNodesInGrid(nodes: Node<NodeHierarchicalModel, any>[]): void {
    nodes.forEach(node => {
      node.model.x = this.calculateXCoordinate(node);
      node.model.y = this.calculateYCoordinate(node);

      node.x = node.model.x;
      node.y = node.model.y;
    });
  }

  protected buildResponse(grid: Node<NodeHierarchicalModel, any>[][]): Grid {
    const maxLevel = grid.length;
    const maxRowSize = maxLevel > 0 ? grid[0].length : 0;
    const minWidth = maxRowSize * this.horizontalStep - this.horizontalGap;
    const minHeight = maxLevel * this.verticalStep - this.verticalGap;

    return new Grid(grid, minWidth, minHeight, maxLevel, maxRowSize);
  }

  protected buildEmptyGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    for (let level = 0; level < this.maxLevel; level++) {
      const row = [];

      for (let index = 0; index < this.maxRowSize; index++) {
        row.push(null);
      }

      grid.push(row);
    }
  }

  protected fillGridWithNodes(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    nodes.forEach(node => grid[node.model.level][node.model.index] = node);
  }

  protected moveNodesInGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    nodes
      .filter(node => node.model.childLinks.length > 0)
      .forEach(node => {
        const count = node.model.childLinks.length;
        const level = Math.round(node.model.childLinks.reduce((value, link) => value + link.target.model.level, 0) / count);
        const index = Math.round(node.model.childLinks.reduce((value, link) => value + link.target.model.index, 0) / count);

        if (grid[level][index] == null) {
          this.moveNodeInGrid(node, grid, level, index);
        } else if (grid[node.model.level][index] == null) {
          this.moveNodeInGrid(node, grid, node.model.level, index);
        } else if (grid[level][node.model.index] == null) {
          this.moveNodeInGrid(node, grid, level, node.model.index);
        }
      });
  }

  protected moveNodeInGrid(node: Node<NodeHierarchicalModel, any>, grid: Node<NodeHierarchicalModel, any>[][], level: number, index: number) {
    grid[node.model.level][node.model.index] = null;
    grid[level][index] = node;

    node.model.level = level;
    node.model.index = index;
  }

  public calculateXCoordinate(node: Node<NodeHierarchicalModel, any>): number {
    return isNaN(node.model.index) ? 0 : (node.model.index * this.horizontalStep + this.nodeRadius);
  }

  public calculateYCoordinate(node: Node<NodeHierarchicalModel, any>): number {
    return isNaN(node.model.level) ? 0 : (node.model.level * this.verticalStep + this.nodeRadius * 2);
  }
}
