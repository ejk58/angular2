export enum NodeType {
  node = 1,
  group = 2
}
