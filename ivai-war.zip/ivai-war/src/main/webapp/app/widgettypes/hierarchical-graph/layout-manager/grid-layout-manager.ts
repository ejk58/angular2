import {Node} from '../../../classes/nodes/node';

import {Grid} from '../model/grid';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';

export interface GridLayoutManager {
  build(nodes: Node<NodeHierarchicalModel, any>[]): Grid;
}
