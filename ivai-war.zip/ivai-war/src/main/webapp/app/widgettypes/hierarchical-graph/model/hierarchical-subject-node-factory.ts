import {SubjectType} from '../../../commons/subject-type';
import {LinkSubjectType} from '../../../classes/links/link-subject-type';
import {Node} from '../../../classes/nodes/node';
import {NodeSubjectPresentation} from '../../../classes/nodes/node-subject-presentation';
import {NodeFactory} from '../../../classes/nodes/node-factory';

import {NodeType} from './node-type';
import {NodeHierarchicalModel} from './node-hierarchical-model';

export class HierarchicalSubjectNodeFactory implements NodeFactory<NodeHierarchicalModel, NodeSubjectPresentation> {

  public build(row: any): Node<NodeHierarchicalModel, NodeSubjectPresentation> {
    const model = this.buildModel(row);
    const presentation = this.buildPresentation(row);
    return this.buildNode(row, model, presentation);
  }

  private buildNode(row: any, model: NodeHierarchicalModel, presentation: NodeSubjectPresentation): Node<NodeHierarchicalModel, NodeSubjectPresentation> {
    const id = row['source'];

    const node = new Node<NodeHierarchicalModel, NodeSubjectPresentation>();
    node.id = id;
    node.model = model;
    node.presentation = presentation;
    node.data = row;
    node.classes = ['node', 'node-id-' + id];
    node.isMain = row['is_subject'] === 1;

    if (node.isMain) {
      node.classes.push('node-subject');
    }

    return node;
  }

  private buildModel(row: any): NodeHierarchicalModel {
    const type = row['type'];
    const behaviour = this.getBaseBehaviour(type);
    const model = new NodeHierarchicalModel();

    model.behaviour = row['is_fe_ob'] === 1 ? NodeType.group : behaviour;
    model.visible = behaviour !== NodeType.group;
    model.isPriority = this.isPerson(type);

    model.parentLinks = [];
    model.childLinks = [];
    model.siblingLinks = [];
    model.groupLinks = [];
    model.loopLinks = [];

    return model;
  }

  private buildPresentation(row: any): NodeSubjectPresentation {
    const type = row['type'];
    const presentation = new NodeSubjectPresentation();

    presentation.isPerson = this.isPerson(type);
    presentation.isMasked = row['finr'] === '######';
    presentation.isFiscalPartner = false;
    presentation.isMarried = false;
    presentation.isLivingTogether = false;
    presentation.isParent = false;
    presentation.isChild = false;
    presentation.isExPartner = false;
    presentation.isManyPeople = type === SubjectType.MeerDan20PersonenOpAdres;
    presentation.isSameAddress = row['is_zelfde_adres'] != null ? row['is_zelfde_adres'] : false;
    presentation.isSameEntity = row['is_zelfde_entiteit'] != null ? row['is_zelfde_entiteit'] : false;

    presentation.type = type;
    presentation.personType = this.getPersonType(type);
    presentation.subjectNr = row['finr'];
    presentation.name = row['naam'];
    presentation.age = row['leeftijd'];
    presentation.relation = row['relatiebeschrijving'];
    presentation.description = row['omschrijving'];

    presentation.groupTypes = [];

    if (row['is_subject'] === 1) {
      presentation.relation = presentation.relation ? presentation.relation : 'Belastingplichtige';
    }

    if (row['is_fe_ob'] === 1) {
      presentation.groupTypes.push(LinkSubjectType.ObFiscaleEenheid);
    }

    if (row['is_fe_vpb'] === 1) {
      presentation.groupTypes.push(LinkSubjectType.VpbFiscaleEenheid);
    }

    return presentation;
  }

  private getPersonType(type: number): number {

    if (type === SubjectType.Persoon || type === SubjectType.PersoonMetRelatiesBinnenEntiteit || type === SubjectType.PersoonMetRelatiesBuitenEntiteit ||
      type === SubjectType.PersoonMetRelatiesBinnenEnBuitenEntiteit || type === SubjectType.MeerDan20PersonenOpAdres) {
      return type;
    } else if (type === SubjectType.Eenmanszaak) {
      return SubjectType.Persoon;
    } else if (type === SubjectType.EenmanszaakMetRelatiesBinnenEntiteit) {
      return SubjectType.PersoonMetRelatiesBinnenEntiteit;
    } else if (type === SubjectType.EenmanszaakMetRelatiesBuitenEntiteit) {
      return SubjectType.PersoonMetRelatiesBuitenEntiteit;
    } else if (type === SubjectType.EenmanszaakMetRelatiesBinnenEnBuitenEntiteit) {
      return SubjectType.PersoonMetRelatiesBinnenEnBuitenEntiteit;
    }

    return null;
  }

  private getBaseBehaviour(type: number): NodeType {
    return (type !== 900 && type !== 901 ? NodeType.node : NodeType.group);
  }

  private isOfBaseType(type: number, baseType: number): boolean {
    return type === baseType ||
        type === (baseType + 1) ||
        type === (baseType + 10) ||
        type === (baseType + 11);
  }

  private isPerson(type: number): boolean {
    return this.isOfBaseType(type, SubjectType.Persoon) || this.isOfBaseType(type, SubjectType.Eenmanszaak) || type === SubjectType.MeerDan20PersonenOpAdres;
  }
}
