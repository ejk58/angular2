import {Node} from '../../../classes/nodes/node';

import {GridLayoutManager} from './grid-layout-manager';
import {AbstractGridLayoutManager} from './abstract-grid-layout-manager';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';

export class SimpleGridLayoutManager extends AbstractGridLayoutManager implements GridLayoutManager {

  protected improveGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    // Do not improve
  }
}
