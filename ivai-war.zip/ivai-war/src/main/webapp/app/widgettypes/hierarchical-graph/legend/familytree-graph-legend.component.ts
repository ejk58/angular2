import {Component, Input, Output, EventEmitter, ViewEncapsulation, OnInit, OnChanges, OnDestroy} from '@angular/core';
import {PageNavigationUtilService} from '../../../commons/page-navigation-util.service';
import {SplitViewState} from '../../../services/split-view-state.service';
import {TrackingService} from '../../../services/tracking.service';
import {SplitWidth} from '../../../classes/split-width';
import {Unsubscriber} from '../../../commons/unsubscriber';

@Component({
  selector: 'i-familytree-graph-legend',
  templateUrl: './familytree-graph-legend.component.html',
  styleUrls: ['./familytree-graph-legend.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})
export class FamilyTreeGraphLegendComponent implements OnInit, OnDestroy, OnChanges {

  private static readonly SidePanelWidth: number = 250;

  @Input() widgetId: string;
  @Input() side: string;
  @Input() settings: any;

  @Output() filterChange = new EventEmitter<any>();

  // public subject: Subject;
  public splitWidth: SplitWidth = SplitWidth.default;
  public breakpointWidth: number;
  public visible: boolean;
  public sidePanelVisible: boolean = true;

  public subject: {type: number};
  public address: {address: string, city: string};
  public addressAvailable: boolean;
  public entity: {entityNr: number; name: string, page: string};
  public entityAvailable: boolean;
  public entityLinkAvailable: boolean;

  public businessItemVisible: boolean;

  constructor(private readonly pageNavigationUtilService: PageNavigationUtilService,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService,
              private readonly unsubscriber: Unsubscriber) {
    this.visible = false;
  }

  ngOnInit(): void {
    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(splitWidth => this.splitWidth = splitWidth != null ? splitWidth : SplitWidth.default);
    this.breakpointWidth = this.splitViewState.breakpointResponsive + FamilyTreeGraphLegendComponent.SidePanelWidth;
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  ngOnChanges(): void {
    if (this.settings) {
      this.subject = this.settings.subject;
      this.address = this.settings.address;
      this.addressAvailable = this.address != null && (this.address.address != null || this.address.city != null);
      this.entity = this.settings.entity;
      this.entityAvailable = this.entity != null && (this.entity.name != null || this.entity.entityNr != null);
      this.entityLinkAvailable = this.entity != null && this.entity.page != null && this.entity.entityNr != null;
      this.businessItemVisible = this.settings.businessItemVisible;
    }
  }

  public getButtonArrow(): string {
    return this.visible ? 'fa fa-fw bd_keyboard_arrow_up' : 'fa fa-fw bd_keyboard_arrow_down';
  }

  public toggleLegend(event: any): void {
    this.visible = !this.visible;

    if (this.visible) {
      this.trackingService.trackEvent('klik',
        'Klik legenda open:' + this.side + '/widget:' + this.widgetId,
        null, null);
    }
  }

  public toggleSidePanel(): void {
    this.sidePanelVisible = !this.sidePanelVisible;
  }

  public toggleFilter(name: string): void {
    this[name] = !this[name];

    this.filterChange.emit({
      'businessItemVisible': this.businessItemVisible
    });
  }

  public clickEntityLink(): void {
    if (this.entityLinkAvailable) {
      const model = {entityNr: this.entity.entityNr};
      this.pageNavigationUtilService.navigate(this.side, 'right', this.entity.page, model, null);
    }
  }
}
