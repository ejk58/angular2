import {Component, ViewEncapsulation} from '@angular/core';
import {D3Service} from 'd3-ng2-service';
import {PageNavigationUtilService} from '../../../commons/page-navigation-util.service';
import {SubjectIconProvider} from '../../../commons/subject-icon-provider';

import {Node} from '../../../classes/nodes/node';
import {NodeSubjectPresentation} from '../../../classes/nodes/node-subject-presentation';
import {NodeDualSubjectPainter} from '../../../classes/nodes/node-dual-subject-painter';
import {NodePersonBusinessPainter} from '../../../classes/nodes/node-person-business-painter';
import {LinkSubjectType} from '../../../classes/links/link-subject-type';
import {LinkSubjectPresentation} from '../../../classes/links/link-subject-presentation';
import {LinkRelationHierarchicalPainter} from '../../../classes/links/link-relation-hierarchical-painter';

import {HierarchicalSubjectNodeFactory} from '../model/hierarchical-subject-node-factory';
import {HierarchicalSubjectLinkFactory} from '../model/hierarchical-subject-link-factory';
import {SplitGridLayoutManager} from '../layout-manager/split-grid-layout-manager';
import {AbstractHierarchicalGraph} from './abstract-hierarchical-graph.component';

@Component({
  selector: 'i-familytree-graph',
  templateUrl: '../hierarchical-graph.component.html',
  styleUrls: ['../hierarchical-graph.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FamilyTreeGraphComponent extends AbstractHierarchicalGraph<NodeSubjectPresentation, LinkSubjectPresentation> {

  private static readonly linkRelationType = '.link-type-';

  private profilePage: string;
  private relationPage: string;
  private entityPage: string;

  constructor(d3Service: D3Service,
      protected readonly pageNavigationUtilService: PageNavigationUtilService,
      protected readonly subjectIconProvider: SubjectIconProvider) {

    super(d3Service);

    this.legendType = 'familytree';
    this.filterType = 'none';
  }

  public changeBusinessVisibility(filter: any) {
    const businessOpacity = filter.businessItemVisible ? 1.0 : 0.0;
    const elementStyleList = [
      {selector: FamilyTreeGraphComponent.linkRelationType + LinkSubjectType.FirmantDeelnemer, key: 'opacity', value: businessOpacity},
      {selector: FamilyTreeGraphComponent.linkRelationType + LinkSubjectType.HeeftFirmantDeelnemer, key: 'opacity', value: businessOpacity},
      {selector: FamilyTreeGraphComponent.linkRelationType + LinkSubjectType.Bestuurder, key: 'opacity', value: businessOpacity},
      {selector: FamilyTreeGraphComponent.linkRelationType + LinkSubjectType.HeeftBestuurder, key: 'opacity', value: businessOpacity},
      {selector: FamilyTreeGraphComponent.linkRelationType + LinkSubjectType.Aandeelhouder, key: 'opacity', value: businessOpacity},
      {selector: FamilyTreeGraphComponent.linkRelationType + LinkSubjectType.HeeftAandeelhouder, key: 'opacity', value: businessOpacity},
      {selector: FamilyTreeGraphComponent.linkRelationType + LinkSubjectType.HeeftMeerRelaties, key: 'opacity', value: businessOpacity},
      {selector: FamilyTreeGraphComponent.linkRelationType + LinkSubjectType.MeerRelaties, key: 'opacity', value: businessOpacity},
      {selector: '.link-percentage', key: 'opacity', value: businessOpacity}];
    this.changeStyles(elementStyleList);

    this.nodesGroup.selectAll('.node-filter-business').transition().attr('opacity', businessOpacity);
    this.nodesGroup.selectAll('.node-filter-person').selectAll('.node-type-filter-business').transition().attr('opacity', businessOpacity);
   }

  protected initializeComponent(): void {
    this.setNodeFactory(new HierarchicalSubjectNodeFactory());
    this.setLinkFactory(new HierarchicalSubjectLinkFactory());

    const layoutManager = new SplitGridLayoutManager(AbstractHierarchicalGraph.nodeRadius,
        AbstractHierarchicalGraph.horizontalStep, AbstractHierarchicalGraph.verticalStep);
    layoutManager.setOptimizationThreshold(this.maxOptimizedRows);
    this.setGridLayoutManager(layoutManager);
  }

  protected initializeVariables(): void {
    super.initializeVariables();

    this.profilePage = this.widget.options.profilePage;
    this.relationPage = this.widget.options.relationPage;
    this.entityPage = this.widget.options.entityPage;
  }

  protected initializePainters(): void {
    this.setNodePainter(new NodeDualSubjectPainter(this.topMargin, this.leftMargin, this.nodeTooltipGroup, this.subjectIconProvider,
            (node: Node<any, any>): void => this.pageNavigationUtilService.navigate(this.side, 'right', this.profilePage, node.data.model, null),
            (node: Node<any, any>): void => this.pageNavigationUtilService.navigate(this.side, 'right', this.relationPage, node.data.model, null)));
    this.setLinkPainter(new LinkRelationHierarchicalPainter(this.topMargin, this.leftMargin));
  }

  protected initializeStyles(): void {
    const businessItemVisible = (this.widget.options.hideBusinessItems ? false : true);

    this.changeBusinessVisibility({'businessItemVisible': businessItemVisible});
  }

  protected initializeLegendAndFilters(): void {
    const subjectRow = this.subject == null ? null :  this.subject.data;
    const subject = (subjectRow == null ? {type: 100} : {type: subjectRow['type'], name: subjectRow['naam'], subjectNr: subjectRow['finr']});
    const address = (subjectRow == null ? null : {address: subjectRow['straat'], city: subjectRow['postcode_plaats']});
    const entity = (subjectRow == null ? null : {entityNr: subjectRow['entiteitnr'], name: subjectRow['entiteitnaam'], page: this.entityPage});
    const businessItemVisible = (this.widget.options.hideBusinessItems ? false : true);

    setTimeout(() => {
      this.initialLegendSettings = {
        'subject': subject,
        'address': address,
        'entity': entity,
        'businessItemVisible': businessItemVisible
      };
    });
  }

  protected buildGrid(): void {
    super.buildGrid();
    this.gridLinks.forEach(link => link.presentation.possibleCrossingLinks = link.model.possibleCrossingLinks);
  }
}
