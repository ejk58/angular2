import {GridLayoutManager} from './grid-layout-manager';
import {AbstractGridLayoutManager} from './abstract-grid-layout-manager';
import {Node} from '../../../classes/nodes/node';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';

export class BruteForceGridLayoutManager extends AbstractGridLayoutManager implements GridLayoutManager {

  private static readonly defaultOptimizationThreshold = 500;

  private static readonly longHorizontalDistanceScoreModifier = 1;
  private static readonly longVerticalDistanceScoreModifier: number = 1;
  private static readonly crossedLinesScoreWeight: number = 25;
  private static readonly crossedNodesScoreWeight: number = 200;

  private optimizationThreshold: number = BruteForceGridLayoutManager.defaultOptimizationThreshold;

  public setOptimizationThreshold(threshold: number): void {
    this.optimizationThreshold = threshold != null ? threshold : this.optimizationThreshold;
  }

  protected improveGrid(nodes: Node<NodeHierarchicalModel, any>[], grid: Node<NodeHierarchicalModel, any>[][]): void {
    let newPenalty = this.calculatePenalty(grid, nodes);
    let penalty = newPenalty + 1;
    let count = 0;

    if (nodes.length <= this.optimizationThreshold) {
      while (count < 20 && newPenalty < penalty) {
        penalty = newPenalty;
        newPenalty = this.rearrangeNodesInGrid(grid, nodes);
        count++;
      }
    }
  }

  private rearrangeNodesInGrid(grid: Node<NodeHierarchicalModel, any>[][], nodes: Node<NodeHierarchicalModel, any>[]): number {
    let level, index, subIndex;
    let newPenalty;
    const maxLevel = grid.length;
    const maxRowSize = grid[0].length;
    let penalty = this.calculatePenalty(grid, nodes);

    for (level = 0; level < maxLevel; level++) {
      for (index = 0; index < (maxRowSize - 1); index++) {
        for (subIndex = index + 1; subIndex < maxRowSize; subIndex++) {
          if ((subIndex - index) > 1) {
            this.shiftNodesInGrid(grid, level, index, subIndex);
            newPenalty = this.calculatePenalty(grid, nodes);

            if (newPenalty <= penalty) {
              penalty = newPenalty;
            } else {
              this.shiftNodesInGrid(grid, level, subIndex, index);
            }
          }
        }
      }
    }

    for (level = 0; level < maxLevel; level++) {
      for (index = 0; index < (maxRowSize - 1); index++) {
        for (subIndex = index + 1; subIndex < maxRowSize; subIndex++) {
          if (grid[level][index] !== null || grid[level][subIndex] !== null) {
            this.swapNodesInGrid(grid, level, index, subIndex);
            newPenalty = this.calculatePenalty(grid, nodes);

            if (newPenalty <= penalty) {
              penalty = newPenalty;
            } else {
              this.swapNodesInGrid(grid, level, index, subIndex);
            }
          }
        }
      }
    }

    for (level = 1; level < maxLevel; level++) {
      for (index = 0; index < (maxRowSize - 1); index++) {
        if (grid[level][index] !== null && grid[level][index].model.parentLinks.length === 1) {
          const parentNode = grid[level][index].model.parentLinks[0].source;
          const parentLevel = parentNode.model.level;
          for (subIndex = 0; subIndex < maxRowSize; subIndex++) {
            if (index !== subIndex && grid[level][index] !== null) {
              this.swapNodesInGrid(grid, level, index, subIndex);
              this.swapNodesInGrid(grid, parentLevel, index, subIndex);
              newPenalty = this.calculatePenalty(grid, nodes);

              if (newPenalty < penalty) {
                penalty = newPenalty;
              } else {
                this.swapNodesInGrid(grid, level, index, subIndex);
                this.swapNodesInGrid(grid, parentLevel, index, subIndex);
              }
            }
          }
        }
      }
    }

    return penalty;
  }

  private calculatePenalty(grid: Node<NodeHierarchicalModel, any>[][], nodes: Node<NodeHierarchicalModel, any>[]): number {
    let penalty = 0;

    for (let index = 0; index < nodes.length; index++) {
      const node = nodes[index];
      for (let childIndex = 0; childIndex < node.model.childLinks.length; childIndex++) {
        const relation = node.model.childLinks[childIndex];
        penalty = penalty +
          this.calculateLinkDistancePenalty(relation, BruteForceGridLayoutManager.longVerticalDistanceScoreModifier) +
          this.calculateCrossedLinksPenalty(relation, BruteForceGridLayoutManager.crossedLinesScoreWeight) +
          this.calculateLongVerticalLinksPenalty(relation, grid, BruteForceGridLayoutManager.crossedNodesScoreWeight);
      }

      for (let siblingIndex = 0; siblingIndex < node.model.siblingLinks.length; siblingIndex++) {
        const relation = node.model.siblingLinks[siblingIndex];
        penalty = penalty +
          this.calculateLinkDistancePenalty(relation, BruteForceGridLayoutManager.longHorizontalDistanceScoreModifier);
      }
    }

    return penalty;
  }
}
