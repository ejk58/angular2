import {Node} from '../../../classes/nodes/node';

export class Group {

  public type: number;
  public name: string;
  public isEnabled: boolean;
  public nodes: Node<any, any>[];

  constructor(type: number, name: string) {
    this.type = type;
    this.name = name;
    this.nodes = [];
  }

  public addNode(node: Node<any, any>): void {
    this.nodes.push(node);
  }
}
