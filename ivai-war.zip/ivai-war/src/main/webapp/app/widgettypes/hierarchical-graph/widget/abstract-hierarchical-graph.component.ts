import {Component, Input, OnInit, AfterViewInit, ViewChild, ElementRef} from '@angular/core';
import {D3Service, D3, Selection} from 'd3-ng2-service';

import {Node} from '../../../classes/nodes/node';
import {NodeFactory} from '../../../classes/nodes/node-factory';
import {NodePainter} from '../../../classes/nodes/node-painter';
import {Link} from '../../../classes/links/link';
import {LinkFactory} from '../../../classes/links/link-factory';
import {LinkPainter} from '../../../classes/links/link-painter';

import {NodeType} from '../model/node-type';
import {Group} from '../model/group';
import {NodeHierarchicalModel} from '../model/node-hierarchical-model';
import {LinkHierarchicalModel} from '../model/link-hierarchical-model';
import {GridLayoutManager} from '../layout-manager/grid-layout-manager';
import {LinkDirection} from '../model/link-direction';

export abstract class AbstractHierarchicalGraph<P, R> implements OnInit, AfterViewInit {

  protected static readonly defaultMaxAllowedRows: number = 2000;
  protected static readonly defaultMaxOptimizedRows: number = 500;
  protected static readonly aspectRatio: number = 0.5;
  protected static readonly nodeRadius: number = 100;

  protected static readonly minimumWidth = 400;
  protected static readonly topMargin = 100;
  protected static readonly bottomMargin = 100;
  protected static readonly leftMargin = 50;
  protected static readonly rightMargin = 50;
  protected static readonly horizontalGap = 10;
  protected static readonly verticalGap = 80;
  protected static readonly horizontalStep = AbstractHierarchicalGraph.nodeRadius * 2 + AbstractHierarchicalGraph.horizontalGap;
  protected static readonly verticalStep = AbstractHierarchicalGraph.nodeRadius * 2 + AbstractHierarchicalGraph.verticalGap;

  @Input() widgetId: string;
  @Input() side: string;
  @Input() widget: any;

  @ViewChild('hierarchicalGraphCanvas') canvasElementRef: ElementRef;

  public zoomCanvas: Selection<any, any, any, any>;
  public zoomElement: Selection<any, any, any, any>;
  public size: {width: number; height: number};
  public subject: Node<NodeHierarchicalModel, P> = null;
  public home: {x: number, y: number};
  public maxAllowedRows: number;
  public maxOptimizedRows: number;
  public hasTooManyRows: boolean = false;
  public hasLoops: boolean = false;
  public hasUnconnectedNodes: boolean = false;
  public hasUnknownLinks: boolean = false;

  protected readonly d3: D3;
  protected canvas: Selection<any, any, any, any>;
  protected graph: Selection<any, any, any, any>;
  protected linksGroup: Selection<any, any, any, any>;
  protected nodesGroup: Selection<any, any, any, any>;
  protected nodeTooltipGroup: Selection<any, any, any, any>;

  protected nodeFactory: NodeFactory<NodeHierarchicalModel, P>;
  protected linkFactory: LinkFactory<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>;
  protected gridLayoutManager: GridLayoutManager;
  protected nodePainter: NodePainter<P>;
  protected linkPainter: LinkPainter<R>;

  protected allGroups: Group[];
  protected allNodes: Node<NodeHierarchicalModel, P>[];
  protected gridNodes: Node<NodeHierarchicalModel, P>[];
  protected allLinks: Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>[];
  protected gridLinks: Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>[];
  protected grid: Node<NodeHierarchicalModel, P>[][];

  protected maxLevel: number;
  protected maxRowSize: number;
  protected width: number;
  protected height: number;
  protected leftMargin: number;
  protected topMargin: number;

  protected legendType: string;
  protected filterType: string;
  protected initialLegendSettings: any;

  constructor(protected readonly d3Service: D3Service) {
    this.d3 = d3Service.getD3();
  }

  ngOnInit() {
    this.initializeComponent();
    this.initializeVariables();

    if (this.widget.data.length > 0 && !this.hasTooManyRows) {
      this.prepareNodeStructure();
      this.buildGrid();
    }
  }

  ngAfterViewInit() {
    if (this.widget.data.length > 0 && !this.hasTooManyRows) {
      this.drawGraph();
    }
  }

  public setNodeFactory(nodeFactory: NodeFactory<NodeHierarchicalModel, P>): void {
    this.nodeFactory = nodeFactory;
  }

  public setLinkFactory(linkFactory: LinkFactory<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>): void {
    this.linkFactory = linkFactory;
  }

  public setGridLayoutManager(gridLayoutManager: GridLayoutManager): void {
    this.gridLayoutManager = gridLayoutManager;
  }

  public setNodePainter(nodePainter: NodePainter<P>): void {
    this.nodePainter = nodePainter;
  }

  public setLinkPainter(linkPainter: LinkPainter<R>): void {
    this.linkPainter = linkPainter;
  }

  protected abstract initializeComponent(): void;

  protected initializeVariables(): void {
    this.maxAllowedRows = (this.widget.options.maxAllowedRows ? +this.widget.options.maxAllowedRows : AbstractHierarchicalGraph.defaultMaxAllowedRows);
    this.maxOptimizedRows = (this.widget.options.maxOptimizedRows ? this.widget.options.maxOptimizedRows : AbstractHierarchicalGraph.defaultMaxOptimizedRows);
    this.hasTooManyRows = (this.widget.data.length > this.maxAllowedRows);
    this.maxLevel = 0;
    this.maxRowSize = 1;

    this.allGroups = [];
    this.allNodes = [];
    this.gridNodes = [];
    this.allLinks = [];
    this.gridLinks = [];
    this.grid = [];
  }

  protected prepareNodeStructure(): void {
    this.buildGroups();
    this.buildPresentNodes();
    this.buildUnknownNodes();
    this.buildLinks();

    this.filterGridNodes();
    this.filterGridLinks();

    this.joinGroups();
    this.solveLoops();
    this.findMainSubject();
  }

  protected buildGroups(): void {
    // No groups on this level
  }

  protected buildPresentNodes(): void {
    this.widget.data
      .filter(row => row['source'] === row['target'])
      .forEach(row => this.allNodes.push(this.nodeFactory.build(row)));
  }

  protected buildUnknownNodes(): void {
    this.widget.data
      .filter(row => row['source'] !== row['target'])
      .map(row => [row['source'], row['target']])
      .reduce((nodeIds, nodeId) => nodeIds.concat(nodeId), [])
      .filter((nodeId, index, array) => index === array.indexOf(nodeId))
      .filter(nodeId => this.findNode(nodeId) == null)
      .forEach(nodeId => this.allNodes.push(this.nodeFactory.build({source: nodeId, naam: '?'})));
  }

  protected buildLinks(): void {
    this.widget.data
      .filter(row => row['source'] !== row['target'])
      .forEach(row => {
        const source = this.findNode(row['source']);
        const target = this.findNode(row['target']);

        if (source != null && target != null) {
          this.allLinks.push(this.linkFactory.build(source, target, row));
        }
      });
  }

  protected filterGridNodes(): void {
    this.gridNodes = this.allNodes.filter(node => node.model.isConnected() || node.isMain);
    this.hasUnconnectedNodes = this.allNodes.length > this.gridNodes.length;
  }

  protected filterGridLinks(): void {
    this.hasUnknownLinks = this.allLinks.some(link => link.model.isUnknownType);
    this.gridLinks = this.allLinks;
  }

  protected joinGroups(): void {
    // No groups on this level
  }

  protected solveLoops(): void {
    this.gridNodes.forEach(node =>  this.solveLoopsForNode(node));
  }

  protected findMainSubject(): void {
    this.gridNodes
      .filter(node => node.isMain)
      .forEach(node => this.subject = node);
  }

  protected findNode(id: string): Node<NodeHierarchicalModel, P> {
    for (let index = 0; index < this.allNodes.length; index++) {
      if (this.allNodes[index].id === id) {
        return this.allNodes[index];
      }
    }

    return null;
  }

  protected findLink(newLink: Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>):
      Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R> {
    const direction = newLink.model.direction;

    for (let index = 0; index < this.allLinks.length; index++) {
      const link = this.allLinks[index];

      if ((direction !== LinkDirection.sameLevel && link.hasMatchingLink(newLink.source, newLink.target)) ||
          (direction === LinkDirection.sameLevel && link.hasMatchingNodes(newLink.source, newLink.target))) {
        return link;
      }
    }

    return null;
  }

  private solveLoopsForNode(node: Node<NodeHierarchicalModel, P>): void {
    let loop = this.findLoop([node]);
    while (loop != null) {
      this.hasLoops = true;
      this.removeLoop(loop);
      loop = this.findLoop([node]);
    }
  }

  private findLoop(path: Node<NodeHierarchicalModel, P>[]): Node<NodeHierarchicalModel, P>[] {
    const tailNode = path[path.length - 1];
    const tailLinks = tailNode.model.childLinks;
    let loopPath = null;

    let index = 0;
    while (index < tailLinks.length && loopPath == null) {
      const nextNode = tailLinks[index].getOtherNode(tailNode);
      const nextPath = path.concat([nextNode]);
      if (path.some(node => node === nextNode)) {
        loopPath = nextPath.slice(path.indexOf(nextNode));
      }
      index++;
    }

    if (loopPath == null) {
      index = 0;
      while (index < tailLinks.length && loopPath == null) {
        const nextNode = tailLinks[index].getOtherNode(tailNode);
        const nextPath = path.concat([nextNode]);
        loopPath = this.findLoop(nextPath);
        index++;
      }
    }

    return loopPath;
  }

  private removeLoop(loopPathNodes: Node<NodeHierarchicalModel, P>[]): void {
    const loopPathLinks = this.getPathLinks(loopPathNodes);
    const weakestLink = this.findWeakestLink(loopPathLinks);

    if (!weakestLink.model.isLoop) {
      weakestLink.model.isLoop = true;
      weakestLink.classes.push('link-loop');
    }

    weakestLink.source.model.hideLoopLink(weakestLink);
    weakestLink.target.model.hideLoopLink(weakestLink);
  }

  private getPathLinks(path: Node<NodeHierarchicalModel, P>[]): Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>[] {
    return path
      .map((node, index, nodes) => node.model.childLinks // .concat(node.siblingLinks)
          .filter(link => index < (nodes.length - 1) && link.hasMatchingNodes(node, nodes[index + 1])))
      .map(links => links.length > 0 ? links[0] : null)
      .filter(link => link != null);
  }

  private findWeakestLink(links: Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R>[]): Link<Node<NodeHierarchicalModel, P>, LinkHierarchicalModel, R> {
    return links
        .reduce((weakestLink, link) => link.model.weight < weakestLink.model.weight ? link : weakestLink, links[0]);
  }

  protected buildGrid(): void {
    const gridLayout = this.gridLayoutManager.build(this.gridNodes);

    this.grid = gridLayout.nodes;
    this.maxLevel = gridLayout.maxLevel;
    this.maxRowSize = gridLayout.maxRowSize;
  }

  protected drawGraph(): void {
    this.calculateCanvasDimensions();
    this.drawBasicSvg();
    this.initializePainters();

    this.drawLinks();
    this.drawNodes();

    this.initializeStyles();
    this.initializeLegendAndFilters();

    this.enableZoomAndPan();
  }

  protected calculateCanvasDimensions(): void {
    const minimumWidth = this.maxRowSize * AbstractHierarchicalGraph.horizontalStep - AbstractHierarchicalGraph.horizontalGap +
      AbstractHierarchicalGraph.leftMargin +
      AbstractHierarchicalGraph.rightMargin;
    const minimumHeight = this.maxLevel * AbstractHierarchicalGraph.verticalStep - AbstractHierarchicalGraph.verticalGap +
      AbstractHierarchicalGraph.topMargin +
      AbstractHierarchicalGraph.bottomMargin;

    this.width = Math.max(minimumWidth, Math.floor(minimumHeight / AbstractHierarchicalGraph.aspectRatio), AbstractHierarchicalGraph.minimumWidth);
    this.height = Math.max(minimumHeight, Math.floor(this.width * AbstractHierarchicalGraph.aspectRatio));
    this.leftMargin = (this.width > minimumWidth) ?
      (AbstractHierarchicalGraph.leftMargin + Math.floor((this.width - minimumWidth) / 2)) : AbstractHierarchicalGraph.leftMargin;
    this.topMargin = AbstractHierarchicalGraph.topMargin;
  }

  protected drawBasicSvg(): void {
    this.canvas = this.d3.select(this.canvasElementRef.nativeElement)
      .append('svg')
      .attr('preserveAspectRatio', 'xMinYMin meet')
      .attr('viewBox', '0 0 ' + this.width + ' ' + this.height)
      .classed('hierarchical-graph', true);

    this.graph = this.canvas.append('g');
    this.linksGroup = this.graph.append('g').classed('link-group', true);
    this.nodesGroup = this.graph.append('g').classed('node-group', true);
    this.nodeTooltipGroup = this.graph.append('g').classed('node-tooltip-group', true);
  }

  protected drawLinks(): void {
   this.linkPainter.drawLinks(this.graph, this.linksGroup, this.gridLinks);
  }

  protected drawNodes(): void {
    this.nodePainter.drawNodes(this.graph, this.nodesGroup, this.gridNodes);
  }

  protected abstract initializePainters(): void;

  protected abstract initializeStyles(): void;

  protected abstract initializeLegendAndFilters(): void;

  protected enableZoomAndPan(): void {
    setTimeout(() => {
      this.zoomCanvas = this.canvas;
      this.zoomElement = this.graph;
      this.size = {width: this.width, height: this.height};
      this.home = this.subject == null ? null : {'x': this.subject.x + this.leftMargin, 'y': this.subject.y + this.topMargin };
    });
  }

  protected changeStyles(elementStyleList: {selector: string, key: string, value: number | string}[]): void {
    elementStyleList.forEach(elementStyle => {
      this.d3.select(this.canvasElementRef.nativeElement)
        .selectAll(elementStyle.selector)
        .transition()
        .style(elementStyle.key, elementStyle.value);
    });
  }

  protected changeClasses(elementClassList: {selector: string, name: string, present: boolean}[]): void {
    elementClassList.forEach(elementClass => {
      this.d3.select(this.canvasElementRef.nativeElement)
        .selectAll(elementClass.selector)
        .classed(elementClass.name, elementClass.present);
    });
  }
}
