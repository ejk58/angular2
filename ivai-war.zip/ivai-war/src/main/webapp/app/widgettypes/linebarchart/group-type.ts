export enum GroupType {
  Unknown = 'none',
  Line = 'line',
  Bar = 'bar',
  Point = 'point',
  Area = 'area',
  Spline = 'spline',
  AreaSpline = 'area-spline'
}
