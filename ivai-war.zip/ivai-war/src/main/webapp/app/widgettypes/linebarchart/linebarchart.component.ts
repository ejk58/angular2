import {AfterViewInit, Component, ElementRef, Input, OnDestroy, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {D3, D3Service} from 'd3-ng2-service';
import * as c3 from 'c3';
import {GroupType} from './group-type';
import {Group} from './group';
import {SplitViewState} from '../../services/split-view-state.service';
import {ChartEvent, Event, EventService, LegendEvent, TableEvent} from '../../services/event.service';
import {ChartService} from '../../commons/chart.service';
import {padStart} from '../../commons/inzicht-functions';
import {Side} from '../../commons/side';
import {Column} from '../../classes/column';
import {Unsubscriber} from '../../commons/unsubscriber';

type Tooltip = {
  tooltip?: {
    show: (args: { x: string | number | Date }) => void,
    hide: () => void
  }
};

@Component({
  selector: 'i-linebarchart',
  templateUrl: './linebarchart.component.html',
  styleUrls: ['./linebarchart.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})

export class LineBarChartComponent implements OnDestroy, OnInit, AfterViewInit {

  private static readonly chartPaddingRight: number = 20;
  private static readonly chartPaddingTop: number = 30;
  private static readonly defaultChartHeightPx = 320;

  private static readonly supportedColumnTypes: string[] = ['LINE', 'BAR', 'SPLINE', 'AREA', 'AREASPLINE', 'ASSPECIFIED'];
  private static readonly defaultXAxisUnit = 'NUMBER';
  private static readonly defaultYAxisUnit = 'MONEY';

  private static readonly xSuffix: string = '-x';
  private static readonly ySuffix: string = '-y';
  private static readonly y2Suffix: string = '-y2';

  public hasData: boolean;
  public hasChartData: boolean;

  @Input() side: Side;
  @Input() widgetId: string;
  @Input() widget: any;

  @ViewChild('lineBarChartCanvas') canvasElementRef: ElementRef;

  private readonly d3: D3;
  private chart: c3.ChartAPI & Tooltip;

  private groupList: Group[];

  private dataList: (string | number | boolean)[][];
  private typeList: { [key: string]: string };
  private stackedBarList: string[];
  private stackedAreaList: string[];
  private hideLegendList: string[];
  private xAxisList: { [key: string]: string };
  private yAxisList: { [key: string]: string };
  private nameList: { [key: string]: string };
  private classList: { [key: string]: string };

  private xAxisUnit: string;
  private xAxisUnitPresentation: string;
  private yAxisUnit: string;
  private y2AxisUnit: string;
  private xAxisValues: (string | number)[];
  private xAxisValueMostRight: string;
  private xAxisValueWithEmphasis: string;
  private yAxisTickValues: { [key: number]: string };
  private xAxis: any;
  private yAxis: any;
  private y2Axis: any;
  private colors: string[];
  private groupNames: string[];
  private chartPaddingLeft: number;
  private chartPaddingRight: number;
  private chartHeightPx: number;

  private showLegend: boolean;
  private stackBars: boolean;
  private stackAreas: boolean;
  private rotateAxes: boolean;
  private enableZoom: boolean;
  private showGridXAxis: boolean;
  private showTooltip: boolean;

  private hasEventListeners: boolean;

  private readonly createTooltip = function (data, defaultTitleFormat, defaultValueFormat, color) {
    const groupKey = data[0].name;
    const nodeIndex = data[0].index;
    const groups = this.groupList.filter(group => group.isSameKey(groupKey));
    const node = (groups.length > 0 && groups[0].nodes.length > nodeIndex) ? groups[0].nodes[nodeIndex] : null;
    const dataColor = color(data[0].id);
    const yAxisTickValuesPresent = Object.keys(this.yAxisTickValues).length > 0 && this.yAxisTickValues.constructor === Object;
    const tooltipData = yAxisTickValuesPresent ? data[0].value : defaultValueFormat(data[0].value);
    const dataValue = node && node.tooltip ? node.tooltip : tooltipData;

    return `<div style="
        background-color:${dataColor};
        color: white;
        padding-left: 15px;
        padding-right: 15px;
        border-radius: 3px">${dataValue}</div>`;
  };

  constructor(private readonly d3Service: D3Service,
              private readonly chartService: ChartService,
              private readonly eventService: EventService,
              private readonly splitViewState: SplitViewState,
              private readonly unsubscriber: Unsubscriber) {
    this.d3 = d3Service.getD3();
  }

  ngOnInit(): void {
    this.initializeVariables();

    if (this.hasData) {
      this.createGroupList();
      this.processXAxisValueMostRight();
    }

    if (this.hasChartData) {
      this.prepareData();
      this.createChartData();
      this.createChartAxes();
    }

    this.subscribeToHasListeners();
    this.intializeEventListeners();
  }

  ngAfterViewInit(): void {
    if (this.hasChartData) {
      this.drawChart();
    }
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
    this.removeEventListeners();
  }

  private initializeVariables(): void {
    this.hasData = this.widget.data.length > 0;

    this.xAxisUnit = this.widget.options.xAxisUnit ? this.widget.options.xAxisUnit : LineBarChartComponent.defaultXAxisUnit;
    this.xAxisUnitPresentation = this.widget.options.xAxisUnitPresentation;
    this.xAxisValues = this.widget.options.xAxisValues ? JSON.parse(this.widget.options.xAxisValues) : [];
    this.xAxisValueMostRight = this.widget.options.xAxisValueMostRight;
    this.xAxisValueWithEmphasis = this.widget.options.xAxisValueWithEmphasis;

    this.yAxisUnit = this.widget.options.yAxisUnit ? this.widget.options.yAxisUnit : LineBarChartComponent.defaultYAxisUnit;
    this.yAxisTickValues = this.widget.options.yAxisTickValues ? JSON.parse(this.widget.options.yAxisTickValues) : {};
    this.y2AxisUnit = this.widget.options.y2AxisUnit ? this.widget.options.y2AxisUnit : LineBarChartComponent.defaultYAxisUnit;

    this.chartHeightPx = this.widget.options.chartHeightPx ? this.widget.options.chartHeightPx : LineBarChartComponent.defaultChartHeightPx;
    this.colors = this.widget.options.colors ? JSON.parse(this.widget.options.colors) : this.chartService.chartColors;
    this.groupNames = this.widget.options.groupNames ? JSON.parse(this.widget.options.groupNames) : [];

    this.showLegend = this.widget.options.showLegend !== 'false';
    this.showTooltip = this.widget.options.showTooltip !== 'false';
    this.stackBars = this.widget.options.stackBars === 'true';
    this.stackAreas = this.widget.options.stackAreas === 'true';
    this.rotateAxes = this.widget.options.rotateAxes === 'true';
    this.enableZoom = false;
    this.showGridXAxis = this.xAxisUnitPresentation === 'YEAR';
    this.hideLegendList = [];
  }

  private createGroupList(): void {
    this.groupList = [];

    if (this.widget.options.groupNames) {
      this.groupNames.forEach((groupName, index) => {
        this.addToGroupList(this.createGroup(this.groupNames[index], null, null));
      });
    }

    Object.keys(this.widget.options.columns)
      .filter(column => Column.isVisible(this.widget.options.columns[column]['behaviour']) && this.checkColumnType(this.widget.options.columns[column]['columnType']))
      .forEach(column => {
        this.addNodesToGroup(column);
      });

    if (this.widget.options.groupNames && this.widget.options.colors) {
      // Only groups with data should be shown
      this.groupList = this.groupList.filter(group => group.nodes.length > 0);
      // Find corresponding color
      const colorGroups = [];
      this.groupList.forEach(group => {
        const colorIndex = this.groupNames.indexOf(group.name);
        colorGroups.push(this.colors[colorIndex] ? this.colors[colorIndex] : []);
      });
      this.colors = [...colorGroups];
    }

    this.hasChartData = this.groupList.length > 0 && this.groupList.some(group => group.nodes.length > 0);
  }

  private addNodesToGroup(column: any): void {
    const columnType = this.widget.options.columns[column]['columnType'];

    for (let index = 0; index < this.widget.data.length; index++) {
      const node = this.widget.data[index][column];
      const groupType = columnType === 'ASSPECIFIED' ? node.type : columnType;
      const groupName = node.hasOwnProperty('group') ? node.group : this.widget.options.columns[column].label;
      const groupKey = node.hasOwnProperty('group') ? node.group : column;
      const group = this.findOrCreateGroup(groupName, groupType, groupKey);

      group.addNode(node);
    }
  }

  private checkColumnType(columnType: string): boolean {
    return LineBarChartComponent.supportedColumnTypes.some(supportedColumnType => supportedColumnType === columnType);
  }

  private findOrCreateGroup(groupName: string, groupType: string, groupKey: string): Group {
    const group = this.groupList.find(group => group.isSameGroup(groupName, groupType));
    return group != null ? this.updateGroup(group, groupType) : this.addToGroupList(this.createGroup(groupName, groupType, groupKey));
  }

  private updateGroup(group: Group, groupType: string): Group {
    group.setType(groupType);
    return group;
  }

  private createGroup(groupName: string, groupType: string, groupKey: string): Group {
    return new Group(groupName, groupType, groupKey);
  }

  private addToGroupList(group: Group): Group {
    this.groupList.push(group);
    return group;
  }

  private processXAxisValueMostRight(): void {
    if (this.xAxisValueMostRight) {
      const xAxisValuesWithData: (string | number)[] = [];
      this.groupList.forEach(group => {
        group.nodes.forEach(node => {
          if (xAxisValuesWithData.indexOf(node.x) === -1) {
            xAxisValuesWithData.push(node.x);
          }
        });
      });
      // Only xAxisValues with data should be shown (even override them when configured in widget.options)
      this.xAxisValues = [...xAxisValuesWithData];
      // Put the xAxisValueMostRight at the end
      this.xAxisValues.sort(xAxisValue => xAxisValue !== this.xAxisValueMostRight ? -1 : 0);
    }
  }

  private prepareData(): void {
    if (this.xAxisValues && this.xAxisValues.length > 0) {
      this.groupList.forEach(group => {

        let nodes = group.nodes;
        group.nodes = [];

        for (let index = 0; index < this.xAxisValues.length; index++) {
          const nodesOnAxis = nodes.filter(node => node.x === this.xAxisValues[index]);

          if (nodesOnAxis.length > 0) {
            nodesOnAxis.forEach(node => group.addNode(node));
            nodes = nodes.filter(node => node.x !== this.xAxisValues[index]);
          } else {
            group.addNode({x: this.xAxisValues[index], y: null});
          }
        }

        nodes.forEach(node => group.addNode(node));
      });
    }

    if (this.xAxisUnit === 'DATE' && this.xAxisUnitPresentation === 'YEAR') {
      this.prepareDataForDateToYearPresentationOnXAxis();
    }

    if ((this.xAxisUnit === 'QUARTER' || this.xAxisUnit === 'MONTH') && this.xAxisUnitPresentation === 'YEAR') {
      this.prepareDataForPeriodToYearPresentationOnXAxis();
    }
  }

  private prepareDataForDateToYearPresentationOnXAxis() {
    const timestampsAsDates: Date[] = this.groupList[0].nodes.map(node => new Date(node.x));
    timestampsAsDates.sort((date1, date2) => date1.getTime() - date2.getTime());
    const minDate: Date = timestampsAsDates[0];
    const minYear: number = minDate.getFullYear();
    const maxDate: Date = timestampsAsDates[timestampsAsDates.length - 1];
    const maxYear: number = maxDate.getFullYear();

    // Add nodes for missing first and/or last day of the year when all data is in one year
    if (minYear === maxYear) {
      if (minDate.getMonth() !== 0 || minDate.getDate() !== 1) {
        this.groupList.forEach(group => {
          const firstDayOfTheYear: Date = new Date(minYear + '-01-01');
          group.addNode({x: firstDayOfTheYear.getTime(), y: null});
        });
      }

      if (maxDate.getMonth() !== 11 || maxDate.getDate() !== 31) {
        this.groupList.forEach(group => {
          const lastDayOfTheYear: Date = new Date(minYear + '-12-31');
          group.addNode({x: lastDayOfTheYear.getTime(), y: null});
        });
      }
    }
  }

  private prepareDataForPeriodToYearPresentationOnXAxis() {
    const currentYearPeriods: number[] = this.groupList[0].nodes.map(node => Number(node.x));
    currentYearPeriods.sort((value1: number, value2: number) => value1 - value2);
    const numberOfPeriods: number = this.xAxisUnit === 'QUARTER' ? 4 : 12;
    const allPossibleYearPeriods: number[] = this.createAllPossibleYearPeriods(currentYearPeriods, numberOfPeriods);
    const missingYearPeriods: number[] = allPossibleYearPeriods.filter(yearPeriod => currentYearPeriods.indexOf(yearPeriod) === -1);

    // Add nodes for missing year-periods
    missingYearPeriods.forEach(yearPeriod => {
      this.groupList.forEach(group => {
        group.addNode({x: yearPeriod, y: null});
      });
    });

    // Convert year-periods to dates
    this.groupList.forEach(group => {
      group.nodes.forEach(node => {
        if (this.xAxisUnit === 'QUARTER') {
          node.x = new Date(this.convertYearQuarterToDate(node.x));
        } else {
          node.x = new Date(this.convertYearMonthToDate(node.x));
        }
      });
    });
  }

    /**
   * Create all possible year periods between the minimum and the maximum year-period.
   * When minimum and maximum year are equal, create year periods for a full year.
   *
   * @param yearPeriods sorted list of year-periods (originating from the original data)
   * @param numberOfPeriods number of periods (4 in case of quarters, 12 in case of months)
   */
  private createAllPossibleYearPeriods(yearPeriods: number[], numberOfPeriods: number): number[] {
    const minYearPeriod: number = yearPeriods[0];
    const [minYear, minPeriod] = this.splitYearPeriod(minYearPeriod);
    const maxYearPeriod: number = yearPeriods[yearPeriods.length - 1];
    const [maxYear, maxPeriod] = this.splitYearPeriod(maxYearPeriod);
    const allPossibleYearPeriods: number[] = [];

    for (let year = minYear; year <= maxYear; year++) {
      if (year === minYear && year === maxYear) {
        allPossibleYearPeriods.push(...this.createPossibleYearPeriodsForYear(year, 1, numberOfPeriods));
      } else if (year === minYear) {
        allPossibleYearPeriods.push(...this.createPossibleYearPeriodsForYear(year, minPeriod, numberOfPeriods));
      } else if (year !== maxYear) {
        allPossibleYearPeriods.push(...this.createPossibleYearPeriodsForYear(year, 1, numberOfPeriods));
      } else if (year === maxYear) {
        allPossibleYearPeriods.push(...this.createPossibleYearPeriodsForYear(year, 1, maxPeriod));
      }
    }
    return allPossibleYearPeriods;
  }

  private createPossibleYearPeriodsForYear(year: number, minPeriod: number, maxPeriod: number): number[] {
    const possibleYearPeriods: number[] = [];
    for (let period = minPeriod; period <= maxPeriod; period++) {
      possibleYearPeriods.push(Number(year + padStart(period, 2, '0')));
    }
   return possibleYearPeriods;
  }

  /**
   * Convert a yearQuarter to a string date (yyyy-mm-01).
   *
   * @param yearQuarter combination of a four digit year and a two digit quarter (01-04)
   */
  private convertYearQuarterToDate(yearQuarter: number | string): string {
    const [year, quarter] = this.splitYearPeriod(yearQuarter);
    const month = this.calculateMonthFromQuarter(quarter);
    return year + '-' + padStart(month, 2, '0') + '-01';
  }

  /**
   * Convert a yearMonth to a string date (yyyy-mm-01).
   *
   * @param yearMonth combination of a four digit year and a two digit month (01-12)
   */
  private convertYearMonthToDate(yearMonth: number | string): string {
    const [year, month] = this.splitYearPeriod(yearMonth);
    const twoDigitMonth: string = padStart(month, 2, '0');
    return year + '-' + twoDigitMonth + '-01';
  }

  /**
   * Split a yearPeriod into a year and a period (quarter or month).
   * Example: 201601 splits into [2016, 1] where year = 2016 and period = 1.
   *
   * @param yearPeriod combination of a four digit year and a two digit period (quarter or month)
   */
  private splitYearPeriod(yearPeriod: number | string): [number, number] {
    const yearPeriodAsString: string = String(yearPeriod);
    return [
      Number(yearPeriodAsString.substring(0, 4)),
      Number(yearPeriodAsString.substring(4, 6))
    ];
  }

  private createHideLegendList(suffix: string): void {
    Object.keys(this.widget.options.columns)
      .filter(column => this.widget.options.columns[column]['hideLegendItem'] === 'true')
      .forEach(column => {
        if (this.hideLegendList.indexOf(column + suffix) === -1) {
          this.hideLegendList.push(column + suffix);
        }
      });
  }

  private addAdditionalAreaClasses(suffix: string): void {
    Object.keys(this.widget.options.columns)
      .filter(column => this.widget.options.columns[column]['areaClass'])
      .forEach(column => {
        this.classList[column + suffix] = this.widget.options.columns[column]['areaClass'];
      });
  }

  private createChartData(): void {
    this.dataList = [];
    this.typeList = {};
    this.xAxisList = {};
    this.yAxisList = {};
    this.nameList = {};
    this.classList = {};
    this.stackedBarList = [];
    this.stackedAreaList = [];

    let groupsOnY2Axis = [];
    if (this.widget.options.groupsOnY2Axis) {
      groupsOnY2Axis = JSON.parse(this.widget.options.groupsOnY2Axis);
    }

    this.groupList.forEach(group => {
      const ySuffix = groupsOnY2Axis.indexOf(group.name) === -1 ? LineBarChartComponent.ySuffix : LineBarChartComponent.y2Suffix;
      const dataXRow = [group.key + LineBarChartComponent.xSuffix, ...group.nodes.map(node => node.x)];
      const dataYRow = [group.key + ySuffix, ...group.nodes.map(node => node.y)];

      this.dataList.push(dataXRow);
      this.dataList.push(dataYRow);
      this.typeList[group.key + ySuffix] = group.getType();
      this.xAxisList[group.key + ySuffix] = group.key + LineBarChartComponent.xSuffix;
      this.yAxisList[group.key + ySuffix] = ySuffix.substr(1);
      this.nameList[group.key + ySuffix] = group.name;

      if (this.stackBars && group.type === GroupType.Bar) {
        this.stackedBarList.push(group.key + ySuffix);
      } else if (this.stackAreas && (group.type === GroupType.AreaSpline || group.type === GroupType.Area)) {
        this.stackedAreaList.push(group.key + ySuffix);
      }

      this.createHideLegendList(ySuffix);
      this.addAdditionalAreaClasses(ySuffix);
    });

    this.showLegend = this.showLegend && (this.dataList.length > 1);
  }

  private createChartAxes(): void {
    this.createXAxis();

    this.yAxis = this.chartService.createYAxis(this.yAxisUnit, this.yAxisTickValues, this.widget.options.yAxisLabel);
    this.chartPaddingLeft = this.calculateYAxisPadding(LineBarChartComponent.ySuffix, this.yAxis);

    if (Object.keys(this.yAxisList).some(ya => this.yAxisList[ya] === 'y2')) {
      this.y2Axis = this.chartService.createYAxis(this.y2AxisUnit, undefined, this.widget.options.y2AxisLabel);
      this.chartPaddingRight = this.calculateYAxisPadding(LineBarChartComponent.y2Suffix, this.y2Axis);
    }
  }

  private createXAxis(): void {
    if (this.xAxisUnit === 'DATE') {
      const type = 'timeseries';
      if (this.xAxisUnitPresentation === 'YEAR') {
        const tickValues: string[] = this.createTickValuesForDateToYearPresentationOnXAxis();
        const tick = {format: '%Y', rotate: 0, values: tickValues};
        this.xAxis = {
          type: type,
          tick: tick,
          show: true
        };
      } else {
        const tick = {format: '%e %b %y', rotate: 0};
        this.xAxis = {
          type: type,
          tick: tick,
          labels: this.groupList[0].nodes.map(node => node.x),
          show: true
        };
      }
    } else if ((this.xAxisUnit === 'QUARTER' || this.xAxisUnit === 'MONTH') && this.xAxisUnitPresentation === 'YEAR') {
      const type = 'timeseries';
      const numberOfPeriods = this.xAxisUnit === 'QUARTER' ? 4 : 12;
      const tickValues: string[] = this.createTickValuesForPeriodToYearPresentationOnXAxis(numberOfPeriods);
      const tick = {format: '%Y', rotate: 0, values: tickValues};
      this.xAxis = {
        type: type,
        tick: tick,
        show: true
      };
    } else {
      const type = 'category';
      const categories = this.xAxisValues && this.xAxisValues.length > 0 ? this.xAxisValues : null;
      const tick = {centered: true};
      this.xAxis = {
        type: type,
        categories: categories,
        tick: tick,
        labels: this.groupList[0].nodes.map(node => node.x),
        show: true
      };
    }
  }

  /**
   * Create tickValues when converting from date to year for presentation on x-axis.
   * There must be a tick value for every year (because the x-axis unit is already a date).
   */
  private createTickValuesForDateToYearPresentationOnXAxis(): string[] {
    const timestampsAsDates: Date[] = this.groupList[0].nodes.map(node => new Date(node.x));
    const minDate: Date = new Date(Math.min.apply(null, timestampsAsDates));
    const minYear: number = minDate.getFullYear();
    const maxDate: Date = new Date(Math.max.apply(null, timestampsAsDates));
    const maxYear: number = maxDate.getFullYear();

    const tickValues: string[] = [];
    for (let year = minYear; year <= maxYear; year++) {
      if (year === minYear && year === maxYear) {
        tickValues.push(year + '-01-01');
      } else if (year === minYear) {
        if (minDate.getMonth() === 0 && minDate.getDate() === 1) {
          tickValues.push(year + '-01-01');
        }
      } else {
        tickValues.push(year + '-01-01');
      }
    }
    return tickValues;
  }

  /**
   * Create tickValues when converting from period (quarter or month) to year for presentation on x-axis.
   * The number of tick values must be equal to the number of periods that are shown in the chart.
   *
   * @param numberOfPeriods number of periods (4 in case of quarters, 12 in case of months)
   */
  private createTickValuesForPeriodToYearPresentationOnXAxis(numberOfPeriods: number): string[] {
    const dates: Date[] = this.groupList[0].nodes.map(node => node.x);
    const minDate: Date = new Date(Math.min.apply(null, dates));
    const minYear: number = minDate.getFullYear();
    const maxDate: Date = new Date(Math.max.apply(null, dates));
    const maxYear: number = maxDate.getFullYear();

    let minPeriod: number;
    let maxPeriod: number;
    if (this.xAxisUnit === 'QUARTER') {
      minPeriod = this.calculatePeriodFromMonth(minDate.getMonth());
      maxPeriod = this.calculatePeriodFromMonth(maxDate.getMonth());
    } else if (this.xAxisUnit === 'MONTH') {
      minPeriod = minDate.getMonth() + 1;
      maxPeriod = maxDate.getMonth() + 1;
    }

    const tickValues: string[] = [];
    for (let year = minYear; year <= maxYear; year++) {
      if (year === minYear) {
        if (minPeriod === 1) {
          tickValues.push(year + '-01-01');
          tickValues.push(...this.createEmptyTickValues(numberOfPeriods - 1));
        } else {
          tickValues.push(...this.createEmptyTickValues(numberOfPeriods - minPeriod + 1));
        }
      } else if (year !== maxYear) {
        tickValues.push(year + '-01-01');
        tickValues.push(...this.createEmptyTickValues(numberOfPeriods - 1));
      } else if (year === maxYear) {
        tickValues.push(year + '-01-01');
        tickValues.push(...this.createEmptyTickValues(maxPeriod - 1));
      }
    }
    return tickValues;
  }

  private calculatePeriodFromMonth(month: number): number {
    return month === 0 ? 1 : month === 3 ? 2 : month === 6 ? 3 : month === 9 ? 4 : undefined;
  }
  private calculateMonthFromQuarter(quarter: number): number {
    return quarter === 1 ? 1 : quarter === 2 ? 4 : quarter === 3 ? 7 : quarter === 4 ? 10 : undefined;
  }

  private createEmptyTickValues(numberOfEmptyTickValues: number): string[] {
    return new Array(numberOfEmptyTickValues).fill(null);
  }

  private calculateYAxisPadding(suffix: string, axis: any): number {
    const yDataList: (string | number | boolean)[][] = this.dataList
      .filter(data => data.length > 0 && (data[0] as string).endsWith(suffix))
      .map(data => data.slice(1));
    const yDataListValues = [].concat(...yDataList); // flattened array
    return this.chartService.calcAxisLabelWidth(yDataListValues, axis);
  }

  private drawChart(): void {
    this.chart = c3.generate({
      bindto: this.d3.select(this.canvasElementRef.nativeElement),
      padding: {
        top: LineBarChartComponent.chartPaddingTop,
        left: this.chartPaddingLeft,
        right: typeof this.y2Axis === 'undefined' ? LineBarChartComponent.chartPaddingRight : this.chartPaddingRight
      },
      data: {
        xs: this.xAxisList,
        columns: this.dataList,
        types: this.typeList,
        groups: [this.stackedBarList, this.stackedAreaList],
        axes: this.yAxisList,
        names: this.nameList,
        classes: this.classList,
        order: null,
        onmouseover: (dataPoint) => this.onMouseOverDataPoint(dataPoint),
        onmouseout: (dataPoint) => this.onMouseOutDataPoint(dataPoint)
      },
      spline: {
        interpolation: {
          type: 'monotone'
        }
      },
      color: {
        pattern: this.colors
      },
      size: {
        height: this.chartHeightPx
      },
      zoom: {
        enabled: this.enableZoom
      },
      axis: {
        x: this.xAxis,
        y: this.yAxis,
        y2: this.y2Axis,
        rotated: this.rotateAxes
      },
      grid: {
        x: {
          show: this.showGridXAxis
        },
        y: {
          show: true,
          lines: [{value: 0, class: 'solid-axis'}]
        }
      },
      tooltip: {
        show: this.showTooltip,
        grouped: false,
        contents: this.createTooltip.bind(this),
        position: (data, width, height, element) => {
          const top = this.d3.mouse(element)[1] + 15;
          const left = this.d3.mouse(element)[0];
          return {top: top, left: left};
        }
      },
      legend: {
        show: this.showLegend,
        hide: this.hideLegendList,
        position: 'inset',
        inset: {
          anchor: 'top-left',
          x: 0,
          y: -LineBarChartComponent.chartPaddingTop,
          step: 1
        }
      },
      bar: {
        width: {
          ratio: 0.8
        }
      }
    });

    if (this.xAxisValueWithEmphasis) {
      this.addEmphasisToXAxisValue(this.xAxisValueWithEmphasis);
    }

    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(sizes => {
        if (sizes != null) {
          this.chart.resize();
        }
      });
  }

  private addEmphasisToXAxisValue(xAxisValue: string): void {
    this.d3.selectAll('.c3-axis-x .tick text')
      .filter((d, i, nodes) => this.d3.select(nodes[i]).text() === xAxisValue)
      .classed('value-with-emphasis', true);
  }

  private subscribeToHasListeners(): void {
    this.eventService.hasListeners(this.widget.name, this.side, ChartEvent.enterTooltip, ChartEvent.leaveTooltip)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(hasListeners => this.hasEventListeners = hasListeners);
  }

  private intializeEventListeners(): void {
    if (this.widget.options.eventSourceWidget) {
      this.eventService.listen(this.widget.options.eventSourceWidget, this.widget.name, this.side, LegendEvent.enableItem, this.showGroup.bind(this));
      this.eventService.listen(this.widget.options.eventSourceWidget, this.widget.name, this.side, LegendEvent.disableItem, this.hideGroup.bind(this));
      this.eventService.listen(this.widget.options.eventSourceWidget, this.widget.name, this.side, TableEvent.enterRow, this.displayTooltip.bind(this));
      this.eventService.listen(this.widget.options.eventSourceWidget, this.widget.name, this.side, TableEvent.leaveRow, this.hideTooltip.bind(this));
    }
  }
  private removeEventListeners(): void {
    if (this.widget.options.eventSourceWidget) {
      this.eventService.remove(this.widget.options.eventSourceWidget, this.widget.name, this.side, LegendEvent.enableItem);
      this.eventService.remove(this.widget.options.eventSourceWidget, this.widget.name, this.side, LegendEvent.disableItem);
      this.eventService.remove(this.widget.options.eventSourceWidget, this.widget.name, this.side, TableEvent.enterRow);
      this.eventService.remove(this.widget.options.eventSourceWidget, this.widget.name, this.side, TableEvent.leaveRow);
    }
  }

  private showGroup(groupName: string): void {
    const groups = this.findDataGroupnamesByLabel(groupName);
    this.chart.show(groups);
  }

  private hideGroup(groupName: string): void {
    const groups = this.findDataGroupnamesByLabel(groupName);
    this.chart.hide(groups);
  }

  private findDataGroupnamesByLabel(groupName: string): string[] {
    const dataNames = this.chart.data.names();
    return Object.keys(dataNames).filter(key => dataNames[key] === groupName);
  }

  private displayTooltip(value: number | string | Date): void {
    const args: any = {x: value};
    this.chart.tooltip.show(args);
  }

  private hideTooltip(): void {
    this.chart.tooltip.hide();
  }

  private onMouseOverDataPoint(dataPoint: any): void {
    if (this.hasEventListeners) {
      // Only broadcast event when somebody is listening
      const event = new Event(ChartEvent.enterTooltip, dataPoint.x);
      this.eventService.broadcast(this.widget.name, this.side, event);
    }
  }

  private onMouseOutDataPoint(dataPoint: any): void {
    if (this.hasEventListeners) {
      // Only broadcast event when somebody is listening
      const event = new Event(ChartEvent.leaveTooltip, dataPoint.x);
      this.eventService.broadcast(this.widget.name, this.side, event);
    }
  }

}
