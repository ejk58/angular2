import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {HistMoneyLineChartComponent} from './histmoney-linechart';
import {XYDataElement} from './xy-data-element';


@Component({
  selector: 'i-selectable-linechart',
  templateUrl: './selectable-linechart.component.html',
  styleUrls: ['./selectable-linechart.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class SelectableLineChartComponent extends HistMoneyLineChartComponent implements OnInit {
  public allDataSets = [];
  legends: string[] = [];

  selectedOption1: string = '';
  selectedOption2: string = '';

  ngOnInit() {
    this.showLegends = false;
    if (this.options['defaultValueFirstDropdown']) {
      this.selectedOption1 = this.options['defaultValueFirstDropdown'];
    }
    if (this.options['defaultValueSecondDropdown']) {
      this.selectedOption2 = this.options['defaultValueSecondDropdown'];
    }
    super.ngOnInit();
  }

  createDataArray(): void {
    let legend: string;
    let xvalue: number;
    let xtype: string;
    let yvalue: number;
    let ytype: string;
    Object.keys(this.data).forEach(dataKey => {
      Object.keys(this.columns).forEach(columnKey => {
        // TODO zodra client 1 weg is een nieuw columnType maken zodat dit robuuster kan. b.v. columnType = 'SET' .
        if (this.columns[columnKey]['columnType'] === 'STRING' && this.columns[columnKey]['columnName'].toLowerCase() === 'post') {
          legend = this.data[dataKey][this.columns[columnKey]['columnName']];
          this.legends.push(legend);
        } else if (this.columns[columnKey]['columnType'] === 'HISTORYMONEY') {
          Object.keys(this.data[dataKey][this.columns[columnKey]['columnName']]).forEach(subColumnKey => {
            if (subColumnKey === 'Jaar')  {
              xvalue = this.data[dataKey][this.columns[columnKey]['columnName']][subColumnKey];
              xtype = 'YEAR';
            } else if (subColumnKey === 'Waarde') {
              yvalue = this.data[dataKey][this.columns[columnKey]['columnName']][subColumnKey];
              ytype = this.getDataType(this.data[dataKey]['SOORT_DATA']);
              const xyDataElement: XYDataElement = new XYDataElement(legend, xvalue, yvalue, xtype, ytype);
              this.allDataSets.push(xyDataElement);
            }
          });
        }
      });
    });

    this.histMoneyData = this.filterDataSets();
  }

  getDataType(soortData: string): string {
    switch (soortData) {
      case 'bedrag': {
        return 'MONEY';
      }
      case 'percentage': {
        return 'PERCENTAGE';
      }
      case 'getal': {
        return 'NUMBER';
      }
      default: {
        return 'STRING';
      }
    }
  }

  onChangeChartName1(selectOpt?: any) {
    this.trackingService.trackEvent('filter',
      'Filter:' + this.side + '/widget:' + this.widgetId +
      'soort:/1=' + selectOpt + '/2=' + this.selectedOption2, null, null);
    this.selectedOption1 = selectOpt;
    this.filterDataSetsAndRedrawChart();
  }

  onChangeChartName2(selectOpt?: any) {
    this.trackingService.trackEvent('filter',
      'Filter:' + this.side + '/widget:' + this.widgetId +
      'soort:/1=' + this.selectedOption1 + '/2=' + selectOpt, null, null);
    this.selectedOption2 = selectOpt;
    this.filterDataSetsAndRedrawChart();
  }

  getLegends(selectBox: string): string[] {
    if (selectBox === 'first') {
      return this.legends.filter(f => f !== this.selectedOption2);
    } else if (selectBox === 'second') {
      return this.legends.filter(f => f !== this.selectedOption1);
    } else {
      return this.legends;
    }
  }

  private filterDataSets(): any {
    const set1 = this.allDataSets.filter(item => item.setName === this.selectedOption1);
    const set2 = this.allDataSets.filter(item => item.setName === this.selectedOption2);
    return [ ...set1, ...set2];
  }

  private filterDataSetsAndRedrawChart(): void {
    this.data = this.filterDataSets();
    if (this.data.length > 0) {
      this.createDataset();
      this.createAxes();
      this.drawLinechart();
    }
  }

}
