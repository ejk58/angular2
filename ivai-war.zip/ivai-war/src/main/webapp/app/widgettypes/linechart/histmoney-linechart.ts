import {Component, OnInit} from '@angular/core';
import {LinechartComponent} from './linechart.component';
import {Column} from '../../classes/column';
import {XYDataElement} from './xy-data-element';

@Component({
  selector: 'i-histmoney-linechart',
  templateUrl: './linechart.component.html'
})

export class HistMoneyLineChartComponent extends LinechartComponent implements OnInit {
  public histMoneyColumns: { [k: string]: any } = {};
  public histMoneyData = [];

  ngOnInit() {
    this.recreateColumns();
    this.createDataArray();
    this.columns = this.histMoneyColumns;
    this.data = this.histMoneyData;
    this.showExtraYAxis = true;
    this.yAxisColored = true;

    super.ngOnInit();
  }

  recreateColumns(): void {
    this.histMoneyColumns['setName'] = new Column('setName', 'GROUP', 'Group');
    this.histMoneyColumns['XYVALUE'] = new Column('XYVALUE', 'COORDINATES', null);
    this.histMoneyColumns['XYVALUE']['composite'] = true;
  }

  createDataArray(): void {
    let legend: string;
    let xvalue: number;
    let xtype: string;
    let yvalue: number;
    let ytype: string;
    Object.keys(this.data).forEach(dataKey => {
      Object.keys(this.columns).forEach(columnKey => {
        // zodra client 1 weg is een nieuw type maken zodat dit robuuster kan. zoiets als columnType = 'SET' .
        if (this.columns[columnKey]['columnType'] === 'STRING' && this.columns[columnKey]['columnName'].toLowerCase() === 'post') {
          legend = this.data[dataKey][this.columns[columnKey]['columnName']];
        } else if (this.columns[columnKey]['columnType'] === 'HISTORYMONEY') {
          Object.keys(this.data[dataKey][this.columns[columnKey]['columnName']]).forEach(subColumnKey => {
            if (subColumnKey === 'Jaar')  {
              xvalue = this.data[dataKey][this.columns[columnKey]['columnName']][subColumnKey];
              xtype = 'YEAR';
            } else if (subColumnKey === 'Waarde') {
              yvalue = this.data[dataKey][this.columns[columnKey]['columnName']][subColumnKey];
              ytype = 'MONEY';
              const xyDataElement: XYDataElement = new XYDataElement(legend, xvalue, yvalue, xtype, ytype);
              this.histMoneyData.push(xyDataElement);
            }
          });
        }
      });
    });

  }
}
