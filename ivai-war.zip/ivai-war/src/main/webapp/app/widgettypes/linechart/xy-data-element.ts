export class XYValue {
  'X-value': number;
  'Y-value': number;
  'X-type': string;
  'Y-type': string;

  constructor(xvalue: number, yvalue: number, xtype: string, ytype: string) {
    this['X-value'] = xvalue;
    this['Y-value'] = yvalue;
    this['X-type'] = xtype;
    this['Y-type'] = ytype;
  }
}

export class XYDataElement {
  setName: string;
  XYVALUE: XYValue;

  constructor(setName: string, xvalue: number, yvalue: number, xtype: string, ytype: string) {
    this.XYVALUE = new XYValue(xvalue, yvalue, xtype, ytype);
    this.setName = setName;
  }
}
