import {Component, EventEmitter, Input, OnInit, Output, ViewChildren, QueryList, OnDestroy} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {WidgetComponent} from '../../components/widget/widget.component';
import {TrackingService} from '../../services/tracking.service';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.scss'],
  providers: [Unsubscriber]
})
export class ContainerComponent implements OnInit, OnDestroy {

  @ViewChildren(WidgetComponent) widgetComponents: QueryList<WidgetComponent>;

  @Input() side: string;
  @Input() widgetId: string;
  @Input() widget: any;
  @Input() params: any;
  @Output() hasData: EventEmitter<any> = new EventEmitter<any>();

  public widgets: any;
  public selectedTab: string;
  public disabledTabs: Array<string>;
  public tabId: number;
  public containerId: string;

  constructor(private readonly route: ActivatedRoute,
              private readonly trackingService: TrackingService,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    this.route.params
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(params => {
        if (params.tabId) {
          this.tabId = params.tabId;
        }
        if (params.containerId) {
          this.containerId = params.containerId;
        }
      });

    this.widgets = this.widget.options.widgets;
    const activeTabNr: number = this.widget.data[0] && this.widget.data[0].activeTabNr ? this.widget.data[0].activeTabNr : 0;

    this.selectedTab = this.widgets[activeTabNr].name; // Select active tab
    let widgetInFilter = false;
    const localContainer = this.containerId;
    this.widgets.forEach(function (widget) {
      if (localContainer === widget.name) {
        widgetInFilter = true;
      }
    });
    if (widgetInFilter && this.tabId) {
      if (this.widgets[this.tabId]) {
        this.selectedTab = this.widgets[this.tabId].name; // Select previous tab
      }
    }
    this.disabledTabs = [];
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  displaySelectedTab(nextTab: string) {
    const previousTab = this.selectedTab;
    this.selectedTab = nextTab;

    this.trackingService.trackEvent('klik',
      'Klik widgettab wisselen:' + this.side +
      '/widget:' + this.widgetId + '/van:' + previousTab + '/naar:' + this.selectedTab, null, null);
  }

  changeDataStatus(e) {
    if (!e.hasData) {
      this.disabledTabs.push(e.id);
      if (this.disabledTabs.length === this.widgets.length) {
        this.hasData.emit({id: this.widgetId, hasData: false});
      }
    }
  }
}
