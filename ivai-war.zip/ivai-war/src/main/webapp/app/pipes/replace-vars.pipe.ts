import {OnDestroy, Pipe, PipeTransform} from '@angular/core';
import {Store} from '@ngrx/store';
import * as fromSelectors from '../store/selectors';
import {Subscription} from 'rxjs';

@Pipe({
  name: 'replaceVars'
})
export class ReplaceVarsPipe implements PipeTransform, OnDestroy {

  private side: string = 'left';
  private taxYear: any;
  private subscription: Subscription;

  constructor(public store: Store<any>) {
    this.subscription = this.store.select(fromSelectors.getRouterSides).subscribe(routerSides => {
      if (routerSides[this.side]) {
        this.taxYear = routerSides[this.side].taxYear;
      }
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  transform(value: any, side: string, input: any): string {
    let newValue = '';
    this.side = side;

    if (isNaN(value)) {
      if (input) {
        if (input['valutajaar']) {
          this.taxYear = input['valutajaar'];
        } else if (!isNaN(input)) {
          this.taxYear = Number(input);
        }
      }

      if (value && side && this.taxYear) {
        value = this.replaceTaxYear(value);
      }

      if (value) {
        newValue = value.replace('{hideNull(addOne(getData(valutajaar)))}', this.taxYear + 1);
        value = newValue;
        newValue = value.replace('{hideNull(getData(valutajaar))}', this.taxYear);
        value = newValue;
        newValue = value.replace('{addOne(getData(valutajaar))}', this.taxYear + 1);
        value = newValue;
        newValue = value.replace('{getData(valutajaar)}', this.taxYear);
        value = newValue;
      }
    }

    return value;
  }

  private replaceTaxYear(label: string): string {
    let result = label;
    let taxYearMatch = result.match(/\{taxYear\s*[-+]?\s*\d*\}/);
    while (taxYearMatch !== null) {
      const taxYear = this.taxYear;
      const baseYear = Number(taxYear);

      const taxYearPlaceholder = taxYearMatch[0];
      const taxYearModifier = taxYearPlaceholder.match(/[-+]?\s*\d/);
      const taxYearDelta = (taxYearModifier === null ? 0 : Number(taxYearModifier[0].replace(/\s/g, '')));

      result = result.slice(0, taxYearMatch.index) +
               (baseYear + taxYearDelta) +
               result.slice(taxYearMatch.index + taxYearPlaceholder.length);
      taxYearMatch = result.match(/\{taxYear\s*[-+]?\s*\d*\}/);
    }
    return result;
  }
}
