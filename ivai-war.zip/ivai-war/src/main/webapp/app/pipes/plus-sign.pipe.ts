import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'plusSign'
})
export class PlusSignPipe implements PipeTransform {

  transform(value: any): string {
    const cleanedUpValue = Number(String(value).replace(/[\.,]/g, '')); // remove . and , from value
    if (isNaN(cleanedUpValue)) {
      return value;
    } else if (cleanedUpValue > 0) {
      return '+' + value;
    } else {
      return value;
    }
  }

}
