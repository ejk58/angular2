import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'relationsFilter'
})
export class RelationsFilterPipe implements PipeTransform {

  constructor() { }

  transform(items: any[], filter: string): any {
    if (!items || !filter) {
      return items;
    }
    return items.filter((item: any) => this.applyFilter(item, filter));
  }

  applyFilter(relation: any, filter: string): boolean {
    const filterValue = filter.toLowerCase();

    return Object.keys(relation).reduce((filterMatch: boolean, relationKey: string): boolean => {
      let relationValue = '';
      if (relationKey === 'name' || relationKey === 'subjectNr') {
        relationValue = String(relation[relationKey]);
      }
      return filterMatch || (relationValue.toLowerCase().indexOf(filterValue) > -1);
    }, false);
  }
}
