import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'trafficLight'
})
export class TrafficLightPipe implements PipeTransform {

  constructor() { }

  transform(value: any): string {
    let styledValue = '';
    if (value !== null && value.hasOwnProperty('Waarde') && value['Waarde'] !== null) {
      const innerValue = value['Waarde'];
      if (value['Kleur'] === 'STOPLICHT_GROEN') {
        styledValue = '<div class="trafficlight green">' + innerValue + '</div>';
      } else if (value['Kleur'] === 'STOPLICHT_GEEL') {
        styledValue = '<div class="trafficlight yellow">' + innerValue + '</div>';
      } else if (value['Kleur'] === 'STOPLICHT_ROOD') {
        styledValue = '<div class="trafficlight red">' + innerValue + '</div>';
      } else {
        styledValue = '<div class="trafficlight">' + innerValue + '</div>';
      }
    }
    return styledValue;
  }
}
