import {IdPipe} from './id.pipe';
import {TrendStringPipe} from './trend-string.pipe';
import {MoneyPipe} from './money.pipe';
import {TrendMoneyPipe} from './trend-money.pipe';
import {WeightPipe} from './weight.pipe';
import {PercentagePipe} from './percentage.pipe';
import {ReplaceVarsPipe} from './replace-vars.pipe';
import {TrafficLightPipe} from './traffic-light.pipe';
import {ComplianceLightPipe} from './compliance-light.pipe';
import {RelationsFilterPipe} from './relations-filter.pipe';
import {SubjectDescriptionPipe} from './subject-description.pipe';
import {ProcessLightPipe} from './process-light.pipe';
import {DateStringPipe} from './date-string.pipe';
import {InzichtDatePipe} from './inzicht-date.pipe';
import {PlusSignPipe} from './plus-sign.pipe';

export const list = [
  IdPipe,
  TrendStringPipe,
  MoneyPipe,
  TrendMoneyPipe,
  PercentagePipe,
  WeightPipe,
  DateStringPipe,
  TrafficLightPipe,
  ComplianceLightPipe,
  ProcessLightPipe,
  ReplaceVarsPipe,
  RelationsFilterPipe,
  SubjectDescriptionPipe,
  InzichtDatePipe,
  PlusSignPipe
];
