import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'subjectDescription'
})
export class SubjectDescriptionPipe implements PipeTransform {

  public pathKeys: any;
  public subjectOmschrijving: string;
  public keySeperator: string;

  transform(subject: Object, side: string, klantbeeld: any): string {
    this.subjectOmschrijving = '';
    this.keySeperator = '';
    if (subject && side && klantbeeld && klantbeeld.pathKeys) {
      this.pathKeys = klantbeeld.pathKeys;

      this.pathKeys.forEach(pathKey => {
        if (pathKey.mandatory && subject[pathKey.name]) {
          this.subjectOmschrijving = this.subjectOmschrijving + this.keySeperator + subject[pathKey.name];
          this.keySeperator = ' - ';
        }
      });
    }

    return this.subjectOmschrijving;
  }
}
