import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
    name: 'iDate'
})
export class InzichtDatePipe implements PipeTransform {

    constructor(private readonly ngDatePipe: DatePipe) { }

  transform(value: { date: number, dateString: string }, ...args: any[]): string {
    if (value == null) {
      return '';
    } else if (value.dateString) {
      return value.dateString;
    } else if (value.date) {
      try {
        return this.ngDatePipe.transform(value.date, ...args);
      } catch (e) {
        return '';
      }
    } else {
      try {
        return this.ngDatePipe.transform(value, ...args);
      } catch (e) {
        return '';
      }
    }
  }
}
