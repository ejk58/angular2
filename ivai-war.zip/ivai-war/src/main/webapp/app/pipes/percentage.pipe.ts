import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'percentage'
})
export class PercentagePipe implements PipeTransform {

  constructor() { }

  transform(value: any): string {
    if ( value !== null ) {
      if ( isNaN(value) ) {
        return value;
      } else {
        return '<span class="percentage">' + value + '%</span>';
      }
    } else {
      return '';
    }
  }
}
