export class Notification {
    public message: string;
    public type: 'error'|'message'|'news'|'warning';
}
