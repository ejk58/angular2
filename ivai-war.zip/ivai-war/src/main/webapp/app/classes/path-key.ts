// TODO: fields like 'type' can be String Literal Types or enums

export class PathKey {
    public id: number;
    public index: number;
    public key: string;
    public mandatory: boolean;
    public name: string;
    public primary: boolean;
    public title: string;
    public type: string;
}
