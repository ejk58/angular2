import {Link} from './link';

export class LinkSubjectPresentation {

  public type: number;
  public direction: number;
  public percentage: number;

  public isLabeled: boolean;
  public isPartnerLink: boolean;
  public isVisible: boolean;

  public possibleCrossingLinks: Link<any, any, any>[];
}
