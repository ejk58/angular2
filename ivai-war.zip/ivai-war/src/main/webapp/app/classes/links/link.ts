import {SimulationLinkDatum} from 'd3-ng2-service';

import {Node} from '../nodes/node';

export class Link<N extends Node<any, any>, M, P> implements SimulationLinkDatum<N> {

  public id: string;
  public source: N;
  public target: N;

  public model: M;
  public presentation: P;

  public data: any;
  public classes: string[];

  public hasMatchingLink(node: N, linkedNode: N): boolean {
    return (this.source === node && this.target === linkedNode);
  }

  public hasMatchingNodes(node: N, linkedNode: N): boolean {
    return (this.source === node && this.target === linkedNode) || (this.source === linkedNode && this.target === node);
  }

  public getOtherNode(node: N): N {
    return (this.source === node) ? this.target : this.source;
  }
}
