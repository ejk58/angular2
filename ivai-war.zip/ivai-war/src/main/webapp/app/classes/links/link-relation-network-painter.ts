import {Selection} from 'd3-ng2-service';

import {LinkPainter} from './link-painter';
import {LinkSubjectType} from './link-subject-type';
import {LinkSubjectPresentation} from './link-subject-presentation';
import {Link} from './link';
import {LinkDirection} from '../../widgettypes/hierarchical-graph/model/link-direction';
import {Node} from '../nodes/node';

export class LinkRelationNetworkPainter implements LinkPainter<LinkSubjectPresentation> {

  public static readonly linkRadius: number = 40;
  public static readonly percentagePositionRatio: number = 0.50;
  public static readonly percentageRadius: number = 15;

  protected readonly calculateSourceX = (link) => link.source.x + this.leftMargin + this.leftOffset;
  protected readonly calculateSourceY = (link) => link.source.y + this.topMargin + this.topOffset;
  protected readonly calculateTargetX = (link) => link.target.x + this.leftMargin + this.leftOffset;
  protected readonly calculateTargetY = (link) => link.target.y + this.topMargin + this.topOffset;

  constructor(protected readonly topMargin: number,
      protected readonly leftMargin: number,
      protected readonly topOffset: number,
      protected readonly leftOffset: number) {
  }

  public drawLinks(graph: Selection<any, any, any, any>, linkMainGroup: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>, links: Link<Node<any, any>, any, LinkSubjectPresentation>[]): void {

    const unlabeledLinks = links.filter(link => !link.presentation.isLabeled);
    const labeledLinks = links.filter(link => link.presentation.isLabeled);
    const sortedLinks = [...unlabeledLinks, ...labeledLinks];

    const linkGroups = linkMainGroup.selectAll('g')
      .data(sortedLinks, (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => link.id);

    this.drawNewLinks(linkGroups.enter().append('g'));
    this.updateExistingLinks(linkGroups);
    this.removeObsoleteLinks(linkGroups.exit());
  }

  protected drawNewLinks(newLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    newLinkGroups
      .attr('class', link => link.classes.join(' '));

    this.drawLine(newLinkGroups);
    this.drawPercentage(newLinkGroups);
  }

  protected updateExistingLinks(existingLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    existingLinkGroups.selectAll('.link-line')
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY);

    existingLinkGroups.selectAll('.link-percentage')
      .attr('transform', (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => this.getPercentageTranslation(link));
  }

  protected removeObsoleteLinks(obsoleteLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    obsoleteLinkGroups.remove();
  }

  protected drawLine(newLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    newLinkGroups
      .append('line')
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY)
      .classed('link-line', true);
  }

  protected drawPercentage(newLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    const newLinkWithPercentageGroups = newLinkGroups.filter(link => link.presentation.type === LinkSubjectType.Aandeelhouder || link.presentation.type === LinkSubjectType.HeeftAandeelhouder)
      .append('g')
      .attr('transform', link => this.getPercentageTranslation(link))
      .classed('link-percentage', true);

    newLinkWithPercentageGroups
      .append('circle')
      .attr('r', LinkRelationNetworkPainter.percentageRadius)
      .attr('cx', 0)
      .attr('cy', 0)
      .classed('link-percentage-circle', true);

    newLinkWithPercentageGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('link-percentage-text', true)
      .text(link => link.presentation.percentage ? link.presentation.percentage : 'NB');
  }

  protected getPercentageTranslation(link: Link<Node<any, any>, any, LinkSubjectPresentation>): string {
    const percentageX = this.getValueForPositionRatio(this.calculateSourceX(link), this.calculateTargetX(link),
        LinkRelationNetworkPainter.percentagePositionRatio);
    const percentageY = this.getValueForPositionRatio(this.calculateSourceY(link), this.calculateTargetY(link),
        LinkRelationNetworkPainter.percentagePositionRatio);
    return 'translate(' + percentageX + ',' + percentageY + ')';
  }

  protected getValueForPositionRatio(source, target, positionRatio) {
    return (source * positionRatio + target * (1 - positionRatio));
  }
}
