import {Selection} from 'd3-ng2-service';

import {LinkPainter} from './link-painter';
import {LinkSubjectType} from './link-subject-type';
import {LinkSubjectPresentation} from './link-subject-presentation';
import {Link} from './link';
import {LinkDirection} from '../../widgettypes/hierarchical-graph/model/link-direction';
import {Node} from '../nodes/node';

export class LinkRelationHierarchicalPainter implements LinkPainter<LinkSubjectPresentation> {

  public static readonly linkHeight = 80;
  public static readonly linkRadius: number = 40;
  public static readonly percentageRadius: number = 15;

  protected readonly calculateSourceX = (link) => link.source.x + this.leftMargin + (link.presentation.isPartnerLink ? (link.source.x > link.target.x ? -30 : 30 ) : 0);
  protected readonly calculateSourceY = (link) => link.source.y + this.topMargin + (link.presentation.isPartnerLink ? -30 : 50);
  protected readonly calculateTargetX = (link) => link.target.x + this.leftMargin + (link.presentation.isPartnerLink ? (link.target.x > link.source.x ? -30 : 30 ) : 0);
  protected readonly calculateTargetY = (link) => link.target.y + this.topMargin + (link.presentation.isPartnerLink ? -30 : (link.presentation.direction === LinkDirection.sameLevel ? 50 : -80));

  constructor(protected readonly topMargin: number,
      protected readonly leftMargin: number) {
  }

  public drawLinks(graph: Selection<any, any, any, any>, linkMainGroup: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>, links: Link<Node<any, any>, any, LinkSubjectPresentation>[]): void {

    const unlabeledLinks = links.filter(link => !link.presentation.isLabeled);
    const labeledLinks = links.filter(link => link.presentation.isLabeled);
    const sortedLinks = [...unlabeledLinks, ...labeledLinks];

    const linkGroups = linkMainGroup.selectAll('g')
      .data(sortedLinks, (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => link.id);

    this.drawNewLinks(linkGroups.enter().append('g'));
    this.updateExistingLinks(linkGroups);
    this.removeObsoleteLinks(linkGroups.exit());
  }

  protected drawNewLinks(newLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    newLinkGroups
      .attr('class', link => link.classes.join(' '));

    this.drawLine(newLinkGroups);
    this.drawPercentage(newLinkGroups);
  }

  protected updateExistingLinks(existingLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    existingLinkGroups.selectAll('.link-line').filter((link: Link<Node<any, any>, any, LinkSubjectPresentation>) => link.presentation.direction !== LinkDirection.sameLevel || link.presentation.isPartnerLink)
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY);

    existingLinkGroups.selectAll('.link-line').filter((link: Link<Node<any, any>, any, LinkSubjectPresentation>) => link.presentation.direction === LinkDirection.sameLevel && !link.presentation.isPartnerLink)
      .attr('d', (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => this.getCurvedLinePath(link));

    existingLinkGroups.selectAll('.link-percentage')
      .attr('transform', (link: Link<Node<any, any>, any, LinkSubjectPresentation>) => this.getPercentageTranslation(link));
  }

  protected removeObsoleteLinks(obsoleteLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    obsoleteLinkGroups.remove();
  }

  protected drawLine(newLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    newLinkGroups.filter((link: Link<Node<any, any>, any, LinkSubjectPresentation>) => link.presentation.direction !== LinkDirection.sameLevel || link.presentation.isPartnerLink)
      .append('line')
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY)
      .classed('link-line', true);

    newLinkGroups.filter(link => link.presentation.direction === LinkDirection.sameLevel && !link.presentation.isPartnerLink)
      .append('path')
      .attr('d', link => this.getCurvedLinePath(link))
      .classed('link-line', true);
  }

  protected drawPercentage(newLinkGroups: Selection<any, Link<Node<any, any>, any, LinkSubjectPresentation>, any, any>): void {
    const newLinkWithPercentageGroups = newLinkGroups.filter(link => link.presentation.type === LinkSubjectType.Aandeelhouder || link.presentation.type === LinkSubjectType.HeeftAandeelhouder)
      .append('g')
      .attr('transform', link => this.getPercentageTranslation(link))
      .classed('link-percentage', true);

    newLinkWithPercentageGroups
      .append('circle')
      .attr('r', LinkRelationHierarchicalPainter.percentageRadius)
      .attr('cx', 0)
      .attr('cy', 0)
      .classed('link-percentage-circle', true);

    newLinkWithPercentageGroups
      .append('text')
      .attr('x', 0)
      .attr('y', 0)
      .classed('link-percentage-text', true)
      .text(link => link.presentation.percentage ? link.presentation.percentage : 'NB');
  }

  protected getCurvedLinePath(link: Link<Node<any, any>, any, LinkSubjectPresentation>): string {
    const sourceX = this.calculateSourceX(link);
    const distanceX = this.calculateTargetX(link) - sourceX;
    const deviationX = Math.floor(distanceX / 2);

    const sourceY = this.calculateSourceY(link);
    const distanceY = this.calculateTargetY(link) - sourceY;
    const deviationY = Math.floor(Math.abs(distanceY / 3) + Math.abs(distanceX / 6));

    return 'M' + sourceX + ' ' + sourceY + 'q' + deviationX + ' ' + deviationY + ' ' + distanceX + ' ' + distanceY;
  }

  protected getPercentageTranslation(link: Link<Node<any, any>, any, LinkSubjectPresentation>): string {
    const positionRatio = this.getPercentagePositionRatio(link);
    const percentageX = this.getValueForPositionRatio(this.calculateSourceX(link), this.calculateTargetX(link), positionRatio);
    const percentageY = this.getValueForPositionRatio(this.calculateSourceY(link), this.calculateTargetY(link), positionRatio);
    return 'translate(' + percentageX + ',' + percentageY + ')';
  }

  protected getPercentagePositionRatio(link: Link<Node<any, any>, any, LinkSubjectPresentation>): number {
    let bestPositionRatio = 0.50;
    let bestPositionCrossingLinkCount = this.getNumberOfCrossingLinks(link, bestPositionRatio);
    let positionRatio = 0.15;

    while (bestPositionCrossingLinkCount > 0 && positionRatio < 0.85) {
      const positionCrossingLinkCount = this.getNumberOfCrossingLinks(link, positionRatio);

      if (positionCrossingLinkCount < bestPositionCrossingLinkCount) {
        bestPositionRatio = positionRatio;
        bestPositionCrossingLinkCount = positionCrossingLinkCount;
      }

      positionRatio = positionRatio + 0.10;
    }

    return bestPositionRatio;
  }

  protected getNumberOfCrossingLinks(link: Link<Node<any, any>, any, LinkSubjectPresentation>, ratio: number): number {
    const sourceX = this.calculateSourceX(link);
    const targetX = this.calculateTargetX(link);
    const x = this.getValueForPositionRatio(sourceX, targetX, ratio);

    const sourceY = this.calculateSourceY(link);
    const targetY = this.calculateTargetY(link);
    const y = this.getValueForPositionRatio(sourceY, targetY, ratio);

    let count = 0;

    link.presentation.possibleCrossingLinks.forEach(possibleCrossingLink => {
      const crossingLinkSourceX = this.calculateSourceX(possibleCrossingLink);
      const crossingLinkTargetX = this.calculateTargetX(possibleCrossingLink);

      const crossingLinkSourceY = this.calculateSourceY(possibleCrossingLink);
      const crossingLinkTargetY = this.calculateTargetY(possibleCrossingLink);

      const crossingRatio = (y - crossingLinkSourceY) / (crossingLinkTargetY - crossingLinkSourceY);
      const crossingX = this.getValueForPositionRatio(crossingLinkSourceX, crossingLinkTargetX, crossingRatio);

      if (Math.abs(x - crossingX) < LinkRelationHierarchicalPainter.percentageRadius * 2) {
        count++;
      }
    });

    return count;
  }

  protected getValueForPositionRatio(source, target, positionRatio) {
    return (source * positionRatio + target * (1 - positionRatio));
  }
}
