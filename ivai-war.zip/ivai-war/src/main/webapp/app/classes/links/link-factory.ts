import {Link} from './link';
import {Node} from '../nodes/node';

export interface LinkFactory<N extends Node<any, any>, M, P> {
  build(source: N, target: N, row: any): Link<N, M, P>;
}
