import {Selection} from 'd3-ng2-service';

import {LinkPainter} from './link-painter';
import {Link} from './link';
import {Node} from '../nodes/node';

export class LinkBaseNetworkPainter implements LinkPainter<any> {

  protected readonly calculateSourceX = (link) => link.source.x + this.leftMargin + this.leftOffset;
  protected readonly calculateSourceY = (link) => link.source.y + this.topMargin + this.topOffset;
  protected readonly calculateTargetX = (link) => link.target.x + this.leftMargin + this.leftOffset;
  protected readonly calculateTargetY = (link) => link.target.y + this.topMargin + this.topOffset;

  constructor(protected readonly topMargin: number,
      protected readonly leftMargin: number,
      protected readonly topOffset: number,
      protected readonly leftOffset: number) {
  }

  public drawLinks(graph: Selection<any, any, any, any>, linkMainGroup: Selection<any, Link<Node<any, any>, any, any>, any, any>, links: Link<Node<any, any>, any, any>[]): void {
    const linkGroups = linkMainGroup.selectAll('g')
      .data(links, (link: Link<Node<any, any>, any, any>) => link.id);

    this.drawNewLinks(linkGroups.enter().append('g'));
    this.updateExistingLinks(linkGroups);
    this.removeObsoleteLinks(linkGroups.exit());
  }

  protected drawNewLinks(newLinkGroups: Selection<any, Link<Node<any, any>, any, any>, any, any>): void {
    newLinkGroups
      .attr('class', link => link.classes.join(' '));

    this.drawLine(newLinkGroups);
  }

  protected updateExistingLinks(existingLinkGroups: Selection<any, Link<Node<any, any>, any, any>, any, any>): void {
    existingLinkGroups.selectAll('.link-line')
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY);
  }

  protected removeObsoleteLinks(obsoleteLinkGroups: Selection<any, Link<Node<any, any>, any, any>, any, any>): void {
    obsoleteLinkGroups.remove();
  }

  protected drawLine(newLinkGroups: Selection<any, Link<Node<any, any>, any, any>, any, any>): void {
    newLinkGroups
      .append('line')
      .attr('x1', this.calculateSourceX)
      .attr('y1', this.calculateSourceY)
      .attr('x2', this.calculateTargetX)
      .attr('y2', this.calculateTargetY)
      .classed('link-line', true);
  }
}
