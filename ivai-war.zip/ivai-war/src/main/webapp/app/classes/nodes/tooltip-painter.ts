import {Node} from './node';

export interface TooltipPainter<P> {
  showTooltip(node: Node<any, P>): void;
  hideTooltip(): void;
}
