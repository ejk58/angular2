import {Selection} from 'd3-ng2-service';
import {SubjectIconProvider} from '../../commons/subject-icon-provider';

import {Node} from './node';
import {NodeSubjectPresentation} from './node-subject-presentation';
import {TooltipPainter} from './tooltip-painter';

export class TooltipSubjectPainter implements TooltipPainter<NodeSubjectPresentation> {

  protected tooltipLabelHeight = 20;
  protected tooltipPadding = 15;
  protected tooltipButtonWidth = 60;

  constructor(protected readonly topMargin: number,
      protected readonly leftMargin: number,
      protected readonly imageRadius: number,
      protected readonly tooltipGroup: Selection<any, any, any, any>,
      protected readonly profileFunction: Function,
      protected readonly relationFunction: Function) {

    this.drawTooltip();
    this.hideTooltip();
  }

  protected drawTooltip(): void {
    this.drawBackground();
    this.drawLabels();
    this.drawButtons();
  }

  public showTooltip(node: Node<any, NodeSubjectPresentation>): void {
    if (node != null) {
      this.updateLabels(node);
      const labelWidth = this.calculateLabelWidth(node);
      this.updateButtons(node, labelWidth);
      const width = this.tooltipPadding * 3 + labelWidth + this.tooltipButtonWidth * 2;
      this.updateBackground(width);

      this.tooltipGroup
        .attr('pointer-events', 'auto')
        .attr('transform', 'translate(' + (node.x - Math.floor(width / 2)) + ',' + node.y + ')')
        .transition()
        .attr('opacity', 1.0);
    } else {
      this.tooltipGroup
        .attr('pointer-events', 'auto')
        .transition()
        .attr('opacity', 1.0);
    }
  }

  public hideTooltip(): void {
    this.tooltipGroup
      .attr('pointer-events', 'none')
      .transition()
      .attr('opacity', 0.0);
  }

  protected drawBackground(): void {
    this.tooltipGroup
      .classed('tooltip', true)
      .attr('opacity', 0.0)
      .append('rect')
      .classed('tooltip-background', true)
      .attr('width', 300)
      .attr('height', this.tooltipLabelHeight * 4 + this.tooltipPadding * 2)
      .attr('rx', 2)
      .attr('ry', 2)
      .on('mouseover', () => this.showTooltip(null))
      .on('mouseout', () => this.hideTooltip());
  }

  protected drawLabels(): void {
    this.tooltipGroup
      .append('text')
      .classed('tooltip-relation-label', true)
      .attr('x', this.tooltipPadding)
      .attr('y', this.tooltipLabelHeight + this.tooltipPadding);

    this.tooltipGroup
      .append('text')
      .classed('tooltip-name-label', true)
      .attr('x', this.tooltipPadding)
      .attr('y', this.tooltipLabelHeight * 2 + this.tooltipPadding);

    this.tooltipGroup
      .append('text')
      .classed('tooltip-number-label', true)
      .attr('x', this.tooltipPadding)
      .attr('y', this.tooltipLabelHeight * 3 + this.tooltipPadding);

      this.tooltipGroup
      .append('text')
      .classed('tooltip-description-label', true)
      .attr('x', this.tooltipPadding)
      .attr('y', this.tooltipLabelHeight * 4 + this.tooltipPadding);
  }

  protected drawButtons(): void {
    if (this.profileFunction != null && this.relationFunction != null) {
      this.tooltipGroup
        .append('line')
        .attr('x1', 240)
        .attr('y1', Math.floor(this.tooltipLabelHeight * 0.5) + this.tooltipPadding)
        .attr('x2', 240)
        .attr('y2', Math.floor(this.tooltipLabelHeight * 3.5) + this.tooltipPadding)
        .classed('tooltip-button-separator', true);
    }

    if (this.profileFunction != null) {
      this.tooltipGroup
        .append('text')
        .attr('x', 185)
        .attr('y', Math.floor(this.tooltipLabelHeight * 2.5) + this.tooltipPadding)
        .classed('tooltip-button', true)
        .classed('tooltip-button-profile', true)
        .text(SubjectIconProvider.personProfileIcon)
        .on('mouseover', () => this.showTooltip(null))
        .on('mouseout', () => this.hideTooltip());
    }

    if (this.relationFunction != null) {
      this.tooltipGroup
        .append('text')
        .attr('x', 245)
        .attr('y', Math.floor(this.tooltipLabelHeight * 2.5) + this.tooltipPadding)
        .classed('tooltip-button', true)
        .classed('tooltip-button-relation', true)
        .text(SubjectIconProvider.relationIcon)
        .on('mouseover', () => this.showTooltip(null))
        .on('mouseout', () => this.hideTooltip());
    }
  }

  protected updateBackground(width: number): void {
    this.tooltipGroup
      .select('.tooltip-background')
      .attr('width', width);
  }

  protected updateLabels(node: Node<any, NodeSubjectPresentation>): void {
    this.tooltipGroup
      .select('.tooltip-relation-label')
      .text(node.presentation.relation);

    this.tooltipGroup
      .select('.tooltip-name-label')
      .text(node.presentation.name);

    this.tooltipGroup
      .select('.tooltip-number-label')
      .text(node.presentation.subjectNr);

    this.tooltipGroup
      .select('.tooltip-description-label')
      .text(node.presentation.description);
  }

  protected updateButtons(node: Node<any, NodeSubjectPresentation>, labelWidth: number): void {
    const profileButtonVisible = this.getProfileButtonVisibility(node);
    const relationButtonVisible = this.getRelationButtonVisibility(node);

    this.tooltipGroup
      .select('.tooltip-button-separator')
      .attr('x1', this.tooltipPadding * 2 + labelWidth + this.tooltipButtonWidth + 2)
      .attr('x2', this.tooltipPadding * 2 + labelWidth + this.tooltipButtonWidth + 2)
      .style('opacity', profileButtonVisible && relationButtonVisible ? 1.0 : 0.0);

    this.tooltipGroup
      .select('.tooltip-button-profile')
      .attr('x', this.tooltipPadding * 2 + labelWidth + 5)
      .classed('tooltip-button-disabled', !profileButtonVisible)
      .text(node.presentation.isPerson ? SubjectIconProvider.personProfileIcon : SubjectIconProvider.businessProfileIcon)
      .on('click', () => this.profileFunction(node));

    this.tooltipGroup
      .select('.tooltip-button-relation')
      .attr('x', this.tooltipPadding * 2 + labelWidth + this.tooltipButtonWidth + 6)
      .classed('tooltip-button-disabled', !relationButtonVisible)
      .on('click', () => this.relationFunction(node));
  }

  protected calculateTooltipWidth(node: Node<any, NodeSubjectPresentation>): number {
    return this.tooltipPadding * 3 + this.calculateLabelWidth(node) + this.tooltipButtonWidth * 2;
  }

  protected calculateLabelWidth(node: Node<any, NodeSubjectPresentation>): number {
    const relationLabel = this.tooltipGroup.select('.tooltip-relation-label');
    const relationBox = (relationLabel.node() as SVGGraphicsElement).getBBox();

    const nameLabel = this.tooltipGroup.select('.tooltip-name-label');
    const nameBox = (nameLabel.node() as SVGGraphicsElement).getBBox();

    const numberLabel = this.tooltipGroup.select('.tooltip-number-label');
    const numberBox = (numberLabel.node() as SVGGraphicsElement).getBBox();

    const descriptionLabel = this.tooltipGroup.select('.tooltip-description-label');
    const descriptionBox = (descriptionLabel.node() as SVGGraphicsElement).getBBox();

    return Math.max(
        relationBox == null ? 0 : relationBox.width,
        nameBox == null ? 0 : nameBox.width,
        numberBox == null ? 0 : numberBox.width,
        descriptionBox == null ? 0 : descriptionBox.width);
  }

  protected calculateButtonWidth(node: Node<any, NodeSubjectPresentation>): number {
    const count = (this.getProfileButtonVisibility(node) ? 1 : 0) + (this.getRelationButtonVisibility(node) ? 1 : 0);
    return count * this.tooltipButtonWidth;
  }

  protected getProfileButtonVisibility(node: Node<any, NodeSubjectPresentation>): boolean {
    return this.profileFunction != null && this.getTooltipButtonVisibility(node);
  }

  protected getRelationButtonVisibility(node: Node<any, NodeSubjectPresentation>): boolean {
    return this.relationFunction != null && this.getTooltipButtonVisibility(node);
  }

  protected getTooltipButtonVisibility(node: Node<any, NodeSubjectPresentation>): boolean {
    return !node.presentation.isMasked && !node.presentation.isManyPeople && node.data.model != null;
  }
}
