import {Selection} from 'd3-ng2-service';
import {SubjectIconProvider} from '../../commons/subject-icon-provider';
import {SubjectType} from '../../commons/subject-type';

import {NodePainter} from './node-painter';
import {Node} from './node';
import {NodeSubjectPresentation} from './node-subject-presentation';
import {TooltipPainter} from './tooltip-painter';
import {TooltipSubjectTopPainter} from './tooltip-subject-top-painter';

export class NodeGroupPainter implements NodePainter<NodeSubjectPresentation> {

  protected static readonly rectangleWidth = 200;
  protected static readonly imageRadius = 30;
  protected static readonly labelHeight = 20;

  protected tooltipPainter: TooltipPainter<NodeSubjectPresentation>;

  constructor(protected readonly topMargin: number,
      protected readonly leftMargin: number,
      protected readonly tooltipGroup: Selection<any, any, any, any>,
      protected readonly subjectIconProvider: SubjectIconProvider,
      protected readonly profileFunction: Function,
      protected readonly relationFunction: Function) {

    this.tooltipPainter = new TooltipSubjectTopPainter(this.topMargin, this.leftMargin, NodeGroupPainter.labelHeight * 2 + 5,
        this.tooltipGroup, this.profileFunction, this.relationFunction);
  }

  public drawNodes(graph: Selection<any, any, any, any>, nodeMainGroup: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, nodes: Node<any, NodeSubjectPresentation>[]) {
    const nodeGroups = nodeMainGroup.selectAll('g')
      .data(nodes, (node: Node<any, NodeSubjectPresentation>) => node.id);

    this.drawNewNodes(graph, nodeGroups.enter().append('g'));
    this.updateExistingNodes(nodeGroups);
    this.removeObsoleteNodes(nodeGroups.exit());
  }

  protected drawNewNodes(graph: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, newNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    newNodeGroups
      .attr('class', node => node.classes.join(' ') + ' node-design-group')
      .attr('transform', node => 'translate(' + (node.x + this.leftMargin) + ',' + (node.y + this.topMargin) + ')');

    newNodeGroups
      .append('rect')
      .classed('node-background', true)
      .attr('x', Math.floor(-NodeGroupPainter.rectangleWidth / 2))
      .attr('y', Math.floor(-NodeGroupPainter.labelHeight * 3 / 2))
      .attr('width', NodeGroupPainter.rectangleWidth)
      .attr('height', NodeGroupPainter.labelHeight * 3)
      .attr('rx', 2)
      .attr('ry', 2);

    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', -Math.floor(NodeGroupPainter.labelHeight / 2))
      .classed('node-name-label', true)
      .text(node => (node.presentation.name == null || node.presentation.name.length <= 18) ? node.presentation.name : node.presentation.name.substr(0, 16) + '...');

    newNodeGroups
      .append('text')
      .attr('x', 0)
      .attr('y', Math.floor(NodeGroupPainter.labelHeight / 2))
      .classed('node-number-label', true)
      .text(node => node.presentation.subjectNr);

    newNodeGroups
      .append('rect')
      .classed('node-aura', true)
      .attr('x', Math.floor(-NodeGroupPainter.rectangleWidth / 2))
      .attr('y', -(NodeGroupPainter.labelHeight * 2 + 5))
      .attr('width', NodeGroupPainter.rectangleWidth)
      .attr('height', Math.floor(NodeGroupPainter.labelHeight * 7 / 2) + 5)
      .on('mouseover', node => this.handleMouseOverEvent(graph, node))
      .on('mouseout', node => this.handleMouseOutEvent(graph, node));
  }

  protected updateExistingNodes(existingNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    existingNodeGroups
      .attr('transform', d => 'translate(' + (d.x + this.leftMargin) + ',' + (d.y + this.topMargin) + ')');
  }

  protected removeObsoleteNodes(obsoleteNodeGroups: Selection<any, Node<any, NodeSubjectPresentation>, any, any>): void {
    obsoleteNodeGroups.remove();
  }

  protected handleMouseOverEvent(graph: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, node: Node<any, NodeSubjectPresentation>): void {
    this.tooltipPainter.showTooltip(node);
    // graph.selectAll('.link-id-' + node.id).classed('link-highlight', true);
  }

  protected handleMouseOutEvent(graph: Selection<any, Node<any, NodeSubjectPresentation>, any, any>, node: Node<any, NodeSubjectPresentation>): void {
    this.tooltipPainter.hideTooltip();
    // graph.selectAll('.link-id-' + node.id).classed('link-highlight', false);
  }
}
