import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoggedInGuard } from './components/login/logged-in.guard';
import { BdStylesheetComponent } from './components/bd-stylesheet/bd-stylesheet.component';

import { LoginComponent } from './components/login/login.component';
import { PageComponent } from './components/page/page.component';
import { MainComponent } from './components/main/main.component';

import { KlantBeeldenResolver } from './components/klantbeeld/resolver/klantbeeld.resolver';
import { PageResolver } from './components/page/resolver/page.resolver';
import { SystemResolver } from './components/main/resolver/system.resolver';

const routes: Routes = [
  { path: 'style', component: BdStylesheetComponent },

  { path: 'login', component: LoginComponent },
  {
    path: 'main',
    component: MainComponent,
    canActivate: [LoggedInGuard],
    resolve: { KlantBeeldenResolver, SystemResolver },
    children: [
      {
        path: ':klantbeeld/:domain',
        component: PageComponent,
        canActivate: [LoggedInGuard],
        resolve: { PageResolver },
        outlet: 'left'
      },
      {
        path: ':klantbeeld/:domain',
        component: PageComponent,
        canActivate: [LoggedInGuard],
        resolve: { PageResolver },
        outlet: 'right'
      }
    ]
  },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, enableTracing: false })],
  exports: [RouterModule],
  providers: [KlantBeeldenResolver, PageResolver, SystemResolver]
})
export class InzichtRoutingModule { }
