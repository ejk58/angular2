import { AfterContentInit, Directive, ElementRef, Renderer } from '@angular/core';

@Directive({
  selector: '[ivaFocus]'
})
export class FocusDirective implements AfterContentInit {

  constructor(private readonly el: ElementRef,
              private readonly renderer: Renderer) {
  }

  ngAfterContentInit () {
    this.renderer.invokeElementMethod(this.el.nativeElement, 'focus', []);
  }
}
