import * as storeActions from '../../actions';
import {DynamicSideIndicator} from '../../../commons/dynamic-side-indicator';
import {Subject} from '../../../classes/subject';

const sideGenerator = new DynamicSideIndicator();

export interface SubjectState {
  loading: boolean;
  left?: {
    selected: Subject;
  };
  right?: {
    selected: Subject;
  };
}

export const initialSubjectState: SubjectState = {
  loading: false,
  left: {
    selected: null
  },
  right: {
    selected: null
  }
};

function loadSubjectFailed(state: SubjectState, action: storeActions.SubjectLoadFailed): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    [updateSide]: {
      selected: action.payload.subject
    },
    [staticSide]: {
      selected: state[staticSide].selected
    }
  };
}

function selectSubject(state: SubjectState, action: storeActions.SubjectSelect): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    [updateSide]: {
      selected: action.payload.subject
    },
    [staticSide]: {
      selected: state[staticSide].selected
    }
  };
}

function clearSubject(state: SubjectState, action: storeActions.SubjectClear): SubjectState {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    [updateSide]: {
      selected: null
    },
    [staticSide]: {
      selected: state[staticSide].selected
    }
  };
}

export function subjectReducer(state = initialSubjectState, action: storeActions.SubjectAll | storeActions.KlantbeeldActions): SubjectState {
  switch (action.type) {
    case storeActions.SUBJECT_LOAD: return { ...state,  loading: true };

    case storeActions.SUBJECT_LOAD_SUCCESS: return { ...state,  loading: false };

    case storeActions.SUBJECT_LOAD_FAILED: return loadSubjectFailed(state, action);

    case storeActions.LOAD_SELECTED_KLANTBEELD_SUBJECTS: return { ...state,  loading: false };

    case storeActions.SUBJECT_SELECT: return selectSubject(state, action);

    case storeActions.SUBJECT_CLEAR: return clearSubject(state, action);

    case storeActions.SUBJECT_RESET: return initialSubjectState;

    default: return state;
  }
}
