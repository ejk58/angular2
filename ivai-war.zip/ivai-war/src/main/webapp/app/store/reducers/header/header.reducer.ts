import * as headerActions from '../../actions/header/header.actions';
import { DynamicSideIndicator } from '../../../commons/dynamic-side-indicator';

const sideGenerator = new DynamicSideIndicator();

export interface HeaderState {
  left?: {
    activeMenu: string;
  };
  right?: {
    activeMenu: string;
  };
}

export const initialHeaderState = {
  left: {
    activeMenu: 'klantbeeld'
  },
  right: {
    activeMenu: 'default'
  }
};

export function headerReducer(state = initialHeaderState, action: headerActions.HeaderActions): HeaderState {

  switch (action.type) {
    case headerActions.HEADER_SELECT_MENU: {
      const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

      return {
        [updateSide]: {
          activeMenu: action.payload.menu
        },
        [staticSide]: {
          activeMenu: state[staticSide].activeMenu
        }
      };
    }

    case headerActions.HEADER_RESET: return initialHeaderState;

    default:
      return state;
  }
}
