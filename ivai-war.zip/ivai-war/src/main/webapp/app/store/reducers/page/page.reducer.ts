import * as storeActions from '../../actions';
import {DynamicSideIndicator} from '../../../commons/dynamic-side-indicator';

const sideGenerator = new DynamicSideIndicator();

export interface PageState {
  loading: boolean;
  error?: string;
  left?: {
    pageConfig: any;
    pageMenu: any;
  };
  right?: {
    pageConfig: any;
    pageMenu: any;
  };
}

export const initialPageState = {
  loading: false,
  left: {
    pageConfig: null,
    pageMenu: null
  },
  right: {
    pageConfig: null,
    pageMenu: null
  }
};

function loadPageSuccess(state: PageState, action: storeActions.LoadPageSuccess) {
  const {updateSide, staticSide} = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    [updateSide]: {
      pageConfig: action.payload.pageConfig.pages,
      pageMenu: action.payload.pageConfig.menuOptions
    },
    [staticSide]: {
      pageConfig: state[staticSide].pageConfig,
      pageMenu: state[staticSide].pageMenu
    }
  };
}

export function pageReducer(state = initialPageState, action: storeActions.pageAll): PageState {

  switch (action.type) {
    case storeActions.LOAD_PAGE: return { ...state,  loading: true };

    case storeActions.LOAD_PAGE_SUCCESS: return loadPageSuccess(state, action);

    case storeActions.LOAD_PAGE_FAILED: return {...state, loading: false, error: 'Page config kan niet opgehaald worden!'};

    default:
      return state;
  }
}
