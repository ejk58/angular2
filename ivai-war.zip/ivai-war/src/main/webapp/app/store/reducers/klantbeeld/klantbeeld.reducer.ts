import * as storeActions from '../../actions/klantbeeld/klantbeeld.actions';
import {SubjectValidator} from '../../../commons/subject-validators';
import {DynamicSideIndicator} from '../../../commons/dynamic-side-indicator';
import {Klantbeeld} from '../../../components/klantbeeld/klantbeeld';
import {Subject} from '../../../classes/subject';

const sideGenerator = new DynamicSideIndicator();
const subjectValidator = new SubjectValidator();

export interface SearchResult {
  name: string;
  subjects: Subject[];
  subjectSearchKey: string;
  error?: string;
}

export interface KlantbeeldState {
  loading: boolean;
  error?: number;
  menuItems: any;

  left?: {
    active: Klantbeeld;
    searchResults: SearchResult[];
  };
  right?: {
    active: Klantbeeld;
    searchResults: SearchResult[];
  };
}

export const initialKlantbeeldState: KlantbeeldState = {
  loading: false,
  menuItems: [],
  left: {
    active: null,
    searchResults: []
  },
  right: {
    active: null,
    searchResults: []
  }
};

function loadKlantbeeld(state: KlantbeeldState, action: storeActions.LoadMenu): KlantbeeldState {
  return {
    loading: true,
    menuItems: state.menuItems,
    left: {
      active: state.left.active,
      searchResults: []
    },
    right: {
      active: state.right.active,
      searchResults: []
    }
  };
}

function loadKlantbeeldSuccess(state: KlantbeeldState, action: storeActions.LoadMenuSuccess): KlantbeeldState {
  return {
    loading: false,
    menuItems: [...state.menuItems, ...action.payload],
    left: {
      active: state.left.active,
      searchResults: state.left.searchResults
    },
    right: {
      active: state.right.active,
      searchResults: state.right.searchResults
    }
  };
}

function loadKlantbeeldFailed(state: KlantbeeldState, action: storeActions.LoadMenuFailed): KlantbeeldState {
  return {
    loading: false,
    error: (action.payload && action.payload.status ? action.payload.status : -1),
    menuItems: state.menuItems,
    left: {
      active: state.left.active,
      searchResults: state.left.searchResults
    },
    right: {
      active: state.right.active,
      searchResults: state.right.searchResults
    }
  };
}

function loadSelectedKlantbeeld(state: KlantbeeldState, action: storeActions.LoadSelectedKlantbeeld): KlantbeeldState {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  let updateSearchResults: SearchResult[];
  const updateSearchResult: SearchResult = { name: action.payload.klantbeeld.name, subjects: [], subjectSearchKey: undefined };

  if (state[updateSide].searchResults.length === 0) {
    updateSearchResults = [updateSearchResult];
  } else {
    const kbExists: boolean = state[updateSide].searchResults.some((searchResult: SearchResult) => {
      return searchResult.name === updateSearchResult.name;
    });

    if (kbExists) {
      updateSearchResults = state[updateSide].searchResults;
    } else {
      updateSearchResults = [...state[updateSide].searchResults, updateSearchResult];
    }
  }

  return {
    loading: false,
    menuItems: state.menuItems,
    [updateSide]: {
      active: state[updateSide].active,
      searchResults: updateSearchResults
    },
    [staticSide]: {
      active: state[staticSide].active,
      searchResults: state[staticSide].searchResults
    }
  };
}

/**
 * On load Active klantbeeld (which is navigated to),
 * reset selected klantbeeld items as false
 */
function loadActiveKlantbeeld(state: KlantbeeldState, action: storeActions.LoadActiveKlantbeeld): KlantbeeldState {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    menuItems: state.menuItems,
    [updateSide]: {
      active: { ...state[updateSide].active, ...action.payload.klantbeeld },
      searchResults: state[updateSide].searchResults
    },
    [staticSide]: {
      active: state[staticSide].active,
      searchResults: state[staticSide].searchResults
    }
  };
}

function loadActiveKlantbeeldSubjects(state: KlantbeeldState, action: storeActions.LoadActiveKlantbeeldSubjects): KlantbeeldState {
  const payload = action.payload;
  const { updateSide, staticSide } = sideGenerator.getSides(payload.side);

  const searchResultIndex: number = state[updateSide].searchResults.findIndex(searchResult => searchResult.name === payload.klantbeeldName);
  state[updateSide].searchResults[searchResultIndex] = {
    name: payload.klantbeeldName,
    subjects: payload.subjects,
    subjectSearchKey: payload.subjectSearchKey,
    error: payload.err ? subjectValidator.generateErrorMessage(payload.err, payload.type, payload.subjectNr) : undefined
  };

  return {
    loading: false,
    menuItems: state.menuItems,
    [updateSide]: {
      active: state[updateSide].active,
      searchResults: [...state[updateSide].searchResults]
    },
    [staticSide]: {
      active: state[staticSide].active,
      searchResults: state[staticSide].searchResults
    }
  };
}

function clearActiveKlantbeeld(state: KlantbeeldState, action: storeActions.ClearActiveKlantbeeld): KlantbeeldState {
  const { updateSide, staticSide } = sideGenerator.getSides(action.payload.side);

  return {
    loading: false,
    menuItems: state.menuItems,
    [updateSide]: {
      active: null,
      searchResults: []
    },
    [staticSide]: {
      active: state[staticSide].active,
      searchResults: state[staticSide].searchResults
    }
  };
}

export function klantbeeldReducer(state = initialKlantbeeldState, action: storeActions.KlantbeeldActions): KlantbeeldState {

  switch (action.type) {
    case storeActions.LOAD_MENU: return loadKlantbeeld(state, action);

    case storeActions.LOAD_MENU_SUCCESS: return loadKlantbeeldSuccess(state, action);

    case storeActions.LOAD_MENU_FAILED: return loadKlantbeeldFailed(state, action);

    case storeActions.LOAD_SELECTED_KLANTBEELD: return loadSelectedKlantbeeld(state, action);

    case storeActions.LOAD_ACTIVE_KLANTBEELD: return loadActiveKlantbeeld(state, action);

    case storeActions.LOAD_SELECTED_KLANTBEELD_SUBJECTS: return loadActiveKlantbeeldSubjects(state, action);

    case storeActions.CLEAR_SELECTED_KLANTBEELD: return clearActiveKlantbeeld(state, action);

    case storeActions.KLANTBEELD_RESET: return initialKlantbeeldState;

    default:
      return state;
  }
}
