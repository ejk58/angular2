import * as modalActions from '../../actions/modal-wrapper/modal-wrapper.actions';

export interface ModalWrapperstate {
  activeWrapper: string;
}

export const initialModalState: ModalWrapperstate = {
  activeWrapper: 'none'
};

export function modalWrapperReducer(state = initialModalState, action: modalActions.ModalActions): ModalWrapperstate {

  switch (action.type) {
    case modalActions.MODAL_OPEN: {
      return {
        activeWrapper: action.payload
      };
    }

    case modalActions.MODAL_CLOSE: {
      return {
        activeWrapper: 'none'
      };
    }

    default:
      return state;
  }
}
