import * as fromReducers from '../../reducers';
import {createSelector} from '@ngrx/store';
import {getRouterStateLeft, getRouterStateRight} from '../router/router.selectors';

export const getPageState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.page);

export const getPageLoadingState = createSelector(
  getPageState, page => page.loading);

// Get the state of **left** page state
export const getPageConfigStateLeft = createSelector(
  getPageState, page => page.left.pageConfig);

export const getPageMenuStateLeft = createSelector(
  getPageState, page => page.left.pageMenu);

export const getPageHasGlobalFiltersLeft = createSelector(
  getRouterStateLeft, getPageConfigStateLeft,
  (routerState, pageConfig) => {
    const page = pageConfig.find(p => p.key === routerState.domain);
    return page && page.globalFilterWidget != null;
  });

// Get the state of **right** page state
export const getPageConfigStateRight = createSelector(
  getPageState, page => page.right.pageConfig);

export const getPageMenuStateRight = createSelector(
  getPageState, page => page.right.pageMenu);

export const getPageHasGlobalFiltersRight = createSelector(
  getRouterStateRight, getPageConfigStateRight,
  (routerState, pageConfig) => {
    const page = pageConfig.find(p => p.key === routerState.domain);
    return page && page.globalFilterWidget != null;
  });
