import { createSelector } from '@ngrx/store';
import * as fromReducers from '../../reducers';

export const getKlantbeeldState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.klantbeeld);

export const getKlantbeeldMenu = createSelector(
  getKlantbeeldState, klantbeeld => klantbeeld.menuItems);

export const getKlantbeeldLoading = createSelector(
  getKlantbeeldState, klantbeeld => klantbeeld.loading);

export const getKlantbeeldError = createSelector(
  getKlantbeeldState, klantbeeld => klantbeeld.error);

// Get the state of **left** side state & klantbeeld properties
export const getKlantbeeldStateLeft = createSelector(
  getKlantbeeldState, klantbeeld => klantbeeld.left);

export const getActiveKlantbeeldLeft = createSelector(
  getKlantbeeldStateLeft, klantbeeld => klantbeeld.active);

export const getActiveViewIdKlantbeeldLeft = createSelector(
  getKlantbeeldStateLeft, klantbeeld => klantbeeld.active ? klantbeeld.active.viewId : null);

export const getSelectedKlantbeeldLeft = createSelector(
  getKlantbeeldStateLeft, klantbeeld => klantbeeld.searchResults);

// Get the state of **right** side state & klantbeeld properties
export const getKlantbeeldStateRight = createSelector(
  getKlantbeeldState, klantbeeld => klantbeeld.right);

export const getActiveKlantbeeldRight = createSelector(
  getKlantbeeldStateRight, klantbeeld => klantbeeld.active);

export const getActiveViewIdKlantbeeldRight = createSelector(
  getKlantbeeldStateRight, klantbeeld => klantbeeld.active ? klantbeeld.active.viewId : null);

export const getSelectedKlantbeeldRight = createSelector(
  getKlantbeeldStateRight, klantbeeld => klantbeeld.searchResults);
