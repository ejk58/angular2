import { createSelector } from '@ngrx/store';
import * as fromReducers from '../../reducers';

export const getSubjectState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.subject);

export const getSubjectLoadingState = createSelector(
  getSubjectState, subject => subject.loading);

// Get the state of **left** side state & subject properties
export const getSelectedSubjectLeft = createSelector(
  getSubjectState, klantbeeld => klantbeeld.left.selected);

// Get the state of **right** side state & subject properties
export const getSelectedSubjectRight = createSelector(
  getSubjectState, klantbeeld => klantbeeld.right.selected);
