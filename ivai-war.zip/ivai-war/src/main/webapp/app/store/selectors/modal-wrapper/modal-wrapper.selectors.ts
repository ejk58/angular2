import { createSelector } from '@ngrx/store';
import * as fromReducers from '../../reducers';

export const getModalWrapperState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.modalWrapper.activeWrapper);

