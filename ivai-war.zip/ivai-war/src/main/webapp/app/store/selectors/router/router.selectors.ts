import { createSelector } from '@ngrx/store';
import * as fromReducers from '../../reducers';

export const getRouterState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.router.state);

export const getRouterStateLeft = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.router.state.routerSidesParams.left);

export const getRouterStateRight = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => appStore.router.state.routerSidesParams.right);

export const getActiveUrl = createSelector(
  getRouterState, (router: any) => router.url);

export const getParams = createSelector(
  getRouterState, (router: any) => router.params);

export const getQueryParams = createSelector(
  getRouterState, (router: any) => router.queryParams);

export const getRouterSides = createSelector(
  getRouterState, (router: any) => router.routerSidesParams);
