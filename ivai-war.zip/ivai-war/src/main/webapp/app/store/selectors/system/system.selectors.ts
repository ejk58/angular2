import * as fromReducers from '../../reducers';
import {createSelector} from '@ngrx/store';

export const getSystemState = createSelector(
  fromReducers.getAppState, (appStore: fromReducers.AppState) => {
    return appStore.system;
  });

export const getSystemVersionState = createSelector(
  getSystemState, system => system.version);

export const getSystemConfigurationUpdateTimeState = createSelector(
  getSystemState, system => system.configurationUpdateTime);

export const getSystemKtaEnvironmentState = createSelector(
  getSystemState, system => system.ktaEnvironment);

export const getSystemHierarchicalGraphMaxRows = createSelector(
  getSystemState, system => system.hierarchicalGraphMaxRows);
