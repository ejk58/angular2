import { Action } from '@ngrx/store';

import { Klantbeeld } from '../../../components/klantbeeld/klantbeeld';
import {Subject} from '../../../classes/subject';


export const LOAD_MENU          = '[Klantbeeld] Load Menu';
export const LOAD_MENU_SUCCESS  = '[Klantbeeld] Load Menu Success';
export const LOAD_MENU_FAILED   = '[Klantbeeld] Load Menu Failed';

export const LOAD_ACTIVE_KLANTBEELD               = '[Klantbeeld] Load Active Klantbeeld';
export const LOAD_SELECTED_KLANTBEELD             = '[Klantbeeld] Load Selected Klantbeeld';
export const LOAD_SELECTED_KLANTBEELD_SUBJECTS    = '[Klantbeeld] Load Selected Klantbeeld Subjects';
export const CLEAR_SELECTED_KLANTBEELD            = '[Klantbeeld] Clear Selected Klantbeeld';

export const SELECT_KLANTBEELD              = '[Klantbeeld] Select';
export const SELECT_KLANTBEELD_WITH_SUBJECT = '[Klantbeeld] Select With subject';
export const KLANTBEELD_SHARED_EFFECT       = '[Klantbeeld] Shared Effect';

export const KLANTBEELD_RESET = '[Klantbeeld] Reset';

export class LoadMenu implements Action {
  readonly type = LOAD_MENU;
}

export class LoadMenuSuccess implements Action {
  readonly type = LOAD_MENU_SUCCESS;

  constructor(public payload: Klantbeeld[]) { }
}

export class LoadMenuFailed implements Action {
  readonly type = LOAD_MENU_FAILED;

  constructor(public payload: any) { }
}

export class LoadActiveKlantbeeld implements Action {
  readonly type = LOAD_ACTIVE_KLANTBEELD;

  constructor(public payload: {side: string; klantbeeld: Klantbeeld}) { }
}

export class LoadSelectedKlantbeeld implements Action {
  readonly type = LOAD_SELECTED_KLANTBEELD;

  constructor(public payload: {side: string; klantbeeld: Klantbeeld}) { }
}

export class LoadActiveKlantbeeldSubjects implements Action {
  readonly type = LOAD_SELECTED_KLANTBEELD_SUBJECTS;

  constructor(public payload: {
    side: string;
    klantbeeldName: string;
    subjects?: Subject[];
    subjectNr?: string;
    subjectSearchKey?: string;
    type?: any;
    err?: any}) { }
}

export class ClearActiveKlantbeeld implements Action {
  readonly type = CLEAR_SELECTED_KLANTBEELD;

  constructor(public payload: {side: string; }) { }
}

export class SelectKlantbeeld implements Action {
  readonly type = SELECT_KLANTBEELD;

  constructor(public payload: any) { }
}

export class SelectKlantbeeldWithSubject implements Action {
  readonly type = SELECT_KLANTBEELD_WITH_SUBJECT;

  constructor(public payload: any) { }
}

export class KlantbeeldSharedEffect implements Action {
  readonly type = KLANTBEELD_SHARED_EFFECT;

  constructor(public payload: any) { }
}

export class KlantbeeldReset implements Action {
  readonly type = KLANTBEELD_RESET;
}

export type KlantbeeldActions
  = LoadMenu
  | LoadMenuSuccess
  | LoadMenuFailed
  | LoadActiveKlantbeeld
  | LoadSelectedKlantbeeld
  | LoadActiveKlantbeeldSubjects
  | SelectKlantbeeldWithSubject
  | KlantbeeldSharedEffect
  | ClearActiveKlantbeeld
  | SelectKlantbeeld
  | KlantbeeldReset;
