import {Action} from '@ngrx/store';

/* Actions To Populate Klantbeeld menu */
export const LOAD_RELATIONS          = '[Relations Menu] Load Menu';
export const LOAD_RELATIONS_SUCCESS  = '[Relations Menu] Load Menu Success';
export const LOAD_RELATIONS_FAILED   = '[Relations Menu] Load Menu Failed';

export const RELATION_SELECTED  = '[Relations] Selected';

export const RELATIONS_RESET  = '[Relations Menu] Reset';

export class LoadRelations implements Action {
  readonly type = LOAD_RELATIONS;

  constructor(public payload: {side: string, klantbeeldViewId: string, subjectModel: Object}) { }
}

export class LoadRelationsSuccess implements Action {
  readonly type = LOAD_RELATIONS_SUCCESS;

  constructor(public payload: {side: string; list: any}) { }
}

export class LoadRelationsFailed implements Action {
  readonly type = LOAD_RELATIONS_FAILED;

  constructor(public payload: any) { }
}

export class RelationSelected implements Action {
  readonly type = RELATION_SELECTED;

  constructor(public payload: any) { }
}


export class RelationsReset implements Action {
  readonly type = RELATIONS_RESET;
}

export type RelationsAll
  = LoadRelations
  | LoadRelationsSuccess
  | LoadRelationsFailed
  | RelationSelected
  | RelationsReset;
