import { Action } from '@ngrx/store';
import {MenuItem} from 'primeng/api';
export const BREADCRUMB_ADD = '[BREADCRUMB] Add';
export const BREADCRUMB_REMOVE = '[BREADCRUMB] Remove';
export const BREADCRUMB_RESET = '[BREADCRUMB] Reset';

export class BreadcrumbAdd implements Action {
  readonly type = BREADCRUMB_ADD;

  constructor(public payload: {side: string; breadcrumb: MenuItem, newpage: string }) { }
}

export class BreadcrumbRemove implements Action {
  readonly type = BREADCRUMB_REMOVE;

  constructor(public payload: {side: string; breadcrumb: MenuItem }) { }
}

export class BreadcrumbReset implements Action {
  readonly type = BREADCRUMB_RESET;

  constructor(public payload: {side: string; breadcrumb: MenuItem }) { }
}


export type BreadcrumbActions = BreadcrumbAdd | BreadcrumbRemove | BreadcrumbReset;
