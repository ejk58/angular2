import {Action} from '@ngrx/store';

export const WIDGETS_LOAD = '[WIDGETS] Widgets Load';
export const WIDGETS_LOAD_SUCCESS = '[WIDGETS] Widgets Load Success';
export const WIDGETS_LOAD_FAILED = '[WIDGETS] Widgets Load Failed';

export class WidgetsLoad implements Action {
  readonly type = WIDGETS_LOAD;

  constructor(public payload: any) { }
}

export class WidgetLoadSuccess implements Action {
  readonly type = WIDGETS_LOAD_SUCCESS;

  constructor(public payload: any) { }
}

export class WidgetsLoadFailed implements Action {
  readonly type = WIDGETS_LOAD_FAILED;

  constructor(public payload: any) { }
}

export type WidgetsAll =
  WidgetsLoad |
  WidgetLoadSuccess |
  WidgetsLoadFailed;
