import {Action} from '@ngrx/store';
import {Subject} from '../../../classes/subject';

export const SUBJECT_LOAD = '[SUBJECT] Subject Load';
export const SUBJECT_LOAD_SUCCESS = '[SUBJECT] Subject Load Success';
export const SUBJECT_LOAD_FAILED = '[SUBJECT] Subject Load Failed';

/* This action will be triggered to get and select "already selected subject"
 * when the app is started with copy paste url.
*/
export const SUBJECT_LOAD_SELECTED_SUBJECT =  '[SUBJECT] Load Selected Subject';

export const SUBJECT_SELECT = '[SUBJECT] Subject Select';

export const SUBJECT_CLEAR = '[SUBJECT] Subject Clear';

export const SUBJECT_RESET = '[SUBJECT] Subject Reset';

export class SubjectLoad implements Action {
  readonly type = SUBJECT_LOAD;

  constructor(public payload: any) { }
}

export class SubjectLoadSuccess implements Action {
  readonly type = SUBJECT_LOAD_SUCCESS;
}

export class SubjectLoadFailed implements Action {
  readonly type = SUBJECT_LOAD_FAILED;

  constructor(public payload: {side: string; subject: Subject}) { }
}

export class SubjectLoadSelectedSubject implements Action {
  readonly type = SUBJECT_LOAD_SELECTED_SUBJECT;

  constructor(public payload?: {side: string; klantbeeld: any; subjectModel: Object}) { }
}

export class SubjectSelect implements Action {
  readonly type = SUBJECT_SELECT;

  constructor(public payload: {side: string; subject: Subject}) { }
}

export class SubjectClear implements Action {
  readonly type = SUBJECT_CLEAR;

  constructor(public payload: {side: string; subject: any}) { }
}

export class SubjectReset implements Action {
  readonly type = SUBJECT_RESET;
}

export type SubjectAll =
  | SubjectLoad
  | SubjectReset
  | SubjectLoadSuccess
  | SubjectLoadFailed
  | SubjectLoadSelectedSubject
  | SubjectSelect
  | SubjectClear;
