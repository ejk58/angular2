import { Action } from '@ngrx/store';
import { NavigationExtras } from '@angular/router';

export const GO       = '[Router] Go';
export const BACK     = '[Router] Back';
export const FORWARD  = '[Router] Forward';
export const GOTO     = '[Router] Go To';
export const NAVIGATE_WITH_PARAMS     = '[Router] Navigate With Params';
export const NAVIGATE_WITHOUT_PARAMS     = '[Router] Navigate Without Params';

export class Go implements Action {
  readonly type = GO;

  constructor(public payload: {
    path: any[];
    query?: object;
    extras?: NavigationExtras;
  }) {}
}

export class GoTo implements Action {
  readonly type = GOTO;

  constructor(public payload: {
    side: string,
    klantbeeld: string;
    page: string;
    params: any;
  }) {}
}

export class NavigateWithoutParams implements Action {
  readonly type = NAVIGATE_WITHOUT_PARAMS;

  constructor(public payload: {
    side: string,
    viewId: string;
    initTab: any;
  }) {}
}

export class NavigateWithParams implements Action {
  readonly type = NAVIGATE_WITH_PARAMS;

  constructor(public payload: any) {}
}

export class Back implements Action {
  readonly type = BACK;
}

export class Forward implements Action {
  readonly type = FORWARD;
}

export type Actions
  = Go
  | GoTo
  | NavigateWithoutParams
  | NavigateWithParams
  | Back
  | Forward;
