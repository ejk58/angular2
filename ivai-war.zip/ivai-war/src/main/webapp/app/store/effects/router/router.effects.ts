import { Injectable } from '@angular/core';
import { Router, Params } from '@angular/router';
import { Location } from '@angular/common';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { map, tap, first } from 'rxjs/operators';

import * as routerActions from '../../actions';
import * as fromSelectors from '../../selectors';
import { Store } from '@ngrx/store';
import { SelectorSideIndicator } from '../../../commons/store-selector-side-indicator';

@Injectable()
export class RouterEffects {
  @Effect({ dispatch: false })
  navigate$ = this.actions$.pipe(
    ofType(routerActions.GO),
    map((action: routerActions.Go) => action.payload),
    tap(({ path, query: queryParams, extras}) => {
      this.router.navigate(path, { queryParams, ...extras });
    })
  );

  @Effect({ dispatch: false })
  navigateTo$ = this.actions$.pipe(
    ofType(routerActions.GOTO),
    map((action: routerActions.GoTo) => action.payload),
    tap(({ side, klantbeeld, page, params}) => {
      this.router.navigate(['/main', { outlets: { [side]: [klantbeeld, page, params]}}]);
    })
  );

  @Effect({ dispatch: false })
  navigateToWithoutParams$ = this.actions$.pipe(
    ofType(routerActions.NAVIGATE_WITHOUT_PARAMS),
    map((action: routerActions.NavigateWithoutParams) => action.payload),
    tap(({ side, viewId, initTab}) => {
      const otherSide = side === 'left' ? 'right' : 'left';
      const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(otherSide, 'getRouterState');
      this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(first()).subscribe(state => {
        const commands = {
          outlets: {
            [side]: [viewId, initTab]
          }
        };

        if (state) {
          this.preserveOtherSide(state, commands, otherSide);
        }

        this.router.navigate(['/main', commands]);
      });
    })
  );

  @Effect({ dispatch: false })
  navigateToWithParams$ = this.actions$.pipe(
    ofType(routerActions.NAVIGATE_WITH_PARAMS),
    map((action: routerActions.NavigateWithParams) => action.payload),
    tap(({ side, klantbeeld, params}) => {
      const otherSide = side === 'left' ? 'right' : 'left';
      const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(otherSide, 'getRouterState');
      this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(first()).subscribe(state => {
        const commands = {
          outlets: {
            [side]: [klantbeeld.viewId, klantbeeld.initTab, params]
          }
        };

        if (state) {
          this.preserveOtherSide(state, commands, otherSide);
        }

        this.router.navigate(['/main', commands]);
      });
    })
  );

  @Effect({ dispatch: false })
  navigateBack$ = this.actions$.pipe(
    ofType(routerActions.BACK),
    tap(() => this.location.back())
  );

  @Effect({ dispatch: false })
  navigateForward$ = this.actions$.pipe(
    ofType(routerActions.FORWARD),
    tap(() => this.location.forward())
  );

  constructor(
    private readonly actions$: Actions,
    private readonly router: Router,
    private readonly location: Location,
    private readonly store: Store<any>,
    private readonly selectorSideIndicator: SelectorSideIndicator
  ) {}

  private preserveOtherSide(state: Params, commands: any, otherSide: 'left'|'right'): void {
    const filtersJson = (state.filters) ? JSON.stringify(state.filters) : undefined;
    const otherViewId = state.klantbeeld;
    const otherTab = state.domain;

    const { ...otherParams } = state;
    delete otherParams.klantbeeld;
    delete otherParams.domain;
    delete otherParams.filters;

    if (state.filters) {
      commands.outlets[otherSide] = [otherViewId, otherTab, filtersJson, otherParams];
    } else {
      commands.outlets[otherSide] = [otherViewId, otherTab, otherParams];
    }
  }
}
