import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {Observable, of} from 'rxjs';
import {catchError, map, mergeMap} from 'rxjs/operators';
import * as storeActions from '../../actions';
import {Subject} from '../../../classes/subject';
import {SubjectPresentation} from '../../../classes/subject-presentation';
import {PathKey} from '../../../classes/path-key';

@Injectable()
export class RelationEffects {
  constructor(
    private readonly action$: Actions,
    private readonly http: HttpClient
  ) { }

  @Effect() relationLoad$: Observable<any> = this.action$.pipe(
    ofType(storeActions.LOAD_RELATIONS),
    mergeMap((action: storeActions.LoadRelations) => {
      const side = action.payload.side;
      const viewId = action.payload.klantbeeldViewId;
      const subjectModel = action.payload.subjectModel;

      let restUrl = 'rest/wizard?viewId=' + viewId;
      Object.keys(subjectModel).forEach(key => {
        if (subjectModel[key]) {
          restUrl += '&' + key + '=' + subjectModel[key];
        }
      });

      return this.http
        .get(restUrl, {withCredentials: true})
        .pipe(map((relations: any) => new storeActions.LoadRelationsSuccess({side, list: relations.data})))
        .pipe(catchError(err => of(new storeActions.LoadRelationsFailed(err))));
    }));

  @Effect() selectedRelation$: Observable<any> = this.action$.pipe(
    ofType(storeActions.RELATION_SELECTED),
    mergeMap((action: storeActions.RelationSelected) => {
      const payload = action.payload;
      const klantbeeld = payload.klantbeeld;
      const subject: Subject = this.createSubject(payload.params, payload.relation);
      const params: any = this.constructParams(subject.model, klantbeeld.pathKeys);

      return [
        new storeActions.SelectKlantbeeldWithSubject({side: payload.side, klantbeeld, subject, params})
      ];
    }));

  // TODO: The way a subject is created is a temporary solution for as long as a relation in the list
  // TODO: of relations in the relation-menu is not properly filled with the required data. (3-6-2019, EK)
  private createSubject(params: any, relation: any): Subject {
    const subjectModel: Object = {subjectNr: relation.subjectNr};
    if (params.entityNr) {
      subjectModel['entityNr'] = params.entityNr;
    }
    if (params.taxYear) {
      subjectModel['taxYear'] = params.taxYear;
    }
    const subjectPresentation: SubjectPresentation = SubjectPresentation.createWithName(relation.name);
    return new Subject(subjectPresentation, subjectModel);
  }

  constructParams(subjectModel: Object, pathKeys: PathKey[]): any {
    const params: any = {};
    pathKeys.forEach(pathKey => {
      if (pathKey.mandatory) {
        params[pathKey.name] = subjectModel[pathKey.name];
      }
    });
    return params;
  }

}
