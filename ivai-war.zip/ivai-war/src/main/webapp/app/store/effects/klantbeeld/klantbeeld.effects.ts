import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {PageTitleService} from '../../../services/page-title.service';
import * as storeActions from '../../actions';
import {Observable, of} from 'rxjs';
import {catchError, map, mergeMap, switchMap} from 'rxjs/operators';

@Injectable()
export class KlantbeeldEffects {
  constructor(
    private readonly action$: Actions,
    private readonly pageTitleService: PageTitleService,
    private readonly http: HttpClient
  ) { }

  @Effect() menuList$: Observable<any> = this.action$.pipe(
      ofType(storeActions.LOAD_MENU),
      switchMap(() => {
      return this.http
        .get('rest/view')
        .pipe(map((data: any) => new storeActions.LoadMenuSuccess(data.views)))
        .pipe(catchError(err => of(new storeActions.LoadMenuFailed(err))));
    }));

  @Effect() selectKlantbeeld$: Observable<any> = this.action$.pipe(
      ofType(storeActions.SELECT_KLANTBEELD),
      mergeMap((action: storeActions.SelectKlantbeeld) => {
      const payload = action.payload;

      if (payload.klantbeeld.subjectTypes.length === 0) {
        return [
          new storeActions.KlantbeeldSharedEffect({side: payload.side, klantbeeld: payload.klantbeeld, subject: payload.subject}),
          new storeActions.NavigateWithoutParams({
             side: payload.side, viewId: payload.klantbeeld.viewId, initTab: payload.klantbeeld.initTab
            })
        ];
      }
    }));

    @Effect() selectKlantbeeldWithSubject$: Observable<any> = this.action$.pipe(
      ofType(storeActions.SELECT_KLANTBEELD_WITH_SUBJECT),
      mergeMap((action: storeActions.SelectKlantbeeldWithSubject) => {
      const payload = action.payload;

        this.pageTitleService.update(payload.subject.model.subjectNr, payload.subject.presentation.name);

        return [
          new storeActions.KlantbeeldSharedEffect({side: payload.side, klantbeeld: payload.klantbeeld, subject: payload.subject}),
          new storeActions.LoadRelations({side: payload.side, klantbeeldViewId: payload.klantbeeld.viewId, subjectModel: payload.subject.model}),
          new storeActions.NavigateWithParams({ side: payload.side, klantbeeld: payload.klantbeeld, params: payload.params })
        ];
    }));

    @Effect() sharedEffect$: Observable<any> = this.action$.pipe(
      ofType(storeActions.KLANTBEELD_SHARED_EFFECT),
      mergeMap((action: storeActions.KlantbeeldSharedEffect) => {
      const payload = action.payload;

        return [
          new storeActions.LoadPage({side: payload.side, klantbeeld: payload.klantbeeld.viewId}),
          new storeActions.SubjectSelect({ side: payload.side, subject: payload.subject }),
          new storeActions.LoadActiveKlantbeeld({side: payload.side, klantbeeld: payload.klantbeeld}),
          new storeActions.HeaderSelectMenu({side: payload.side, menu: 'none'})
        ];
    }));
}
