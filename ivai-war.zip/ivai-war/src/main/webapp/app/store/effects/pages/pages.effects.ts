import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {Observable, of} from 'rxjs';
import {catchError, map, mergeMap} from 'rxjs/operators';
import * as pageActions from '../../actions/pages/pages.actions';

@Injectable()
export class PageEffects {
  constructor(
    private readonly action$: Actions,
    private readonly http: HttpClient
  ) { }

  @Effect() page$: Observable<any> = this.action$.pipe(
      ofType(pageActions.LOAD_PAGE),
      mergeMap((action: pageActions.LoadPage) => {
      return this.http
        .get(`rest/page/${action.payload.klantbeeld}`)
        .pipe(map((data: any) => new pageActions.LoadPageSuccess({side: action.payload.side, pageConfig: data})))
        .pipe(catchError(err => of(new pageActions.LoadPageFailed(err))));
    }));
}
