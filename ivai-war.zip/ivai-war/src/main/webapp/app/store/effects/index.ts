import { KlantbeeldEffects } from './klantbeeld/klantbeeld.effects';
import { PageEffects } from './pages/pages.effects';
import { SubjectEffects } from './subject/subject.effects';
import { RouterEffects } from './router/router.effects';
import { RelationEffects } from './relation/relation.effects';
import { SystemEffects } from './system/system.effects';

export const effects = [
  KlantbeeldEffects,
  PageEffects,
  SubjectEffects,
  RouterEffects,
  RelationEffects,
  SystemEffects
];

export * from './klantbeeld/klantbeeld.effects';
export * from './pages/pages.effects';
export * from './subject/subject.effects';
export * from './router/router.effects';
export * from './relation/relation.effects';
export * from './system/system.effects';
