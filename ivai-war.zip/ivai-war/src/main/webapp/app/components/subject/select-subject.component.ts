import {Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewEncapsulation} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {TrackingService} from '../../services/tracking.service';
import {PathKey} from '../../classes/path-key';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import * as storeActions from '../../store/actions';
import * as fromSelectors from '../../store/selectors';
import {Subject} from '../../classes/subject';
import {SearchResult} from '../../store/reducers';
import {map} from 'rxjs/operators';
import {Klantbeeld} from '../klantbeeld/klantbeeld';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-select-subject',
  templateUrl: './select-subject.component.html',
  styleUrls: ['./select-subject.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})

export class SelectSubjectComponent implements OnInit, OnDestroy, OnChanges {

  @Input()
  side: string;

  @Input()
  klantbeeld: Klantbeeld;

  @Input()
  focus: boolean;

  @Output()
  selected: EventEmitter<boolean> = new EventEmitter<boolean>();

  public subjectSearchKey: string;
  public subjectTypes: any[];
  public selectedSubjectType: any;
  public selectedSubject: Subject;

  public loading$: Observable<boolean>;
  public searchResult$: Observable<SearchResult[]>;

  constructor(private readonly router: Router,
              private readonly route: ActivatedRoute,
              private readonly trackingService: TrackingService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit(): void {
    this.subjectTypes = this.klantbeeld.subjectTypes;
    this.selectedSubjectType = this.subjectTypes[0];
    this.loading$ = this.store.select(fromSelectors.getSubjectLoadingState);

    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeSubject => this.selectedSubject = activeSubject);
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // react to changes of 'klantbeeld' because otherwise the searchResult$ pipe is not re-evaluated
    // since the value that's being observed (klantbeeld-reducer :: klantbeeld.searchResult) has not been changed.
    if (changes.klantbeeld) {
      const indicatedSelectedKBSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedKlantbeeld');
      this.searchResult$ = this.store.select<SearchResult[]>(fromSelectors[indicatedSelectedKBSelector]).pipe(
        map(searchResult => searchResult.filter(klantbeeld => klantbeeld['name'] === this.klantbeeld.name))
      );
    }
  }

  isSelectedSubject(subject: Subject): boolean {
    if (this.selectedSubject) {
      const obj1 = JSON.stringify(subject);
      const obj2 = JSON.stringify(this.selectedSubject);

      return obj1 === obj2;
    }
    return false;
  }

  search(): void {
    this.subjectSearchKey = (this.subjectSearchKey == null) ? null : this.subjectSearchKey.replace(/^[0\.,\ \/]+|[\.,\ \/]+/g, '');

    if (this.subjectSearchKey !== null && this.subjectSearchKey !== '') {
      this.store.dispatch(new storeActions.SubjectLoad({
        side: this.side,
        klantbeeld: this.klantbeeld,
        subjectSearchKey: this.subjectSearchKey,
        subject: this.subjectSearchKey,
        type: this.selectedSubjectType
      }));
    }
  }

  selectASubject(subject: Subject): void {
    this.store.dispatch(new storeActions.SelectKlantbeeldWithSubject({
      side: this.side,
      klantbeeld: this.klantbeeld,
      subject: subject,
      params: this.constructParams(subject.model, this.klantbeeld.pathKeys)
    }));
  }

  constructParams(subjectModel: Object, pathKeys: PathKey[]): any {
    const params: any = {};
    pathKeys.forEach(pathKey => {
      if (pathKey.mandatory) {
        params[pathKey.name] = subjectModel[pathKey.name];
      }
    });
    return params;
  }
}

