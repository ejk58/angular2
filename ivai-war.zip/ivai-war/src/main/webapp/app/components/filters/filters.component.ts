import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Params, Router} from '@angular/router';

import {Store} from '@ngrx/store';
import {SelectItem} from 'primeng/api';
import {forkJoin, Observable} from 'rxjs';
import {filter, first, skip} from 'rxjs/operators';

import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {Unsubscriber} from '../../commons/unsubscriber';
import {SplitViewState} from '../../services/split-view-state.service';
import {TrackingService} from '../../services/tracking.service';
import {WidgetService} from '../../services/widget.service';
import * as fromSelectors from '../../store/selectors';

type Filter = {
  key: string;
  label: string;
  options: SelectItem[];
  placeholder: string;
  showClear: boolean;
  type: 'MultiValuePageFilter' | 'SingleValuePageFilter';
  selection?: any;
};

@Component({
  selector: 'i-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.scss'],
  providers: [Unsubscriber]
})
export class FiltersComponent implements OnDestroy, OnInit {

  @Input() widgetId: string;
  @Input() side: string;
  @Input() isFixed: boolean;

  public filters: Filter[];
  public pageSize: number;
  public filtersOpen: boolean;

  private filterWidgetInfos: any[] = [];
  private domain: string;
  private klantbeeld: string;

  constructor(private readonly route: ActivatedRoute,
              private readonly router: Router,
              private readonly widgetService: WidgetService,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly unsubscriber: Unsubscriber,
              private readonly store: Store<any>) {
  }

  ngOnInit() {
    this.initSplitViewSizesListener();
    this.initFilters();
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public onFilterChange(label: string): void {
    this.trackingService.trackEvent('filter', 'Filter globaal:' + this.side + '/gewijzigd:' + label, null, null);
    this.setFilterStateInUrl();
  }

  private initSplitViewSizesListener(): void {
    this.splitViewState.listenSizes().pipe(
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe(sizes => {
      if (sizes != null) {
        this.pageSize = sizes[this.side];
      } else {
        this.pageSize = 10000;
      }
    });
  }

  private initFilters(): void {
    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    this.filters = [];
    this.widgetService.get(this.widgetId, this.side, null).pipe(
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe(filterContainer => {
      this.filterWidgetInfos = filterContainer.options.widgets;
      const filterWidgets$ = this.filterWidgetInfos.map(this.getFilterWidgets, this);
      const routerState$ = this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(first());
      forkJoin(
        routerState$,
        ...filterWidgets$
      ).pipe(
        this.unsubscriber.takeUntilForUnsubscribe
      ).subscribe(([routerState, ...filterWidgets]) => {
        this.klantbeeld = routerState.klantbeeld;
        this.domain = routerState.domain;
        this.filters = filterWidgets.map(filterWidget => this.createFilter(filterWidget, routerState));
        this.startUpdatingFiltersFromRouterState();
      });
    });
  }

  private startUpdatingFiltersFromRouterState(): void {
    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(
      skip(1),
      filter(routerState => routerState && routerState.klantbeeld === this.klantbeeld && routerState.domain === this.domain),
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe(routerState => {
      this.filters.forEach(filter => this.setFilterSelectionBasedOnRouterState(filter, routerState, true));
      this.setFilterOptions();
    });
  }

  private setFilterOptions(): void {
    const newFilter = {};
    this.filters.forEach(filter => {
      if (filter.selection != undefined) {
        newFilter[filter.key] = filter.selection;
      }
    });
    forkJoin(
      this.filterWidgetInfos.map(filterWidgetInfo => this.widgetService.get(filterWidgetInfo.name, this.side, newFilter))
    ).pipe(
      this.unsubscriber.takeUntilForUnsubscribe
    ).subscribe(filterWidgets => {
      filterWidgets.forEach((filterWidget, i) => {
        this.filters[i].options = this.createOptions(filterWidget.data, filterWidget.options.unfilteredOption);
      });
    });
  }

  private setFilterSelectionBasedOnRouterState(filter: any, routerState: Params, routerStateCanClearFilters: boolean): void {
    const routerFilterValue = routerState[filter.key];
    if (routerFilterValue != null || routerStateCanClearFilters) {
      if (filter.type === 'SingleValuePageFilter') {
        filter.selection = this.toSingleValueFilterValue(routerFilterValue);
      } else {
        filter.selection = this.toMultiValueFilterValue(routerFilterValue);
      }
    }
  }

  private setFilterStateInUrl(): void {
    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(
      first(),
    ).subscribe(routerState => {
      const fullParams = { ...routerState };
      delete fullParams.klantbeeld;
      delete fullParams.domain;
      this.filters.forEach(filter => {
        if (filter.selection != null && !(Array.isArray(filter.selection) && filter.selection.length === 0)) {
          fullParams[filter.key] = filter.selection;
        } else {
          delete fullParams[filter.key];
        }
      });
      this.router.navigate([fullParams], { relativeTo: this.route });
    });
  }

  private toSingleValueFilterValue(value: string | number): string | number | undefined {
    return isNaN(value as any) ? value : Number(value);
  }

  private toMultiValueFilterValue(value: (string|number)[] | string | number): (string|number)[] | undefined {
    if (typeof value === 'undefined' || Array.isArray(value)) {
      return value;
    } else {
      return ('' + value).split(',').map(this.toSingleValueFilterValue);
    }
  }

  private getFilterWidgets(filterWidgetInfo: any): Observable<any> {
    return this.widgetService.get(filterWidgetInfo.name, this.side, null);
  }

  private createFilter(filterWidget: any, routerState: Params): Filter {
    const filter = this.createFilterBasedOnConfiguration(filterWidget);
    this.setFilterSelectionBasedOnRouterState(filter, routerState, false);
    return filter;
  }

  private createFilterBasedOnConfiguration(filterWidget: any): Filter {
    const forcedSelection = filterWidget.options.forcedSelection ? JSON.parse(filterWidget.options.forcedSelection) : false;
    const filterOptions = this.createOptions(filterWidget.data, filterWidget.options.unfilteredOption);

    const filter: Filter = {
      key: filterWidget.data[0] ? filterWidget.data[0].Filter.key : filterWidget.options.label,
      label: filterWidget.options.label,
      options: filterOptions,
      placeholder: filterWidget.options.label,
      showClear: true,
      type: filterWidget.type
    };

    if (forcedSelection) {
      filter.placeholder = null;
      filter.showClear = false;

      if (filterOptions.length > 0) {
        filter.selection = filterOptions[0].value;
      }
    }

    return filter;
  }

  private createOptions(data: any[], unfilteredOption?: string): SelectItem[] {
    const options = data.map(option => {
      let label: string = option.Filter.label;
      if (option.Filter.count) {
        label += ` (${option.Filter.count})`;
      }
      return {
        label: label,
        value: option.Filter.value
      };
    });

    if (unfilteredOption) {
      options.unshift({label: unfilteredOption, value: null});
    }

    return options;
  }
}
