import { Component } from '@angular/core';

import { Store } from '@ngrx/store';

@Component({
  selector: 'i-modal-wrapper',
  templateUrl: './modal-wrapper.component.html',
  styleUrls: ['./modal-wrapper.component.scss']
})
export class ModalWrapperComponent { }
