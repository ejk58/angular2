export interface Klantbeeld {
  iconName: string;
  index: number;
  initTab: string;
  name: string;
  pathKeys: Array<any>;
  subjectTypes: Array<any>;
  viewId: string;
}
