import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {Store} from '@ngrx/store';
import * as klantbeeldActions from '../../../store/actions';

@Injectable()
export class KlantBeeldenResolver implements Resolve<any> {

  constructor(private readonly store: Store<any>) { }

  resolve() {
    this.store.dispatch(new klantbeeldActions.LoadMenu());
  }
}
