import {Component, Input, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import * as storeActions from '../../store';
import * as fromSelectors from '../../store/selectors';
import {Klantbeeld} from './klantbeeld';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-klantbeeld',
  templateUrl: './klantbeeld.component.html',
  styleUrls: ['./klantbeeld.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})
export class KlantbeeldComponent implements OnInit, OnDestroy {

  @Input() side: string;

  public readonly browserIsIE = /trident\//i.test(window.navigator.userAgent);

  public klantbeeldMenu$: Observable<Klantbeeld[]>;
  public klantbeeldMenuLoading$: Observable<boolean>;
  public klantbeeldMenuError$: Observable<number>;
  public username: string;
  public loading: boolean;
  public test: any;
  public selectedKlantbeeld: any;
  public activeKlantbeeldViewId: any;
  private readonly viewId: string;

  constructor(private readonly router: Router,
              private readonly store: Store<any>,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    // Scroll top the klantbeeldMenu on start
    const kbContainer = document.getElementById('klantbeeld');
    setTimeout(() => kbContainer.scrollTop = 0, 300);

    this.klantbeeldMenu$ = this.store.select(fromSelectors.getKlantbeeldMenu);
    this.klantbeeldMenuLoading$ = this.store.select(fromSelectors.getKlantbeeldLoading);
    this.klantbeeldMenuError$ = this.store.select(fromSelectors.getKlantbeeldError);

    const indicatedKBSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getActiveViewIdKlantbeeld');
    this.store.select(fromSelectors[indicatedKBSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeKbId => this.activeKlantbeeldViewId = activeKbId);

    const indicatedSelectedKBSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedKlantbeeld');
    this.store.select(fromSelectors[indicatedSelectedKBSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(selectedKb => this.selectedKlantbeeld = selectedKb);
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public selectKlantbeeld(klantbeeld: Klantbeeld): void {
    this.store.dispatch(new storeActions.LoadSelectedKlantbeeld({side: this.side, klantbeeld}));

    if (klantbeeld.subjectTypes.length === 0) {
      this.store.dispatch(new storeActions.SelectKlantbeeld({side: this.side, klantbeeld, subject: null}));
    }
  }

  public getActiveClass(klantbeeld: Klantbeeld): string {
    return this.activeKlantbeeldViewId === klantbeeld.viewId ? 'klantbeeld-active' : '';
  }
}
