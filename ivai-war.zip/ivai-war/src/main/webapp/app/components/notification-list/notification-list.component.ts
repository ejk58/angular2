import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

import { Notification } from '../../classes/notification';

@Component({
  selector: 'i-notification-list',
  templateUrl: './notification-list.component.html'
})
export class NotificationListComponent implements OnChanges {

  @Input() public domain: string;
  @Input() public page: string;

  public notifications$: Observable<Notification[]>;

  constructor(
    private readonly http: HttpClient
  ) { }

  ngOnChanges(changes: SimpleChanges): void {
    this.notifications$ = of([]);
    this.getNotifications();
  }

  private getNotifications(): void {
    if (this.page && this.domain) {
      this.notifications$ = this.http.get<Notification[]>(`rest/notification?domainId=${this.domain}&pageId=${this.page}`, { withCredentials: true });
    }
  }
}
