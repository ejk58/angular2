export interface Page {
  key: string;
  type: 'main' | 'detail';
  title: string;
  rows: Array<any>;
  globalFilterWidget?: string;
  headerWidget?: string;
  label?: string;
}
