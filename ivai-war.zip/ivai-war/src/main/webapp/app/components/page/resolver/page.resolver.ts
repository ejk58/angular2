import {Injectable} from '@angular/core';
import {Params, Resolve} from '@angular/router';
import {Store} from '@ngrx/store';
import {first} from 'rxjs/operators';
import * as storeActions from '../../../store/actions';
import * as fromSelectors from '../../../store/selectors';
import {PathKey} from '../../../classes/path-key';
import {RouterSidesParams} from '../../../store/reducers';

@Injectable()
export class PageResolver implements Resolve<void> {

  routerState = this.store.select(fromSelectors.getRouterState);
  klantbeeld = this.store.select(fromSelectors.getKlantbeeldState);

  constructor(private readonly store: Store<any>) { }

  updatePageConfig(side, klantbeeld) {
    // Load page config and menu on url navigation
    this.store.dispatch(new storeActions.LoadPage({side, klantbeeld}));

    // Update header activeMenu / close on klantbeeld select
    this.store.dispatch(new storeActions.HeaderSelectMenu({ side, menu: 'none' }));
  }

  updateSelectedKlantbeeld(side, klantbeeld) {
    this.store.dispatch(new storeActions.LoadActiveKlantbeeld({ side, klantbeeld }));
    this.store.dispatch(new storeActions.LoadSelectedKlantbeeld({ side, klantbeeld }));
  }

  updateSubject(side: string, klantbeeld: any, subjectModel: Object) {
    this.store.dispatch(new storeActions.SubjectLoadSelectedSubject({ side, klantbeeld, subjectModel }));
  }

  updateRelations(side: string, klantbeeldViewId: string, subjectModel: Object) {
    this.store.dispatch(new storeActions.LoadRelations({ side, klantbeeldViewId, subjectModel }));
  }

  private constructSubjectModel(params: Params, pathKeys: PathKey[]): Object {
    const mandatoryPathKeys: PathKey[] = pathKeys.filter(pathKey => pathKey.mandatory);
    const subjectModel: Object = {};

    mandatoryPathKeys.forEach(pathKey => {
      if (params[pathKey.name]) {
        let parameterValue = params[pathKey.name];
        if (parameterValue === 'null') {
          parameterValue = null;
        } else if (pathKey.type === 'number') {
          parameterValue = Number(parameterValue);
        }
        subjectModel[pathKey.name] = parameterValue;
        // Temporary solution !!! See IVAI-6738 for discussion.
        if (pathKey.type === 'number' && isNaN(parameterValue)) {
          delete subjectModel[pathKey.name];
        }
      }
    });

    return subjectModel;
  }

  resolve(): void {
    // TODO:  Concat the subscriptions to avoid nested statements
    this.routerState
      .pipe(first())
      .subscribe(router => {
        const loadedKlantbeeld: string = router.params.klantbeeld;
        const activeSidesParams: RouterSidesParams = router.routerSidesParams;

        this.klantbeeld
          .pipe(first(klantbeeldState => klantbeeldState.menuItems && klantbeeldState.menuItems.length > 0))
          .subscribe(klantbeeldState => {
            Object.keys(activeSidesParams).forEach(side => {
              const activeSideParams: Params = activeSidesParams[side];
              const activeKlantbeeld = klantbeeldState.menuItems.find(kb => kb.viewId === activeSideParams.klantbeeld);
              const subjectModel: Object = this.constructSubjectModel(activeSideParams, activeKlantbeeld.pathKeys);

              this.updateSelectedKlantbeeld(side, activeKlantbeeld);
              if (Object.keys(subjectModel).length > 0) {
                this.updateSubject(side, activeKlantbeeld, subjectModel);
              }
              if (loadedKlantbeeld && klantbeeldState[side].active === null) {
                this.updatePageConfig(side, activeSideParams.klantbeeld);
                this.updateRelations(side, activeSideParams.klantbeeld, subjectModel);
              }
            });
          });
      });
  }
}
