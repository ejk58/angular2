import {DOCUMENT} from '@angular/common';
import {Component, ElementRef, Inject, OnInit, OnDestroy, ViewChild, ViewChildren, QueryList} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';

import {Store} from '@ngrx/store';
import {first} from 'rxjs/operators';
import {MenuItem} from 'primeng/components/common/api';

import {Page} from './page';
import {Side} from '../../commons/side';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {TrackingService} from '../../services/tracking.service';
import {WidgetService} from '../../services/widget.service';
import * as storeActions from '../../store/actions';
import * as fromSelectors from '../../store/selectors';
import {WidgetComponent} from '../widget/widget.component';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.scss'],
  providers: [Unsubscriber]
})

export class PageComponent implements OnInit, OnDestroy {
  public page: Page;
  public widgetsRows;
  public side: Side;
  public breadcrumbs: MenuItem[];
  public showBreadcrumb: boolean = false;
  public klantbeeld: string;
  public domain: string;
  public globalFilterOnPage: boolean;
  public globalWidgetId: string;
  public headerOnPage: boolean;
  public headerData: any;
  public headerKeys: any;
  public scrollTop: number;
  public offsetTop: number;

  private boundPageScrollFunction = this.pageScrollEventHandler.bind(this);

  @ViewChild('pageElement', {read: ElementRef}) pageElementRef: ElementRef;
  @ViewChildren(WidgetComponent) widgetComponents: QueryList<WidgetComponent>;

  private prevRouterState: Params;
  private pageConfig: any;

  constructor(@Inject(DOCUMENT) document,
              private readonly route: ActivatedRoute,
              public readonly util: PageNavigationUtilService,
              private readonly trackingService: TrackingService,
              private readonly widgetService: WidgetService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) {
  }

  ngOnInit(): void {
    this.route.params
      .pipe(first())
      .subscribe(params => {
        this.side = (this.route.outlet) as Side;
        this.trackingService.trackEvent('url',
          window.location.href.substring(30, window.location.href.length - 1),
          null, null);

        if (params.containerId) {
          setTimeout(() => {
            const container = document.getElementById(`${this.side}_${params.containerId}`);
            if (container) {
              container.scrollIntoView(true);
            }
          }, 2500);
        } else {
          document.getElementsByClassName(this.side)[0].scrollTop = 0;
        }
      });

    const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getRouterState');
    this.store.select(fromSelectors[indicatedRouterStateSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(routerState => {
        if (routerState !== undefined) {
          const klantbeeldChanged = this.prevRouterState === undefined || this.prevRouterState.klantbeeld !== routerState.klantbeeld;
          const domainChanged = this.prevRouterState === undefined || this.prevRouterState.domain !== routerState.domain;
          const changedRouterKeys: boolean = this.prevRouterState === undefined || Object.keys({...this.prevRouterState, ...routerState}).some(key => this.prevRouterState[key] !== routerState[key]);
          if (klantbeeldChanged || domainChanged) {
            this.processKlantbeeldOrDomainChange(routerState);
          } else if (changedRouterKeys) {
              this.processRouteKeysChange();
          }
          this.prevRouterState = routerState;
        }
      });

    this.addPageScrollEvent(this.boundPageScrollFunction);
  }

  ngOnDestroy(): void {
    this.removePageScrollEvent(this.boundPageScrollFunction);
    this.unsubscriber.unsubscribe();
  }

  private processKlantbeeldOrDomainChange(routerState: Params): void {
    this.klantbeeld = routerState.klantbeeld;
    this.domain = routerState.domain;

    const indicatedPageConfigSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getPageConfigState');
    this.store.select(fromSelectors[indicatedPageConfigSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(config => {
        this.pageConfig = config;
        this.widgetsRows = [];
        this.globalFilterOnPage = false;
        this.headerOnPage = false;

        if (this.pageConfig && this.domain) {
          this.page = this.pageConfig.find(page => page.key === this.domain);
          if (this.page) {
            setTimeout(() => {
              this.widgetsRows = this.page.rows;
              if (this.page.globalFilterWidget) {
                this.globalFilterOnPage = true;
                this.globalWidgetId = this.page.globalFilterWidget;
              }
              if (this.page.headerWidget) {
                this.setHeader();
              }
              this.setBreadcrumbs();
            }, 100);
          }
        }
      });
  }

  private setHeader(): void {
    this.widgetService.get(this.page.headerWidget, this.side, null)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(data => {
        this.headerData = data.data[0];
        if (this.headerData) {
          this.headerOnPage = true;
          this.headerKeys = Object.keys(this.headerData);
        }
      });
  }

  private setBreadcrumbs(): void {
    this.breadcrumbs = [];
    this.showBreadcrumb = false;
    if (this.page.type.toLowerCase() === 'detail') {
      const indicatedBreadcrumbSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getBreadcrumbState');
      this.store.select(fromSelectors[indicatedBreadcrumbSelector])
        .pipe(this.unsubscriber.takeUntilForUnsubscribe)
        .subscribe(breadcrumbs => {
          this.breadcrumbs = breadcrumbs;
          this.showBreadcrumb = this.breadcrumbs.length > 1;
        });
    } else {
      this.store.dispatch(new storeActions.BreadcrumbReset({side: this.side, breadcrumb: null}));
    }
  }

  private processRouteKeysChange(): void {
    this.widgetComponents.forEach(widget => {
      widget.reloadWidget();
    });
  }

  private addPageScrollEvent(scrollHandler): void {
      const element = document.getElementsByClassName(this.getPageClassName(this.side))[0] as HTMLInputElement;
      element.addEventListener('scroll', scrollHandler);
  }

  public isScrollToTopButtonVisible(): boolean {
    return this.scrollTop > 90;
  }

  public isPageFilterFixed(): boolean {
    return this.scrollTop > 50;
  }

  public getPageTopMargin(): number {
    return (this.page && this.page.globalFilterWidget && this.isPageFilterFixed()) ? this.offsetTop + 90 : 0;
  }

  private pageScrollEventHandler(e): void {
    this.scrollTop = e.target.scrollTop;
    this.offsetTop = e.target.offsetTop;
  }

  private removePageScrollEvent(scrollHandler): void {
    const element = document.getElementsByClassName(this.getPageClassName(this.side))[0] as HTMLInputElement;
    element.removeEventListener('scroll', scrollHandler);
  }

  public scrollToTop(sideToScroll: Side): void {
    this.trackingService.trackEvent('klik',
      'Klik tab omhoog: ' + sideToScroll,
      null, null);
    document.getElementsByClassName(this.getPageClassName(sideToScroll))[0].scrollTop = 0;
  }

  private getPageClassName(side: string): string {
    return 'page-' + side;
  }
}
