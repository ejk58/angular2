import {Component, OnDestroy, OnInit} from '@angular/core';
import {AuthenticationService} from '../../services/authentication.service';
import {Observable} from 'rxjs';
import {ActivatedRoute} from '@angular/router';
import {Store} from '@ngrx/store';
import * as fromSelectors from '../../store/selectors';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
  providers: [Unsubscriber]
})
export class FooterComponent implements OnInit, OnDestroy {

  public version: Observable<string>;
  public username: any;
  public currentRoute: string;

  constructor(private readonly auth: AuthenticationService,
              private readonly route: ActivatedRoute,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) {
    this.auth.getUserName()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(userName => {
        if (userName) {
          this.username = userName.text;
        }
      });
  }

  ngOnInit() {
    this.username = sessionStorage.getItem('username');

    this.version = this.store.select(fromSelectors.getSystemVersionState);

    this.route.params.subscribe(params => {
      this.currentRoute = this.route.snapshot.url[0].path;
    });

  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }
}
