import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {Subject} from 'rxjs';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
  providers: [Unsubscriber]
})
export class DropdownComponent implements OnInit, OnDestroy {

  @Input() showTitle: string;
  @Input() dropdownLabel: string;
  @Input() dropdownName: string;
  @Input() validationMessage: string;
  @Input() options: Array<{}>;
  @Input() required: boolean;
  @Input() selectedOption: any;
  @Input() submitEvent: Subject<any> = new Subject();
  @Input() color: string;

  @Output() selected: EventEmitter<string> = new EventEmitter<string>();

  public open: boolean;
  public active: boolean;
  public submitted: any;

  constructor(private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    this.submitEvent
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(event => this.submitted = event);
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  toggleOptions() {
    this.open ? this.open = false : this.open = true;
  }

  selectOption(selected: string) {
    this.selectedOption = selected;
    this.toggleOptions();
    this.selected.emit(selected);
  }

  public sanitizeSelector(selector: string): string {
    if (selector == null || selector.length === 0) {
      return selector;
    } else {
      return selector.replace(/\s/g, '');
    }
  }
}
