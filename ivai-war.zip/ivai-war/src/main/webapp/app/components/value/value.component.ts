import {Component, Input, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {Subject} from '../../classes/subject';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {Unsubscriber} from '../../commons/unsubscriber';
import {DataTypeService} from '../../services/data-type.service';
import {SubjectService} from '../../services/subject.service';
import {TrackingService} from '../../services/tracking.service';

@Component({
  selector: 'i-value',
  templateUrl: './value.component.html',
  styleUrls: ['./value.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [Unsubscriber]
})
export class ValueComponent implements OnInit, OnDestroy {

  @Input() type?: string;
  @Input() value?: any;
  @Input() side?: any;
  @Input() row?: any;
  @Input() column?: any;
  @Input() widgetId?: any;
  @Input() containerTabId?: number;
  @Input() domain?: any;
  @Input() page?: any;
  @Input() inner?: boolean;

  public label: string;
  public style: string;
  public hasNoDataWrapping: boolean;

  constructor(private readonly trackingService: TrackingService,
              private readonly subjectService: SubjectService,
              private readonly pageNavigationUtil: PageNavigationUtilService,
              private readonly dataTypeService: DataTypeService,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    if (this.column != null && this.row != null) {
      this.type = (!this.row['ROWTYPE'] || this.column.columnName === 'FIRSTCOL') ? this.column.columnType : this.row['ROWTYPE'];
      this.value = this.row[this.column.columnName];
      this.label = this.column.label;
      this.style = 'value' + (this.column.style == null ? '' : (' ' + this.column.style)) + this.addDefaultStyles(this.row['alignment']);
      this.hasNoDataWrapping = this.column.noDataWrapping;
    } else {
      this.label = '';
      this.style = 'value' + this.addDefaultStyles(null);
      this.hasNoDataWrapping = false;
    }
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  public getBaseType(): string {
    return this.dataTypeService.getBaseType(this.type, this.value);
  }

  public getOuterType(): string {
    return this.dataTypeService.getOuterType(this.type);
  }

  public getInnerType(): string {
    return this.dataTypeService.getInnerType(this.type);
  }

  private getDefaultAlignment(): string {
    return this.dataTypeService.getDefaultAlignment(this.type, this.value);
  }

  private getTypeFromSpecified(): string {
    return this.dataTypeService.getTypeFromSpecified(this.value);
  }

  private getValue(): any {
    let value = this.value;

    if (value != null) {
      if (value.hasOwnProperty('value')) {
        value = value.value;
      } else if (this.isAnnotatedType() && value.hasOwnProperty('Waarde')) {
        value = value.Waarde;
      } else if (this.isTrendType() && value.hasOwnProperty('Bedrag')) {
        value = value.Bedrag;
      } else if (this.isSpecifiedType() && value.hasOwnProperty('Waarde')) {
        value = value.Waarde;
      }
    }

    return value;
  }

  private addDefaultStyles(alignmentClass: string): string {
    const baseType = this.dataTypeService.getBaseType(this.type);
    const value = this.getValue();
    const possiblyNegative = DataTypeService.possiblyNegativeBaseTypes.some(possiblyNegativeBaseType => possiblyNegativeBaseType === baseType);

    let styles = ' ' + (alignmentClass ? alignmentClass : this.dataTypeService.getDefaultAlignment(this.type, this.value));

    if (possiblyNegative && !isNaN(value) && value < 0) {
      styles = styles + ' negative';
    }

    if (this.hasClickEvent()) {
      styles = styles + ' click-event';
    }

    if (this.hasDrillDown()) {
      styles = styles + ' drilldown';
    }

    return styles;
  }

  // Event Handling

  public handleClick(): void {
    if (this.hasDrillDown()) {
      this.goToDetailsPage();
    } else if (this.hasPageLink()) {
      this.followPageLink();
    } else if (this.hasSearchLink()) {
      this.followSearchLink();
    } else if (this.hasFileLink()) {
      this.downloadFile();
    } else if (this.hasScrollLink()) {
      this.scrollToWidget();
    }
  }

  private goToDetailsPage(): void {
    this.trackingService.trackEvent('klik',
      `Klik doorsturen:${this.side}/tab van:${this.page}/widget van:${this.widgetId}/tab naar:${this.getDetailsPage()}`,
      null, null);

    this.pageNavigationUtil.updateBreadcrumb(this.side, this.widgetId, this.domain, this.page, this.getDetailsPage(), this.containerTabId);
    this.pageNavigationUtil.navigateToPage(this.side, this.getDetailsPage(), this.getDetailsFilter(), null);
  }

  private downloadFile(): void {
    let win: any;
    const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/gi;

    if (this.value != null && this.value.hasOwnProperty('Url')) {
      win = window.open(this.value['Url'], '_blank');
    } else if (this.value.match(urlRegex)) {
      win = window.open(this.value, '_blank');
    }
    win.focus();
  }

  private scrollToWidget(): void {
    const container = document.querySelector(`.${this.side} #${this.side}_${this.value.widget}`);
    if (container) {
      container.scrollIntoView(true);
    }
  }

  private followPageLink(): void {
    // value: waarde die getoond moet worden
    // target: type link (externalLink = url voor in nieuwe tab/window, rightSide = tweede scherm, currentSide = huidige scherm, none = geen link)
    // url: url voor externe link
    // filter: pathkeys voor link naar (huidige of) tweede scherm (ontbrekende pathkeys worden aangevuld met huidige pathkeys)
    // page: pagina voor link naar huidige of tweede scherm

    const target = this.value['target'];

    if (target === 'externalLink') {
      const url = this.value['url'];
      this.trackingService.trackEvent('klik', 'Open external link', url, null);
      const win = window.open(url, '_blank');
      win.focus();
    } else if (target === 'rightSide') {
      const page = this.value['page'] != undefined ? this.value['page'] : this.page;
      const filter = this.value['filter'] != undefined ? this.value['filter'] : {};
      this.pageNavigationUtil.navigate(this.side, 'right', page, filter, null);
    } else if (target === 'currentSide') {
      const page = this.value['page'] != undefined ? this.value['page'] : this.page;
      const filter = this.value['filter'] != undefined ? this.value['filter'] : {};
      this.trackingService.trackEvent('klik',
        `Klik doorsturen:${this.side}/tab van:${this.page}/widget van:${this.widgetId}/tab naar:${page}`,
        null, null);
      this.pageNavigationUtil.navigate(this.side, this.side, page, filter, null);
    }
  }

  // TODO: Improve error handling
  private followSearchLink(): void {
    // value: waarde die getoond moet worden
    // target: type link (alleen rightSide = tweede scherm is van toepassing)
    // filter: pathkeys voor link naar tweede scherm (ontbrekende pathkeys worden aangevuld met huidige pathkeys)
    // page: pagina voor link naar tweede scherm

    const page = this.value['page'] != undefined ? this.value['page'] : this.page;
    const filter = this.value['filter'] != undefined ? this.value['filter'] : {};
    const viewId: string = this.domain;
    const filterKeys: string[] = Object.keys(filter);
    const type: string = filterKeys && filterKeys.length > 0 ? filterKeys[0] : '';
    const subjectNr: string = filter && filter[type] ? filter[type] : '';
    this.subjectService.getSubjects(viewId, type, subjectNr)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(
        (subjects: Subject[]) => {
          if (subjects && subjects.length === 1) {
            const subject = subjects[0];
            const modelKeys: string[] = Object.keys(subject.model);
            modelKeys.forEach(key => filter[key] = subject.model[key]);
            this.pageNavigationUtil.navigate(this.side, 'right', page, filter, null);
          } else {
            console.log(`Bij het gebruik van een SearchLink voor ${type} ${subjectNr} is er geen of meer ` +
              `dan 1 zoekresultaat. Hierdoor kan niet worden bepaald met welk zoekresultaat gewerkt moet worden.`);
          }
        },
        error => {
          console.log('Bij het gebruik van een SearchLink is de volgende fout opgetreden:');
          console.log(error);
        });
  }

  public isBaseType(): boolean {
    return this.dataTypeService.isBaseType(this.type);
  }

  public isSpecifiedType(): boolean {
    return this.dataTypeService.isSpecifiedType(this.type);
  }

  public isDrillDownType(): boolean {
    return this.dataTypeService.isDrillDownType(this.type);
  }

  public isPageLinkType(): boolean {
    return this.dataTypeService.isPageLinkType(this.type);
  }

  public isSearchLinkType(): boolean {
    return this.dataTypeService.isSearchLinkType(this.type);
  }

  public isAnnotatedType(): boolean {
    return this.dataTypeService.isAnnotatedType(this.type);
  }

  public isFootnotedType(): boolean {
    return this.dataTypeService.isFootnotedType(this.type);
  }

  public isTrendType(): boolean {
    return this.dataTypeService.isTrendType(this.type);
  }

  public isDeltaType(): boolean {
    return this.dataTypeService.isDeltaType(this.type);
  }

  public isFileLinkType(): boolean {
    return this.dataTypeService.isFileLinkType(this.type);
  }

  public isScrollLinkType(): boolean {
    return this.dataTypeService.isScrollLinkType(this.type);
  }

  public hasDrillDown(): boolean {
    return this.isDrillDownType() && this.value.detail;
  }

  public hasValue(): boolean {
    const value = this.getValue();
    return value != null && value !== '';
  }

  public hasPageLink(): boolean {
    return this.isPageLinkType() && this.value && this.value.value && this.value.target && this.value.target !== 'none';
  }

  public hasSearchLink(): boolean {
    return this.isSearchLinkType() && this.value && this.value.value && this.value.target && this.value.target !== 'none';
  }

  public hasAnnotation(): boolean {
    return this.isAnnotatedType() && this.value.Tooltip;
  }

  public hasFileLink(): boolean {
    return this.isFileLinkType() && this.value;
  }

  public hasScrollLink(): boolean {
    return this.isScrollLinkType() && this.value.widget;
  }

  public hasClickEvent(): boolean {
    return this.hasDrillDown() || this.hasPageLink() || this.hasSearchLink() || this.hasFileLink() || this.hasScrollLink();
  }

  public getDetailsPage(): string {
    return this.value.detail;
  }

  public getDetailsFilter(): any {
    return this.value.filter;
  }

  public getAnnotation(): string {
    return this.value.Tooltip;
  }

  public getFootnote(): string {
    return this.value.footnote;
  }

  public getDelta(): string {
    return this.value.delta;
  }

  public getTrendIcon(): string {
    const value = this.value.hasOwnProperty('revision') ? this.value.revision : this.value.Correctie;
    return (value === 1 || value === '1' || value === 'J') ? 'trendicon fa bd_lens' : '';
  }
}
