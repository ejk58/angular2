import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import * as fromSelectors from '../../store/selectors';
import {Store} from '@ngrx/store';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss'],
  providers: [Unsubscriber]
})
export class HelpComponent implements OnInit, OnDestroy {

  @Input() helpTexts: any;

  public activeTab: number = 0;
  public activeKlantbeeld: any;
  public modalState: string;

  constructor(private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    const indicatedKBSelector = this.selectorSideIndicator.indicatedSelectorName('left', 'getActiveKlantbeeld');
    this.store.select(fromSelectors[indicatedKBSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeKB => this.activeKlantbeeld = activeKB);

    this.store.select(fromSelectors.getModalWrapperState)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(modalState => this.modalState = modalState);
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  selectTab(tab: number) {
    this.activeTab = tab;
  }
}
