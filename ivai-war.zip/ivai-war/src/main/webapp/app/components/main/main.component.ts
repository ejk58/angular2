import {AfterViewChecked, ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, OnDestroy} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {SplitViewState} from '../../services/split-view-state.service';
import * as fromSelectors from '../../store/selectors';
import {HelpState} from '../../services/help.service';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import * as storeActions from '../../store/actions';
import {TrackingService} from '../../services/tracking.service';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {Subject} from '../../classes/subject';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'i-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
  providers: [Unsubscriber]
})
export class MainComponent implements OnInit, OnDestroy, AfterViewChecked {

  public screenSizePx: number = window.innerWidth;
  public mobileSreenSizePx = 320;
  public mobileBreakpointPx = 400;
  public leftSize = 100;
  public rightSize = 0;
  public horizontal = 'horizontal';
  public initDragHandle = true;
  public modalWrapper: any;
  public contextText: string;
  public displayHelp: boolean = false;
  public displayFeedback: boolean = false;
  public activeKlantbeeld: any;
  public selectedSubjectLeft: Subject;
  public selectedSubjectRight: Subject;

  private draggingGutter: boolean = false;

  @HostListener('window:resize', ['$event']) onResize() {
    this.screenSizePx = window.innerWidth;
    if (this.screenSizePx < this.mobileBreakpointPx) {

      this.mobileSreenSizePx = this.screenSizePx;
      if (this.leftSize > 0) {
        this.leftSize = 100;
        this.rightSize = 0;
      }
    } else {
      this.mobileSreenSizePx = this.splitViewState.breakpointMobile;
    }
  }

  constructor(private readonly route: ActivatedRoute,
              private readonly changeDetectorRef: ChangeDetectorRef,
              private readonly router: Router,
              private readonly elementRef: ElementRef,
              private readonly splitViewState: SplitViewState,
              private readonly trackingService: TrackingService,
              private readonly helpState: HelpState,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly util: PageNavigationUtilService,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    const indicatedKBSelector = this.selectorSideIndicator.indicatedSelectorName('left', 'getActiveKlantbeeld');
    this.store.select(fromSelectors[indicatedKBSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeKB => this.activeKlantbeeld = activeKB);

    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName('left', 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeSubject => this.selectedSubjectLeft = activeSubject);

    const indicatedSelectedSubjectSelector2 = this.selectorSideIndicator.indicatedSelectorName('right', 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelector2])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeSubject => this.selectedSubjectRight = activeSubject);

    this.store.select(fromSelectors.getModalWrapperState)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(modalState => {
        this.modalWrapper = modalState;
        switch (this.modalWrapper) {
          case 'help': {
            this.displayHelp = true;
            this.displayFeedback = false;
            break;
          }
          case 'feedback': {
            this.displayHelp = false;
            this.displayFeedback = true;
            break;
          }
          default: {
            this.displayHelp = false;
            this.displayFeedback = false;
            break;
          }
        }
      });
    const helpTexts = this.helpState.generalHelp;
    this.helpState.emitHelpText(helpTexts);

    if (this.screenSizePx < this.mobileBreakpointPx) {
      this.mobileSreenSizePx = this.screenSizePx;
      this.leftSize = 100;
      this.rightSize = 0;
    }

    this.helpState.listenHelpText()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(text => this.contextText = text);

    this.splitViewState.listenOpen2Screen()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(open2Screen => {
        if (open2Screen) {
          this.splitScreensInHalf();
          this.splitViewState.emitOpen2Screen(false);
        }
      });
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  ngAfterViewChecked() {
    if (this.initDragHandle) {
      const splitGutter = (document.querySelector('div.as-split-gutter') as HTMLElement);
      splitGutter.classList.add('dragBarWidth');

      const newElDiv = document.createElement('div');
      const newElBlock = document.createElement('div');
      const newElBar = document.createElement('div');
      const newElBar2 = document.createElement('div');

      newElDiv.classList.add('drag-handle');
      newElBlock.classList.add('handle-block');
      newElBar.classList.add('handle-bar');
      newElBar2.classList.add('handle-bar');

      newElBlock.appendChild(newElBar);
      newElBlock.appendChild(newElBar2);
      newElDiv.appendChild(newElBlock);
      splitGutter.appendChild(newElDiv);

      splitGutter.onclick = () => this.onGutterClick();

      this.initDragHandle = false;
    }
  }

  convertPercToPx(sizeInPercentage: number): number {
    const sizeInPx = ((this.screenSizePx / 100) * sizeInPercentage);
    return Math.round(sizeInPx);
  }

  onGutterClick(): void {
    if (this.draggingGutter) {
      this.splitScreensInHalf();
      this.draggingGutter = false;
    }
  }

  onDragStart(): void {
    this.draggingGutter = true;

    if (this.selectedSubjectRight === null) {
      const initTab: string = this.activeKlantbeeld ? this.activeKlantbeeld.initTab : null;
      this.util.navToPageSecondScreen(initTab, false, this.selectedSubjectLeft);
    }
  }

  onDragEnd(e: { gutterNum: number, sizes: number[] }): void {
    const eventLeftSize = e.sizes[0];
    const eventRightSize = e.sizes[1];

    // register that we're done dragging, if we moved. This is to prevent a clash with the onGutterClick event handler
    if (this.draggingGutter && (Math.abs(eventLeftSize - this.leftSize) > 0.01 || Math.abs(eventRightSize - this.rightSize) > 0.01)) {
      this.draggingGutter = false;
    }

    const eventLeftSizePx = this.convertPercToPx(eventLeftSize);
    const eventRightSizePx = this.convertPercToPx(eventRightSize);

    let newLeftSize = eventLeftSize;
    let newRightSize = eventRightSize;

    if (this.screenSizePx < this.mobileBreakpointPx) {
      if (eventLeftSize > this.leftSize) {
        newLeftSize = 100;
        newRightSize = 0;
      } else {
        newLeftSize = 0;
        newRightSize = 100;
      }
    } else {
      if (eventLeftSizePx < this.mobileSreenSizePx) {
        if (eventLeftSize > this.leftSize) {
          newLeftSize = 320 / (this.screenSizePx / 100);
          newRightSize = 100 - newLeftSize;
        } else {
          newLeftSize = 0;
          newRightSize = 100;
        }
      }
      if (eventRightSizePx < this.mobileSreenSizePx) {
        if (eventRightSize > this.rightSize) {
          newRightSize = 320 / (this.screenSizePx / 100);
          newLeftSize = 100 - newRightSize;
        } else {
          newLeftSize = 100;
          newRightSize = 0;
        }
      }
    }

    this.leftSize = newLeftSize;
    this.rightSize = newRightSize;

    setTimeout(() => {
      this.trackingService.trackEvent('klik',
        `Scherm aanpassen/left:${this.leftSize} - right:${this.rightSize}`,
        null, null);

      const sizesInPx = {left: this.convertPercToPx(this.leftSize), right: this.convertPercToPx(this.rightSize)};
      this.splitViewState.emitSizes(sizesInPx);

      // force change detection, for when the 'dragend' happens outside the window, without focus
      this.changeDetectorRef.detectChanges();
    });
  }

  splitScreensInHalf() {
    this.leftSize = 50;
    this.rightSize = 50;
    const sizesInPx = { left: this.convertPercToPx(this.leftSize), right: this.convertPercToPx(this.rightSize) };
    this.splitViewState.emitSizes(sizesInPx);
  }

  wasClosed(event) {
    this.leftSize = 100;
    this.rightSize = 0;
    const sizesInPx = { left: this.convertPercToPx(this.leftSize), right: this.convertPercToPx(this.rightSize) };
    this.splitViewState.emitSizes(sizesInPx);
    this.store.dispatch(new storeActions.SubjectClear({side: 'right', subject: null}));
    this.store.dispatch(new storeActions.ClearActiveKlantbeeld({side: 'right'}));
    this.router.navigate(['/main', {outlets: {right: null}}]);
  }

  openKlantbeeld() {
    setTimeout(() => {
      this.store.dispatch(new storeActions.HeaderSelectMenu({side: 'left', menu: 'klantbeeld'}));
    }, 250);
  }

  openWidgetHelp() {
    const helpTexts = this.helpState.generalHelp;
    this.store.dispatch(new storeActions.HeaderSelectMenu({side: 'left', menu: 'default'}));
    this.helpState.emitHelpText( helpTexts );
    this.store.dispatch(new storeActions.ModalOpen('help'));
  }

  closeHelpAndFeedback() {
    this.store.dispatch(new storeActions.ModalClose());
  }

  scrollHandler(event) {
    this.splitViewState.offsetScroll.next(event.target.scrollTop);
  }
}
