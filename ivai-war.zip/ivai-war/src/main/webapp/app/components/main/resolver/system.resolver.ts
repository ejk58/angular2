import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Store } from '@ngrx/store';

import * as systemActions from '../../../store/actions/index';

@Injectable()
export class SystemResolver implements Resolve<any> {

  constructor(private readonly store: Store<any>) { }

  resolve() {
    this.store.dispatch(new systemActions.SystemVersionLoad());
    this.store.dispatch(new systemActions.SystemConfigurationLoad());
  }
}
