import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {SplitWidth} from '../../classes/split-width';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import * as headerActions from '../../store/actions/header/header.actions';
import * as fromSelectors from '../../store/selectors';
import {SplitViewState} from '../../services/split-view-state.service';
import {TrackingService} from '../../services/tracking.service';
import {PageNavigationUtilService} from '../../commons/page-navigation-util.service';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  providers: [Unsubscriber]
})
export class SidebarComponent implements OnInit, OnDestroy {

  @Input() side: any;
  @Output() selected: EventEmitter<boolean> = new EventEmitter<boolean>();

  public params: any;
  public klantbeeld: string;
  public page: string;
  public id: number;
  private viewId: string;
  private currentStateParams: any;

  selectedLink: any;

  public pageMenu: any;
  public currentPage: string;
  public pageConfig: any;
  public splitWidth: SplitWidth;

  constructor(private readonly router: Router,
              private readonly route: ActivatedRoute,
              private readonly trackingService: TrackingService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly util: PageNavigationUtilService,
              private readonly splitViewState: SplitViewState,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    this.store.select(fromSelectors.getRouterSides)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(routerSides => {
        if (routerSides[this.side]) {
          this.currentPage = routerSides[this.side].domain;
          this.currentStateParams = routerSides[this.side];
        }
      });

    const indicatedKBSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getActiveKlantbeeld');
    this.store.select(fromSelectors[indicatedKBSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeKBid => this.viewId = activeKBid);

    const indicatedPageMenuSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getPageMenuState');
    this.store.select(fromSelectors[indicatedPageMenuSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(menu => this.pageMenu = menu);

    this.route.params
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(params => {
        this.params = params;
        this.page = params['domain'];
        this.id = params['subjectNr'];
      });

    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(sizes => {
        if (sizes != null) {
          this.splitWidth = sizes;
        } else {
          this.splitWidth = SplitWidth.default;
        }
      });
  }

  ngOnDestroy() {
    this.unsubscriber.unsubscribe();
  }

  toggleMenuLinks(link) {
    return (this.selectedLink === link) ? this.selectedLink = '' : this.selectedLink = link;
  }

  selectView(menuLink) {
    const selectedPageMenu = menuLink.key;

    this.store.dispatch(new headerActions.HeaderSelectMenu({side: this.side, menu: 'none' }));
    this.util.navigateToPage(this.side, selectedPageMenu, null, null);
  }

  splittedToMobileScreen(): boolean {
    return this.splitWidth[this.side] <= this.splitViewState.breakpointMobile;
  }
}
