import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {WidgetService} from '../../services/widget.service';
import {MenuItem} from 'primeng/components/common/menuitem';
import {ActivatedRoute} from '@angular/router';
import {Store} from '@ngrx/store';
import {first} from 'rxjs/operators';
import * as storeActions from '../../store/actions';
import {HelpState} from '../../services/help.service';
import {ExcelExportUtil} from '../../commons/excel-export-util';
import * as fromSelectors from '../../store/selectors';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {TrackingService} from '../../services/tracking.service';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'widget',
  templateUrl: './widget.component.html',
  styleUrls: ['./widget.component.scss'],
  providers: [Unsubscriber]
})
export class WidgetComponent implements OnDestroy, OnInit {

  @Input() widgetId: any;
  @Input() widgetTitle: any;
  @Input() side: string;
  @Input() params: any;
  @Input() containerTabId: number;
  @Input() isDataDrivenChild: boolean;
  @Input() hideTitle: boolean;
  @Input() inWidget: boolean;
  @Input() hideDescription: boolean;
  @Input() gridColumns: number;
  @Input() filter: any;
  @Output() hasData: EventEmitter<any> = new EventEmitter<any>();

  public widgetData: any;
  public error: any;
  public full: any;
  public options: MenuItem[];
  public minimize: boolean = false;
  public view: any;
  public overflowMinimize: boolean = false;
  public trendMoney: boolean = false;
  public helpTexts: any;
  public ktaEnvironment: any;
  public valutajaar: number;
  public noData: boolean = false;

  private widgetDataInitialized: boolean;

  constructor(private readonly widgetService: WidgetService,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store<any>,
              private readonly trackingService: TrackingService,
              private readonly helpState: HelpState,
              private readonly excelUtil: ExcelExportUtil,
              private readonly route: ActivatedRoute,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    this.route.params.pipe(first()).subscribe(params => {
      this.side = this.route.outlet;
    });

    this.store.select(fromSelectors.getSystemKtaEnvironmentState).pipe(first()).subscribe(configurationData => {
      this.ktaEnvironment = configurationData;
    });

    this.reloadWidget();
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  handleResizeButtonClick() {
    this.toggleMinimize();
    let text: string;
    if (this.minimize) {
      text = `Klik min:${this.side}/widget:`;
    } else {
      text = `Klik max:${this.side}/widget:`;
    }
    this.trackingService.trackEvent('klik',
      text + (this.widgetData ? this.widgetData.options.label : this.widgetTitle),
      this.widgetId, null);
  }

  toggleMinimize(): void {
    this.minimize = !this.minimize;
    if (this.minimize) {
      this.overflowMinimize = true;
    } else {
      setTimeout(() => {
        this.overflowMinimize = false;
      }, 300);
    }
  }

  openWidgetHelp(): void {
    this.helpState.emitHelpText(this.helpTexts);
    this.trackingService.trackEvent('klik',
      `Klik help:${this.side}/manier:widget help/widget:${this.widgetData.options.label}`,
      this.widgetId, null);
    this.store.dispatch(new storeActions.ModalOpen('help'));
  }

  checkForTrendMoney(columns): boolean {
    return Object.keys(columns).some(key =>
      columns[key].columnType === 'TRENDMONEY' ||
      columns[key].columnType === 'DRILLDOWNTRENDMONEY'
    );
  }

  ktaLink(widgetId): void {
    this.widgetService.get(widgetId, this.side, this.filter)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(
        data => {
          const url = data.data[0].LINK.replace(/#.*#/, this.ktaEnvironment);
          this.trackingService.trackEvent('klik',
            `Klik externe link:${this.side}/widget:${this.widgetData.options.label}/naar:${url}`,
            this.widgetId, null);
          const newWindow = window.open(url, '_blank');
          if (newWindow) {
            newWindow.focus();
          }
        },
        error => {
          this.error = error;
        });
  }

  downloadExcel(widgetId, title): void {
    this.widgetService.get(widgetId, this.side, this.filter)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(
        data => {
          this.trackingService.trackEvent('klik',
            `Klik downloaden:${this.side}/widget:${this.widgetData.options.label}`,
            this.widgetId, null);
          const exportData = data;
          this.excelUtil.exportToExcel(title, exportData);
        },
        error => {
          this.error = error;
        });
  }

  reloadPage(): void {
    document.location.reload(true);
  }

  reloadWidget(): void {
    this.minimize = false;
    this.overflowMinimize = false;
    this.trendMoney = false;
    this.noData = false;
    this.widgetData = undefined;
    this.options = [];

    this.widgetService.get(this.widgetId, this.side, this.filter)
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(
        data => {
          this.widgetData = data;
          if (this.widgetData.options.title == null || this.widgetData.options.title === '') {
            this.hideTitle = true;
          }
          this.valutajaar = null;
          if (this.widgetData.data) {
            if (this.widgetData.data.length > 0 ||
              this.widgetData.type === 'Container' ||
              this.widgetData.type === 'Composition' ||
              this.widgetData.type === 'DataDrivenComposition') {
              if (this.widgetData.data.length > 0) {
                this.valutajaar = this.widgetData.data[0].valutajaar;
              }
              this.hasData.emit({id: this.widgetId, hasData: true});
            } else {
              this.noData = true;
              this.hasData.emit({id: this.widgetId, hasData: false});
              this.toggleMinimize();
            }
          }

          this.makeHelpTextsAndOptions();
          this.widgetDataInitialized = true;
        },
        error => {
          this.widgetData = null;
          this.error = error;
        });
  }

  private makeHelpTextsAndOptions(): void {
    this.helpTexts = { 'title': this.widgetData.options.helpTitle, texts: this.widgetData.options.helpTexts };

    if (this.widgetData.options.ktaLinkWidget) {
      this.options.push({
        label: 'Bekijk in KTA', icon: 'bd_kta', command: (event) => {
          this.ktaLink(this.widgetData.options.ktaLinkWidget);
        }
      });
    }
    if (this.widgetData.options.anbiLink) {
      this.options.push({
        label: 'Bekijk in ANBI',
        icon: 'bd_open_in_new', url: this.widgetData.options.anbiLink, target: '_blank'
      });
    }
    if (this.widgetData.options.exportWidget) {
      this.options.push({
        label: 'Download', icon: 'bd_get_app', command: (event) => {
          this.downloadExcel(this.widgetData.options.exportWidget, this.widgetData.options.label);
        }
      });
    }
    if (this.options.length > 0 || this.helpTexts.texts.length > 0) {
      this.options.push({
        label: 'Minimaliseer', icon: 'bd_window-minimize', command: (event) => {
          this.toggleMinimize();
        }
      });
    }
    if (this.helpTexts.texts) {
      if (this.helpTexts.texts.length > 0) {
        this.options.push({
          label: 'Help', icon: 'bd_help_outline', command: (event) => {
            this.openWidgetHelp();
          }
        });
      }
    }
  }

  changeDataStatus(e): void {
    if (!e.hasData) {
      this.noData = true;
      this.hasData.emit({id: this.widgetId, hasData: false});
      if (this.widgetData.options.title != null) {
        this.toggleMinimize();
      }
    }
  }
}
