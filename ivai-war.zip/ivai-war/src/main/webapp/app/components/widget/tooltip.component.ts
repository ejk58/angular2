import { D3, Selection } from 'd3-ng2-service';

export class TooltipComponent {
  private element: Selection<any, any, any, any>;
  private balloon: Selection<any, any, any, any>;
  private arrow: Selection<any, any, any, any>;
  private text: Selection<any, any, any, any>;
  private readonly transitionDuration = 500;
  private readonly balloonHeigth = 25;
  private readonly arrowHeight = 8;

  public create (canvas: Selection<any, any, any, any>, width: number): void {
    const rounding = 6;
    const backgroundColor = '#007BC8';
    const textColor = '#fff';

    this.element = canvas
      .append('g')
      .attr('class', 'tooltip-d3')
      .style('z-index', -99999999999)
      .style('opacity', 0);

    this.balloon = this.element.append('rect')
      .attr('rx', rounding)
      .attr('ry', rounding)
      .attr('width', width)
      .attr('height', this.balloonHeigth)
      .style('fill', backgroundColor);

    this.text = this.element.append('text')
      .attr('width', width)
      .attr('height', this.balloonHeigth)
      .attr('fill', textColor)
      .style('font-size', '12px')
      .style('text-anchor', 'middle')
      .style('alignment-baseline', 'middle');

    this.arrow = this.element.append('path')
      .attr('d', () => {
        const x = Number(this.balloon.attr('x')) + (Number(this.balloon.attr('width')) / 2) - 8;
        const y = Number(this.balloon.attr('y')) + Number(this.balloon.attr('height'));

        return 'M ' +
          x + ' ' +
          (y - 1) +
          ' l ' +
          (this.arrowHeight * 2) +
          ' 0 l -' +
          this.arrowHeight +
          ' ' +
          this.arrowHeight +
          ' z';
      })
      .attr('fill', backgroundColor);
  }

  public show (element: any, backgroundColor: string): void {
    const balloonWidth = Number(element.attr('width')) - 2;
    const label = element.attr('label');

    const xBalloon = Number(element.attr('x')) + 1;
    const yBalloon = Number(element.attr('y')) - this.balloonHeigth - this.arrowHeight;
    const xArrow = xBalloon + balloonWidth / 2 - 8;
    const yArrow = yBalloon + Number(this.balloon.attr('height'));
    const xText = xBalloon + balloonWidth / 2 - 3;
    const yText = yBalloon + (Number(this.balloon.attr('height')) / 2) + 3;

    this.balloon
      .transition()
      .duration(this.transitionDuration)
      .attr('x', xBalloon)
      .attr('y', yBalloon)
      .attr('width', balloonWidth)
      .style('fill', backgroundColor);

    this.arrow
      .transition()
      .duration(this.transitionDuration)
      .attr('d', 'M ' +
        xArrow +
        ' ' +
        (yArrow - 1) +
        ' l ' +
        (this.arrowHeight * 2) +
        ' 0 l -' +
        this.arrowHeight +
        ' ' +
        this.arrowHeight +
        ' z')
      .style('fill', backgroundColor);

    this.text
      .text(label)
      .transition()
      .duration(this.transitionDuration)
      .attr('x', xText)
      .attr('y', yText)
      .attr('width', balloonWidth);

    this.element
      .transition()
      .duration(this.transitionDuration)
      .style('opacity', '1')
      .style('z-index', 99999999999);
  }

  public hide (element: any): void {
    this.element
      .transition()
      .duration(this.transitionDuration)
      .style('opacity', '0')
      .style('z-index', -99999999999);
  }
}
