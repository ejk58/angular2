import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class LoggedInGuard implements CanActivate {

    constructor(private readonly router: Router,
                private readonly authService: AuthenticationService) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        if (this.authService.isLoggedIn()) {
            return true;
        }
        // not logged in so redirect to login page
        this.authService.sendUserName(null);
        this.router.navigate(['/login'], { queryParams: { redirect: state.url, embed: route.queryParamMap.get('embed') }});
        return false;
    }
}
