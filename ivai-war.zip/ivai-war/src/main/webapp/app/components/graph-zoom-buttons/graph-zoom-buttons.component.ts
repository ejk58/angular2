import { Component, Input, AfterViewInit, ViewEncapsulation, ViewChild, ElementRef, OnInit } from '@angular/core';
import { D3Service, D3, Selection } from 'd3-ng2-service';

@Component({
  selector: 'i-graph-zoom-buttons',
  templateUrl: './graph-zoom-buttons.component.html',
  styleUrls: ['./graph-zoom-buttons.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class GraphZoomButtonsComponent implements AfterViewInit, OnInit {

  private static readonly minimumZoom: number = 0.5;
  private static readonly maximumZoom: number = 32.0;
  private static readonly indicatorWidth: number = 80;
  private static readonly indicatorHeight: number = 80;

  @Input() canvas: Selection<any, any, any, any>;
  @Input() element: Selection<any, any, any, any>;
  @Input() size: {width: number, height: number};
  @Input() home: {x: number, y: number};

  @ViewChild('zoomIndicatorCanvas') canvasElementRef: ElementRef;

  private readonly d3: D3;
  private readonly zoomBehavior: any;
  private zoomValue: any;
  private zoomViewIndicator: Selection<any, any, any, any>;

  constructor(d3Service: D3Service) {
    this.d3 = d3Service.getD3();
    this.zoomValue = this.d3.zoomIdentity;

    this.zoomBehavior = this.d3.zoom()
      .scaleExtent([GraphZoomButtonsComponent.minimumZoom, GraphZoomButtonsComponent.maximumZoom])
      .filter(() => {
        return this.d3.event.type !== 'wheel' || this.d3.event.ctrlKey;
      })
      .on('zoom', () => {
        this.zoomValue = this.d3.event.transform;
        this.element.attr('transform', this.zoomValue);
        this.updateIndicator();
      });
  }

  ngOnInit(): void {
    // apply zoom behavior
    this.canvas.call(this.zoomBehavior);

    // listen to wheel events to show the overlay
    this.canvas.on('wheel', () => {
      if (!this.d3.event.ctrlKey) {
        const cover = this.d3.select(this.canvas.node().parentNode.parentNode).select('.hierarchical-graph-cover');
        cover.classed('visible', true);
        setTimeout(() => cover.classed('visible', false));
      }
    });
  }

  ngAfterViewInit(): void {
    const zoomIndicatorCanvas = this.d3.select(this.canvasElementRef.nativeElement)
      .append('svg')
      .attr('preserveAspectRatio', 'xMinYMin meet')
      .attr('viewBox', `0 0 ${GraphZoomButtonsComponent.indicatorWidth} ${GraphZoomButtonsComponent.indicatorHeight}`);

    zoomIndicatorCanvas
      .append('rect')
      .attr('x', 0)
      .attr('y', 0)
      .attr('width', GraphZoomButtonsComponent.indicatorWidth)
      .attr('height', GraphZoomButtonsComponent.indicatorWidth)
      .attr('class', 'indicator-background');

    this.zoomViewIndicator = zoomIndicatorCanvas
      .append('rect')
      .attr('x', 0)
      .attr('y', 0)
      .attr('width', GraphZoomButtonsComponent.indicatorWidth)
      .attr('height', GraphZoomButtonsComponent.indicatorWidth)
      .attr('class', 'indicator-view')
      .attr('cursor', 'move')
      .call(this.d3.drag().on('drag', () => {
        this.move(this.d3.event);
      }));
  }

  public goToHome(): void {
    const transformation = this.d3.zoomIdentity
      .translate(this.size.width / 2 - this.home.x * 2, this.size.height / 2 - this.home.y * 2)
      .scale(2.0);

    this.transform(transformation);
  }

  public zoomIn(): void {
    this.zoom(Math.min(this.zoomValue.k * 2, GraphZoomButtonsComponent.maximumZoom));
  }

  public zoomOut(): void {
    this.zoom(Math.max(this.zoomValue.k / 2, GraphZoomButtonsComponent.minimumZoom));
  }

  public reset(): void {
    this.transform(this.d3.zoomIdentity);
  }

  private zoom(k: number): void {
    const zoomFactor = (k / this.zoomValue.k);
    const dx = (this.zoomValue.x * zoomFactor) - (this.size.width / 2) * zoomFactor + (this.size.width / 2);
    const dy = (this.zoomValue.y * zoomFactor) - (this.size.height / 2) * zoomFactor + (this.size.height / 2);

    const transformation = this.d3.zoomIdentity
      .translate(dx, dy)
      .scale(k);

    this.transform(transformation);
  }

  private transform(transformation: any): void {
    this.canvas.transition().duration(500).call(this.zoomBehavior.transform, transformation);
  }

  private move(event: any): void {
    const dx = event.dx * this.size.width * this.zoomValue.k / GraphZoomButtonsComponent.indicatorWidth;
    const dy = event.dy * this.size.height * this.zoomValue.k / GraphZoomButtonsComponent.indicatorHeight;

    const transformation = this.d3.zoomIdentity
      .translate(this.zoomValue.x - dx, this.zoomValue.y - dy)
      .scale(this.zoomValue.k);

    this.canvas.call(this.zoomBehavior.transform, transformation);
  }

  private updateIndicator(): void {
    const viewIndicatorWidth = GraphZoomButtonsComponent.indicatorWidth / this.zoomValue.k;
    const viewIndicatorHeight = GraphZoomButtonsComponent.indicatorHeight / this.zoomValue.k;

    this.zoomViewIndicator
      .attr('x', viewIndicatorWidth * -this.zoomValue.x / this.size.width)
      .attr('y', viewIndicatorHeight * -this.zoomValue.y / this.size.height)
      .attr('width', viewIndicatorWidth)
      .attr('height', viewIndicatorHeight);
  }
}
