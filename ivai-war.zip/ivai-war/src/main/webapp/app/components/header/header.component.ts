import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Store} from '@ngrx/store';

import {SplitWidth} from '../../classes/split-width';
import {AuthenticationService} from '../../services/authentication.service';
import {SplitViewState} from '../../services/split-view-state.service';
import {PageTitleService} from '../../services/page-title.service';
import {SelectorSideIndicator} from '../../commons/store-selector-side-indicator';
import {KlantBeeldenResolver} from '../klantbeeld/resolver/klantbeeld.resolver';
import * as storeActions from '../../store/actions';
import * as fromSelectors from '../../store/selectors';
import {HelpState} from '../../services/help.service';
import {TrackingService} from '../../services/tracking.service';
import {Subject} from '../../classes/subject';
import {Unsubscriber} from '../../commons/unsubscriber';

@Component({
  selector: 'header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [Unsubscriber]
})
export class HeaderComponent implements OnInit, OnDestroy {

  @Input() side: any;
  @Output() secondScreenActive: EventEmitter<boolean> = new EventEmitter<boolean>();

  public readonly accountMenuOptions = [
    { label: 'Feedback', icon: 'bd_chat_bubble_outline', command: this.triggerFeedbackModal.bind(this), selected: false },
    { label: 'Uitloggen', icon: 'bd_lock_open', command: this.logout.bind(this), selected: false }
  ];

  public view: any;
  public currentRoute: string;
  public username: any;
  public loading: boolean;
  public selectedSubject: Subject;
  public activeKlantbeeld: any;
  public headerState: string;
  public splitWidth: SplitWidth = SplitWidth.default;

  constructor(private readonly route: ActivatedRoute,
              private readonly auth: AuthenticationService,
              public readonly splitViewState: SplitViewState,
              private readonly helpState: HelpState,
              private readonly trackingService: TrackingService,
              private readonly pageTitleService: PageTitleService,
              private readonly klantBeeldenResolver: KlantBeeldenResolver,
              private readonly selectorSideIndicator: SelectorSideIndicator,
              private readonly store: Store<any>,
              private readonly unsubscriber: Unsubscriber) { }

  ngOnInit() {
    const indicatedKBSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getActiveKlantbeeld');
    this.store.select(fromSelectors[indicatedKBSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeKB => this.activeKlantbeeld = activeKB);

    const indicatedHeaderSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getActiveMenu');
    this.store.select(fromSelectors[indicatedHeaderSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeMenu => this.headerState = activeMenu);

    const indicatedSelectedSubjectSelector = this.selectorSideIndicator.indicatedSelectorName(this.side, 'getSelectedSubject');
    this.store.select(fromSelectors[indicatedSelectedSubjectSelector])
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(activeSubject => this.selectedSubject = activeSubject);

    this.route.params
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(params => this.currentRoute = this.route.snapshot.url[0].path);

    this.splitViewState.listenSizes()
      .pipe(this.unsubscriber.takeUntilForUnsubscribe)
      .subscribe(splitWidth => {
        if (splitWidth != null) {
          this.splitWidth = splitWidth;
        } else {
          this.splitWidth = SplitWidth.default;
        }
      });
  }

  ngOnDestroy(): void {
    this.unsubscriber.unsubscribe();
  }

  public isKlantbeeldSelected(): boolean {
    return this.activeKlantbeeld !== null;
  }

  public isKlantbeeldMenuOpened(): boolean {
    return this.side && this.headerState === 'klantbeeld';
  }

  public isPageMenuOpened(): boolean {
    return this.side && this.headerState === 'page';
  }

  public isRelationMenuOpened(): boolean {
    return this.side && this.headerState === 'relation';
  }

  public isSubjectMenuOpened(): boolean {
    return this.side && this.headerState === 'subject';
  }

  public isAccountMenuOpened(): boolean {
    return this.side && this.headerState === 'account';
  }

  public selectAccountOption(index: number): void {
    for (let i = 0; i < this.accountMenuOptions.length; i++) {
      this.accountMenuOptions[i].selected = false;
    }
    this.accountMenuOptions[index].selected = true;
    this.accountMenuOptions[index].command();
  }

  private triggerFeedbackModal(): void {
    this.trackingService.trackEvent('klik',
      'Klik feedback:' + this.side, null, null);
    this.store.dispatch(new storeActions.ModalOpen('feedback'));
    this.switchMenu('default');
  }

  public switchMenu(selectedMenu: string): void {
    const menuChanged = selectedMenu !== this.headerState;
    const menuClicked = selectedMenu !== 'default'; // clicking the same button twice toggles the menu

    if (menuChanged) {
      this.store.dispatch(new storeActions.HeaderSelectMenu({ side: this.side, menu: selectedMenu }));
      if (this.selectedSubject && menuClicked) {
        this.trackingService.trackEvent('klik',
          `Klik ${selectedMenu}:${this.side}/open met icoon`,
          null, this.selectedSubject['subjectNr']);
      }
    } else if (menuClicked) {
      this.store.dispatch(new storeActions.HeaderSelectMenu({ side: this.side, menu: 'default' }));
    }
  }

  public closeSecondScreen() {
    let subject: string;
    if (this.selectedSubject) {
      subject = this.selectedSubject['subjectNr'];
    }
    this.trackingService.trackEvent('klik',
      `Klik close:${this.side}/icoon close`,
      null, subject);
    this.secondScreenActive.emit(true);
  }

  logout() {
    this.auth.logout();
  }

  openWidgetHelp() {
    const helpTexts = this.helpState.generalHelp;
    let subject: string;
    if (this.selectedSubject) {
      subject = this.selectedSubject['subjectNr'];
    }
    this.switchMenu('default');
    this.trackingService.trackEvent('klik',
      `Klik help:${this.side}/manier: icoon help`,
      null, subject);
    this.helpState.emitHelpText(helpTexts);
    this.store.dispatch(new storeActions.ModalOpen('help'));
  }

  onClickedOutside(e: Event) {
    if (this.currentRoute !== 'login') {
      this.switchMenu('default');
    }
  }
}
