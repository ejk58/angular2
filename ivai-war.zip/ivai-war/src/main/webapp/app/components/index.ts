import { LoginComponent } from './login/login.component';
import { SelectSubjectComponent } from './subject/select-subject.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { PageComponent } from './page/page.component';
import { WidgetComponent } from './widget/widget.component';
import { MainComponent } from './main/main.component';
import { FooterComponent } from './footer/footer.component';
import { KlantbeeldComponent } from './klantbeeld/klantbeeld.component';
import { RelationComponent } from './relation/relation.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { HelpComponent } from './help/help.component';
import { ModalWrapperComponent } from './modal-wrapper/modal-wrapper.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { GraphZoomButtonsComponent } from './graph-zoom-buttons/graph-zoom-buttons.component';
import { FiltersComponent } from './filters/filters.component';
import { ValueComponent } from './value/value.component';
import { SparklineComponent } from './sparkline/sparkline.component';

// Tijdelijk voor stylesheet
import { BdStylesheetComponent } from './bd-stylesheet/bd-stylesheet.component';

export const list = [
  LoginComponent,
  SelectSubjectComponent,
  HeaderComponent,
  SidebarComponent,
  PageComponent,
  MainComponent,
  KlantbeeldComponent,
  RelationComponent,
  FooterComponent,
  FeedbackComponent,
  HelpComponent,
  WidgetComponent,
  ModalWrapperComponent,
  DropdownComponent,
  GraphZoomButtonsComponent,
  FiltersComponent,
  BdStylesheetComponent,
  ValueComponent,
  SparklineComponent
];
