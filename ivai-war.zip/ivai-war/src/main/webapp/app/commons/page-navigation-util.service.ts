import {Injectable} from '@angular/core';
import {Router} from '@angular/router';

import {MenuItem} from 'primeng/components/common/api';
import {Store} from '@ngrx/store';
import {first} from 'rxjs/operators';

import {TrackingService} from '../services/tracking.service';
import {SplitViewState} from '../services/split-view-state.service';
import * as storeActions from '../store/actions';
import * as fromSelectors from '../store/selectors';
import {SelectorSideIndicator} from './store-selector-side-indicator';
import {PathKey} from '../classes/path-key';
import {Subject} from '../classes/subject';

@Injectable()
export class PageNavigationUtilService {

  public side: string;
  public domain: string;
  public sideParams: any;
  public viewId: any;
  public pathKeys: PathKey[];
  private pageConfig: any;
  public pageMenu: any;

  constructor(private readonly router: Router,
    private readonly trackingService: TrackingService,
    private readonly splitViewState: SplitViewState,
    private readonly selectorSideIndicator: SelectorSideIndicator,
    private readonly store: Store<any>) { }

  public composeNavParams(side: string, destinationPage: string, filter: any, containerId: string, tabId: number) {
    this.store.select(fromSelectors.getRouterSides).pipe(first()).subscribe(sides => {
      this.sideParams = sides[side]; // todo loopt dit 1 cyclus achter?
    });

    const navParams: any = {};

    // all mandatory pathkeys are added
    if (this.pathKeys) {
      this.pathKeys.filter(pk => pk.mandatory).forEach((pathKey) => {
        navParams[pathKey.name] = this.sideParams[pathKey.name];
      });
    }

    // add the filter pathkeys
    if (filter) {
      const filterKeys = Object.keys(filter);

      const index = filterKeys.indexOf('vervang', 0);
      if (index > -1) {
        filterKeys.splice(index, 1);
      }

      filterKeys.forEach((filterKey) => {
          const pathKey = this.pathKeys.find((pathKey) => {
            return pathKey.name === filterKey;
          });
          if (pathKey && filter[pathKey.name] != null) {
            navParams[pathKey.name] = filter[pathKey.name];
          }
      });
    }
    if (containerId) {
      navParams['containerId'] = containerId;
    }
    if (tabId !== undefined && tabId !== null) {
      navParams['tabId'] = tabId;
    }

    return navParams;
  }

  public navigateToPage(side: string, destinationPage: string, filter: any, containerId: string): void {
    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getActiveKlantbeeld');
    this.store.select(fromSelectors[indicatedDomainSelector]).pipe(first()).subscribe(activeDomain => {
      this.viewId = activeDomain.viewId;
      this.pathKeys = activeDomain.pathKeys;
      const parameters = this.composeNavParams(side, destinationPage, filter, containerId, null);

      this.router.navigate(['/main', { outlets: { [side]: [this.viewId, destinationPage, parameters] } }]);
    });
  }

  public navigate(side: string, destinationSide: string, destinationPage: string, filter: any, containerId: string): void {
    const indicatedDomainSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getActiveKlantbeeld');
    this.store.select(fromSelectors[indicatedDomainSelector]).pipe(first()).subscribe(activeDomain => {
      this.viewId = activeDomain.viewId;
      this.pathKeys = activeDomain.pathKeys;
      const destinationPageLocal = destinationPage ? destinationPage : activeDomain.initTab;
      const parameters = this.composeNavParams(side, destinationPageLocal, filter, containerId, null);

      if (destinationSide === 'right') {
        this.splitViewState.emitOpen2Screen(true);
        this.store.dispatch(new storeActions.HeaderSelectMenu({ side: 'right', menu: 'none' }));
        if (side === 'left') {
          this.trackingService.trackEvent('klik', 'Tweede scherm/soort:automatisch', destinationPage, null);
        }
      }

      this.router.navigate(['/main', { outlets: { [destinationSide]: [this.viewId, destinationPageLocal, parameters] } }]);
    });
  }

  public updateBreadcrumb(side: string, widgetId: string, klantbeeld: string, currentpage: string, newpage: string, tabId: number) {
    const indicatedPageMenuSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getPageConfigState');
    this.store.select(fromSelectors[indicatedPageMenuSelector]).pipe(first()).subscribe(config => this.pageConfig = config);
    const outlet = {};
    let breadcrumb: MenuItem;
    let label: string = null;
    let newLabel: string = null;
    this.pageConfig.forEach( function(page) {
      if (page.key === currentpage) {
        label = page.title;
      }
      if (page.key === newpage) {
        newLabel = page.title;
      }
    });
    const indicatedKBSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getActiveKlantbeeld');
    this.store.select(fromSelectors[indicatedKBSelector]).pipe(first()).subscribe(activeKB => {
      this.viewId = activeKB.viewId;
      this.pathKeys = activeKB.pathKeys;

      const indicatedRouterStateSelector = this.selectorSideIndicator.indicatedSelectorName(side, 'getRouterState');
      this.store.select(fromSelectors[indicatedRouterStateSelector]).pipe(first()).subscribe(sideParams => {
        outlet[side] = [klantbeeld, currentpage, sideParams];
        breadcrumb = { label: label, routerLink: ['/main', { outlets: outlet}], command: (event) => {
            this.breadcrumbBack(side, event);
          } };
        this.store.dispatch(new storeActions.BreadcrumbAdd({side: side, breadcrumb: breadcrumb, newpage: newLabel}));
      });
    });
   }

  public breadcrumbBack(side, event) {
    this.store.dispatch(new storeActions.BreadcrumbRemove({side: side, breadcrumb: event.item}));
  }

  private constructSubjectModel(subject: Subject, pathKeys: PathKey[]): Object {
    const subjectModel: Object = {};

    pathKeys.forEach(param => {
      if (param.mandatory) {
        if (subject.model[param.name]) {
          subjectModel[param.name] = subject.model[param.name];
        }
      }
    });

    return subjectModel;
  }

  /*
  * @deprecated Deprecated in favor of using navigate method.
  */
  public navToPageSecondScreen(location: string, open2Screen: boolean = true, subject?: Subject) {
    this.splitViewState.emitOpen2Screen(open2Screen);
    this.store.dispatch(new storeActions.HeaderSelectMenu({ side: 'right', menu: 'none' }));

    this.trackingService.trackEvent('klik', 'Tweede scherm/soort:zelf', location, null);

    const indicatedKBSelector = this.selectorSideIndicator.indicatedSelectorName('left', 'getActiveKlantbeeld');
    this.store.select(fromSelectors[indicatedKBSelector]).pipe(first()).subscribe(activeKB => {
      if (activeKB) {
        this.updateSelectedKlantbeeld('right', activeKB);

        if (subject) {
          this.selectKlantbeeldAndSubject(activeKB, subject);

          const subjectModel: Object = this.constructSubjectModel(subject, activeKB.pathKeys);
          this.updateSubject('right', activeKB, subjectModel);
        } else {
          this.selectKlantbeeld(activeKB);
        }
      }
    });
  }

  updateSelectedKlantbeeld(side, klantbeeld): void {
    this.store.dispatch(new storeActions.LoadActiveKlantbeeld({ side, klantbeeld }));
    this.store.dispatch(new storeActions.LoadSelectedKlantbeeld({ side, klantbeeld }));
  }

  updateSubject(side: string, klantbeeld: any, subjectModel: Object): void {
    this.store.dispatch(new storeActions.SubjectLoadSelectedSubject({
      side,
      klantbeeld,
      subjectModel
    }));
  }

  selectKlantbeeld(klantbeeld): void {
    this.store.dispatch(new storeActions.SelectKlantbeeld({
      side: 'right',
      klantbeeld: klantbeeld
    }));
  }

  selectKlantbeeldAndSubject(klantbeeld, subject: Subject): void {
    this.store.dispatch(new storeActions.SelectKlantbeeldWithSubject({
      side: 'right',
      klantbeeld: klantbeeld,
      subject: subject,
      params: this.constructParams(subject, klantbeeld.pathKeys)
    }));
  }

  private constructParams(subject: Subject, pathKeys: PathKey[]): any {
    const params: any = {};
    pathKeys.forEach(pathKey => {
      if (pathKey.mandatory) {
        params[pathKey.name] = subject.model[pathKey.name];
      }
    });
    return params;
  }
}
