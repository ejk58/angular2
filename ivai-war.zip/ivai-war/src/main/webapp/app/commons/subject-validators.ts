export class SubjectValidator {
  public static readonly invalidBSN = 'Het opgegeven BSN is niet valide.';
  public static readonly invalidEntity = 'Het opgegeven entiteitnummer is niet valide.';

  checkValidSubjectNr(nr): boolean {
    nr = (nr == null) ? null : nr.replace(/[\./,]/g, '');
    if (nr != null && !isNaN(nr) && nr.length <= 9) {
      let checksum = 0;

      while (nr.length < 9) {
        nr = '0' + nr;
      }
      for (let i = 0; i < 8; i++) {
        checksum += (nr.charAt(i) * (9 - i));
      }
      checksum -= nr.charAt(8);

      return checksum % 11 === 0;
    } else {
      return false;
    }
  }

  checkValidEntityNr(nr): boolean {
    nr = (nr == null) ? null : nr.replace(/[\./,]/g, '');
    return (nr != null && !isNaN(nr));
  }

  generateErrorMessage(error, subjectType, subjectNumber): string {
    switch (error) {
      case 400:
        if (subjectType === 'subjectNr' && !this.checkValidSubjectNr(subjectNumber)) {
          return SubjectValidator.invalidBSN;
        }
        if (subjectType !== 'subjectNr' && !this.checkValidEntityNr(subjectNumber)) {
          return SubjectValidator.invalidEntity;
        }

      case 401: return 'U bent niet geautoriseerd om de opgevraagde VIP gegevens te bekijken.';

      case 404:
        if (subjectType === 'subjectNr' && !this.checkValidSubjectNr(subjectNumber)) {
          return SubjectValidator.invalidBSN;
        } else {
          if (subjectType !== 'subjectNr' && !this.checkValidEntityNr(subjectNumber)) {
            return SubjectValidator.invalidEntity;
          } else {
            return 'Geen resultaat.';
          }
        }

      case 500:
        if (subjectType === 'subjectNr' && !this.checkValidSubjectNr(subjectNumber)) {
          return SubjectValidator.invalidBSN;
        } else {
          if (subjectType !== 'subjectNr' && !this.checkValidEntityNr(subjectNumber)) {
            return SubjectValidator.invalidEntity;
          } else {
            return 'Door een server-fout kunnen er geen gegevens getoond worden.';
          }
        }

      default:
        return `Een onbekend probleem zorgt ervoor dat er geen gegevens getoond worden. Foutcode:${error.status}`;
    }
  }
}
