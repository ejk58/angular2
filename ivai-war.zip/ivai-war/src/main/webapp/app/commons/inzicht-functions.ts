/**
 * Returns an array filled with each underlying field of the given object.
 *
 * Example:
 * {
 *   homeAddress: {street: 'Homelane', number: 23},
 *   workAddress: {street: 'Workstreet', number: 95}
 * }
 *
 * would become
 *
 * [
 *   0: {street: 'Homelane', number: 23},
 *   1: {street: 'Workstreet', number: 95}
 * ]
 * @param object The object you wish to transform into an array
 */
export function objectFieldsAsArray(object: {[key: string]: any}): any[] {
    return Object.keys(object).map(key => object[key]);
}

/**
 * The padStart() method pads the current string with another string (multiple times, if needed) until the resulting string reaches the given length.
 * The padding is applied from the start (left) of the current string.
 * This implementation is based on the String.prototype.padStart polyfill.
 * @param source The source string you'd wish to pad
 * @param targetLength The length of the resulting string once the current string has been padded.
 *        If the value is less than the current string's length, the current string is returned as is.
 * @param padString The string to pad the current string with. If this padding string is too long to stay within the targetLength,
 *        it will be truncated from the right. The default value is " " (U+0020 'SPACE').
 */
export function padStart(source: number|string, targetLength: number, padString: string = ' '): string {
    source = String(source);
    if (source.length >= targetLength) {
        return source;
    } else {
        const diff = targetLength - source.length;
        if (diff > padString.length) {
            padString += padString.repeat(diff / padString.length); // append to original to ensure we are longer than needed
        }
        return padString.slice(0, diff) + String(source);
    }
}
