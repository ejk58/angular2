export const roles: string = 'roles';
export const userHasLoggedOut: string = 'user_has_logged_out';
export const userHasTriedSso: string = 'user_has_tried_sso';
export const username: string = 'username';
