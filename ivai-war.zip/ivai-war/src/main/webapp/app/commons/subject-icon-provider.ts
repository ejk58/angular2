import {Injectable} from '@angular/core';
import {SubjectType} from './subject-type';

@Injectable()
export class SubjectIconProvider {

  public static readonly subjectIconMap: Map<number, {normalIcon: string, mainSubjectIcon: string, normalCharacter: string, mainSubjectCharacter: string}> = new Map([
    [SubjectType.Persoon, {'normalIcon': '\ue94d', 'mainSubjectIcon': '\ue940', 'normalCharacter': 'bd_np', 'mainSubjectCharacter': 'bd_np_diap'}],
    [SubjectType.PersoonMetRelatiesBuitenEntiteit, {'normalIcon': '\ue94c', 'mainSubjectIcon': '\ue93f', 'normalCharacter': 'bd_np-out', 'mainSubjectCharacter': 'bd_np-out_diap'}],
    [SubjectType.PersoonMetRelatiesBinnenEntiteit, {'normalIcon': '\ue94b', 'mainSubjectIcon': '\ue93e', 'normalCharacter': 'bd_np-in', 'mainSubjectCharacter': 'bd_np-in_diap'}],
    [SubjectType.PersoonMetRelatiesBinnenEnBuitenEntiteit, {'normalIcon': '\ue94a', 'mainSubjectIcon': '\ue93d', 'normalCharacter': 'bd_np-in-out', 'mainSubjectCharacter': 'bd_np-in-out_diap'}],
    [SubjectType.Eenmanszaak, {'normalIcon': '\ue948', 'mainSubjectIcon': '\ue93c', 'normalCharacter': 'bd_ez', 'mainSubjectCharacter': 'bd_ez_diap'}],
    [SubjectType.EenmanszaakMetRelatiesBuitenEntiteit, {'normalIcon': '\ue947', 'mainSubjectIcon': '\ue93b', 'normalCharacter': 'bd_ez-out', 'mainSubjectCharacter': 'bd_ez-out_diap'}],
    [SubjectType.EenmanszaakMetRelatiesBinnenEntiteit, {'normalIcon': '\ue946', 'mainSubjectIcon': '\ue93a', 'normalCharacter': 'bd_ez-in', 'mainSubjectCharacter': 'bd_ez-in_diap'}],
    [SubjectType.EenmanszaakMetRelatiesBinnenEnBuitenEntiteit, {'normalIcon': '\ue945', 'mainSubjectIcon': '\ue93f', 'normalCharacter': 'bd_ez-in-out', 'mainSubjectCharacter': 'bd_ez-in-out_diap'}],
    [SubjectType.BvOfNv, {'normalIcon': '\ue944', 'mainSubjectIcon': '\ue938', 'normalCharacter': 'bd_bv', 'mainSubjectCharacter': 'bd_bv_diap'}],
    [SubjectType.BvOfNvMetRelatiesBuitenEntiteit, {'normalIcon': '\ue943', 'mainSubjectIcon': '\ue937', 'normalCharacter': 'bd_bv-out', 'mainSubjectCharacter': 'bd_bv-out_diap'}],
    [SubjectType.Stichting, {'normalIcon': '\ue951', 'mainSubjectIcon': '\ue917', 'normalCharacter': 'bd_vg', 'mainSubjectCharacter': 'bd_vg_diap'}],
    [SubjectType.StichtingMetRelatiesBuitenEntiteit, {'normalIcon': '\ue950', 'mainSubjectIcon': '\ue916', 'normalCharacter': 'bd_vg-out', 'mainSubjectCharacter': 'bd_vg-out_diap'}],
    [SubjectType.Vof, {'normalIcon': '\ue955', 'mainSubjectIcon': '\ue91b', 'normalCharacter': 'bd_vof', 'mainSubjectCharacter': 'bd_vof_diap'}],
    [SubjectType.VofMetRelatiesBuitenEntiteit, {'normalIcon': '\ue954', 'mainSubjectIcon': '\ue91a', 'normalCharacter': 'bd_vof-out', 'mainSubjectCharacter': 'bd_vof-out_diap'}],
    [SubjectType.BuitenlandseRechtsvorm, {'normalIcon': '\ue942', 'mainSubjectIcon': '\ue919', 'normalCharacter': 'bd_bl', 'mainSubjectCharacter': 'bd_bl_diap'}],
    [SubjectType.BuitenlandseRechtsvormMetRelatiesBuitenEntiteit, {'normalIcon': '\ue941', 'mainSubjectIcon': '\ue918', 'normalCharacter': 'bd_bl-out', 'mainSubjectCharacter': 'bd_bl-out_diap'}],
    [SubjectType.OverigeRechtsvorm, {'normalIcon': '\ue94f', 'mainSubjectIcon': '\ue90b', 'normalCharacter': 'bd_on', 'mainSubjectCharacter': 'bd_on_diap'}],
    [SubjectType.OverigeRechtsvormMetRelatiesBuitenEntiteit, {'normalIcon': '\ue94e', 'mainSubjectIcon': '\ue90a', 'normalCharacter': 'bd_on-out', 'mainSubjectCharacter': 'bd_on-out_diap'}],
    [SubjectType.MeerDan20PersonenOpAdres, {'normalIcon': '\ue949', 'mainSubjectIcon': '\ue906', 'normalCharacter': 'bd_np-20-plus', 'mainSubjectCharacter': 'bd_np-20-plus-diap'}],
    [SubjectType.OnbekendSubject, {'normalIcon': '\ue3c8', 'mainSubjectIcon': '\ue3c8', 'normalCharacter': 'bd_details', 'mainSubjectCharacter': 'bd_details'}]
  ]);

  public static readonly personIcon = '\ue923';
  public static readonly businessIcon = '\ue957';
  public static readonly partnerIcon = '\ue91d';
  public static readonly manyPeopleIcon = '\ue905';

  public static readonly personProfileIcon = '\ue7fd';
  public static readonly businessProfileIcon = '\ue7ee';
  public static readonly relationIcon = '\ue913';
  public static readonly locationIcon = '\ue8b4';

  public getMainSubjectIcon(type: number): string {
    return SubjectIconProvider.subjectIconMap.has(type) ? SubjectIconProvider.subjectIconMap.get(type).mainSubjectIcon : '\ue3c8';
  }

  public getMainSubjectCharacter(type: number): string {
    return SubjectIconProvider.subjectIconMap.has(type) ? SubjectIconProvider.subjectIconMap.get(type).mainSubjectCharacter : 'bd_details';
  }

  public getNormalSubjectIcon(type: number): string {
    return SubjectIconProvider.subjectIconMap.has(type) ? SubjectIconProvider.subjectIconMap.get(type).normalIcon : '\ue3c8';
  }

  public getNormalSubjectCharacter(type: number): string {
    return SubjectIconProvider.subjectIconMap.has(type) ? SubjectIconProvider.subjectIconMap.get(type).normalCharacter : 'bd_details';
  }
}
