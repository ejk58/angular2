import { Injectable } from '@angular/core';
import { Selection } from 'd3-ng2-service';

@Injectable()
export class SvgIconProvider {

  public drawPersonIcon(group: Selection<any, any, any, any>, x: number, y: number, size: number, classes: string): void {
    group.append('circle')
      .attr('cx', x + size * 0.500)
      .attr('cy', y + size * 0.200)
      .attr('r', size * 0.200)
      .attr('class', classes);

    group.append('path')
      .attr('d', 'M' + (x + size * 0.100) + ',' + (y + size) +
        ' c' + size * 0.100 + ',' + size * -0.600 + ' ' + size * 0.700 + ',' + size * -0.600 + ' ' + (size * 0.800) + ',0' +
        ' z')
      .attr('class', classes);
  }

  public drawBusinessIcon(group: Selection<any, any, any, any>, x: number, y: number, size: number, classes: string): void {
    group.append('rect')
      .attr('x', x)
      .attr('y', y)
      .attr('width', size * 0.500)
      .attr('height', size)
      .attr('class', classes);

    group.append('line')
      .attr('x1', x + size * 0.250)
      .attr('y1', y)
      .attr('x2', x + size * 0.250)
      .attr('y2', y + size)
      .attr('class', classes);

    group.append('rect')
      .attr('x', x)
      .attr('y', y + size * 0.250)
      .attr('width', size)
      .attr('height', size * 0.750)
      .attr('class', classes);

    group.append('line')
      .attr('x1', x)
      .attr('y1', y + size * 0.500)
      .attr('x2', x + size * 0.650)
      .attr('y2', y + size * 0.500)
      .attr('class', classes);

    group.append('line')
      .attr('x1', x)
      .attr('y1', y + size * 0.750)
      .attr('x2', x + size * 0.650)
      .attr('y2', y + size * 0.750)
      .attr('class', classes);

    group.append('line')
      .attr('x1', x + size * 0.750)
      .attr('y1', y + size * 0.500)
      .attr('x2', x + size * 0.850)
      .attr('y2', y + size * 0.500)
      .attr('class', classes);

    group.append('line')
      .attr('x1', x + size * 0.750)
      .attr('y1', y + size * 0.750)
      .attr('x2', x + size * 0.850)
      .attr('y2', y + size * 0.750)
      .attr('class', classes);
  }

  public drawRelationsIcon(group: Selection<any, any, any, any>, x: number, y: number, size: number, classes: string): void {
    group.append('circle')
      .attr('cx', x + size * 0.200)
      .attr('cy', y + size * 0.200)
      .attr('r', size * 0.200)
      .attr('class', classes);

    group.append('circle')
      .attr('cx', x + size * 0.800)
      .attr('cy', y + size * 0.200)
      .attr('r', size * 0.200)
      .attr('class', classes);

    group.append('circle')
      .attr('cx', x + size * 0.500)
      .attr('cy', y + size * 0.800)
      .attr('r', size * 0.200)
      .attr('class', classes);

    group.append('line')
      .attr('x1', x + size * 0.400)
      .attr('y1', y + size * 0.200)
      .attr('x2', x + size * 0.600)
      .attr('y2', y + size * 0.200)
      .attr('class', classes);

    group.append('line')
      .attr('x1', x + size * 0.270)
      .attr('y1', y + size * 0.360)
      .attr('x2', x + size * 0.420)
      .attr('y2', y + size * 0.640)
      .attr('class', classes);
  }
}
