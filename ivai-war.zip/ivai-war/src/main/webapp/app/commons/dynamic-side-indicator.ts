export class DynamicSideIndicator {

  // Generate dynamic side key based on action payload side
  getSides(side): { updateSide: string; staticSide: string } {
    return {
      updateSide: side === 'left' ? 'left' : 'right',
      staticSide: side === 'left' ? 'right' : 'left'
    };
  }
}
