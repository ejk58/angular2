import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable()
export class SubjectService {

  constructor(private readonly http: HttpClient) { }

  public getSubjects(viewId: string, type: string, subjectNr: string): Observable<any> {
    return this.http.get('rest/subject?viewId=' + viewId + '&' + type + '=' + subjectNr, {withCredentials: true});
  }

}
