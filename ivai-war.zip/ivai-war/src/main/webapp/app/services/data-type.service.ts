import { Injectable } from '@angular/core';

@Injectable()
export class DataTypeService {

  public static readonly baseNumber: string = 'NUMBER';
  public static readonly baseString: string = 'STRING';
  public static readonly baseDate: string = 'DATE';
  public static readonly baseYear: string = 'YEAR';
  public static readonly baseMoney: string = 'MONEY';
  public static readonly baseForeignMoney: string = 'FOREIGNMONEY';
  public static readonly basePercentage: string = 'PERCENTAGE';
  public static readonly baseWeight: string = 'WEIGHT';
  public static readonly baseTrafficLight: string = 'TRAFFICLIGHT';
  public static readonly baseComplianceLight: string = 'COMPLIANCELIGHT';
  public static readonly baseProcessLight: string = 'PROCESSLIGHT';
  public static readonly baseImage: string = 'IMAGE';
  public static readonly baseFileLink: string = 'FILELINK';
  public static readonly baseScrollLink: string = 'SCROLLLINK';
  public static readonly baseSparkLine: string = 'SPARKLINE';
  public static readonly baseDifferenceMarker: string = 'DIFFERENCEMARKER';
  public static readonly baseAsSpecified: string = 'ASSPECIFIED';

  public static readonly baseTypes: string[] = [DataTypeService.baseNumber, DataTypeService.baseString, DataTypeService.baseMoney, DataTypeService.baseForeignMoney,
      DataTypeService.baseDate, DataTypeService.baseYear,
      DataTypeService.baseWeight, DataTypeService.basePercentage, DataTypeService.baseImage,
      DataTypeService.baseTrafficLight, DataTypeService.baseComplianceLight, DataTypeService.baseProcessLight,
      DataTypeService.baseFileLink, DataTypeService.baseScrollLink,
      DataTypeService.baseSparkLine, DataTypeService.baseDifferenceMarker, DataTypeService.baseAsSpecified];

  public static readonly prefixDrillDown: string = 'DRILLDOWN';
  public static readonly prefixAnnotated: string = 'ANNOTATED';
  public static readonly prefixFootnoted: string = 'FOOTNOTED';
  public static readonly prefixPageLink: string = 'PAGELINK';
  public static readonly prefixSearchLink: string = 'SEARCHLINK';
  public static readonly prefixTrend: string = 'TREND';
  public static readonly prefixDelta: string = 'DELTA';

  public static readonly prefixTypes: string[] = [DataTypeService.prefixDrillDown,
      DataTypeService.prefixFootnoted, DataTypeService.prefixAnnotated,
      DataTypeService.prefixPageLink, DataTypeService.prefixSearchLink,
      DataTypeService.prefixTrend, DataTypeService.prefixDelta];

  public static readonly leftAlignBaseTypes: string[] = [DataTypeService.baseString, DataTypeService.baseDate, DataTypeService.baseYear,
      DataTypeService.baseComplianceLight, DataTypeService.baseFileLink, DataTypeService.baseScrollLink];
  public static readonly possiblyNegativeBaseTypes: string[] = [DataTypeService.baseNumber, DataTypeService.baseMoney, DataTypeService.baseForeignMoney];

  public getDefaultAlignment(type: string, value?: any): string {
    const baseType = this.getBaseType(type, value);
    let alignment = DataTypeService.leftAlignBaseTypes.some(leftAlignType => leftAlignType === baseType) ? 'left' : 'right';

    if (this.isSpecifiedType(type) && value != null && value.Meeteenheid === 'TEKSTRECHTS') {
      alignment = 'right';
    }

    return alignment;
  }

  public getBaseType(type: string, value?: any): string {
    let baseType = type;

    if (this.isSpecifiedType(type) && value != null) {
      baseType = this.getTypeFromSpecified(value);
    } else if (type) {
      baseType = DataTypeService.baseTypes.find(baseType => type.indexOf(baseType, type.length - baseType.length) !== -1);
    }

    return baseType;
  }

  public getOuterType(type: string): string {
    return type ? DataTypeService.prefixTypes.find(prefixType => type.indexOf(prefixType) === 0) : type;
  }

  public getInnerType(type: string): string {
    const outerType = this.getOuterType(type);
    return (type != null && outerType != null) ? type.substring(outerType.length) : type;
  }

  public getTypeFromSpecified(value: any): string {
    let type = 'STRING';

    if (value.Meeteenheid === 'GETAL') {
      type = 'NUMBER';
    } else if (value.Meeteenheid === 'BEDRAG') {
      type = 'MONEY';
    } else if (value.Meeteenheid === 'PERCENTAGE') {
      type = 'PERCENTAGE';
    } else if (value.hasOwnProperty('unit')) {
      type = value.unit;
    }

    return type;
  }

  public isBaseType(type: string): boolean {
    return type && DataTypeService.baseTypes.some(baseType => type === baseType);
  }

  public isOfBaseType(type: string, baseType: string) {
    return type === baseType;
  }

  public isOfOuterType(type: string, outerType: string) {
    return type && type.indexOf(outerType) === 0;
  }

  public isSpecifiedType(type: string): boolean {
    return type && type.indexOf(DataTypeService.baseAsSpecified, type.length - DataTypeService.baseAsSpecified.length) !== -1;
  }

  public isDrillDownType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixDrillDown);
  }

  public isPageLinkType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixPageLink);
  }

  public isSearchLinkType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixSearchLink);
  }

  public isAnnotatedType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixAnnotated);
  }

  public isFootnotedType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixFootnoted);
  }

  public isTrendType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixTrend);
  }

  public isDeltaType(type: string): boolean {
    return this.isOfOuterType(type, DataTypeService.prefixDelta);
  }

  public isFileLinkType(type: string): boolean {
    return this.isOfBaseType(type, DataTypeService.baseFileLink);
  }

  public isScrollLinkType(type: string): boolean {
    return this.isOfBaseType(type, DataTypeService.baseScrollLink);
  }

}
