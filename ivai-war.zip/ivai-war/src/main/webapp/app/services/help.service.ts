import {Injectable} from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable()
export class HelpState {
  public helpText = new BehaviorSubject<any>([]);
  public generalHelp = { 'title': 'Help', texts: [
      {
        title: '',
        content: `
        <div class="main-help-div">
            <h2>Iconen in de menubalk</h2>
          <ul>
            <li>
                <div class="header-icon fa bd_menu-hm float-left"></div>
                <p>Hier vind je de pagina’s die binnen je klantbeeld beschikbaar zijn</p>
            </li>
            <li>
                <div class="header-icon fa bd_relaties-hm float-left"></div>
                <p>Bekijk en selecteer (entiteits) relaties van je actieve BSN / RSIN</p>
            </li>
            <li>
                <div class="header-icon fa bd_search float-left"></div>
                <p>Zoek een nieuw BSN / RSIN of selecteer een ander belastingjaar</p>
            </li>
            </ul>
            <ul>
            <li>
                <div class="header-icon fa bd_image_aspect_ratio float-left"></div>
                <p>Wissel tussen de verschillende klantbeelden</p>
            </li>
            <li>
                <div class="header-icon fa bd_help_outline float-left"></div>
                 <p>Open dit helpscherm om uitleg over de applicatie te krijgen</p>
            </li>
            <li>
                <div class="header-icon fa bd_person_outline float-left"></div>
                <p>In het accountmenu kan je feedback geven of uitloggen </p>
            </li>
          </ul>
        </div>
        <div class="main-help-div">
          <h2>Presentatie van gegevens</h2>
          <p class="helft">In Inzicht wordt informatie gepresenteerd in diverse vormen: tabellen, grafieken en andere
          grafische weergaven zoals bijvoorbeeld relaties. Rechtsboven in het kader kan je op de drie stipjes klikken
          om een menu te openen. Hier vind je onder andere ‘help’. Klik erop voor uitleg over de data en technische
          werking.</p>
          <div class="helft widgets-help-img">
        </div>
        <div class="main-help-div">
          <h2>Tweede scherm</h2>
          <p class="helft">Binnen Inzicht kan je met twee schermen werken, waardoor je eenvoudig gegevens kunt
          vergelijken. Je opent het tweede scherm, door rechts in beeld aan de donkergrijze schuifbalk te slepen.
          Als je binnen een pagina op een BSN / RSIN klikt, dan opent deze automatisch in het tweede scherm.</p>
          <div class="helft splitscreen-help-img">
        </div>
        `
      }
    ]};
  emitHelpText(helpText: any) {
    this.helpText.next(helpText);
  }

  listenHelpText(): Observable<any> {
    return this.helpText;
  }
}
