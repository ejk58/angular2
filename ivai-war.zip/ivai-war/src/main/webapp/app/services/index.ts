import {AuthenticationService} from './authentication.service';
import {TrackingService} from './tracking.service';
import {WidgetService} from './widget.service';
import {SplitViewState} from './split-view-state.service';
import {PageTitleService} from './page-title.service';
import {HelpState} from './help.service';
import {EventService} from './event.service';
import {SubjectService} from './subject.service';
import {DataTypeService} from './data-type.service';

export const list = [
  AuthenticationService,
  TrackingService,
  WidgetService,
  SplitViewState,
  PageTitleService,
  HelpState,
  EventService,
  SubjectService,
  DataTypeService
];
