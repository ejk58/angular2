import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';

import * as storageKeys from '../commons/storage-keys';

@Injectable()
export class AuthenticationService {
  private readonly userName = new Subject<any>();
  private readonly httpOptions = { withCredentials: true };

  constructor(private readonly router: Router,
              private readonly http: HttpClient) { }

  login(username: string, password: string): Observable<any> {
    sessionStorage.removeItem(storageKeys.username);
    sessionStorage.removeItem(storageKeys.roles);

    return this.http.post('rest/security/login', { username: username, password: password }, this.httpOptions);
  }

  logout(): void {
    this.http.post('rest/security/logout', this.httpOptions, { responseType: 'text' })
      .subscribe(
      data => {
        sessionStorage.removeItem(storageKeys.roles);
        sessionStorage.setItem(storageKeys.userHasLoggedOut, 'true');
        sessionStorage.removeItem(storageKeys.username);

        this.sendUserName(null);
        this.router.navigate(['/login']);
      });
  }

  sso(): Observable<any> {
    const userHasLoggedOut = sessionStorage.getItem(storageKeys.userHasLoggedOut);
    const userHasTriedSso = sessionStorage.getItem(storageKeys.userHasTriedSso);

    if (!userHasLoggedOut && !userHasTriedSso) {
      sessionStorage.setItem(storageKeys.userHasTriedSso, 'true');

      return this.http.get('sso/login', this.httpOptions);
    }
    return null;
  }

  getUser(): string {
    const user = sessionStorage.getItem(storageKeys.username);
    if (user) {
      return user.toUpperCase();
    }
    return null;
  }

  sendUserName(name: string): void {
    this.userName.next({ text: name });
  }

  getUserName(): Observable<{ text: string }> {
    return this.userName.asObservable();
  }

  isLoggedIn(): boolean {
    return this.getUser() !== null;
  }

  triedSso(): boolean {
    return sessionStorage.getItem(storageKeys.userHasTriedSso) != null;
  }
}
