import {Component, OnInit} from '@angular/core';
import {AuthenticationService} from './services/authentication.service';
import {environment} from '../environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {

  public title = 'Inzicht';
  svg_path = environment.svg_path;
  public username: any;

  constructor(private readonly auth: AuthenticationService) {
    this.auth.getUserName().subscribe(userName => {
      if (userName) {
        this.username = userName.text;
      }
    });
  }

  ngOnInit() {
    this.auth.sendUserName(null);
  }

}
