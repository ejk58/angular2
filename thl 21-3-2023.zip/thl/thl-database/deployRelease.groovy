@Library("GENERIC") _
	pipelineDeployDatabaseFromNexus {
		deploymentId = "thl-database"
		integrationPipeline = "IVA-THL_test-Robot"
		packageChoices = "iva-thl-database"
		applicationVersionChoices = "0.4.2\n0.4.1\n0.4.0\n0.3.0\n0.2.1"
		environmentChoices = "tst\nacc\nprd"
		streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
	}
