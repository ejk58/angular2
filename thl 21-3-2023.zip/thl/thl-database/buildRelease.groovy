@Library("GENERIC") _
    pipelineDatabaseRelease {
		deploymentId = "thl-database"
		deployPipeline = "IVA-THL_database-deploy-release"
		integrationPipeline = "IVA-THL_test-Robot"
		environmentChoices = "tst\nacc"
		streetChoices = "str11\nstr12\nstr13\nstr14\nstr15"
	}
