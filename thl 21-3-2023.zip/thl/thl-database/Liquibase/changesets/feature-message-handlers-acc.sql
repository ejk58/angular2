-- Corresponds to the prefix FEATURE_PREFIX_MESSAGE_HANDLER in thl-dev\thl-ws\src\main\java\nl\belastingdienst\iva\wd\thl\mq\MessageHandler.java
DELETE FROM FEATURE WHERE NAME LIKE 'MESSAGE-HANDLER_%';
COMMIT;

-- Corresponds to aforementioned prefix + ID's of enum members in thl-dev\thl-ws\src\main\java\nl\belastingdienst\iva\wd\thl\mq\MessageIdentifier.java
INSERT INTO FEATURE (NAME, ENABLED_SINCE_TS, DESCRIPTION) VALUES
  ('MESSAGE-HANDLER_TGL-ABS01', '2021-05-26 09:00:00.000', 'MessageHandler voor MQ berichten met ID TGL-ABS01'),
  ('MESSAGE-HANDLER_TGL-VPB02', '2021-05-26 09:00:00.000', 'MessageHandler voor MQ berichten met ID TGL-VPB02'),
  ('MESSAGE-HANDLER_TGL-RSA03', '2021-05-26 09:00:00.000', 'MessageHandler voor MQ berichten met ID TGL-RSA03'),
  ('MESSAGE-HANDLER_TGL-ATK04', '2021-05-26 09:00:00.000', 'MessageHandler voor MQ berichten met ID TGL-ATK04'),
  ('MESSAGE-HANDLER_TGL-ATK05', '2021-05-26 09:00:00.000', 'MessageHandler voor MQ berichten met ID TGL-ATK05'),
  ('MESSAGE-HANDLER_TGL-VTC06', '2021-05-26 09:00:00.000', 'MessageHandler voor MQ berichten met ID TGL-VTC06'),
  ('MESSAGE-HANDLER_TGL-KWO07', '2021-05-26 09:00:00.000', 'MessageHandler voor MQ berichten met ID TGL-KWO07')
;
COMMIT;
