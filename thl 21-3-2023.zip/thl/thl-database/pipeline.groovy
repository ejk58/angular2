@Library("GENERIC") _
    pipelineDatabase_v2 {
			deploymentId = "thl-database"
			environmentChoices = "ont\ntst"
			streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
			codePipeline = ["IVA-THL_build"]
    }
