@Library("GENERIC") _
pipelineTest_v3a {
    deploymentId = "iva-thl"
    project = "iva-thl"
    robotTestPath = "iva-thl-robot/testsuites"
    robotArguments = "--include FINAL --exclude NIGHTLY"
    robotNonCriticals = "--noncritical NONCRITICAL"
    robotDir = "/srv/jenkins/home/robotframework_322/bin/"
    environmentChoices = "ont\ntst\nacc"
    streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
}