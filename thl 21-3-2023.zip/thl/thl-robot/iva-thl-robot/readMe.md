De file resources/BAT_testdata.sql is gelijk aan de file liquibase/testdata.
Dit moet nog aan een repository toegeveogd worden (zie IVATHL-39)