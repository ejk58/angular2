@Library("GENERIC") _
pipelineRelease {
    deploymentId = "iva-thl"
    deployPipeline = "IVA-THL_deploy-release"
    integrationPipeline = "IVA-THL_test-Robot"
    environmentChoices = "tst\nacc"
    streetChoices = "str11\nstr12"
}
