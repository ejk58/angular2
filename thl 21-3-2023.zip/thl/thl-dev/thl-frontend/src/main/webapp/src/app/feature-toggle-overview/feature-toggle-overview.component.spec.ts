import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeatureToggleOverviewComponent } from './feature-toggle-overview.component';

describe('FeatureToggleOverviewComponent', () => {
  let component: FeatureToggleOverviewComponent;
  let fixture: ComponentFixture<FeatureToggleOverviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeatureToggleOverviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeatureToggleOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
