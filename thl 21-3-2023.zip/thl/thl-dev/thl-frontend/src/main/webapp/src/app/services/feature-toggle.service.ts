import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Feature} from '../interfaces/feature';

@Injectable({
  providedIn: 'root'
})
export class FeatureToggleService {

  public static readonly SERVICE_ROOT = '/thl/rest/features';

  constructor(private readonly http: HttpClient) {
  }

  findAll(): Observable<Feature[]> {
    return this.http.get<Feature[]>(`${FeatureToggleService.SERVICE_ROOT}/all`);
  }

  findByName(name: string): Observable<Feature> {
    return this.http.get<Feature>(`${FeatureToggleService.SERVICE_ROOT}/${name}`);
  }

  toggleFeatureByName(name: string): Observable<Feature[]> {
    return this.http.get<Feature[]>(`${FeatureToggleService.SERVICE_ROOT}/${name}/toggle`);
  }
}
