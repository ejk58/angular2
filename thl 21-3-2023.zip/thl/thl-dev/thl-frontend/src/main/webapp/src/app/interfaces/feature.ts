export interface Feature {
  name: string;
  enabledSince: Date;
  description: string;
}
