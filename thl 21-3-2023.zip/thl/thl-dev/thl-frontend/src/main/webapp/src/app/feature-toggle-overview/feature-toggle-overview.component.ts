import {Component, OnInit} from '@angular/core';
import {FeatureToggleService} from '../services/feature-toggle.service';
import {Observable} from 'rxjs';
import {Feature} from '../interfaces/feature';

@Component({
  selector: 'app-feature-toggle-overview',
  templateUrl: './feature-toggle-overview.component.html',
  styleUrls: ['./feature-toggle-overview.component.scss']
})
export class FeatureToggleOverviewComponent implements OnInit {

  featureToggles$: Observable<Feature[]> = this.featureService.findAll();

  constructor(private readonly featureService: FeatureToggleService) {
  }

  ngOnInit(): void {
  }

  toggleFeatureByName(name: string): void {
    this.featureToggles$ = this.featureService.toggleFeatureByName(name);
  }
}
