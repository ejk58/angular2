import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {CountVerwerkingenResponse, VerwerkingResponse} from "../home/home.component";
import {IsAliveInformation} from "../domain/is.alive.information";

@Injectable({
  providedIn: 'root'
})
export class VerwerkingenService {

  constructor(private readonly http: HttpClient) { }

  count(): Observable<CountVerwerkingenResponse> {
    return this.http
      .get<CountVerwerkingenResponse>('/thl/rest/operations/verwerkingen/count');
  }

  countLastWeek(): Observable<CountVerwerkingenResponse> {
    return this.http
      .get<CountVerwerkingenResponse>('/thl/rest/operations/verwerkingen/countLastWeek');
  }

  findAll(): Observable<VerwerkingResponse[]> {
    return this.http
      .get<VerwerkingResponse[]>('/thl/rest/operations/verwerkingen/');
  }

  findBy(id: number): Observable<VerwerkingResponse> {
    return this.http
      .get<VerwerkingResponse>(`/thl/rest/operations/verwerkingen/${id}`);
  }

  getIsAliveInformation(): Observable<IsAliveInformation> {
    return this.http
      .get<IsAliveInformation>('/thl/rest/isAlive');
  }

}
