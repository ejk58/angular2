export interface IsAliveInformation {
  serverName: string;
  alive: boolean;
  version: string;
  buildNumber: string;
  components: Map<string, number>;
}
