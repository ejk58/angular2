import {MenuItem} from "iv-framework-lib";

export const initialMenuItems: Array<MenuItem> = [
  {
    text: 'Overzicht',
    route: '/authenticated/home',
    icon: 'fas fa-chart-line'
  },
  {
    text: 'Operations',
    route: '/authenticated/operations',
    icon: 'fas fa-cog'
  },

]
