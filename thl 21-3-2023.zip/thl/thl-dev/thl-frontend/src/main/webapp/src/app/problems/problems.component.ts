import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import {ProblemsService} from "../services/problems.service";
import {Verwerking} from "../interfaces/verwerking";

@Component({
  selector: 'app-problems',
  templateUrl: './problems.component.html',
  styleUrls: ['./problems.component.scss']
})
export class ProblemsComponent implements OnInit {
  verwerking: Verwerking = {
    id: 1, problems: [
      {
        id: 1,
        version: 1,
        verwerkingId: 1,
        error: 'errorblob',
        moment: new Date()
      },
      {
        id: 2,
        version: 2,
        verwerkingId: 2,
        error: 'errorblob',
        moment: new Date()
      }
    ],
    correlationId: "correlationId",
    type: "type",
    einde: new Date(),
    start: new Date(),
    aantalRequestRecords: 2,
    aantalResponseRecords: 3

  }


  constructor(private readonly route: ActivatedRoute,
              private readonly problems: ProblemsService) {

  }

  ngOnInit(): void {
    this.verwerking = this.problems.verwerking;
  }
}
