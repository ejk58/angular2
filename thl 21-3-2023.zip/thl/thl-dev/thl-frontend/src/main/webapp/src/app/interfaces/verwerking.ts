import {Problem} from "./problem";

export interface Verwerking {
  id: number,
  correlationId: string,
  start: Date,
  einde: Date,
  type: string,
  aantalRequestRecords: number,
  aantalResponseRecords: number,
  problems: Problem[]
}
