import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor() {
  }

  intercept(req: HttpRequest<any>,
            next: HttpHandler): Observable<HttpEvent<any>> {
return  next.handle(req);
    console.log('interceptor');
    const idToken = localStorage.getItem('id_token');
    if (idToken && req.url !== '/api/login') {
      const cloned = req.clone({
        headers: req.headers.set('Authorization', `Bearer ${idToken}`)
      });

      return next.handle(cloned);
    } else {
      const ret = next.handle(req);
      ret.subscribe(
        (event: HttpEvent<any>) => {
          if (event instanceof HttpResponse) {
            const tkn = event.headers.get('authorization');
            if (tkn) {
              localStorage.setItem('id_token', tkn.substr(7));
            }
          }
        }, (err: any) => {
          if (err instanceof HttpErrorResponse) {
            if (err.status === 401 || err.status === 403) {
              console.log('Token niet meer geldig');
              // redirect to the login route
              // or show a modal
            }
          }
        });
      return ret;
    }
  }
}
