import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class CountService {
  //Error messages : Methodes voor de error queue
  errormessagesUrl = '/thl/rest/mq/v1/errorQueue/count';
  // Event messages : Methodes voor de TGl input queue
  eventMessagesUrl = '/thl/rest/mq/v1/tglEventQueue/count';
  // Response messages : Methodes voor de response queue
  responseMessageUrl = '/thl/rest/mq/v1/responseQueue/count';

  private readonly headers = new HttpHeaders()
    .set('Content-Type', 'application/json; charset=utf-8')
    .set('accept', 'application/json')
    .set('x-api-key','F9NI3P1XYOTODS8C');

  constructor(private readonly http: HttpClient) {
  }

  countErrorMessages(): Observable<any> {
    return this.http
      .get<any>(this.errormessagesUrl,  {headers : this.headers} );
  }

  countEventMessages(): Observable<any> {
    return this.http
      .get<any>(this.eventMessagesUrl,  {headers : this.headers});
  }

  countResponseMessages(): Observable<any> {
    return this.http
      .get<any>(this.responseMessageUrl,  {headers : this.headers});
  }
}
