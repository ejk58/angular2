export interface Problem {
  id: number,
  version: number,
  verwerkingId: number,
  moment: Date,
  error: string
}
