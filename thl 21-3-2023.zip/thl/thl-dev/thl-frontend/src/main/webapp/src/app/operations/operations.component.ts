import {AfterViewInit, Component, OnInit} from '@angular/core';
import {VerwerkingenService} from "../services/verwerkingen.service";
import {Router} from "@angular/router";
import {Verwerking} from "../interfaces/verwerking";
import {ProblemsService} from "../services/problems.service";

@Component({
  selector: 'app-operations',
  templateUrl: './operations.component.html',
  styleUrls: ['./operations.component.scss']
})
export class OperationsComponent implements OnInit, AfterViewInit {
  verwerkingenCol: Verwerking[] = [];

  constructor(private readonly verwerkingenService: VerwerkingenService,
              private readonly problems: ProblemsService,
              private readonly router: Router) { }

  ngOnInit(): void {
    this.findAllOpererations()
  }

  ngAfterViewInit() {


  }

  findAllOpererations() {
    this.verwerkingenService.findAll()
      .subscribe((data: any ) => {
          this.verwerkingenCol = data.verwerkingen;
        },
        error => {
          console.log('error bij verwerkingen count', error);
        }, () => {
          console.log('done find all verwerkingen.');
        });
  }

  showErrorsFor(verwerking: Verwerking ): void {
    if (!verwerking || verwerking.problems.length < 1) {
      return;
    }
    console.log('open problem page with verwerking', verwerking);
    this.problems.verwerking = verwerking;
    this.router.navigate(['authenticated','problems']);
  }

  verschilEindeStart(verwerking: Verwerking): number {
    return verwerking.einde.valueOf() - verwerking.start.valueOf();
  }

  getSizeProblems(verwerking: Verwerking): number | string {
    if (!verwerking || verwerking.problems.length < 1) {
      return '-';
    }
    return verwerking.problems.length;
  }

  verwerkingenAanwezig(): boolean {
    return !this.verwerkingenCol || this.verwerkingenCol.length > 0;
  }
}
