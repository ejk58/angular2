import { Injectable } from '@angular/core';
import {Verwerking} from "../interfaces/verwerking";

@Injectable({
  providedIn: 'root'
})
export class ProblemsService {

  public verwerking: Verwerking = {
    id: 0, problems: [
    ],
    correlationId: "0",
    type: "0",
    einde: new Date(),
    start: new Date(),
    aantalRequestRecords: 0,
    aantalResponseRecords: 0

  };

  constructor() { }

}
