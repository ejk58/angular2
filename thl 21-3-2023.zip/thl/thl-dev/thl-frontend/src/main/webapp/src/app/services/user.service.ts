import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {UserApi} from 'iv-framework-lib';

@Injectable()
export class UserService extends UserApi {

  isAuthenticated = true; // TODO Debug: Remove this line, because effectively THL doesn't use any authentication?
  private username = "";

  constructor(private readonly router: Router, private readonly httpClient: HttpClient) {
    super();
  }

  signIn(username: string, password: string) {
    return of({}); // TODO Debug: Remove this line, because effectively THL doesn't use any authentication?
    // return this.httpClient.post('/api/login', {username, password});
  }

  signOut(): Observable<any> {
    localStorage.removeItem('id_token');
    return of({});
  }

  getSignInRoute(): string {
    return "signIn";
  }
  getAuthenticatedRoute(): string {
    return "authenticated";
  }
  isSignedIn(): boolean {
    return this.isAuthenticated;
  }
  getUsername(): string | null {
    return this.username;
  }
}
