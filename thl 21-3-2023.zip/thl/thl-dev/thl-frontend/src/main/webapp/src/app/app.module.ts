import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {HashLocationStrategy, LocationStrategy} from '@angular/common';
import {FeedbackApi, FrameworkModule, UserApi} from 'iv-framework-lib';
import {RouterModule} from '@angular/router';
import {appRoutes} from './app.routing';
import {AppComponent} from './app.component';
import {HomeComponent} from './home/home.component';
import {OperationsComponent} from './operations/operations.component';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {UserService} from './services/user.service';
import {AuthenticatedUserComponent} from './authenticated-user/authenticated-user.component';
import {AuthInterceptor} from './services/auth-interceptor';
import {AuthGuard} from './services/auth-guard.service';
import {ProblemsComponent} from './problems/problems.component';
import {FeatureToggleOverviewComponent} from './feature-toggle-overview/feature-toggle-overview.component';
import {FeedbackService} from './services/feedback.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    OperationsComponent,
    AuthenticatedUserComponent,
    ProblemsComponent,
    FeatureToggleOverviewComponent
  ],
  imports: [
    BrowserModule,
    FrameworkModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule
  ],
  providers: [
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    UserService,
    {
      provide: UserApi,
      useExisting: UserService
    },
    FeedbackService,
    {
      provide: FeedbackApi,
      useExisting: FeedbackService
    },
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
