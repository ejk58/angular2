import {Routes} from '@angular/router';
import {OperationsComponent} from "./operations/operations.component";
import {HomeComponent} from "./home/home.component";
import {SignInComponent} from "iv-framework-lib";
import {AuthGuard} from "./services/auth-guard.service";
import {AuthenticatedUserComponent} from "./authenticated-user/authenticated-user.component";
import {ProblemsComponent} from "./problems/problems.component";

export const appRoutes: Routes = [
  { path: 'signin', component: SignInComponent },
  { path: 'authenticated', component: AuthenticatedUserComponent, canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', component: HomeComponent },
      { path: 'operations', component: OperationsComponent },
      { path: 'problems', component: ProblemsComponent  },
    ]
  },
  { path: '', component: SignInComponent },
  { path: '**', component: SignInComponent },
]
