    pipelineCode_v4 {
        deploymentId = "iva-thl"
        integrationPipeline = "IVA-THL_test-Robot"
        environmentChoices = "ont\ntst\nacc"
        streetChoices = "str11\nstr12\nstr13"
    }
