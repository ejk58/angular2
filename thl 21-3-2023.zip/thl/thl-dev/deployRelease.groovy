@Library("GENERIC") _
pipelineDeployArtifactFromNexus_v1 {
    deploymentId = "iva-thl"
    integrationPipeline = "IVA-THL_test-Robot"
    packageChoices = "iva-thl\nas-iva-thl"
    applicationVersionChoices = "0.5.1\n0.5.0\n0.4.0\n0.3.0\n0.2.4"
    asVersionChoices = "n.v.t"
    environmentChoices = "tst\nacc\nprd"
    streetChoices = "str11\nstr12"
}
