package nl.belastingdienst.iva.wd.thl.dao;

import java.util.List;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import nl.belastingdienst.iva.wd.thl.domain.Feature;

import lombok.extern.slf4j.Slf4j;

@Singleton
@Slf4j
public class FeatureDao {

	private static final String FULL_SELECT = " select f from Feature f ";
	private static final String ORDER_BY_NAME = " order by f.name ";

	@PersistenceContext(unitName = "iva-thl-pu")
	private EntityManager em;

	public List<Feature> findAll() {
		TypedQuery<Feature> query = em.createQuery(FULL_SELECT + ORDER_BY_NAME, Feature.class);
		return query.getResultList();
	}

	public Feature findByName(String name) {
		TypedQuery<Feature> query = em.createQuery(FULL_SELECT + " where f.name = :nameParam " + ORDER_BY_NAME, Feature.class);
		query.setParameter("nameParam", name);
		return query.getSingleResult();
	}

	public Feature update(Feature f) {
		return em.merge(f);
	}
}
