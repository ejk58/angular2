package nl.belastingdienst.iva.wd.thl.mq.handler;

import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

/**
 * Deze handler krijgt een lijst van BSN/RSIN, haalt bij de BAT all
 */
public class Abs01Handler extends AbstractHandler {
	private static final int BSN_START = 0;
	private static final int BSN_END = 9;
	private static final int JAAR_START = 9;
	private static final int JAAR_END = 13;
	private static final int MIDDEL_START = 13;
	private static final int MIDDEL_END = 16;

	private static final int ANSWER_PART_START = 0;
	private static final int ANSWER_PART_END = 16;

	private static final int REQUEST_RECORD_LENGTH = 16;
	static final int ANSWER_RECORD_LENGTH = 18;

	@Inject
	private BatDao batDao;

	@Override
	public List<String> getData(List<String> records, ProgressReporter reporter, String lineEnding) {
		List<String> responseList = new LinkedList<>();
		int recCnt = 0;
		StringBuilder sb = new StringBuilder();
		for (String rec : records) {
			if (rec.length() != REQUEST_RECORD_LENGTH) {
				reporter.reportBadRecordLength(recCnt + 1);
			}
			if (recCnt++ == 0) {
				addVoorloopRecord(sb, rec, reporter);
			} else {
				processRecord(sb, rec, recCnt, reporter);
			}
			sb.append(lineEnding);
		}
		reporter.numberOfResponseRecords(recCnt);

		responseList.add(sb.toString());
		return responseList;
	}

	private void processRecord(StringBuilder sb, String rec, int recNumber, ProgressReporter reporter) {
		if (rec.length() < MIDDEL_END) {
			// If the request record is to small to hold valid data we just return it with answer 'No BehandelVoornemen found'
			reporter.reportBadRecordLength(recNumber);
			sb.append(rec, ANSWER_PART_START, rec.length());
			return;
		}
		sb.append(rec, ANSWER_PART_START, ANSWER_PART_END);

		String bsn = rec.substring(BSN_START, BSN_END).trim();
		String belastingJaar = rec.substring(JAAR_START, JAAR_END).trim();
		String middel = rec.substring(MIDDEL_START, MIDDEL_END).trim();
		if (validRequestParameters(bsn, belastingJaar, middel, reporter) &&
				batDao.existsBehandelvoorstel(Integer.parseInt(bsn), Integer.parseInt(belastingJaar), middel)) {
			sb.append("03");
		} else {
			sb.append("  ");
		}
	}

	boolean validRequestParameters(String bsn, String belastingJaar, String middel, ProgressReporter reporter) {
		StringBuilder sb = new StringBuilder();
		if (bsn == null || bsn.trim().isEmpty() || !StringUtils.isNumeric(bsn)) {
			sb.append("BSN invalid, ");
		}
		if (belastingJaar == null || belastingJaar.trim().isEmpty() || !StringUtils.isNumeric(belastingJaar)) {
			sb.append("Belastingjaar invalid, ");
		}
		if (middel == null || middel.trim().isEmpty()) {
			sb.append("Middel invalid, ");
		}
		if (sb.length() > 0) {
			sb.deleteCharAt(sb.length()-1);
			sb.deleteCharAt(sb.length()-1);
			reporter.error(sb.toString());
			return false;
		}
		return true;
	}

	@Override
	public int getAnswerRecordLength() {
		return ANSWER_RECORD_LENGTH;
	}

	@Override
	int getRequestRecordLength() {
		return REQUEST_RECORD_LENGTH;
	}
}
