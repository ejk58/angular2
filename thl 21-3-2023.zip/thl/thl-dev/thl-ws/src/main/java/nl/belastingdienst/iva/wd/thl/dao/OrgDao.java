package nl.belastingdienst.iva.wd.thl.dao;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lombok.extern.slf4j.Slf4j;

@Singleton
@Slf4j
public class OrgDao {

	private String currentSchema;

	@PersistenceContext(unitName = "iva-org-pu")
	private EntityManager em;

	private static final String DATE_FORMAT = "yyyy-MM-dd";
	private final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	public List<String> getOrgChangesSince(Date vanafDatum) {
		List<String> resultaat = new LinkedList<>();
		TempOrgData tempStorage = null;
		try {
			Query query = em.createNativeQuery("CALL "+getCurrentSchema()+".GET_MUT_KLANTGROEPKC(?1)");
			query.setParameter(1, sdf.format(vanafDatum));
			List<Object[]> orgChanges = query.getResultList();

			for(Object[] orgChange : orgChanges) {
				tempStorage = processOrgChange(resultaat, tempStorage, orgChange);
			}
			if (tempStorage != null) {
				resultaat.add(getFormattedResult(tempStorage.orgChange, tempStorage.isRecordWithEindDtSet));
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return resultaat;
	}

	private TempOrgData processOrgChange(List<String> resultaat, TempOrgData tempStorage, Object[] orgChange) {
		Timestamp endTs = getLatestTimestamp(orgChange[2], orgChange[4]);
		Timestamp startTs = getLatestTimestamp(orgChange[1], orgChange[3]);
		Timestamp latestTs = getLatestTimestamp(startTs, endTs);

		if (tempStorage == null) {
			// First record processing.
			tempStorage = new TempOrgData();
			fillTempStorage(tempStorage, orgChange, endTs != null, latestTs);
		} else if (tempStorage.orgChange[0].equals(orgChange[0])) {
			// Checking which of the 2 org records is the last.
			if (tempStorage.latestTs.before(latestTs) || (tempStorage.latestTs.equals(latestTs) && latestTs.equals(startTs))) {
				fillTempStorage(tempStorage, orgChange, endTs != null, latestTs);
			}
		} else {
			// add the data in tempStorage to the resultset and fill tempStorage with the new entity data
			resultaat.add(getFormattedResult(tempStorage.orgChange, tempStorage.isRecordWithEindDtSet));
			fillTempStorage(tempStorage, orgChange, endTs != null, latestTs);
		}
		return tempStorage;
	}

	private void fillTempStorage(TempOrgData tempStorage, Object[] orgChange, boolean endDateIsFilled, Timestamp latestTs) {
		tempStorage.orgChange = orgChange;
		tempStorage.latestTs = latestTs;
		tempStorage.isRecordWithEindDtSet = endDateIsFilled;
	}

	private String getFormattedResult(Object[] objs, boolean isRecordWithEindDtSet) {
		return String.format("%09d%05d%05d", objs[0],
				objs[5] == null || isRecordWithEindDtSet ? 0 : objs[5],
				objs[6] == null || isRecordWithEindDtSet ? 0 : objs[6]);
	}

	private Timestamp getLatestTimestamp(Object firstDt, Object secondDt) {
		Timestamp firstTs = (Timestamp) firstDt;
		Timestamp secondTs = (Timestamp) secondDt;
		return getLatestTimestamp(firstTs, secondTs);
	}
	private Timestamp getLatestTimestamp(Timestamp firstTs, Timestamp secondTs) {
		if (firstTs != null) {
			if (secondTs != null) {
				if (firstTs.before(secondTs)) {
					return secondTs;
				} else {
					return firstTs;
				}
			} else {
				return firstTs;
			}
		}
		return secondTs;
	}

	public long executeIsAliveCheck() {
		long start = System.currentTimeMillis();
		try {
			Query query = em.createNativeQuery("select * from KLANTGROEP_ENTITEIT fetch first 2 rows only");
			query.getResultList();
		} catch (Exception e) {
			return -1;
		}
		return System.currentTimeMillis() - start;
	}

	private String getCurrentSchema() {
		if (currentSchema == null) {
			Query query = em.createNativeQuery("values current schema");
			currentSchema = (String) query.getSingleResult();
			log.debug("Current schema is {}", currentSchema);
		}
		return currentSchema;
	}
}
class TempOrgData {
	boolean isRecordWithEindDtSet;
	Timestamp latestTs;
	Object[] orgChange;
}