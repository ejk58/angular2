package nl.belastingdienst.iva.wd.thl.apikey;

import nl.belastingdienst.iva.common.apiKey.AbstractApiKeyService;
import nl.belastingdienst.iva.common.apiKey.ApiKeyService;

import javax.ejb.Singleton;
import javax.enterprise.inject.Default;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Singleton
@Default
public class ApiKeyServiceImpl extends AbstractApiKeyService implements ApiKeyService {

	@PersistenceContext(unitName = "iva-thl-pu")
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return this.entityManager;
	}

}
