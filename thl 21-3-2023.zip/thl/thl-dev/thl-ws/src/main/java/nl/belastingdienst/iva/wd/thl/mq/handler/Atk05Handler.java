package nl.belastingdienst.iva.wd.thl.mq.handler;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import nl.belastingdienst.iva.wd.thl.dao.OrgDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

/**
 * Deze handler krijgt een timestamp en moet alle veranderen in ORG terug leveren
 */
public class Atk05Handler extends AbstractHandler{

	static final int REQUEST_RECORD_LENGTH = 14;
	static final int ANSWER_RECORD_LENGTH = 19;

	@Inject
	private OrgDao orgDao;

	@Override
	public List<String> getData(List<String> records, ProgressReporter reporter, String lineEnding) {
		List<String> result = new LinkedList<>();
		StringBuilder sb = new StringBuilder();
		addVoorloopRecord(sb, records.get(0), reporter);
		sb.append(lineEnding);

		Date vanafDatum = getTimestampFromMessage(records.get(1));
		if (vanafDatum == null) {
			reporter.error("Invalid date format: '" + records.get(1) + "'.");
			setInvalidDateFormatErrorCode(sb);
			result.add(sb.toString());
		} else {
			List<String> orgChanges = orgDao.getOrgChangesSince(vanafDatum);
			result.add(processData(orgChanges, sb, reporter, lineEnding));
		}
		return result;
	}

	private String processData(List<String> orgChanges, StringBuilder sb, ProgressReporter reporter, String lineEnding) {
		int recCount = 0;
		for (String rec : orgChanges) {
			sb.append(rec).append(lineEnding);
			recCount++;
		}
		reporter.numberOfResponseRecords(recCount);
		return sb.toString();
	}

	@Override
	int getAnswerRecordLength() {
		return ANSWER_RECORD_LENGTH;
	}
	@Override
	int getRequestRecordLength() {
		return REQUEST_RECORD_LENGTH;
	}

	@Override
	void setInvalidDateFormatErrorCode(StringBuilder sb) {
		sb.setCharAt(9, '8');
		sb.setCharAt(10, '0');
	}

}


