package nl.belastingdienst.iva.wd.thl.webservice;

import io.swagger.annotations.*;
import nl.belastingdienst.iva.common.errorhandling.UserError;
import nl.belastingdienst.iva.wd.thl.mq.MessageResponse;
import nl.belastingdienst.iva.wd.thl.utls.HttpResponseHelper;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Api()
@Path("/mq/v1")
@SwaggerDefinition(info = @Info(title = "RestMqService", version = "V1", description = "REST MQ Service",
		contact = @Contact(name = "Webdevelopment Team", url = "https://devtools.belastingdienst.nl/confluence/display/CM/CoE+Webdevelopment+Home")),
		consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON, schemes = {
		SwaggerDefinition.Scheme.HTTPS, SwaggerDefinition.Scheme.HTTP }, tags = {
			@Tag(name = RestMqService.TAG_EVENT_SUPPORT, description = "Methodes voor de TGL input queue"),
			@Tag(name = RestMqService.TAG_RESPONSE_SUPPORT, description = "Methodes voor de response queue"),
			@Tag(name = RestMqService.TAG_ERROR_SUPPORT, description = "Methodes voor de error queue"),
		})
public class RestMqService {
	public static final String TAG_EVENT_SUPPORT = "Event messages";
	public static final String TAG_RESPONSE_SUPPORT = "Response messages";
	public static final String TAG_ERROR_SUPPORT = "Error messages";

	@Inject
	private MqService mqService;

	@GET()
	@Path("/tglEventQueue/count")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Count the number of tgl messages in the input queue", response = MessageResponse.class, tags = TAG_EVENT_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission"),
			@ApiResponse(code = 415, message = "Unsupported Media Type")
	})
	public Response getTglEventQueueCount(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey) {
		try {
			MessageResponse response = mqService.getTglEventsCount(apiKey);
			return Response.ok(response).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@GET()
	@Path("/tglEventQueue/{messageId}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Get MQ message from the tgl events input queue by it's messageId", response = MessageResponse.class, tags = TAG_EVENT_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"), @ApiResponse(code = 403, message = "No permission") })
	public Response getTglEvent(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey,
			@ApiParam(value = "The id of the mqMessage", example = "ID:414d5120514f4c434d515530314f31205a00662e10eeeb24") @PathParam("messageId") String messageId) {
		try {
			return Response.ok(mqService.getTglEvent(apiKey, messageId)).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@POST()
	@Path("/tglEventQueue/{correlationId}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Put tglEvent request on the queue", tags = TAG_EVENT_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission"),
			@ApiResponse(code = 415, message = "Unsupported Media Type") })
	public Response addTglEventToMq(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey,
			@ApiParam(value = "The correlationId for the event", example = "3aa3398d-dce7-48b8-807e-1b010d4a14f4") @PathParam("correlationId") String correlationId,
			@ApiParam(value = "TglEvent") String message) {
		try {
			mqService.mqPlaceTglEventOnQueue(apiKey, correlationId, message);
			return Response.noContent().build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@PUT()
	@Path("/tglEventQueue/clear")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Remove all tglEvents from the input queue", response = MessageResponse.class, tags = TAG_EVENT_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission") })
	public Response clearAllTglEvents(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey) {
		try {
			return Response.ok(mqService.clearAllTglEvents(apiKey)).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@GET()
	@Path("/errorQueue/count")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Count the number of messages in the error queue", response = MessageResponse.class, tags = TAG_ERROR_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission"),
			@ApiResponse(code = 415, message = "Unsupported Media Type")
	})
	public Response getErrorQueueMessageCount(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey) {
		try {
			MessageResponse response = mqService.getErrorQueueMessageCount(apiKey);
			return Response.ok(response).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@GET()
	@Path("/errorQueue/{messageId}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Get MQ message from the error queue by it's messageId", response = MessageResponse.class, tags = TAG_ERROR_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"), @ApiResponse(code = 403, message = "No permission") })
	public Response getErrorQueueMessage(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey,
			@ApiParam(value = "The id of the mqMessage", example = "ID:414d5120514f4c434d515530314f31205a00662e10eeeb24") @PathParam("messageId") String messageId) {
		try {
			return Response.ok(mqService.getErrorMessage(apiKey, messageId)).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@POST()
	@Path("/errorQueue")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Put error message on the queue", tags = TAG_ERROR_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission"),
			@ApiResponse(code = 415, message = "Unsupported Media Type") })
	public Response addErrorMessageToMq(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey,
			@ApiParam(value = "ErrorMessage") String message) {
		try {
			mqService.mqPlaceErrorMessageOnQueue(apiKey, message);
			return Response.noContent().build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@PUT()
	@Path("/errorQueue/clear")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Remove all messages from the error queue", response = MessageResponse.class, tags = TAG_ERROR_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission") })
	public Response clearErrorQueue(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey) {
		try {
			return Response.ok(mqService.clearErrorQueue(apiKey)).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@DELETE()
	@Path("/errorQueue/{messageId}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Delete MQ message from the error queue by it's messageId", response = MessageResponse.class, tags = TAG_ERROR_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"), @ApiResponse(code = 403, message = "No permission") })
	public Response removeErrorQueueMessage(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey,
			@ApiParam(value = "The id of the mqMessage", example = "ID:414d5120514f4c434d515530314f31205a00662e10eeeb24") @PathParam("messageId") String messageId) {
		try {
			return Response.ok(mqService.removeErrorMessage(apiKey, messageId)).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@GET()
	@Path("/responseQueue/count")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Count the number of response messages in the output queue", response = MessageResponse.class, tags = TAG_RESPONSE_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission"),
			@ApiResponse(code = 415, message = "Unsupported Media Type")
	})
	public Response getResponseMessageCount(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey) {
		try {
			MessageResponse response = mqService.getResponseMessageCount(apiKey);
			return Response.ok(response).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@GET()
	@Path("/responseQueue/{messageId}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Get response message from the ouptu queue by it's messageId", response = MessageResponse.class, tags = TAG_RESPONSE_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"), @ApiResponse(code = 403, message = "No permission") })
	public Response getResponseMessage(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey,
			@ApiParam(value = "The id of the mqMessage", example = "ID:414d5120514f4c434d515530314f31205a00662e10eeeb24") @PathParam("messageId") String messageId) {
		try {
			return Response.ok(mqService.getResponseMessage(apiKey, messageId)).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	@PUT()
	@Path("/responseQueue/clear")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Remove all response messages from the output queue", response = MessageResponse.class, tags = TAG_RESPONSE_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission") })
	public Response clearResponseMessages(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey) {
		try {
			return Response.ok(mqService.clearResponseMessages(apiKey)).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}
	@POST()
	@Path("/responseQueue")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Put response on the response queue", tags = TAG_RESPONSE_SUPPORT)
	@ApiResponses(value = {
			@ApiResponse(code = 204, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 401, message = "Not authorized"),
			@ApiResponse(code = 403, message = "No permission"),
			@ApiResponse(code = 415, message = "Unsupported Media Type") })
	public Response addResponseToMq(
			@ApiParam(value = "The supplied API Key", example = "F7CFD8DC42261C66") @HeaderParam("x-api-key") String apiKey,
			@ApiParam(value = "Response") String message) {
		try {
			mqService.mqPlaceResponseOnQueue(apiKey, message);
			return Response.noContent().build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

}
