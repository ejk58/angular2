package nl.belastingdienst.iva.wd.thl.utls;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MessageCreationTool {

    public static String spaces(int number) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < number; i++) {
            sb.append(" ");
        }
        return sb.toString();
    }

    public static String numbers(int number) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < number; i++) {
            String num = String.format("%d", ((i + 1) % 10));
            sb.append(num);
        }
        return sb.toString();
    }

    public static String zeroFiller(int amount) {
        String formatString = "%"+amount+"s";
        return String.format(formatString, "0").replace(" ","0");
    }

    public static String stringFiller(String text, int amount, boolean putFillerLeft) {
        if (!putFillerLeft) {
            amount *= -1;
        }
        String formatString = "%"+amount+"s";
        return String.format(formatString, text);
    }

    public static String stringFiller(String text, int amount) {
        return stringFiller(text, amount, true);
    }
}
