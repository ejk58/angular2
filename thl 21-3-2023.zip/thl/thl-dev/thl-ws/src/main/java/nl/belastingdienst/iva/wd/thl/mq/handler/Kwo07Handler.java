/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: Kwo07Handler.java
 *             Auteur: duisr01
 *    Creatietijdstip: 9-9-2021 09:53
 *          Copyright: (c) 2021 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.wd.thl.mq.handler;

import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

public class Kwo07Handler extends AbstractHandler {

	static final int REQUEST_RECORD_LENGTH = 9;
	static final int ANSWER_RECORD_LENGTH = 19;

	@Inject
	private BatDao batdao;

	@Override
	public List<String> getData(List<String> records, ProgressReporter reporter, String lineEnding) {
		List<StringBuilder> result = new LinkedList<>();
		StringBuilder sb = new StringBuilder();
		addVoorloopRecord(sb, records.get(0), reporter, 1);
		sb.append(lineEnding);

		List<String> batChanges = batdao.getKwaliteitsbeoordelingenLast6YearsForKwo07();
		processData(batChanges, result, sb, reporter, records.get(0), lineEnding);
		return resultWithMaxVolgnummers(result);
	}

	@Override
	void setErrorCodeToZero(StringBuilder sb) {
		setErrorCodeToZero(sb, 15, 16);
	}

	@Override
	int getAnswerRecordLength() {
		return ANSWER_RECORD_LENGTH;
	}

	@Override
	int getRequestRecordLength() {
		return REQUEST_RECORD_LENGTH;
	}
}
