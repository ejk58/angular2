package nl.belastingdienst.iva.wd.thl.mq;

import lombok.*;

/**
 * This class is used to store messages with error on the error queue together with the errors found.
 * 
 * @author weera09
 */
@Data
public class ErrorMessage {

	private String textMessageReceived;
	private ExceptionInfo exceptionInfo;
	private String timestamp;
	private String id;

}
