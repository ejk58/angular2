package nl.belastingdienst.iva.wd.thl.mq;

import javax.ejb.ApplicationException;

@ApplicationException
public class IllegalMessageType extends RuntimeException{
    private static final long serialVersionUID = 8898690984942900514L;

    public IllegalMessageType(String message) {
        super(message);
    }
}
