package nl.belastingdienst.iva.wd.thl.utls;

import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import javax.ejb.EJBException;
import javax.persistence.EntityExistsException;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

import nl.belastingdienst.iva.common.apiKey.AuthenticationException;
import nl.belastingdienst.iva.common.errorhandling.ConfigurationException;
import nl.belastingdienst.iva.common.errorhandling.InterceptedException;
import nl.belastingdienst.iva.common.errorhandling.UserContext;
import nl.belastingdienst.iva.common.errorhandling.UserError;
import nl.belastingdienst.iva.common.errorhandling.UserErrorException;
import nl.belastingdienst.iva.common.errorhandling.ValidationException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HttpResponseHelper {

	public static final Marker confidentialMarker = MarkerFactory.getMarker("Confidential");

	private HttpResponseHelper() {
		// private constructor to prevent instantiation
	}

	public static Response handleException(Exception e) {
		e = removeEjbExceptions(e);

		if (e instanceof AuthenticationException) {
			Status status = ((AuthenticationException) e).getStatus();
			String statusName = status.name();
			String method = ((AuthenticationException) e).getMethod();
			String application = ((AuthenticationException) e).getApplication();
			log.warn("Authentication Error. Status: {} for {} using {}", statusName, application, method);
			return Response.status(status).build();
		}

		if (!(e instanceof InterceptedException)) {
			return handleNotInterceptedException(e);
		}

		InterceptedException ie = (InterceptedException) e;
		UserContext ctx = ie.getContext();
		InterceptedException.Type type = ie.getType();
		if (type == InterceptedException.Type.WEB) {
			log.error("Upstream error {} : {}", ie.getStatusCode(), ctx);
			return Response.status(502).build();
		} else if (type == InterceptedException.Type.EXCEPTION) {
			Response response = handleCaughtException(e, ctx);
			if (response != null) {
				return response;
			}
		}
		log.error("Internal server error: {}", ctx, e);
		return Response.serverError().build();
	}

	private static Exception removeEjbExceptions(Exception e) {
		while (e != null) {
			if (e instanceof EJBException) {
				e = ((EJBException) e).getCausedByException();
			} else {
				break;
			}
		}
		return e;
	}

	private static Response handleNotInterceptedException(Exception e) {
		// check for specific persistence exceptions (in some timing situations not intercepted)
		if (isConflict(e)) {
			return Response.status(Status.CONFLICT).type(MediaType.APPLICATION_JSON_TYPE).build();
		}
		log.error("Internal server error (not intercepted)", e);
		return Response.serverError().build();
	}

	private static Response handleCaughtException(Exception e, UserContext ctx) {
		Exception ee = removeEjbExceptions((Exception) e.getCause());
		if (ee instanceof ValidationException) {
			return createResponseFromValidationException(ctx, (ValidationException) ee);
		} else if (ee instanceof ConfigurationException) {

			UserError error = new UserError(3000);
			error.setUserMessage("Validatie levert fouten op");
			error.addParameter("Text", ee.getMessage());
			error.addContext(ctx);
			logUserError(error);
			return Response.status(Status.BAD_REQUEST).entity(error).type(MediaType.APPLICATION_JSON_TYPE).build();
		} else if (ee instanceof UserErrorException) {
			UserError error = ((UserErrorException) ee).getUserError();
			error.addContext(ctx);
			logUserError(error);
			return Response.status(Status.BAD_REQUEST).entity(error).type(MediaType.APPLICATION_JSON_TYPE).build();
		} else if (ee instanceof PersistenceException && isConflict(ee)) {
			return Response.status(Status.CONFLICT).type(MediaType.APPLICATION_JSON_TYPE).build();
		}
		return null;
	}

	private static boolean isConflict(Exception e) {
		Optional<Throwable> rootCause = Stream.iterate(e, Throwable::getCause).filter(element -> element.getCause() == null)
				.findFirst();
		boolean isConflict = false;
		Throwable tempThrowable = e;
		while (tempThrowable != null) {
			if (tempThrowable instanceof OptimisticLockException || tempThrowable instanceof EntityExistsException) {
				isConflict = true;
				break;
			}
			tempThrowable = tempThrowable.getCause();
		}
		if (isConflict && rootCause.isPresent()) {
			log.error(rootCause.get().getMessage());
			return true;
		}
		return false;
	}

	private static void logUserError(UserError error) {
		String uuid = UUID.randomUUID().toString();
		log.error(confidentialMarker, "error_log_id={}, {}", uuid, error);
		log.error("User error occured with error_log_id={}", uuid);
	}

	private static Response createResponseFromValidationException(UserContext ctx, ValidationException ee) {
		UserError error = new UserError(2000);
		error.setUserMessage("Validatie levert fouten op");
		switch (ee.getType()) {
		case VIOLATIONS:
			error.addViolations(ee.getViolations());
			break;
		case PERTYPE:
			error.addViolations(ee.getViolationMap());
			break;
		default:
			error.addParameter("error", ee.getMessage());
		}
		error.addContext(ctx);
		logUserError(error);
		return Response.status(Status.BAD_REQUEST).entity(error).type(MediaType.APPLICATION_JSON_TYPE).build();
	}

	public static CacheControl noCache() {
		CacheControl cacheControl = new CacheControl();
		cacheControl.setNoCache(true);
		return cacheControl;
	}
}
