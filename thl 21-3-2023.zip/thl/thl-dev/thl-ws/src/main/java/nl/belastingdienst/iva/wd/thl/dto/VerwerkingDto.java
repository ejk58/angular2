package nl.belastingdienst.iva.wd.thl.dto;

import java.util.Date;
import java.util.List;

import nl.belastingdienst.iva.wd.thl.domain.Problem;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class VerwerkingDto {
    Long id;
    String correlationId;
    Date start;
    Date einde;
    String type;
    Integer aantalRequestRecords;
    Integer aantalResponseRecords;
    List<Problem> problems;
}
