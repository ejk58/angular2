package nl.belastingdienst.iva.wd.thl.webservice;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import nl.belastingdienst.iva.common.errorhandling.UserError;
import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.dao.OrgDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.utls.HttpResponseHelper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Contact;
import io.swagger.annotations.Info;
import io.swagger.annotations.SwaggerDefinition;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Api()
@Path("/isAlive")
@SwaggerDefinition(info = @Info(title = "RestIsAliveService", version = "V1", description = "REST IsAlive Service",
		contact = @Contact(name = "Webdevelopment Team", url = "https://devtools.belastingdienst.nl/confluence/display/CM/CoE+Webdevelopment+Home")),
		consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON, schemes = {
		SwaggerDefinition.Scheme.HTTPS, SwaggerDefinition.Scheme.HTTP })
public class RestIsAliveService {

	@Inject
	private BatDao batDao;

	@Inject
	private OrgDao orgDao;

	@Inject
	private ThlDao thlDao;

	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Is alive check", response = IsAliveResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request", response = UserError.class),
			@ApiResponse(code = 415, message = "Unsupported Media Type")
	})
	public Response checkIsAlive() {
		try {
			IsAliveResponse response = new IsAliveResponse();
			response.setTimeThl(thlDao.executeIsAliveCheck());
			response.setTimeBat(batDao.executeIsAliveCheck());
			response.setTimeOrg(orgDao.executeIsAliveCheck());
			response.setServerName(getServerName());
			response.setAlive(true);
			Properties props = new Properties();
			props.load(this.getClass().getClassLoader().getResourceAsStream("thl.properties"));
			response.setVersion(props.getProperty("version"));
			response.setBuildNumber(props.getProperty("buildnumber"));
			return Response.ok(response).cacheControl(HttpResponseHelper.noCache()).build();
		} catch (Exception e) {
			return HttpResponseHelper.handleException(e);
		}
	}

	private String getServerName() {
		try {
			return InetAddress.getLocalHost().toString();
		} catch (UnknownHostException e) {
			log.warn("Unable to retrieve server hostname!", e);
			return "Onbekend";
		}
	}
}
@Getter
@Setter
@ToString
class IsAliveResponse {
	public static final String BAT_DB = "BAT DB";
	public static final String THL_DB = "THL DB";
	public static final String ORG_DB = "ORG DB";
	private String serverName;
	private boolean alive = false;
	private String version;
	private String buildNumber;
	private Map<String,Long> components = new HashMap<>();

	public void setTimeBat(Long timeBat) {
		components.put(BAT_DB, timeBat);
		setTimeTotal();
	}
	public void setTimeThl(Long timeThl) {
		components.put(THL_DB, timeThl);
		setTimeTotal();
	}
	public void setTimeOrg(Long timeOrg) {
		components.put(ORG_DB, timeOrg);
		setTimeTotal();
	}
	public void setTimeTotal() {
		if (components.containsKey(THL_DB) && components.containsKey(BAT_DB) && components.containsKey(ORG_DB)) {
			components.put("TOTAL", components.get(THL_DB) + components.get(BAT_DB) + components.get(ORG_DB));
		}
	}
}
