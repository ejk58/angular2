package nl.belastingdienst.iva.wd.thl.mq.handler;

import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.spaces;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

public abstract class AbstractHandler {

	@Resource(name = "var/maxNumberOfRecordsPerMessageRef")
	private String maxNumberOfRecordsPerMessageStr;

	private Integer maxNumberOfRecordsPerMessage = null;
	private static final String TIMESTAMP_FORMAT = "yyyyMMddHHmmss";

	public abstract List<String> getData(List<String> records, ProgressReporter reporter, String lineEnding);
	/**
	 * @return the maximum byte length of an answer record (excl. line endings)
	 */
	abstract int getAnswerRecordLength();
	/**
	 * @return the maximum byte length of a request record (excl. line endings)
	 */
	abstract int getRequestRecordLength();

	public int getMaxNumberOfRecordPerMessage(){
		if (maxNumberOfRecordsPerMessage == null) {
			maxNumberOfRecordsPerMessage = Integer.parseInt(maxNumberOfRecordsPerMessageStr);
		}
		return maxNumberOfRecordsPerMessage;
	}

	void makeAnswerRecordLengthCorrect(StringBuilder sb) {
		if (sb.length() > getAnswerRecordLength()) {
			sb.setLength(getAnswerRecordLength());
		}
		if (sb.length() < getAnswerRecordLength()) {
			sb.append(spaces(getAnswerRecordLength() - sb.length()));
		}
	}

	protected void processData(List<String> changes, List<StringBuilder> result, StringBuilder sb, ProgressReporter reporter,
			String voorloopRecord, String lineEnding) {
		int recCount = 0;
		int recordGroups = 1;
		for (String rec : changes) {
			if (recCount != 0 && (recCount % getMaxNumberOfRecordPerMessage()) == 0) {
				result.add(sb);
				recordGroups += 1;
				sb = new StringBuilder();
				addVoorloopRecord(sb, voorloopRecord, reporter, recordGroups);
				sb.append(lineEnding);
			}
			sb.append(rec).append(lineEnding);
			recCount++;
		}
		result.add(sb);
		reporter.numberOfResponseRecords(recCount);
	}

	void setErrorCodeToZero(StringBuilder sb) {
		setErrorCodeToZero(sb, 9, 10);
	}

	void setErrorCodeToZero(StringBuilder sb, int first, int second) {
		sb.setCharAt(first, '0');
		sb.setCharAt(second, '0');
	}
	void setInvalidDateFormatErrorCode(StringBuilder sb) {
		sb.setCharAt(15, '8');
		sb.setCharAt(16, '0');
	}

	void addVoorloopRecord(StringBuilder sb, String rec,
						   ProgressReporter reporter, Integer volgnummer ) {
		checkRecordLength(rec, reporter);

		sb.append(rec);

		makeAnswerRecordLengthCorrect(sb);
		setErrorCodeToZero(sb);
		setVolgnummer(sb, volgnummer);
	}

	void setVolgnummer(StringBuilder sb, Integer volgnummer) {
		if (volgnummer != null) {
			setVolgnummer(volgnummer, sb);
		}
	}

	private void checkRecordLength(String rec, ProgressReporter reporter) {
		if (rec.length() != getRequestRecordLength()) {
			reporter.error(String.format("VoorloopRecord has incorrect length (%d).", rec.length()));
		}
	}

	protected void setVolgnummer(int volgnummer, StringBuilder sb) {
		sb.replace(9,12, String.format("%03d", volgnummer));
	}

	public void setMaxVolgnummer(int maxVolgnummer, StringBuilder sb) {
		sb.replace(12,15, String.format("%03d", maxVolgnummer));
	}

	protected List<String> resultWithMaxVolgnummers(List<StringBuilder> result) {
		final int maxLength = result.size();
		return result.stream().map(sb -> {
			setMaxVolgnummer(maxLength, sb);
			return sb.toString();
		}).collect(Collectors.toList());
	}

	void addVoorloopRecord(StringBuilder sb, String rec, ProgressReporter reporter) {
		addVoorloopRecord(sb, rec, reporter, null);
	}

	Date getTimestampFromMessage(String record) {
		String recordTemp = record.trim();
		if (recordTemp.length() < TIMESTAMP_FORMAT.length() ||
				recordTemp.length() > TIMESTAMP_FORMAT.length()) {
			return null;
		}
		Pattern pattern = Pattern.compile("^[0-9]+$");
		Matcher matcher = pattern.matcher(recordTemp);
		if (! matcher.find()) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(TIMESTAMP_FORMAT);
		try {
			Date dateFound = sdf.parse(recordTemp);
			if (recordTemp.equals(sdf.format(dateFound)))
				return dateFound;
		} catch (ParseException e) {
			return null;
		}
		return null;
	}

}
