package nl.belastingdienst.iva.wd.thl.webservice;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/rest")
public class RestApplication extends Application {
    // Door geen resources de declareren worden alle resources automatisch geinjecteerd.
}
