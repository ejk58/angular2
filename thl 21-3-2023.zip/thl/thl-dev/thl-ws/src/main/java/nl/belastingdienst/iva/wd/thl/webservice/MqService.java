package nl.belastingdienst.iva.wd.thl.webservice;

import nl.belastingdienst.iva.common.apiKey.ApiKeyInterceptor;
import nl.belastingdienst.iva.wd.thl.mq.MessageResponse;
import nl.belastingdienst.iva.wd.thl.mq.gateway.MqGateway;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

@Stateless
@Interceptors({ ApiKeyInterceptor.class })
public class MqService {

	@Inject
	MqGateway mqGateway;

	public void mqPlaceTglEventOnQueue(String apiKey, String correlationId, String message) {
		mqGateway.sendEvent(correlationId, message);
	}
	public MessageResponse getErrorQueueMessageCount(String apiKey) {
		return mqGateway.getErrorMessageCount();
	}

	public MessageResponse getErrorMessage(String apiKey, String messageId) {
		return mqGateway.getErrorMessage(messageId);
	}

	public void mqPlaceErrorMessageOnQueue(String apiKey, String message) {
		mqGateway.placeErrorMessageOnQueue(message);
	}
	public MessageResponse removeErrorMessage(String apiKey, String messageId) {
		return mqGateway.removeErrorMessage(messageId);
	}

	public MessageResponse clearErrorQueue(String apiKey) {
		return mqGateway.clearErrorQueue();
	}

	public MessageResponse getTglEventsCount(String apiKey) {
		return mqGateway.getTglEventCount();
	}

	public MessageResponse getTglEvent(String apiKey, String messageId) {
		return mqGateway.getTglEvent((messageId));
	}

	public MessageResponse clearAllTglEvents(String apiKey) {
		return mqGateway.clearTglEventQueue();
	}

	public MessageResponse getResponseMessageCount(String apiKey) {
		return mqGateway.getResponseEventsCount();
	}

	public MessageResponse getResponseMessage(String apiKey, String messageId) {
		return mqGateway.getResponseEvent(messageId);
	}

	public MessageResponse clearResponseMessages(String apiKey) {
		return mqGateway.clearResponseEventQueue();
	}

    public void mqPlaceResponseOnQueue(String apiKey, String message) { mqGateway.sendResponse(message); }
}
