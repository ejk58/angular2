import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.IOException;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;
import lombok.ToString;

public class SentMessage {

    private static final String apiKey = "U9T7RR5C2XX5QVIP";
    private static final String URL_PREFIX = "https://iva-thl.str11.acc.belastingdienst.nl/thl/rest/mq/v1";

//    private static final String apiKey = "F9NI3P1XYOTODS8C";
//    private static final String URL_PREFIX = "https://iva-thl.str11.tst.belastingdienst.nl/thl/rest/mq/v1";
//    private static final String URL_PREFIX = "https://iva-thl.str11.ont.belastingdienst.nl/thl/rest/mq/v1";
//    private static final String URL_PREFIX = "http://localhost:9080/iva-thl/rest/mq/v1";
    private static final String postTglEventUrl = URL_PREFIX + "/tglEventQueue/correllationId";
    private static final String getResponseUrlPrefix = URL_PREFIX + "/response/ID%3A";
//
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    @Disabled
    public void sentSimpleMessage() throws IOException {
        String body =
                "TGL-ABS01       \n" +
                "1234567892019ABC\n";
        sentMessage(body);
    }

    @Test
    @Disabled
    public void checkNumberStartingWithZero() {
        String numStr = "012345679";
        assertEquals(12345679, Integer.parseInt(numStr));
    }

    @Test
    @Disabled
    public void sentMessageWith10000Records() throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("TGL-ABS01       \n");
        String[] middelen = new String[]{"abc", "bce", "cef", "efg", "fgh"};
        int bsn = 123456789;
        for(int i=0; i< 400; i++) {
            for(int bj = 2016; bj < 2021; bj++) {
                for(String middel : middelen) {
                    sb.append(bsn + i);
                    sb.append(bj);
                    sb.append(middel);
                    sb.append("\n");
                }
            }
        }
        sentMessage(sb.toString());
    }
    @Test
    public void sentMessageWith100_000Records() throws IOException {
        int cnt = 0;
        StringBuilder sb = new StringBuilder();
        sb.append("TGL-ABS01       \n");
        String[] middelen = new String[]{"abc", "bce", "cef", "efg", "fgh"};
        int bsn = 123456789;
        for(int i=0; i< 4000; i++) {
            for(int bj = 2016; bj < 2021; bj++) {
                for(String middel : middelen) {
                    sb.append(bsn + i);
                    sb.append(bj);
                    sb.append(middel);
                    sb.append("\n");
                    cnt++;
                }
            }
        }
        System.out.println("Sending " + cnt + " records in 1 bericht aan " + URL_PREFIX);
        sentMessage(sb.toString());
    }

    private void sentMessage(String message) throws IOException {
        try (final CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpPost post = new HttpPost(postTglEventUrl);
            post.addHeader("accept", "application/json");
            post.addHeader("x-api-key", apiKey);
            post.setEntity(new StringEntity(message));
            CloseableHttpResponse response = httpclient.execute(post);
            assertEquals(204, response.getStatusLine().getStatusCode());
        }
    }

    @Test
    @Disabled
    public void getMessageFromQueue() throws IOException {
        String messageId = "134ddbe83f21bd5ccaf5ca44110a134f0000000000000001";
        String url = getResponseUrlPrefix + messageId;
        System.out.println(url);
        CloseableHttpResponse response;
        try (final CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpGet post = new HttpGet(url);
            post.addHeader("accept", "application/json");
            post.addHeader("x-api-key", apiKey);
            response = httpclient.execute(post);
            assertNotNull(response);
            assertEquals(200, response.getStatusLine().getStatusCode());
            HttpEntity entity = response.getEntity();
            assertNotNull(entity);
            MyJmsMessage message = objectMapper.readValue(entity.getContent(), MyJmsMessage.class);
            assertNotNull(message);
            System.out.println(message);
            assertNotNull(message.getTextMessageText());
            String[] recs = message.getTextMessageText().split("\n");
            assertEquals(10001, recs.length);
            for(int i = 0; i < 50; i++) {
                System.out.printf("--%s--%n", recs[i]);
            }
        }
    }
}

@Data
@ToString
class MyJmsMessage {
    private long messageCount;
    private String messageIds;
    private String jmsCorrelationID;
    private String jmsDestination;
    private String jmsMessageID;
    private String jmsReplyTo;
    private long jmsPriority;
    private boolean jmsRedelivered;
    private long jmsTimestamp;
    private String jmsType;
    private String textMessageText;
    private String errorMessage;
    private String action;
    private String exceptionInformation;
    private Properties properties;
//        "JMSXDeliveryCount": 1,
//                "JMSXUserID": "",
//                "JMS_IBM_System_MessageID": "9F841BBBDD912780_15500008",
//                "JMSXAppID": "WebSphere Embedded Messaging"
//    }
}