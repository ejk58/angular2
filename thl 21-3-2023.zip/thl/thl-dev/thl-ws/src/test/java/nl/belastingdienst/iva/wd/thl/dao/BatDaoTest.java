package nl.belastingdienst.iva.wd.thl.dao;

import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.spaces;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.mq.handler.Atk04Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Rsa03Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Vpb02Handler;

@ExtendWith(MockitoExtension.class)
class BatDaoTest {

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");

    @InjectMocks
    private final BatDao batDao = new BatDao();
    @Mock
    EntityManager em;
    @Mock
    Query query;

    Date vanafDate;
    Object[] singleRow;

    @BeforeEach
    public void setup() throws ParseException {
        vanafDate = new SimpleDateFormat("yyyyMMddHHmmss").parse("20210101000000");
        singleRow = new Object[]{ 123456789, 2016, "03"
                , new Timestamp(sdf.parse("2021-01-02 03:04:05.0").getTime())
                , new Timestamp(sdf.parse("2021-01-21 00:00:00.0").getTime())
                , new Timestamp(sdf.parse("2021-01-21 00:00:00.0").getTime())};
    }

    @Test
    public void batDaoBasicMessageWithAllCorrectlyFilledValueTest() {

        List<Object> mockData = Collections.singletonList(singleRow);
        doMockQueryAndGiveResultList(mockData);

        List<String> getChangesSinceFromBatDao = batDao.getVpbChangesSince(vanafDate);
        Vpb02Handler vpb02Handler = new Vpb02Handler();

        assertEquals(1, getChangesSinceFromBatDao.size());
        assertEquals("12345678920160320210121", getChangesSinceFromBatDao.get(0));
        assertEquals(vpb02Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(0).length());
    }

    @Test
    public void batDaoBasicMessageWithoutIngetrokkenAndWithoutGewijzigdValuesTest() {

        Object[] row = new Object[]{singleRow[0], singleRow[1], singleRow[2], singleRow[3], null, null};
        List<Object> mockData = Collections.singletonList(row);
        doMockQueryAndGiveResultList(mockData);

        List<String> getChangesSinceFromBatDao = batDao.getVpbChangesSince(vanafDate);
        Vpb02Handler vpb02Handler = new Vpb02Handler();

        assertEquals(1, getChangesSinceFromBatDao.size());
        assertEquals("12345678920160300000000", getChangesSinceFromBatDao.get(0));
        assertEquals(vpb02Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(0).length());
    }

    @Test
    public void batDaoTwoCorrectBasicMessagesTest() throws ParseException {

        Object[] singleRow2 = new Object[]{singleRow[0], singleRow[1], singleRow[2]
                , new Timestamp(sdf.parse("2021-02-02 00:00:00.0").getTime())
                , new Timestamp(sdf.parse("2021-02-20 00:00:00.0").getTime())
                , new Timestamp(sdf.parse("2021-01-21 00:00:00.0").getTime())};
        List<Object> mockData = Arrays.asList(singleRow, singleRow2);
        Date vanafDate = new SimpleDateFormat("yyyyMMdd").parse("20210101");

        when(em.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(mockData);
        List<String> getChangesSinceFromBatDao = batDao.getVpbChangesSince(vanafDate);
        Vpb02Handler vpb02Handler = new Vpb02Handler();
        System.out.println(getChangesSinceFromBatDao);
        assertEquals(2, getChangesSinceFromBatDao.size());
        assertEquals("12345678920160320210121", getChangesSinceFromBatDao.get(0));
        assertEquals("12345678920160320210121", getChangesSinceFromBatDao.get(1));
        assertEquals(vpb02Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(0).length());
        assertEquals(vpb02Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(1).length());
    }

    @Test
    public void batDaoBasicMessageWithIncorrectBSNRSINValueTest() {

        Object[] faultyBSNRSINsingleRow = new Object[]{ 12345678, singleRow[1], singleRow[2],
                singleRow[3], singleRow[4], singleRow[5]};

        List<Object> mockData = Collections.singletonList(faultyBSNRSINsingleRow);
        doMockQueryAndGiveResultList(mockData);

        List<String> getChangesSinceFromBatDao = batDao.getVpbChangesSince(vanafDate);
        Vpb02Handler vpb02Handler = new Vpb02Handler();

        assertEquals(1, getChangesSinceFromBatDao.size());
        assertEquals("01234567820160320210121", getChangesSinceFromBatDao.get(0));
        assertEquals(vpb02Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(0).length());
    }
    @Test
    public void batDaoForAtk04CheckIH2IBTransformation() {
        List<Object> mockData = new ArrayList<>();

        Object[] databaseResultWithVpbAndIH = new Object[]{ 12345678, 0, 2021, "VPB", "03", null, null};
        mockData.add(databaseResultWithVpbAndIH);
        databaseResultWithVpbAndIH = new Object[]{ 12345678, 0, 2021, "IB", "03", null, null};
        mockData.add(databaseResultWithVpbAndIH);
        doMockQueryAndGiveResultList(mockData);

        List<String> getChangesSinceFromBatDao = batDao.getChangesForAtk04(vanafDate);

        assertEquals(2, getChangesSinceFromBatDao.size());
        assertEquals("012345678002021VPB03        " + spaces(255), getChangesSinceFromBatDao.get(0));
        assertEquals("012345678002021IB 03        " + spaces(255), getChangesSinceFromBatDao.get(1));
        Atk04Handler atk04Handler = new Atk04Handler();
        assertEquals(atk04Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(0).length());
        assertEquals(atk04Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(1).length());
    }
    @Test
    public void batDaoForAtk04CheckTruncationOfLongToelichten() {
        List<Object> mockData = new ArrayList<>();

        Object[] databaseResultWithVpbAndIH = new Object[]{ 12345678, 0, 2021, "VPB", "03", null, "toelichting bij 01 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
        mockData.add(databaseResultWithVpbAndIH);
        databaseResultWithVpbAndIH = new Object[]{ 12345678, 0, 2021, "IB", "03", null, "toelichting bij 02 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
        mockData.add(databaseResultWithVpbAndIH);
        doMockQueryAndGiveResultList(mockData);

        List<String> getChangesSinceFromBatDao = batDao.getChangesForAtk04(vanafDate);

        assertEquals(2, getChangesSinceFromBatDao.size());
        assertEquals("012345678002021VPB03        toelichting bij 01 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABC", getChangesSinceFromBatDao.get(0));
        assertEquals("012345678002021IB 03        toelichting bij 02 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABC", getChangesSinceFromBatDao.get(1));
        Atk04Handler atk04Handler = new Atk04Handler();
        assertEquals(atk04Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(0).length());
        assertEquals(atk04Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(1).length());
    }

    @Test
    public void batDaoForRsa03CheckTruncationOfLongToelichten() {
        List<Object> mockData = new ArrayList<>();

        Object[] databaseResultWithVpb = new Object[]{ 12345678, 2021, "03", "toelichting bij 01 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
        mockData.add(databaseResultWithVpb);
        databaseResultWithVpb = new Object[]{ 12345678, 2021, "03", "toelichting bij 02 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
        mockData.add(databaseResultWithVpb);
        doMockQueryAndGiveResultList(mockData);

        List<String> getChangesSinceFromBatDao = batDao.getVpbChangesForRsaSince(vanafDate);

        assertEquals(2, getChangesSinceFromBatDao.size());
        assertEquals("012345678202103toelichting bij 01 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABC", getChangesSinceFromBatDao.get(0));
        assertEquals("012345678202103toelichting bij 02 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 abcdefghijklmnopqrstuvwxyz ABC", getChangesSinceFromBatDao.get(1));
        Rsa03Handler rsa03Handler = new Rsa03Handler();
        assertEquals(rsa03Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(0).length());
        assertEquals(rsa03Handler.getAnswerRecordLength(), getChangesSinceFromBatDao.get(1).length());
    }


    private void doMockQueryAndGiveResultList(List<Object> mockData) {
        when(em.createNativeQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(mockData);
    }
}