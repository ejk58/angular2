package nl.belastingdienst.iva.wd.thl.mq;

import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.numbers;
import static nl.belastingdienst.iva.wd.thl.utls.MessageCreationTool.spaces;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.domain.Problem;
import nl.belastingdienst.iva.wd.thl.mq.handler.Abs01Handler;
import nl.belastingdienst.iva.wd.thl.mq.handler.Vpb02Handler;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;
import nl.belastingdienst.iva.wd.thl.webservice.FeatureService;

@ExtendWith(MockitoExtension.class)
public class MessageHandlerTest {

	@Mock
	private FeatureService featureService;

	@Mock
	private Vpb02Handler vpb02Handler;

	@Mock
	private Abs01Handler abs01Handler;

	@Mock
	private ThlDao thlDao;

	private ProgressReporter reporter;

	@InjectMocks
	private final MessageHandler messageHandler = new MessageHandler();

	@BeforeEach
	public void setup() {
		reporter = new ProgressReporter(thlDao);
		messageHandler.initialize();
		when(featureService.isFeatureEnabled(anyString())).thenReturn(true);
	}

	@Test
	public void ABS01Test() {
		// ABS-BAT-Voorlooprecord
		// 001-007 	//HERKOMST	//C(007)	// Waarde “TGL-ABS
		// 008-009	//FUNCTIE	//N(002)	// Waarde 01
		// 010-016	//FILLER	//C(007)	// Waarde 7 spaces.
		// ABS BAT record
		// 001-009 BSNRSIN 		//N(009)
		// 010-013 BELASTINGJAAR//N(004)
		// 014-016 MIDDEL		//C(003)
		String resString = "TGL-ABS01         \n1234567892017ABC03\n";// dit is het verwachte resultaat.
		List<String> expectedResult = new LinkedList<>();
		expectedResult.add(resString);
		when(abs01Handler.getData(anyList(), any(ProgressReporter.class), anyString())).thenReturn(expectedResult);
		reporter.reportStart("CorrId");
		/*
		BAT-ABS-Voorlooprecord
		001-007 HERKOMST C(007) Waarde “TGL-ABS”
		008-009 FUNCTIE N(002) Waarde 01
		010-011 ERRORCODE C(002)
		012-018 FILLER C(001)
		BAT-ABS-Record
		001-009 BSNRSIN N (009)
		010-013 BELASTINGJAAR N (004)
		014-016 MIDDEL C(003)
		017-018 BEH_WIJZE C(002)
		*/
		List<String> result = messageHandler.processMessage("TGL-ABS01       \n1234567892017ABC\n", reporter);
		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals(resString, result.get(0));
	}
	@Test
	public void ABS01TestWithDifferentLineEnding() {
		String resultString = "TGL-ABS01         \r\n1234567892017ABC03\r\n";
		List<String> expectedResult = new LinkedList<>();
		expectedResult.add(resultString);
		when(abs01Handler.getData(anyList(), any(ProgressReporter.class), anyString())).thenReturn(expectedResult);
		reporter.reportStart("CorrId");
		List<String> result = messageHandler.processMessage("TGL-ABS01       \r\n1234567892017ABC\r\n", reporter);
		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals(resultString, result.get(0));
	}

	@Test
	public void Vpb02Test()
	{
		// VPB-BAT-Voorlooprecord
		// 001-007	//HERKOMST	//C(007)	// Waarde “TGL-VPB""
		// 008-009	//FUNCTIE	//N(002)	// Waarde 02
		// 010-014	//FILLER	//C(005)
		// VPB-BAT-Record
		// 001-014	//MUTATIEDATUM	//DATETIME		//EEJJMMDDHHMMSS
		String herkomst = "TGL-VPB";
		String functie = "02";
		String filler = spaces(5);
		String mutatiedatum = "20210102030405";
		String message = String.format("%s%s%s\n%s03\n", herkomst, functie, filler, mutatiedatum);
		String resString = "TGL-VPB02     \n2021010203040503\n";
		List<String> expectedResult = new LinkedList<>();
		expectedResult.add(message);
		when(vpb02Handler.getData(anyList(), any(ProgressReporter.class), anyString())).thenReturn(expectedResult);
		reporter.reportStart("CorrId");

		message = createValidVpb02Message(mutatiedatum);
		List<String> result = messageHandler.processMessage(message, reporter);

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals(resString, result.get(0));
	}

	private String createValidVpb02Message(String mutatiedatum) {
		/*
		VPB BAT voorlooprecord
		001-007 HERKOMST C(007) Waarde “TGL-VPB”
		008-009 FUNCTIE N(002)  Waarde 02
		010-012 VOLGNUMMER N(003)
		013-015 MAXVOLGNUMMER N(003)
		016-017 ERRORCODE C(002)
		018-037 FILLER C(020)

		BAT-VPB-Record
		001-009 BSNRSIN N (009)
		010-013 BELASTINGJAAR N (004)
		014-015 BEH_WIJZE C(002)
		016-029 MUTATIEDATUM DATETIME EEJJMMDDHHMMSS
		030-037 INGETROKKEN DATE EEJJMMDD
		*/
		//voorloop
		String herkomst = "TGL-VPB";
		String functie = "02";
		String volgnummer = numbers(3);
		String maxvolgnummer = numbers(3);
		String errorcode = spaces(2);
		String filler = spaces(20);
		//record
		String bsnrsin = numbers(9);
		String belastingjaar = "2021";
		String beh_wijze = "AB";
		String ingetrokken = "20210102";
		return String.format("%s%s%s%s%s%s\n%s%s%s%s%s\n",
				herkomst, functie, volgnummer, maxvolgnummer, errorcode, filler,
				bsnrsin, belastingjaar, beh_wijze, mutatiedatum, ingetrokken);
	}

	@Test
	public void testProcessMessage_ShouldAbort_WhenVpb02MessageHandlerIsDisabledThroughAssociatedFeatureToggle() {
		when(featureService.isFeatureEnabled(MessageHandler.FEATURE_PREFIX + MessageIdentifier.TGL_VPB02)).thenReturn(false);
		reporter.reportStart("CorrId");
		String message = createValidVpb02Message("20210102030405");

		List<String> result = messageHandler.processMessage(message, reporter);
		List<Problem> actualProblems = reporter.getProblems();

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals("TGL-VPB02993123                      \n1234567892021AB2021010203040520210102\n", result.get(0));

		assertNotNull(actualProblems);
		assertEquals(1, actualProblems.size());
		assertEquals("Bad batchId received: TGL-VPB02", actualProblems.get(0).getError());
	}
}
