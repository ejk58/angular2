package nl.belastingdienst.iva.wd.thl.mq.handler;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import nl.belastingdienst.iva.wd.thl.dao.BatDao;
import nl.belastingdienst.iva.wd.thl.dao.ThlDao;
import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

@ExtendWith(MockitoExtension.class)
public class Abs01HandlerTest {

	@Mock
	private BatDao batDao;

	@InjectMocks
	private final Abs01Handler mh = new Abs01Handler();

	@Mock
	private ThlDao thlDao;

	@Test
	public void checkValidParameters() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		assertTrue(mh.validRequestParameters("123", "2020", "ABC", reporter));
	}
	@Test
	public void checkInvalidBSN() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters("123A", "2020", "ABC", reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("BSN invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkEmptyBSN() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters("    ", "2020", "ABC", reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("BSN invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkInvalidBelastingjaar() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters(" 123 ".trim(), "20A0", "ABC", reporter));
		assertEquals(123, Integer.parseInt(" 123 ".trim()));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("Belastingjaar invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkEmptyBelastingjaar() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters("01234", "    ", "ABC", reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("Belastingjaar invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkEmptyMiddel() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters("01234", "2019", "   ", reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("Middel invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkNullBSN() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters(null, "2020", "ABC", reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("BSN invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkNullBelastingjaar() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters("01234", null, "ABC", reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("Belastingjaar invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkNullMiddel() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters("01234", "2019", null, reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("Middel invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkAllParametersNull() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters(null, null, null, reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("BSN invalid, Belastingjaar invalid, Middel invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkAllParametersEmpty() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		assertFalse(mh.validRequestParameters("    ", "  ", "  ", reporter));
		assertEquals(1, reporter.getProblems().size());
		assertEquals("BSN invalid, Belastingjaar invalid, Middel invalid", reporter.getProblems().get(0).getError());
	}
	@Test
	public void checkAllRecordsInOneLine() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		String[] testdata = new String[]{"TGL-ABS01       202103301226500"};
		List<String> data = mh.getData(Arrays.asList(testdata), reporter, "\n");
		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals(19, data.get(0).length());
		assertEquals("TGL-ABS0100     20\n", data.get(0));
	}
	@Test
	public void checkReplyForBehandelvoornemenFound() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		String[] testdata = "TGL-ABS01       \n0330122652021023\n".split("\n");
		when(batDao.existsBehandelvoorstel(any(Integer.class), any(Integer.class), any(String.class))).thenReturn(true);
		List<String> data = mh.getData(Arrays.asList(testdata), reporter, "\n");
		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals(38, data.get(0).length());
		assertEquals("TGL-ABS0100       \n033012265202102303\n", data.get(0));
	}
	@Test
	public void checkReplyForBehandelvoornemenFoundUsingDifferentLineEnding() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		String[] testdata = "TGL-ABS01       \r\n0330122652021023\r\n".split("\r\n");
		when(batDao.existsBehandelvoorstel(any(Integer.class), any(Integer.class), any(String.class))).thenReturn(true);
		List<String> data = mh.getData(Arrays.asList(testdata), reporter, "\r\n");
		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals(40, data.get(0).length());
		assertEquals("TGL-ABS0100       \r\n033012265202102303\r\n", data.get(0));
	}
	@Test
	public void checkReplyForBehandelvoornemenNotFound() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		String[] testdata = "TGL-ABS01       \n0330122652021023\n".split("\n");
		when(batDao.existsBehandelvoorstel(any(Integer.class), any(Integer.class), any(String.class))).thenReturn(false);
		List<String> data = mh.getData(Arrays.asList(testdata), reporter, "\n");
		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals(38, data.get(0).length());
		assertEquals("TGL-ABS0100       \n0330122652021023  \n", data.get(0));
	}
	@Test
	public void checkProcessingToLongRecords() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		String[] testdata = "TGL-ABS01        \n0330122652021MIDD\n".split("\n");
		when(batDao.existsBehandelvoorstel(any(Integer.class), any(Integer.class), any(String.class))).thenReturn(false);
		List<String> data = mh.getData(Arrays.asList(testdata), reporter, "\n");
		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals(38, data.get(0).length());
		assertEquals("TGL-ABS0100       \n0330122652021MID  \n", data.get(0));

		assertEquals(2, reporter.getProblems().size());
		assertEquals("Recordlength not correct: 1, 2, ", reporter.getProblems().get(0).getError());
		assertEquals("VoorloopRecord has incorrect length (17).", reporter.getProblems().get(1).getError());
	}
	@Test
	public void checkProcessingALotOfRecordsThatAreToLong() {
		ProgressReporter reporter = new ProgressReporter(thlDao);
		reporter.reportStart("1");
		String[] testdata = generateAbs01Records(40, "2021MIDD");
		when(batDao.existsBehandelvoorstel(any(Integer.class), any(Integer.class), any(String.class))).thenReturn(false);
		List<String> data = mh.getData(Arrays.asList(testdata), reporter, "\n");
		assertNotNull(data);
		assertEquals(1, data.size());
		assertEquals(779, data.get(0).length());
		assertTrue(data.get(0).startsWith("TGL-ABS0100       \n0330122652021MID  \n0330122662021MID  \n0330122672021MID  \n"));

		assertEquals(2, reporter.getProblems().size());
		assertEquals("Recordlength not correct: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, ", reporter.getProblems().get(0).getError());
		assertEquals("VoorloopRecord has incorrect length (17).", reporter.getProblems().get(1).getError());
	}

	private String[] generateAbs01Records(int quantity, String jaarAndMiddel) {
		List<String> result = new LinkedList<>();
		result.add("TGL-ABS01        ");
		for(int i = 0; i < quantity; i++) {
			result.add(String.format("%09d%s", 33012265 + i, jaarAndMiddel));
		}
		return result.toArray(new String[0]);
	}
}
