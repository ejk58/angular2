package nl.belastingdienst.iva.wd.thl.mq.handler;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import nl.belastingdienst.iva.wd.thl.reporting.ProgressReporter;

class AbstractHandlerTest {

	private static final int REQUEST_RECORD_LENGTH = 16;
	private static final int ANSWER_RECORD_LENGTH = 18;

	private final char[] fillerArray = new char[100];
	private String filler;

	private AbstractHandler ah;

	@BeforeEach
	public void setup() {
		ah = new AbstractHandler() {
			@Override
			public List<String> getData(List<String> records, ProgressReporter reporter, String lineEnding) { return Collections.emptyList(); }
			@Override
			int getAnswerRecordLength() { return ANSWER_RECORD_LENGTH; }
			@Override
			int getRequestRecordLength() { return REQUEST_RECORD_LENGTH; }
		};

		Arrays.fill(fillerArray, ' ');
		filler = new String(fillerArray);
	}

	@Test
	public void checkAddingToMakeCorrectLengthFromShortString() {
		StringBuilder sb = new StringBuilder();
		String shortString = "AbCdEf  ";
		sb.append(shortString);
		ah.makeAnswerRecordLengthCorrect(sb);
		assertEquals(Abs01Handler.ANSWER_RECORD_LENGTH, sb.length());
		String temp = shortString + filler;
		temp = temp.substring(0, Abs01Handler.ANSWER_RECORD_LENGTH);
		assertEquals(temp , sb.toString());
	}
	@Test
	public void checkAddingToMakeCorrectLengthFromToLongString() {
		StringBuilder sb = new StringBuilder();
		String longString = "AbCdEfGhIjKlMnOpQrStUvWxYzAbCdEfGhIjKlMnOpQrStUvWxYz";
		sb.append(longString);
		ah.makeAnswerRecordLengthCorrect(sb);
		String temp = longString.substring(0, Abs01Handler.ANSWER_RECORD_LENGTH);
		assertEquals(temp , sb.toString());
	}
	@Test
	void setErrocodeToZero() {
		StringBuilder sb = new StringBuilder();
		sb.append("            ");
		ah.setErrorCodeToZero(sb);
		assertEquals("         00 ", sb.toString());
	}

	@Test
	void setInvalidDateFormatErrorCode() {
		StringBuilder sb = new StringBuilder();
		sb.append("                  ");
		ah.setInvalidDateFormatErrorCode(sb);
		assertEquals("               80 ", sb.toString());
	}

	@Test
	void getTimestampFromMessageWithCorrectFormat() {
		String dateString = "20201231134556";
		Date datum = ah.getTimestampFromMessage(dateString);
		assertNotNull(datum);
		assertEquals(1609418756000L, datum.getTime());
	}
	@Test
	void getTimestampFromMessageWithInvalidCharacters() {
		String dateString = "20201231134556a";
		Date datum = ah.getTimestampFromMessage(dateString);
		assertNull(datum);
	}
	@Test
	void getTimestampFromMessageWithToShortFormat() {
		String dateString = "2020123113455";
		Date datum = ah.getTimestampFromMessage(dateString);
		assertNull(datum);
	}
	@Test
	void getTimestampFromMessageWithToLongFormat() {
		String dateString = "202012311345567";
		Date datum = ah.getTimestampFromMessage(dateString);
		assertNull(datum);
	}
	@Test
	void getTimestampFromMessageWithFormatContainingLetters() {
		String dateString = "20201B31134556";
		Date datum = ah.getTimestampFromMessage(dateString);
		assertNull(datum);
	}
	@Test
	void getTimestampFromMessageWithBadFormat() {
		String dateString = "20201331134556";
		Date datum = ah.getTimestampFromMessage(dateString);
		assertNull(datum);
	}
}