package nl.belastingdienst.iva.wd.thl.mq;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

public class MessageHandlerExtraTest {

	private final MessageHandler messageHandler = new MessageHandler();

	@Test
	public void checkCreateBadHeaderResponseWithNormalBatchId() {
		List<String> request = Arrays.asList("AbC-dEf01xyz", "SomeParameter");
		String result = messageHandler.createBadHeaderResponse(request, "\n");
		assertNotNull(result);
		assertEquals("AbC-dEf0199z\nSomeParameter\n", result);
	}
	@Test
	public void checkCreateBadHeaderResponseWithBatchIdThatIsToShort() {
		List<String> request = Arrays.asList("AbC", "SomeParameter");
		String result = messageHandler.createBadHeaderResponse(request, "\n");
		assertNotNull(result);
		assertEquals("AbC      99\nSomeParameter\n", result);
	}
}
