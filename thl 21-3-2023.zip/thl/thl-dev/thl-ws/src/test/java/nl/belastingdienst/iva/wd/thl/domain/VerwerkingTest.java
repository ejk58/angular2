package nl.belastingdienst.iva.wd.thl.domain;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class VerwerkingTest {

	@Test
	public void checkValidationMaxLengthOfTypeFieldExpectNoProblem() {
		Verwerking verwerking = new Verwerking();
		verwerking.setType("123456789012345");
		assertEquals("123456789012345", verwerking.getType());
	}
	@Test
	public void checkValidationMaxLengthOfTypeFieldExpectATruncateType() {
		Verwerking verwerking = new Verwerking();
		verwerking.setType("1234567890123456");
		assertEquals("123456789012345", verwerking.getType());
	}

	@Test
	public void checkValidationMaxLengthOfCorrelationIdFieldExpectNoProblem() {
		String testStr = "12345678901234567890123456789012345678901234567890";
		Verwerking verwerking = new Verwerking();
		verwerking.setCorrelationId(testStr);
		assertEquals(testStr, verwerking.getCorrelationId());
	}
	@Test
	public void checkValidationMaxLengthOfCorrelationIdFieldExpectATruncatedCorrelationId() {
		String testStr = "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901";
		Verwerking verwerking = new Verwerking();
		verwerking.setCorrelationId(testStr);
		assertEquals("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890", verwerking.getCorrelationId());
	}
}
