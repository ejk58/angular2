package nl.belastingdienst.iva.wd.thl.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class OrgDaoTest {

	@Mock
	private EntityManager em;

	@Mock
	private Query query;

	@InjectMocks
	private OrgDao orgDao;

	@Test
	public void checkNullValuesGetReplacedByNulls() {
		Timestamp ts0701 = Timestamp.valueOf(" 2021-01-07 12:50:00.000000000");
		List<Object[]> mockData = Arrays.asList(new Object[][]{
				{3456789, ts0701, null, ts0701, null, 1, 2},
				{3456788, ts0701, null, ts0701, null, null, 2},
				{3456787, ts0701, null, ts0701, null, 1, null},
				{3456786, ts0701, null, ts0701, null, null, null} } );
		when(em.createNativeQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyInt(), any())).thenReturn(query);
		when(query.getResultList()).thenReturn(mockData);

		List<String> result = orgDao.getOrgChangesSince(new Date());
		assertEquals(4, result.size());
		assertEquals("0034567890000100002", result.get(0));
		assertEquals("0034567880000000002", result.get(1));
		assertEquals("0034567870000100000", result.get(2));
		assertEquals("0034567860000000000", result.get(3));

	}
	@Test
	public void checkOrderIscorrectWithMultipleRecordsforSameEntity() {
		Timestamp ts0501Earlier = Timestamp.valueOf(" 2021-01-05 12:00:00.000000000");
		Timestamp ts0501 = Timestamp.valueOf(" 2021-01-05 12:50:00.000000000");
		Timestamp ts0701 = Timestamp.valueOf(" 2021-01-07 12:50:00.000000000");
		Timestamp ts0801 = Timestamp.valueOf(" 2021-01-08 12:50:00.000000000");
		Timestamp ts0901 = Timestamp.valueOf(" 2021-01-09 12:50:00.000000000");
		List<Object[]> mockData = Arrays.asList(new Object[][]{
				{3456788, ts0501, ts0701, ts0501,        null,   0, 2},
				{3456788, ts0701, null,   ts0501,        null,   1, 5},
				{3456788, ts0501, null,   ts0501,        null,   1, 2},
				{3456789, ts0501, ts0701, ts0501Earlier, null,   1, 2},
				{3456789, ts0501, null,   ts0501Earlier, null,   1, 2},
				{3456787, ts0501, null,   ts0901,        null,   4, 5},
				{3456787, ts0701, null,   ts0501,        ts0801, 3, 4},
				{3456787, ts0701, null,   ts0501,        null,   3, 4},
		} );
		when(em.createNativeQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyInt(), any())).thenReturn(query);
		when(query.getResultList()).thenReturn(mockData);

		List<String> result = orgDao.getOrgChangesSince(new Date());
		assertEquals(3, result.size());
		assertEquals("0034567880000100005", result.get(0));
		assertEquals("0034567890000000000", result.get(1));
		assertEquals("0034567870000400005", result.get(2));

	}
}
