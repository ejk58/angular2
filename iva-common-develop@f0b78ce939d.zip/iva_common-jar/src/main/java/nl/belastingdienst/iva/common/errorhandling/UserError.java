package nl.belastingdienst.iva.common.errorhandling;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;

public class UserError implements Serializable {
	private static final long serialVersionUID = -2306305628151664929L;
	static Map<Integer, String> allErrors = new HashMap<>();
	static {
		allErrors.put(404, "Item not found");
		allErrors.put(1000, "MediaType not supported");
		allErrors.put(2000, "Message structure violations found");
		allErrors.put(3000, "Configuration is not valid");
		allErrors.put(4000, "Status is not valid");
		allErrors.put(4001, "Trying to pickup signal, but signal already pickedup.");
		allErrors.put(4002, "Trying to pickup signal, but case already completed.");
		allErrors.put(4003, "Trying to pickup signal, but case is removed.");
		allErrors.put(4004, "Trying to pickup signal, but case is canceled.");
		allErrors.put(4005, "Trying to pickup signal, but signal is not active (there is a newer signal)");
		allErrors.put(4006, "Trying to pickup signal, but case is failed.");
		allErrors.put(4007, "Trying to pickup signal, but case is toextend.");
		allErrors.put(4008, "Trying to pickup signal, but case is manual.");
		allErrors.put(4009, "Trying to pickup signal, but case is toextend_manual.");
		allErrors.put(4010, "Trying to pickup signal, but the signal is being blocked");
		allErrors.put(4011, "Trying to complete case, but case is waiting.");
		allErrors.put(4012, "Trying to complete case, but case already completed.");
		allErrors.put(4013, "Trying to complete case, but case is removed.");
		allErrors.put(4014, "Trying to complete case, but case is canceled.");
		allErrors.put(4015, "Trying to complete case, but case not found or multiple cases found.");
		allErrors.put(4016, "Trying to complete case, but the active signal is not picked up.");
		allErrors.put(4017, "Trying to complete case, but case is failed.");
		allErrors.put(4018, "Trying to complete case, but case is toextend.");
		allErrors.put(4019, "Trying to complete case, but case is manual.");
		allErrors.put(4020, "Trying to complete case, but case is toextend_manual.");
		allErrors.put(4021, "Trying to update case, but case already completed.");
		allErrors.put(4022, "Trying to update case, but case already removed.");
		allErrors.put(4023, "Trying to update case, but case already canceled.");
		allErrors.put(4031, "Trying to delete case, but case already completed.");
		allErrors.put(4032, "Trying to delete case, but case already removed.");
		allErrors.put(4033, "Trying to delete case, but case already canceled.");
		allErrors.put(4034, "Trying to recreate postsignal, but signal not found or not completed.");
		allErrors.put(4041, "Trying to update signal, but signal not found.");
		allErrors.put(4042, "Trying to update signal, but signal is not available or picked up.");
		allErrors.put(4043, "Trying to set attribute on signal, but attribute is required attribute.");
		allErrors.put(4044, "Trying to remove attribute on signal, but attribute is required attribute.");
		allErrors.put(4045, "Trying to update signal, but signal is not available.");
		allErrors.put(4050, "Number of casereferences is greater then 50.");
		allErrors.put(4060, "Trying to retrieve case, but case not found or multiple cases found.");
		allErrors.put(4070, "Trying to retrieve active signal, but case not found or multiple cases found.");
		allErrors.put(4071, "Trying to retrieve active signal, but case already completed.");
		allErrors.put(4072, "Trying to retrieve active signal, but case case is removed.");
		allErrors.put(4073, "Trying to retrieve active signal, but case is canceled.");
		allErrors.put(4080, "Trying to decline signal, but the signal is not available.");
		allErrors.put(4081, "Trying to pick up signal, but the signal is declined.");
		allErrors.put(4090, "Trying to reallocate werkitem, but the item is not picked up.");
		allErrors.put(4091, "Trying to reallocate werkitem, but the item is already reallocated.");
	}

	@ApiModelProperty(value = "Error code")
	private Integer code;

	@ApiModelProperty(value = "The message for the user")
	private String userMessage;

	@ApiModelProperty(value = "Dev oriented message")
	private String internalMessage;

	@ApiModelProperty(value = "Parameters for the error")
	private Map<String, String> parameters = new HashMap<>();

	public UserError(Integer code) {
		super();
		this.code = code;
		this.userMessage = "";
		this.internalMessage = allErrors.get(code);
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getUserMessage() {
		return userMessage;
	}

	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}

	public String getInternalMessage() {
		return internalMessage;
	}

	public void setInternalMessage(String internalMessage) {
		this.internalMessage = internalMessage;
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}

	public void addParameter(String key, String value) {
		this.parameters.put(key, value);
	}

	public void addViolations(List<MyConstraintViolation> violations) {
		Integer keyNum = 0;
		for (MyConstraintViolation violation : violations) {
			String key = violation.getProperty();
			if (key == null) {
				key = "Key" + keyNum++;
			}
			this.addParameter(key,
					String.format("Problem with value: %s; violation message: %s", violation.getValue(), violation.getMessage()));
		}
	}

	public void addViolations(Map<Integer, List<MyConstraintViolation>> violationsMap) {
		for (Map.Entry<Integer, List<MyConstraintViolation>> entry : violationsMap.entrySet()) {
			String key = "Signaal_" + entry.getKey();
			Integer keyNum = 0;
			for (MyConstraintViolation violation : entry.getValue()) {
				String prop = violation.getProperty();
				if (prop == null) {
					prop = "Prop" + keyNum++;
				}
				this.addParameter(key + "_" + prop, String.format("Problem with value: %s; violation message: %s",
						violation.getValue(), violation.getMessage()));
			}
		}
	}

	public void addContext(UserContext ctx) {
		Integer keyNum = 0;
		addParameter("Functie", ctx.getFunction());
		addParameter("Identificatie", ctx.getIdentification());
		for (Map.Entry<String, String> entry : ctx.getParameters().entrySet()) {
			String key = entry.getKey();
			if (key == null) {
				key = "Key" + keyNum;
			}
			Object value = entry.getValue();
			if (value instanceof String || value instanceof Integer) {
				addParameter(key, value.toString());
			}
			keyNum++;
		}
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserError [");
		if (code != null)
			builder.append("code=").append(code).append(", ");
		if (userMessage != null)
			builder.append("userMessage=").append(userMessage).append(", ");
		if (parameters != null)
			builder.append("parameters=").append(parameters);
		builder.append("]");
		return builder.toString();
	}
}
