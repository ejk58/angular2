
package nl.belastingdienst.iva.common.logging;

import java.lang.management.ManagementFactory;
import java.security.SecureRandom;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.lookup.AbstractLookup;
import org.apache.logging.log4j.core.lookup.StrLookup;

/**
 * Lookup implementatie voor de naam van de virtual machine waarop de applicatie draait.
 *
 */
@Plugin(name = "vmname", category = StrLookup.CATEGORY)
public class VirtualMachineNameLookup extends AbstractLookup {

	@Override
	public String lookup(LogEvent logEvent, String key) {
		String name;
		try {
			String[] nameParts = ManagementFactory.getRuntimeMXBean().getName().split("@");
			name = nameParts[1] + "-" + nameParts[0];
		} catch (Exception e) {
			name = "UNKNOWN-" + new SecureRandom().nextInt(10000);
		}
		return name;
	}

}
