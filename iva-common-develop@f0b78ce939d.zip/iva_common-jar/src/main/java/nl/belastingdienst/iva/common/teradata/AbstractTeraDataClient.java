package nl.belastingdienst.iva.common.teradata;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.annotation.Resource;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import nl.belastingdienst.iva.common.errorhandling.CommonException;
import nl.belastingdienst.iva.common.errorhandling.DataproviderClientException;
import nl.belastingdienst.iva.common.util.EncryptionUtil;

public abstract class AbstractTeraDataClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractTeraDataClient.class);

	private static final ObjectMapper mapper = new ObjectMapper();

	@Resource(name = "var/teraDataUserIdRef")
	private String teradataUserid;

	@Resource(name = "var/teraDataPasswordEncryptedRef")
	private String teradataEncPass;

	@Resource(name = "rest/teradata/urlRef")
	private java.net.URL restUrl;

	public JsonNode getContent(String query) throws CommonException {
		LOGGER.debug(query);

		int connectionTimeOut = 5000; // Timeout in millis.
		RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(connectionTimeOut)
				.setConnectTimeout(connectionTimeOut).setSocketTimeout(connectionTimeOut).build();

		CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).useSystemProperties().build();
		HttpPost httpPost = initHttpPost(query);
		HttpEntity responseEntity = null;
		long before = System.currentTimeMillis();
		try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
			checkTeradataProcessingTime(query, before);

			LOGGER.debug(response.getStatusLine().toString());
			responseEntity = response.getEntity();

			JsonNode root = mapper.readTree(responseEntity.getContent());
			if (response.getStatusLine().getStatusCode() != 200) {
				String message = "Failed to run a query on Teradata with error " + root.path("message").textValue();
				throw new DataproviderClientException(message);
			}
			return root;
		} catch (IOException e) {
			throw new DataproviderClientException(e);
		} finally {
			if (responseEntity != null) {
				try {
					responseEntity.consumeContent();
				} catch (IOException e) {
					/* Doing nothing here. */ }
			}
		}
	}

	private void checkTeradataProcessingTime(String query, long before) {
		long after = System.currentTimeMillis();
		long duration = after - before;

		if (duration > 2000L) {
			LOGGER.warn("Slow query (" + duration + "ms) on Teradata: " + query);
		}
	}

	private HttpPost initHttpPost(String query) throws CommonException {
		HttpPost httpPost = new HttpPost(restUrl.toString());
		httpPost.addHeader(HttpHeaders.AUTHORIZATION, createCredentials());
		httpPost.addHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON);
		httpPost.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);

		LOGGER.info("URL: " + restUrl.toString());
		LOGGER.info("Query: " + query);
		StringEntity entity = buildBody(query);
		httpPost.setEntity(entity);

		return httpPost;
	}

	public static String getExceptionsForMessage(Exception exception) {
		Throwable cause = exception;
		StringBuilder exceptionBuilder = new StringBuilder();

		exceptionBuilder.append(cause.getClass().getSimpleName());
		while (cause.getCause() != null) {
			cause = cause.getCause();
			exceptionBuilder.append(" > ");
			exceptionBuilder.append(cause.getClass().getSimpleName());
		}

		return exceptionBuilder.toString();
	}

	private StringEntity buildBody(String query) throws CommonException {
		StringEntity entity = null;
		try {
			entity = new StringEntity(query);
			entity.setContentEncoding("application/json");
		} catch (UnsupportedEncodingException e) {
			throw new CommonException("Problem building teradata query.", e);
		}
		return entity;
	}

	private String createCredentials() {
		String credential = teradataUserid + ":" + EncryptionUtil.getInstance().decrypt(teradataEncPass);
		byte[] credBytes = credential.getBytes();
		byte[] encodedCredBytes = Base64.encodeBase64(credBytes, false);
		return "Basic " + new String(encodedCredBytes); //$NON-NLS-1$
	}
}
