package nl.belastingdienst.iva.common.errorhandling;

import javax.ejb.ApplicationException;

@ApplicationException
public class UserErrorException extends Exception {
	private static final long serialVersionUID = 9089908005989795456L;
	private final UserError userError;

	public UserErrorException(UserError error, String userMessage) {
		super();
		this.userError = error;
		this.userError.setUserMessage(userMessage);
	}

	public UserError getUserError() {
		return userError;
	}

}
