package nl.belastingdienst.iva.common.errorhandling;

import javax.ejb.ApplicationException;

@ApplicationException
public class DataproviderClientException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DataproviderClientException(Exception cause) {
		super(cause);
	}

	public DataproviderClientException(String message) {
		super(message);
	}

	public DataproviderClientException(String message, Exception cause) {
		super(cause.getMessage() == null ? message : message + " > " + cause.getMessage(), cause);
	}
}
