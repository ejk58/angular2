package nl.belastingdienst.iva.common.validator;

public interface DateTimeValidator {
	boolean isValid(String dateTimeStr);
}