package nl.belastingdienst.iva.common.errorhandling;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class ErrorInterceptor {

	@AroundInvoke
	public Object process(InvocationContext ic) throws InterceptedException {
		try {
			return ic.proceed();
		} catch (UpstreamWebWrapperException e) {
			throw new InterceptedException(createContext(ic), e);
		} catch (Exception e) {
			throw new InterceptedException(createContext(ic), e);
		}
	}

	private UserContext createContext(InvocationContext ic) {
		Method m = ic.getMethod();
		Object[] parmValues = ic.getParameters();
		Parameter[] parms = m.getParameters();
		UserContext ctx = new UserContext(m.getName(), null);
		int i = 0;
		for (; i < parmValues.length; i++) {
			String parmName = parms[i].getName();
			if (parmValues[i] == null)
				parmValues[i] = "<null>";
			ctx.addParameters(parmName, parmValues[i].toString());

		}
		return ctx;
	}
}
