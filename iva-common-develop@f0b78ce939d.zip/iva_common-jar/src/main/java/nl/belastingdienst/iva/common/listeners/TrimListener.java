/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: TrimListener.java
 *             Auteur: denee00
 *    Creatietijdstip: 2 mei 2018 09:58:38
 *          Copyright: (c) 2018 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.common.listeners;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.PostLoad;

/**
 * Listener voor trimmen attributen type string, configuratie in ORM.xml (naast persistence.xml)
 * voorbeeld:
 * 
 * 
 * <?xml version="1.0" encoding="UTF-8"?>
 * 
 * <entity-mappings xmlns="http://java.sun.com/xml/ns/persistence/orm" xmlns:xsi=
 * "http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation=
 * "http://java.sun.com/xml/ns/persistence/orm orm_2_0.xsd" version="2.0">
 * <persistence-unit-metadata> <persistence-unit-defaults> <entity-listeners>
 * <entity-listener class="nl.belastingdienst.iva.common.datasource.TrimListener">
 * </entity-listener> </entity-listeners> </persistence-unit-defaults> </persistence-unit-metadata>
 * </entity-mappings>
 * 
 * 
 * 
 * @author denee00
 */
public class TrimListener {

	private final Map<Class<?>, Set<Field>> trimProperties = new HashMap<>();

	@PostLoad
	public void trimStringsAfterLoad(final Object entity) throws Exception {
		for (final Field fieldToTrim : getTrimProperties(entity.getClass())) {
			final String propertyValue = (String) fieldToTrim.get(entity);
			if (propertyValue != null)
				fieldToTrim.set(entity, propertyValue.trim());
		}
	}

	private Set<Field> getTrimProperties(Class<?> entityClass) throws Exception {
		if (Object.class.equals(entityClass))
			return Collections.emptySet();
		Set<Field> propertiesToTrim = trimProperties.get(entityClass);
		if (propertiesToTrim == null) {
			propertiesToTrim = new HashSet<>();
			for (final Field field : entityClass.getDeclaredFields()) {
				if (field.getType().equals(String.class) && !Modifier.isFinal(field.getModifiers())) {
					field.setAccessible(true);
					propertiesToTrim.add(field);
				}
			}
			trimProperties.put(entityClass, propertiesToTrim);
		}
		return propertiesToTrim;
	}

}
