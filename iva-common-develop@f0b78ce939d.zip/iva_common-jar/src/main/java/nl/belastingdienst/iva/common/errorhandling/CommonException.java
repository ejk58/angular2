package nl.belastingdienst.iva.common.errorhandling;

/**
 * Base class for our exceptions.
 * 
 * @author weera09
 */
public class CommonException extends RuntimeException {
	private static final long serialVersionUID = 9089908005989795456L;

	/**
	 * @param message
	 */
	public CommonException(String message) {
		super(message);
	}

	public CommonException(String message, Exception e) {
		super(message, e);
	}

}
