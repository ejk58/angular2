package nl.belastingdienst.iva.common.apiKey;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "API_KEY")
@NamedQuery(name = "ApiKey.findAll", query = "SELECT a FROM ApiKey a")
public class ApiKey {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "API_KEY")
    private String apiKey;

    @Column(name = "CUSTOMER")
    private String customer;

    @Column(name = "AUTHORIZED_METHODS")
    private String authorizedMethods;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getAuthorizedMethods() {
        return authorizedMethods;
    }

    public void setAuthorizedMethods(String authorizedMethods) {
        this.authorizedMethods = authorizedMethods;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "ApiKey [id=" + id + ", apiKey=" + apiKey + ", customer=" + customer + ", authorizedMethods=" + authorizedMethods
                + "]";
    }

}
