package nl.belastingdienst.iva.common.errorhandling;

import javax.ejb.ApplicationException;
import javax.xml.ws.WebServiceException;

@ApplicationException
public class NotFoundException extends WebServiceException {

	private static final long serialVersionUID = 140279259840901665L;

	private final UserContext context;

	public NotFoundException(UserContext context) {
		super();
		this.context = context;
	}

	public UserContext getContext() {
		return context;
	}
}
