/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: CorsFilter.java
 *             Auteur: denee00
 *    Creatietijdstip: 27 jun. 2018 09:27:35
 *          Copyright: (c) 2018 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.common.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * Servlet Filter implementation class CORSFilter
 * 
 */

public class CORSFilter implements Filter {

	/**
	 * 
	 * Default constructor.
	 * 
	 */

	public CORSFilter() {
		super();
	}

	/**
	 * 
	 * @see Filter#destroy()
	 * 
	 */
	@Override
	public void destroy() {
		// Er is niets om op te ruimen.
	}

	/**
	 * 
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 * 
	 */
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		// Authorize (allow) all domains to consume the content
		((HttpServletResponse) servletResponse).addHeader("Access-Control-Allow-Origin", "*");
		((HttpServletResponse) servletResponse).addHeader("Access-Control-Allow-Methods", "GET, OPTIONS, HEAD, PUT, POST");
		HttpServletResponse resp = (HttpServletResponse) servletResponse;
		// For HTTP OPTIONS verb/method reply with ACCEPTED status code -- per CORS handshake
		if ("OPTIONS".equals(request.getMethod())) {
			resp.setStatus(HttpServletResponse.SC_ACCEPTED);
			return;
		}

		// pass the request along the filter chain
		chain.doFilter(request, servletResponse);
	}

	/**
	 * 
	 * @see Filter#init(FilterConfig)
	 * 
	 */
	@Override
	public void init(FilterConfig fConfig) throws ServletException {
		// nothing to do
	}
}
