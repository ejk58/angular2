/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: ShortIdGenerator.java
 *             Auteur: denee00
 *    Creatietijdstip: 29-10-2020 13:21
 *          Copyright: (c) 2020 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.common.util;

import java.util.UUID;

public class ShortIdGenerator {

	private ShortIdGenerator() {
		// privaate constructor
	}

	// Een kenmerk / human readable ID / ShortID wordt afgeleid door de volgende formule:
	// ZaakID = UUIDv4 = e8ea073cd5994a7dbdf434e08a53f7f2 (128 bits, hexadecimaal, op te slaan);
	// ZaakID = UUIDv4 = e8ea073c-d599-4a7d-bdf4-34e08a53f7f2 (128 bits plus opmaak, vier streepjes, voor weergave);
	// Voor de eerste tien getallen pakken we de decimale waarde modulo 10 en tellen er 48 bij op om ASCII cijfers te krijgen;
	// Deze ASCII tekens concateneren we tot:
	// ShortID (als getal voor opslaan) =484007323
	// ShortID (als string voor weergave) =484 007 323
	public static String generateShortIdAsString(String uuid) {
		StringBuilder sb = getStringBuilder(uuid);
		return sb.toString();
	}

	public static String generateShortIdAsStringWithSpaces(String uuid) {
		StringBuilder sb = getStringBuilder(uuid);
		return sb.insert(3, " ").insert(7, " ").toString();
	}

	private static StringBuilder getStringBuilder(String uuid) {
		if (uuid == null || !isValidUuid(uuid)) {
			throw new IllegalArgumentException(uuid + " is not a valid uuid");
		}
		StringBuilder sb = new StringBuilder();
		for (char c : uuid.replace("-", "").toLowerCase().substring(0, 9).toCharArray()) {
			sb.append(Integer.parseInt(String.valueOf(c), 16) % 10);
		}
		return sb;
	}


	private static boolean isValidUuid(String strUuid) {
		boolean result = true;
		try {
			UUID.fromString(strUuid);
		} catch (IllegalArgumentException exception) {
			result = false;
		}
		return result;
	}
}
