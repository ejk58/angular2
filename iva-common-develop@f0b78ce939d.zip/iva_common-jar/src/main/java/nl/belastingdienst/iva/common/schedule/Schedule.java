package nl.belastingdienst.iva.common.schedule;

import java.util.Date;

import javax.persistence.*;

@Entity
@NamedQuery(name = "Schedule.retrieveActiveNotStartedSchedules", query = "SELECT s FROM Schedule s WHERE s.active = true AND s.started = false")
public class Schedule {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private boolean active;

	private boolean started;

	@Column(name = "LAST_RUN")
	private Date lastRun;

	private String cron;

	private String algorithm;

	@Version
	private Long version;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isStarted() {
		return started;
	}

	public void setStarted(boolean started) {
		this.started = started;
	}

	public Date getLastRun() {
		return lastRun;
	}

	public void setLastRun(Date lastRun) {
		this.lastRun = lastRun;
	}

	public String getCron() {
		return cron;
	}

	public void setCron(String cron) {
		this.cron = cron;
	}

	public String getAlgorithm() {
		return algorithm;
	}

	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long v) {
		this.version = v;
	}
}
