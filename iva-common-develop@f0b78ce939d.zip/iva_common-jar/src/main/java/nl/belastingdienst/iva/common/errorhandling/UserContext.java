package nl.belastingdienst.iva.common.errorhandling;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserContext implements Serializable {
	private static final long serialVersionUID = -5402299757003578035L;
	private static final Logger LOGGER = LoggerFactory.getLogger(UserContext.class);
	public static final String PROCESSING_TIME_PREFIX = "processingTime";
	private Boolean ok;
	private String identification;
	private String function;
	private ArrayList<UserError> errors;
	private Map<String, String> parameters = new HashMap<>();

	public UserContext(String function, String identification) {
		super();
		this.function = function;
		this.identification = identification;
		this.ok = true;
		this.errors = new ArrayList<>();
	}

	public Boolean isOk() {
		if (!this.errors.isEmpty())
			this.ok = false;
		return ok;
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public List<UserError> getErrors() {
		return errors;
	}

	public void addError(UserError error) {
		this.ok = false;
		this.errors.add(error);
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}

	public void addParameters(String key, String value) {
		this.parameters.put(key, value);
	}

	@Override
	public String toString() {
		return "UserContext [ok=" + ok + ", identification=" + identification + ", function=" + function + ", errors="
				+ errors + ", parameters=" + parameters + "]";
	}

	public void reportProcessingTimes() {
		for (Entry<String, String> entry : parameters.entrySet()) {
			String key = entry.getKey();
			if (key.startsWith(PROCESSING_TIME_PREFIX)) {
				LOGGER.info(String.format("MihCallName=%s, ElapseTime=%s msec.", key.substring(PROCESSING_TIME_PREFIX.length() + 1),
						entry.getValue()));
			}
		}
	}

}
