package nl.belastingdienst.iva.common.schedule;

import java.util.List;

import javax.ejb.EJBException;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.OptimisticLockException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nl.belastingdienst.iva.common.logging.MattermostAppender;

public abstract class AbstractScheduleService {

	/*
	 * Denk er aan om in de persistence.xml de onderstaande regel op te nemen !!!
	 * <class>nl.belastingdienst.iva.common.schedule.Schedule</class> Anders error dat een query
	 * "Schedule.retrieveActiveNotStartedSchedules" niet gevonden kan worden
	 */

	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractScheduleService.class);

	@Inject
	protected ScheduleStatusService scheduleStatusService;

	protected abstract EntityManager getEntityManager();

	protected abstract void timeout();

	protected void checkWork() {
		scheduleStatusService.setEntityManager(getEntityManager());
		List<Schedule> schedules = scheduleStatusService.retrieveActiveNotStartedSchedules();
		for (Schedule schedule : schedules) {
			if (ScheduleUtil.mustRun(schedule.getCron(), schedule.getLastRun())) {
				try {
					if (scheduleStatusService.start(schedule.getId())) {
						ScheduleAlgorithm algo = ScheduleUtil.instantiateScheduleAlgorithm(schedule.getAlgorithm());
						algo.execute();
						scheduleStatusService.stop(schedule.getId());
					}
				} catch (EJBException e) {
					LOGGER.error(
							String.format("Execution of algorithm %s for schedule %d failed", schedule.getAlgorithm(),
									schedule.getId()),
							e);
					LOGGER.error(MattermostAppender.marker, "Execution of algorithm {} for schedule {} failed",
							schedule.getAlgorithm(), schedule.getId());
				} catch (OptimisticLockException e) {
					LOGGER.debug("OptimisticLockException: It seems that another scheduler has already started");
				}catch (Exception e) {
					LOGGER.error("ScheduleService unexpected error", e);
					LOGGER.error(MattermostAppender.marker, "ScheduleService unexpected error");
				}
			}
		}
	}

}
