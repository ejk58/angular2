package nl.belastingdienst.iva.common.validator;

import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;

public class DateTimeValidatorIsoOffsetDateTime implements DateTimeValidator {

	@Override
	public boolean isValid(String dateTimeStr) {
		try {
			// Geen ISO_LOCAL_DATE_TIME als formatter omdat milliseconden n.v.t zijn
			// Acceptatie van elke offset als die in juiste formaat is
			OffsetDateTime.parse(dateTimeStr, FormatterConstants.FORMATTER_DATETIME);
		} catch (DateTimeParseException e) {
			return false;
		} catch (NullPointerException e) {
			return false;
		}
		return true;
	}
}
