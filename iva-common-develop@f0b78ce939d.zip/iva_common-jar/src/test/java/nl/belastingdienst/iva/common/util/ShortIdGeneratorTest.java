/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: ShortIdGeneratorTest.java
 *             Auteur: denee00
 *    Creatietijdstip: 29-10-2020 13:40
 *          Copyright: (c) 2020 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.common.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ShortIdGeneratorTest {

	private static final String UUID_E8EA073C_D599_4A7D_BDF4_34E08A53F7F2 = "e8ea073c-d599-4a7d-bdf4-34e08a53f7f2";
	private static final String SHORT_ID_484_007_323 = "484007323";
	private static final String SHORT_ID_484_007_323_WITH_SPACES = "484 007 323";

	@Test
	public void testGenerateShortId() {
		String shortId = ShortIdGenerator.generateShortIdAsString(UUID_E8EA073C_D599_4A7D_BDF4_34E08A53F7F2.toUpperCase());
		assertEquals(SHORT_ID_484_007_323, shortId);

		shortId = ShortIdGenerator.generateShortIdAsString(UUID_E8EA073C_D599_4A7D_BDF4_34E08A53F7F2).replace("-", "");
		assertEquals(SHORT_ID_484_007_323, shortId);

		shortId = ShortIdGenerator.generateShortIdAsString(UUID_E8EA073C_D599_4A7D_BDF4_34E08A53F7F2);
		assertEquals(SHORT_ID_484_007_323, shortId);
	}

	@Test
	public void testGenerateShortIdWithSpaces() {
		String shortId = ShortIdGenerator.generateShortIdAsStringWithSpaces(UUID_E8EA073C_D599_4A7D_BDF4_34E08A53F7F2);
		assertEquals(SHORT_ID_484_007_323_WITH_SPACES, shortId);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGenerateShortIdFail1() {
		ShortIdGenerator.generateShortIdAsString("e8ea07");
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGenerateShortIdFail2() {
		ShortIdGenerator.generateShortIdAsString(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGenerateShortIdFail3() {
		ShortIdGenerator.generateShortIdAsString("h8ea073c-d599-4a7d-bdf4-34e08a53f7f2".toUpperCase());
	}
}
