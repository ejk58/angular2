/*
 *
 *  ---------------------------------------------------------------------------------------------------------
 *              Titel: TrimListenerTest.java
 *             Auteur: denee00
 *    Creatietijdstip: 2 mei 2018 13:43:02
 *          Copyright: (c) 2018 Belastingdienst / Centrum voor Applicatieontwikkeling en Onderhoud,
 *                     All Rights Reserved.
 *  ---------------------------------------------------------------------------------------------------------
 *                                              |   Unpublished work. This computer program includes
 *     De Belastingdienst                       |   Confidential, Properietary Information and is a
 *     Postbus 9050                             |   trade Secret of the Belastingdienst. No part of
 *     7300 GM  Apeldoorn                       |   this file may be reproduced or transmitted in any
 *     The Netherlands                          |   form or by any means, electronic or mechanical,
 *     http://belastingdienst.nl/               |   for the purpose, without the express written
 *                                              |   permission of the copyright holder.
 *  ---------------------------------------------------------------------------------------------------------
 *
 */
package nl.belastingdienst.iva.common.listeners;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Testklasse voor TrimListener
 * 
 * @author denee00
 */
public class TrimListenerTest {

	@Test
	public void testTrimNotFinalStringFields() throws Exception {
		TrimListener tl = new TrimListener();
		TestEntity entity = new TestEntity();
		tl.trimStringsAfterLoad(entity);
		assertEquals("lengte10   ", entity.getFinalString());
		assertEquals("lengte7", entity.getNotFinalString());
		assertEquals(Integer.valueOf(8), entity.getIntField());
	}
}

class TestEntity {

	private final String finalString = "lengte10   ";
	private String notFinalString = "lengte7   ";
	private Integer intField = Integer.valueOf(8);

	public String getNotFinalString() {
		return notFinalString;
	}

	public void setNotFinalString(String notFinalString) {
		this.notFinalString = notFinalString;
	}

	public Integer getIntField() {
		return intField;
	}

	public void setIntField(Integer intField) {
		this.intField = intField;
	}

	public String getFinalString() {
		return finalString;
	}
}
