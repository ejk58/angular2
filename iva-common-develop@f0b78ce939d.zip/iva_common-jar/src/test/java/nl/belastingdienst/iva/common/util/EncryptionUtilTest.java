package nl.belastingdienst.iva.common.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class EncryptionUtilTest {

	@Test
	public void testGenerateEncryptedPassword() {
		String pass = "i-V-a-Werkgroep";
		String encryptedPassword = EncryptionUtil.getInstance().encrypt(pass);
		System.out.println(encryptedPassword);
		String decryptedPassword = EncryptionUtil.getInstance().decrypt(encryptedPassword);
		assertEquals(pass, decryptedPassword);

	}
}
