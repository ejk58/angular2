## Release notes
| version | datum    | user    | Aanpassingen                            |
|---------|----------|---------|-----------------------------------------|
| 0.2.0   | 20210311 | weera09 | Schedule domain class voorzien van version member met @Version annotatie. Bij nader inzien was dit niet echt nodig omdat bij het starten van een ealgoritme een pessimistic lock wordt gebruikt wat lezen of schrijven door een ander proces verhindert. Ik heb de @Version wel laten staan en ook het afvangen van de OptimisticLockException in AbstractScheduleService.|