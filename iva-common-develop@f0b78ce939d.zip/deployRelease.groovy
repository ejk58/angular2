@Library("GENERIC") _
    pipelineDeployArtifactFromNexus_v1 {
	baseDirectory = "iva_common-jar"
	deploymentId = "iva-common"
	integrationPipeline = ""
	packageChoices = "iva-common\n"
	applicationVersionChoices = "0.8.0\n0.7.0\n0.6.0\n0.5.0\n0.4.0"
	asVersionChoices = ""
	environmentChoices = "tst\nacc\nprd"
	streetChoices = "str11\nstr12\nstr13\nstr14\nstr15\nstr16"
}
