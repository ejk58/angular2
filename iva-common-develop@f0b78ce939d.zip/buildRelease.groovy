@Library("GENERIC") _
    pipelineRelease {
    baseDirectory = "iva_common-jar"
	deploymentId = "iva-common"
	deployPipeline = ""
	integrationPipeline = ""
	environmentChoices = "tst\nacc"
	streetChoices = "str11"
}
